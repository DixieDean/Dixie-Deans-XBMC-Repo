# coding: UTF-8
import sys
l1l11ll1_opy_ = sys.version_info [0] == 2
l1llll1l_opy_ = 2048
l1l1ll1l_opy_ = 7
def l11ll_opy_ (l1l11l_opy_):
	global l111111_opy_
	l1ll1lll_opy_ = ord (l1l11l_opy_ [-1])
	l1l1l1ll_opy_ = l1l11l_opy_ [:-1]
	l11l11l_opy_ = l1ll1lll_opy_ % len (l1l1l1ll_opy_)
	l11ll1_opy_ = l1l1l1ll_opy_ [:l11l11l_opy_] + l1l1l1ll_opy_ [l11l11l_opy_:]
	if l1l11ll1_opy_:
		l1llll_opy_ = unicode () .join ([unichr (ord (char) - l1llll1l_opy_ - (l111l1l_opy_ + l1ll1lll_opy_) % l1l1ll1l_opy_) for l111l1l_opy_, char in enumerate (l11ll1_opy_)])
	else:
		l1llll_opy_ = str () .join ([chr (ord (char) - l1llll1l_opy_ - (l111l1l_opy_ + l1ll1lll_opy_) % l1l1ll1l_opy_) for l111l1l_opy_, char in enumerate (l11ll1_opy_)])
	return eval (l1llll_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
import mapping
ADDON    = dixie.ADDON
l1l1ll11_opy_ = dixie.PROFILE
l1ll1llll_opy_  = os.path.join(l1l1ll11_opy_, l11ll_opy_ (u"ࠪ࡭ࡳ࡯ࠧঀ"))
l111l11l_opy_    = os.path.join(l1ll1llll_opy_, l11ll_opy_ (u"ࠫࡲࡧࡰࡱ࡫ࡱ࡫ࡸ࠴ࡪࡴࡱࡱࠫঁ"))
l11l11ll_opy_   = os.path.join(l1ll1llll_opy_, l11ll_opy_ (u"ࠬࡳࡡࡱࡵ࠱࡮ࡸࡵ࡮ࠨং"))
LABELFILE  = os.path.join(l1ll1llll_opy_, l11ll_opy_ (u"࠭࡬ࡢࡤࡨࡰࡸ࠴ࡪࡴࡱࡱࠫঃ"))
l1ll1l11l_opy_ = os.path.join(l1ll1llll_opy_, l11ll_opy_ (u"ࠧࡱࡴࡨࡪ࡮ࡾࡥࡴ࠰࡭ࡷࡴࡴࠧ঄"))
l111l1l1_opy_  = json.load(open(l111l11l_opy_))
l11111ll_opy_      = json.load(open(l11l11ll_opy_))
labelmaps = json.load(open(LABELFILE))
l1ll1_opy_  = json.load(open(l1ll1l11l_opy_))
l1ll11ll1_opy_ = l11ll_opy_ (u"ࠨࠩঅ")
def l1l1lllll_opy_(i, t1, l1ll11l1l_opy_=[]):
 t = l1ll11ll1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1ll11l1l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11l11l1_opy_ = l1l1lllll_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11ll1ll_opy_ = l1l1lllll_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1lll1l_opy_      = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡦࡸࡻ࠭আ")
l1ll11l1_opy_   = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡸࡷ࡫ࡡ࡮ࡵࡸࡴࡷ࡫࡭ࡦ࠴ࠪই")
l11l1l11_opy_    = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡹࡰࡺࡵࡳ࡭ࠪঈ")
l1l111ll_opy_ = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡑ࡯࡭ࡪࡶ࡯ࡩࡸࡹࡉࡑࡖ࡙ࠫউ")
l1lll111l_opy_       = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡬ࡡࡣࡪࡲࡷࡹ࡯࡮ࡨࠩঊ")
l1ll1l111_opy_       = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡤࡧࡷࡺࠬঋ")
l11lll1_opy_   = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡩࡱࡵ࡭ࡿࡵ࡮ࡪࡲࡷࡺࠬঌ")
root      = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡲࡳࡹࡏࡐࡕࡘࠪ঍")
l1ll11lll_opy_      = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡰࡩ࡬ࡧࡩࡱࡶࡹࠫ঎")
l1ll11l11_opy_  = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡪࡷ࡫ࡥࡷ࡫ࡨࡻࠬএ")
l11lll11_opy_  = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡒࡧࡴࡴࡄࡸ࡭ࡱࡪࡳࡊࡒࡗ࡚ࠬঐ")
l11lll1_opy_   = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡮࡯ࡳ࡫ࡽࡳࡳ࡯ࡰࡵࡸࠪ঑")
l111111l_opy_  = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱࡶࡹࡷࡺࡨࡳࠨ঒")
l1llllll1_opy_      = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡫࡫ࡱࡼࡹࡼ࠲ࠨও")
l1ll1ll11_opy_   = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡇࡱࡨࡱ࡫ࡳࡴࠩঔ")
l1l111l_opy_  = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡉࡰࡦࡽ࡬ࡦࡵࡶࡘࡻ࠭ক")
l111l111_opy_   = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡱࡦࡾࡩࡸࡧࡥࡸࡻ࠭খ")
dexter    = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸࠨগ")
l1ll_opy_     = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡜ࡁࡅࡇࡕࠫঘ")
l11111l1_opy_ = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡓࡶࡲࡵࡩࡲࡧࡣࡺࡖ࡙ࠫঙ")
l1ll1l1ll_opy_     = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡮ࡥ࡮ࡸࡻ࠳ࡰ࡭ࡷࡶࠫচ")
l1111ll1_opy_   = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡶࡺ࡭ࡸࡺࡥࡥࠩছ")
l1lll1111_opy_  = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡳࡷࡦࡪࡤࡰࡰࠪজ")
l111lll1_opy_  = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡆࡱࡧࡣ࡬ࡋࡦࡩ࡙࡜ࠧঝ")
l1ll1l11_opy_    = [l1lll1l_opy_, l1ll11l1_opy_, l11l1l11_opy_, l1l111ll_opy_, l1lll111l_opy_,l1ll1l111_opy_, l11lll1_opy_, root, l1ll11lll_opy_, l1ll11l11_opy_, l111111l_opy_, l1llllll1_opy_, l1ll1ll11_opy_, l1l111l_opy_, l111l111_opy_, dexter, l1ll_opy_, l11111l1_opy_, l1ll1l1ll_opy_, l1111ll1_opy_, l1lll1111_opy_, l111lll1_opy_]
def checkAddons():
    for addon in l1ll1l11_opy_:
        if l1ll11111_opy_(addon):
            try: createINI(addon)
            except: continue
def l1ll11111_opy_(addon):
    if xbmc.getCondVisibility(l11ll_opy_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠦࡵࠬࠫঞ") % addon) == 1:
        dixie.log(l11ll_opy_ (u"࠭࠽࠾࠿ࡀࠤࡦࡪࡤࡰࡰࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦ࠽࠾࠿ࡀࠫট"))
        dixie.log(addon)
        return True
    return False
def createINI(addon):
    l1lll1l1l_opy_  = str(addon).split(l11ll_opy_ (u"ࠧ࠯ࠩঠ"))[2] + l11ll_opy_ (u"ࠨ࠰࡬ࡲ࡮࠭ড")
    l1lllll1l_opy_   = os.path.join(l1ll1llll_opy_, l1lll1l1l_opy_)
    response = l11lll1l_opy_(addon)
    l11l111_opy_ = response[l11ll_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩঢ")][l11ll_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩণ")]
    l1lllllll_opy_  = l11ll_opy_ (u"ࠫࡠ࠭ত") + addon + l11ll_opy_ (u"ࠬࡣ࡜࡯ࠩথ")
    l11l1l1l_opy_  =  file(l1lllll1l_opy_, l11ll_opy_ (u"࠭ࡷࠨদ"))
    l11l1l1l_opy_.write(l1lllllll_opy_)
    l1llll11l_opy_ = []
    for channel in l11l111_opy_:
        l111l1ll_opy_ = l1ll111l1_opy_(addon)
        l11ll111_opy_  = channel[l11ll_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ধ")].split(l11ll_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪন"), 1)[0]
        if addon == dexter:
            l11ll111_opy_ = l11ll111_opy_.split(l11ll_opy_ (u"ࠩࠣ࠯ࠥ࠭঩"), 1)[0]
        if (addon == root) or (addon == l1l111ll_opy_):
            l11ll111_opy_ = l11ll111_opy_.split(l11ll_opy_ (u"ࠪࠤ࠲ࠦࠧপ"), 1)[0]
        l1lll11ll_opy_ = l1lll1lll_opy_(addon, l11ll111_opy_)
        l11l1ll1_opy_ = l1ll111ll_opy_(addon, l1ll1_opy_, labelmaps, l111l1l1_opy_, l11111ll_opy_, l11ll111_opy_)
        stream  = l111l1ll_opy_ + l1lll11ll_opy_
        l11l1111_opy_ = l11l1ll1_opy_  + l11ll_opy_ (u"ࠫࡂ࠭ফ") + stream
        if l11l1111_opy_ not in l1llll11l_opy_:
            l1llll11l_opy_.append(l11l1111_opy_)
    l1llll11l_opy_.sort()
    for item in l1llll11l_opy_:
        l11l1l1l_opy_.write(l11ll_opy_ (u"ࠧࠫࡳ࡝ࡰࠥব") % item)
    l11l1l1l_opy_.close()
def l1lll1lll_opy_(addon, l11ll111_opy_):
    if (addon == root) or (addon == l1l111ll_opy_):
        l1l1111_opy_ = mapping.cleanLabel(l11ll111_opy_)
        l1lll11ll_opy_ = mapping.editPrefix(l1ll1_opy_, l1l1111_opy_)
        return l1lll11ll_opy_
    l1l1111_opy_ = mapping.cleanLabel(l11ll111_opy_)
    l1lll11ll_opy_ = mapping.cleanStreamLabel(l1l1111_opy_)
    return l1lll11ll_opy_
def l1ll111ll_opy_(addon, l1ll1_opy_, labelmaps, l111l1l1_opy_, l11111ll_opy_, l11ll111_opy_):
    if (addon == root) or (addon == l1l111ll_opy_):
        return l1ll1111l_opy_(l1ll1_opy_, l11111ll_opy_, l11ll111_opy_)
    l1lllll_opy_    = mapping.cleanLabel(l11ll111_opy_)
    l1l1111_opy_ = mapping.mapLabel(labelmaps, l1lllll_opy_)
    l11l1ll1_opy_ = mapping.cleanPrefix(l1l1111_opy_)
    return mapping.mapChannelName(l111l1l1_opy_, l11l1ll1_opy_)
def l1ll1111l_opy_(l1ll1_opy_, l11111ll_opy_, l11ll111_opy_):
    l111ll1l_opy_ = mapping.cleanLabel(l11ll111_opy_)
    l1l1111_opy_   = mapping.editPrefix(l1ll1_opy_, l111ll1l_opy_)
    l1llll1l1_opy_   = mapping.mapEPGLabel(l1ll1_opy_, l11111ll_opy_, l1l1111_opy_)
    return l1llll1l1_opy_
def l11l111l_opy_(addon, file):
    l1lllll_opy_ = file[l11ll_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬভ")].split(l11ll_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩম"), 1)[0]
    l1lllll_opy_ = l1lllll_opy_.split(l11ll_opy_ (u"ࠨ࠭ࠪয"), 1)[0]
    l1lllll_opy_ = mapping.cleanLabel(l1lllll_opy_)
    return l1lllll_opy_
def l1ll111l1_opy_(addon):
    if addon == l1lll1l_opy_:
        return l11ll_opy_ (u"ࠩࡖࡇ࡙࡜࠺ࠨর")
    if addon == l1ll11l1_opy_:
        return l11ll_opy_ (u"ࠪࡗ࡚ࡖ࠺ࠨ঱")
    if addon == l11l1l11_opy_:
        return l11ll_opy_ (u"࡚ࠫࡑࡔ࠻ࠩল")
    if addon == l1l111ll_opy_:
        return l11ll_opy_ (u"ࠬࡒࡉࡎࡋࡗ࠾ࠬ঳")
    if addon == l1lll111l_opy_:
        return l11ll_opy_ (u"࠭ࡆࡂࡄ࠽ࠫ঴")
    if addon == l1ll1l111_opy_:
        return l11ll_opy_ (u"ࠧࡂࡅࡈ࠾ࠬ঵")
    if addon == l11lll1_opy_:
        return l11ll_opy_ (u"ࠨࡊࡒࡖࡎࡠ࠺ࠨশ")
    if addon == root:
        return l11ll_opy_ (u"ࠩࡕࡓࡔ࡚࠲࠻ࠩষ")
    if addon == l1ll11lll_opy_:
        return l11ll_opy_ (u"ࠪࡑࡊࡍࡁ࠻ࠩস")
    if addon == l1ll11l11_opy_:
        return l11ll_opy_ (u"ࠫࡋࡘࡅࡆ࠼ࠪহ")
    if addon == l11lll11_opy_:
        return l11ll_opy_ (u"ࠬࡓࡁࡕࡕ࠽ࠫ঺")
    if addon == l111111l_opy_:
        return l11ll_opy_ (u"࠭ࡉࡑࡖࡖ࠾ࠬ঻")
    if addon == l1llllll1_opy_:
        return l11ll_opy_ (u"ࠧࡋࡋࡑ࡜࠷ࡀ়ࠧ")
    if addon == l1ll1ll11_opy_:
        return l11ll_opy_ (u"ࠨࡇࡑࡈ࠿࠭ঽ")
    if addon == l1l111l_opy_:
        return l11ll_opy_ (u"ࠩࡉࡐࡆࡀࠧা")
    if addon == l111l111_opy_:
        return l11ll_opy_ (u"ࠪࡑࡆ࡞ࡉ࠻ࠩি")
    if addon == dexter:
        return l11ll_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡇ࠾ࠬী")
    if addon == l1ll_opy_:
        return l11ll_opy_ (u"ࠬ࡜ࡄࡓࡖ࡙࠾ࠬু")
    if addon == l11111l1_opy_:
        return l11ll_opy_ (u"࠭ࡓࡑࡔࡐ࠾ࠬূ")
    if addon == l1ll1l1ll_opy_:
        return l11ll_opy_ (u"ࠧࡎࡅࡎࡘ࡛ࡀࠧৃ")
    if addon == l1111ll1_opy_:
        return l11ll_opy_ (u"ࠨࡖ࡚ࡍࡘ࡚࠺ࠨৄ")
    if addon == l1lll1111_opy_:
        return l11ll_opy_ (u"ࠩࡓࡖࡊ࡙ࡔ࠻ࠩ৅")
    if addon == l111lll1_opy_:
        return l11ll_opy_ (u"ࠪࡆࡑࡑࡉ࠻ࠩ৆")
def getURL(url):
    if url.startswith(l11ll_opy_ (u"ࠫࡘࡉࡔࡗࠩে")):
        return l11ll1l1_opy_(url, l1lll1l_opy_)
    if url.startswith(l11ll_opy_ (u"࡙ࠬࡕࡑࠩৈ")):
        return l11ll1l1_opy_(url, l1ll11l1_opy_)
    if url.startswith(l11ll_opy_ (u"࠭ࡕࡌࡖࠪ৉")):
        return l11ll1l1_opy_(url, l11l1l11_opy_)
    if url.startswith(l11ll_opy_ (u"ࠧࡍࡋࡐࡍ࡙࠭৊")):
        return l11ll1l1_opy_(url, l1l111ll_opy_)
    if url.startswith(l11ll_opy_ (u"ࠨࡈࡄࡆࠬো")):
        return l11ll1l1_opy_(url, l1lll111l_opy_)
    if url.startswith(l11ll_opy_ (u"ࠩࡄࡇࡊ࠭ৌ")):
        return l11ll1l1_opy_(url, l1ll1l111_opy_)
    if url.startswith(l11ll_opy_ (u"ࠪࡌࡔࡘࡉ্࡛ࠩ")):
        return l11ll1l1_opy_(url, l11lll1_opy_)
    if url.startswith(l11ll_opy_ (u"ࠫࡗࡕࡏࡕ࠴ࠪৎ")):
        return l11ll1l1_opy_(url, root)
    if url.startswith(l11ll_opy_ (u"ࠬࡓࡅࡈࡃࠪ৏")):
        return l11ll1l1_opy_(url, l1ll11lll_opy_)
    if url.startswith(l11ll_opy_ (u"࠭ࡆࡓࡇࡈࠫ৐")):
        return l11ll1l1_opy_(url, l1ll11l11_opy_)
    if url.startswith(l11ll_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡉࡌࡖ࠼ࠪ৑")):
        url = url.replace(l11ll_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡃࡍࡗ࠽ࠫ৒"), l11ll_opy_ (u"ࠩࠪ৓")).replace(l11ll_opy_ (u"ࠪ࠱࠲ࡻࡳࡦࡴ࠰ࡥ࡬࡫࡮ࡵࠩ৔"), l11ll_opy_ (u"ࠫࢁࡻࡳࡦࡴ࠰ࡥ࡬࡫࡮ࡵࠩ৕"))
        return url
    if url.startswith(l11ll_opy_ (u"ࠬࡓࡁࡕࡕࠪ৖")):
        return l11ll1l1_opy_(url, l11lll11_opy_)
    if url.startswith(l11ll_opy_ (u"࠭ࡉࡑࡖࡖࠫৗ")):
        return l11ll1l1_opy_(url, l111111l_opy_)
    if url.startswith(l11ll_opy_ (u"ࠧࡋࡋࡑ࡜࠷࠭৘")):
        return l11ll1l1_opy_(url, l1llllll1_opy_)
    if url.startswith(l11ll_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡄࠨ৙")):
        return l11ll1l1_opy_(url, dexter)
    if url.startswith(l11ll_opy_ (u"ࠩࡉࡐࡆ࠭৚")):
        return l11ll1l1_opy_(url, l1l111l_opy_)
    if url.startswith(l11ll_opy_ (u"ࠪࡑࡆ࡞ࡉࠨ৛")):
        return l11ll1l1_opy_(url, l111l111_opy_)
    if url.startswith(l11ll_opy_ (u"ࠫࡊࡔࡄࠨড়")):
        return l11ll1l1_opy_(url, l1ll1ll11_opy_)
    if url.startswith(l11ll_opy_ (u"ࠬ࡜ࡄࡓࡖ࡙ࠫঢ়")):
        return l11ll1l1_opy_(url, l1ll_opy_)
    if url.startswith(l11ll_opy_ (u"࠭ࡓࡑࡔࡐࠫ৞")):
        return l11ll1l1_opy_(url, l11111l1_opy_)
    if url.startswith(l11ll_opy_ (u"ࠧࡎࡅࡎࡘ࡛࠭য়")):
        return l11ll1l1_opy_(url, l1ll1l1ll_opy_)
    if url.startswith(l11ll_opy_ (u"ࠨࡖ࡚ࡍࡘ࡚ࠧৠ")):
        return l11ll1l1_opy_(url, l1111ll1_opy_)
    if url.startswith(l11ll_opy_ (u"ࠩࡓࡖࡊ࡙ࡔࠨৡ")):
        return l11ll1l1_opy_(url, l1lll1111_opy_)
    if url.startswith(l11ll_opy_ (u"ࠪࡆࡑࡑࡉࠨৢ")):
        return l11ll1l1_opy_(url, l111lll1_opy_)
    response  = l11ll11l_opy_(url)
    l1llll1ll_opy_ = url.split(l11ll_opy_ (u"ࠫ࠿࠭ৣ"), 1)[-1]
    try:
        result = response[l11ll_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬ৤")]
        l11111l_opy_  = result[l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬ৥")]
    except Exception as e:
        l1ll1ll1l_opy_(e)
        return None
    for file in l11111l_opy_:
        l11ll111_opy_  = file[l11ll_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭০")].split(l11ll_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ১"), 1)[0]
        l1l1lll_opy_  = l11ll111_opy_.split(l11ll_opy_ (u"ࠩ࠮ࠫ২"), 1)[0]
        l1ll1lll1_opy_ = mapping.cleanLabel(l1l1lll_opy_)
        try:
            if l1llll1ll_opy_ == l1ll1lll1_opy_:
                return file[l11ll_opy_ (u"ࠪࡪ࡮ࡲࡥࠨ৩")]
        except:
            if (l1llll1ll_opy_ in l1ll1lll1_opy_) or (l1ll1lll1_opy_ in l1llll1ll_opy_):
                return file[l11ll_opy_ (u"ࠫ࡫࡯࡬ࡦࠩ৪")]
    return None
def l11ll1l1_opy_(url, addon):
    PATH = l11l1lll_opy_(addon)
    try:
        response = json.load(open(PATH))
    except:
        response = l11lll1l_opy_(addon)
    l1l11l11_opy_      = url.split(l11ll_opy_ (u"ࠬࡀࠧ৫"), 1)[-1]
    stream    = l1l11l11_opy_.split(l11ll_opy_ (u"࠭ࠠ࡜ࠩ৬"), 1)[0]
    l1llll1ll_opy_ = mapping.cleanLabel(stream)
    l11111l_opy_  = response[l11ll_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧ৭")][l11ll_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧ৮")]
    for file in l11111l_opy_:
        l11ll111_opy_  = file[l11ll_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨ৯")].split(l11ll_opy_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬৰ"), 1)[0]
        if addon == dexter:
            l11ll111_opy_ = l11ll111_opy_.split(l11ll_opy_ (u"ࠫࠥ࠱ࠠࠨৱ"), 1)[0]
        if (addon == root) or (addon == l1l111ll_opy_):
            l11ll111_opy_ = l11ll111_opy_.split(l11ll_opy_ (u"ࠬࠦ࠭ࠡࠩ৲"), 1)[0]
        l1ll1lll1_opy_ = l1lll1lll_opy_(addon, l11ll111_opy_)
        try:
            if l1llll1ll_opy_ == l1ll1lll1_opy_:
                return file[l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࠫ৳")]
        except:
            if (l1llll1ll_opy_ in l1ll1lll1_opy_) or (l1ll1lll1_opy_ in l1llll1ll_opy_):
                return file[l11ll_opy_ (u"ࠧࡧ࡫࡯ࡩࠬ৴")]
    return None
def l11lll1l_opy_(addon):
    PATH  = l11l1lll_opy_(addon)
    if addon == l1ll_opy_:
        query = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡙ࡅࡉࡋࡒ࠰࡮࡬ࡺࡪࡺࡶ࠰ࡣ࡯ࡰ࠴࠭৵")
    elif addon == l1ll11l1_opy_:
        query = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡹࡸࡥࡢ࡯ࡶࡹࡵࡸࡥ࡮ࡧ࠵࠳ࡱ࡯ࡶࡦࡶࡹ࠳ࡦࡲ࡬࠰ࠩ৶")
    elif addon == l1lll1l_opy_:
        query = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡩࡴࡷ࠱࡯࡭ࡻ࡫ࡴࡷ࠱ࡤࡰࡱ࠵ࠧ৷")
    elif addon == l1ll11l1_opy_:
        query = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹࡴࡳࡧࡤࡱࡸࡻࡰࡳࡧࡰࡩ࠷࠵࡬ࡪࡸࡨࡸࡻ࠵ࡡ࡭࡮࠲ࠫ৸")
    elif addon == l1ll11l11_opy_:
        query = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡦࡳࡧࡨࡺ࡮࡫ࡷ࠰ࡁࡸࡶࡱࡃࡵࡳ࡮ࠩࡱࡴࡪࡥ࠾࠷ࠩࡲࡦࡳࡥ࠾ࡎ࡬ࡺࡪ࠱ࡔࡗࠩ৹")
    elif addon == l11l1l11_opy_:
        query = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡶ࡭ࡷࡹࡷࡱ࠯ࡀࡷࡵࡰࡂ࡮ࡴࡵࡲࠨ࠷ࡆࠫ࠲ࡇࠧ࠵ࡊࡦࡪࡤࡰࡰࡦࡰࡴࡻࡤ࠯ࡱࡵ࡫ࠪ࠸ࡆࡶ࡭ࡷࡹࡷࡱࠥ࠳ࡈࡘࡏ࡙ࡻࡲ࡬ࠧ࠵ࡊࡑ࡯ࡶࡦࠧ࠵࠹࠷࠶ࡔࡗ࠰ࡷࡼࡹࠬ࡭ࡰࡦࡨࡁ࠶ࠬ࡮ࡢ࡯ࡨࡁࡑ࡯ࡶࡦ࠭ࡗ࡚ࠫࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࡀࠪ࡫ࡧ࡮ࡢࡴࡷࡁࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠩ৺")
    else:
        query = l1lll1l11_opy_(addon)
    try:
        return json.load(open(PATH))
    except:
        content = doJSON(query)
        return l1111111_opy_(PATH, addon, content)
def l1111111_opy_(PATH, addon, content):
    json.dump(content, open(PATH,l11ll_opy_ (u"ࠧࡸࠩ৻")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    l1l1l11_opy_  = (l11ll_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫৼ") % query)
    response = xbmc.executeJSONRPC(l1l1l11_opy_)
    content  = json.loads(response)
    return content
def l11l1lll_opy_(addon):
    if addon == l1lll1l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠩࡶࡧࡹ࡫࡭ࡱࠩ৽"))
    if addon == l1ll11l1_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠪࡷࡺࡶࡴࡦ࡯ࡳࠫ৾"))
    if addon == l11l1l11_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠫࡺࡱࡴࡵࡧࡰࡴࠬ৿"))
    if addon == l1l111ll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠬࡲࡩ࡮࡫ࡷࡩࡲࡶࠧ਀"))
    if addon == l1lll111l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"࠭ࡦࡢࡤࡷࡩࡲࡶࠧਁ"))
    if addon == l1ll1l111_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠧࡢࡥࡨࡸࡪࡳࡰࠨਂ"))
    if addon == l11lll1_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠨࡪࡲࡶࡹ࡫࡭ࡱࠩਃ"))
    if addon == root:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠩࡵࡳ࠷ࡺࡥ࡮ࡲࠪ਄"))
    if addon == l1ll11lll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠪࡱࡪ࡭ࡡࡵ࡯ࡳࠫਅ"))
    if addon == l11lll11_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠫࡲࡧࡴࡴࡶࡰࡴࠬਆ"))
    if addon == l1ll11l11_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠬ࡬ࡲࡦࡧࡷࡱࡵ࠭ਇ"))
    if addon == l111111l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"࠭ࡩࡱࡶࡶࡸࡲࡶࠧਈ"))
    if addon == l1llllll1_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠧ࡫࠴ࡷࡩࡲࡶࠧਉ"))
    if addon == l1ll1ll11_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠨࡧࡷࡩࡲࡶࠧਊ"))
    if addon == l1l111l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠩࡩࡸࡪࡳࡰࠨ਋"))
    if addon == l111l111_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠪࡱࡦࡾࡴࡦ࡯ࡳࠫ਌"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠫࡩࡺࡥ࡮ࡲࠪ਍"))
    if addon == l1ll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠬࡼࡤࡵࡧࡰࡴࠬ਎"))
    if addon == l11111l1_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"࠭ࡳࡱࡴࡷࡩࡲࡶࠧਏ"))
    if addon == l1ll1l1ll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠧ࡮ࡥ࡮ࡸࡪࡳࡰࠨਐ"))
    if addon == l1111ll1_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠨࡶࡺ࡭ࡹ࡫࡭ࡱࠩ਑"))
    if addon == l1lll1111_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠩࡳࡶࡪࡹࡴࡦ࡯ࡳࠫ਒"))
    if addon == l111lll1_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠪࡦࡱࡱࡩࡵࡧࡰࡴࠬਓ"))
def l1lll1l11_opy_(addon):
    query = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧਔ") + addon
    response = doJSON(query)
    l11111l_opy_    = response[l11ll_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬਕ")][l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬਖ")]
    for file in l11111l_opy_:
        l1lll1ll1_opy_ = file[l11ll_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ਗ")]
        l1lllll_opy_ = mapping.cleanLabel(l1lll1ll1_opy_)
        l1lllll_opy_ = l1lllll_opy_.upper()
        if (l1lllll_opy_ == l11ll_opy_ (u"ࠨࡎࡌ࡚ࡊࠦࡉࡑࡖ࡙ࠫਘ")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠩࡏࡍ࡛ࡋࠠࡕࡘࠪਙ")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠪࡐࡎ࡜ࡅࠡࡅࡋࡅࡓࡔࡅࡍࡕࠪਚ")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠫࡑࡏࡖࡆࠩਛ")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠬࡋࡎࡅࡎࡈࡗࡘࠦࡍࡆࡆࡌࡅࠬਜ")) or (l1lllll_opy_ == l11ll_opy_ (u"࠭ࡆࡍࡃ࡚ࡐࡊ࡙ࡓࡕࡘࠪਝ")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠧࡎࡃ࡛ࡍ࡜ࡋࡂࠡࡖ࡙ࠫਞ")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠨࡄࡏࡅࡈࡑࡉࡄࡇࠣࡘ࡛࠭ਟ")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠩࡋࡓࡗࡏ࡚ࡐࡐࠣࡍࡕ࡚ࡖࠨਠ")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠪࡊࡆࡈࠠࡊࡒࡗ࡚ࠬਡ")):
            livetv = file[l11ll_opy_ (u"ࠫ࡫࡯࡬ࡦࠩਢ")]
            return l111ll11_opy_(livetv)
def l111ll11_opy_(livetv):
    response = doJSON(livetv)
    l11111l_opy_    = response[l11ll_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬਣ")][l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬਤ")]
    for file in l11111l_opy_:
        l1lll1ll1_opy_ = file[l11ll_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ਥ")]
        l1lllll_opy_ = mapping.cleanLabel(l1lll1ll1_opy_)
        l1lllll_opy_ = l1lllll_opy_.upper()
        if l1lllll_opy_ == l11ll_opy_ (u"ࠨࡃࡏࡐࠬਦ"):
            return file[l11ll_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧਧ")]
def l1lllll11_opy_(l1llll111_opy_):
    items = []
    _1lll11l1_opy_(l1llll111_opy_, items)
    return items
def _1lll11l1_opy_(l1llll111_opy_, items):
    response = doJSON(l1llll111_opy_)
    if response[l11ll_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪਨ")].has_key(l11ll_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪ਩")):
        result = response[l11ll_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬਪ")][l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬਫ")]
        for item in result:
            if item[l11ll_opy_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩਬ")] == l11ll_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ਭ"):
                l1lllll_opy_ = mapping.cleanLabel(item[l11ll_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨਮ")])
                items.append(item)
            elif item[l11ll_opy_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬਯ")] == l11ll_opy_ (u"ࠫࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠧਰ"):
                l1lllll_opy_ = mapping.cleanLabel(item[l11ll_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫ਱")])
                l1ll1l1l1_opy_  = item[l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࠫਲ")]
                dixie.log(item)
                dixie.log(l1ll1l1l1_opy_)
                _1lll11l1_opy_(l1ll1l1l1_opy_, items)
def l11ll11l_opy_(url):
    if url.startswith(l11ll_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡀࠧਲ਼")):
        l1l1l11_opy_ = (l11ll_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡧࡨࡣࡪࡲ࡯ࡥࡾ࡫ࡲ࠰ࡁࡸࡶࡱࡃࡵࡳ࡮ࠩࡱࡴࡪࡥ࠾࠴ࠩࡲࡦࡳࡥ࠾ࡎ࡬ࡺࡪࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࠩࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮࠾ࠨࡌࡔࡎࡊ࠽ࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭਴"))
    if url.startswith(l11ll_opy_ (u"ࠩࡌࡔࡑࡇ࡙࠳࠼ࠪਵ")):
        l1l1l11_opy_ = (l11ll_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱ࡮ࡤࡽࡪࡸࡷࡸࡹ࠲ࡃࡺࡸ࡬࠾ࡷࡵࡰࠫࡳ࡯ࡥࡧࡀ࠵࠵࠷ࠦ࡯ࡣࡰࡩࡂ࡝ࡡࡵࡥ࡫࠯ࡑ࡯ࡶࡦࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࡁࠫࡹࡵࡣࡶ࡬ࡸࡱ࡫ࡳࡠࡷࡵࡰࡂࠬ࡬ࡰࡩࡪࡩࡩࡥࡩ࡯࠿ࡉࡥࡱࡹࡥࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ਸ਼"))
    if url.startswith(l11ll_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡕ࠾ࠬ਷")):
        l1l1l11_opy_ = (l11ll_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡰࡦࡿࡥࡳࡹࡺࡻ࠴ࡅࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠪࡱࡵࡧࡨࡧࡧࡣ࡮ࡴ࠽ࡇࡣ࡯ࡷࡪࠬ࡭ࡰࡦࡨࡁ࠶࠷࠳ࠧࡰࡤࡱࡪࡃࡌࡪࡵࡷࡩࡳࠫ࠲࠱ࡎ࡬ࡺࡪࠬࡳࡶࡤࡷ࡭ࡹࡲࡥࡴࡡࡸࡶࡱࠬࡵࡳ࡮ࡀࡹࡷࡲࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬਸ"))
    if url.startswith(l11ll_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡎ࡚ࡖ࠻ࠩਹ")):
        l1l1l11_opy_ = (l11ll_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡹࡼࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬ਺"))
    if url.startswith(l11ll_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡄ࠻ࠩ਻")):
        l1l1l11_opy_ = (l11ll_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡪࡥࡹ࠱ࡂࡥࡨࡺࡩࡰࡰࡀࡥࡱࡲࠦࡦࡺࡷࡶࡦࠬࡰࡢࡩࡨࠪࡵࡲ࡯ࡵࠨࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡂࠬࡴࡪࡶ࡯ࡩࡂࠫ࠵ࡣࡅࡒࡐࡔࡘࠥ࠳࠲ࡺ࡬࡮ࡺࡥࠦ࠷ࡧࡅࡱࡲࠥ࠳࠲ࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠩ࠺ࡨࠥ࠳ࡨࡆࡓࡑࡕࡒࠦ࠷ࡧࠪࡺࡸ࡬ࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ਼࠭"))
    if url.startswith(l11ll_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡔࡅ࠾ࠬ਽")):
        l1l1l11_opy_ = (l11ll_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡧࡥࡳࡴࡺ࠯ࡀࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠬࡦࡢࡰࡤࡶࡹࡃࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡲࡵࡤࡦ࠿࠺ࠪࡵ࡯࡬࡭ࡱࡺࡁࡑ࡯ࡶࡦࠧ࠵࠴ࡘࡺࡲࡦࡣࡰࡷࠫࡻࡲ࡭࠿ࡵࡥࡳࡪ࡯࡮ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧਾ"))
    try:
        dixie.ShowBusy()
        addon =  l1l1l11_opy_.split(l11ll_opy_ (u"ࠬ࠵࠯ࠨਿ"), 1)[-1].split(l11ll_opy_ (u"࠭࠯ࠨੀ"), 1)[0]
        login = l11ll_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬੁ") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1l1l11_opy_)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1ll1ll1l_opy_(e)
        return {l11ll_opy_ (u"ࠨࡇࡵࡶࡴࡸࠧੂ") : l11ll_opy_ (u"ࠩࡓࡰࡺ࡭ࡩ࡯ࠢࡈࡶࡷࡵࡲࠨ੃")}
def l1111l11_opy_():
    modules = map(__import__, [l1l1lllll_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11l11l1_opy_)):
        return l11ll_opy_ (u"ࠪࡘࡷࡻࡥࠨ੄")
    if len(modules[-1].Window(10**4).getProperty(l11ll1ll_opy_)):
        return l11ll_opy_ (u"࡙ࠫࡸࡵࡦࠩ੅")
    return l11ll_opy_ (u"ࠬࡌࡡ࡭ࡵࡨࠫ੆")
def l1ll1ll1l_opy_(e):
    l1111l1l_opy_ = l11ll_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠱ࠦࡡ࡯ࠢࡨࡶࡷࡵࡲࠡࡱࡦࡧࡺࡸࡥࡥ࠼ࠣࡎࡘࡕࡎࠡࡇࡵࡶࡴࡸ࠺ࠡࠧࡶࠫੇ")  %e
    l111llll_opy_ = l11ll_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡳࡧ࠰ࡰ࡮ࡴ࡫ࠡࡶ࡫࡭ࡸࠦࡣࡩࡣࡱࡲࡪࡲࠠࡢࡰࡧࠤࡹࡸࡹࠡࡣࡪࡥ࡮ࡴ࠮ࠨੈ")
    l1111lll_opy_ = l11ll_opy_ (u"ࠨࡗࡶࡩ࠿ࠦࡃࡰࡰࡷࡩࡽࡺࠠࡎࡧࡱࡹࠥࡃ࠾ࠡࡔࡨࡱࡴࡼࡥࠡࡕࡷࡶࡪࡧ࡭ࠨ੉")
    dixie.log(e)
    dixie.DialogOK(l1111l1l_opy_, l111llll_opy_, l1111lll_opy_)
if __name__ == l11ll_opy_ (u"ࠩࡢࡣࡲࡧࡩ࡯ࡡࡢࠫ੊"):
    checkAddons()