# -*- coding: utf-8 -*-
import sys
l11ll111_opy_ = sys.version_info [0] == 2
l1lll1l1_opy_ = 2048
l11lllll_opy_ = 7
def l1l11_opy_ (l11ll1_opy_):
	global l1llll11_opy_
	l1ll1111_opy_ = ord (l11ll1_opy_ [-1])
	l11ll11l_opy_ = l11ll1_opy_ [:-1]
	l11l11l_opy_ = l1ll1111_opy_ % len (l11ll11l_opy_)
	l111l1_opy_ = l11ll11l_opy_ [:l11l11l_opy_] + l11ll11l_opy_ [l11l11l_opy_:]
	if l11ll111_opy_:
		l1lll1_opy_ = unicode () .join ([unichr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	else:
		l1lll1_opy_ = str () .join ([chr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	return eval (l1lll1_opy_)
import platform
try:    l1ll1l11l_opy_ = platform.system
except: l1ll1l11l_opy_ = None
def l1lll11ll_opy_():
    if l1ll1l11l_opy_:
        return l1ll1l11l_opy_()
    import sys
    if sys.platform.lower().startswith(l1l11_opy_ (u"ࠨࡹ࡬ࡲࠬ࡟")):
        return l1l11_opy_ (u"࡚ࠩ࡭ࡳࡪ࡯ࡸࡵࠪࡠ")
    return l1l11_opy_ (u"ࠪࡓࡹ࡮ࡥࡳࠢࡒࡗࡪࡹࠠࡵࡱࠣࡦࡪࠦࡤࡦࡶࡨࡶࡲ࡯࡮ࡦࡦࠪࡡ")
platform.system = l1lll11ll_opy_
import requests
platform.system = l1ll1l11l_opy_
import os
import json
import dixie
l1lll1l1l_opy_ = dixie.PROFILE
PATH = os.path.join(l1lll1l1l_opy_, l1l11_opy_ (u"ࠫࡵࡲࡩࡴࡶࡶࠫࡢ"))
def loadPlaylists():
    if os.path.exists(PATH):
        return json.load(open(PATH))
    try:
        l1lll111l_opy_()
        return json.load(open(PATH))
    except:
        dixie.log(l1l11_opy_ (u"ࠬࡃ࠽࠾࠿ࠣࡔࡱࡧࡹ࡭࡫ࡶࡸࠥࡲ࡯ࡢࡦࠣࡩࡷࡸ࡯ࡳࠢࡀࡁࡂࡃࠧࡣ"))
        return []
def l1lll111l_opy_():
    source = dixie.GetSetting(l1l11_opy_ (u"࠭ࡩࡱࡶࡹ࠲ࡸࡵࡵࡳࡥࡨࠫࡤ"))
    if not source == l1l11_opy_ (u"ࠧ࠲ࠩࡥ"):
        return l1llll11l_opy_()
    return l1ll11111_opy_()
def l1llll11l_opy_():
    l111l111_opy_ = []
    if dixie.GetSetting(l1l11_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠰ࠨࡦ")) == l1l11_opy_ (u"ࠩࡷࡶࡺ࡫ࠧࡧ"):
        l1lllllll_opy_  = dixie.GetSetting(l1l11_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠲ࡢ࡙ࡗࡒࠧࡨ"))
        l1llllll1_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠳ࡣࡕࡕࡒࡕࠩࡩ"))
        l1lll1lll_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠴ࡤ࡚࡙ࡑࡇࠪࡪ"))
        l1111111_opy_ = dixie.GetSetting(l1l11_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠵ࡥࡕࡔࡇࡕࠫ࡫"))
        l11111l1_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠶࡟ࡑࡃࡖࡗࠬ࡬"))
        if len(l1lllllll_opy_) > 0:
            l1ll1111l_opy_ = l1ll11l1l_opy_(l1lllllll_opy_, l1llllll1_opy_, l1lll1lll_opy_, l1111111_opy_, l11111l1_opy_)
            l111l111_opy_.append((l1ll1111l_opy_, l1l11_opy_ (u"ࠨࡋࡓࡘ࡛࠷࠺ࠡࠩ࡭")))
    if dixie.GetSetting(l1l11_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠲ࠩ࡮")) == l1l11_opy_ (u"ࠪࡸࡷࡻࡥࠨ࡯"):
        l1lllllll_opy_  = dixie.GetSetting(l1l11_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠴ࡣ࡚ࡘࡌࠨࡰ"))
        l1llllll1_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠵ࡤࡖࡏࡓࡖࠪࡱ"))
        l1lll1lll_opy_ = dixie.GetSetting(l1l11_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠶ࡥࡔ࡚ࡒࡈࠫࡲ"))
        l1111111_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠷࡟ࡖࡕࡈࡖࠬࡳ"))
        l11111l1_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠱ࡠࡒࡄࡗࡘ࠭ࡴ"))
        if len(l1lllllll_opy_) > 0:
            l1lllll1l_opy_ = l1ll11l1l_opy_(l1lllllll_opy_, l1llllll1_opy_, l1lll1lll_opy_, l1111111_opy_, l11111l1_opy_)
            l111l111_opy_.append((l1lllll1l_opy_, l1l11_opy_ (u"ࠩࡌࡔ࡙࡜࠲࠻ࠢࠪࡵ")))
    if dixie.GetSetting(l1l11_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠴ࠪࡶ")) == l1l11_opy_ (u"ࠫࡹࡸࡵࡦࠩࡷ"):
        l1lllllll_opy_  = dixie.GetSetting(l1l11_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠶ࡤ࡛ࡒࡍࠩࡸ"))
        l1llllll1_opy_ = dixie.GetSetting(l1l11_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠷ࡥࡐࡐࡔࡗࠫࡹ"))
        l1lll1lll_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠸࡟ࡕ࡛ࡓࡉࠬࡺ"))
        l1111111_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠲ࡠࡗࡖࡉࡗ࠭ࡻ"))
        l11111l1_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠳ࡡࡓࡅࡘ࡙ࠧࡼ"))
        if len(l1lllllll_opy_) > 0:
            l1lllll11_opy_ = l1ll11l1l_opy_(l1lllllll_opy_, l1llllll1_opy_, l1lll1lll_opy_, l1111111_opy_, l11111l1_opy_)
            l111l111_opy_.append((l1lllll11_opy_, l1l11_opy_ (u"ࠪࡍࡕ࡚ࡖ࠴࠼ࠣࠫࡽ")))
    return l1ll1l111_opy_(l1l11_opy_ (u"࡚ࠫࡘࡌࡔࠩࡾ"),  l111l111_opy_)
def l1ll11111_opy_():
    l111l111_opy_ = []
    if dixie.GetSetting(l1l11_opy_ (u"ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡵࡻࡳࡩࠬࡿ")) == l1l11_opy_ (u"࠭࠰ࠨࢀ"):
        if dixie.GetSetting(l1l11_opy_ (u"ࠧࡖࡔࡏࡣࡔ࠭ࢁ")) == l1l11_opy_ (u"ࠨࡶࡵࡹࡪ࠭ࢂ"):
            l1l1lllll_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡺࡸ࡬ࠨࢃ"))
            if len(l1l1lllll_opy_) > 0:
                l111l111_opy_.append((l1l1lllll_opy_, l1l11_opy_ (u"࡙ࠪࡗࡒ࠱࠻ࠢࠪࢄ")))
        if dixie.GetSetting(l1l11_opy_ (u"࡚ࠫࡘࡌࡠ࠳ࠪࢅ")) == l1l11_opy_ (u"ࠬࡺࡲࡶࡧࠪࢆ"):
            l1ll1l1ll_opy_ = dixie.GetSetting(l1l11_opy_ (u"࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡷࡵࡰ࠶࠭ࢇ"))
            if len(l1ll1l1ll_opy_) > 0:
                l111l111_opy_.append((l1ll1l1ll_opy_, l1l11_opy_ (u"ࠧࡖࡔࡏ࠶࠿ࠦࠧ࢈")))
        if dixie.GetSetting(l1l11_opy_ (u"ࠨࡗࡕࡐࡤ࠸ࠧࢉ")) == l1l11_opy_ (u"ࠩࡷࡶࡺ࡫ࠧࢊ"):
            l1llll1ll_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡻࡲ࡭࠴ࠪࢋ"))
            if len(l1llll1ll_opy_) > 0:
                l111l111_opy_.append((l1llll1ll_opy_, l1l11_opy_ (u"࡚ࠫࡘࡌ࠴࠼ࠣࠫࢌ")))
        dixie.log(l111l111_opy_)
        return l1ll1l111_opy_(l1l11_opy_ (u"࡛ࠬࡒࡍࡕࠪࢍ"),  l111l111_opy_)
    if dixie.GetSetting(l1l11_opy_ (u"࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡶࡼࡴࡪ࠭ࢎ")) == l1l11_opy_ (u"ࠧ࠲ࠩ࢏"):
        if dixie.GetSetting(l1l11_opy_ (u"ࠨࡈࡌࡐࡊࡥ࠰ࠨ࢐")) == l1l11_opy_ (u"ࠩࡷࡶࡺ࡫ࠧ࢑"):
            l1111l1l_opy_ = os.path.join(dixie.GetSetting(l1l11_opy_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳࡬ࡩ࡭ࡧࠪ࢒")))
            if l1111l1l_opy_:
                l111l111_opy_.append((l1111l1l_opy_, l1l11_opy_ (u"ࠫࡋࡏࡌࡆ࠳࠽ࠤࠬ࢓")))
        if dixie.GetSetting(l1l11_opy_ (u"ࠬࡌࡉࡍࡇࡢ࠴ࠬ࢔")) == l1l11_opy_ (u"࠭ࡴࡳࡷࡨࠫ࢕"):
            l1111ll1_opy_ = os.path.join(dixie.GetSetting(l1l11_opy_ (u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡩ࡭ࡱ࡫࠱ࠨ࢖")))
            if l1111ll1_opy_:
                l111l111_opy_.append((l1111ll1_opy_, l1l11_opy_ (u"ࠨࡈࡌࡐࡊ࠸࠺ࠡࠩࢗ")))
        if dixie.GetSetting(l1l11_opy_ (u"ࠩࡉࡍࡑࡋ࡟࠱ࠩ࢘")) == l1l11_opy_ (u"ࠪࡸࡷࡻࡥࠨ࢙"):
            l1111lll_opy_ = os.path.join(dixie.GetSetting(l1l11_opy_ (u"ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡦࡪ࡮ࡨ࠶࢚ࠬ")))
            if l1111lll_opy_:
                l111l111_opy_.append((l1111lll_opy_, l1l11_opy_ (u"ࠬࡌࡉࡍࡇ࠶࠾࢛ࠥ࠭")))
        dixie.log(l111l111_opy_)
        return l1ll1l111_opy_(l1l11_opy_ (u"࠭ࡆࡊࡎࡈࡗࠬ࢜"), l111l111_opy_)
def l1ll111ll_opy_():
    l1ll11l11_opy_ = [l1l11_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡹ࠰ࡦࡳ࠴ࡎࡅ࡛࠷࡝ࡽ࡮ࡐࡥࡘࠩ࢝")]
    for url in l1ll11l11_opy_:
        request = requests.get(url)
        content = request.content
        if l1l11_opy_ (u"ࠨࠥࡈ࡜࡙ࡓ࠳ࡖࠩ࢞") in content:
            return l1ll1l111_opy_(l1l11_opy_ (u"ࠩࡆࡐࡔ࡛ࡄࠨ࢟"), [(url, l1l11_opy_ (u"ࠪࠫࢠ"))])
            break
def l1ll1l111_opy_(l1ll11ll1_opy_, plist):
    dixie.log(l1ll11ll1_opy_)
    dixie.log(plist)
    playlists = []
    for item in plist:
        url = item[0]
        l11111ll_opy_ = item[1]
        l1llll1l1_opy_ = l1111l11_opy_(l1ll11ll1_opy_, url, l11111ll_opy_)
        playlists.extend(l1llll1l1_opy_)
    json.dump(playlists, open(PATH,l1l11_opy_ (u"ࠫࡼ࠭ࢡ")))
def l1111l11_opy_(l1ll11ll1_opy_, url, l11111ll_opy_):
    content  = l1ll111l1_opy_(l1ll11ll1_opy_, url)
    pairs    = []
    for i in range(1,len(content), 2):
        if l1ll11lll_opy_(content[i+1]) == True:
            l1lll1l11_opy_ = content[i]
            l1ll1lll1_opy_   = content[i+1].rstrip()
            pairs.append([l1lll1l11_opy_, l1ll1lll1_opy_])
    l1ll1ll11_opy_ = list()
    l1lll1l11_opy_   = l1l11_opy_ (u"ࠬ࠭ࢢ")
    value   = l1l11_opy_ (u"࠭ࠧࢣ")
    for item in pairs:
        l1lll1ll1_opy_ = item[0]
        l1llll111_opy_ = item[1]
        l1lll1111_opy_   = l1lll1ll1_opy_.split(l1l11_opy_ (u"ࠧ࠭ࠩࢤ"))[-1].strip()
        l1ll1llll_opy_   = dixie.cleanLabel(l1lll1111_opy_)
        l1lll11l1_opy_ = dixie.cleanPrefix(l1ll1llll_opy_)
        l111111l_opy_ = dixie.mapChannelName(l1lll11l1_opy_)
        value = l1llll111_opy_.replace(l1l11_opy_ (u"ࠨࡴࡷࡱࡵࡀ࠯࠰ࠦࡒࡔ࡙ࡀࡲࡵ࡯ࡳ࠱ࡷࡧࡷ࠾ࠩࢥ"), l1l11_opy_ (u"ࠩࠪࢦ")).replace(l1l11_opy_ (u"ࠪࡠࡳ࠭ࢧ"), l1l11_opy_ (u"ࠫࠬࢨ"))
        l1ll1ll11_opy_.append((l11111ll_opy_, l111111l_opy_, value))
    return l1ll1ll11_opy_
def l1ll11lll_opy_(link):
    if link == l1l11_opy_ (u"ࠬࠩࡅ࡙ࡖ࠰࡜࠲ࡋࡎࡅࡎࡌࡗ࡙࠭ࢩ"):
        return False
    if len(link) < 1:
        return False
    return True
def l1ll111l1_opy_(l1ll11ll1_opy_, url):
    import urllib
    if (l1ll11ll1_opy_ == l1l11_opy_ (u"࠭ࡕࡓࡎࡖࠫࢪ")) or (l1ll11ll1_opy_ == l1l11_opy_ (u"ࠧࡄࡎࡒ࡙ࡉ࠭ࢫ")):
        response = urllib.urlopen(url)
        content  = response.readlines()
        return content
    if l1ll11ll1_opy_ == l1l11_opy_ (u"ࠨࡈࡌࡐࡊ࡙ࠧࢬ"):
        with open(url) as content:
            return content.readlines()
def l1ll11l1l_opy_(l1lllllll_opy_, l1llllll1_opy_, l1lll1lll_opy_, l1111111_opy_, l11111l1_opy_):
    if l1lllllll_opy_.startswith(l1l11_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࠪࢭ")):
        url = l1lllllll_opy_
    else:
        url = l1l11_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫࢮ") + l1lllllll_opy_
    url +=  l1ll1l1l1_opy_(l1llllll1_opy_)
    url += l1l11_opy_ (u"ࠫ࠴࡭ࡥࡵ࠰ࡳ࡬ࡵࡅࡵࡴࡧࡵࡲࡦࡳࡥ࠾ࠩࢯ")
    url +=  l1111111_opy_
    url += l1l11_opy_ (u"ࠬࠬࡰࡢࡵࡶࡻࡴࡸࡤ࠾ࠩࢰ")
    url +=  l11111l1_opy_
    url += l1l11_opy_ (u"࠭ࠦࡵࡻࡳࡩࡂࡳ࠳ࡶࡡࡳࡰࡺࡹࠦࡰࡷࡷࡴࡺࡺ࠽ࠨࢱ")
    url +=  l1ll1ll1l_opy_(l1lll1lll_opy_)
    return url
def l1ll1l1l1_opy_(l1llllll1_opy_):
    if not l1llllll1_opy_ == l1l11_opy_ (u"ࠧࠨࢲ"):
        return l1l11_opy_ (u"ࠨ࠼ࠪࢳ") + l1llllll1_opy_
    return l1l11_opy_ (u"ࠩࠪࢴ")
def l1ll1ll1l_opy_(l1lll1lll_opy_):
    if l1lll1lll_opy_ == l1l11_opy_ (u"ࠪ࠴ࠬࢵ"):
        return l1l11_opy_ (u"ࠫࡲ࠹ࡵ࠹ࠩࢶ")
    if l1lll1lll_opy_ == l1l11_opy_ (u"ࠬ࠷ࠧࢷ"):
        return l1l11_opy_ (u"࠭࡭ࡱࡧࡪࡸࡸ࠭ࢸ")
if __name__ == l1l11_opy_ (u"ࠧࡠࡡࡰࡥ࡮ࡴ࡟ࡠࠩࢹ"):
    l1lll111l_opy_()