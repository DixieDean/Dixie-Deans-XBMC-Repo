# coding: UTF-8
import sys
l1111_opy_ = sys.version_info [0] == 2
l11l11_opy_ = 2048
l11l1_opy_ = 7
def l111ll_opy_ (l11l1l_opy_):
	global l11111_opy_
	l11lll_opy_ = ord (l11l1l_opy_ [-1])
	l11ll_opy_ = l11l1l_opy_ [:-1]
	l1111l_opy_ = l11lll_opy_ % len (l11ll_opy_)
	l1l1l1_opy_ = l11ll_opy_ [:l1111l_opy_] + l11ll_opy_ [l1111l_opy_:]
	if l1111_opy_:
		l1l1ll_opy_ = unicode () .join ([unichr (ord (char) - l11l11_opy_ - (l1l1l_opy_ + l11lll_opy_) % l11l1_opy_) for l1l1l_opy_, char in enumerate (l1l1l1_opy_)])
	else:
		l1l1ll_opy_ = str () .join ([chr (ord (char) - l11l11_opy_ - (l1l1l_opy_ + l11lll_opy_) % l11l1_opy_) for l1l1l_opy_, char in enumerate (l1l1l1_opy_)])
	return eval (l1l1ll_opy_)
import xbmc
import xbmcaddon
import json
import urllib
import os
import dixie
l1l11l11l_opy_   = l111ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡵ࡬ࡶࡹࡪࡷࡧ࡮ࡤࡧࠪࣿ")
l1l111111_opy_   = l111ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡹࡶࡵࡩࡦࡳ࠭ࡤࡱࡧࡩࡸ࠭ऀ")
l1l111ll1_opy_ = l111ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡸࡻࡹࡵࡣࡵࠪँ")
l11lll11l_opy_    = l111ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡴࡹ࡮ࡩ࡫ࡪࡲࡷࡺࠬं")
l11lll1l1_opy_   = l111ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡪࡺࡺࡵࡳࡧࡶࡸࡷ࡫ࡡ࡮ࡵࠪः")
l1l11l111_opy_  = l111ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡺࡥࡢ࡮ࡷ࡬ࡺࡴࡤࡦࡴࡪࡶࡴࡻ࡮ࡥࠩऄ")
l1l1l111l_opy_   =  [l1l11l11l_opy_, l1l111111_opy_, l1l111ll1_opy_, l11lll11l_opy_, l11lll1l1_opy_, l1l11l111_opy_]
def checkAddons():
    for addon in l1l1l111l_opy_:
        if l1ll11l11_opy_(addon):
            l1ll11l1l_opy_(addon)
def l1ll11l11_opy_(addon):
    if xbmc.getCondVisibility(l111ll_opy_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡈࡢࡵࡄࡨࡩࡵ࡮ࠩࠧࡶ࠭ࠬअ") % addon) == 1:
        return True
    else:
        return False
def l1ll11l1l_opy_(addon):
    HOME = dixie.PROFILE
    PATH = os.path.join(HOME, l111ll_opy_ (u"ࠧࡪࡰ࡬ࠫआ"))
    l1ll1llll_opy_ = l1l111l1l_opy_(addon) + l111ll_opy_ (u"ࠨ࠰࡬ࡲ࡮࠭इ")
    l1l1l11ll_opy_  = os.path.join(PATH, l1ll1llll_opy_)
    response = l1lll1l11_opy_(addon)
    try:
        result = response[l111ll_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩई")]
    except KeyError:
        dixie.log(l111ll_opy_ (u"ࠪ࠱࠲࠳࠭࠮ࠢࡎࡩࡾࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡨࡧࡷࡊ࡮ࡲࡥࡴࠢ࠰࠱࠲࠳࠭ࠡࠩउ") + addon)
        result = {l111ll_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࡶࠫऊ"): [{l111ll_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨऋ"): l111ll_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࠬऌ"), l111ll_opy_ (u"ࡵࠨࡶࡼࡴࡪ࠭ऍ"): l111ll_opy_ (u"ࡶࠩࡸࡲࡰࡴ࡯ࡸࡰࠪऎ"), l111ll_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࠨए"): l111ll_opy_ (u"ࡸࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾࡸࡹࠩऐ"), l111ll_opy_ (u"ࡹࠬࡲࡡࡣࡧ࡯ࠫऑ"): l111ll_opy_ (u"ࡺ࠭ࡎࡐࠢࡆࡌࡆࡔࡎࡆࡎࡖࠫऒ")}], l111ll_opy_ (u"ࡻࠧ࡭࡫ࡰ࡭ࡹࡹࠧओ"): {l111ll_opy_ (u"ࡵࠨࡵࡷࡥࡷࡺࠧऔ"): 0, l111ll_opy_ (u"ࡶࠩࡷࡳࡹࡧ࡬ࠨक"): 1, l111ll_opy_ (u"ࡷࠪࡩࡳࡪࠧख"): 1}}
    l1lll1111_opy_ = result[l111ll_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩग")]
    l1l1ll1l1_opy_  = file(l1l1l11ll_opy_, l111ll_opy_ (u"ࠫࡼ࠭घ"))
    l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠬࡡࠧङ"))
    l1l1ll1l1_opy_.write(addon)
    l1l1ll1l1_opy_.write(l111ll_opy_ (u"࠭࡝ࠨच"))
    l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠧ࡝ࡰࠪछ"))
    l1l11111l_opy_ = []
    for channel in l1lll1111_opy_:
        l1l111l11_opy_ = channel[l111ll_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧज")]
        stream = channel[l111ll_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧझ")]
        l1l1111ll_opy_  = l11llll11_opy_(addon, l1l111l11_opy_)
        channel = l11llll1l_opy_(addon, l1l1111ll_opy_)
        l1l11l1l1_opy_ = channel + l111ll_opy_ (u"ࠪࡁࠬञ") + stream
        l1l11111l_opy_.append(l1l11l1l1_opy_)
        l1l11111l_opy_.sort()
    for item in l1l11111l_opy_:
      l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠦࠪࡹ࡜࡯ࠤट") % item)
    l1l1ll1l1_opy_.close()
def l1l111l1l_opy_(addon):
    if addon == l1l11l11l_opy_:
        return l111ll_opy_ (u"ࠬࡻ࡫ࡵࡸࡩࡶࡦࡴࡣࡦࠩठ")
    if addon == l1l111111_opy_:
        return l111ll_opy_ (u"࠭ࡸࡵࡴࡨࡥࡲ࠳ࡣࡰࡦࡨࡷࠬड")
    if addon == l1l111ll1_opy_:
        return l111ll_opy_ (u"ࠧࡪࡲࡷࡺࡸࡻࡢࡴࠩढ")
    if addon == l11lll11l_opy_:
        return l111ll_opy_ (u"ࠨࡳࡸ࡭ࡨࡱࠧण")
    if addon == l11lll1l1_opy_:
        return l111ll_opy_ (u"ࠩࡩࡹࡹࡻࡲࡦࠩत")
    if addon == l1l11l111_opy_:
        return l111ll_opy_ (u"ࠪࡷࡹ࡫ࡡ࡭ࡶ࡫ࠫथ")
def l1lll1l11_opy_(addon):
    l1l111lll_opy_ = (l111ll_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࠥࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧद") % addon)
    if addon == l1l11l111_opy_:
        l11lll111_opy_ = l111ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡵࡧࡤࡰࡹ࡮ࡵ࡯ࡦࡨࡶ࡬ࡸ࡯ࡶࡰࡧ࠳ࡄࡳ࡯ࡥࡧࡀ࡫ࡪࡴࡲࡦࡵࠩࡴࡴࡸࡴࡢ࡮ࡀࠩ࠼ࡨࠥ࠳࠴ࡱࡥࡲ࡫ࠥ࠳࠴ࠨ࠷ࡦࠫ࠲࠱ࠧ࠵࠶ࠪ࠻ࡢࡊࠧ࠸ࡨࠪ࠻ࡢࡄࡑࡏࡓࡗࠫ࠲࠱ࡹ࡫࡭ࡹ࡫ࠥ࠶ࡦࡆࡰ࡮ࡩ࡫ࠦ࠴࠳ࡘࡴࠫ࠲࠱ࡘ࡬ࡩࡼࠫ࠲࠱ࡖ࡫ࡩࠪ࠸࠰ࡍ࡫ࡶࡸࠪ࠸࠰ࡐࡨࠨ࠶࠵ࡉࡨࡢࡰࡱࡩࡱࡹࠥ࠶ࡤࠨ࠶࡫ࡉࡏࡍࡑࡕࠩ࠺ࡪࠥ࠶ࡤࠨ࠶࡫ࡏࠥ࠶ࡦࠨ࠶࠷ࠫ࠲ࡤࠧ࠵࠴ࠪ࠸࠲ࡱࡣࡵࡩࡳࡺࡡ࡭ࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࠩ࠷࠸ࡦࡢ࡮ࡶࡩࠪ࠸࠲ࠦ࠴ࡦࠩ࠷࠶ࠥ࠳࠴ࡸࡶࡱࠫ࠲࠳ࠧ࠶ࡥࠪ࠸࠰ࠦ࠴࠵࡬ࡹࡺࡰࠦ࠵ࡤࠩ࠷࡬ࠥ࠳ࡨࡰࡻ࠶࠴ࡩࡱࡶࡹ࠺࠻࠴ࡴࡷࠧ࠵࠶ࠪ࠸ࡣࠦ࠴࠳ࠩ࠷࠸ࡰࡱࡣࡶࡷࡼࡵࡲࡥࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࠩ࠷࠸࠰࠱࠲࠳ࠩ࠷࠸ࠥ࠳ࡥࠨ࠶࠵ࠫ࠲࠳࡯ࡤࡧࠪ࠸࠲ࠦ࠵ࡤࠩ࠷࠶ࠥ࠳࠴࠳࠴ࠪ࠹ࡡ࠲ࡃࠨ࠷ࡦ࠽࠸ࠦ࠵ࡤ࠸࠸ࠫ࠳ࡢ࠳࠵ࠩ࠸ࡧ࠷࠵ࠧ࠵࠶ࠪ࠸ࡣࠦ࠴࠳ࠩ࠷࠸ࡳࡦࡴ࡬ࡥࡱࠫ࠲࠳ࠧ࠶ࡥࠪ࠸࠰ࠦ࠹ࡥࠩ࠷࠸ࡳࡦࡰࡧࡣࡸ࡫ࡲࡪࡣ࡯ࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࡺࡲࡶࡧࠨ࠶ࡨࠫ࠲࠱ࠧ࠵࠶ࡨࡻࡳࡵࡱࡰࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࡺࡲࡶࡧࠨ࠶ࡨࠫ࠲࠱ࠧ࠵࠶ࡸࡴࠥ࠳࠴ࠨ࠷ࡦࠫ࠲࠱ࠧ࠵࠶ࠪ࠸࠲ࠦ࠴ࡦࠩ࠷࠶ࠥ࠳࠴ࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࠪ࠸࠲ࠦ࠵ࡤࠩ࠷࠶ࠥ࠳࠴ࠨ࠶࠷ࠫ࠲ࡤࠧ࠵࠴ࠪ࠸࠲ࡥࡧࡹ࡭ࡨ࡫࡟ࡪࡦ࠵ࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࠫ࠲࠳ࠧ࠵࠶ࠪ࠸ࡣࠦ࠴࠳ࠩ࠷࠸ࡤࡦࡸ࡬ࡧࡪࡥࡩࡥࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࠩ࠷࠸ࠥ࠳࠴ࠨ࠻ࡩࠫ࠲ࡤࠧ࠵࠴ࠪ࠸࠲ࡱࡣࡶࡷࡼࡵࡲࡥࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࡲࡺࡲ࡬ࠦ࠴ࡦࠩ࠷࠶ࠥ࠳࠴࡯ࡳ࡬࡯࡮ࠦ࠴࠵ࠩ࠸ࡧࠥ࠳࠲ࡱࡹࡱࡲࠥ࠸ࡦࠪध")
    else:
        l11lll111_opy_ = l111ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩन") + addon + l111ll_opy_ (u"ࠧ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿ࡶࡩࡨࡻࡲࡪࡶࡼࡣࡨ࡮ࡥࡤ࡭ࠩࡩࡽࡺࡲࡢࠨࡳࡥ࡬࡫ࠦࡱ࡮ࡲࡸࠫࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠧࡶ࡬ࡸࡱ࡫࠽ࡍ࡫ࡹࡩࠪ࠸࠰ࡕࡘࠩࡹࡷࡲࠧऩ")
    query = l1l1111l1_opy_(addon)
    l1l11l1ll_opy_ = (l111ll_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫप") % l11lll111_opy_)
    l1l11ll11_opy_ = (l111ll_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬफ") % query)
    try:
        xbmc.executeJSONRPC(l1l111lll_opy_)
        xbmc.executeJSONRPC(l1l11l1ll_opy_)
        response = xbmc.executeJSONRPC(l1l11ll11_opy_)
        content  = json.loads(response.decode(l111ll_opy_ (u"ࠪࡹࡹ࡬࠭࠹ࠩब"), l111ll_opy_ (u"ࠫ࡮࡭࡮ࡰࡴࡨࠫभ")))
        return content
    except:
        dixie.log(l111ll_opy_ (u"ࠬ࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳ࠠࡑ࡮ࡸ࡫࡮ࡴࠠࡆࡴࡵࡳࡷࠦ࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭ࠨम"))
        return {l111ll_opy_ (u"࠭ࡅࡳࡴࡲࡶࠬय") : l111ll_opy_ (u"ࠧࡑ࡮ࡸ࡫࡮ࡴࠠࡆࡴࡵࡳࡷ࠭र")}
def l1l1111l1_opy_(addon):
    if addon == l11lll11l_opy_:
        return l111ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡴࡹ࡮ࡩ࡫ࡪࡲࡷࡺ࠴ࡅࡡࡤࡶ࡬ࡳࡳࡃࡳࡵࡴࡨࡥࡲࡥࡶࡪࡦࡨࡳࠫ࡫ࡸࡵࡴࡤࠪࡵࡧࡧࡦࠨࡳࡰࡴࡺࠦࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡀࠪࡹ࡯ࡴ࡭ࡧࡀࡅࡱࡲࠦࡶࡴ࡯ࡁ࠵࠭ऱ")
    if addon == l11lll1l1_opy_:
        return l111ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡪࡺࡺࡵࡳࡧࡶࡸࡷ࡫ࡡ࡮ࡵ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡸࡺࡲࡦࡣࡰࡣࡻ࡯ࡤࡦࡱࠩࡩࡽࡺࡲࡢࠨࡳࡥ࡬࡫ࠦࡱ࡮ࡲࡸࠫࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠾ࠨࡷ࡭ࡹࡲࡥ࠾ࡃ࡯ࡰࠫࡻࡲ࡭࠿࠳ࠫल")
    if addon == l1l11l111_opy_:
        return l111ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡺࡥࡢ࡮ࡷ࡬ࡺࡴࡤࡦࡴࡪࡶࡴࡻ࡮ࡥ࠱ࡂ࡫ࡪࡴࡲࡦࡡࡱࡥࡲ࡫࠽ࡂ࡮࡯ࠪࡵࡵࡲࡵࡣ࡯ࡁࠪ࠽ࡂࠦ࠴࠵ࡲࡦࡳࡥࠦ࠴࠵ࠩ࠸ࡇࠫࠦ࠴࠵ࠩ࠺ࡈࡉࠦ࠷ࡇࠩ࠺ࡈࡃࡐࡎࡒࡖ࠰ࡽࡨࡪࡶࡨࠩ࠺ࡊࡃ࡭࡫ࡦ࡯࠰࡚࡯ࠬࡘ࡬ࡩࡼ࠱ࡔࡩࡧ࠮ࡐ࡮ࡹࡴࠬࡑࡩ࠯ࡈ࡮ࡡ࡯ࡰࡨࡰࡸࠫ࠵ࡃࠧ࠵ࡊࡈࡕࡌࡐࡔࠨ࠹ࡉࠫ࠵ࡃࠧ࠵ࡊࡎࠫ࠵ࡅࠧ࠵࠶ࠪ࠸ࡃࠬࠧ࠵࠶ࡵࡧࡲࡦࡰࡷࡥࡱࠫ࠲࠳ࠧ࠶ࡅ࠰ࠫ࠲࠳ࡨࡤࡰࡸ࡫ࠥ࠳࠴ࠨ࠶ࡈ࠱ࠥ࠳࠴ࡸࡶࡱࠫ࠲࠳ࠧ࠶ࡅ࠰ࠫ࠲࠳ࡪࡷࡸࡵࠫ࠳ࡂࠧ࠵ࡊࠪ࠸ࡆ࡮ࡹ࠴࠲࡮ࡶࡴࡷ࠸࠹࠲ࡹࡼࠥ࠳࠴ࠨ࠶ࡈ࠱ࠥ࠳࠴ࡳࡴࡦࡹࡳࡸࡱࡵࡨࠪ࠸࠲ࠦ࠵ࡄ࠯ࠪ࠸࠲࠱࠲࠳࠴ࠪ࠸࠲ࠦ࠴ࡆ࠯ࠪ࠸࠲࡮ࡣࡦࠩ࠷࠸ࠥ࠴ࡃ࠮ࠩ࠷࠸࠰࠱ࠧ࠶ࡅ࠶ࡇࠥ࠴ࡃ࠺࠼ࠪ࠹ࡁ࠵࠵ࠨ࠷ࡆ࠷࠲ࠦ࠵ࡄ࠻࠹ࠫ࠲࠳ࠧ࠵ࡇ࠰ࠫ࠲࠳ࡵࡨࡶ࡮ࡧ࡬ࠦ࠴࠵ࠩ࠸ࡇࠫࠦ࠹ࡅࠩ࠷࠸ࡳࡦࡰࡧࡣࡸ࡫ࡲࡪࡣ࡯ࠩ࠷࠸ࠥ࠴ࡃ࠮ࡸࡷࡻࡥࠦ࠴ࡆ࠯ࠪ࠸࠲ࡤࡷࡶࡸࡴࡳࠥ࠳࠴ࠨ࠷ࡆ࠱ࡴࡳࡷࡨࠩ࠷ࡉࠫࠦ࠴࠵ࡷࡳࠫ࠲࠳ࠧ࠶ࡅ࠰ࠫ࠲࠳ࠧ࠵࠶ࠪ࠸ࡃࠬࠧ࠵࠶ࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࠥ࠳࠴ࠨ࠷ࡆ࠱ࠥ࠳࠴ࠨ࠶࠷ࠫ࠲ࡄ࠭ࠨ࠶࠷ࡪࡥࡷ࡫ࡦࡩࡤ࡯ࡤ࠳ࠧ࠵࠶ࠪ࠹ࡁࠬࠧ࠵࠶ࠪ࠸࠲ࠦ࠴ࡆ࠯ࠪ࠸࠲ࡥࡧࡹ࡭ࡨ࡫࡟ࡪࡦࠨ࠶࠷ࠫ࠳ࡂ࠭ࠨ࠶࠷ࠫ࠲࠳ࠧ࠺ࡈࠪ࠸ࡃࠬࠧ࠵࠶ࡵࡧࡳࡴࡹࡲࡶࡩࠫ࠲࠳ࠧ࠶ࡅ࠰ࡴࡵ࡭࡮ࠨ࠶ࡈ࠱ࠥ࠳࠴࡯ࡳ࡬࡯࡮ࠦ࠴࠵ࠩ࠸ࡇࠫ࡯ࡷ࡯ࡰࠪ࠽ࡄࠧ࡯ࡲࡨࡪࡃࡣࡩࡣࡱࡲࡪࡲࡳࠧࡩࡨࡲࡷ࡫࡟ࡪࡦࡀࠩ࠷ࡇࠧळ")
    else:
        Addon = xbmcaddon.Addon(addon)
        username =  Addon.getSetting(l111ll_opy_ (u"ࠫࡰࡧࡳࡶࡶࡤ࡮ࡦࡴࡩ࡮࡫ࠪऴ"))
        password =  Addon.getSetting(l111ll_opy_ (u"ࠬࡹࡡ࡭ࡣࡶࡳࡳࡧࠧव"))
        l11lll1ll_opy_     = l111ll_opy_ (u"࠭࠯ࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡵࡷࡶࡪࡧ࡭ࡠࡸ࡬ࡨࡪࡵࠦࡦࡺࡷࡶࡦࠬࡰࡢࡩࡨࠪࡵࡲ࡯ࡵࠨࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡂࠬࡴࡪࡶ࡯ࡩࡂࡇ࡬࡭ࠨࡸࡶࡱࡃࠧश")
        l1ll11ll1_opy_  =  l1lll11ll_opy_(addon)
        l1l1ll11l_opy_   = l111ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪष") + addon
        l11lllll1_opy_  =  l1l1ll11l_opy_ + l11lll1ll_opy_ + l1ll11ll1_opy_
        l1l11ll1l_opy_ = l111ll_opy_ (u"ࠨࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠫस") + username + l111ll_opy_ (u"ࠩࠩࡴࡦࡹࡳࡸࡱࡵࡨࡂ࠭ह") + password + l111ll_opy_ (u"ࠪࠪࡹࡿࡰࡦ࠿ࡪࡩࡹࡥ࡬ࡪࡸࡨࡣࡸࡺࡲࡦࡣࡰࡷࠫࡩࡡࡵࡡ࡬ࡨࡂ࠶ࠧऺ")
        return l11lllll1_opy_ + urllib.quote_plus(l1l11ll1l_opy_)
def l1lll11ll_opy_(addon):
    if (addon == l1l11l11l_opy_) or (addon == l1l111111_opy_):
        return l111ll_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠸࠽࠮࠲࠺࠺࠲࠶࠹࠹࠯࠳࠸࠹࠿࠾࠰࠱࠲࠲ࡩࡳ࡯ࡧ࡮ࡣ࠵࠲ࡵ࡮ࡰࡀࠩऻ")
    if addon == l1l111ll1_opy_:
        return l111ll_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠸࠮ࡸࡧ࡯ࡧࡲ࠴ࡴࡷ࠼࠻࠴࠵࠶࠯ࡦࡰ࡬࡫ࡲࡧ࠲࠯ࡲ࡫ࡴࡄ़࠭")
def l11llll11_opy_(addon, l1ll1l111_opy_):
    if (addon == l1l11l11l_opy_) or (addon == l1l111111_opy_) or (addon == l1l111ll1_opy_):
        l1ll1l111_opy_ = l1ll1l111_opy_.replace(l111ll_opy_ (u"࠭ࠠࠡࠩऽ"), l111ll_opy_ (u"ࠧࠡࠩा")).replace(l111ll_opy_ (u"ࠨࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫि"), l111ll_opy_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫी"))
        return l1ll1l111_opy_
    if (addon == l11lll11l_opy_) or (addon == l11lll1l1_opy_) or (addon == l1l11l111_opy_):
        return l1ll1l111_opy_
def l11llll1l_opy_(addon, l11llllll_opy_):
    if (addon == l1l11l11l_opy_) or (addon == l1l111111_opy_) or (addon == l1l111ll1_opy_):
        channel = l11llllll_opy_.rsplit(l111ll_opy_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬु"), 1)[0].split(l111ll_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡼ࡮ࡩࡵࡧࡠࠫू"), 1)[-1]
        channel = channel.replace(l111ll_opy_ (u"ࠬࡈࡂࡄࠢ࠴ࠫृ"), l111ll_opy_ (u"࠭ࡂࡃࡅࠣࡓࡳ࡫ࠧॄ")).replace(l111ll_opy_ (u"ࠧࡃࡄࡆࠤ࠷࠭ॅ"), l111ll_opy_ (u"ࠨࡄࡅࡇ࡚ࠥࡷࡰࠩॆ")).replace(l111ll_opy_ (u"ࠩࡅࡆࡈࠦ࠴ࠨे"), l111ll_opy_ (u"ࠪࡆࡇࡉࠠࡇࡑࡘࡖࠬै")).replace(l111ll_opy_ (u"ࠫࡎ࡚ࡖࠡ࠳ࠪॉ"), l111ll_opy_ (u"ࠬࡏࡔࡗ࠳ࠪॊ")).replace(l111ll_opy_ (u"࠭ࡉࡕࡘࠣ࠶ࠬो"), l111ll_opy_ (u"ࠧࡊࡖ࡙࠶ࠬौ")).replace(l111ll_opy_ (u"ࠨࡋࡗ࡚ࠥ࠹्ࠧ"), l111ll_opy_ (u"ࠩࡌࡘ࡛࠹ࠧॎ")).replace(l111ll_opy_ (u"ࠪࡍ࡙࡜ࠠ࠵ࠩॏ"), l111ll_opy_ (u"ࠫࡎ࡚ࡖ࠵ࠩॐ"))
        return channel
    if (addon == l11lll11l_opy_) or (addon == l11lll1l1_opy_):
        channel = l11llllll_opy_.rsplit(l111ll_opy_ (u"࡛ࠬࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ॑"))[0].replace(l111ll_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡷࡩ࡫ࡷࡩࡢ॒࠭"), l111ll_opy_ (u"ࠧࠨ॓"))
        channel = channel.replace(l111ll_opy_ (u"ࠨ࠼ࠪ॔"), l111ll_opy_ (u"ࠩࠪॕ")).replace(l111ll_opy_ (u"ࠪࡆࡇࡉࠠ࠲ࠩॖ"), l111ll_opy_ (u"ࠫࡇࡈࡃࠡࡑࡱࡩࠬॗ")).replace(l111ll_opy_ (u"ࠬࡈࡂࡄࠢ࠵ࠫक़"), l111ll_opy_ (u"࠭ࡂࡃࡅࠣࡘࡼࡵࠧख़")).replace(l111ll_opy_ (u"ࠧࡃࡄࡆࠤ࠹࠭ग़"), l111ll_opy_ (u"ࠨࡄࡅࡇࠥࡌࡏࡖࡔࠪज़")).replace(l111ll_opy_ (u"ࠩࡌࡘ࡛ࠦ࠱ࠨड़"), l111ll_opy_ (u"ࠪࡍ࡙࡜࠱ࠨढ़")).replace(l111ll_opy_ (u"ࠫࡎ࡚ࡖࠡ࠴ࠪफ़"), l111ll_opy_ (u"ࠬࡏࡔࡗ࠴ࠪय़")).replace(l111ll_opy_ (u"࠭ࡉࡕࡘࠣ࠷ࠬॠ"), l111ll_opy_ (u"ࠧࡊࡖ࡙࠷ࠬॡ")).replace(l111ll_opy_ (u"ࠨࡋࡗ࡚ࠥ࠺ࠧॢ"), l111ll_opy_ (u"ࠩࡌࡘ࡛࠺ࠧॣ"))
        return channel
    else:
        channel = l11llllll_opy_.replace(l111ll_opy_ (u"ࠪࡆࡇࡉࠠ࠲ࠩ।"), l111ll_opy_ (u"ࠫࡇࡈࡃࠡࡑࡱࡩࠬ॥")).replace(l111ll_opy_ (u"ࠬࡈࡂࡄࠢ࠵ࠫ०"), l111ll_opy_ (u"࠭ࡂࡃࡅࠣࡘࡼࡵࠧ१")).replace(l111ll_opy_ (u"ࠧࡃࡄࡆࠤ࠹࠭२"), l111ll_opy_ (u"ࠨࡄࡅࡇࠥࡌࡏࡖࡔࠪ३")).replace(l111ll_opy_ (u"ࠩࡌࡘ࡛ࠦ࠱ࠨ४"), l111ll_opy_ (u"ࠪࡍ࡙࡜࠱ࠨ५")).replace(l111ll_opy_ (u"ࠫࡎ࡚ࡖࠡ࠴ࠪ६"), l111ll_opy_ (u"ࠬࡏࡔࡗ࠴ࠪ७")).replace(l111ll_opy_ (u"࠭ࡉࡕࡘࠣ࠷ࠬ८"), l111ll_opy_ (u"ࠧࡊࡖ࡙࠷ࠬ९")).replace(l111ll_opy_ (u"ࠨࡋࡗ࡚ࠥ࠺ࠧ॰"), l111ll_opy_ (u"ࠩࡌࡘ࡛࠺ࠧॱ"))
        return channel
def l1l1ll1ll_opy_(e):
    l1ll1l11l_opy_ = l111ll_opy_ (u"ࠪࡗࡴࡸࡲࡺ࠮ࠣࡥࡳࠦࡥࡳࡴࡲࡶࠥࡵࡣࡤࡷࡵࡩࡩࡀࠠࡋࡕࡒࡒࠥࡋࡲࡳࡱࡵ࠾ࠥࠫࡳࠨॲ")  %e
    l1ll1l1l1_opy_ = l111ll_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡨࡵ࡮ࡵࡣࡦࡸࠥࡻࡳࠡࡱࡱࠤࡹ࡮ࡥࠡࡨࡲࡶࡺࡳ࠮ࠨॳ")
    l1ll1l1ll_opy_ = l111ll_opy_ (u"࡛ࠬࡰ࡭ࡱࡤࡨࠥࡧࠠ࡭ࡱࡪࠤࡻ࡯ࡡࠡࡶ࡫ࡩࠥࡧࡤࡥࡱࡱࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸࠦࡡ࡯ࡦࠣࡴࡴࡹࡴࠡࡶ࡫ࡩࠥࡲࡩ࡯࡭࠱ࠫॴ")
    dixie.log(e)
    dixie.DialogOK(l1ll1l11l_opy_, l1ll1l1l1_opy_, l1ll1l1ll_opy_)
    dixie.SetSetting(SETTING, l111ll_opy_ (u"࠭ࠧॵ"))