# -*- coding: utf-8 -*-
import sys
l11llll_opy_ = sys.version_info [0] == 2
l1llll1_opy_ = 2048
l1llll_opy_ = 7
def l11l11_opy_ (ll_opy_):
	global l1lllll_opy_
	l1l1111_opy_ = ord (ll_opy_ [-1])
	l1111l_opy_ = ll_opy_ [:-1]
	l1ll111_opy_ = l1l1111_opy_ % len (l1111l_opy_)
	l1l1l_opy_ = l1111l_opy_ [:l1ll111_opy_] + l1111l_opy_ [l1ll111_opy_:]
	if l11llll_opy_:
		l1ll1ll_opy_ = unicode () .join ([unichr (ord (char) - l1llll1_opy_ - (l11ll1_opy_ + l1l1111_opy_) % l1llll_opy_) for l11ll1_opy_, char in enumerate (l1l1l_opy_)])
	else:
		l1ll1ll_opy_ = str () .join ([chr (ord (char) - l1llll1_opy_ - (l11ll1_opy_ + l1l1111_opy_) % l1llll_opy_) for l11ll1_opy_, char in enumerate (l1l1l_opy_)])
	return eval (l1ll1ll_opy_)
import os
import json
import requests
import dixie
l1l11l_opy_ = dixie.PROFILE
PATH = os.path.join(l1l11l_opy_, l11l11_opy_ (u"ࠬࡶ࡬ࡪࡵࡷࡷࠬং"))
def loadPlaylists():
    dixie.log(l11l11_opy_ (u"࠭࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࠦࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠢࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠨঃ"))
    if os.path.exists(PATH):
        return json.load(open(PATH))
    l11lll1l1_opy_()
    return json.load(open(PATH))
def l11lll1l1_opy_():
    source = dixie.GetSetting(l11l11_opy_ (u"ࠧࡪࡲࡷࡺ࠳ࡹ࡯ࡶࡴࡦࡩࠬ঄"))
    if not source == l11l11_opy_ (u"ࠨ࠳ࠪঅ"):
        return l11llllll_opy_()
    return l11ll11ll_opy_()
def l11llllll_opy_():
    l1l11l1l1_opy_ = []
    if dixie.GetSetting(l11l11_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠱ࠩআ")) == l11l11_opy_ (u"ࠪࡸࡷࡻࡥࠨই"):
        l1l1l11l1_opy_  = dixie.GetSetting(l11l11_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠳ࡣ࡚ࡘࡌࠨঈ"))
        l1l11ll11_opy_ = dixie.GetSetting(l11l11_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠴ࡤࡖࡏࡓࡖࠪউ"))
        l11lllll1_opy_ = dixie.GetSetting(l11l11_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠵ࡥࡔ࡚ࡒࡈࠫঊ"))
        l1l11lll1_opy_ = dixie.GetSetting(l11l11_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠶࡟ࡖࡕࡈࡖࠬঋ"))
        l1l1l11ll_opy_ = dixie.GetSetting(l11l11_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠰ࡠࡒࡄࡗࡘ࠭ঌ"))
        if len(l1l1l11l1_opy_) > 0:
            l1l111l11_opy_ = l1l11ll1l_opy_(l1l1l11l1_opy_, l1l11ll11_opy_, l11lllll1_opy_, l1l11lll1_opy_, l1l1l11ll_opy_)
            l1l11l1l1_opy_.append((l1l111l11_opy_, l11l11_opy_ (u"ࠩࡌࡔ࡙࡜࠱࠻ࠢࠪ঍")))
    if dixie.GetSetting(l11l11_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠳ࠪ঎")) == l11l11_opy_ (u"ࠫࡹࡸࡵࡦࠩএ"):
        l1l1l11l1_opy_  = dixie.GetSetting(l11l11_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠵ࡤ࡛ࡒࡍࠩঐ"))
        l1l11ll11_opy_ = dixie.GetSetting(l11l11_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠶ࡥࡐࡐࡔࡗࠫ঑"))
        l11lllll1_opy_ = dixie.GetSetting(l11l11_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠷࡟ࡕ࡛ࡓࡉࠬ঒"))
        l1l11lll1_opy_ = dixie.GetSetting(l11l11_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠱ࡠࡗࡖࡉࡗ࠭ও"))
        l1l1l11ll_opy_ = dixie.GetSetting(l11l11_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠲ࡡࡓࡅࡘ࡙ࠧঔ"))
        if len(l1l1l11l1_opy_) > 0:
            l1l1111ll_opy_ = l1l11ll1l_opy_(l1l1l11l1_opy_, l1l11ll11_opy_, l11lllll1_opy_, l1l11lll1_opy_, l1l1l11ll_opy_)
            l1l11l1l1_opy_.append((l1l1111ll_opy_, l11l11_opy_ (u"ࠪࡍࡕ࡚ࡖ࠳࠼ࠣࠫক")))
    if dixie.GetSetting(l11l11_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠵ࠫখ")) == l11l11_opy_ (u"ࠬࡺࡲࡶࡧࠪগ"):
        l1l1l11l1_opy_  = dixie.GetSetting(l11l11_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠷ࡥࡕࡓࡎࠪঘ"))
        l1l11ll11_opy_ = dixie.GetSetting(l11l11_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠸࡟ࡑࡑࡕࡘࠬঙ"))
        l11lllll1_opy_ = dixie.GetSetting(l11l11_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠲ࡠࡖ࡜ࡔࡊ࠭চ"))
        l1l11lll1_opy_ = dixie.GetSetting(l11l11_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠳ࡡࡘࡗࡊࡘࠧছ"))
        l1l1l11ll_opy_ = dixie.GetSetting(l11l11_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠴ࡢࡔࡆ࡙ࡓࠨজ"))
        if len(l1l1l11l1_opy_) > 0:
            l1l1111l1_opy_ = l1l11ll1l_opy_(l1l1l11l1_opy_, l1l11ll11_opy_, l11lllll1_opy_, l1l11lll1_opy_, l1l1l11ll_opy_)
            l1l11l1l1_opy_.append((l1l1111l1_opy_, l11l11_opy_ (u"ࠫࡎࡖࡔࡗ࠵࠽ࠤࠬঝ")))
    return l11lll11l_opy_(l11l11_opy_ (u"࡛ࠬࡒࡍࡕࠪঞ"),  l1l11l1l1_opy_)
def l11ll11ll_opy_():
    l1l11l1l1_opy_ = []
    if dixie.GetSetting(l11l11_opy_ (u"࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡶࡼࡴࡪ࠭ট")) == l11l11_opy_ (u"ࠧ࠱ࠩঠ"):
        if dixie.GetSetting(l11l11_opy_ (u"ࠨࡗࡕࡐࡤࡕࠧড")) == l11l11_opy_ (u"ࠩࡷࡶࡺ࡫ࠧঢ"):
            l11ll11l1_opy_ = dixie.GetSetting(l11l11_opy_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡻࡲ࡭ࠩণ"))
            if len(l11ll11l1_opy_) > 0:
                l1l11l1l1_opy_.append((l11ll11l1_opy_, l11l11_opy_ (u"࡚ࠫࡘࡌ࠲࠼ࠣࠫত")))
        if dixie.GetSetting(l11l11_opy_ (u"࡛ࠬࡒࡍࡡ࠴ࠫথ")) == l11l11_opy_ (u"࠭ࡴࡳࡷࡨࠫদ"):
            l11ll1l11_opy_ = dixie.GetSetting(l11l11_opy_ (u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡸࡶࡱ࠷ࠧধ"))
            if len(l11ll1l11_opy_) > 0:
                l1l11l1l1_opy_.append((l11ll1l11_opy_, l11l11_opy_ (u"ࠨࡗࡕࡐ࠷ࡀࠠࠨন")))
        if dixie.GetSetting(l11l11_opy_ (u"ࠩࡘࡖࡑࡥ࠲ࠨ঩")) == l11l11_opy_ (u"ࠪࡸࡷࡻࡥࠨপ"):
            l1l11111l_opy_ = dixie.GetSetting(l11l11_opy_ (u"ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡵࡳ࡮࠵ࠫফ"))
            if len(l1l11111l_opy_) > 0:
                l1l11l1l1_opy_.append((l1l11111l_opy_, l11l11_opy_ (u"࡛ࠬࡒࡍ࠵࠽ࠤࠬব")))
        dixie.log(l1l11l1l1_opy_)
        return l11lll11l_opy_(l11l11_opy_ (u"࠭ࡕࡓࡎࡖࠫভ"),  l1l11l1l1_opy_)
    if dixie.GetSetting(l11l11_opy_ (u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡷࡽࡵ࡫ࠧম")) == l11l11_opy_ (u"ࠨ࠳ࠪয"):
        if dixie.GetSetting(l11l11_opy_ (u"ࠩࡉࡍࡑࡋ࡟࠱ࠩর")) == l11l11_opy_ (u"ࠪࡸࡷࡻࡥࠨ঱"):
            l1l111lll_opy_ = os.path.join(dixie.GetSetting(l11l11_opy_ (u"ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡦࡪ࡮ࡨࠫল")))
            if l1l111lll_opy_:
                l1l11l1l1_opy_.append((l1l111lll_opy_, l11l11_opy_ (u"ࠬࡌࡉࡍࡇ࠴࠾ࠥ࠭঳")))
        if dixie.GetSetting(l11l11_opy_ (u"࠭ࡆࡊࡎࡈࡣ࠵࠭঴")) == l11l11_opy_ (u"ࠧࡵࡴࡸࡩࠬ঵"):
            l1l11l111_opy_ = os.path.join(dixie.GetSetting(l11l11_opy_ (u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡪ࡮ࡲࡥ࠲ࠩশ")))
            if l1l11l111_opy_:
                l1l11l1l1_opy_.append((l1l11l111_opy_, l11l11_opy_ (u"ࠩࡉࡍࡑࡋ࠲࠻ࠢࠪষ")))
        if dixie.GetSetting(l11l11_opy_ (u"ࠪࡊࡎࡒࡅࡠ࠲ࠪস")) == l11l11_opy_ (u"ࠫࡹࡸࡵࡦࠩহ"):
            l1l11l11l_opy_ = os.path.join(dixie.GetSetting(l11l11_opy_ (u"ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡧ࡫࡯ࡩ࠷࠭঺")))
            if l1l11l11l_opy_:
                l1l11l1l1_opy_.append((l1l11l11l_opy_, l11l11_opy_ (u"࠭ࡆࡊࡎࡈ࠷࠿ࠦࠧ঻")))
        dixie.log(l1l11l1l1_opy_)
        return l11lll11l_opy_(l11l11_opy_ (u"ࠧࡇࡋࡏࡉࡘ়࠭"), l1l11l1l1_opy_)
    if dixie.GetSetting(l11l11_opy_ (u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡸࡾࡶࡥࠨঽ")) == l11l11_opy_ (u"ࠩ࠵ࠫা"):
        return l11ll1ll1_opy_()
def l11ll1ll1_opy_():
    l11ll1lll_opy_ = [l11l11_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡼ࠳ࡩ࡯࠰ࡊࡈ࡞࠺ࡠࡹࡪࡌࡨ࡛ࠬি"), l11l11_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱ࡻࡪ࠺ࡏ࠳ࡉࡑࡧ࡝ࡓ࠭ী"), l11l11_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲࡙ࡑࡩ࠰࠲ࡏࡒࡐ࡬ࡉࠧু"), l11l11_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳࡯ࡻࡎࡎࡐࡪࡻ࡯ࡖ࠰ࠨূ"), l11l11_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡹ࠰ࡦࡳ࠴ࡪࡪࡃࡣ࠴ࡲࡻ࠿ࡇࡻࠩৃ"), l11l11_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡺ࠱ࡧࡴ࠵࡮ࡗࡵࡴࡧ࡬ࡩࡣ࠺ࡻࠪৄ"), l11l11_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡻ࠲ࡨࡵ࠯ࡹࡎࡆ࠽࠹ࡋࡖࡒࡸ࡜ࠫ৅"), l11l11_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡼ࠳ࡩ࡯࠰ࡶࡶࡉ࠸ࡐࡐࡵࡨࡐࡶࠬ৆"), l11l11_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱ࡨ࡚࡛ࡇࡷࡌࡋࡶࡗ࡭࠭ে"), l11l11_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲ࡼࡖࡶࡆࡋ࡙ࡪ࡭࡬ࡰࠧৈ")]
    for url in l11ll1lll_opy_:
        request = requests.get(url)
        content = request.content
        if l11l11_opy_ (u"࠭ࠣࡆ࡚ࡗࡑ࠸࡛ࠧ৉") in content:
            return l11lll11l_opy_(l11l11_opy_ (u"ࠧࡄࡎࡒ࡙ࡉ࠭৊"), [(url, l11l11_opy_ (u"ࠨࠩো"))])
            break
def l11lll11l_opy_(l11lll111_opy_, plist):
    dixie.log(l11lll111_opy_)
    dixie.log(plist)
    playlists = []
    for item in plist:
        url = item[0]
        l1l111l1l_opy_ = item[1]
        l1l111111_opy_ = l1l111ll1_opy_(l11lll111_opy_, url, l1l111l1l_opy_)
        playlists.extend(l1l111111_opy_)
    json.dump(playlists, open(PATH,l11l11_opy_ (u"ࠩࡺࠫৌ")))
def l1l111ll1_opy_(l11lll111_opy_, url, l1l111l1l_opy_):
    content = l11ll1l1l_opy_(l11lll111_opy_, url)
    l11lll1ll_opy_ = list()
    l11lll_opy_   = l11l11_opy_ (u"্ࠪࠫ")
    value   = l11l11_opy_ (u"ࠫࠬৎ")
    for line in content:
        if line.startswith(l11l11_opy_ (u"ࠬࠩࡅ࡙ࡖࡌࡒࡋࡀࠧ৏")):
            l11ll1l_opy_ = dixie.cleanLabel(line.split(l11l11_opy_ (u"࠭ࠬࠨ৐"))[-1].strip())
            l1ll1_opy_ = dixie.mapChannelName(l11ll1l_opy_)
            l11lll_opy_ = l1l111l1l_opy_ + l1ll1_opy_
        if line.startswith(l11l11_opy_ (u"ࠧࡳࡶࡰࡴࠬ৑")) or line.startswith(l11l11_opy_ (u"ࠨࡴࡷࡱࡵ࡫ࠧ৒")) or line.startswith(l11l11_opy_ (u"ࠩࡵࡸࡸࡶࠧ৓")) or line.startswith(l11l11_opy_ (u"ࠪ࡬ࡹࡺࡰࠨ৔")):
            value = line.replace(l11l11_opy_ (u"ࠫࡷࡺ࡭ࡱ࠼࠲࠳ࠩࡕࡐࡕ࠼ࡵࡸࡲࡶ࠭ࡳࡣࡺࡁࠬ৕"), l11l11_opy_ (u"ࠬ࠭৖")).replace(l11l11_opy_ (u"࠭࡜࡯ࠩৗ"), l11l11_opy_ (u"ࠧࠨ৘"))
            l11lll1ll_opy_.append((l11lll_opy_, value))
    return l11lll1ll_opy_
def l11ll1l1l_opy_(l11lll111_opy_, url):
    if l11lll111_opy_ == l11l11_opy_ (u"ࠨࡗࡕࡐࡘ࠭৙"):
        content = requests.get(url)
        return content.iter_lines()
    if l11lll111_opy_ == l11l11_opy_ (u"ࠩࡉࡍࡑࡋࡓࠨ৚"):
        with open(url) as content:
            return content.readlines()
    if l11lll111_opy_ == l11l11_opy_ (u"ࠪࡇࡑࡕࡕࡅࠩ৛"):
        content = requests.get(url)
        dixie.log(content)
        return content.iter_lines()
def l1l11ll1l_opy_(l1l1l11l1_opy_, l1l11ll11_opy_, l11lllll1_opy_, l1l11lll1_opy_, l1l1l11ll_opy_):
    url  = l11l11_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬড়")
    url +=  l1l1l11l1_opy_
    url +=  l11llll1l_opy_(l1l11ll11_opy_)
    url += l11l11_opy_ (u"ࠬ࠵ࡧࡦࡶ࠱ࡴ࡭ࡶ࠿ࡶࡵࡨࡶࡳࡧ࡭ࡦ࠿ࠪঢ়")
    url +=  l1l11lll1_opy_
    url += l11l11_opy_ (u"࠭ࠦࡱࡣࡶࡷࡼࡵࡲࡥ࠿ࠪ৞")
    url +=  l1l1l11ll_opy_
    url += l11l11_opy_ (u"ࠧࠧࡶࡼࡴࡪࡃ࡭࠴ࡷࡢࡴࡱࡻࡳࠧࡱࡸࡸࡵࡻࡴ࠾ࠩয়")
    url +=  l11llll11_opy_(l11lllll1_opy_)
    return url
def l11llll1l_opy_(l1l11ll11_opy_):
    if not l1l11ll11_opy_ == l11l11_opy_ (u"ࠨࠩৠ"):
        return l11l11_opy_ (u"ࠩ࠽ࠫৡ") + l1l11ll11_opy_
    return l11l11_opy_ (u"ࠪࠫৢ")
def l11llll11_opy_(l11lllll1_opy_):
    if l11lllll1_opy_ == l11l11_opy_ (u"ࠫ࠵࠭ৣ"):
        return l11l11_opy_ (u"ࠬࡳ࠳ࡶ࠺ࠪ৤")
    if l11lllll1_opy_ == l11l11_opy_ (u"࠭࠱ࠨ৥"):
        return l11l11_opy_ (u"ࠧ࡮ࡲࡨ࡫ࡹࡹࠧ০")
if __name__ == l11l11_opy_ (u"ࠨࡡࡢࡱࡦ࡯࡮ࡠࡡࠪ১"):
    l11lll1l1_opy_()