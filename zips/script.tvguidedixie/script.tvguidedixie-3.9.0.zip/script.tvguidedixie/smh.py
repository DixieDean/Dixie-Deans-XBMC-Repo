# coding: UTF-8
import sys
l1llll_opy_ = sys.version_info [0] == 2
l1ll1_opy_ = 2048
l11l_opy_ = 7
def l11l1_opy_ (ll_opy_):
	global l1lll1_opy_
	l11ll1_opy_ = ord (ll_opy_ [-1])
	l1111_opy_ = ll_opy_ [:-1]
	l1_opy_ = l11ll1_opy_ % len (l1111_opy_)
	l1l1l1_opy_ = l1111_opy_ [:l1_opy_] + l1111_opy_ [l1_opy_:]
	if l1llll_opy_:
		l1ll11_opy_ = unicode () .join ([unichr (ord (char) - l1ll1_opy_ - (l11ll_opy_ + l11ll1_opy_) % l11l_opy_) for l11ll_opy_, char in enumerate (l1l1l1_opy_)])
	else:
		l1ll11_opy_ = str () .join ([chr (ord (char) - l1ll1_opy_ - (l11ll_opy_ + l11ll1_opy_) % l11l_opy_) for l11ll_opy_, char in enumerate (l1l1l1_opy_)])
	return eval (l1ll11_opy_)
import xbmc
import xbmcaddon
import dixie
import os
import sys
import json
l11l11111_opy_ = l11l1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴ࡯ࡤࡶࡹ࡮ࡵࡣࠩલ")
l111lllll_opy_ = l11l1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࠸ࠧળ")
l1l111l_opy_ = [l11l11111_opy_, l111lllll_opy_]
def checkAddons():
    for addon in l1l111l_opy_:
        if l1ll1l1_opy_(addon):
            createINI(addon)
def l1ll1l1_opy_(addon):
    if xbmc.getCondVisibility(l11l1_opy_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡌࡦࡹࡁࡥࡦࡲࡲ࠭ࠫࡳࠪࠩ઴") % addon) == 1:
        return True
    else:
        return False
def l111llll1_opy_(addon):
    Addon  = xbmcaddon.Addon(id=addon)
    prefix = l1lll1l_opy_(Addon)
    if prefix == l11l1_opy_ (u"ࠫࡍࡊࡔࡗ࠼ࠪવ"):
        return os.path.join(dixie.PROFILE, l11l1_opy_ (u"ࠬࡹࡨࡵࡧࡰࡴࠬશ"))
    if prefix == l11l1_opy_ (u"࠭ࡈࡅࡖ࡙࠶࠿࠭ષ"):
        return os.path.join(dixie.PROFILE, l11l1_opy_ (u"ࠧࡳࡷࡷࡩࡲࡶࠧસ"))
def createINI(addon):
    # shpath = os.path.join(dixie.PROFILE, 'shtemp')
    # if os.path.exists(shpath):
    #     os.remove(shpath)
    #
    # rupath = os.path.join(dixie.PROFILE, 'rutemp')
    # if os.path.exists(rupath):
    #     os.remove(rupath)

    Addon  = xbmcaddon.Addon(id=addon)
    path   = Addon.getAddonInfo(l11l1_opy_ (u"ࠨࡲࡤࡸ࡭࠭હ"))
    prefix = l1lll1l_opy_(Addon)
    sys.path.insert(0, path)
    import api
    api.login()
    doJSON(addon)
    HOME  = dixie.PROFILE
    l1lll11_opy_ = os.path.join(HOME, l11l1_opy_ (u"ࠩ࡬ࡲ࡮࠭઺"))
    l11l11_opy_  = str(addon).split(l11l1_opy_ (u"ࠪ࠲ࠬ઻"))[2] + l11l1_opy_ (u"ࠫ࠳࡯࡮ࡪ઼ࠩ")
    l1l11l1_opy_   = os.path.join(l1lll11_opy_, l11l11_opy_)
    response = doJSON(addon)
    l1l_opy_ = response[l11l1_opy_ (u"ࠬࡨ࡯ࡥࡻࠪઽ")]
    l1ll1ll_opy_  = l11l1_opy_ (u"࡛࠭ࠨા") + addon + l11l1_opy_ (u"ࠧ࡞࡞ࡱࠫિ")
    l1l11l_opy_  =  file(l1l11l1_opy_, l11l1_opy_ (u"ࠨࡹࠪી"))
    l1l11l_opy_.write(l1ll1ll_opy_)
    l1ll11l_opy_ = []
    for channel in l1l_opy_:
        category =  channel[l11l1_opy_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫુ")]
        l1l1111_opy_  = l11l1_opy_ (u"ࠪ࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮ࠢࠪૂ") + category + l11l1_opy_ (u"ࠫࠥ࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰ࡁࠬૃ")
        l1l11_opy_    =  channel[l11l1_opy_ (u"ࠬࡺࡩࡵ࡮ࡨࠫૄ")]
        l1111l_opy_ =  l1l1l1l_opy_(l1l11_opy_, category)
        if (l1111l_opy_ == l11l1_opy_ (u"࠭ࡔࡗࠢ࠶ࠤࡘࡋࠧૅ")) or (l1111l_opy_ == l11l1_opy_ (u"ࠧࡕࡘࠣ࠸࡙ࠥࡅࠨ૆")) or (l1111l_opy_ == l11l1_opy_ (u"ࠨࡖ࡙ࠤ࠸ࠦࡄࡌࠩે")) or (l1111l_opy_ == l11l1_opy_ (u"ࠩࡗ࡚ࠥ࠺ࠠࡅࡍࠪૈ")):
            stream   =  prefix + l1111l_opy_
        else:
            stream   =  prefix + l1l11_opy_
        l1lllll_opy_  =  l1111l_opy_ + l11l1_opy_ (u"ࠪࡁࠬૉ") + stream
        if l1l1111_opy_ not in l1ll11l_opy_:
            l1ll11l_opy_.append(l1l1111_opy_)
        if l1lllll_opy_ not in l1ll11l_opy_:
            l1ll11l_opy_.append(l1lllll_opy_)
    for item in l1ll11l_opy_:
        l1l11l_opy_.write(l11l1_opy_ (u"ࠦࠪࡹ࡜࡯ࠤ૊") % item)
    l1l11l_opy_.close()
def l1lll1l_opy_(Addon):
    l11l1111l_opy_ = Addon.getAddonInfo(l11l1_opy_ (u"ࠬࡴࡡ࡮ࡧࠪો"))
    l11l1111l_opy_ = l11l1111l_opy_.replace(l11l1_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡷࡩ࡫ࡷࡩࡢ࠭ૌ"), l11l1_opy_ (u"ࠧࠨ્")).replace(l11l1_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ૎"), l11l1_opy_ (u"ࠩࠪ૏"))
    if l11l1111l_opy_ == l11l1_opy_ (u"ࠪࡗࡒࡇࡒࡕࡊࡘࡆࠬૐ"):
        return l11l1_opy_ (u"ࠫࡍࡊࡔࡗ࠼ࠪ૑")
    if l11l1111l_opy_ == l11l1_opy_ (u"ࠬࡘࡵࡺࡣࠣࡍࡕ࡚ࡖࠨ૒"):
        return l11l1_opy_ (u"࠭ࡈࡅࡖ࡙࠶࠿࠭૓")
def l1l1l1l_opy_(l1l11_opy_, category):
    if (l1l11_opy_ == l11l1_opy_ (u"ࠧࡕࡘ࠶ࠫ૔")) and (category == l11l1_opy_ (u"ࠨࡕࡺࡩࡩ࡯ࡳࡩࠢࡊࡩࡳ࡫ࡲࡢ࡮ࠪ૕")):
        return l11l1_opy_ (u"ࠩࡗ࡚ࠥ࠹ࠠࡔࡇࠪ૖")
    if (l1l11_opy_ == l11l1_opy_ (u"ࠪࡘ࡛࠺ࠧ૗")) and (category == l11l1_opy_ (u"ࠫࡘࡽࡥࡥ࡫ࡶ࡬ࠥࡍࡥ࡯ࡧࡵࡥࡱ࠭૘")):
        return l11l1_opy_ (u"࡚ࠬࡖࠡ࠶ࠣࡗࡊ࠭૙")
    if (l1l11_opy_ == l11l1_opy_ (u"࠭ࡔࡗ࠵ࠪ૚")) and (category == l11l1_opy_ (u"ࠧࡅࡧࡱࡱࡦࡸ࡫ࠡࡉࡨࡲࡪࡸࡡ࡭ࠩ૛")):
        return l11l1_opy_ (u"ࠨࡖ࡙ࠤ࠸ࠦࡄࡌࠩ૜")
    if (l1l11_opy_ == l11l1_opy_ (u"ࠩࡗ࡚࠹࠭૝")) and (category == l11l1_opy_ (u"ࠪࡈࡪࡴ࡭ࡢࡴ࡮ࠤࡌ࡫࡮ࡦࡴࡤࡰࠬ૞")):
        return l11l1_opy_ (u"࡙ࠫ࡜ࠠ࠵ࠢࡇࡏࠬ૟")
    return dixie.mapChannelName(l1l11_opy_)
def getURL(url):
    if url.startswith(l11l1_opy_ (u"ࠬࡎࡄࡕࡘ࠽ࠫૠ")):
        addon = l11l11111_opy_
    else:
        addon = l111lllll_opy_
    Addon = xbmcaddon.Addon(id=addon)
    path  = Addon.getAddonInfo(l11l1_opy_ (u"࠭ࡰࡢࡶ࡫ࠫૡ"))
    sys.path.insert(0, path)
    import api
    api.login()
    channel   = url.split(l11l1_opy_ (u"ࠧ࠻ࠩૢ"), 1)[-1]
    l11l111ll_opy_ = l11l111l1_opy_(channel, addon)
    response  = api.remote_call( l11l1_opy_ (u"ࠣࡵࡷࡶࡪࡧ࡭࠰ࡩࡨࡸ࠳ࡶࡨࡱࠤૣ") , { l11l1_opy_ (u"ࠤࡷࠦ૤") : l11l1_opy_ (u"ࠥࡧ࡭ࡧ࡮࡯ࡧ࡯ࠦ૥") , l11l1_opy_ (u"ࠦ࡮ࡪࠢ૦") : l11l111ll_opy_ } )
    return response[l11l1_opy_ (u"ࠧࡨ࡯ࡥࡻࠥ૧")][l11l1_opy_ (u"ࠨࡵࡳ࡮ࠥ૨")]
def l11l111l1_opy_(channel, addon):
    PATH = l111llll1_opy_(addon)
    if os.path.exists(PATH):
        response = json.load(open(PATH))
    else:
        response = doJSON(addon)
    items = response[l11l1_opy_ (u"ࠢࡣࡱࡧࡽࠧ૩")]
    for item in items:
        if channel == l11l1_opy_ (u"ࠨࡖ࡙ࠤ࠸ࠦࡓࡆࠩ૪"):
            if (item[l11l1_opy_ (u"ࠤࡦࡥࡹ࡫ࡧࡰࡴࡼࠦ૫")] == l11l1_opy_ (u"ࠪࡗࡼ࡫ࡤࡪࡵ࡫ࠤࡌ࡫࡮ࡦࡴࡤࡰࠬ૬")) and (item[l11l1_opy_ (u"ࠦࡹ࡯ࡴ࡭ࡧࠥ૭")] == l11l1_opy_ (u"࡚ࠬࡖ࠴ࠩ૮")):
                return item[l11l1_opy_ (u"ࠨࡩࡥࠤ૯")]
        if channel == l11l1_opy_ (u"ࠧࡕࡘࠣ࠷ࠥࡊࡋࠨ૰"):
            if (item[l11l1_opy_ (u"ࠣࡥࡤࡸࡪ࡭࡯ࡳࡻࠥ૱")] == l11l1_opy_ (u"ࠩࡇࡩࡳࡳࡡࡳ࡭ࠣࡋࡪࡴࡥࡳࡣ࡯ࠫ૲")) and (item[l11l1_opy_ (u"ࠥࡸ࡮ࡺ࡬ࡦࠤ૳")] == l11l1_opy_ (u"࡙ࠫ࡜࠳ࠨ૴")):
                return item[l11l1_opy_ (u"ࠧ࡯ࡤࠣ૵")]
        if channel == l11l1_opy_ (u"࠭ࡔࡗࠢ࠷ࠤࡘࡋࠧ૶"):
            if (item[l11l1_opy_ (u"ࠢࡤࡣࡷࡩ࡬ࡵࡲࡺࠤ૷")] == l11l1_opy_ (u"ࠨࡕࡺࡩࡩ࡯ࡳࡩࠢࡊࡩࡳ࡫ࡲࡢ࡮ࠪ૸")) and (item[l11l1_opy_ (u"ࠤࡷ࡭ࡹࡲࡥࠣૹ")] == l11l1_opy_ (u"ࠪࡘ࡛࠺ࠧૺ")):
                return item[l11l1_opy_ (u"ࠦ࡮ࡪࠢૻ")]
        if channel == l11l1_opy_ (u"࡚ࠬࡖࠡ࠶ࠣࡈࡐ࠭ૼ"):
            if (item[l11l1_opy_ (u"ࠨࡣࡢࡶࡨ࡫ࡴࡸࡹࠣ૽")] == l11l1_opy_ (u"ࠧࡅࡧࡱࡱࡦࡸ࡫ࠡࡉࡨࡲࡪࡸࡡ࡭ࠩ૾")) and (item[l11l1_opy_ (u"ࠣࡶ࡬ࡸࡱ࡫ࠢ૿")] == l11l1_opy_ (u"ࠩࡗ࡚࠹࠭଀")):
                return item[l11l1_opy_ (u"ࠥ࡭ࡩࠨଁ")]
        if channel == item[l11l1_opy_ (u"ࠦࡹ࡯ࡴ࡭ࡧࠥଂ")]:
            return item[l11l1_opy_ (u"ࠧ࡯ࡤࠣଃ")]
def doJSON(addon):
    Addon = xbmcaddon.Addon(id=addon)
    path  = Addon.getAddonInfo(l11l1_opy_ (u"࠭ࡰࡢࡶ࡫ࠫ଄"))
    sys.path.insert(0, path)
    import api
    PATH    = l111llll1_opy_(addon)
    content = api.remote_call( l11l1_opy_ (u"ࠢࡤࡪࡤࡲࡳ࡫࡬ࡴ࠱࡯࡭ࡸࡺ࠮ࡱࡪࡳࠦଅ") , {l11l1_opy_ (u"ࠨࡣࠪଆ"): l11l1_opy_ (u"ࠩ࠳ࠫଇ"), l11l1_opy_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫଈ"): l11l1_opy_ (u"ࠫࡦࡲ࡬ࠨଉ")} )
    json.dump(content, open(PATH,l11l1_opy_ (u"ࠬࡽࠧଊ")), indent=3)
    return json.load(open(PATH))
if __name__ == l11l1_opy_ (u"࠭࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠨଋ"):
    checkAddons()