# coding: UTF-8
import sys
l11llll_opy_ = sys.version_info [0] == 2
l1llll1_opy_ = 2048
l1llll_opy_ = 7
def l11l11_opy_ (ll_opy_):
	global l1lllll_opy_
	l1l1111_opy_ = ord (ll_opy_ [-1])
	l1111l_opy_ = ll_opy_ [:-1]
	l1ll111_opy_ = l1l1111_opy_ % len (l1111l_opy_)
	l1l1l_opy_ = l1111l_opy_ [:l1ll111_opy_] + l1111l_opy_ [l1ll111_opy_:]
	if l11llll_opy_:
		l1ll1ll_opy_ = unicode () .join ([unichr (ord (char) - l1llll1_opy_ - (l11ll1_opy_ + l1l1111_opy_) % l1llll_opy_) for l11ll1_opy_, char in enumerate (l1l1l_opy_)])
	else:
		l1ll1ll_opy_ = str () .join ([chr (ord (char) - l1llll1_opy_ - (l11ll1_opy_ + l1l1111_opy_) % l1llll_opy_) for l11ll1_opy_, char in enumerate (l1l1l_opy_)])
	return eval (l1ll1ll_opy_)
import xbmc
import xbmcaddon
import json
import os
import dixie
l1l1l1111_opy_  = l11l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡜ࡹࡸࡥࡢ࡯ࡌࡔ࡙࡜ࠧू")
l1l11l1ll_opy_ = l11l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡺࡲࡦࡣࡰ࠱ࡨࡵࡤࡦࡵࠪृ")
l11l11l_opy_ = [l1l1l1111_opy_, l1l11l1ll_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l11l11_opy_ (u"࠭ࡩ࡯࡫ࠪॄ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1l11l1_opy_ = l11l11_opy_ (u"ࠧࠨॅ")
def l11l111_opy_(i, t1, l1l111l_opy_=[]):
 t = l1l11l1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l111l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1l11_opy_ = l11l111_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11ll_opy_ = l11l111_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l11l11l_opy_:
        if l11l1ll_opy_(addon):
            createINI(addon)
def l11l1ll_opy_(addon):
    if xbmc.getCondVisibility(l11l11_opy_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫࠩࡸ࠯ࠧॆ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l11_opy_ = str(addon).split(l11l11_opy_ (u"ࠩ࠱ࠫे"))[2] + l11l11_opy_ (u"ࠪ࠲࡮ࡴࡩࠨै")
    l1l_opy_  = os.path.join(PATH, l11_opy_)
    try:
        l1l1l1l_opy_ = l111lll_opy_(addon)
    except KeyError:
        dixie.log(l11l11_opy_ (u"ࠫ࠲࠳࠭࠮࠯ࠣࡏࡪࡿࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡩࡨࡸࡋ࡯࡬ࡦࡵࠣ࠱࠲࠳࠭࠮ࠢࠪॉ") + addon)
        result = {l11l11_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࡷࠬॊ"): [{l11l11_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩो"): l11l11_opy_ (u"ࡵࠨࡨ࡬ࡰࡪ࠭ौ"), l11l11_opy_ (u"ࡶࠩࡷࡽࡵ࡫्ࠧ"): l11l11_opy_ (u"ࡷࠪࡹࡳࡱ࡮ࡰࡹࡱࠫॎ"), l11l11_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࠩॏ"): l11l11_opy_ (u"ࡹࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸࡹࡺࠪॐ"), l11l11_opy_ (u"ࡺ࠭࡬ࡢࡤࡨࡰࠬ॑"): l11l11_opy_ (u"ࡻࠧࡏࡑࠣࡇࡍࡇࡎࡏࡇࡏࡗ॒ࠬ")}], l11l11_opy_ (u"ࡵࠨ࡮࡬ࡱ࡮ࡺࡳࠨ॓"):{l11l11_opy_ (u"ࡶࠩࡶࡸࡦࡸࡴࠨ॔"): 0, l11l11_opy_ (u"ࡷࠪࡸࡴࡺࡡ࡭ࠩॕ"): 1, l11l11_opy_ (u"ࡸࠫࡪࡴࡤࠨॖ"): 1}}
    l111l1_opy_  = l11l11_opy_ (u"ࠫࡠ࠭ॗ") + addon + l11l11_opy_ (u"ࠬࡣ࡜࡯ࠩक़")
    l1l1l11_opy_  = file(l1l_opy_, l11l11_opy_ (u"࠭ࡷࠨख़"))
    l1l1l11_opy_.write(l111l1_opy_)
    l1ll11_opy_ = []
    for channel in l1l1l1l_opy_:
        l11ll1l_opy_ = channel[l11l11_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ग़")].split(l11l11_opy_ (u"ࠨࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬज़"))[0]
        l11ll1l_opy_ = dixie.cleanLabel(l11ll1l_opy_)
        l1ll1_opy_ = dixie.mapChannelName(l11ll1l_opy_)
        stream   = channel[l11l11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧड़")]
        l11l1_opy_ = l1ll1_opy_ + l11l11_opy_ (u"ࠪࡁࠬढ़") + stream
        l1ll11_opy_.append(l11l1_opy_)
        l1ll11_opy_.sort()
    for item in l1ll11_opy_:
        l1l1l11_opy_.write(l11l11_opy_ (u"ࠦࠪࡹ࡜࡯ࠤफ़") % item)
    l1l1l11_opy_.close()
def l111lll_opy_(addon):
    login = l11l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠦࡵ࠲ࠫय़") % addon
    sendJSON(login, addon)
    if addon == l1l11l1ll_opy_:
        return l1_opy_(addon)
    if addon == l1l1l1111_opy_:
        l111111_opy_ = [l11l11_opy_ (u"࠭࠳ࠨॠ"), l11l11_opy_ (u"ࠧ࠵ࠩॡ"), l11l11_opy_ (u"ࠨ࠸ࠪॢ"), l11l11_opy_ (u"ࠩ࠺ࠫॣ"), l11l11_opy_ (u"ࠪ࠼ࠬ।"), l11l11_opy_ (u"ࠫ࠶࠷ࠧ॥"), l11l11_opy_ (u"ࠬ࠷࠲ࠨ०"), l11l11_opy_ (u"࠭࠱࠵ࠩ१"), l11l11_opy_ (u"ࠧ࠲࠷ࠪ२"), l11l11_opy_ (u"ࠨ࠵࠶ࠫ३"), l11l11_opy_ (u"ࠩ࠼࠵ࠬ४"), l11l11_opy_ (u"ࠪ࠽࠷࠭५")]
    l11111_opy_ = []
    for l111l1l_opy_ in l111111_opy_:
        if addon == l1l1l1111_opy_:
            query = l11l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴ࠱ࡂࡥࡨࡺࡩࡰࡰࡀࡷࡹࡸࡥࡢ࡯ࡢࡺ࡮ࡪࡥࡰࠨࡨࡼࡹࡸࡡࠧࡲࡤ࡫ࡪࠬࡰ࡭ࡱࡷࠪࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠽ࠧࡶ࡬ࡸࡱ࡫࠽ࠧࡷࡵࡰࡂࠫࡳࠨ६") % (addon, l111l1l_opy_)
        response = sendJSON(query, addon)
        l11111_opy_.extend(response)
    return l11111_opy_
def l1_opy_(addon):
    query = l1l1l111l_opy_(addon)
    return sendJSON(query, addon)
def l1l1l111l_opy_(addon):
    Addon = xbmcaddon.Addon(addon)
    l1l1l11l1_opy_  = Addon.getSetting(l11l11_opy_ (u"ࠬࡲࡥࡩࡧ࡮ࡽࡱ࡭ࠧ७"))
    l1l11ll11_opy_ = Addon.getSetting(l11l11_opy_ (u"࠭ࡰࡰࡴࡧ࡭ࡳࡻ࡭ࡣࡧࡵࠫ८"))
    l1l11lll1_opy_ = Addon.getSetting(l11l11_opy_ (u"ࠧ࡬ࡣࡶࡹࡹࡧࡪࡢࡰ࡬ࡱ࡮࠭९"))
    l1l1l11ll_opy_ = Addon.getSetting(l11l11_opy_ (u"ࠨࡵࡤࡰࡦࡹ࡯࡯ࡣࠪ॰"))
    return l1l11ll1l_opy_(addon, l1l1l11l1_opy_, l1l11ll11_opy_, l1l11lll1_opy_, l1l1l11ll_opy_)
def l1l11ll1l_opy_(addon, l1l1l11l1_opy_, l1l11ll11_opy_, l1l11lll1_opy_, l1l1l11ll_opy_):
    l1l11llll_opy_  = l11l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬॱ")
    l1l11llll_opy_ +=  addon
    l1l11llll_opy_ += l11l11_opy_ (u"ࠪ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡹࡴࡳࡧࡤࡱࡤࡼࡩࡥࡧࡲࠪࡪࡾࡴࡳࡣࠩࡴࡦ࡭ࡥࠧࡲ࡯ࡳࡹࠬࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠿ࠩࡸ࡮ࡺ࡬ࡦ࠿ࡄࡰࡱࠬࡵࡳ࡮ࡀࠫॲ")
    params  =  l1l1l11l1_opy_
    params += l11l11_opy_ (u"ࠫ࠿࠭ॳ") + l1l11ll11_opy_
    params += l11l11_opy_ (u"ࠬ࠵ࡥ࡯࡫ࡪࡱࡦ࠸࠮ࡱࡪࡳࡃࡺࡹࡥࡳࡰࡤࡱࡪࡃࠧॴ")
    params +=  l1l11lll1_opy_
    params += l11l11_opy_ (u"࠭ࠦࡱࡣࡶࡷࡼࡵࡲࡥ࠿ࠪॵ")
    params +=  l1l1l11ll_opy_
    params += l11l11_opy_ (u"ࠧࠧࡶࡼࡴࡪࡃࡧࡦࡶࡢࡰ࡮ࡼࡥࡠࡵࡷࡶࡪࡧ࡭ࡴࠨࡦࡥࡹࡥࡩࡥ࠿࠳ࠫॶ")
    import urllib
    params = urllib.quote_plus(params)
    url = l1l11llll_opy_ + params
    return url
def login(addon):
    login = l11l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸ࠵ࠧॷ") % addon
    sendJSON(login, addon)
def sendJSON(query, addon):
    l1111ll_opy_     = l11l11_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬॸ") % query
    l111ll1_opy_  = xbmc.executeJSONRPC(l1111ll_opy_)
    response = json.loads(l111ll1_opy_)
    result   = response[l11l11_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪॹ")]
    return result[l11l11_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪॺ")]
def l1111_opy_():
    modules = map(__import__, [l11l111_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1l11_opy_)):
        return l11l11_opy_ (u"࡚ࠬࡲࡶࡧࠪॻ")
    if len(modules[-1].Window(10**4).getProperty(l11ll_opy_)):
        return l11l11_opy_ (u"࠭ࡔࡳࡷࡨࠫॼ")
    return l11l11_opy_ (u"ࠧࡇࡣ࡯ࡷࡪ࠭ॽ")
def l1l1ll1_opy_(e, addon):
    l1l111_opy_ = l11l11_opy_ (u"ࠨࡕࡲࡶࡷࡿࠬࠡࡣࡱࠤࡪࡸࡲࡰࡴࠣࡳࡨࡩࡵࡳࡧࡧ࠾ࠥࡐࡓࡐࡐࠣࡉࡷࡸ࡯ࡳ࠼ࠣࠩࡸ࠲ࠠࠦࡵࠪॾ")  % (e, addon)
    l111l_opy_ = l11l11_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡹࡸࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡦࡰࡴࡸࡱ࠳࠭ॿ")
    l1l1l1_opy_ = l11l11_opy_ (u"࡙ࠪࡵࡲ࡯ࡢࡦࠣࡥࠥࡲ࡯ࡨࠢࡹ࡭ࡦࠦࡴࡩࡧࠣࡥࡩࡪ࡯࡯ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠤࡦࡴࡤࠡࡲࡲࡷࡹࠦࡴࡩࡧࠣࡰ࡮ࡴ࡫࠯ࠩঀ")
    dixie.log(addon)
    dixie.log(e)
if __name__ == l11l11_opy_ (u"ࠫࡤࡥ࡭ࡢ࡫ࡱࡣࡤ࠭ঁ"):
    checkAddons()