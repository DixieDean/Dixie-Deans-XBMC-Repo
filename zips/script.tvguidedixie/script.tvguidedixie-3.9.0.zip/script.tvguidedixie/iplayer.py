# coding: UTF-8
import sys
l11lll1_opy_ = sys.version_info [0] == 2
l1llll1_opy_ = 2048
l1llll_opy_ = 7
def l11l11_opy_ (ll_opy_):
	global l1lllll_opy_
	l11llll_opy_ = ord (ll_opy_ [-1])
	l1111l_opy_ = ll_opy_ [:-1]
	l1l1lll_opy_ = l11llll_opy_ % len (l1111l_opy_)
	l1l1l_opy_ = l1111l_opy_ [:l1l1lll_opy_] + l1111l_opy_ [l1l1lll_opy_:]
	if l11lll1_opy_:
		l1ll1l1_opy_ = unicode () .join ([unichr (ord (char) - l1llll1_opy_ - (l11ll1_opy_ + l11llll_opy_) % l1llll_opy_) for l11ll1_opy_, char in enumerate (l1l1l_opy_)])
	else:
		l1ll1l1_opy_ = str () .join ([chr (ord (char) - l1llll1_opy_ - (l11ll1_opy_ + l11llll_opy_) % l1llll_opy_) for l11ll1_opy_, char in enumerate (l1l1l_opy_)])
	return eval (l1ll1l1_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
ADDON    = dixie.ADDON
l1l11l_opy_ = dixie.PROFILE
l1l1ll1_opy_  = os.path.join(l1l11l_opy_, l11l11_opy_ (u"ࠫ࡮ࡴࡩࠨࠀ"))
l1l111l_opy_ = l11l11_opy_ (u"ࠬ࠭ࠁ")
def l11l111_opy_(i, t1, l1l1111_opy_=[]):
 t = l1l111l_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l1111_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1l11_opy_ = l11l111_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11_opy_ = l11l111_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1ll11l_opy_ = l11l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡌ࡬ࡢࡹ࡯ࡩࡸࡹࡔࡷࠩࠂ")
dexter   = l11l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡤࡦࡺࠪࠃ")
l11l11l_opy_   = [l1ll11l_opy_, dexter]
l1ll1ll_opy_ = os.path.join(dixie.PROFILE, l11l11_opy_ (u"ࠨࡦࡷࡩࡲࡶࠧࠄ"))
if os.path.exists(l1ll1ll_opy_):
    os.remove(l1ll1ll_opy_)
l11l1l_opy_ = os.path.join(dixie.PROFILE, l11l11_opy_ (u"ࠩࡩࡸࡪࡳࡰࠨࠅ"))
if os.path.exists(l11l1l_opy_):
    os.remove(l11l1l_opy_)
l1ll_opy_ = os.path.join(l1l1ll1_opy_, l11l11_opy_ (u"ࠪࡨࡪࡾࡴࡦࡴ࠱࡭ࡳ࡯ࠧࠆ"))
if os.path.exists(l1ll_opy_):
    os.remove(l1ll_opy_)
def checkAddons():
    for addon in l11l11l_opy_:
        if l11l1ll_opy_(addon):
            createINI(addon)
def l11l1ll_opy_(addon):
    if xbmc.getCondVisibility(l11l11_opy_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡍࡧࡳࡂࡦࡧࡳࡳ࠮ࠥࡴࠫࠪࠇ") % addon) == 1:
        return True
    else:
        return False
def createINI(addon):
    HOME  = dixie.PROFILE
    l1l1ll_opy_ = os.path.join(HOME, l11l11_opy_ (u"ࠬ࡯࡮ࡪࠩࠈ"))
    l1lll1l_opy_  = str(addon).split(l11l11_opy_ (u"࠭࠮ࠨࠉ"))[2] + l11l11_opy_ (u"ࠧ࠯࡫ࡱ࡭ࠬࠊ")
    l1l_opy_   = os.path.join(l1l1ll_opy_, l1lll1l_opy_)
    response = l1_opy_(addon)
    l1l1l11_opy_ = response[l11l11_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨࠋ")][l11l11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨࠌ")]
    l111l1_opy_  = l11l11_opy_ (u"ࠪ࡟ࠬࠍ") + addon + l11l11_opy_ (u"ࠫࡢࡢ࡮ࠨࠎ")
    l1l11ll_opy_  =  file(l1l_opy_, l11l11_opy_ (u"ࠬࡽࠧࠏ"))
    l1l11ll_opy_.write(l111l1_opy_)
    l1ll11_opy_ = []
    for channel in l1l1l11_opy_:
        l11ll11_opy_ = l11ll_opy_(addon, channel)
        l1ll111_opy_ = l11ll11_opy_
        l1ll1l_opy_ = l11ll1l_opy_(addon)
        l1ll1_opy_  = dixie.mapChannelName(l11ll11_opy_)
        stream    = l1ll1l_opy_ + l1ll111_opy_
        l11l1_opy_   = l1ll1_opy_ + l11l11_opy_ (u"࠭࠽ࠨࠐ") + stream
        if l11l1_opy_ not in l1ll11_opy_:
            l1ll11_opy_.append(l11l1_opy_)
    l1ll11_opy_.sort()
    for item in l1ll11_opy_:
        l1l11ll_opy_.write(l11l11_opy_ (u"ࠢࠦࡵ࡟ࡲࠧࠑ") % item)
    l1l11ll_opy_.close()
def l11ll_opy_(addon, file):
    l11lll_opy_ = file[l11l11_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࠒ")].split(l11l11_opy_ (u"ࠩࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠓ"))[0]
    l11lll_opy_ = dixie.cleanLabel(l11lll_opy_)
    return l11lll_opy_.split(l11l11_opy_ (u"ࠪࠤ࠰࠭ࠔ"))[0]
def l11ll1l_opy_(addon):
    if addon == l1ll11l_opy_:
        return l11l11_opy_ (u"ࠫࡋࡒࡁ࠻ࠩࠕ")
    if addon == dexter:
        return l11l11_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡈ࠿࠭ࠖ")
def getURL(url):
    if url.startswith(l11l11_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡈࡒࡕ࠻ࠩࠗ")):
        url = url.replace(l11l11_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡉࡌࡖ࠼ࠪ࠘"), l11l11_opy_ (u"ࠨࠩ࠙")).replace(l11l11_opy_ (u"ࠩ࠰࠱ࡺࡹࡥࡳ࠯ࡤ࡫ࡪࡴࡴࠨࠚ"), l11l11_opy_ (u"ࠪࢀࡺࡹࡥࡳ࠯ࡤ࡫ࡪࡴࡴࠨࠛ"))
        return url
    if url.startswith(l11l11_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡇࠫࠜ")):
        return l1l1_opy_(url, dexter)
    if url.startswith(l11l11_opy_ (u"ࠬࡌࡌࡂࠩࠝ")):
        return l1l1_opy_(url, l1ll11l_opy_)
    response = l11l_opy_(url)
    stream   = url.split(l11l11_opy_ (u"࠭࠺ࠨࠞ"), 1)[-1]
    try:
        result = response[l11l11_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧࠟ")]
        l11111_opy_  = result[l11l11_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧࠠ")]
    except Exception as e:
        l1l1l1l_opy_(e)
        return None
    for file in l11111_opy_:
        l11lll_opy_ = file[l11l11_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨࠡ")]
        if stream in l11lll_opy_:
            return file[l11l11_opy_ (u"ࠪࡪ࡮ࡲࡥࠨࠢ")]
    return None
def l1l1_opy_(url, addon):
    PATH = l1lll_opy_(addon)
    if os.path.exists(PATH):
        response = json.load(open(PATH))
    else:
        response = l1_opy_(addon)
    l1lll11_opy_ = url.split(l11l11_opy_ (u"ࠫ࠿࠭ࠣ"))[0]
    l11l1l1_opy_     = url.split(l11l11_opy_ (u"ࠬࡀࠧࠤ"), 1)[-1]
    stream   = l11l1l1_opy_.split(l11l11_opy_ (u"࠭ࠠ࡜ࠩࠥ"), 1)[0]
    stream   = dixie.cleanLabel(stream)
    l11111_opy_  = response[l11l11_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧࠦ")][l11l11_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧࠧ")]
    for file in l11111_opy_:
        l11lll_opy_ = l11ll_opy_(addon, file)
        if stream in l11lll_opy_:
            l111_opy_ = file[l11l11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧࠨ")]
            if l1lll11_opy_ == l11l11_opy_ (u"ࠪࡊࡑࡇࡓࠨࠩ"):
                return l111_opy_
            l111_opy_ = l111_opy_.replace(l11l11_opy_ (u"ࠫ࠳ࡺࡳࠨࠪ"), l11l11_opy_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫࠫ"))
            return l111_opy_
def l1_opy_(addon):
    if addon == l1ll11l_opy_:
        query = l11l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡇ࡮ࡤࡻࡱ࡫ࡳࡴࡖࡹ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡹࡴࡳࡧࡤࡱࡤࡼࡩࡥࡧࡲࠪࡪࡾࡴࡳࡣࠩࡴࡦ࡭ࡥࠧࡲ࡯ࡳࡹࠬࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠿ࠩࡸ࡮ࡺ࡬ࡦ࠿ࡄࡰࡱࠬࡵࡳ࡮ࡀ࠴ࠬࠬ")
        content = doJSON(query)
        return l111ll_opy_(addon, content)
    if addon == dexter:
        query   = l1lll1_opy_(dexter)
        content = doJSON(query)
        return l111ll_opy_(dexter, content)
def l111ll_opy_(addon, content):
    PATH  = l1lll_opy_(addon)
    json.dump(content, open(PATH,l11l11_opy_ (u"ࠧࡸࠩ࠭")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    l1l11l1_opy_  = (l11l11_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫ࠮") % query)
    response = xbmc.executeJSONRPC(l1l11l1_opy_)
    content  = json.loads(response)
    return content
def l1lll_opy_(addon):
    if addon == l1ll11l_opy_:
        return os.path.join(dixie.PROFILE, l11l11_opy_ (u"ࠩࡩࡸࡪࡳࡰࠨ࠯"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l11l11_opy_ (u"ࠪࡨࡹ࡫࡭ࡱࠩ࠰"))
def l1lll1_opy_(addon):
    if addon == dexter:
        query = l11l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡪࡥࡹࠩ࠱")
        response = doJSON(query)
        l11111_opy_    = response[l11l11_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬ࠲")][l11l11_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬ࠳")]
        for file in l11111_opy_:
            l11lll_opy_ = file[l11l11_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭࠴")]
            if l11lll_opy_ == l11l11_opy_ (u"ࠨࡃ࡯ࡰࠬ࠵"):
                login = file[l11l11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧ࠶")]
                return login
def l11l_opy_(url):
    if url.startswith(l11l11_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠼ࠪ࠷")):
        l1l11l1_opy_ = (l11l11_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡣࡤࡦ࡭ࡵࡲࡡࡺࡧࡵ࠳ࡄࡻࡲ࡭࠿ࡸࡶࡱࠬ࡭ࡰࡦࡨࡁ࠷ࠬ࡮ࡢ࡯ࡨࡁࡑ࡯ࡶࡦࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࡁࠫࡏࡐࡊࡆࡀࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ࠸"))
    if url.startswith(l11l11_opy_ (u"ࠬࡏࡐࡍࡃ࡜࠶࠿࠭࠹")):
        l1l11l1_opy_ = (l11l11_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠵࠿ࡶࡴ࡯ࡁࡺࡸ࡬ࠧ࡯ࡲࡨࡪࡃ࠱࠱࠳ࠩࡲࡦࡳࡥ࠾࡙ࡤࡸࡨ࡮ࠫࡍ࡫ࡹࡩࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴ࠽ࠧࡵࡸࡦࡹ࡯ࡴ࡭ࡧࡶࡣࡺࡸ࡬࠾ࠨ࡯ࡳ࡬࡭ࡥࡥࡡ࡬ࡲࡂࡌࡡ࡭ࡵࡨࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ࠺"))
    if url.startswith(l11l11_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡘ࠺ࠨ࠻")):
        l1l11l1_opy_ = (l11l11_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶ࡬ࡢࡻࡨࡶࡼࡽࡷ࠰ࡁࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠦ࡭ࡱࡪ࡫ࡪࡪ࡟ࡪࡰࡀࡊࡦࡲࡳࡦࠨࡰࡳࡩ࡫࠽࠲࠳࠶ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡸࡺࡥ࡯ࠧ࠵࠴ࡑ࡯ࡶࡦࠨࡶࡹࡧࡺࡩࡵ࡮ࡨࡷࡤࡻࡲ࡭ࠨࡸࡶࡱࡃࡵࡳ࡮ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ࠼"))
    if url.startswith(l11l11_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡊࡖ࡙࠾ࠬ࠽")):
        l1l11l1_opy_ = (l11l11_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡵࡸࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ࠾"))
    if url.startswith(l11l11_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡇ࠾ࠬ࠿")):
        l1l11l1_opy_ = (l11l11_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡦࡨࡼ࠴ࡅࡡࡤࡶ࡬ࡳࡳࡃࡡ࡭࡮ࠩࡩࡽࡺࡲࡢࠨࡳࡥ࡬࡫ࠦࡱ࡮ࡲࡸࠫࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠾ࠨࡷ࡭ࡹࡲࡥ࠾ࠧ࠸ࡦࡈࡕࡌࡐࡔࠨ࠶࠵ࡽࡨࡪࡶࡨࠩ࠺ࡪࡁ࡭࡮ࠨ࠶࠵ࡉࡨࡢࡰࡱࡩࡱࡹࠥ࠶ࡤࠨ࠶࡫ࡉࡏࡍࡑࡕࠩ࠺ࡪࠦࡶࡴ࡯ࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩࡀ"))
    if url.startswith(l11l11_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡗࡈ࠺ࠨࡁ")):
        l1l11l1_opy_ = (l11l11_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡪࡨ࡯ࡰࡶ࠲ࡃࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠨࡩࡥࡳࡧࡲࡵ࠿ࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦ࡮ࡱࡧࡩࡂ࠽ࠦࡱ࡫࡯ࡰࡴࡽ࠽ࡍ࡫ࡹࡩࠪ࠸࠰ࡔࡶࡵࡩࡦࡳࡳࠧࡷࡵࡰࡂࡸࡡ࡯ࡦࡲࡱࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࡂ"))
    if url.startswith(l11l11_opy_ (u"ࠨࡋࡓࡘࡘࡀࠧࡃ")):
        l1l11l1_opy_ = (l11l11_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡵࡺࡣ࡬ࡴࡹࡼ࠯ࡀࡣࡦࡸ࡮ࡵ࡮࠾࡮࡬ࡺࡪࡺࡶࡠࡣ࡯ࡰࠫ࡫ࡸࡵࡴࡤࠪࡵࡧࡧࡦࠨࡳࡰࡴࡺࠦࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡀࠪࡹ࡯ࡴ࡭ࡧࡀࡅࡱࡲࠥ࠳࠲ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪࡺࡸ࡬ࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ࡄ"))
    try:
        dixie.ShowBusy()
        addon =  l1l11l1_opy_.split(l11l11_opy_ (u"ࠪ࠳࠴࠭ࡅ"), 1)[-1].split(l11l11_opy_ (u"ࠫ࠴࠭ࡆ"), 1)[0]
        login = l11l11_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࡇ") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1l11l1_opy_)
        dixie.log(response)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1l1l1l_opy_(e)
        return {l11l11_opy_ (u"࠭ࡅࡳࡴࡲࡶࠬࡈ") : l11l11_opy_ (u"ࠧࡑ࡮ࡸ࡫࡮ࡴࠠࡆࡴࡵࡳࡷ࠭ࡉ")}
def l1111_opy_():
    modules = map(__import__, [l11l111_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1l11_opy_)):
        return l11l11_opy_ (u"ࠨࡖࡵࡹࡪ࠭ࡊ")
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l11l11_opy_ (u"ࠩࡗࡶࡺ࡫ࠧࡋ")
    return l11l11_opy_ (u"ࠪࡊࡦࡲࡳࡦࠩࡌ")
def l1l1l1l_opy_(e):
    l1l111_opy_ = l11l11_opy_ (u"ࠫࡘࡵࡲࡳࡻ࠯ࠤࡦࡴࠠࡦࡴࡵࡳࡷࠦ࡯ࡤࡥࡸࡶࡪࡪ࠺ࠡࡌࡖࡓࡓࠦࡅࡳࡴࡲࡶ࠿ࠦࠥࡴࠩࡍ")  %e
    l111l_opy_ = l11l11_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡸࡥ࠮࡮࡬ࡲࡰࠦࡴࡩ࡫ࡶࠤࡨ࡮ࡡ࡯ࡰࡨࡰࠥࡧ࡮ࡥࠢࡷࡶࡾࠦࡡࡨࡣ࡬ࡲ࠳࠭ࡎ")
    l1l1l1_opy_ = l11l11_opy_ (u"࠭ࡕࡴࡧ࠽ࠤࡈࡵ࡮ࡵࡧࡻࡸࠥࡓࡥ࡯ࡷࠣࡁࡃࠦࡒࡦ࡯ࡲࡺࡪࠦࡓࡵࡴࡨࡥࡲ࠭ࡏ")
    dixie.log(e)
    dixie.DialogOK(l1l111_opy_, l111l_opy_, l1l1l1_opy_)
if __name__ == l11l11_opy_ (u"ࠧࡠࡡࡰࡥ࡮ࡴ࡟ࡠࠩࡐ"):
    checkAddons()