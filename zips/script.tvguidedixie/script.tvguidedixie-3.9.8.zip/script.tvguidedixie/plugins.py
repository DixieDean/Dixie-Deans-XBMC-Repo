# coding: UTF-8
import sys
l111l1l_opy_ = sys.version_info [0] == 2
l1ll111_opy_ = 2048
l1lll1_opy_ = 7
def l1111l_opy_ (ll_opy_):
	global l11l_opy_
	l111ll1_opy_ = ord (ll_opy_ [-1])
	l1ll1ll_opy_ = ll_opy_ [:-1]
	l1l1111_opy_ = l111ll1_opy_ % len (l1ll1ll_opy_)
	l1ll1_opy_ = l1ll1ll_opy_ [:l1l1111_opy_] + l1ll1ll_opy_ [l1l1111_opy_:]
	if l111l1l_opy_:
		l1l1ll1_opy_ = unicode () .join ([unichr (ord (char) - l1ll111_opy_ - (l11l11_opy_ + l111ll1_opy_) % l1lll1_opy_) for l11l11_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1l1ll1_opy_ = str () .join ([chr (ord (char) - l1ll111_opy_ - (l11l11_opy_ + l111ll1_opy_) % l1lll1_opy_) for l11l11_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1l1ll1_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l1l111l11_opy_     = l1111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡴࡴࡷࠩࣷ")
l11llllll_opy_  = l1111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡷ࡭࡫ࡳࡸࡻ࠭ࣸ")
l1l11llll_opy_     = l1111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡶ࡭ࡷࡹࡷࡱࣹࠧ")
locked  = l1111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮ࡲࡧࡰ࡫ࡤࡵࡸࣺࠪ")
l11lll1ll_opy_      = l1111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸࡰࡹ࡯࡭ࡢࡶࡨࡱࡦࡴࡩࡢࠩࣻ")
l11llll1l_opy_    = l1111l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰ࡮ࡻࡸ࠯ࡶࡹࠫࣼ")
l1l11111l_opy_     = l1111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡉࡉࡓࡱࡱࡵࡸࡸ࠭ࣽ")
l1l11lll1_opy_  = l1111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡥࡣࡱࡲࡸࠬࣾ")
l1l1111l1_opy_     = l1111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡣ࡭ࡷ࡬ࡴࡹࡼࠧࣿ")
l1l11ll1l_opy_ = l1111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡶ࡭ࡷࡺ࠹࡫ࡸࡱࡣࡷࡷ࠳ࡩ࡯࡮ࠩऀ")
l111111_opy_ = [l1l111l11_opy_, locked, l11llll1l_opy_, l11llllll_opy_, l1l11ll1l_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1111l_opy_ (u"ࠩ࡬ࡲ࡮࠭ँ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l11l11l_opy_ = l1111l_opy_ (u"ࠪࠫं")
def l1llllll_opy_(i, t1, l11l111_opy_=[]):
 t = l11l11l_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l11l111_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1l11_opy_ = l1llllll_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11ll_opy_ = l1llllll_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l111111_opy_:
        if l1111l1_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1111l1_opy_(addon):
    if xbmc.getCondVisibility(l1111l_opy_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡍࡧࡳࡂࡦࡧࡳࡳ࠮ࠥࡴࠫࠪः") % addon) == 1:
        return True
    return False
def createINI(addon):
    l1l1l11_opy_ = str(addon).split(l1111l_opy_ (u"ࠬ࠴ࠧऄ"))[2] + l1111l_opy_ (u"࠭࠮ࡪࡰ࡬ࠫअ")
    l1l_opy_  = os.path.join(PATH, l1l1l11_opy_)
    try:
        l11111_opy_ = l1_opy_(addon)
    except KeyError:
        dixie.log(l1111l_opy_ (u"ࠧ࠮࠯࠰࠱࠲ࠦࡋࡦࡻࡈࡶࡷࡵࡲࠡ࡫ࡱࠤ࡬࡫ࡴࡇ࡫࡯ࡩࡸࠦ࠭࠮࠯࠰࠱ࠥ࠭आ") + addon)
        result = {l1111l_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࡳࠨइ"): [{l1111l_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬई"): l1111l_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࠩउ"), l1111l_opy_ (u"ࡹࠬࡺࡹࡱࡧࠪऊ"): l1111l_opy_ (u"ࡺ࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧऋ"), l1111l_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࠬऌ"): l1111l_opy_ (u"ࡵࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡼࡽ࠭ऍ"), l1111l_opy_ (u"ࡶࠩ࡯ࡥࡧ࡫࡬ࠨऎ"): l1111l_opy_ (u"ࡷࠪࡒࡔࠦࡃࡉࡃࡑࡒࡊࡒࡓࠨए")}], l1111l_opy_ (u"ࡸࠫࡱ࡯࡭ࡪࡶࡶࠫऐ"):{l1111l_opy_ (u"ࡹࠬࡹࡴࡢࡴࡷࠫऑ"): 0, l1111l_opy_ (u"ࡺ࠭ࡴࡰࡶࡤࡰࠬऒ"): 1, l1111l_opy_ (u"ࡻࠧࡦࡰࡧࠫओ"): 1}}
    l1lll1l_opy_  = l1111l_opy_ (u"ࠧ࡜ࠩऔ") + addon + l1111l_opy_ (u"ࠨ࡟࡟ࡲࠬक")
    l11ll11_opy_  =  file(l1l_opy_, l1111l_opy_ (u"ࠩࡺࠫख"))
    l11ll11_opy_.write(l1lll1l_opy_)
    l1l1l1_opy_ = []
    for channel in l11111_opy_:
        l1l1l111l_opy_ = cleanLabel(channel[l1111l_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩग")])
        l1111ll_opy_   = dixie.cleanPrefix(l1l1l111l_opy_)
        l1lll_opy_ = dixie.mapChannelName(l1111ll_opy_)
        stream   = channel[l1111l_opy_ (u"ࠫ࡫࡯࡬ࡦࠩघ")]
        l11l1_opy_ = l1lll_opy_ + l1111l_opy_ (u"ࠬࡃࠧङ") + stream
        l1l1l1_opy_.append(l11l1_opy_)
        l1l1l1_opy_.sort()
    for item in l1l1l1_opy_:
        l11ll11_opy_.write(l1111l_opy_ (u"ࠨࠥࡴ࡞ࡱࠦच") % item)
    l11ll11_opy_.close()
def l1_opy_(addon):
    if (addon == l1l111l11_opy_) or (addon == l11llllll_opy_):
        if xbmcaddon.Addon(addon).getSetting(l1111l_opy_ (u"ࠧࡨࡧࡱࡶࡪ࠭छ")) == l1111l_opy_ (u"ࠨࡶࡵࡹࡪ࠭ज"):
            xbmcaddon.Addon(addon).setSetting(l1111l_opy_ (u"ࠩࡪࡩࡳࡸࡥࠨझ"), l1111l_opy_ (u"ࠪࡪࡦࡲࡳࡦࠩञ"))
            xbmcgui.Window(10000).setProperty(l1111l_opy_ (u"ࠫࡕࡒࡕࡈࡋࡑࡣࡌࡋࡎࡓࡇࠪट"), l1111l_opy_ (u"࡚ࠬࡲࡶࡧࠪठ"))
        if xbmcaddon.Addon(addon).getSetting(l1111l_opy_ (u"࠭ࡴࡷࡩࡸ࡭ࡩ࡫ࠧड")) == l1111l_opy_ (u"ࠧࡵࡴࡸࡩࠬढ"):
            xbmcaddon.Addon(addon).setSetting(l1111l_opy_ (u"ࠨࡶࡹ࡫ࡺ࡯ࡤࡦࠩण"), l1111l_opy_ (u"ࠩࡩࡥࡱࡹࡥࠨत"))
            xbmcgui.Window(10000).setProperty(l1111l_opy_ (u"ࠪࡔࡑ࡛ࡇࡊࡐࡢࡘ࡛ࡍࡕࡊࡆࡈࠫथ"), l1111l_opy_ (u"࡙ࠫࡸࡵࡦࠩद"))
        l11lllll1_opy_  = l1111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨध") + addon
        l1l11l1ll_opy_ =  l1l1l11l1_opy_(addon)
        query   =  l11lllll1_opy_ + l1l11l1ll_opy_
        return sendJSON(query, addon)
    return l1l111lll_opy_(addon)
def l1l111lll_opy_(addon):
    if addon == l1l11ll1l_opy_:
        l1l11l111_opy_ = [l1111l_opy_ (u"࠭࠱࠷࠳ࠪन"), l1111l_opy_ (u"ࠧ࠲࠸࠳ࠫऩ"), l1111l_opy_ (u"ࠨ࠴࠶࠺ࠬप"), l1111l_opy_ (u"ࠩ࠵࠸࠷࠭फ"), l1111l_opy_ (u"ࠪ࠵࠺࠾ࠧब"), l1111l_opy_ (u"ࠫ࠶࠻࠹ࠨभ")]
    if addon == l11llll1l_opy_:
        l1l11l111_opy_ = [l1111l_opy_ (u"ࠬ࠻ࠧम"), l1111l_opy_ (u"࠭࠱࠱࠸ࠪय"), l1111l_opy_ (u"ࠧ࠵ࠩर"), l1111l_opy_ (u"ࠨ࠴࠹࠷ࠬऱ"), l1111l_opy_ (u"ࠩ࠴࠷࠷࠭ल")]
    if addon == locked:
        l1l11l111_opy_ = [l1111l_opy_ (u"ࠪ࠷࠵࠭ळ"), l1111l_opy_ (u"ࠫ࠸࠷ࠧऴ"), l1111l_opy_ (u"ࠬ࠹࠲ࠨव"), l1111l_opy_ (u"࠭࠳࠴ࠩश"), l1111l_opy_ (u"ࠧ࠴࠶ࠪष"), l1111l_opy_ (u"ࠨ࠵࠸ࠫस"), l1111l_opy_ (u"ࠩ࠶࠼ࠬह"), l1111l_opy_ (u"ࠪ࠸࠵࠭ऺ"), l1111l_opy_ (u"ࠫ࠹࠷ࠧऻ"), l1111l_opy_ (u"ࠬ࠺࠵ࠨ़"), l1111l_opy_ (u"࠭࠴࠸ࠩऽ"), l1111l_opy_ (u"ࠧ࠵࠻ࠪा"), l1111l_opy_ (u"ࠨ࠷࠵ࠫि")]
    if addon == l11lll1ll_opy_:
        l1l11l111_opy_ = [l1111l_opy_ (u"ࠩ࠵࠹ࠬी"), l1111l_opy_ (u"ࠪ࠶࠻࠭ु"), l1111l_opy_ (u"ࠫ࠷࠽ࠧू"), l1111l_opy_ (u"ࠬ࠸࠹ࠨृ"), l1111l_opy_ (u"࠭࠳࠱ࠩॄ"), l1111l_opy_ (u"ࠧ࠴࠳ࠪॅ"), l1111l_opy_ (u"ࠨ࠵࠵ࠫॆ"), l1111l_opy_ (u"ࠩ࠶࠹ࠬे"), l1111l_opy_ (u"ࠪ࠷࠻࠭ै"), l1111l_opy_ (u"ࠫ࠸࠽ࠧॉ"), l1111l_opy_ (u"ࠬ࠹࠸ࠨॊ"), l1111l_opy_ (u"࠭࠳࠺ࠩो"), l1111l_opy_ (u"ࠧ࠵࠲ࠪौ"), l1111l_opy_ (u"ࠨ࠶࠴्ࠫ"), l1111l_opy_ (u"ࠩ࠷࠼ࠬॎ"), l1111l_opy_ (u"ࠪ࠸࠾࠭ॏ"), l1111l_opy_ (u"ࠫ࠺࠶ࠧॐ"), l1111l_opy_ (u"ࠬ࠻࠲ࠨ॑"), l1111l_opy_ (u"࠭࠵࠵॒ࠩ"), l1111l_opy_ (u"ࠧ࠶࠸ࠪ॓"), l1111l_opy_ (u"ࠨ࠷࠺ࠫ॔"), l1111l_opy_ (u"ࠩ࠸࠼ࠬॕ"), l1111l_opy_ (u"ࠪ࠹࠾࠭ॖ"), l1111l_opy_ (u"ࠫ࠻࠶ࠧॗ"), l1111l_opy_ (u"ࠬ࠼࠱ࠨक़"), l1111l_opy_ (u"࠭࠶࠳ࠩख़"), l1111l_opy_ (u"ࠧ࠷࠵ࠪग़"), l1111l_opy_ (u"ࠨ࠸࠸ࠫज़"), l1111l_opy_ (u"ࠩ࠹࠺ࠬड़"), l1111l_opy_ (u"ࠪ࠺࠼࠭ढ़"), l1111l_opy_ (u"ࠫ࠻࠿ࠧफ़"), l1111l_opy_ (u"ࠬ࠽࠰ࠨय़"), l1111l_opy_ (u"࠭࠷࠵ࠩॠ"), l1111l_opy_ (u"ࠧ࠸࠹ࠪॡ"), l1111l_opy_ (u"ࠨ࠹࠻ࠫॢ"), l1111l_opy_ (u"ࠩ࠻࠴ࠬॣ"), l1111l_opy_ (u"ࠪ࠼࠶࠭।")]
    login = l1111l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴ࠱ࠪ॥") % addon
    sendJSON(login, addon)
    l1llll_opy_ = []
    for l1l1l1111_opy_ in l1l11l111_opy_:
        if (addon == l1l11ll1l_opy_) or (addon == l11llll1l_opy_):
            query = l1111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠦࡵ࠲ࡃࡲࡵࡤࡦࡡ࡬ࡨࡂࡩࡨࡢࡰࡱࡩࡱࡹࠦ࡮ࡱࡧࡩࡂࡩࡨࡢࡰࡱࡩࡱࡹࠦࡴࡧࡦࡸ࡮ࡵ࡮ࡠ࡫ࡧࡁࠪࡹࠧ०") % (addon, l1l1l1111_opy_)
        if (addon == locked) or (addon == l11lll1ll_opy_):
            query = l1111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶ࠳ࡄࡻࡲ࡭࠿ࠨࡷࠫࡳ࡯ࡥࡧࡀ࠸ࠫࡴࡡ࡮ࡧࡀࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧࡲ࡯ࡥࡾࡃࠦࡥࡣࡷࡩࡂࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࡁࠫࡶࡡࡨࡧࡀࠫ१") % (addon, l1l1l1111_opy_)
        response = sendJSON(query, addon)
        l1llll_opy_.extend(response)
    return l1llll_opy_
def sendJSON(query, addon):
    l1l11ll11_opy_     = l1111l_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ२") % query
    l1l111l1l_opy_  = xbmc.executeJSONRPC(l1l11ll11_opy_)
    response = json.loads(l1l111l1l_opy_)
    result   = response[l1111l_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨ३")]
    if xbmcgui.Window(10000).getProperty(l1111l_opy_ (u"ࠩࡓࡐ࡚ࡍࡉࡏࡡࡊࡉࡓࡘࡅࠨ४")) == l1111l_opy_ (u"ࠪࡘࡷࡻࡥࠨ५"):
        xbmcaddon.Addon(addon).setSetting(l1111l_opy_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ६"), l1111l_opy_ (u"ࠬࡺࡲࡶࡧࠪ७"))
    if xbmcgui.Window(10000).getProperty(l1111l_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡔࡗࡉࡘࡍࡉࡋࠧ८")) == l1111l_opy_ (u"ࠧࡕࡴࡸࡩࠬ९"):
        xbmcaddon.Addon(addon).setSetting(l1111l_opy_ (u"ࠨࡶࡹ࡫ࡺ࡯ࡤࡦࠩ॰"), l1111l_opy_ (u"ࠩࡷࡶࡺ࡫ࠧॱ"))
    return result[l1111l_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩॲ")]
def l1l1l11l1_opy_(addon):
    if (addon == l1l111l11_opy_) or (addon == l11llllll_opy_):
        return l1111l_opy_ (u"ࠫ࠴ࡅࡣࡢࡶࡀ࠱࠷ࠬࡤࡢࡶࡨࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠨࡨࡲࡩࡊࡡࡵࡧࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦ࡮ࡱࡧࡩࡂ࠸ࠦ࡯ࡣࡰࡩࡂࡓࡹࠦ࠴࠳ࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡸࡥࡤࡱࡵࡨࡳࡧ࡭ࡦࠨࡶࡸࡦࡸࡴࡅࡣࡷࡩࠫࡻࡲ࡭࠿ࡸࡶࡱ࠭ॳ")
    return l1111l_opy_ (u"ࠬ࠭ॴ")
def l1111_opy_():
    modules = map(__import__, [l1llllll_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1l11_opy_)):
        return l1111l_opy_ (u"࠭ࡔࡳࡷࡨࠫॵ")
    if len(modules[-1].Window(10**4).getProperty(l11ll_opy_)):
        return l1111l_opy_ (u"ࠧࡕࡴࡸࡩࠬॶ")
    return l1111l_opy_ (u"ࠨࡈࡤࡰࡸ࡫ࠧॷ")
def l11lll1_opy_(e, addon):
    l11ll1_opy_ = l1111l_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠭ࠢࡤࡲࠥ࡫ࡲࡳࡱࡵࠤࡴࡩࡣࡶࡴࡨࡨ࠿ࠦࡊࡔࡑࡑࠤࡊࡸࡲࡰࡴ࠽ࠤࠪࡹࠬࠡࠧࡶࠫॸ")  % (e, addon)
    l111l_opy_ = l1111l_opy_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡧࡴࡴࡴࡢࡥࡷࠤࡺࡹࠠࡰࡰࠣࡸ࡭࡫ࠠࡧࡱࡵࡹࡲ࠴ࠧॹ")
    l1l111_opy_ = l1111l_opy_ (u"࡚ࠫࡶ࡬ࡰࡣࡧࠤࡦࠦ࡬ࡰࡩࠣࡺ࡮ࡧࠠࡵࡪࡨࠤࡦࡪࡤࡰࡰࠣࡷࡪࡺࡴࡪࡰࡪࡷࠥࡧ࡮ࡥࠢࡳࡳࡸࡺࠠࡵࡪࡨࠤࡱ࡯࡮࡬࠰ࠪॺ")
    dixie.log(addon)
    dixie.log(e)
def getPluginInfo(streamurl):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l11lll1l1_opy_   = l1111l_opy_ (u"ࠬࡑ࡯ࡥ࡫ࠣࡔ࡛ࡘࠧॻ")
            l11llll11_opy_ = os.path.join(dixie.RESOURCES, l1111l_opy_ (u"࠭࡫ࡰࡦ࡬࠱ࡵࡼࡲ࠯ࡲࡱ࡫ࠬॼ"))
            return l11lll1l1_opy_, l11llll11_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l1111l_opy_ (u"ࠧࡳࡶࡰࡴࠬॽ")) or url.startswith(l1111l_opy_ (u"ࠨࡴࡷࡱࡵ࡫ࠧॾ")) or url.startswith(l1111l_opy_ (u"ࠩࡵࡸࡸࡶࠧॿ")) or url.startswith(l1111l_opy_ (u"ࠪ࡬ࡹࡺࡰࠨঀ")):
            l11lll1l1_opy_   = l1111l_opy_ (u"ࠫࡲ࠹ࡵࠡࡒ࡯ࡥࡾࡲࡩࡴࡶࠪঁ")
            l11llll11_opy_ = os.path.join(dixie.RESOURCES, l1111l_opy_ (u"ࠬ࡯ࡰࡵࡸ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡶ࡮ࡨࠩং"))
            return l11lll1l1_opy_, l11llll11_opy_
    except:
        pass
    if streamurl.startswith(l1111l_opy_ (u"࠭ࡰࡷࡴ࠽࠳࠴࠭ঃ")):
        l11lll1l1_opy_   = l1111l_opy_ (u"ࠧࡌࡱࡧ࡭ࠥࡖࡖࡓࠩ঄")
        l11llll11_opy_ = os.path.join(dixie.RESOURCES, l1111l_opy_ (u"ࠨ࡭ࡲࡨ࡮࠳ࡰࡷࡴ࠱ࡴࡳ࡭ࠧঅ"))
        return l11lll1l1_opy_, l11llll11_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        l1l1111ll_opy_ = streamurl.split(l1111l_opy_ (u"ࠩࡠࡓ࡙࡚࡟ࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪআ"), 1)[-1].split(l1111l_opy_ (u"ࠪ࠳ࠬই"), 1)[0]
    if l1111l_opy_ (u"ࠫࡢࡕࡔࡕࡡࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬঈ") in streamurl:
        l1l1111ll_opy_ = streamurl.split(l1111l_opy_ (u"ࠬࡣࡏࡕࡖࡢࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭উ"), 1)[-1].split(l1111l_opy_ (u"࠭࠯ࠨঊ"), 1)[0]
    if streamurl.startswith(l1111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪঋ")):
        l1l1111ll_opy_ = streamurl.split(l1111l_opy_ (u"ࠨ࠱࠲ࠫঌ"), 1)[-1].split(l1111l_opy_ (u"ࠩ࠲ࠫ঍"), 1)[0]
    if l1111l_opy_ (u"ࠪࡣࡤ࡙ࡆࡠࡡࠪ঎") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡵࡸ࡯ࡨࡴࡤࡱ࠳ࡹࡵࡱࡧࡵ࠲࡫ࡧࡶࡰࡷࡵ࡭ࡹ࡫ࡳࠨএ")
    if l1111l_opy_ (u"ࠬ࡜ࡄࡓࡖ࡙࠾ࠬঐ") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡜ࡁࡅࡇࡕࠫ঑")
    if l1111l_opy_ (u"ࠧࡉࡆࡗ࡚࠿࠭঒") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴ࡯ࡤࡶࡹ࡮ࡵࡣࠩও")
    if l1111l_opy_ (u"ࠩࡋࡈ࡙࡜࠲࠻ࠩঔ") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧ࠲ࠨক")
    if l1111l_opy_ (u"ࠫࡍࡊࡔࡗ࠵࠽ࠫখ") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢ࠴ࠪগ")
    if l1111l_opy_ (u"࠭ࡈࡅࡖ࡙࠸࠿࠭ঘ") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸ࡭ࠩঙ")
    if l1111l_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠺ࠨচ") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡤࡥࡧ࡮ࡶ࡬ࡢࡻࡨࡶࠬছ")
    if l1111l_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠴࠽ࠫজ") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽࠧঝ")
    if l1111l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖ࠿࠭ঞ") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰ࡭ࡣࡼࡩࡷࡽࡷࡸࠩট")
    if l1111l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡏࡔࡗ࠼ࠪঠ") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡶࡹࠫড")
    if l1111l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪঢ") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡧࡩࡽ࠭ণ")
    if l1111l_opy_ (u"ࠫࡏࡏࡎ࡙࠴࠽ࠫত") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡯࡯࡮ࡹࡶࡹ࠶ࠬথ")
    if l1111l_opy_ (u"࠭ࡒࡐࡑࡗ࠾ࠬদ") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡰࡱࡷ࡭ࡵࡺࡶࠨধ")
    if l1111l_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡒࡃ࠼ࠪন") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡨࡦࡴࡵࡴࠨ঩")
    if l1111l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡅࡏ࡙࠿࠭প") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡧࡱࡻࡩࡱࡶࡹࠫফ")
    if l1111l_opy_ (u"ࠬࡏࡐࡕࡕࠪব") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰࡵࡸࡶࡹࡧࡹࠧভ")
    if l1111l_opy_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠺ࠨম") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡭࡫ࡹࡩࡲ࡯ࡸࠨয")
    if l1111l_opy_ (u"ࠩࡈࡒࡉࡀࠧর") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡈࡲࡩࡲࡥࡴࡵࠪ঱")
    if l1111l_opy_ (u"ࠫࡋࡒࡁ࠻ࠩল") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡋࡲࡡࡸ࡮ࡨࡷࡸ࡚ࡶࠨ঳")
    if l1111l_opy_ (u"࠭ࡆࡍࡃࡖ࠾ࠬ঴") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡆ࡭ࡣࡺࡰࡪࡹࡳࡕࡸࠪ঵")
    if l1111l_opy_ (u"ࠨࡕࡓࡖࡒࡀࠧশ") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡕࡸࡴࡷ࡫࡭ࡢࡥࡼࡘ࡛࠭ষ")
    if l1111l_opy_ (u"ࠪࡑࡈࡑࡔࡗ࠼ࠪস") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡱࡨࡱࡴࡷ࠯ࡳࡰࡺࡹࠧহ")
    if l1111l_opy_ (u"ࠬࡻࡰ࡯ࡲ࠽ࠫ঺") in streamurl:
        l1l1111ll_opy_ = l1111l_opy_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴ࡨࡥࡪࡲࡱࡪࡸࡵ࡯࠰ࡹ࡭ࡪࡽࠧ঻")
    return l1l11l1l1_opy_(l1l1111ll_opy_)
def l1l11l1l1_opy_(l1l1111ll_opy_):
    l11lll1l1_opy_   = l1111l_opy_ (u"ࠧࠨ়")
    l11llll11_opy_ = l1111l_opy_ (u"ࠨࠩঽ")
    try:
        l1l1l11ll_opy_ = xbmcaddon.Addon(l1l1111ll_opy_).getAddonInfo(l1111l_opy_ (u"ࠩࡱࡥࡲ࡫ࠧা"))
        l11lll1l1_opy_    = cleanLabel(l1l1l11ll_opy_)
        l11llll11_opy_  = xbmcaddon.Addon(l1l1111ll_opy_).getAddonInfo(l1111l_opy_ (u"ࠪ࡭ࡨࡵ࡮ࠨি"))
        return l11lll1l1_opy_, l11llll11_opy_
    except:
        l11lll1l1_opy_   = l1111l_opy_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲ࡙ࠥ࡯ࡶࡴࡦࡩࠬী")
        l11llll11_opy_ =  dixie.ICON
        return l11lll1l1_opy_, l11llll11_opy_
    return l11lll1l1_opy_, l11llll11_opy_
def selectStream(url, channel):
    l11lll11l_opy_ = url.split(l1111l_opy_ (u"ࠬࢂࠧু"))
    if len(l11lll11l_opy_) == 0:
        return None
    options, l11111l_opy_ = getOptions(l11lll11l_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l11lll11l_opy_) == 1:
            return l11111l_opy_[0]
    import selectDialog
    l1l111ll1_opy_ = selectDialog.select(l1111l_opy_ (u"࠭ࡓࡦ࡮ࡨࡧࡹࠦࡡࠡࡵࡷࡶࡪࡧ࡭ࠨূ"), options)
    if l1l111ll1_opy_ < 0:
        raise Exception(l1111l_opy_ (u"ࠧࡔࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡇࡦࡴࡣࡦ࡮ࠪৃ"))
    return l11111l_opy_[l1l111ll1_opy_]
def getOptions(l11lll11l_opy_, channel, addmore=True):
    options = []
    l11111l_opy_    = []
    for index, stream in enumerate(l11lll11l_opy_):
        l11lll1l1_opy_ = getPluginInfo(stream)
        l11l1l_opy_ = l11lll1l1_opy_[0]
        l1l111111_opy_  = l11lll1l1_opy_[1]
        l11l1l_opy_ = l1111l_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡱࡵࡥࡳ࡭ࡥ࡞࡝ࠪৄ") + l11l1l_opy_ + l1111l_opy_ (u"ࠩࡠ࡟࠴ࡉࡏࡍࡑࡕࡡࠥ࠭৅")
        if stream.startswith(OPEN_OTT):
            l1l11l11l_opy_ = stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l1111l_opy_ (u"ࠪࠫ৆"))
            l11l1l_opy_  = l11l1l_opy_ + l1l11l11l_opy_
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l1111l_opy_ (u"ࠫࠬে"))
        else:
            l11l1l_opy_  = l11l1l_opy_ + channel
        options.append([l11l1l_opy_, index, l1l111111_opy_])
        l11111l_opy_.append(stream)
    if addmore:
        options.append([l1111l_opy_ (u"ࠬࡇࡤࡥࠢࡰࡳࡷ࡫࠮࠯࠰ࠪৈ"), index + 1, dixie.ICON])
        l11111l_opy_.append(l1111l_opy_ (u"࠭ࡡࡥࡦࡐࡳࡷ࡫ࠧ৉"))
    return options, l11111l_opy_
def cleanLabel(name):
    import re
    name  = re.sub(l1111l_opy_ (u"ࠧ࡝ࠪ࡞࠴࠲࠿ࠩ࡞ࠬ࡟࠭ࠬ৊"), l1111l_opy_ (u"ࠨࠩো"), name)
    items = name.split(l1111l_opy_ (u"ࠩࡠࠫৌ"))
    name  = l1111l_opy_ (u"্ࠪࠫ")
    for item in items:
        if len(item) == 0:
            continue
        item += l1111l_opy_ (u"ࠫࡢ࠭ৎ")
        item  = re.sub(l1111l_opy_ (u"ࠬࡢ࡛࡜ࡠࠬࡡ࠯ࡢ࡝ࠨ৏"), l1111l_opy_ (u"࠭ࠧ৐"), item)
        if len(item) > 0:
            name += item
    name  = name.replace(l1111l_opy_ (u"ࠧ࡜ࠩ৑"), l1111l_opy_ (u"ࠨࠩ৒"))
    name  = name.replace(l1111l_opy_ (u"ࠩࡠࠫ৓"), l1111l_opy_ (u"ࠪࠫ৔"))
    name  = name.strip()
    while True:
        length = len(name)
        name = name.replace(l1111l_opy_ (u"ࠫࠥࠦࠧ৕"), l1111l_opy_ (u"ࠬࠦࠧ৖"))
        if length == len(name):
            break
    return name.strip()
if __name__ == l1111l_opy_ (u"࠭࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠨৗ"):
    checkAddons()