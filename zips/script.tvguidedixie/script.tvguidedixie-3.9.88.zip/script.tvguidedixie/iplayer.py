# coding: UTF-8
import sys
l1l11l1_opy_ = sys.version_info [0] == 2
l1l111l_opy_ = 2048
l1l1ll_opy_ = 7
def l1lll11_opy_ (ll_opy_):
	global l1ll1l_opy_
	l1ll1ll1_opy_ = ord (ll_opy_ [-1])
	l1l1l1l_opy_ = ll_opy_ [:-1]
	l1l1l_opy_ = l1ll1ll1_opy_ % len (l1l1l1l_opy_)
	l1llll1l_opy_ = l1l1l1l_opy_ [:l1l1l_opy_] + l1l1l1l_opy_ [l1l1l_opy_:]
	if l1l11l1_opy_:
		l11l1ll_opy_ = unicode () .join ([unichr (ord (char) - l1l111l_opy_ - (l1lllll_opy_ + l1ll1ll1_opy_) % l1l1ll_opy_) for l1lllll_opy_, char in enumerate (l1llll1l_opy_)])
	else:
		l11l1ll_opy_ = str () .join ([chr (ord (char) - l1l111l_opy_ - (l1lllll_opy_ + l1ll1ll1_opy_) % l1l1ll_opy_) for l1lllll_opy_, char in enumerate (l1llll1l_opy_)])
	return eval (l11l1ll_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
import mapping
ADDON    = dixie.ADDON
l111l1_opy_ = dixie.PROFILE
l11l11_opy_  = os.path.join(l111l1_opy_, l1lll11_opy_ (u"ࠫ࡮ࡴࡩࠨࠀ"))
l1lll111_opy_ = l1lll11_opy_ (u"ࠬ࠭ࠁ")
def l1l1lll1_opy_(i, t1, l1ll1lll_opy_=[]):
 t = l1lll111_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1ll1lll_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11l1_opy_ = l1l1lll1_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l111l_opy_ = l1l1lll1_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1111ll_opy_       = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡣࡦࡶࡹࠫࠂ")
l1ll111l_opy_   = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡨࡰࡴ࡬ࡾࡴࡴࡩࡱࡶࡹࠫࠃ")
l1lllll1_opy_     = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡱࡲࡸࡎࡖࡔࡗࠩࠄ")
l1lll11l_opy_      = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡯ࡨ࡫ࡦ࡯ࡰࡵࡸࠪࠅ")
l11ll1l_opy_  = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡩࡶࡪ࡫ࡶࡪࡧࡺࠫࠆ")
l11_opy_  = l1lll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡑࡦࡺࡳࡃࡷ࡬ࡰࡩࡹࡉࡑࡖ࡙ࠫࠇ")
l1ll111l_opy_   = l1lll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡭ࡵࡲࡪࡼࡲࡲ࡮ࡶࡴࡷࠩࠈ")
l1lll1l_opy_  = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰࡵࡸࡶࡹࡧࡹࠧࠉ")
l1l1ll1_opy_      = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡪࡪࡰࡻࡸࡻ࠸ࠧࠊ")
l1ll11l_opy_  = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡱࡲࡸ࡮ࡶࡴࡷࠩࠋ")
l1ll111_opy_   = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡇࡱࡨࡱ࡫ࡳࡴࠩࠌ")
l1ll1l11_opy_  = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡉࡰࡦࡽ࡬ࡦࡵࡶࡘࡻ࠭ࠍ")
l11ll11_opy_   = l1lll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡱࡦࡾࡩࡸࡧࡥࡸࡻ࠭ࠎ")
dexter    = l1lll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸࠨࠏ")
l11ll_opy_     = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡜ࡁࡅࡇࡕࠫࠐ")
l11ll1_opy_ = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡓࡶࡲࡵࡩࡲࡧࡣࡺࡖ࡙ࠫࠑ")
l1llll1_opy_     = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡮ࡥ࡮ࡸࡻ࠳ࡰ࡭ࡷࡶࠫࠒ")
l1lll1l1_opy_   = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡶࡺ࡭ࡸࡺࡥࡥࠩࠓ")
l11l1l1_opy_  = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡳࡷࡦࡪࡤࡰࡰࠪࠔ")
l1l1l1_opy_  = l1lll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡆࡱࡧࡣ࡬ࡋࡦࡩ࡙࡜ࠧࠕ")
l1l1llll_opy_    = [l1111ll_opy_, l1ll111l_opy_, l1lllll1_opy_, l1lll11l_opy_, l11ll1l_opy_, l11_opy_, l1lll1l_opy_, l1l1ll1_opy_, l1ll11l_opy_, l1ll111_opy_, l1ll1l11_opy_, l11ll11_opy_, dexter, l11ll_opy_, l11ll1_opy_, l1llll1_opy_, l1lll1l1_opy_, l11l1l1_opy_, l1l1l1_opy_]
def checkAddons():
    for addon in l1l1llll_opy_:
        if l1ll11l1_opy_(addon):
            try: createINI(addon)
            except: continue
def l1ll11l1_opy_(addon):
    if xbmc.getCondVisibility(l1lll11_opy_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠦࡵࠬࠫࠖ") % addon) == 1:
        dixie.log(l1lll11_opy_ (u"࠭࠽࠾࠿ࡀࠤࡦࡪࡤࡰࡰࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦ࠽࠾࠿ࡀࠫࠗ"))
        dixie.log(addon)
        return True
    return False
def createINI(addon):
    HOME  = dixie.PROFILE
    iPATH = os.path.join(HOME, l1lll11_opy_ (u"ࠧࡪࡰ࡬ࠫ࠘"))
    l11l111_opy_  = str(addon).split(l1lll11_opy_ (u"ࠨ࠰ࠪ࠙"))[2] + l1lll11_opy_ (u"ࠩ࠱࡭ࡳ࡯ࠧࠚ")
    l1l_opy_   = os.path.join(iPATH, l11l111_opy_)
    l11l1l_opy_   = os.path.join(iPATH, l1lll11_opy_ (u"ࠪࡱࡦࡶࡰࡪࡰࡪࡷ࠳ࡰࡳࡰࡰࠪࠛ"))
    LABELFILE = os.path.join(iPATH, l1lll11_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࡶ࠲࡯ࡹ࡯࡯ࠩࠜ"))
    l111ll_opy_  = json.load(open(l11l1l_opy_))
    labelmaps = json.load(open(LABELFILE))
    response = l1_opy_(addon)
    l1ll1ll_opy_ = response[l1lll11_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬࠝ")][l1lll11_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬࠞ")]
    l1l1lll_opy_  = l1lll11_opy_ (u"ࠧ࡜ࠩࠟ") + addon + l1lll11_opy_ (u"ࠨ࡟࡟ࡲࠬࠠ")
    l1l11_opy_  =  file(l1l_opy_, l1lll11_opy_ (u"ࠩࡺࠫࠡ"))
    l1l11_opy_.write(l1l1lll_opy_)
    l1ll1111_opy_ = []
    for channel in l1ll1ll_opy_:
        l11lll_opy_ = l1l11l_opy_(addon)
        l1lll_opy_  = channel[l1lll11_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࠢ")].split(l1lll11_opy_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠣ"), 1)[0]
        if addon == dexter:
            l1lll_opy_ = l1lll_opy_.split(l1lll11_opy_ (u"ࠬࠦࠫࠡࠩࠤ"), 1)[0]
        if addon == l1lllll1_opy_:
            l1lll_opy_ = l1lll_opy_.split(l1lll11_opy_ (u"࠭ࠠ࠮ࠢࠪࠥ"), 1)[0]
        l111ll1_opy_  = l11lll1_opy_(l1lll_opy_)
        l1111l1_opy_  = l1ll1l1l_opy_(labelmaps, l111ll_opy_, l1lll_opy_)
        stream  = l11lll_opy_ + l111ll1_opy_
        l1111_opy_ = l1111l1_opy_  + l1lll11_opy_ (u"ࠧ࠾ࠩࠦ") + stream
        if l1111_opy_ not in l1ll1111_opy_:
            l1ll1111_opy_.append(l1111_opy_)
    l1ll1111_opy_.sort()
    for item in l1ll1111_opy_:
        l1l11_opy_.write(l1lll11_opy_ (u"ࠣࠧࡶࡠࡳࠨࠧ") % item)
    l1l11_opy_.close()
def l11lll1_opy_(l1lll_opy_):
    l1ll11ll_opy_ = mapping.cleanLabel(l1lll_opy_)
    l111ll1_opy_ = mapping.cleanStreamLabel(l1ll11ll_opy_)
    return l111ll1_opy_
def l1ll1l1l_opy_(labelmaps, l111ll_opy_, l1lll_opy_):
    l11111_opy_    = mapping.cleanLabel(l1lll_opy_)
    l1ll11ll_opy_ = mapping.mapLabel(labelmaps, l11111_opy_)
    l1111l1_opy_ = mapping.cleanPrefix(l1ll11ll_opy_)
    return mapping.mapChannelName(l111ll_opy_, l1111l1_opy_)
def l1ll_opy_(addon, file):
    l11111_opy_ = file[l1lll11_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨࠨ")].split(l1lll11_opy_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࠩ"), 1)[0]
    l11111_opy_ = l11111_opy_.split(l1lll11_opy_ (u"ࠫ࠰࠭ࠪ"), 1)[0]
    l11111_opy_ = mapping.cleanLabel(l11111_opy_)
    return l11111_opy_
def l1l11l_opy_(addon):
    if addon == l1111ll_opy_:
        return l1lll11_opy_ (u"ࠬࡇࡃࡆ࠼ࠪࠫ")
    if addon == l1ll111l_opy_:
        return l1lll11_opy_ (u"࠭ࡈࡐࡔࡌ࡞࠿࠭ࠬ")
    if addon == l1lllll1_opy_:
        return l1lll11_opy_ (u"ࠧࡓࡑࡒࡘ࠷ࡀࠧ࠭")
    if addon == l1lll11l_opy_:
        return l1lll11_opy_ (u"ࠨࡏࡈࡋࡆࡀࠧ࠮")
    if addon == l11ll1l_opy_:
        return l1lll11_opy_ (u"ࠩࡉࡖࡊࡋ࠺ࠨ࠯")
    if addon == l11_opy_:
        return l1lll11_opy_ (u"ࠪࡑࡆ࡚ࡓ࠻ࠩ࠰")
    if addon == l1lll1l_opy_:
        return l1lll11_opy_ (u"ࠫࡎࡖࡔࡔ࠼ࠪ࠱")
    if addon == l1l1ll1_opy_:
        return l1lll11_opy_ (u"ࠬࡐࡉࡏ࡚࠵࠾ࠬ࠲")
    if addon == l1ll11l_opy_:
        return l1lll11_opy_ (u"࠭ࡒࡐࡑࡗ࠾ࠬ࠳")
    if addon == l1ll111_opy_:
        return l1lll11_opy_ (u"ࠧࡆࡐࡇ࠾ࠬ࠴")
    if addon == l1ll1l11_opy_:
        return l1lll11_opy_ (u"ࠨࡈࡏࡅ࠿࠭࠵")
    if addon == l11ll11_opy_:
        return l1lll11_opy_ (u"ࠩࡐࡅ࡝ࡏ࠺ࠨ࠶")
    if addon == dexter:
        return l1lll11_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡆ࠽ࠫ࠷")
    if addon == l11ll_opy_:
        return l1lll11_opy_ (u"࡛ࠫࡊࡒࡕࡘ࠽ࠫ࠸")
    if addon == l11ll1_opy_:
        return l1lll11_opy_ (u"࡙ࠬࡐࡓࡏ࠽ࠫ࠹")
    if addon == l1llll1_opy_:
        return l1lll11_opy_ (u"࠭ࡍࡄࡍࡗ࡚࠿࠭࠺")
    if addon == l1lll1l1_opy_:
        return l1lll11_opy_ (u"ࠧࡕ࡙ࡌࡗ࡙ࡀࠧ࠻")
    if addon == l11l1l1_opy_:
        return l1lll11_opy_ (u"ࠨࡒࡕࡉࡘ࡚࠺ࠨ࠼")
    if addon == l1l1l1_opy_:
        return l1lll11_opy_ (u"ࠩࡅࡐࡐࡏ࠺ࠨ࠽")
def getURL(url):
    if url.startswith(l1lll11_opy_ (u"ࠪࡅࡈࡋࠧ࠾")):
        return l11l_opy_(url, l1111ll_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠫࡍࡕࡒࡊ࡜ࠪ࠿")):
        return l11l_opy_(url, l1ll111l_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠬࡘࡏࡐࡖ࠵ࠫࡀ")):
        return l11l_opy_(url, l1lllll1_opy_)
    if url.startswith(l1lll11_opy_ (u"࠭ࡍࡆࡉࡄࠫࡁ")):
        return l11l_opy_(url, l1lll11l_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠧࡇࡔࡈࡉࠬࡂ")):
        return l11l_opy_(url, l11ll1l_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡃࡍࡗ࠽ࠫࡃ")):
        url = url.replace(l1lll11_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡄࡎࡘ࠾ࠬࡄ"), l1lll11_opy_ (u"ࠪࠫࡅ")).replace(l1lll11_opy_ (u"ࠫ࠲࠳ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪࡆ"), l1lll11_opy_ (u"ࠬࢂࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪࡇ"))
        return url
    if url.startswith(l1lll11_opy_ (u"࠭ࡍࡂࡖࡖࠫࡈ")):
        return l11l_opy_(url, l11_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠧࡊࡒࡗࡗࠬࡉ")):
        return l11l_opy_(url, l1lll1l_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠨࡌࡌࡒ࡝࠸ࠧࡊ")):
        return l11l_opy_(url, l1l1ll1_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠩࡕࡓࡔ࡚ࠧࡋ")):
        return l11l_opy_(url, l1ll11l_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡆࠪࡌ")):
        return l11l_opy_(url, dexter)
    if url.startswith(l1lll11_opy_ (u"ࠫࡋࡒࡁࠨࡍ")):
        return l11l_opy_(url, l1ll1l11_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠬࡓࡁ࡙ࡋࠪࡎ")):
        return l11l_opy_(url, l11ll11_opy_)
    if url.startswith(l1lll11_opy_ (u"࠭ࡅࡏࡆࠪࡏ")):
        return l11l_opy_(url, l1ll111_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠧࡗࡆࡕࡘ࡛࠭ࡐ")):
        return l11l_opy_(url, l11ll_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠨࡕࡓࡖࡒ࠭ࡑ")):
        return l11l_opy_(url, l11ll1_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠩࡐࡇࡐ࡚ࡖࠨࡒ")):
        return l11l_opy_(url, l1llll1_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠪࡘ࡜ࡏࡓࡕࠩࡓ")):
        return l11l_opy_(url, l1lll1l1_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠫࡕࡘࡅࡔࡖࠪࡔ")):
        return l11l_opy_(url, l11l1l1_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠬࡈࡌࡌࡋࠪࡕ")):
        return l11l_opy_(url, l1l1l1_opy_)
    response  = l111_opy_(url)
    l1l11ll_opy_ = url.split(l1lll11_opy_ (u"࠭࠺ࠨࡖ"), 1)[-1]
    try:
        result = response[l1lll11_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧࡗ")]
        l1ll11_opy_  = result[l1lll11_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧࡘ")]
    except Exception as e:
        l1llllll_opy_(e)
        return None
    for file in l1ll11_opy_:
        l1lll_opy_  = file[l1lll11_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨ࡙")].split(l1lll11_opy_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡ࡚ࠬ"), 1)[0]
        l11111l_opy_  = l1lll_opy_.split(l1lll11_opy_ (u"ࠫ࠰࡛࠭"), 1)[0]
        l111111_opy_ = mapping.cleanLabel(l11111l_opy_)
        try:
            if l1l11ll_opy_ == l111111_opy_:
                return file[l1lll11_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪ࡜")]
        except:
            if (l1l11ll_opy_ in l111111_opy_) or (l111111_opy_ in l1l11ll_opy_):
                return file[l1lll11_opy_ (u"࠭ࡦࡪ࡮ࡨࠫ࡝")]
    return None
def l11l_opy_(url, addon):
    PATH = l1ll1_opy_(addon)
    try:
        response = json.load(open(PATH))
    except:
        response = l1_opy_(addon)
    l111l11_opy_      = url.split(l1lll11_opy_ (u"ࠧ࠻ࠩ࡞"), 1)[-1]
    stream    = l111l11_opy_.split(l1lll11_opy_ (u"ࠨࠢ࡞ࠫ࡟"), 1)[0]
    l1l11ll_opy_ = mapping.cleanLabel(stream)
    l1ll11_opy_  = response[l1lll11_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩࡠ")][l1lll11_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩࡡ")]
    for file in l1ll11_opy_:
        l1lll_opy_  = file[l1lll11_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪࡢ")].split(l1lll11_opy_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࡣ"), 1)[0]
        if addon == dexter:
            l1lll_opy_ = l1lll_opy_.split(l1lll11_opy_ (u"࠭ࠠࠬࠢࠪࡤ"), 1)[0]
        if addon == l1lllll1_opy_:
            l1lll_opy_ = l1lll_opy_.split(l1lll11_opy_ (u"ࠧࠡ࠯ࠣࠫࡥ"), 1)[0]
        l111111_opy_ = l11lll1_opy_(l1lll_opy_)
        try:
            if l1l11ll_opy_ == l111111_opy_:
                return file[l1lll11_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ࡦ")]
        except:
            if (l1l11ll_opy_ in l111111_opy_) or (l111111_opy_ in l1l11ll_opy_):
                return file[l1lll11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧࡧ")]
            if l1lll11_opy_ (u"࡙ࠪࡘࡇ࠯ࡄࡃ࠽ࠫࡨ") in l111111_opy_:
                l11llll_opy_ = l111111_opy_.replace(l1lll11_opy_ (u"࡚࡙ࠫࡁ࠰ࡅࡄ࠾ࠬࡩ"), l1lll11_opy_ (u"࡛ࠬࡓࡂ࠼ࠪࡪ"))
                if dixie.fuzzyMatch(l1l11ll_opy_, l11llll_opy_):
                    return file[l1lll11_opy_ (u"࠭ࡦࡪ࡮ࡨࠫ࡫")]
    return None
def l1_opy_(addon):
    PATH  = l1ll1_opy_(addon)
    if addon == l11ll_opy_:
        query = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡘࡄࡈࡊࡘ࠯࡭࡫ࡹࡩࡹࡼ࠯ࡢ࡮࡯࠳ࠬ࡬")
    elif addon == l11ll1l_opy_:
        query = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡩࡶࡪ࡫ࡶࡪࡧࡺ࠳ࡄࡻࡲ࡭࠿ࡸࡶࡱࠬ࡭ࡰࡦࡨࡁ࠺ࠬ࡮ࡢ࡯ࡨࡁࡑ࡯ࡶࡦ࠭ࡗ࡚ࠬ࡭")
    else:
        query = l111lll_opy_(addon)
    try:
        return json.load(open(PATH))
    except:
        content = doJSON(query)
        return l1ll1l1_opy_(PATH, addon, content)
def l1ll1l1_opy_(PATH, addon, content):
    json.dump(content, open(PATH,l1lll11_opy_ (u"ࠩࡺࠫ࡮")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    l1lll1ll_opy_  = (l1lll11_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭࡯") % query)
    response = xbmc.executeJSONRPC(l1lll1ll_opy_)
    content  = json.loads(response)
    return content
def l1ll1_opy_(addon):
    if addon == l1111ll_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠫࡦࡩࡥࡵࡧࡰࡴࠬࡰ"))
    if addon == l1ll111l_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠬ࡮࡯ࡳࡶࡨࡱࡵ࠭ࡱ"))
    if addon == l1lllll1_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"࠭ࡲࡰ࠴ࡷࡩࡲࡶࠧࡲ"))
    if addon == l1lll11l_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠧ࡮ࡧࡪࡥࡹࡳࡰࠨࡳ"))
    if addon == l11_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠨ࡯ࡤࡸࡸࡺ࡭ࡱࠩࡴ"))
    if addon == l11ll1l_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠩࡩࡶࡪ࡫ࡴ࡮ࡲࠪࡵ"))
    if addon == l1lll1l_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠪ࡭ࡵࡺࡳࡵ࡯ࡳࠫࡶ"))
    if addon == l1l1ll1_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠫ࡯࠸ࡴࡦ࡯ࡳࠫࡷ"))
    if addon == l1ll11l_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠬࡸ࡯ࡵࡧࡰࡴࠬࡸ"))
    if addon == l1ll111_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"࠭ࡥࡵࡧࡰࡴࠬࡹ"))
    if addon == l1ll1l11_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠧࡧࡶࡨࡱࡵ࠭ࡺ"))
    if addon == l11ll11_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠨ࡯ࡤࡼࡹ࡫࡭ࡱࠩࡻ"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠩࡧࡸࡪࡳࡰࠨࡼ"))
    if addon == l11ll_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠪࡺࡩࡺࡥ࡮ࡲࠪࡽ"))
    if addon == l11ll1_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠫࡸࡶࡲࡵࡧࡰࡴࠬࡾ"))
    if addon == l1llll1_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠬࡳࡣ࡬ࡶࡨࡱࡵ࠭ࡿ"))
    if addon == l1lll1l1_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"࠭ࡴࡸ࡫ࡷࡩࡲࡶࠧࢀ"))
    if addon == l11l1l1_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠧࡱࡴࡨࡷࡹ࡫࡭ࡱࠩࢁ"))
    if addon == l1l1l1_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠨࡤ࡯࡯࡮ࡺࡥ࡮ࡲࠪࢂ"))
def l111lll_opy_(addon):
    query = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬࢃ") + addon
    response = doJSON(query)
    l1ll11_opy_    = response[l1lll11_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪࢄ")][l1lll11_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪࢅ")]
    for file in l1ll11_opy_:
        l11l11l_opy_ = file[l1lll11_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫࢆ")]
        l11111_opy_ = mapping.cleanLabel(l11l11l_opy_)
        l11111_opy_ = l11111_opy_.upper()
        if (l11111_opy_ == l1lll11_opy_ (u"࠭ࡌࡊࡘࡈࠤࡎࡖࡔࡗࠩࢇ")) or (l11111_opy_ == l1lll11_opy_ (u"ࠧࡍࡋ࡙ࡉ࡚ࠥࡖࠨ࢈")) or (l11111_opy_ == l1lll11_opy_ (u"ࠨࡎࡌ࡚ࡊࠦࡃࡉࡃࡑࡒࡊࡒࡓࠨࢉ")) or (l11111_opy_ == l1lll11_opy_ (u"ࠩࡏࡍ࡛ࡋࠧࢊ")) or (l11111_opy_ == l1lll11_opy_ (u"ࠪࡉࡓࡊࡌࡆࡕࡖࠤࡒࡋࡄࡊࡃࠪࢋ")) or (l11111_opy_ == l1lll11_opy_ (u"ࠫࡋࡒࡁࡘࡎࡈࡗࡘ࡚ࡖࠨࢌ")) or (l11111_opy_ == l1lll11_opy_ (u"ࠬࡓࡁ࡙ࡋ࡚ࡉࡇࠦࡔࡗࠩࢍ")) or (l11111_opy_ == l1lll11_opy_ (u"࠭ࡂࡍࡃࡆࡏࡎࡉࡅࠡࡖ࡙ࠫࢎ")) or (l11111_opy_ == l1lll11_opy_ (u"ࠧࡉࡑࡕࡍ࡟ࡕࡎࠡࡋࡓࡘ࡛࠭࢏")):
            livetv = file[l1lll11_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭࢐")]
            return l1l111_opy_(livetv)
def l1l111_opy_(livetv):
    response = doJSON(livetv)
    l1ll11_opy_    = response[l1lll11_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩ࢑")][l1lll11_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩ࢒")]
    for file in l1ll11_opy_:
        l11l11l_opy_ = file[l1lll11_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪ࢓")]
        l11111_opy_ = mapping.cleanLabel(l11l11l_opy_)
        l11111_opy_ = l11111_opy_.upper()
        if l11111_opy_ == l1lll11_opy_ (u"ࠬࡇࡌࡍࠩ࢔"):
            return file[l1lll11_opy_ (u"࠭ࡦࡪ࡮ࡨࠫ࢕")]
def l1l1l11_opy_(l1l1111_opy_):
    items = []
    _111l1l_opy_(l1l1111_opy_, items)
    return items
def _111l1l_opy_(l1l1111_opy_, items):
    response = doJSON(l1l1111_opy_)
    if response[l1lll11_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧ࢖")].has_key(l1lll11_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧࢗ")):
        result = response[l1lll11_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩ࢘")][l1lll11_opy_ (u"ࠪࡪ࡮ࡲࡥࡴ࢙ࠩ")]
        for item in result:
            if item[l1lll11_opy_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࢚࠭")] == l1lll11_opy_ (u"ࠬ࡬ࡩ࡭ࡧ࢛ࠪ"):
                l11111_opy_ = mapping.cleanLabel(item[l1lll11_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬ࢜")])
                items.append(item)
            elif item[l1lll11_opy_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ࢝")] == l1lll11_opy_ (u"ࠨࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠫ࢞"):
                l11111_opy_ = mapping.cleanLabel(item[l1lll11_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨ࢟")])
                l1llll11_opy_  = item[l1lll11_opy_ (u"ࠪࡪ࡮ࡲࡥࠨࢠ")]
                dixie.log(item)
                dixie.log(l1llll11_opy_)
                _111l1l_opy_(l1llll11_opy_, items)
def l111_opy_(url):
    if url.startswith(l1lll11_opy_ (u"ࠫࡎࡖࡌࡂ࡛࠽ࠫࢡ")):
        l1lll1ll_opy_ = (l1lll11_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡤࡥࡧ࡮ࡶ࡬ࡢࡻࡨࡶ࠴ࡅࡵࡳ࡮ࡀࡹࡷࡲࠦ࡮ࡱࡧࡩࡂ࠸ࠦ࡯ࡣࡰࡩࡂࡒࡩࡷࡧࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࡂࠬࡉࡑࡋࡇࡁࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࢢ"))
    if url.startswith(l1lll11_opy_ (u"࠭ࡉࡑࡎࡄ࡝࠷ࡀࠧࢣ")):
        l1lll1ll_opy_ = (l1lll11_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽ࠯ࡀࡷࡵࡰࡂࡻࡲ࡭ࠨࡰࡳࡩ࡫࠽࠲࠲࠴ࠪࡳࡧ࡭ࡦ࠿࡚ࡥࡹࡩࡨࠬࡎ࡬ࡺࡪࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࠩࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮࠾ࠨࡶࡹࡧࡺࡩࡵ࡮ࡨࡷࡤࡻࡲ࡭࠿ࠩࡰࡴ࡭ࡧࡦࡦࡢ࡭ࡳࡃࡆࡢ࡮ࡶࡩࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࢤ"))
    if url.startswith(l1lll11_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡒ࠻ࠩࢥ")):
        l1lll1ll_opy_ = (l1lll11_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰ࡭ࡣࡼࡩࡷࡽࡷࡸ࠱ࡂࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠧ࡮ࡲ࡫࡬࡫ࡤࡠ࡫ࡱࡁࡋࡧ࡬ࡴࡧࠩࡱࡴࡪࡥ࠾࠳࠴࠷ࠫࡴࡡ࡮ࡧࡀࡐ࡮ࡹࡴࡦࡰࠨ࠶࠵ࡒࡩࡷࡧࠩࡷࡺࡨࡴࡪࡶ࡯ࡩࡸࡥࡵࡳ࡮ࠩࡹࡷࡲ࠽ࡶࡴ࡯ࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩࢦ"))
    if url.startswith(l1lll11_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡋࡗ࡚࠿࠭ࢧ")):
        l1lll1ll_opy_ = (l1lll11_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡶࡹࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩࢨ"))
    if url.startswith(l1lll11_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡈ࠿࠭ࢩ")):
        l1lll1ll_opy_ = (l1lll11_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡧࡩࡽ࠵࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࡢ࡮࡯ࠪࡪࡾࡴࡳࡣࠩࡴࡦ࡭ࡥࠧࡲ࡯ࡳࡹࠬࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠿ࠩࡸ࡮ࡺ࡬ࡦ࠿ࠨ࠹ࡧࡉࡏࡍࡑࡕࠩ࠷࠶ࡷࡩ࡫ࡷࡩࠪ࠻ࡤࡂ࡮࡯ࠩ࠷࠶ࡃࡩࡣࡱࡲࡪࡲࡳࠦ࠷ࡥࠩ࠷࡬ࡃࡐࡎࡒࡖࠪ࠻ࡤࠧࡷࡵࡰࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࢪ"))
    if url.startswith(l1lll11_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡘࡂ࠻ࠩࢫ")):
        l1lll1ll_opy_ = (l1lll11_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷ࡫ࡢࡰࡱࡷ࠳ࡄࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠩࡪࡦࡴࡡࡳࡶࡀࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧ࡯ࡲࡨࡪࡃ࠷ࠧࡲ࡬ࡰࡱࡵࡷ࠾ࡎ࡬ࡺࡪࠫ࠲࠱ࡕࡷࡶࡪࡧ࡭ࡴࠨࡸࡶࡱࡃࡲࡢࡰࡧࡳࡲࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࢬ"))
    try:
        dixie.ShowBusy()
        addon =  l1lll1ll_opy_.split(l1lll11_opy_ (u"ࠩ࠲࠳ࠬࢭ"), 1)[-1].split(l1lll11_opy_ (u"ࠪ࠳ࠬࢮ"), 1)[0]
        login = l1lll11_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩࢯ") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1lll1ll_opy_)
        dixie.log(response)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1llllll_opy_(e)
        return {l1lll11_opy_ (u"ࠬࡋࡲࡳࡱࡵࠫࢰ") : l1lll11_opy_ (u"࠭ࡐ࡭ࡷࡪ࡭ࡳࠦࡅࡳࡴࡲࡶࠬࢱ")}
def l1lll1_opy_():
    modules = map(__import__, [l1l1lll1_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11l1_opy_)):
        return l1lll11_opy_ (u"ࠧࡕࡴࡸࡩࠬࢲ")
    if len(modules[-1].Window(10**4).getProperty(l111l_opy_)):
        return l1lll11_opy_ (u"ࠨࡖࡵࡹࡪ࠭ࢳ")
    return l1lll11_opy_ (u"ࠩࡉࡥࡱࡹࡥࠨࢴ")
def l1llllll_opy_(e):
    l1111l_opy_ = l1lll11_opy_ (u"ࠪࡗࡴࡸࡲࡺ࠮ࠣࡥࡳࠦࡥࡳࡴࡲࡶࠥࡵࡣࡤࡷࡵࡩࡩࡀࠠࡋࡕࡒࡒࠥࡋࡲࡳࡱࡵ࠾ࠥࠫࡳࠨࢵ")  %e
    l1llll_opy_ = l1lll11_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡷ࡫࠭࡭࡫ࡱ࡯ࠥࡺࡨࡪࡵࠣࡧ࡭ࡧ࡮࡯ࡧ࡯ࠤࡦࡴࡤࠡࡶࡵࡽࠥࡧࡧࡢ࡫ࡱ࠲ࠬࢶ")
    l1l1_opy_ = l1lll11_opy_ (u"࡛ࠬࡳࡦ࠼ࠣࡇࡴࡴࡴࡦࡺࡷࠤࡒ࡫࡮ࡶࠢࡀࡂࠥࡘࡥ࡮ࡱࡹࡩ࡙ࠥࡴࡳࡧࡤࡱࠬࢷ")
    dixie.log(e)
    dixie.DialogOK(l1111l_opy_, l1llll_opy_, l1l1_opy_)
if __name__ == l1lll11_opy_ (u"࠭࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠨࢸ"):
    checkAddons()