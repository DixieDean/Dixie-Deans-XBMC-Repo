# coding: UTF-8
import sys
l1l11ll_opy_ = sys.version_info [0] == 2
l1l11l1_opy_ = 2048
l1l1ll_opy_ = 7
def l1lll11_opy_ (ll_opy_):
	global l1ll1l_opy_
	l1lll11l_opy_ = ord (ll_opy_ [-1])
	l1l1ll1_opy_ = ll_opy_ [:-1]
	l111l1l_opy_ = l1lll11l_opy_ % len (l1l1ll1_opy_)
	l111111_opy_ = l1l1ll1_opy_ [:l111l1l_opy_] + l1l1ll1_opy_ [l111l1l_opy_:]
	if l1l11ll_opy_:
		l11ll11_opy_ = unicode () .join ([unichr (ord (char) - l1l11l1_opy_ - (l1lllll_opy_ + l1lll11l_opy_) % l1l1ll_opy_) for l1lllll_opy_, char in enumerate (l111111_opy_)])
	else:
		l11ll11_opy_ = str () .join ([chr (ord (char) - l1l11l1_opy_ - (l1lllll_opy_ + l1lll11l_opy_) % l1l1ll_opy_) for l1lllll_opy_, char in enumerate (l111111_opy_)])
	return eval (l11ll11_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
import mapping
ADDON    = dixie.ADDON
l111l1_opy_ = dixie.PROFILE
l11l11_opy_  = os.path.join(l111l1_opy_, l1lll11_opy_ (u"ࠫ࡮ࡴࡩࠨࠀ"))
l1lll1ll_opy_ = l1lll11_opy_ (u"ࠬ࠭ࠁ")
def l1ll111l_opy_(i, t1, l1lll1l1_opy_=[]):
 t = l1lll1ll_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1lll1l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11l1_opy_ = l1ll111l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l111l_opy_ = l1ll111l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1llll11_opy_      = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡳࡥࡨࡣ࡬ࡴࡹࡼࠧࠂ")
l11lll1_opy_  = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡦࡳࡧࡨࡺ࡮࡫ࡷࠨࠃ")
l11_opy_  = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡎࡣࡷࡷࡇࡻࡩ࡭ࡦࡶࡍࡕ࡚ࡖࠨࠄ")
l1lll1l_opy_  = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡸࡻࡹࡵࡣࡵࠪࠅ")
l1l1lll_opy_      = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡭࡭ࡳࡾࡴࡷ࠴ࠪࠆ")
l1ll11l_opy_  = l1lll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡴࡵࡴࡪࡲࡷࡺࠬࠇ")
l11111l_opy_   = l1lll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡊࡴࡤ࡭ࡧࡶࡷࠬࠈ")
l1ll1lll_opy_  = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡌ࡬ࡢࡹ࡯ࡩࡸࡹࡔࡷࠩࠉ")
l11ll1l_opy_   = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡭ࡢࡺ࡬ࡻࡪࡨࡴࡷࠩࠊ")
dexter    = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡥࡧࡻࠫࠋ")
l11ll_opy_     = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡘࡄࡈࡊࡘࠧࠌ")
l11ll1_opy_ = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡖࡹࡵࡸࡥ࡮ࡣࡦࡽ࡙࡜ࠧࠍ")
l1llll1_opy_     = l1lll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡱࡨࡱࡴࡷ࠯ࡳࡰࡺࡹࠧࠎ")
l1llll1l_opy_   = l1lll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡹࡽࡩࡴࡶࡨࡨࠬࠏ")
l11l1ll_opy_  = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡶࡳࡢࡦࡧࡳࡳ࠭ࠐ")
l1l1l1_opy_  = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡂ࡭ࡣࡦ࡯ࡎࡩࡥࡕࡘࠪࠑ")
l1ll11l1_opy_    = [l1llll11_opy_, l11lll1_opy_, l11_opy_, l1lll1l_opy_, l1l1lll_opy_, l1ll11l_opy_, l11111l_opy_, l1ll1lll_opy_, l11ll1l_opy_, dexter, l11ll_opy_, l11ll1_opy_, l1llll1_opy_, l1llll1l_opy_, l11l1ll_opy_, l1l1l1_opy_]
def checkAddons():
    for addon in l1ll11l1_opy_:
        if l1ll1l1l_opy_(addon):
            createINI(addon)
def l1ll1l1l_opy_(addon):
    if xbmc.getCondVisibility(l1lll11_opy_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫࠩࡸ࠯ࠧࠒ") % addon) == 1:
        return True
    return False
def createINI(addon):
    HOME  = dixie.PROFILE
    iPATH = os.path.join(HOME, l1lll11_opy_ (u"ࠩ࡬ࡲ࡮࠭ࠓ"))
    l11l11l_opy_  = str(addon).split(l1lll11_opy_ (u"ࠪ࠲ࠬࠔ"))[2] + l1lll11_opy_ (u"ࠫ࠳࡯࡮ࡪࠩࠕ")
    l1l_opy_   = os.path.join(iPATH, l11l11l_opy_)
    l11l1l_opy_   = os.path.join(iPATH, l1lll11_opy_ (u"ࠬࡳࡡࡱࡲ࡬ࡲ࡬ࡹ࠮࡫ࡵࡲࡲࠬࠖ"))
    LABELFILE = os.path.join(iPATH, l1lll11_opy_ (u"࠭࡬ࡢࡤࡨࡰࡸ࠴ࡪࡴࡱࡱࠫࠗ"))
    l111ll_opy_  = json.load(open(l11l1l_opy_))
    labelmaps = json.load(open(LABELFILE))
    response = l1_opy_(addon)
    l1ll1ll_opy_ = response[l1lll11_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧ࠘")][l1lll11_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧ࠙")]
    l1ll111_opy_  = l1lll11_opy_ (u"ࠩ࡞ࠫࠚ") + addon + l1lll11_opy_ (u"ࠪࡡࡡࡴࠧࠛ")
    l1l11_opy_  =  file(l1l_opy_, l1lll11_opy_ (u"ࠫࡼ࠭ࠜ"))
    l1l11_opy_.write(l1ll111_opy_)
    l1ll11ll_opy_ = []
    for channel in l1ll1ll_opy_:
        l11lll_opy_ = l1l11l_opy_(addon)
        l1lll_opy_  = channel[l1lll11_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫࠝ")].split(l1lll11_opy_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࠞ"), 1)[0]
        if addon == dexter:
            l1lll_opy_ = l1lll_opy_.split(l1lll11_opy_ (u"ࠧࠡ࠭ࠣࠫࠟ"), 1)[0]
        l111lll_opy_  = l11llll_opy_(l1lll_opy_)
        l1l1l_opy_  = l1lll111_opy_(labelmaps, l111ll_opy_, l1lll_opy_)
        stream  = l11lll_opy_ + l111lll_opy_
        l1111_opy_ = l1l1l_opy_  + l1lll11_opy_ (u"ࠨ࠿ࠪࠠ") + stream
        if l1111_opy_ not in l1ll11ll_opy_:
            l1ll11ll_opy_.append(l1111_opy_)
    l1ll11ll_opy_.sort()
    for item in l1ll11ll_opy_:
        l1l11_opy_.write(l1lll11_opy_ (u"ࠤࠨࡷࡡࡴࠢࠡ") % item)
    l1l11_opy_.close()
def l11llll_opy_(l1lll_opy_):
    l1ll1ll1_opy_ = mapping.cleanLabel(l1lll_opy_)
    l111lll_opy_ = mapping.cleanStreamLabel(l1ll1ll1_opy_)
    return l111lll_opy_
def l1lll111_opy_(labelmaps, l111ll_opy_, l1lll_opy_):
    l11111_opy_    = mapping.cleanLabel(l1lll_opy_)
    l1ll1ll1_opy_ = mapping.mapLabel(labelmaps, l11111_opy_)
    l1l1l_opy_ = mapping.cleanPrefix(l1ll1ll1_opy_)
    return mapping.mapChannelName(l111ll_opy_, l1l1l_opy_)
def l1ll_opy_(addon, file):
    l11111_opy_ = file[l1lll11_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࠢ")].split(l1lll11_opy_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠣ"), 1)[0]
    l11111_opy_ = l11111_opy_.split(l1lll11_opy_ (u"ࠬ࠱ࠧࠤ"), 1)[0]
    l11111_opy_ = mapping.cleanLabel(l11111_opy_)
    return l11111_opy_
def l1l11l_opy_(addon):
    if addon == l1llll11_opy_:
        return l1lll11_opy_ (u"࠭ࡍࡆࡉࡄ࠾ࠬࠥ")
    if addon == l11lll1_opy_:
        return l1lll11_opy_ (u"ࠧࡇࡔࡈࡉ࠿࠭ࠦ")
    if addon == l11_opy_:
        return l1lll11_opy_ (u"ࠨࡏࡄࡘࡘࡀࠧࠧ")
    if addon == l1lll1l_opy_:
        return l1lll11_opy_ (u"ࠩࡌࡔ࡙࡙࠺ࠨࠨ")
    if addon == l1l1lll_opy_:
        return l1lll11_opy_ (u"ࠪࡎࡎࡔࡘ࠳࠼ࠪࠩ")
    if addon == l1ll11l_opy_:
        return l1lll11_opy_ (u"ࠫࡗࡕࡏࡕ࠼ࠪࠪ")
    if addon == l11111l_opy_:
        return l1lll11_opy_ (u"ࠬࡋࡎࡅ࠼ࠪࠫ")
    if addon == l1ll1lll_opy_:
        return l1lll11_opy_ (u"࠭ࡆࡍࡃ࠽ࠫࠬ")
    if addon == l11ll1l_opy_:
        return l1lll11_opy_ (u"ࠧࡎࡃ࡛ࡍ࠿࠭࠭")
    if addon == dexter:
        return l1lll11_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡄ࠻ࠩ࠮")
    if addon == l11ll_opy_:
        return l1lll11_opy_ (u"࡙ࠩࡈࡗ࡚ࡖ࠻ࠩ࠯")
    if addon == l11ll1_opy_:
        return l1lll11_opy_ (u"ࠪࡗࡕࡘࡍ࠻ࠩ࠰")
    if addon == l1llll1_opy_:
        return l1lll11_opy_ (u"ࠫࡒࡉࡋࡕࡘ࠽ࠫ࠱")
    if addon == l1llll1l_opy_:
        return l1lll11_opy_ (u"࡚ࠬࡗࡊࡕࡗ࠾ࠬ࠲")
    if addon == l11l1ll_opy_:
        return l1lll11_opy_ (u"࠭ࡐࡓࡇࡖࡘ࠿࠭࠳")
    if addon == l1l1l1_opy_:
        return l1lll11_opy_ (u"ࠧࡃࡎࡎࡍ࠿࠭࠴")
def getURL(url):
    if url.startswith(l1lll11_opy_ (u"ࠨࡏࡈࡋࡆ࠭࠵")):
        return l11l_opy_(url, l1llll11_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠩࡉࡖࡊࡋࠧ࠶")):
        return l11l_opy_(url, l11lll1_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡅࡏ࡙࠿࠭࠷")):
        url = url.replace(l1lll11_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡆࡐ࡚ࡀࠧ࠸"), l1lll11_opy_ (u"ࠬ࠭࠹")).replace(l1lll11_opy_ (u"࠭࠭࠮ࡷࡶࡩࡷ࠳ࡡࡨࡧࡱࡸࠬ࠺"), l1lll11_opy_ (u"ࠧࡽࡷࡶࡩࡷ࠳ࡡࡨࡧࡱࡸࠬ࠻"))
        return url
    if url.startswith(l1lll11_opy_ (u"ࠨࡏࡄࡘࡘ࠭࠼")):
        return l11l_opy_(url, l11_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠩࡌࡔ࡙࡙ࠧ࠽")):
        return l11l_opy_(url, l1lll1l_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠪࡎࡎࡔࡘ࠳ࠩ࠾")):
        return l11l_opy_(url, l1l1lll_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠫࡗࡕࡏࡕࠩ࠿")):
        return l11l_opy_(url, l1ll11l_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡈࠬࡀ")):
        return l11l_opy_(url, dexter)
    if url.startswith(l1lll11_opy_ (u"࠭ࡆࡍࡃࠪࡁ")):
        return l11l_opy_(url, l1ll1lll_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠧࡎࡃ࡛ࡍࠬࡂ")):
        return l11l_opy_(url, l11ll1l_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠨࡇࡑࡈࠬࡃ")):
        return l11l_opy_(url, l11111l_opy_)
    if url.startswith(l1lll11_opy_ (u"࡙ࠩࡈࡗ࡚ࡖࠨࡄ")):
        return l11l_opy_(url, l11ll_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠪࡗࡕࡘࡍࠨࡅ")):
        return l11l_opy_(url, l11ll1_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠫࡒࡉࡋࡕࡘࠪࡆ")):
        return l11l_opy_(url, l1llll1_opy_)
    if url.startswith(l1lll11_opy_ (u"࡚ࠬࡗࡊࡕࡗࠫࡇ")):
        return l11l_opy_(url, l1llll1l_opy_)
    if url.startswith(l1lll11_opy_ (u"࠭ࡐࡓࡇࡖࡘࠬࡈ")):
        return l11l_opy_(url, l11l1ll_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠧࡃࡎࡎࡍࠬࡉ")):
        return l11l_opy_(url, l1l1l1_opy_)
    response  = l111_opy_(url)
    l1l1l11_opy_ = url.split(l1lll11_opy_ (u"ࠨ࠼ࠪࡊ"), 1)[-1]
    try:
        result = response[l1lll11_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩࡋ")]
        l1ll11_opy_  = result[l1lll11_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩࡌ")]
    except Exception as e:
        l1111l1_opy_(e)
        return None
    for file in l1ll11_opy_:
        l1lll_opy_  = file[l1lll11_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪࡍ")].split(l1lll11_opy_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࡎ"), 1)[0]
        l111l11_opy_  = l1lll_opy_.split(l1lll11_opy_ (u"࠭ࠫࠨࡏ"), 1)[0]
        l1111ll_opy_ = mapping.cleanLabel(l111l11_opy_)
        try:
            if l1l1l11_opy_ == l1111ll_opy_:
                return file[l1lll11_opy_ (u"ࠧࡧ࡫࡯ࡩࠬࡐ")]
        except:
            if (l1l1l11_opy_ in l1111ll_opy_) or (l1111ll_opy_ in l1l1l11_opy_):
                return file[l1lll11_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ࡑ")]
    return None
def l11l_opy_(url, addon):
    PATH = l1ll1_opy_(addon)
    try:
        response = json.load(open(PATH))
    except:
        response = l1_opy_(addon)
    l1ll1l11_opy_      = url.split(l1lll11_opy_ (u"ࠩ࠽ࠫࡒ"), 1)[-1]
    stream    = l1ll1l11_opy_.split(l1lll11_opy_ (u"ࠪࠤࡠ࠭ࡓ"), 1)[0]
    l1l1l11_opy_ = mapping.cleanLabel(stream)
    l1ll11_opy_  = response[l1lll11_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫࡔ")][l1lll11_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫࡕ")]
    for file in l1ll11_opy_:
        l1lll_opy_  = file[l1lll11_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬࡖ")].split(l1lll11_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࡗ"), 1)[0]
        if addon == dexter:
            l1lll_opy_ = l1lll_opy_.split(l1lll11_opy_ (u"ࠨࠢ࠮ࠤࠬࡘ"), 1)[0]
        l1111ll_opy_ = l11llll_opy_(l1lll_opy_)
        try:
            if l1l1l11_opy_ == l1111ll_opy_:
                return file[l1lll11_opy_ (u"ࠩࡩ࡭ࡱ࡫࡙ࠧ")]
        except:
            if (l1l1l11_opy_ in l1111ll_opy_) or (l1111ll_opy_ in l1l1l11_opy_):
                return file[l1lll11_opy_ (u"ࠪࡪ࡮ࡲࡥࠨ࡚")]
            if l1lll11_opy_ (u"࡚࡙ࠫࡁ࠰ࡅࡄ࠾࡛ࠬ") in l1111ll_opy_:
                l1l1111_opy_ = l1111ll_opy_.replace(l1lll11_opy_ (u"࡛ࠬࡓࡂ࠱ࡆࡅ࠿࠭࡜"), l1lll11_opy_ (u"࠭ࡕࡔࡃ࠽ࠫ࡝"))
                if dixie.fuzzyMatch(l1l1l11_opy_, l1l1111_opy_):
                    return file[l1lll11_opy_ (u"ࠧࡧ࡫࡯ࡩࠬ࡞")]
    return None
def l1_opy_(addon):
    PATH  = l1ll1_opy_(addon)
    if addon == l11ll_opy_:
        query = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡙ࡅࡉࡋࡒ࠰࡮࡬ࡺࡪࡺࡶ࠰ࡣ࡯ࡰ࠴࠭࡟")
    elif addon == l11lll1_opy_:
        query = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡪࡷ࡫ࡥࡷ࡫ࡨࡻ࠴ࡅࡵࡳ࡮ࡀࡹࡷࡲࠦ࡮ࡱࡧࡩࡂ࠻ࠦ࡯ࡣࡰࡩࡂࡒࡩࡷࡧ࠮ࡘ࡛࠭ࡠ")
    else:
        query = l11l111_opy_(addon)
    try:
        return json.load(open(PATH))
    except:
        content = doJSON(query)
        return l1ll1l1_opy_(PATH, addon, content)
def l1ll1l1_opy_(PATH, addon, content):
    json.dump(content, open(PATH,l1lll11_opy_ (u"ࠪࡻࠬࡡ")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    l1lllll1_opy_  = (l1lll11_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࠥࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࡢ") % query)
    response = xbmc.executeJSONRPC(l1lllll1_opy_)
    content  = json.loads(response)
    return content
def l1ll1_opy_(addon):
    if addon == l1llll11_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠬࡳࡥࡨࡣࡷࡱࡵ࠭ࡣ"))
    if addon == l11_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"࠭࡭ࡢࡶࡶࡸࡲࡶࠧࡤ"))
    if addon == l11lll1_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠧࡧࡴࡨࡩࡹࡳࡰࠨࡥ"))
    if addon == l1lll1l_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠨ࡫ࡳࡸࡸࡺ࡭ࡱࠩࡦ"))
    if addon == l1l1lll_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠩ࡭࠶ࡹ࡫࡭ࡱࠩࡧ"))
    if addon == l1ll11l_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠪࡶࡴࡺࡥ࡮ࡲࠪࡨ"))
    if addon == l11111l_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠫࡪࡺࡥ࡮ࡲࠪࡩ"))
    if addon == l1ll1lll_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠬ࡬ࡴࡦ࡯ࡳࠫࡪ"))
    if addon == l11ll1l_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"࠭࡭ࡢࡺࡷࡩࡲࡶࠧ࡫"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠧࡥࡶࡨࡱࡵ࠭࡬"))
    if addon == l11ll_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠨࡸࡧࡸࡪࡳࡰࠨ࡭"))
    if addon == l11ll1_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠩࡶࡴࡷࡺࡥ࡮ࡲࠪ࡮"))
    if addon == l1llll1_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠪࡱࡨࡱࡴࡦ࡯ࡳࠫ࡯"))
    if addon == l1llll1l_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠫࡹࡽࡩࡵࡧࡰࡴࠬࡰ"))
    if addon == l11l1ll_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠬࡶࡲࡦࡵࡷࡩࡲࡶࠧࡱ"))
    if addon == l1l1l1_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"࠭ࡢ࡭࡭࡬ࡸࡪࡳࡰࠨࡲ"))
def l11l111_opy_(addon):
    query = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪࡳ") + addon
    response = doJSON(query)
    l1ll11_opy_    = response[l1lll11_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨࡴ")][l1lll11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨࡵ")]
    for file in l1ll11_opy_:
        l11l1l1_opy_ = file[l1lll11_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࡶ")]
        l11111_opy_ = mapping.cleanLabel(l11l1l1_opy_)
        l11111_opy_ = l11111_opy_.upper()
        if (l11111_opy_ == l1lll11_opy_ (u"ࠫࡑࡏࡖࡆࠢࡌࡔ࡙࡜ࠧࡷ")) or (l11111_opy_ == l1lll11_opy_ (u"ࠬࡒࡉࡗࡇࠣࡘ࡛࠭ࡸ")) or (l11111_opy_ == l1lll11_opy_ (u"࠭ࡌࡊࡘࡈࠤࡈࡎࡁࡏࡐࡈࡐࡘ࠭ࡹ")) or (l11111_opy_ == l1lll11_opy_ (u"ࠧࡍࡋ࡙ࡉࠬࡺ")) or (l11111_opy_ == l1lll11_opy_ (u"ࠨࡇࡑࡈࡑࡋࡓࡔࠢࡐࡉࡉࡏࡁࠨࡻ")) or (l11111_opy_ == l1lll11_opy_ (u"ࠩࡉࡐࡆ࡝ࡌࡆࡕࡖࡘ࡛࠭ࡼ")) or (l11111_opy_ == l1lll11_opy_ (u"ࠪࡑࡆ࡞ࡉࡘࡇࡅࠤ࡙࡜ࠧࡽ")) or (l11111_opy_ == l1lll11_opy_ (u"ࠫࡇࡒࡁࡄࡍࡌࡇࡊࠦࡔࡗࠩࡾ")):
            livetv = file[l1lll11_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪࡿ")]
            return l1l111_opy_(livetv)
def l1l111_opy_(livetv):
    response = doJSON(livetv)
    l1ll11_opy_    = response[l1lll11_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࢀ")][l1lll11_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࢁ")]
    for file in l1ll11_opy_:
        l11l1l1_opy_ = file[l1lll11_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࢂ")]
        l11111_opy_ = mapping.cleanLabel(l11l1l1_opy_)
        l11111_opy_ = l11111_opy_.upper()
        if l11111_opy_ == l1lll11_opy_ (u"ࠩࡄࡐࡑ࠭ࢃ"):
            return file[l1lll11_opy_ (u"ࠪࡪ࡮ࡲࡥࠨࢄ")]
def l1l1l1l_opy_(l1l111l_opy_):
    items = []
    _111ll1_opy_(l1l111l_opy_, items)
    return items
def _111ll1_opy_(l1l111l_opy_, items):
    response = doJSON(l1l111l_opy_)
    if response[l1lll11_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫࢅ")].has_key(l1lll11_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫࢆ")):
        result = response[l1lll11_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࢇ")][l1lll11_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭࢈")]
        for item in result:
            if item[l1lll11_opy_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪࢉ")] == l1lll11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧࢊ"):
                l11111_opy_ = mapping.cleanLabel(item[l1lll11_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࢋ")])
                items.append(item)
            elif item[l1lll11_opy_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭ࢌ")] == l1lll11_opy_ (u"ࠬࡪࡩࡳࡧࡦࡸࡴࡸࡹࠨࢍ"):
                l11111_opy_ = mapping.cleanLabel(item[l1lll11_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬࢎ")])
                l1llllll_opy_  = item[l1lll11_opy_ (u"ࠧࡧ࡫࡯ࡩࠬ࢏")]
                dixie.log(item)
                dixie.log(l1llllll_opy_)
                _111ll1_opy_(l1llllll_opy_, items)
def l111_opy_(url):
    if url.startswith(l1lll11_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠺ࠨ࢐")):
        l1lllll1_opy_ = (l1lll11_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡨࡢࡤ࡫ࡳࡰࡦࡿࡥࡳ࠱ࡂࡹࡷࡲ࠽ࡶࡴ࡯ࠪࡲࡵࡤࡦ࠿࠵ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡻ࡫ࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠩࡍࡕࡏࡄ࠾ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧ࢑"))
    if url.startswith(l1lll11_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠴࠽ࠫ࢒")):
        l1lllll1_opy_ = (l1lll11_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺ࠳ࡄࡻࡲ࡭࠿ࡸࡶࡱࠬ࡭ࡰࡦࡨࡁ࠶࠶࠱ࠧࡰࡤࡱࡪࡃࡗࡢࡶࡦ࡬࠰ࡒࡩࡷࡧࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࡂࠬࡳࡶࡤࡷ࡭ࡹࡲࡥࡴࡡࡸࡶࡱࡃࠦ࡭ࡱࡪ࡫ࡪࡪ࡟ࡪࡰࡀࡊࡦࡲࡳࡦࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧ࢓"))
    if url.startswith(l1lll11_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖ࠿࠭࢔")):
        l1lllll1_opy_ = (l1lll11_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠵࠿ࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠫࡲ࡯ࡨࡩࡨࡨࡤ࡯࡮࠾ࡈࡤࡰࡸ࡫ࠦ࡮ࡱࡧࡩࡂ࠷࠱࠴ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡶࡸࡪࡴࠥ࠳࠲ࡏ࡭ࡻ࡫ࠦࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡵࡢࡹࡷࡲࠦࡶࡴ࡯ࡁࡺࡸ࡬ࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭࢕"))
    if url.startswith(l1lll11_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡏࡔࡗ࠼ࠪ࢖")):
        l1lllll1_opy_ = (l1lll11_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡺࡶࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ࢗ"))
    if url.startswith(l1lll11_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪ࢘")):
        l1lllll1_opy_ = (l1lll11_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡤࡦࡺ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡦࡲ࡬ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠦࡵ࡫ࡷࡰࡪࡃࠥ࠶ࡤࡆࡓࡑࡕࡒࠦ࠴࠳ࡻ࡭࡯ࡴࡦࠧ࠸ࡨࡆࡲ࡬ࠦ࠴࠳ࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠪ࠻ࡢࠦ࠴ࡩࡇࡔࡒࡏࡓࠧ࠸ࡨࠫࡻࡲ࡭ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃ࢙ࠧ"))
    if url.startswith(l1lll11_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡕࡆ࠿࢚࠭")):
        l1lllll1_opy_ = (l1lll11_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡨࡦࡴࡵࡴ࠰ࡁࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠦࡧࡣࡱࡥࡷࡺ࠽ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡳ࡯ࡥࡧࡀ࠻ࠫࡶࡩ࡭࡮ࡲࡻࡂࡒࡩࡷࡧࠨ࠶࠵࡙ࡴࡳࡧࡤࡱࡸࠬࡵࡳ࡮ࡀࡶࡦࡴࡤࡰ࡯ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ࢛"))
    try:
        dixie.ShowBusy()
        addon =  l1lllll1_opy_.split(l1lll11_opy_ (u"࠭࠯࠰ࠩ࢜"), 1)[-1].split(l1lll11_opy_ (u"ࠧ࠰ࠩ࢝"), 1)[0]
        login = l1lll11_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭࢞") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1lllll1_opy_)
        dixie.log(response)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1111l1_opy_(e)
        return {l1lll11_opy_ (u"ࠩࡈࡶࡷࡵࡲࠨ࢟") : l1lll11_opy_ (u"ࠪࡔࡱࡻࡧࡪࡰࠣࡉࡷࡸ࡯ࡳࠩࢠ")}
def l1lll1_opy_():
    modules = map(__import__, [l1ll111l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11l1_opy_)):
        return l1lll11_opy_ (u"࡙ࠫࡸࡵࡦࠩࢡ")
    if len(modules[-1].Window(10**4).getProperty(l111l_opy_)):
        return l1lll11_opy_ (u"࡚ࠬࡲࡶࡧࠪࢢ")
    return l1lll11_opy_ (u"࠭ࡆࡢ࡮ࡶࡩࠬࢣ")
def l1111l1_opy_(e):
    l1111l_opy_ = l1lll11_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠲ࠠࡢࡰࠣࡩࡷࡸ࡯ࡳࠢࡲࡧࡨࡻࡲࡦࡦ࠽ࠤࡏ࡙ࡏࡏࠢࡈࡶࡷࡵࡲ࠻ࠢࠨࡷࠬࢤ")  %e
    l1llll_opy_ = l1lll11_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡴࡨ࠱ࡱ࡯࡮࡬ࠢࡷ࡬࡮ࡹࠠࡤࡪࡤࡲࡳ࡫࡬ࠡࡣࡱࡨࠥࡺࡲࡺࠢࡤ࡫ࡦ࡯࡮࠯ࠩࢥ")
    l1l1_opy_ = l1lll11_opy_ (u"ࠩࡘࡷࡪࡀࠠࡄࡱࡱࡸࡪࡾࡴࠡࡏࡨࡲࡺࠦ࠽࠿ࠢࡕࡩࡲࡵࡶࡦࠢࡖࡸࡷ࡫ࡡ࡮ࠩࢦ")
    dixie.log(e)
    dixie.DialogOK(l1111l_opy_, l1llll_opy_, l1l1_opy_)
if __name__ == l1lll11_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬࢧ"):
    checkAddons()