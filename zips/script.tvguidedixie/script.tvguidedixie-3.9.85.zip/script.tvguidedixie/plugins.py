# coding: UTF-8
import sys
l1l11ll_opy_ = sys.version_info [0] == 2
l1l11l1_opy_ = 2048
l1l1ll_opy_ = 7
def l1lll11_opy_ (ll_opy_):
	global l1ll1l_opy_
	l1lll11l_opy_ = ord (ll_opy_ [-1])
	l1l1ll1_opy_ = ll_opy_ [:-1]
	l111l1l_opy_ = l1lll11l_opy_ % len (l1l1ll1_opy_)
	l111111_opy_ = l1l1ll1_opy_ [:l111l1l_opy_] + l1l1ll1_opy_ [l111l1l_opy_:]
	if l1l11ll_opy_:
		l11ll11_opy_ = unicode () .join ([unichr (ord (char) - l1l11l1_opy_ - (l1lllll_opy_ + l1lll11l_opy_) % l1l1ll_opy_) for l1lllll_opy_, char in enumerate (l111111_opy_)])
	else:
		l11ll11_opy_ = str () .join ([chr (ord (char) - l1l11l1_opy_ - (l1lllll_opy_ + l1lll11l_opy_) % l1l1ll_opy_) for l1lllll_opy_, char in enumerate (l111111_opy_)])
	return eval (l11ll11_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l11ll1ll1_opy_     = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡯ࡶࡹࠫइ")
l11ll111l_opy_  = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡹ࡯࡭ࡵࡺࡶࠨई")
l1l11111l_opy_     = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸ࡯ࡹࡻࡲ࡬ࠩउ")
locked  = l1lll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰࡴࡩ࡫ࡦࡦࡷࡺࠬऊ")
l11l1ll1l_opy_      = l1lll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡲࡴࡪ࡯ࡤࡸࡪࡳࡡ࡯࡫ࡤࠫऋ")
l11l1llll_opy_    = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲࡩࡶࡺ࠱ࡸࡻ࠭ऌ")
l11ll11ll_opy_     = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡄࡄࡕࡳࡳࡷࡺࡳࠨऍ")
l1l111111_opy_  = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡧࡥࡳࡴࡺࠧऎ")
l11ll1l11_opy_     = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡥ࡯ࡹ࡮ࡶࡴࡷࠩए")
l11llllll_opy_ = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸ࡯ࡹࡼ࠴ࡦࡺࡳࡥࡹࡹ࠮ࡤࡱࡰࠫऐ")
l1ll11l1_opy_ = [l11ll1ll1_opy_, locked, l11l1llll_opy_, l11ll111l_opy_, l11llllll_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1lll11_opy_ (u"ࠫ࡮ࡴࡩࠨऑ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1lll1ll_opy_ = l1lll11_opy_ (u"ࠬ࠭ऒ")
def l1ll111l_opy_(i, t1, l1lll1l1_opy_=[]):
 t = l1lll1ll_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1lll1l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11l1_opy_ = l1ll111l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l111l_opy_ = l1ll111l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1ll11l1_opy_:
        if l1ll1l1l_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1ll1l1l_opy_(addon):
    if xbmc.getCondVisibility(l1lll11_opy_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡈࡢࡵࡄࡨࡩࡵ࡮ࠩࠧࡶ࠭ࠬओ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l11l11l_opy_ = str(addon).split(l1lll11_opy_ (u"ࠧ࠯ࠩऔ"))[2] + l1lll11_opy_ (u"ࠨ࠰࡬ࡲ࡮࠭क")
    l1l_opy_  = os.path.join(PATH, l11l11l_opy_)
    try:
        l1ll1ll_opy_ = l1_opy_(addon)
    except KeyError:
        dixie.log(l1lll11_opy_ (u"ࠩ࠰࠱࠲࠳࠭ࠡࡍࡨࡽࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡧࡦࡶࡉ࡭ࡱ࡫ࡳࠡ࠯࠰࠱࠲࠳ࠠࠨख") + addon)
        result = {l1lll11_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࡵࠪग"): [{l1lll11_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧघ"): l1lll11_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࠫङ"), l1lll11_opy_ (u"ࡻࠧࡵࡻࡳࡩࠬच"): l1lll11_opy_ (u"ࡵࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩछ"), l1lll11_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࠧज"): l1lll11_opy_ (u"ࡷࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡾࡸࠨझ"), l1lll11_opy_ (u"ࡸࠫࡱࡧࡢࡦ࡮ࠪञ"): l1lll11_opy_ (u"ࡹࠬࡔࡏࠡࡅࡋࡅࡓࡔࡅࡍࡕࠪट")}], l1lll11_opy_ (u"ࡺ࠭࡬ࡪ࡯࡬ࡸࡸ࠭ठ"):{l1lll11_opy_ (u"ࡻࠧࡴࡶࡤࡶࡹ࠭ड"): 0, l1lll11_opy_ (u"ࡵࠨࡶࡲࡸࡦࡲࠧढ"): 1, l1lll11_opy_ (u"ࡶࠩࡨࡲࡩ࠭ण"): 1}}
    l1ll111_opy_  = l1lll11_opy_ (u"ࠩ࡞ࠫत") + addon + l1lll11_opy_ (u"ࠪࡡࡡࡴࠧथ")
    l1l11_opy_  =  file(l1l_opy_, l1lll11_opy_ (u"ࠫࡼ࠭द"))
    l1l11_opy_.write(l1ll111_opy_)
    l1ll11ll_opy_ = []
    for channel in l1ll1ll_opy_:
        l1l1111ll_opy_ = dixie.cleanLabel(channel[l1lll11_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫध")])
        l1ll1ll1_opy_   = dixie.cleanPrefix(l1l1111ll_opy_)
        l1l1l_opy_ = dixie.mapChannelName(l1ll1ll1_opy_)
        stream   = channel[l1lll11_opy_ (u"࠭ࡦࡪ࡮ࡨࠫन")]
        l1111_opy_ = l1l1l_opy_ + l1lll11_opy_ (u"ࠧ࠾ࠩऩ") + stream
        l1ll11ll_opy_.append(l1111_opy_)
        l1ll11ll_opy_.sort()
    for item in l1ll11ll_opy_:
        l1l11_opy_.write(l1lll11_opy_ (u"ࠣࠧࡶࡠࡳࠨप") % item)
    l1l11_opy_.close()
def l1_opy_(addon):
    if (addon == l11ll1ll1_opy_) or (addon == l11ll111l_opy_):
        if xbmcaddon.Addon(addon).getSetting(l1lll11_opy_ (u"ࠩࡪࡩࡳࡸࡥࠨफ")) == l1lll11_opy_ (u"ࠪࡸࡷࡻࡥࠨब"):
            xbmcaddon.Addon(addon).setSetting(l1lll11_opy_ (u"ࠫ࡬࡫࡮ࡳࡧࠪभ"), l1lll11_opy_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫम"))
            xbmcgui.Window(10000).setProperty(l1lll11_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡇࡆࡐࡕࡉࠬय"), l1lll11_opy_ (u"ࠧࡕࡴࡸࡩࠬर"))
        if xbmcaddon.Addon(addon).getSetting(l1lll11_opy_ (u"ࠨࡶࡹ࡫ࡺ࡯ࡤࡦࠩऱ")) == l1lll11_opy_ (u"ࠩࡷࡶࡺ࡫ࠧल"):
            xbmcaddon.Addon(addon).setSetting(l1lll11_opy_ (u"ࠪࡸࡻ࡭ࡵࡪࡦࡨࠫळ"), l1lll11_opy_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪऴ"))
            xbmcgui.Window(10000).setProperty(l1lll11_opy_ (u"ࠬࡖࡌࡖࡉࡌࡒࡤ࡚ࡖࡈࡗࡌࡈࡊ࠭व"), l1lll11_opy_ (u"࠭ࡔࡳࡷࡨࠫश"))
        l11ll1111_opy_  = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪष") + addon
        l11llll1l_opy_ =  l1l111l11_opy_(addon)
        query   =  l11ll1111_opy_ + l11llll1l_opy_
        return sendJSON(query, addon)
    return l11lll11l_opy_(addon)
def l11lll11l_opy_(addon):
    if addon == l11llllll_opy_:
        l11lll1l1_opy_ = [l1lll11_opy_ (u"ࠨ࠳࠹࠵ࠬस"), l1lll11_opy_ (u"ࠩ࠴࠺࠵࠭ह"), l1lll11_opy_ (u"ࠪ࠶࠸࠼ࠧऺ"), l1lll11_opy_ (u"ࠫ࠷࠺࠲ࠨऻ"), l1lll11_opy_ (u"ࠬ࠷࠵࠹़ࠩ"), l1lll11_opy_ (u"࠭࠱࠶࠻ࠪऽ")]
    if addon == l11l1llll_opy_:
        l11lll1l1_opy_ = [l1lll11_opy_ (u"ࠧ࠶ࠩा"), l1lll11_opy_ (u"ࠨ࠳࠳࠺ࠬि"), l1lll11_opy_ (u"ࠩ࠷ࠫी"), l1lll11_opy_ (u"ࠪ࠶࠻࠹ࠧु"), l1lll11_opy_ (u"ࠫ࠶࠹࠲ࠨू")]
    if addon == locked:
        l11lll1l1_opy_ = [l1lll11_opy_ (u"ࠬ࠹࠰ࠨृ"), l1lll11_opy_ (u"࠭࠳࠲ࠩॄ"), l1lll11_opy_ (u"ࠧ࠴࠴ࠪॅ"), l1lll11_opy_ (u"ࠨ࠵࠶ࠫॆ"), l1lll11_opy_ (u"ࠩ࠶࠸ࠬे"), l1lll11_opy_ (u"ࠪ࠷࠺࠭ै"), l1lll11_opy_ (u"ࠫ࠸࠾ࠧॉ"), l1lll11_opy_ (u"ࠬ࠺࠰ࠨॊ"), l1lll11_opy_ (u"࠭࠴࠲ࠩो"), l1lll11_opy_ (u"ࠧ࠵࠷ࠪौ"), l1lll11_opy_ (u"ࠨ࠶࠺्ࠫ"), l1lll11_opy_ (u"ࠩ࠷࠽ࠬॎ"), l1lll11_opy_ (u"ࠪ࠹࠷࠭ॏ")]
    if addon == l11l1ll1l_opy_:
        l11lll1l1_opy_ = [l1lll11_opy_ (u"ࠫ࠷࠻ࠧॐ"), l1lll11_opy_ (u"ࠬ࠸࠶ࠨ॑"), l1lll11_opy_ (u"࠭࠲࠸॒ࠩ"), l1lll11_opy_ (u"ࠧ࠳࠻ࠪ॓"), l1lll11_opy_ (u"ࠨ࠵࠳ࠫ॔"), l1lll11_opy_ (u"ࠩ࠶࠵ࠬॕ"), l1lll11_opy_ (u"ࠪ࠷࠷࠭ॖ"), l1lll11_opy_ (u"ࠫ࠸࠻ࠧॗ"), l1lll11_opy_ (u"ࠬ࠹࠶ࠨक़"), l1lll11_opy_ (u"࠭࠳࠸ࠩख़"), l1lll11_opy_ (u"ࠧ࠴࠺ࠪग़"), l1lll11_opy_ (u"ࠨ࠵࠼ࠫज़"), l1lll11_opy_ (u"ࠩ࠷࠴ࠬड़"), l1lll11_opy_ (u"ࠪ࠸࠶࠭ढ़"), l1lll11_opy_ (u"ࠫ࠹࠾ࠧफ़"), l1lll11_opy_ (u"ࠬ࠺࠹ࠨय़"), l1lll11_opy_ (u"࠭࠵࠱ࠩॠ"), l1lll11_opy_ (u"ࠧ࠶࠴ࠪॡ"), l1lll11_opy_ (u"ࠨ࠷࠷ࠫॢ"), l1lll11_opy_ (u"ࠩ࠸࠺ࠬॣ"), l1lll11_opy_ (u"ࠪ࠹࠼࠭।"), l1lll11_opy_ (u"ࠫ࠺࠾ࠧ॥"), l1lll11_opy_ (u"ࠬ࠻࠹ࠨ०"), l1lll11_opy_ (u"࠭࠶࠱ࠩ१"), l1lll11_opy_ (u"ࠧ࠷࠳ࠪ२"), l1lll11_opy_ (u"ࠨ࠸࠵ࠫ३"), l1lll11_opy_ (u"ࠩ࠹࠷ࠬ४"), l1lll11_opy_ (u"ࠪ࠺࠺࠭५"), l1lll11_opy_ (u"ࠫ࠻࠼ࠧ६"), l1lll11_opy_ (u"ࠬ࠼࠷ࠨ७"), l1lll11_opy_ (u"࠭࠶࠺ࠩ८"), l1lll11_opy_ (u"ࠧ࠸࠲ࠪ९"), l1lll11_opy_ (u"ࠨ࠹࠷ࠫ॰"), l1lll11_opy_ (u"ࠩ࠺࠻ࠬॱ"), l1lll11_opy_ (u"ࠪ࠻࠽࠭ॲ"), l1lll11_opy_ (u"ࠫ࠽࠶ࠧॳ"), l1lll11_opy_ (u"ࠬ࠾࠱ࠨॴ")]
    login = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶ࠳ࠬॵ") % addon
    sendJSON(login, addon)
    l1ll11_opy_ = []
    for l1l1111l1_opy_ in l11lll1l1_opy_:
        if (addon == l11llllll_opy_) or (addon == l11l1llll_opy_):
            query = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷ࠴ࡅ࡭ࡰࡦࡨࡣ࡮ࡪ࠽ࡤࡪࡤࡲࡳ࡫࡬ࡴࠨࡰࡳࡩ࡫࠽ࡤࡪࡤࡲࡳ࡫࡬ࡴࠨࡶࡩࡨࡺࡩࡰࡰࡢ࡭ࡩࡃࠥࡴࠩॶ") % (addon, l1l1111l1_opy_)
        if (addon == locked) or (addon == l11l1ll1l_opy_):
            query = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸ࠵࠿ࡶࡴ࡯ࡁࠪࡹࠦ࡮ࡱࡧࡩࡂ࠺ࠦ࡯ࡣࡰࡩࡂࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࠩࡴࡱࡧࡹ࠾ࠨࡧࡥࡹ࡫࠽ࠧࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࡃࠦࡱࡣࡪࡩࡂ࠭ॷ") % (addon, l1l1111l1_opy_)
        response = sendJSON(query, addon)
        l1ll11_opy_.extend(response)
    return l1ll11_opy_
def sendJSON(query, addon):
    l11lllll1_opy_     = l1lll11_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬॸ") % query
    l11ll1lll_opy_  = xbmc.executeJSONRPC(l11lllll1_opy_)
    response = json.loads(l11ll1lll_opy_)
    result   = response[l1lll11_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪॹ")]
    if xbmcgui.Window(10000).getProperty(l1lll11_opy_ (u"ࠫࡕࡒࡕࡈࡋࡑࡣࡌࡋࡎࡓࡇࠪॺ")) == l1lll11_opy_ (u"࡚ࠬࡲࡶࡧࠪॻ"):
        xbmcaddon.Addon(addon).setSetting(l1lll11_opy_ (u"࠭ࡧࡦࡰࡵࡩࠬॼ"), l1lll11_opy_ (u"ࠧࡵࡴࡸࡩࠬॽ"))
    if xbmcgui.Window(10000).getProperty(l1lll11_opy_ (u"ࠨࡒࡏ࡙ࡌࡏࡎࡠࡖ࡙ࡋ࡚ࡏࡄࡆࠩॾ")) == l1lll11_opy_ (u"ࠩࡗࡶࡺ࡫ࠧॿ"):
        xbmcaddon.Addon(addon).setSetting(l1lll11_opy_ (u"ࠪࡸࡻ࡭ࡵࡪࡦࡨࠫঀ"), l1lll11_opy_ (u"ࠫࡹࡸࡵࡦࠩঁ"))
    return result[l1lll11_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫং")]
def l1l111l11_opy_(addon):
    if (addon == l11ll1ll1_opy_) or (addon == l11ll111l_opy_):
        return l1lll11_opy_ (u"࠭࠯ࡀࡥࡤࡸࡂ࠳࠲ࠧࡦࡤࡸࡪࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠪࡪࡴࡤࡅࡣࡷࡩࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡰࡳࡩ࡫࠽࠳ࠨࡱࡥࡲ࡫࠽ࡎࡻࠨ࠶࠵ࡉࡨࡢࡰࡱࡩࡱࡹࠦࡳࡧࡦࡳࡷࡪ࡮ࡢ࡯ࡨࠪࡸࡺࡡࡳࡶࡇࡥࡹ࡫ࠦࡶࡴ࡯ࡁࡺࡸ࡬ࠨঃ")
    return l1lll11_opy_ (u"ࠧࠨ঄")
def l1lll1_opy_():
    modules = map(__import__, [l1ll111l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11l1_opy_)):
        return l1lll11_opy_ (u"ࠨࡖࡵࡹࡪ࠭অ")
    if len(modules[-1].Window(10**4).getProperty(l111l_opy_)):
        return l1lll11_opy_ (u"ࠩࡗࡶࡺ࡫ࠧআ")
    return l1lll11_opy_ (u"ࠪࡊࡦࡲࡳࡦࠩই")
def l1111l1_opy_(e, addon):
    l1111l_opy_ = l1lll11_opy_ (u"ࠫࡘࡵࡲࡳࡻ࠯ࠤࡦࡴࠠࡦࡴࡵࡳࡷࠦ࡯ࡤࡥࡸࡶࡪࡪ࠺ࠡࡌࡖࡓࡓࠦࡅࡳࡴࡲࡶ࠿ࠦࠥࡴ࠮ࠣࠩࡸ࠭ঈ")  % (e, addon)
    l1llll_opy_ = l1lll11_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡩ࡯࡯ࡶࡤࡧࡹࠦࡵࡴࠢࡲࡲࠥࡺࡨࡦࠢࡩࡳࡷࡻ࡭࠯ࠩউ")
    l1l1_opy_ = l1lll11_opy_ (u"࠭ࡕࡱ࡮ࡲࡥࡩࠦࡡࠡ࡮ࡲ࡫ࠥࡼࡩࡢࠢࡷ࡬ࡪࠦࡡࡥࡦࡲࡲࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹࠠࡢࡰࡧࠤࡵࡵࡳࡵࠢࡷ࡬ࡪࠦ࡬ࡪࡰ࡮࠲ࠬঊ")
    dixie.log(addon)
    dixie.log(e)
def getPluginInfo(streamurl):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l11l1ll11_opy_   = l1lll11_opy_ (u"ࠧࡌࡱࡧ࡭ࠥࡖࡖࡓࠩঋ")
            l11l1lll1_opy_ = os.path.join(dixie.RESOURCES, l1lll11_opy_ (u"ࠨ࡭ࡲࡨ࡮࠳ࡰࡷࡴ࠱ࡴࡳ࡭ࠧঌ"))
            return l11l1ll11_opy_, l11l1lll1_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l1lll11_opy_ (u"ࠩࡵࡸࡲࡶࠧ঍")) or url.startswith(l1lll11_opy_ (u"ࠪࡶࡹࡳࡰࡦࠩ঎")) or url.startswith(l1lll11_opy_ (u"ࠫࡷࡺࡳࡱࠩএ")) or url.startswith(l1lll11_opy_ (u"ࠬ࡮ࡴࡵࡲࠪঐ")):
            l11l1ll11_opy_   = l1lll11_opy_ (u"࠭࡭࠴ࡷࠣࡔࡱࡧࡹ࡭࡫ࡶࡸࠬ঑")
            l11l1lll1_opy_ = os.path.join(dixie.RESOURCES, l1lll11_opy_ (u"ࠧࡪࡲࡷࡺ࠲ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡱࡰࡪࠫ঒"))
            return l11l1ll11_opy_, l11l1lll1_opy_
    except:
        pass
    if streamurl.startswith(l1lll11_opy_ (u"ࠨࡲࡹࡶ࠿࠵࠯ࠨও")):
        l11l1ll11_opy_   = l1lll11_opy_ (u"ࠩࡎࡳࡩ࡯ࠠࡑࡘࡕࠫঔ")
        l11l1lll1_opy_ = os.path.join(dixie.RESOURCES, l1lll11_opy_ (u"ࠪ࡯ࡴࡪࡩ࠮ࡲࡹࡶ࠳ࡶ࡮ࡨࠩক"))
        return l11l1ll11_opy_, l11l1lll1_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        l11ll1l1l_opy_ = streamurl.split(l1lll11_opy_ (u"ࠫࡢࡕࡔࡕࡡࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬখ"), 1)[-1].split(l1lll11_opy_ (u"ࠬ࠵ࠧগ"), 1)[0]
    if l1lll11_opy_ (u"࠭࡝ࡐࡖࡗࡣࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧঘ") in streamurl:
        l11ll1l1l_opy_ = streamurl.split(l1lll11_opy_ (u"ࠧ࡞ࡑࡗࡘࡤࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨঙ"), 1)[-1].split(l1lll11_opy_ (u"ࠨ࠱ࠪচ"), 1)[0]
    if streamurl.startswith(l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬছ")):
        l11ll1l1l_opy_ = streamurl.split(l1lll11_opy_ (u"ࠪ࠳࠴࠭জ"), 1)[-1].split(l1lll11_opy_ (u"ࠫ࠴࠭ঝ"), 1)[0]
    if l1lll11_opy_ (u"ࠬࡥ࡟ࡔࡈࡢࡣࠬঞ") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡰࡳࡱࡪࡶࡦࡳ࠮ࡴࡷࡳࡩࡷ࠴ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵࠪট")
    if l1lll11_opy_ (u"ࠧࡎࡇࡊࡅ࠿࠭ঠ") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡮ࡧࡪࡥ࡮ࡶࡴࡷࠩড")
    if l1lll11_opy_ (u"࡙ࠩࡈࡗ࡚ࡖ࠻ࠩঢ") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡙ࡅࡉࡋࡒࠨণ")
    if l1lll11_opy_ (u"ࠫࡍࡊࡔࡗ࠼ࠪত") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡳࡡࡳࡶ࡫ࡹࡧ࠭থ")
    if l1lll11_opy_ (u"࠭ࡈࡅࡖ࡙࠶࠿࠭দ") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࠶ࠬধ")
    if l1lll11_opy_ (u"ࠨࡊࡇࡘ࡛࠹࠺ࠨন") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࠸ࠧ঩")
    if l1lll11_opy_ (u"ࠪࡌࡉ࡚ࡖ࠵࠼ࠪপ") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡱ࠭ফ")
    if l1lll11_opy_ (u"ࠬࡏࡐࡍࡃ࡜࠾ࠬব") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡨࡢࡤ࡫ࡳࡰࡦࡿࡥࡳࠩভ")
    if l1lll11_opy_ (u"ࠧࡊࡒࡏࡅ࡞࠸࠺ࠨম") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺࠫয")
    if l1lll11_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡓ࠼ࠪর") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠭঱")
    if l1lll11_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡌࡘ࡛ࡀࠧল") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡺࡶࠨ঳")
    if l1lll11_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡉࡀࠧ঴") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡤࡦࡺࠪ঵")
    if l1lll11_opy_ (u"ࠨࡌࡌࡒ࡝࠸࠺ࠨশ") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡬࡬ࡲࡽࡺࡶ࠳ࠩষ")
    if l1lll11_opy_ (u"ࠪࡑࡆ࡚ࡓ࠻ࠩস") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡑࡦࡺࡳࡃࡷ࡬ࡰࡩࡹࡉࡑࡖ࡙ࠫহ")
    if l1lll11_opy_ (u"ࠬࡘࡏࡐࡖ࠽ࠫ঺") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸ࡯ࡰࡶ࡬ࡴࡹࡼࠧ঻")
    if l1lll11_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡘࡂ࠻়ࠩ") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡧࡥࡳࡴࡺࠧঽ")
    if l1lll11_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡄࡎࡘ࠾ࠬা") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡦࡰࡺ࡯ࡰࡵࡸࠪি")
    if l1lll11_opy_ (u"ࠫࡎࡖࡔࡔࠩী") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶࡴࡷࡵࡸࡦࡸ࠭ু")
    if l1lll11_opy_ (u"࠭ࡌࡊࡘࡈࡘ࡛ࡀࠧূ") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡬ࡪࡸࡨࡱ࡮ࡾࠧৃ")
    if l1lll11_opy_ (u"ࠨࡇࡑࡈ࠿࠭ৄ") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡇࡱࡨࡱ࡫ࡳࡴࠩ৅")
    if l1lll11_opy_ (u"ࠪࡊࡑࡇ࠺ࠨ৆") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡊࡱࡧࡷ࡭ࡧࡶࡷ࡙ࡼࠧে")
    if l1lll11_opy_ (u"ࠬࡓࡁ࡙ࡋ࠽ࠫৈ") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡳࡡࡹ࡫ࡺࡩࡧࡺࡶࠨ৉")
    if l1lll11_opy_ (u"ࠧࡇࡎࡄࡗ࠿࠭৊") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡇ࡮ࡤࡻࡱ࡫ࡳࡴࡖࡹࠫো")
    if l1lll11_opy_ (u"ࠩࡖࡔࡗࡓ࠺ࠨৌ") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡖࡹࡵࡸࡥ࡮ࡣࡦࡽ࡙࡜্ࠧ")
    if l1lll11_opy_ (u"ࠫࡒࡉࡋࡕࡘ࠽ࠫৎ") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡲࡩ࡫ࡵࡸ࠰ࡴࡱࡻࡳࠨ৏")
    if l1lll11_opy_ (u"࠭ࡔࡘࡋࡖࡘ࠿࠭৐") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡴࡸ࡫ࡶࡸࡪࡪࠧ৑")
    if l1lll11_opy_ (u"ࠨࡒࡕࡉࡘ࡚࠺ࠨ৒") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡲࡶࡥࡩࡪ࡯࡯ࠩ৓")
    if l1lll11_opy_ (u"ࠪࡆࡑࡑࡉ࠻ࠩ৔") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡆࡱࡧࡣ࡬ࡋࡦࡩ࡙࡜ࠧ৕")
    if l1lll11_opy_ (u"ࠬࡌࡒࡆࡇ࠽ࠫ৖") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡬ࡲࡦࡧࡹ࡭ࡪࡽࠧৗ")
    if l1lll11_opy_ (u"ࠧࡶࡲࡱࡴ࠿࠭৘") in streamurl:
        l11ll1l1l_opy_ = l1lll11_opy_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯ࡪࡧ࡬ࡴࡳࡥࡳࡷࡱ࠲ࡻ࡯ࡥࡸࠩ৙")
    return l11llll11_opy_(l11ll1l1l_opy_)
def l11llll11_opy_(l11ll1l1l_opy_):
    l11l1ll11_opy_   = l1lll11_opy_ (u"ࠩࠪ৚")
    l11l1lll1_opy_ = l1lll11_opy_ (u"ࠪࠫ৛")
    try:
        l1l111l1l_opy_ = xbmcaddon.Addon(l11ll1l1l_opy_).getAddonInfo(l1lll11_opy_ (u"ࠫࡳࡧ࡭ࡦࠩড়"))
        l11l1ll11_opy_    = dixie.cleanLabel(l1l111l1l_opy_)
        l11l1lll1_opy_  = xbmcaddon.Addon(l11ll1l1l_opy_).getAddonInfo(l1lll11_opy_ (u"ࠬ࡯ࡣࡰࡰࠪঢ়"))
        return l11l1ll11_opy_, l11l1lll1_opy_
    except:
        l11l1ll11_opy_   = l1lll11_opy_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡔࡱࡸࡶࡨ࡫ࠧ৞")
        l11l1lll1_opy_ =  dixie.ICON
        return l11l1ll11_opy_, l11l1lll1_opy_
    return l11l1ll11_opy_, l11l1lll1_opy_
def selectStream(url, channel):
    l11l1l1ll_opy_ = url.split(l1lll11_opy_ (u"ࠧࡽࠩয়"))
    if len(l11l1l1ll_opy_) == 0:
        return None
    options, l1ll1l11_opy_ = getOptions(l11l1l1ll_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l11l1l1ll_opy_) == 1:
            return l1ll1l11_opy_[0]
    import selectDialog
    l11lll111_opy_ = selectDialog.select(l1lll11_opy_ (u"ࠨࡕࡨࡰࡪࡩࡴࠡࡣࠣࡷࡹࡸࡥࡢ࡯ࠪৠ"), options)
    if l11lll111_opy_ < 0:
        raise Exception(l1lll11_opy_ (u"ࠩࡖࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡉࡡ࡯ࡥࡨࡰࠬৡ"))
    return l1ll1l11_opy_[l11lll111_opy_]
def getOptions(l11l1l1ll_opy_, channel, addmore=True):
    options = []
    l1ll1l11_opy_    = []
    for index, stream in enumerate(l11l1l1ll_opy_):
        l11l1ll11_opy_ = getPluginInfo(stream)
        l11111_opy_ = l11l1ll11_opy_[0]
        l11ll11l1_opy_  = l11l1ll11_opy_[1]
        l11111_opy_ = l1lll11_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡳࡷࡧ࡮ࡨࡧࡠ࡟ࠬৢ") + l11111_opy_ + l1lll11_opy_ (u"ࠫࡢࡡ࠯ࡄࡑࡏࡓࡗࡣࠠࠨৣ")
        if stream.startswith(OPEN_OTT):
            l11lll1ll_opy_ = stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l1lll11_opy_ (u"ࠬ࠭৤"))
            l11111_opy_  = l11111_opy_ + l11lll1ll_opy_
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l1lll11_opy_ (u"࠭ࠧ৥"))
        else:
            l11111_opy_  = l11111_opy_ + channel
        options.append([l11111_opy_, index, l11ll11l1_opy_])
        l1ll1l11_opy_.append(stream)
    if addmore:
        options.append([l1lll11_opy_ (u"ࠧࡂࡦࡧࠤࡲࡵࡲࡦ࠰࠱࠲ࠬ০"), index + 1, dixie.ICON])
        l1ll1l11_opy_.append(l1lll11_opy_ (u"ࠨࡣࡧࡨࡒࡵࡲࡦࠩ১"))
    return options, l1ll1l11_opy_
if __name__ == l1lll11_opy_ (u"ࠩࡢࡣࡲࡧࡩ࡯ࡡࡢࠫ২"):
    checkAddons()