# coding: UTF-8
import sys
l11ll111_opy_ = sys.version_info [0] == 2
l1lll1l1_opy_ = 2048
l11lllll_opy_ = 7
def l1l11_opy_ (l11ll1_opy_):
	global l1llll11_opy_
	l1ll1111_opy_ = ord (l11ll1_opy_ [-1])
	l11ll11l_opy_ = l11ll1_opy_ [:-1]
	l11l11l_opy_ = l1ll1111_opy_ % len (l11ll11l_opy_)
	l111l1_opy_ = l11ll11l_opy_ [:l11l11l_opy_] + l11ll11l_opy_ [l11l11l_opy_:]
	if l11ll111_opy_:
		l1lll1_opy_ = unicode () .join ([unichr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	else:
		l1lll1_opy_ = str () .join ([chr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	return eval (l1lll1_opy_)
import xbmc
import xbmcaddon
import json
import os
import shutil
import dixie
l1lll1l1l_opy_    = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡯ࡶࡹࠫ࡟")
l111111l_opy_    = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡷ࡮ࡸࡺࡸ࡫ࠨࡠ")
locked = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡯ࡳࡨࡱࡥࡥࡶࡹࠫࡡ")
l1111ll1_opy_   = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡹࡸࡥࡢ࡯ࡷࡺࡧࡵࡸࠨࡢ")
l1ll1l1l1_opy_     = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡶ࡯ࡳࡶࡶࡱࡦࡴࡩࡢࠩࡣ")
l1llll11l_opy_     = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹࡰࡰࡴࡷࡷࡳࡧࡴࡪࡱࡱ࡬ࡩࡺࡶࠨࡤ")
l1ll1ll1l_opy_     = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡵ࡭ࡶ࡬ࡱࡦࡺࡥ࡮ࡣࡱ࡭ࡦ࠭ࡥ")
l1ll1llll_opy_   = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡭࡫ࡸࡼ࠳ࡺࡶࠨࡦ")
l1ll1l11l_opy_ = [l1lll1l1l_opy_, l111111l_opy_, locked, l1111ll1_opy_, l1ll1l1l1_opy_, l1llll11l_opy_, l1ll1ll1l_opy_, l1ll1llll_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1l11_opy_ (u"ࠩ࡬ࡲ࡮࠭ࡧ"))
def checkAddons():
    for l1lll11l1_opy_ in l1ll1l11l_opy_:
        if l1111l1l_opy_(l1lll11l1_opy_):
            try: l1llll1l1_opy_(l1lll11l1_opy_)
            except: pass
def l1111l1l_opy_(l1lll11l1_opy_):
    if xbmc.getCondVisibility(l1l11_opy_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡌࡦࡹࡁࡥࡦࡲࡲ࠭ࠫࡳࠪࠩࡨ") % l1lll11l1_opy_) == 1:
        return True
    return False
def l1llll1l1_opy_(l1lll11l1_opy_):
    l11111ll_opy_ = str(l1lll11l1_opy_).split(l1l11_opy_ (u"ࠫ࠳࠭ࡩ"))[2] + l1l11_opy_ (u"ࠬ࠴ࡩ࡯࡫ࠪࡪ")
    l1ll1l1ll_opy_  = os.path.join(PATH, l11111ll_opy_)
    l1lll111l_opy_ = l111l111_opy_(l1lll11l1_opy_)
    l1111l11_opy_  = file(l1ll1l1ll_opy_, l1l11_opy_ (u"࠭ࡷࠨ࡫"))
    l1111l11_opy_.write(l1l11_opy_ (u"ࠧ࡜ࠩ࡬"))
    l1111l11_opy_.write(l1lll11l1_opy_)
    l1111l11_opy_.write(l1l11_opy_ (u"ࠨ࡟ࠪ࡭"))
    l1111l11_opy_.write(l1l11_opy_ (u"ࠩ࡟ࡲࠬ࡮"))
    for channel in l1lll111l_opy_:
        l1lllll1l_opy_  = channel[l1l11_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩ࡯")]
        l1lllll1l_opy_  = l1lllll1l_opy_.replace(l1l11_opy_ (u"ࠫ࠳࠴࠮࠯࠰ࠪࡰ"), l1l11_opy_ (u"ࠬ࠭ࡱ")).replace(l1l11_opy_ (u"࠭࠺ࠨࡲ"), l1l11_opy_ (u"ࠧࠨࡳ")).replace(l1l11_opy_ (u"ࠨࠢ࡞ࠫࡴ"), l1l11_opy_ (u"ࠩ࡞ࠫࡵ")).replace(l1l11_opy_ (u"ࠪࡡࠥ࠭ࡶ"), l1l11_opy_ (u"ࠫࡢ࠭ࡷ")).replace(l1l11_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡧࡱࡶࡣࡠࠫࡸ"), l1l11_opy_ (u"࠭ࠧࡹ")).replace(l1l11_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠ࡭࡫ࡰࡩ࡬ࡸࡥࡦࡰࡠࠫࡺ"), l1l11_opy_ (u"ࠨࠩࡻ")).replace(l1l11_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡪࡶࡪ࡫࡮࡞ࠩࡼ"), l1l11_opy_ (u"ࠪࠫࡽ")).replace(l1l11_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡾ࡫࡬࡭ࡱࡺࡡࠬࡾ"), l1l11_opy_ (u"ࠬ࠭ࡿ")).replace(l1l11_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࠬࢀ"), l1l11_opy_ (u"ࠧࠨࢁ")).replace(l1l11_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡱࡵࡥࡳ࡭ࡥ࡞ࠩࢂ"), l1l11_opy_ (u"ࠩࠪࢃ")).replace(l1l11_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࠨࢄ"), l1l11_opy_ (u"ࠫࠬࢅ")).replace(l1l11_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡽࡨࡪࡶࡨࡡࠬࢆ"), l1l11_opy_ (u"࠭ࠧࢇ")).replace(l1l11_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࢈"), l1l11_opy_ (u"ࠨࠩࢉ")).replace(l1l11_opy_ (u"ࠩ࡞ࡍࡢ࠭ࢊ"), l1l11_opy_ (u"ࠪࠫࢋ")).replace(l1l11_opy_ (u"ࠫࡠ࠵ࡉ࡞ࠩࢌ"), l1l11_opy_ (u"ࠬ࠭ࢍ")).replace(l1l11_opy_ (u"࡛࠭ࡃ࡟ࠪࢎ"), l1l11_opy_ (u"ࠧࠨ࢏")).replace(l1l11_opy_ (u"ࠨ࡝࠲ࡆࡢ࠭࢐"), l1l11_opy_ (u"ࠩࠪ࢑"))
        stream = channel[l1l11_opy_ (u"ࠪࡪ࡮ࡲࡥࠨ࢒")]
        l1111l11_opy_.write(l1l11_opy_ (u"ࠫࠪࡹࠧ࢓") % l1lllll1l_opy_)
        l1111l11_opy_.write(l1l11_opy_ (u"ࠬࡃࠧ࢔"))
        l1111l11_opy_.write(l1l11_opy_ (u"࠭ࠥࡴࠩ࢕") % stream)
        l1111l11_opy_.write(l1l11_opy_ (u"ࠧ࡝ࡰࠪ࢖"))
    l1111l11_opy_.write(l1l11_opy_ (u"ࠨ࡞ࡱࠫࢗ"))
    l1111l11_opy_.close()
def l111l111_opy_(l1lll11l1_opy_):
    if l1lll11l1_opy_ == l111111l_opy_:
        return l1lll1l11_opy_(l1lll11l1_opy_)
    try:
        xbmcaddon.Addon(l1lll11l1_opy_).setSetting(l1l11_opy_ (u"ࠩࡪࡩࡳࡸࡥࠨ࢘"), l1l11_opy_ (u"ࠪࡪࡦࡲࡳࡦ࢙ࠩ"))
        xbmcaddon.Addon(l1lll11l1_opy_).setSetting(l1l11_opy_ (u"ࠫࡹࡼࡧࡶ࡫ࡧࡩ࢚ࠬ"), l1l11_opy_ (u"ࠬ࡬ࡡ࡭ࡵࡨ࢛ࠫ"))
    except: pass
    l1lll1111_opy_  = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ࢜") + l1lll11l1_opy_
    l1llll1ll_opy_ =  l1111lll_opy_(l1lll11l1_opy_)
    query   =  l1lll1111_opy_ + l1llll1ll_opy_
    return sendJSON(query, l1lll11l1_opy_)
def getPluginInfo(streamurl):
    if streamurl.isdigit():
        l1ll1ll11_opy_   = l1l11_opy_ (u"ࠧࡌࡱࡧ࡭ࠥࡖࡖࡓࠢࡆ࡬ࡦࡴ࡮ࡦ࡮ࠪ࢝")
        l1ll1lll1_opy_ = os.path.join(dixie.RESOURCES, l1l11_opy_ (u"ࠨ࡭ࡲࡨ࡮࠳ࡰࡷࡴ࠱ࡴࡳ࡭ࠧ࢞"))
        return l1ll1ll11_opy_, l1ll1lll1_opy_
    if streamurl.startswith(l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ࢟")):
        name = streamurl.split(l1l11_opy_ (u"ࠪ࠳࠴࠭ࢠ"), 1)[-1].split(l1l11_opy_ (u"ࠫ࠴࠭ࢡ"), 1)[0]
    if streamurl.startswith(l1l11_opy_ (u"ࠬࡥ࡟ࡔࡈࡢࡣࠬࢢ")):
        name = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡰࡳࡱࡪࡶࡦࡳ࠮ࡴࡷࡳࡩࡷ࠴ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵࠪࢣ")
    if streamurl.startswith(l1l11_opy_ (u"ࠧࡉࡆࡗ࡚࠿࠭ࢤ")):
        name = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡩࡦࡷࡺࠬࢥ")
    if streamurl.startswith(l1l11_opy_ (u"ࠩࡋࡈ࡙࡜࠲࠻ࠩࢦ")):
        name = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧࡩࡱࡶࡹࠫࢧ")
    if streamurl.startswith(l1l11_opy_ (u"ࠫࡍࡊࡔࡗ࠵࠽ࠫࢨ")):
        name = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢࡶࡹࠫࢩ")
    if streamurl.startswith(l1l11_opy_ (u"࠭ࡈࡅࡖ࡙࠸࠿࠭ࢪ")):
        name = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸ࡭ࠩࢫ")
    if streamurl.startswith(l1l11_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠺ࠨࢬ")):
        name = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡤࡥࡧ࡮ࡶ࡬ࡢࡻࡨࡶࠬࢭ")
    if streamurl.startswith(l1l11_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠴࠽ࠫࢮ")):
        name = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽࠧࢯ")
    if streamurl.startswith(l1l11_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖ࠿࠭ࢰ")):
        name = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰ࡭ࡣࡼࡩࡷࡽࡷࡸࠩࢱ")
    if streamurl.startswith(l1l11_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡏࡔࡗ࠼ࠪࢲ")):
        name = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡶࡹࠫࢳ")
    if streamurl.startswith(l1l11_opy_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠼ࠪࢴ")):
        name = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡯࡭ࡻ࡫࡭ࡪࡺࠪࢵ")
    if streamurl.startswith(l1l11_opy_ (u"ࠫࡺࡶ࡮ࡱ࠼ࠪࢶ")):
        name = l1l11_opy_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳࡮ࡤࡩࡱࡰࡩࡷࡻ࡮࠯ࡸ࡬ࡩࡼ࠭ࢷ")
    try:
        l1ll1ll11_opy_   = xbmcaddon.Addon(name).getAddonInfo(l1l11_opy_ (u"࠭࡮ࡢ࡯ࡨࠫࢸ"))
        l1ll1lll1_opy_ = xbmcaddon.Addon(name).getAddonInfo(l1l11_opy_ (u"ࠧࡪࡥࡲࡲࠬࢹ"))
    except:
        l1ll1ll11_opy_   = l1l11_opy_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡶࡸࡷ࡫ࡡ࡮ࠢࡲࡶࠥࡧࡤࡥ࠯ࡲࡲࠬࢺ")
        l1ll1lll1_opy_ =  dixie.ICON
    return l1ll1ll11_opy_, l1ll1lll1_opy_
def l1lll1l11_opy_(l1lll11l1_opy_):
    l1lll1111_opy_ = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬࢻ") + l1lll11l1_opy_
    l1ll11ll1_opy_ = l1l11_opy_ (u"ࠪ࠳ࡄࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦ࡮ࡱࡧࡩࡂ࠷ࠦ࡯ࡣࡰࡩࡂࡒࡩࡷࡧࠨ࠶࠵࡚ࡖࠧࡷࡵࡰࡂ࡮ࡴࡵࡲࠨ࠷ࡦࠫ࠲ࡧࠧ࠵ࡪࡲ࡫ࡴࡢ࡮࡮ࡩࡹࡺ࡬ࡦ࠰ࡦࡳࠪ࠸ࡦࡖࡍࡗࡹࡷࡱ࠱࠹࠲࠵࠶࠵࠷࠶ࠦ࠴ࡩࡐ࡮ࡼࡥࠦ࠴࠸࠶࠵࡚ࡖ࠯ࡶࡻࡸࠬࢼ")
    l1ll1l111_opy_ = l1l11_opy_ (u"ࠫ࠴ࡅࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧ࡯ࡲࡨࡪࡃ࠱ࠧࡰࡤࡱࡪࡃࡓࡱࡱࡵࡸࡸࠬࡵࡳ࡮ࡀ࡬ࡹࡺࡰࠦ࠵ࡤࠩ࠷࡬ࠥ࠳ࡨࡰࡩࡹࡧ࡬࡬ࡧࡷࡸࡱ࡫࠮ࡤࡱࠨ࠶࡫࡛ࡋࡕࡷࡵ࡯࠶࠾࠰࠳࠴࠳࠵࠻ࠫ࠲ࡧࡕࡳࡳࡷࡺࡳࡍ࡫ࡶࡸ࠳ࡺࡸࡵࠩࢽ")
    l1llll111_opy_  = []
    l1llll111_opy_ += sendJSON(l1lll1111_opy_ + l1ll11ll1_opy_, l1lll11l1_opy_)
    l1llll111_opy_ += sendJSON(l1lll1111_opy_ + l1ll1l111_opy_, l1lll11l1_opy_)
    return l1llll111_opy_
def l1111lll_opy_(l1lll11l1_opy_):
    if l1lll11l1_opy_ == l1lll1l1l_opy_:
        return l1l11_opy_ (u"ࠬ࠵࠿ࡤࡣࡷࡁ࠲࠸ࠦ࡮ࡱࡧࡩࡂ࠸ࠦ࡯ࡣࡰࡩࡂࡓࡹࠦ࠴࠳ࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡻࡲ࡭࠿ࡸࡶࡱ࠭ࢾ")
    else: return l1l11_opy_ (u"࠭ࠧࢿ")
def sendJSON(query, l1lll11l1_opy_):
    try:
        l1lllll11_opy_     = l1l11_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࣀ") % query
        l1lll1ll1_opy_  = xbmc.executeJSONRPC(l1lllll11_opy_)
        response = json.loads(l1lll1ll1_opy_)
        result   = response[l1l11_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨࣁ")]
        return result[l1l11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨࣂ")]
    except Exception as e:
        l1lll11ll_opy_(e, l1lll11l1_opy_)
        return {l1l11_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠩࣃ") : l1l11_opy_ (u"ࠫࡕࡲࡵࡨ࡫ࡱࠤࡊࡸࡲࡰࡴࠪࣄ")}
def l1lll11ll_opy_(e, l1lll11l1_opy_):
    l1llllll1_opy_ = l1l11_opy_ (u"࡙ࠬ࡯ࡳࡴࡼ࠰ࠥࡧ࡮ࠡࡧࡵࡶࡴࡸࠠࡰࡥࡦࡹࡷ࡫ࡤ࠻ࠢࡍࡗࡔࡔࠠࡆࡴࡵࡳࡷࡀࠠࠦࡵ࠯ࠤࠪࡹࠧࣅ")  % (e, l1lll11l1_opy_)
    l1lllllll_opy_ = l1l11_opy_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡣࡰࡰࡷࡥࡨࡺࠠࡶࡵࠣࡳࡳࠦࡴࡩࡧࠣࡪࡴࡸࡵ࡮࠰ࠪࣆ")
    l1111111_opy_ = l1l11_opy_ (u"ࠧࡖࡲ࡯ࡳࡦࡪࠠࡢࠢ࡯ࡳ࡬ࠦࡶࡪࡣࠣࡸ࡭࡫ࠠࡢࡦࡧࡳࡳࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠡࡣࡱࡨࠥࡶ࡯ࡴࡶࠣࡸ࡭࡫ࠠ࡭࡫ࡱ࡯࠳࠭ࣇ")
    dixie.log(l1lll11l1_opy_)
    dixie.log(e)
def getPlaylist():
    import requests
    l1lll1lll_opy_ = [l1l11_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡩࡲ࠶ࡱ࠴ࡩ࡯࡭࠲࡯ࡴࡪࡩࠨࣈ"), l1l11_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡻ࠲ࡨࡵ࠯ࡥࡤࡦ࡬࠵࠷ࠧࣉ"), l1l11_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩ࠯ࡥࡦࡰࡩ࠴ࡩࡰࠩ࣊"), l1l11_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦ࡯࡯࠯ࡥࡦࡰࡴࡻࡤࡵࡸ࠱ࡳࡷ࡭࠯࡬ࡱࡧ࡭ࠬ࣋")]
    l1ll11lll_opy_ =  l1l11_opy_ (u"ࠬࠩࡅ࡙ࡖࡐ࠷࡚࠭࣌")
    for url in l1lll1lll_opy_:
        dixie.log(url)
        try:
            request  = requests.get(url)
            l11111l1_opy_ = request.text
        except: pass
        if l1ll11lll_opy_ in l11111l1_opy_:
            path = os.path.join(dixie.PROFILE, l1l11_opy_ (u"࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴ࠯࡯࠶ࡹࠬ࣍"))
            with open(path, l1l11_opy_ (u"ࠧࡸࠩ࣎")) as f:
                f.write(l11111l1_opy_)
                break