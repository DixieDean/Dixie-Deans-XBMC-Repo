# coding: UTF-8
import sys
l11l111_opy_ = sys.version_info [0] == 2
l1ll1l1_opy_ = 2048
l1llll_opy_ = 7
def l111l1_opy_ (ll_opy_):
	global l11l_opy_
	l11l11l_opy_ = ord (ll_opy_ [-1])
	l1lll1l_opy_ = ll_opy_ [:-1]
	l1l11l1_opy_ = l11l11l_opy_ % len (l1lll1l_opy_)
	l1ll1_opy_ = l1lll1l_opy_ [:l1l11l1_opy_] + l1lll1l_opy_ [l1l11l1_opy_:]
	if l11l111_opy_:
		l1ll111_opy_ = unicode () .join ([unichr (ord (char) - l1ll1l1_opy_ - (l11l11_opy_ + l11l11l_opy_) % l1llll_opy_) for l11l11_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1ll111_opy_ = str () .join ([chr (ord (char) - l1ll1l1_opy_ - (l11l11_opy_ + l11l11l_opy_) % l1llll_opy_) for l11l11_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1ll111_opy_)
import xbmc
import xbmcaddon
import json
import os
import dixie
l11111_opy_ = l111l1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡱࡲࡸ࡮ࡶࡴࡷࠩࣝ")
l1l11lll1_opy_   = l111l1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡚ࡷࡶࡪࡧ࡭ࡊࡒࡗ࡚ࠬࣞ")
l1l11l111_opy_  = l111l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡸࡷ࡫ࡡ࡮࠯ࡦࡳࡩ࡫ࡳࠨࣟ")
l1l1l111l_opy_   = l111l1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡒࡪࡳࡺࡻࡻࡌࡔ࡙࡜ࠧ࣠")
l1l11ll1l_opy_     = l111l1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡴࡺࡴࡢ࡮ࡳ࡬ࡦ࠭࣡")
l1111ll_opy_ = [l1l11lll1_opy_, l1l11l111_opy_, l1l1l111l_opy_, l1l11ll1l_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l111l1_opy_ (u"࠭ࡩ࡯࡫ࠪ࣢"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l11l1ll_opy_ = l111l1_opy_ (u"ࠧࠨࣣ")
def l1111l1_opy_(i, t1, l11l1l1_opy_=[]):
 t = l11l1ll_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l11l1l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1l1l_opy_ = l1111l1_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l1l11_opy_ = l1111l1_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1111ll_opy_:
        if l111l1l_opy_(addon):
            createINI(addon)
def l111l1l_opy_(addon):
    if xbmc.getCondVisibility(l111l1_opy_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫࠩࡸ࠯ࠧࣤ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l1l11ll_opy_ = str(addon).rsplit(l111l1_opy_ (u"ࠩ࠱ࠫࣥ"), 1)[1] + l111l1_opy_ (u"ࠪ࠲࡮ࡴࡩࠨࣦ")
    l1l_opy_  = os.path.join(PATH, l1l11ll_opy_)
    try:
        l11lll1_opy_ = l1l111l1l_opy_(addon)
    except KeyError:
        dixie.log(l111l1_opy_ (u"ࠫ࠲࠳࠭࠮࠯ࠣࡏࡪࡿࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡩࡨࡸࡋ࡯࡬ࡦࡵࠣ࠱࠲࠳࠭࠮ࠢࠪࣧ") + addon)
        result = {l111l1_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࡷࠬࣨ"): [{l111l1_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࣩࠩ"): l111l1_opy_ (u"ࡵࠨࡨ࡬ࡰࡪ࠭࣪"), l111l1_opy_ (u"ࡶࠩࡷࡽࡵ࡫ࠧ࣫"): l111l1_opy_ (u"ࡷࠪࡹࡳࡱ࡮ࡰࡹࡱࠫ࣬"), l111l1_opy_ (u"ࡸࠫ࡫࡯࡬ࡦ࣭ࠩ"): l111l1_opy_ (u"ࡹࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸࡹࡺ࣮ࠪ"), l111l1_opy_ (u"ࡺ࠭࡬ࡢࡤࡨࡰ࣯ࠬ"): l111l1_opy_ (u"ࡻࠧࡏࡑࠣࡇࡍࡇࡎࡏࡇࡏࡗࣰࠬ")}], l111l1_opy_ (u"ࡵࠨ࡮࡬ࡱ࡮ࡺࡳࠨࣱ"):{l111l1_opy_ (u"ࡶࠩࡶࡸࡦࡸࡴࠨࣲ"): 0, l111l1_opy_ (u"ࡷࠪࡸࡴࡺࡡ࡭ࠩࣳ"): 1, l111l1_opy_ (u"ࡸࠫࡪࡴࡤࠨࣴ"): 1}}
    l1lllll_opy_  = l111l1_opy_ (u"ࠫࡠ࠭ࣵ") + addon + l111l1_opy_ (u"ࠬࡣ࡜࡯ࣶࠩ")
    l11ll1l_opy_  = file(l1l_opy_, l111l1_opy_ (u"࠭ࡷࠨࣷ"))
    l11ll1l_opy_.write(l1lllll_opy_)
    l1l1ll_opy_ = []
    try:
        for channel in l11lll1_opy_:
            l111ll1_opy_ = l11_opy_(addon, channel)
            l1lll_opy_ = dixie.mapChannelName(l111ll1_opy_)
            stream   = channel[l111l1_opy_ (u"ࠧࡧ࡫࡯ࡩࠬࣸ")]
            l11ll_opy_ = l1lll_opy_ + l111l1_opy_ (u"ࠨ࠿ࣹࠪ") + stream
            l1l1ll_opy_.append(l11ll_opy_)
            l1l1ll_opy_.sort()
        for item in l1l1ll_opy_:
            l11ll1l_opy_.write(l111l1_opy_ (u"ࠤࠨࡷࡡࡴࣺࠢ") % item)
        l11ll1l_opy_.close()
    except Exception as e:
        l1l1111_opy_(e, addon)
        return {l111l1_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࡵࠪࣻ"): [{l111l1_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧࣼ"): l111l1_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࠫࣽ"), l111l1_opy_ (u"ࡻࠧࡵࡻࡳࡩࠬࣾ"): l111l1_opy_ (u"ࡵࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩࣿ"), l111l1_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࠧऀ"): l111l1_opy_ (u"ࡷࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡾࡸࠨँ"), l111l1_opy_ (u"ࡸࠫࡱࡧࡢࡦ࡮ࠪं"): l111l1_opy_ (u"ࡹࠬࡔࡏࠡࡅࡋࡅࡓࡔࡅࡍࡕࠪः")}], l111l1_opy_ (u"ࡺ࠭࡬ࡪ࡯࡬ࡸࡸ࠭ऄ"):{l111l1_opy_ (u"ࡻࠧࡴࡶࡤࡶࡹ࠭अ"): 0, l111l1_opy_ (u"ࡵࠨࡶࡲࡸࡦࡲࠧआ"): 1, l111l1_opy_ (u"ࡶࠩࡨࡲࡩ࠭इ"): 1}}
def l11_opy_(addon, file):
    l11l1l_opy_ = file[l111l1_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨई")].split(l111l1_opy_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬउ"), 1)[0]
    return dixie.cleanLabel(l11l1l_opy_)
def l1l111l1l_opy_(addon):
    login = l111l1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴ࠱ࠪऊ") % addon
    sendJSON(login, addon)
    if (addon == l11111_opy_) or (addon == l1l11l111_opy_) or (addon == l1l11ll1l_opy_):
        return l1_opy_(addon)
    if (addon == l1l11lll1_opy_) or (addon == l1l1l111l_opy_):
        l1l111lll_opy_ = [l111l1_opy_ (u"ࠬ࠹ࠧऋ"), l111l1_opy_ (u"࠭࠴ࠨऌ"), l111l1_opy_ (u"ࠧ࠷ࠩऍ"), l111l1_opy_ (u"ࠨ࠹ࠪऎ"), l111l1_opy_ (u"ࠩ࠻ࠫए"), l111l1_opy_ (u"ࠪ࠵࠶࠭ऐ"), l111l1_opy_ (u"ࠫ࠶࠸ࠧऑ"), l111l1_opy_ (u"ࠬ࠷࠴ࠨऒ"), l111l1_opy_ (u"࠭࠱࠶ࠩओ"), l111l1_opy_ (u"ࠧ࠴࠵ࠪऔ"), l111l1_opy_ (u"ࠨ࠻࠴ࠫक"), l111l1_opy_ (u"ࠩ࠼࠶ࠬख")]
    l1111_opy_ = []
    for l1l11llll_opy_ in l1l111lll_opy_:
        if (addon == l1l11lll1_opy_) or (addon == l1l1l111l_opy_):
            query = l111l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿ࡶࡸࡷ࡫ࡡ࡮ࡡࡹ࡭ࡩ࡫࡯ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠦࡵ࡫ࡷࡰࡪࡃࠦࡶࡴ࡯ࡁࠪࡹࠧग") % (addon, l1l11llll_opy_)
        response = sendJSON(query, addon)
        l1111_opy_.extend(response)
    return l1111_opy_
def l1_opy_(addon):
    query = l1l1l11ll_opy_(addon)
    return sendJSON(query, addon)
def l1l1l11ll_opy_(addon):
    Addon = xbmcaddon.Addon(addon)
    l1l1l1l1l_opy_, l1l11l11l_opy_  = l1l1l1l11_opy_(Addon, addon)
    l1l11ll11_opy_, l1l1l1ll1_opy_ = l1l111ll1_opy_(Addon, addon)
    return l1l11l1l1_opy_(addon, l1l1l1l1l_opy_, l1l11l11l_opy_, l1l11ll11_opy_, l1l1l1ll1_opy_)
def l1l1l1l11_opy_(Addon, addon):
    if addon == l11111_opy_:
        l1l1l1l1l_opy_  = l111l1_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡷࡵ࡯ࡵ࠯࡬ࡴࡹࡼ࠮ࡪࡵ࠰ࡪࡴࡻ࡮ࡥ࠰ࡲࡶ࡬࠭घ")
        l1l11l11l_opy_ = l111l1_opy_ (u"ࠬ࠸࠵࠵࠸࠴ࠫङ")
        return l1l1l1l1l_opy_, l1l11l11l_opy_
    if addon == l1l11ll1l_opy_:
        l1l1l1l1l_opy_  = l111l1_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡯ࡵࡶࡷࡺ࠳࡭ࡡࠨच")
        l1l11l11l_opy_ = l111l1_opy_ (u"ࠧ࠳࠲࠼࠹ࠬछ")
        return l1l1l1l1l_opy_, l1l11l11l_opy_
    l1l1l1l1l_opy_  = Addon.getSetting(l111l1_opy_ (u"ࠨ࡮ࡨ࡬ࡪࡱࡹ࡭ࡩࠪज"))
    l1l11l11l_opy_ = Addon.getSetting(l111l1_opy_ (u"ࠩࡳࡳࡷࡪࡩ࡯ࡷࡰࡦࡪࡸࠧझ"))
    return l1l1l1l1l_opy_, l1l11l11l_opy_
def l1l111ll1_opy_(Addon, addon):
    if addon == l1l11ll1l_opy_:
        l1l11ll11_opy_ = Addon.getSetting(l111l1_opy_ (u"࡙ࠪࡸ࡫ࡲ࡯ࡣࡰࡩࠬञ"))
        l1l1l1ll1_opy_ = Addon.getSetting(l111l1_opy_ (u"ࠫࡕࡧࡳࡴࡹࡲࡶࡩ࠭ट"))
        return l1l11ll11_opy_, l1l1l1ll1_opy_
    l1l11ll11_opy_ = Addon.getSetting(l111l1_opy_ (u"ࠬࡱࡡࡴࡷࡷࡥ࡯ࡧ࡮ࡪ࡯࡬ࠫठ"))
    l1l1l1ll1_opy_ = Addon.getSetting(l111l1_opy_ (u"࠭ࡳࡢ࡮ࡤࡷࡴࡴࡡࠨड"))
    return l1l11ll11_opy_, l1l1l1ll1_opy_
def l1l11l1l1_opy_(addon, l1l1l1l1l_opy_, l1l11l11l_opy_, l1l11ll11_opy_, l1l1l1ll1_opy_):
    if addon == l11111_opy_:
        action = l111l1_opy_ (u"ࠧࡊ࠳࠴ࡍࡎ࠷ࡩࠨढ")
    else:
        action = l111l1_opy_ (u"ࠨࡵࡷࡶࡪࡧ࡭ࡠࡸ࡬ࡨࡪࡵࠧण")
    l1l1l11l1_opy_  = l111l1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬत")
    l1l1l11l1_opy_ +=  addon
    l1l1l11l1_opy_ += l111l1_opy_ (u"ࠪ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࠫࡳࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠦࡵ࡫ࡷࡰࡪࡃࡁ࡭࡮ࠩࡹࡷࡲ࠽ࠨथ") % (action)
    params  =  l1l1l1l1l_opy_
    params += l111l1_opy_ (u"ࠫ࠿࠭द") + l1l11l11l_opy_
    params += l111l1_opy_ (u"ࠬ࠵ࡥ࡯࡫ࡪࡱࡦ࠸࠮ࡱࡪࡳࡃࡺࡹࡥࡳࡰࡤࡱࡪࡃࠧध")
    params +=  l1l11ll11_opy_
    params += l111l1_opy_ (u"࠭ࠦࡱࡣࡶࡷࡼࡵࡲࡥ࠿ࠪन")
    params +=  l1l1l1ll1_opy_
    params += l111l1_opy_ (u"ࠧࠧࡶࡼࡴࡪࡃࡧࡦࡶࡢࡰ࡮ࡼࡥࡠࡵࡷࡶࡪࡧ࡭ࡴࠨࡦࡥࡹࡥࡩࡥ࠿࠳ࠫऩ")
    import urllib
    params = urllib.quote_plus(params)
    url = l1l1l11l1_opy_ + params
    return url
def login(addon):
    login = l111l1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸ࠵ࠧप") % addon
    sendJSON(login, addon)
def sendJSON(query, addon):
    l1l11l1ll_opy_     = l111l1_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬफ") % query
    l1l1l1111_opy_  = xbmc.executeJSONRPC(l1l11l1ll_opy_)
    response = json.loads(l1l1l1111_opy_)
    result   = response[l111l1_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪब")]
    return result[l111l1_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪभ")]
def l111l_opy_():
    modules = map(__import__, [l1111l1_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1l1l_opy_)):
        return l111l1_opy_ (u"࡚ࠬࡲࡶࡧࠪम")
    if len(modules[-1].Window(10**4).getProperty(l1l11_opy_)):
        return l111l1_opy_ (u"࠭ࡔࡳࡷࡨࠫय")
    return l111l1_opy_ (u"ࠧࡇࡣ࡯ࡷࡪ࠭र")
def l1l1111_opy_(e, addon):
    l11ll1_opy_ = l111l1_opy_ (u"ࠨࡕࡲࡶࡷࡿࠬࠡࡣࡱࠤࡪࡸࡲࡰࡴࠣࡳࡨࡩࡵࡳࡧࡧ࠾ࠥࡐࡓࡐࡐࠣࡉࡷࡸ࡯ࡳ࠼ࠣࠩࡸ࠲ࠠࠦࡵࠪऱ")  % (e, addon)
    l11l1_opy_ = l111l1_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡹࡸࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡦࡰࡴࡸࡱ࠳࠭ल")
    l1l111_opy_ = l111l1_opy_ (u"࡙ࠪࡵࡲ࡯ࡢࡦࠣࡥࠥࡲ࡯ࡨࠢࡹ࡭ࡦࠦࡴࡩࡧࠣࡥࡩࡪ࡯࡯ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠤࡦࡴࡤࠡࡲࡲࡷࡹࠦࡴࡩࡧࠣࡰ࡮ࡴ࡫࠯ࠩळ")
    dixie.log(addon)
    dixie.log(e)
if __name__ == l111l1_opy_ (u"ࠫࡤࡥ࡭ࡢ࡫ࡱࡣࡤ࠭ऴ"):
    checkAddons()