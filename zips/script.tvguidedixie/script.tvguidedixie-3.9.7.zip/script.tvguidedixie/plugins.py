# coding: UTF-8
import sys
l11ll111_opy_ = sys.version_info [0] == 2
l1lll1l1_opy_ = 2048
l11lllll_opy_ = 7
def l1l11_opy_ (l11ll1_opy_):
	global l1llll11_opy_
	l1ll1111_opy_ = ord (l11ll1_opy_ [-1])
	l11ll11l_opy_ = l11ll1_opy_ [:-1]
	l11l11l_opy_ = l1ll1111_opy_ % len (l11ll11l_opy_)
	l111l1_opy_ = l11ll11l_opy_ [:l11l11l_opy_] + l11ll11l_opy_ [l11l11l_opy_:]
	if l11ll111_opy_:
		l1lll1_opy_ = unicode () .join ([unichr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	else:
		l1lll1_opy_ = str () .join ([chr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	return eval (l1lll1_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l1ll1l1l1_opy_    = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡯ࡶࡹࠫ࡟")
l1ll111ll_opy_ = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡹ࡯࡭ࡵࡺࡶࠨࡠ")
l1llll1l1_opy_    = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸ࡯ࡹࡻࡲ࡬ࠩࡡ")
locked = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰࡴࡩ࡫ࡦࡦࡷࡺࠬࡢ")
l1l1llll1_opy_     = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡲࡴࡪ࡯ࡤࡸࡪࡳࡡ࡯࡫ࡤࠫࡣ")
l1l1l1lll_opy_   = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲࡩࡶࡺ࠱ࡸࡻ࠭ࡤ")
l1ll11lll_opy_    = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡄࡄࡕࡳࡳࡷࡺࡳࠨࡥ")
l1llll111_opy_ = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡧࡥࡳࡴࡺࠧࡦ")
l1lll11l1_opy_    = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡥ࡯ࡹ࡮ࡶࡴࡷࠩࡧ")
l1l1ll111_opy_ = [l1ll1l1l1_opy_, locked, l1l1l1lll_opy_, l1ll111ll_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1l11_opy_ (u"ࠪ࡭ࡳ࡯ࠧࡨ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1ll11111_opy_ = l1l11_opy_ (u"ࠫࠬࡩ")
def l1l1l1ll1_opy_(i, t1, l1111l1l_opy_=[]):
 t = l1ll11111_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1111l1l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l111111l_opy_ = l1l1l1ll1_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l1111ll1_opy_ = l1l1l1ll1_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1l1ll111_opy_:
        if l1lll1111_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1lll1111_opy_(addon):
    if xbmc.getCondVisibility(l1l11_opy_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠦࡵࠬࠫࡪ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l1111111_opy_ = str(addon).split(l1l11_opy_ (u"࠭࠮ࠨ࡫"))[2] + l1l11_opy_ (u"ࠧ࠯࡫ࡱ࡭ࠬ࡬")
    l1l1ll1l1_opy_  = os.path.join(PATH, l1111111_opy_)
    try:
        l11111l1_opy_ = l111l111_opy_(addon)
    except KeyError:
        dixie.log(l1l11_opy_ (u"ࠨ࠯࠰࠱࠲࠳ࠠࡌࡧࡼࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥ࡭ࡥࡵࡈ࡬ࡰࡪࡹࠠ࠮࠯࠰࠱࠲ࠦࠧ࡭") + addon)
        result = {l1l11_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࡴࠩ࡮"): [{l1l11_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭࡯"): l1l11_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࠪࡰ"), l1l11_opy_ (u"ࡺ࠭ࡴࡺࡲࡨࠫࡱ"): l1l11_opy_ (u"ࡻࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨࡲ"), l1l11_opy_ (u"ࡵࠨࡨ࡬ࡰࡪ࠭ࡳ"): l1l11_opy_ (u"ࡶࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡽࡾࠧࡴ"), l1l11_opy_ (u"ࡷࠪࡰࡦࡨࡥ࡭ࠩࡵ"): l1l11_opy_ (u"ࡸࠫࡓࡕࠠࡄࡊࡄࡒࡓࡋࡌࡔࠩࡶ")}], l1l11_opy_ (u"ࡹࠬࡲࡩ࡮࡫ࡷࡷࠬࡷ"):{l1l11_opy_ (u"ࡺ࠭ࡳࡵࡣࡵࡸࠬࡸ"): 0, l1l11_opy_ (u"ࡻࠧࡵࡱࡷࡥࡱ࠭ࡹ"): 1, l1l11_opy_ (u"ࡵࠨࡧࡱࡨࠬࡺ"): 1}}
    l1lll111l_opy_  = l1l11_opy_ (u"ࠨ࡝ࠪࡻ") + addon + l1l11_opy_ (u"ࠩࡠࡠࡳ࠭ࡼ")
    l1ll11l11_opy_  =  file(l1l1ll1l1_opy_, l1l11_opy_ (u"ࠪࡻࠬࡽ"))
    l1ll11l11_opy_.write(l1lll111l_opy_)
    l1ll1ll11_opy_ = []
    for channel in l11111l1_opy_:
        l1lllll11_opy_ = cleanLabel(channel[l1l11_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪࡾ")])
        l1l1lll11_opy_   = dixie.cleanPrefix(l1lllll11_opy_)
        l11111ll_opy_ = dixie.mapChannelName(l1l1lll11_opy_)
        stream   = channel[l1l11_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪࡿ")]
        l1lllllll_opy_ = l11111ll_opy_ + l1l11_opy_ (u"࠭࠽ࠨࢀ") + stream
        l1ll1ll11_opy_.append(l1lllllll_opy_)
        l1ll1ll11_opy_.sort()
    for item in l1ll1ll11_opy_:
        l1ll11l11_opy_.write(l1l11_opy_ (u"ࠢࠦࡵ࡟ࡲࠧࢁ") % item)
    l1ll11l11_opy_.close()
def l111l111_opy_(addon):
    if (addon == l1ll1l1l1_opy_) or (addon == l1ll111ll_opy_):
        if xbmcaddon.Addon(addon).getSetting(l1l11_opy_ (u"ࠨࡩࡨࡲࡷ࡫ࠧࢂ")) == l1l11_opy_ (u"ࠩࡷࡶࡺ࡫ࠧࢃ"):
            xbmcaddon.Addon(addon).setSetting(l1l11_opy_ (u"ࠪ࡫ࡪࡴࡲࡦࠩࢄ"), l1l11_opy_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪࢅ"))
            xbmcgui.Window(10000).setProperty(l1l11_opy_ (u"ࠬࡖࡌࡖࡉࡌࡒࡤࡍࡅࡏࡔࡈࠫࢆ"), l1l11_opy_ (u"࠭ࡔࡳࡷࡨࠫࢇ"))
        if xbmcaddon.Addon(addon).getSetting(l1l11_opy_ (u"ࠧࡵࡸࡪࡹ࡮ࡪࡥࠨ࢈")) == l1l11_opy_ (u"ࠨࡶࡵࡹࡪ࠭ࢉ"):
            xbmcaddon.Addon(addon).setSetting(l1l11_opy_ (u"ࠩࡷࡺ࡬ࡻࡩࡥࡧࠪࢊ"), l1l11_opy_ (u"ࠪࡪࡦࡲࡳࡦࠩࢋ"))
            xbmcgui.Window(10000).setProperty(l1l11_opy_ (u"ࠫࡕࡒࡕࡈࡋࡑࡣ࡙࡜ࡇࡖࡋࡇࡉࠬࢌ"), l1l11_opy_ (u"࡚ࠬࡲࡶࡧࠪࢍ"))
        l1ll111l1_opy_  = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩࢎ") + addon
        l1lll1l11_opy_ =  l1111l11_opy_(addon)
        query   =  l1ll111l1_opy_ + l1lll1l11_opy_
        return sendJSON(query, addon)
    return l1ll1lll1_opy_(addon)
def l1ll1lll1_opy_(addon):
    if addon == l1l1l1lll_opy_:
        l1ll1111l_opy_ = [l1l11_opy_ (u"ࠧ࠶ࠩ࢏"), l1l11_opy_ (u"ࠨ࠳࠳࠺ࠬ࢐"), l1l11_opy_ (u"ࠩ࠷ࠫ࢑"), l1l11_opy_ (u"ࠪ࠶࠻࠹ࠧ࢒"), l1l11_opy_ (u"ࠫ࠶࠹࠲ࠨ࢓")]
    if addon == locked:
        l1ll1111l_opy_ = [l1l11_opy_ (u"ࠬ࠹࠰ࠨ࢔"), l1l11_opy_ (u"࠭࠳࠲ࠩ࢕"), l1l11_opy_ (u"ࠧ࠴࠴ࠪ࢖"), l1l11_opy_ (u"ࠨ࠵࠶ࠫࢗ"), l1l11_opy_ (u"ࠩ࠶࠸ࠬ࢘"), l1l11_opy_ (u"ࠪ࠷࠺࢙࠭"), l1l11_opy_ (u"ࠫ࠸࠾࢚ࠧ"), l1l11_opy_ (u"ࠬ࠺࠰ࠨ࢛"), l1l11_opy_ (u"࠭࠴࠲ࠩ࢜"), l1l11_opy_ (u"ࠧ࠵࠷ࠪ࢝"), l1l11_opy_ (u"ࠨ࠶࠺ࠫ࢞"), l1l11_opy_ (u"ࠩ࠷࠽ࠬ࢟"), l1l11_opy_ (u"ࠪ࠹࠷࠭ࢠ")]
    if addon == l1l1llll1_opy_:
        l1ll1111l_opy_ = [l1l11_opy_ (u"ࠫ࠷࠻ࠧࢡ"), l1l11_opy_ (u"ࠬ࠸࠶ࠨࢢ"), l1l11_opy_ (u"࠭࠲࠸ࠩࢣ"), l1l11_opy_ (u"ࠧ࠳࠻ࠪࢤ"), l1l11_opy_ (u"ࠨ࠵࠳ࠫࢥ"), l1l11_opy_ (u"ࠩ࠶࠵ࠬࢦ"), l1l11_opy_ (u"ࠪ࠷࠷࠭ࢧ"), l1l11_opy_ (u"ࠫ࠸࠻ࠧࢨ"), l1l11_opy_ (u"ࠬ࠹࠶ࠨࢩ"), l1l11_opy_ (u"࠭࠳࠸ࠩࢪ"), l1l11_opy_ (u"ࠧ࠴࠺ࠪࢫ"), l1l11_opy_ (u"ࠨ࠵࠼ࠫࢬ"), l1l11_opy_ (u"ࠩ࠷࠴ࠬࢭ"), l1l11_opy_ (u"ࠪ࠸࠶࠭ࢮ"), l1l11_opy_ (u"ࠫ࠹࠾ࠧࢯ"), l1l11_opy_ (u"ࠬ࠺࠹ࠨࢰ"), l1l11_opy_ (u"࠭࠵࠱ࠩࢱ"), l1l11_opy_ (u"ࠧ࠶࠴ࠪࢲ"), l1l11_opy_ (u"ࠨ࠷࠷ࠫࢳ"), l1l11_opy_ (u"ࠩ࠸࠺ࠬࢴ"), l1l11_opy_ (u"ࠪ࠹࠼࠭ࢵ"), l1l11_opy_ (u"ࠫ࠺࠾ࠧࢶ"), l1l11_opy_ (u"ࠬ࠻࠹ࠨࢷ"), l1l11_opy_ (u"࠭࠶࠱ࠩࢸ"), l1l11_opy_ (u"ࠧ࠷࠳ࠪࢹ"), l1l11_opy_ (u"ࠨ࠸࠵ࠫࢺ"), l1l11_opy_ (u"ࠩ࠹࠷ࠬࢻ"), l1l11_opy_ (u"ࠪ࠺࠺࠭ࢼ"), l1l11_opy_ (u"ࠫ࠻࠼ࠧࢽ"), l1l11_opy_ (u"ࠬ࠼࠷ࠨࢾ"), l1l11_opy_ (u"࠭࠶࠺ࠩࢿ"), l1l11_opy_ (u"ࠧ࠸࠲ࠪࣀ"), l1l11_opy_ (u"ࠨ࠹࠷ࠫࣁ"), l1l11_opy_ (u"ࠩ࠺࠻ࠬࣂ"), l1l11_opy_ (u"ࠪ࠻࠽࠭ࣃ"), l1l11_opy_ (u"ࠫ࠽࠶ࠧࣄ"), l1l11_opy_ (u"ࠬ࠾࠱ࠨࣅ")]
    login = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶ࠳ࠬࣆ") % addon
    sendJSON(login, addon)
    l1ll1llll_opy_ = []
    for l1llll1ll_opy_ in l1ll1111l_opy_:
        if addon == l1l1l1lll_opy_:
            query = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷ࠴ࡅ࡭ࡰࡦࡨࡣ࡮ࡪ࠽ࡤࡪࡤࡲࡳ࡫࡬ࡴࠨࡰࡳࡩ࡫࠽ࡤࡪࡤࡲࡳ࡫࡬ࡴࠨࡶࡩࡨࡺࡩࡰࡰࡢ࡭ࡩࡃࠥࡴࠩࣇ") % (addon, l1llll1ll_opy_)
        if (addon == locked) or (addon == l1l1llll1_opy_):
            query = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸ࠵࠿ࡶࡴ࡯ࡁࠪࡹࠦ࡮ࡱࡧࡩࡂ࠺ࠦ࡯ࡣࡰࡩࡂࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࠩࡴࡱࡧࡹ࠾ࠨࡧࡥࡹ࡫࠽ࠧࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࡃࠦࡱࡣࡪࡩࡂ࠭ࣈ") % (addon, l1llll1ll_opy_)
        response = sendJSON(query, addon)
        l1ll1llll_opy_.extend(response)
    return l1ll1llll_opy_
def sendJSON(query, addon):
    l1lll1l1l_opy_     = l1l11_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬࣉ") % query
    l1ll1l1ll_opy_  = xbmc.executeJSONRPC(l1lll1l1l_opy_)
    response = json.loads(l1ll1l1ll_opy_)
    result   = response[l1l11_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪ࣊")]
    if xbmcgui.Window(10000).getProperty(l1l11_opy_ (u"ࠫࡕࡒࡕࡈࡋࡑࡣࡌࡋࡎࡓࡇࠪ࣋")) == l1l11_opy_ (u"࡚ࠬࡲࡶࡧࠪ࣌"):
        xbmcaddon.Addon(addon).setSetting(l1l11_opy_ (u"࠭ࡧࡦࡰࡵࡩࠬ࣍"), l1l11_opy_ (u"ࠧࡵࡴࡸࡩࠬ࣎"))
    if xbmcgui.Window(10000).getProperty(l1l11_opy_ (u"ࠨࡒࡏ࡙ࡌࡏࡎࡠࡖ࡙ࡋ࡚ࡏࡄࡆ࣏ࠩ")) == l1l11_opy_ (u"ࠩࡗࡶࡺ࡫࣐ࠧ"):
        xbmcaddon.Addon(addon).setSetting(l1l11_opy_ (u"ࠪࡸࡻ࡭ࡵࡪࡦࡨ࣑ࠫ"), l1l11_opy_ (u"ࠫࡹࡸࡵࡦ࣒ࠩ"))
    return result[l1l11_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶ࣓ࠫ")]
def l1111l11_opy_(addon):
    if (addon == l1ll1l1l1_opy_) or (addon == l1ll111ll_opy_):
        return l1l11_opy_ (u"࠭࠯ࡀࡥࡤࡸࡂ࠳࠲ࠧࡦࡤࡸࡪࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠪࡪࡴࡤࡅࡣࡷࡩࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡰࡳࡩ࡫࠽࠳ࠨࡱࡥࡲ࡫࠽ࡎࡻࠨ࠶࠵ࡉࡨࡢࡰࡱࡩࡱࡹࠦࡳࡧࡦࡳࡷࡪ࡮ࡢ࡯ࡨࠪࡸࡺࡡࡳࡶࡇࡥࡹ࡫ࠦࡶࡴ࡯ࡁࡺࡸ࡬ࠨࣔ")
    return l1l11_opy_ (u"ࠧࠨࣕ")
def l1lllll1l_opy_():
    modules = map(__import__, [l1l1l1ll1_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l111111l_opy_)):
        return l1l11_opy_ (u"ࠨࡖࡵࡹࡪ࠭ࣖ")
    if len(modules[-1].Window(10**4).getProperty(l1111ll1_opy_)):
        return l1l11_opy_ (u"ࠩࡗࡶࡺ࡫ࠧࣗ")
    return l1l11_opy_ (u"ࠪࡊࡦࡲࡳࡦࠩࣘ")
def l1ll11ll1_opy_(e, addon):
    l1lll1lll_opy_ = l1l11_opy_ (u"ࠫࡘࡵࡲࡳࡻ࠯ࠤࡦࡴࠠࡦࡴࡵࡳࡷࠦ࡯ࡤࡥࡸࡶࡪࡪ࠺ࠡࡌࡖࡓࡓࠦࡅࡳࡴࡲࡶ࠿ࠦࠥࡴ࠮ࠣࠩࡸ࠭ࣙ")  % (e, addon)
    l1llllll1_opy_ = l1l11_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡩ࡯࡯ࡶࡤࡧࡹࠦࡵࡴࠢࡲࡲࠥࡺࡨࡦࠢࡩࡳࡷࡻ࡭࠯ࠩࣚ")
    l1llll11l_opy_ = l1l11_opy_ (u"࠭ࡕࡱ࡮ࡲࡥࡩࠦࡡࠡ࡮ࡲ࡫ࠥࡼࡩࡢࠢࡷ࡬ࡪࠦࡡࡥࡦࡲࡲࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹࠠࡢࡰࡧࠤࡵࡵࡳࡵࠢࡷ࡬ࡪࠦ࡬ࡪࡰ࡮࠲ࠬࣛ")
    dixie.log(addon)
    dixie.log(e)
def getPluginInfo(streamurl):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l1l1lll1l_opy_   = l1l11_opy_ (u"ࠧࡌࡱࡧ࡭ࠥࡖࡖࡓࠩࣜ")
            l1l1lllll_opy_ = os.path.join(dixie.RESOURCES, l1l11_opy_ (u"ࠨ࡭ࡲࡨ࡮࠳ࡰࡷࡴ࠱ࡴࡳ࡭ࠧࣝ"))
            return l1l1lll1l_opy_, l1l1lllll_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l1l11_opy_ (u"ࠩࡵࡸࡲࡶࠧࣞ")) or url.startswith(l1l11_opy_ (u"ࠪࡶࡹࡳࡰࡦࠩࣟ")) or url.startswith(l1l11_opy_ (u"ࠫࡷࡺࡳࡱࠩ࣠")) or url.startswith(l1l11_opy_ (u"ࠬ࡮ࡴࡵࡲࠪ࣡")):
            l1l1lll1l_opy_   = l1l11_opy_ (u"࠭࡭࠴ࡷࠣࡔࡱࡧࡹ࡭࡫ࡶࡸࠬ࣢")
            l1l1lllll_opy_ = os.path.join(dixie.RESOURCES, l1l11_opy_ (u"ࠧࡪࡲࡷࡺ࠲ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡱࡰࡪࣣࠫ"))
            return l1l1lll1l_opy_, l1l1lllll_opy_
    except:
        pass
    if streamurl.startswith(l1l11_opy_ (u"ࠨࡲࡹࡶ࠿࠵࠯ࠨࣤ")):
        l1l1lll1l_opy_   = l1l11_opy_ (u"ࠩࡎࡳࡩ࡯ࠠࡑࡘࡕࠫࣥ")
        l1l1lllll_opy_ = os.path.join(dixie.RESOURCES, l1l11_opy_ (u"ࠪ࡯ࡴࡪࡩ࠮ࡲࡹࡶ࠳ࡶ࡮ࡨࣦࠩ"))
        return l1l1lll1l_opy_, l1l1lllll_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        l1ll1l11l_opy_ = streamurl.split(l1l11_opy_ (u"ࠫࡢࡕࡔࡕࡡࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬࣧ"), 1)[-1].split(l1l11_opy_ (u"ࠬ࠵ࠧࣨ"), 1)[0]
    if l1l11_opy_ (u"࠭࡝ࡐࡖࡗࡣࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࣩࠧ") in streamurl:
        l1ll1l11l_opy_ = streamurl.split(l1l11_opy_ (u"ࠧ࡞ࡑࡗࡘࡤࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ࣪"), 1)[-1].split(l1l11_opy_ (u"ࠨ࠱ࠪ࣫"), 1)[0]
    if streamurl.startswith(l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ࣬")):
        l1ll1l11l_opy_ = streamurl.split(l1l11_opy_ (u"ࠪ࠳࠴࣭࠭"), 1)[-1].split(l1l11_opy_ (u"ࠫ࠴࣮࠭"), 1)[0]
    if l1l11_opy_ (u"ࠬࡥ࡟ࡔࡈࡢࡣ࣯ࠬ") in streamurl:
        l1ll1l11l_opy_ = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡰࡳࡱࡪࡶࡦࡳ࠮ࡴࡷࡳࡩࡷ࠴ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵࣰࠪ")
    if l1l11_opy_ (u"ࠧࡉࡆࡗ࡚࠿ࣱ࠭") in streamurl:
        l1ll1l11l_opy_ = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴ࡯ࡤࡶࡹ࡮ࡵࡣࣲࠩ")
    if l1l11_opy_ (u"ࠩࡋࡈ࡙࡜࠲࠻ࠩࣳ") in streamurl:
        l1ll1l11l_opy_ = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧ࠲ࠨࣴ")
    if l1l11_opy_ (u"ࠫࡍࡊࡔࡗ࠵࠽ࠫࣵ") in streamurl:
        l1ll1l11l_opy_ = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢ࠴ࣶࠪ")
    if l1l11_opy_ (u"࠭ࡈࡅࡖ࡙࠸࠿࠭ࣷ") in streamurl:
        l1ll1l11l_opy_ = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸ࡭ࠩࣸ")
    if l1l11_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠺ࠨࣹ") in streamurl:
        l1ll1l11l_opy_ = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡤࡥࡧ࡮ࡶ࡬ࡢࡻࡨࡶࣺࠬ")
    if l1l11_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠴࠽ࠫࣻ") in streamurl:
        l1ll1l11l_opy_ = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽࠧࣼ")
    if l1l11_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖ࠿࠭ࣽ") in streamurl:
        l1ll1l11l_opy_ = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰ࡭ࡣࡼࡩࡷࡽࡷࡸࠩࣾ")
    if l1l11_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡏࡔࡗ࠼ࠪࣿ") in streamurl:
        l1ll1l11l_opy_ = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡶࡹࠫऀ")
    if l1l11_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪँ") in streamurl:
        l1ll1l11l_opy_ = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡧࡩࡽ࠭ं")
    if l1l11_opy_ (u"ࠫࡏࡏࡎ࡙࠴࠽ࠫः") in streamurl:
        l1ll1l11l_opy_ = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡯࡯࡮ࡹࡶࡹ࠶ࠬऄ")
    if l1l11_opy_ (u"࠭ࡒࡐࡑࡗ࠾ࠬअ") in streamurl:
        l1ll1l11l_opy_ = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡰࡱࡷ࡭ࡵࡺࡶࠨआ")
    if l1l11_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡒࡃ࠼ࠪइ") in streamurl:
        l1ll1l11l_opy_ = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡨࡦࡴࡵࡴࠨई")
    if l1l11_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡅࡏ࡙࠿࠭उ") in streamurl:
        l1ll1l11l_opy_ = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡧࡱࡻࡩࡱࡶࡹࠫऊ")
    if l1l11_opy_ (u"ࠬࡏࡐࡕࡕࠪऋ") in streamurl:
        l1ll1l11l_opy_ = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰࡵࡸࡶࡹࡧࡹࠧऌ")
    if l1l11_opy_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠺ࠨऍ") in streamurl:
        l1ll1l11l_opy_ = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡭࡫ࡹࡩࡲ࡯ࡸࠨऎ")
    if l1l11_opy_ (u"ࠩࡈࡒࡉࡀࠧए") in streamurl:
        l1ll1l11l_opy_ = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡈࡲࡩࡲࡥࡴࡵࠪऐ")
    if l1l11_opy_ (u"ࠫࡋࡒࡁ࠻ࠩऑ") in streamurl:
        l1ll1l11l_opy_ = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡋࡲࡡࡸ࡮ࡨࡷࡸ࡚ࡶࠨऒ")
    if l1l11_opy_ (u"࠭ࡆࡍࡃࡖ࠾ࠬओ") in streamurl:
        l1ll1l11l_opy_ = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡆ࡭ࡣࡺࡰࡪࡹࡳࡕࡸࠪऔ")
    if l1l11_opy_ (u"ࠨࡷࡳࡲࡵࡀࠧक") in streamurl:
        l1ll1l11l_opy_ = l1l11_opy_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰࡫ࡨ࡭ࡵ࡭ࡦࡴࡸࡲ࠳ࡼࡩࡦࡹࠪख")
    return l1lll11ll_opy_(l1ll1l11l_opy_)
def l1lll11ll_opy_(l1ll1l11l_opy_):
    l1l1lll1l_opy_   = l1l11_opy_ (u"ࠪࠫग")
    l1l1lllll_opy_ = l1l11_opy_ (u"ࠫࠬघ")
    try:
        l1111lll_opy_ = xbmcaddon.Addon(l1ll1l11l_opy_).getAddonInfo(l1l11_opy_ (u"ࠬࡴࡡ࡮ࡧࠪङ"))
        l1l1lll1l_opy_    = cleanLabel(l1111lll_opy_)
        l1l1lllll_opy_  = xbmcaddon.Addon(l1ll1l11l_opy_).getAddonInfo(l1l11_opy_ (u"࠭ࡩࡤࡱࡱࠫच"))
        return l1l1lll1l_opy_, l1l1lllll_opy_
    except:
        l1l1lll1l_opy_   = l1l11_opy_ (u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡕࡲࡹࡷࡩࡥࠨछ")
        l1l1lllll_opy_ =  dixie.ICON
        return l1l1lll1l_opy_, l1l1lllll_opy_
    return l1l1lll1l_opy_, l1l1lllll_opy_
def selectStream(url, channel):
    l1l1ll1ll_opy_ = url.split(l1l11_opy_ (u"ࠨࡾࠪज"))
    if len(l1l1ll1ll_opy_) == 0:
        return None
    options, l1l1ll11l_opy_ = getOptions(l1l1ll1ll_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l1l1ll1ll_opy_) == 1:
            return l1l1ll11l_opy_[0]
    import selectDialog
    l1ll1ll1l_opy_ = selectDialog.select(l1l11_opy_ (u"ࠩࡖࡩࡱ࡫ࡣࡵࠢࡤࠤࡸࡺࡲࡦࡣࡰࠫझ"), options)
    if l1ll1ll1l_opy_ < 0:
        raise Exception(l1l11_opy_ (u"ࠪࡗࡪࡲࡥࡤࡶ࡬ࡳࡳࠦࡃࡢࡰࡦࡩࡱ࠭ञ"))
    return l1l1ll11l_opy_[l1ll1ll1l_opy_]
def getOptions(l1l1ll1ll_opy_, channel, addmore=True):
    options = []
    l1l1ll11l_opy_    = []
    for index, stream in enumerate(l1l1ll1ll_opy_):
        l1l1lll1l_opy_ = getPluginInfo(stream)
        l1lll1ll1_opy_ = l1l1lll1l_opy_[0]
        l1ll11l1l_opy_  = l1l1lll1l_opy_[1]
        l1lll1ll1_opy_ = l1l11_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡴࡸࡡ࡯ࡩࡨࡡࡠ࠭ट") + l1lll1ll1_opy_ + l1l11_opy_ (u"ࠬࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠡࠩठ")
        if stream.startswith(OPEN_OTT):
            l1ll1l111_opy_ = stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l1l11_opy_ (u"࠭ࠧड"))
            l1lll1ll1_opy_  = l1lll1ll1_opy_ + l1ll1l111_opy_
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l1l11_opy_ (u"ࠧࠨढ"))
        else:
            l1lll1ll1_opy_  = l1lll1ll1_opy_ + channel
        options.append([l1lll1ll1_opy_, index, l1ll11l1l_opy_])
        l1l1ll11l_opy_.append(stream)
    if addmore:
        options.append([l1l11_opy_ (u"ࠨࡃࡧࡨࠥࡳ࡯ࡳࡧ࠱࠲࠳࠭ण"), index + 1, dixie.ICON])
        l1l1ll11l_opy_.append(l1l11_opy_ (u"ࠩࡤࡨࡩࡓ࡯ࡳࡧࠪत"))
    return options, l1l1ll11l_opy_
def cleanLabel(name):
    import re
    name  = re.sub(l1l11_opy_ (u"ࠪࡠ࠭ࡡ࠰࠮࠻ࠬࡡ࠯ࡢࠩࠨथ"), l1l11_opy_ (u"ࠫࠬद"), name)
    items = name.split(l1l11_opy_ (u"ࠬࡣࠧध"))
    name  = l1l11_opy_ (u"࠭ࠧन")
    for item in items:
        if len(item) == 0:
            continue
        item += l1l11_opy_ (u"ࠧ࡞ࠩऩ")
        item  = re.sub(l1l11_opy_ (u"ࠨ࡞࡞࡟ࡣ࠯࡝ࠫ࡞ࡠࠫप"), l1l11_opy_ (u"ࠩࠪफ"), item)
        if len(item) > 0:
            name += item
    name  = name.replace(l1l11_opy_ (u"ࠪ࡟ࠬब"), l1l11_opy_ (u"ࠫࠬभ"))
    name  = name.replace(l1l11_opy_ (u"ࠬࡣࠧम"), l1l11_opy_ (u"࠭ࠧय"))
    name  = name.strip()
    while True:
        length = len(name)
        name = name.replace(l1l11_opy_ (u"ࠧࠡࠢࠪर"), l1l11_opy_ (u"ࠨࠢࠪऱ"))
        if length == len(name):
            break
    return name.strip()
if __name__ == l1l11_opy_ (u"ࠩࡢࡣࡲࡧࡩ࡯ࡡࡢࠫल"):
    checkAddons()