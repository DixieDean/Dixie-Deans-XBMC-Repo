#
# Copyright (C) 2015 On-Tapp-Networks Limited

import xbmc
import xbmcaddon
import xbmcgui
import json
import os

import shutil
import dixie

ntv     = 'plugin.video.ntv'
wliptv  = 'plugin.video.wliptv'
ukt     = 'plugin.video.ukturk'
locked  = 'plugin.video.lockedtv'
um      = 'plugin.video.ultimatemania'
liux    = 'plugin.video.liux.tv'
dcs     = 'plugin.video.DCSports'
reboot  = 'plugin.video.reboot'
clu     = 'plugin.video.cluiptv'
ukexpat = 'plugin.video.uktv4expats.com'


ADDONS = [ntv, locked, liux, wliptv, ukexpat] # [um, ntv, locked, liux]

HOME = dixie.PROFILE
PATH = os.path.join(HOME, 'ini')

OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT


ooOOOoo = ''
def ttTTtt(i, t1, t2=[]):
 t = ooOOOoo
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in t2:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t

WID1 = ttTTtt(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
WID2 = ttTTtt(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
# dixie.log('============== WINDOW IDS ==============')
# dixie.log(WID1)
# dixie.log(WID2)


def checkAddons():
    # if not updateJSON() == 'True':
    #     return
    for addon in ADDONS:
        if isInstalled(addon):
            try:
                createINI(addon)
            except: pass


def isInstalled(addon):
    if xbmc.getCondVisibility('System.HasAddon(%s)' % addon) == 1:
        return True
    return False


def createINI(addon):
    FILE = str(addon).split('.')[2] + '.ini'
    INI  = os.path.join(PATH, FILE)

    try:
        channels = getFiles(addon)
    except KeyError:
        dixie.log('----- KeyError in getFiles ----- ' + addon)
        result = {u'files': [{u'filetype': u'file', u'type': u'unknown', u'file': u'plugin://plugin.video.xxx', u'label': u'NO CHANNELS'}], u'limits':{u'start': 0, u'total': 1, u'end': 1}}

    TOPLINE  = '[' + addon + ']\n'
    theFile  =  file(INI, 'w')

    theFile.write(TOPLINE)

    theList = []

    for channel in channels:
        cleanlabel = dixie.cleanLabel(channel['label'])
        tmplabel   = dixie.cleanPrefix(cleanlabel)

        ottlabel = dixie.mapChannelName(tmplabel)
        stream   = channel['file']

        iniLine = ottlabel + '=' + stream
        theList.append(iniLine)
        theList.sort()

    for item in theList:
        theFile.write("%s\n" % item)

    theFile.close()


def getFiles(addon):
    if (addon == ntv) or (addon == wliptv):
        if xbmcaddon.Addon(addon).getSetting('genre') == 'true':
            xbmcaddon.Addon(addon).setSetting('genre', 'false')
            xbmcgui.Window(10000).setProperty('PLUGIN_GENRE', 'True')

        if xbmcaddon.Addon(addon).getSetting('tvguide') == 'true':
            xbmcaddon.Addon(addon).setSetting('tvguide', 'false')
            xbmcgui.Window(10000).setProperty('PLUGIN_TVGUIDE', 'True')

        plugin  = 'plugin://' + addon
        slugurl =  getSlugURL(addon)
        query   =  plugin + slugurl

        return sendJSON(query, addon)

    return getSections(addon)


def getSections(addon):
    if addon == ukexpat:
        sections = ['161', '160', '236', '242', '158', '159']

    if addon == liux:
        sections = ['5', '106', '4', '263', '132']

    if addon == locked:
        sections = ['30', '31', '32', '33', '34', '35', '38', '40', '41', '45', '47', '49', '52']

    if addon == um:
        sections = ['25', '26', '27', '29', '30', '31', '32', '35', '36', '37', '38', '39', '40', '41', '48', '49', '50', '52', '54', '56', '57', '58', '59', '60', '61', '62', '63', '65', '66', '67', '69', '70', '74', '77', '78', '80', '81']


    login = 'plugin://%s/' % addon
    sendJSON(login, addon)

    files = []
    for section in sections:
        if (addon == ukexpat) or (addon == liux):
            query = 'plugin://%s/?mode_id=channels&mode=channels&section_id=%s' % (addon, section)

        if (addon == locked) or (addon == um):
            query = 'plugin://%s/?url=%s&mode=4&name=&iconimage=&play=&date=&description=&page=' % (addon, section)

        response = sendJSON(query, addon)

        files.extend(response)

    return files


def sendJSON(query, addon):
    JSON     = '{"jsonrpc":"2.0", "method":"Files.GetDirectory", "params":{"directory":"%s"}, "id": 1}' % query
    jsonCMD  = xbmc.executeJSONRPC(JSON)
    response = json.loads(jsonCMD)
    result   = response['result']

    if xbmcgui.Window(10000).getProperty('PLUGIN_GENRE') == 'True':
        xbmcaddon.Addon(addon).setSetting('genre', 'true')

    if xbmcgui.Window(10000).getProperty('PLUGIN_TVGUIDE') == 'True':
        xbmcaddon.Addon(addon).setSetting('tvguide', 'true')

    return result['files']


def getSlugURL(addon):
    if (addon == ntv) or (addon == wliptv):
        return '/?cat=-2&date&description&endDate&iconimage=&mode=2&name=My%20Channels&recordname&startDate&url=url'

    return ''


def updateJSON():
    modules = map(__import__, [ttTTtt(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(WID1)):
        return 'True'
    if len(modules[-1].Window(10**4).getProperty(WID2)):
        return 'True'
    return 'False'


def catchException(e, addon):
    line1 = 'Sorry, an error occured: JSON Error: %s, %s'  % (e, addon) 
    line2 = 'Please contact us on the forum.'
    line3 = 'Upload a log via the addon settings and post the link.'

    dixie.log(addon)
    dixie.log(e)


def getPluginInfo(streamurl):
    # if not updateJSON() == 'True':
    #     dixie.log('============ ERROR, ERROR, ERROR ===========')
    #     return

    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            pluginid   = 'Kodi PVR'
            pluginicon = os.path.join(dixie.RESOURCES, 'kodi-pvr.png')
            return pluginid, pluginicon
    except:
        pass

    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith('rtmp') or url.startswith('rtmpe') or url.startswith('rtsp') or url.startswith('http'):
            pluginid   = 'm3u Playlist'
            pluginicon = os.path.join(dixie.RESOURCES, 'iptv-playlist.png')
            return pluginid, pluginicon
    except:
        pass

    if streamurl.startswith('pvr://'):
        pluginid   = 'Kodi PVR'
        pluginicon = os.path.join(dixie.RESOURCES, 'kodi-pvr.png')
        return pluginid, pluginicon

    if streamurl.startswith(dixie.OPEN_OTT):
        pluginname = streamurl.split(']OTT_plugin://', 1)[-1].split('/', 1)[0]

    if ']OTT_plugin://' in streamurl:
        pluginname = streamurl.split(']OTT_plugin://', 1)[-1].split('/', 1)[0]

    if streamurl.startswith('plugin://'):
        pluginname = streamurl.split('//', 1)[-1].split('/', 1)[0]

    if '__SF__' in streamurl:
        pluginname = 'plugin.program.super.favourites'

    if 'FAB:' in streamurl:
        pluginname = 'plugin.video.fabhosting'

    if 'ACE:' in streamurl:
        pluginname = 'plugin.video.acetv'

    if 'HORIZ:' in streamurl:
        pluginname = 'plugin.video.horizoniptv'

    if 'ROOT2:' in streamurl:
        pluginname = 'plugin.video.rootIPTV'

    if 'MEGA:' in streamurl:
        pluginname = 'plugin.video.megaiptv'

    if 'VDRTV:' in streamurl:
        pluginname = 'plugin.video.VADER'

    if 'HDTV:' in streamurl:
        pluginname = 'plugin.video.smarthub'

    if 'HDTV2:' in streamurl:
        pluginname = 'plugin.video.ruya2'

    if 'HDTV3:' in streamurl:
        pluginname = 'plugin.video.ruya2' # XL Ruya v2.0 addon

    if 'HDTV4:' in streamurl:
        pluginname = 'plugin.video.xl'

    if 'IPLAY:' in streamurl:
        pluginname = 'plugin.video.bbciplayer'

    if 'IPLAY2:' in streamurl:
        pluginname = 'plugin.video.iplayerwww'

    if 'IPLAYR:' in streamurl:
        pluginname = 'plugin.video.iplayerwww'

    if 'IPLAYITV:' in streamurl:
        pluginname = 'plugin.video.itv'

    if 'IPLAYD:' in streamurl:
        pluginname = 'plugin.video.dex'

    if 'JINX2:' in streamurl:
        pluginname = 'plugin.video.jinxtv2'

    if 'MATS:' in streamurl:
        pluginname = 'plugin.video.MatsBuildsIPTV'

    if 'ROOT:' in streamurl:
        pluginname = 'plugin.video.rootiptv'

    if 'IPLAYRB:' in streamurl:
        pluginname = 'plugin.video.reboot'

    if 'IPLAYCLU:' in streamurl:
        pluginname = 'plugin.video.cluiptv'

    if 'IPTS' in streamurl:
        pluginname = 'plugin.video.iptvsubs'

    if 'LIVETV:' in streamurl:
        pluginname = 'plugin.video.livemix'

    if 'END:' in streamurl:
        pluginname = 'plugin.video.Endless'

    if 'FLA:' in streamurl:
        pluginname = 'plugin.video.FlawlessTv'

    if 'MAXI:' in streamurl:
        pluginname = 'plugin.video.maxiwebtv'

    if 'FLAS:' in streamurl:
        pluginname = 'plugin.video.FlawlessTv'

    if 'SPRM:' in streamurl:
        pluginname = 'plugin.video.SupremacyTV'

    if 'MCKTV:' in streamurl:
        pluginname = 'plugin.video.mcktv-plus'

    if 'TWIST:' in streamurl:
        pluginname = 'plugin.video.twisted'

    if 'PREST:' in streamurl:
        pluginname = 'plugin.video.psaddon'

    if 'BLKI:' in streamurl:
        pluginname = 'plugin.video.BlackIceTV'

    if 'FREE:' in streamurl:
        pluginname = 'plugin.video.freeview'

    if 'upnp:' in streamurl:
        pluginname = 'script.hdhomerun.view'

    return getIDS(pluginname)


def getIDS(pluginname):
    pluginid   = ''
    pluginicon = ''

    try:
        pluginlabel = xbmcaddon.Addon(pluginname).getAddonInfo('name')
        pluginid    = dixie.cleanLabel(pluginlabel)
        pluginicon  = xbmcaddon.Addon(pluginname).getAddonInfo('icon')
        return pluginid, pluginicon

    except:
        pluginid   = 'Unknown Source'
        pluginicon =  dixie.ICON
        return pluginid, pluginicon

    return pluginid, pluginicon


def selectStream(url, channel):
    streams = url.split('|')

    if len(streams) == 0:
        return None

    options, urls = getOptions(streams, channel)

    if not dixie.IGNORESTRM:
        if len(streams) == 1:
            return urls[0]

    import selectDialog

    option = selectDialog.select('Select a stream', options)

    if option < 0:
        raise Exception('Selection Cancel')

    return urls[option]


def getOptions(streams, channel, addmore=True):
    # if not updateJSON() == 'True':
    #     dixie.log('============ ERROR, ERROR, ERROR ===========')
    #     return

    options = []
    urls    = []

    for index, stream in enumerate(streams):
        pluginid = getPluginInfo(stream)

        label = pluginid[0]
        icon  = pluginid[1]

        label = '[COLOR orange][' + label + '][/COLOR] '

        if stream.startswith(OPEN_OTT):
            labelA = stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, '')
            label  = label + labelA
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, '')
        else:
            label  = label + channel

        options.append([label, index, icon])
        urls.append(stream)

    if addmore:
        options.append(['Add more...', index + 1, dixie.ICON])
        urls.append('addMore')

    return options, urls


if __name__ == '__main__':
    checkAddons()
