# coding: UTF-8
import sys
l111l1l_opy_ = sys.version_info [0] == 2
l1llll1_opy_ = 2048
l11l1l_opy_ = 7
def l11lll_opy_ (ll_opy_):
	global l111_opy_
	l111l_opy_ = ord (ll_opy_ [-1])
	l111lll_opy_ = ll_opy_ [:-1]
	l1lll_opy_ = l111l_opy_ % len (l111lll_opy_)
	l1ll1_opy_ = l111lll_opy_ [:l1lll_opy_] + l111lll_opy_ [l1lll_opy_:]
	if l111l1l_opy_:
		l1ll1ll_opy_ = unicode () .join ([unichr (ord (char) - l1llll1_opy_ - (l1l1l1_opy_ + l111l_opy_) % l11l1l_opy_) for l1l1l1_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1ll1ll_opy_ = str () .join ([chr (ord (char) - l1llll1_opy_ - (l1l1l1_opy_ + l111l_opy_) % l11l1l_opy_) for l1l1l1_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1ll1ll_opy_)
import xbmc
import xbmcgui
import xbmcaddon
import json
import datetime
import os
import dixie
import mapping
l1111ll_opy_   = l11lll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰ࡮ࡻࡸ࠯ࡶࡹࠫࠀ")
l1ll1l1_opy_ = l11lll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡺࡲࡦࡣࡰࡷࡪࡧࡳࡺ࠰ࡷࡺࠬࠁ")
l1l1l11_opy_ = l11lll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹ࡭ࡢࡴࡷ࡬ࡺࡨࠧࠂ")
l11ll_opy_ = l11lll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࠶ࠬࠃ")
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
def isValid(stream):
    dixie.log(l11lll_opy_ (u"ࠨ࠯࠰࠱ࠥࡉࡨࡦࡥ࡮ࠤࡎ࡙ࠠࡗࡃࡏࡍࡉࠦࡳࡵࡴࡨࡥࡲࠦ࠭࠮࠯ࠪࠄ"))
    dixie.log(stream)
    if (l11lll_opy_ (u"ࠩࡋࡓࡗࡏ࡚࠻ࠩࠅ") in stream) or (l11lll_opy_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱ࠱࡮ࡶࡴࡷࠩࠆ") in stream):
        dixie.log(l11lll_opy_ (u"ࠫ࠲࠳࠭ࠡࡊࡒࡖࡎࡠࡏࡏࠢࡗࡖ࡚ࡋࠠ࠮࠯࠰ࠫࠇ"))
        return True
    if (l11lll_opy_ (u"ࠬࡌࡌࡂ࠼ࠪࠈ") in stream) or (l11lll_opy_ (u"࠭ࡦ࡭ࡣࡺࡰࡪࡹࡳ࠮࡫ࡳࡸࡻ࠭ࠉ") in stream):
        dixie.log(l11lll_opy_ (u"ࠧ࠮࠯࠰ࠤࡋࡒࡁࡘࡎࡈࡗࡘࠦࡔࡓࡗࡈࠤ࠲࠳࠭ࠨࠊ"))
        return True
    if (l11lll_opy_ (u"ࠨࡈࡄࡆ࠿࠭ࠋ") in stream) or (l11lll_opy_ (u"ࠩࡶࡸࡷ࡫ࡡ࡮࠰ࡩࡥࡧ࡯ࡰࡵࡸࠪࠌ") in stream):
        dixie.log(l11lll_opy_ (u"ࠪ࠱࠲࠳ࠠࡇࡃࡅࡍࡕ࡚ࡖࠡࡖࡕ࡙ࡊࠦ࠭࠮࠯ࠪࠍ"))
        return True
    if l11lll_opy_ (u"ࠫࡍࡊࡔࡗࠩࠎ") in stream:
        dixie.log(l11lll_opy_ (u"ࠬ࠳࠭࠮ࠢࡋࡈ࡙࡜ࠠࡕࡔࡘࡉࠥ࠳࠭࠮ࠩࠏ"))
        return True
    if l1111ll_opy_ in stream:
        dixie.log(l11lll_opy_ (u"࠭࠭࠮࠯ࠣࡐࡎ࡛ࡘࠡࡖࡕ࡙ࡊࠦ࠭࠮࠯ࠪࠐ"))
        return True
    if l1ll1l1_opy_ in stream:
        dixie.log(l11lll_opy_ (u"ࠧ࠮࠯࠰ࠤࡘ࡚ࡅࡂࡕ࡜ࠤ࡙ࡘࡕࡆࠢ࠰࠱࠲࠭ࠑ"))
        return True
    dixie.log(l11lll_opy_ (u"ࠨ࠯࠰࠱ࠥ࡜ࡁࡍࡋࡇࠤࡋࡇࡌࡔࡇࠣ࠱࠲࠳ࠧࠒ"))
    return False
def getRecording(name, title, start, stream):
    if l11lll_opy_ (u"ࠩࡋࡓࡗࡏ࡚࠻ࠩࠓ") in stream:
        dixie.log(l11lll_opy_ (u"ࠪ࠱࠲࠳ࠠࡉࡑࡕࡍ࡟ࡀࠠࡪࡰࠣࡷࡹࡸࡥࡢ࡯ࠣ࠱࠲࠳ࠧࠔ"))
        return getIPTVRecording(name, title, start, stream)
    if l11lll_opy_ (u"ࠫࡋࡒࡁ࠻ࠩࠕ") in stream:
        dixie.log(l11lll_opy_ (u"ࠬ࠳࠭࠮ࠢࡉࡐࡆࡀࠠࡪࡰࠣࡷࡹࡸࡥࡢ࡯ࠣ࠱࠲࠳ࠧࠖ"))
        return getIPTVRecording(name, title, start, stream)
    if l11lll_opy_ (u"࠭ࡆࡂࡄ࠽ࠫࠗ") in stream:
        dixie.log(l11lll_opy_ (u"ࠧ࠮࠯࠰ࠤࡋࡒࡁ࠻ࠢ࡬ࡲࠥࡹࡴࡳࡧࡤࡱࠥ࠳࠭࠮ࠩ࠘"))
        return getIPTVRecording(name, title, start, stream)
    if l11lll_opy_ (u"ࠨࡊࡇࡘ࡛࠭࠙") in stream:
        dixie.log(l11lll_opy_ (u"ࠩ࠰࠱࠲ࠦࡈࡅࡖ࡙࠾ࠥ࡯࡮ࠡࡵࡷࡶࡪࡧ࡭ࠡ࠯࠰࠱ࠬࠚ"))
        return getHDTVRecording(name, title, start, stream)
    if l1111ll_opy_ in stream:
        dixie.log(l11lll_opy_ (u"ࠪ࠱࠲࠳ࠠࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡬ࡪࡷࡻ࠲ࡹࡼࠠࡪࡰࠣࡷࡹࡸࡥࡢ࡯ࠣ࠱࠲࠳ࠧࠛ"))
        addon = l1111ll_opy_
        return l1ll_opy_(addon, name, title, start, stream)
    if l1ll1l1_opy_ in stream:
        dixie.log(l11lll_opy_ (u"ࠫ࠲࠳࠭ࠡࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡶࡵࡩࡦࡳࡳࡦࡣࡶࡽ࠳ࡺࡶࠡ࡫ࡱࠤࡸࡺࡲࡦࡣࡰࠤ࠲࠳࠭ࠨࠜ"))
        addon = l1ll1l1_opy_
        return l1ll_opy_(addon, name, title, start, stream)
def getIPTVRecording(name, title, start, stream):
    dixie.log(l11lll_opy_ (u"ࠬࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࠡࡅࡄࡘࡈࡎࠠࡖࡒࠣࡍࡕ࡚ࡖࠡࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࠬࠝ"))
    dixie.log(name)
    dixie.log(title)
    dixie.log(start)
    dixie.log(stream)
    import time
    l1lllll_opy_ = stream.split(l11lll_opy_ (u"࠭ࡼࠨࠞ"))
    dixie.log(l1lllll_opy_)
    for url in l1lllll_opy_:
        url   = url.split(CLOSE_OTT)[1].rsplit(l11lll_opy_ (u"ࠧ࠻ࠩࠟ"))
        l11l1_opy_ = url[0]
        dixie.log(url)
        addon = l1111_opy_(l11l1_opy_)
    dixie.log(l11lll_opy_ (u"ࠨࡇࡓࡋ࡙ࠥࡴࡢࡴࡷࠤ࡙࡯࡭ࡦ࠰࠱࠲࠿ࠦࠥࡴࠩࠠ") % start)
    l11_opy_ = str(start)
    dixie.log(l11lll_opy_ (u"ࠩࡷ࡭ࡲ࡫ࡳࡵࡴ࡬ࡲ࡬ࡀࠠࠦࡵࠪࠡ") % l11_opy_)
    l1ll1l_opy_   = l11_opy_.split(l11lll_opy_ (u"ࠪࠤࠬࠢ"))[0]
    l1l11ll_opy_  = l11_opy_.split(l11lll_opy_ (u"ࠫࠥ࠭ࠣ"))[1]
    l1l1_opy_  = time.strptime(l1l11ll_opy_,  l11lll_opy_ (u"ࠬࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠧࠤ"))
    theTime    = time.strftime(l11lll_opy_ (u"࠭ࠥࡉ࠼ࠨࡑࠬࠥ"),  l1l1_opy_)
    dixie.log(l11lll_opy_ (u"ࠧࡊࡒࡗ࡚ࡸࡺࡡࡳࡶ࠽ࠤࠪࡹࠧࠦ") % theTime)
    l11l1l1_opy_ = time.strptime(l1ll1l_opy_,   l11lll_opy_ (u"ࠨࠧ࡜࠱ࠪࡳ࠭ࠦࡦࠪࠧ"))
    theDate    = time.strftime(l11lll_opy_ (u"ࠩࠨ࡝࠲ࠫ࡭࠮ࠧࡧࠫࠨ"), l11l1l1_opy_)
    dixie.log(l11lll_opy_ (u"ࠪࡍࡕ࡚ࡖࡥࡶ࡬ࡸࡱ࡫࠺ࠡࠧࡶࠫࠩ") % theDate)
    return getCatchupLink(addon, name, title, theDate, theTime)
def l1111_opy_(l11l1_opy_):
    if l11l1_opy_ == l11lll_opy_ (u"ࠫࡋࡇࡂࠨࠪ"):
        return l11lll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡫ࡧࡢࡩࡱࡶࡸ࡮ࡴࡧࠨࠫ")
    if l11l1_opy_ == l11lll_opy_ (u"࠭ࡆࡍࡃࠪࠬ"):
        return l11lll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡆ࡭ࡣࡺࡰࡪࡹࡳࡕࡸࠪ࠭")
    if l11l1_opy_ == l11lll_opy_ (u"ࠨࡊࡒࡖࡎࡠࠧ࠮"):
        return l11lll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡪࡲࡶ࡮ࢀ࡯࡯࡫ࡳࡸࡻ࠭࠯")
def getCatchupLink(addon, channel, theShow, theDate, theTime):
    HOME  = dixie.PROFILE
    iPATH = os.path.join(HOME, l11lll_opy_ (u"ࠪ࡭ࡳ࡯ࠧ࠰"))
    LABELFILE = os.path.join(iPATH, l11lll_opy_ (u"ࠫࡨࡧࡴࡤࡪࡸࡴ࠳ࡰࡳࡰࡰࠪ࠱"))
    labelmaps = json.load(open(LABELFILE))
    dixie.log(l11lll_opy_ (u"ࠬࡃ࠽࠾࠿ࡀࡁࠥࡩࡡࡵࡥ࡫ࡹࡵ࠴ࡪࡴࡱࡱࠤࡂࡃ࠽࠾࠿ࡀࠫ࠲"))
    dixie.log(labelmaps)
    l11llll_opy_ = l11lll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ࠳") + addon
    item   = l11l111_opy_(addon)
    try:
        l1llll_opy_  = findCatchup(l11llll_opy_, item)
        l1l1l_opy_  = mapping.mapLabel(labelmaps, channel)
        l11l_opy_   = findCatchup(l1llll_opy_, l1l1l_opy_)
        l11l11_opy_ = theDate + l11lll_opy_ (u"ࠧࠡ࠯ࠣࠫ࠴") + theTime
        l11l11_opy_ = l11l11_opy_.upper()
        l1111l_opy_      = findCatchup(l11l_opy_, l11l11_opy_, splitlabel=True)
        dixie.DialogOK(l11lll_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡱࡵࡥࡳ࡭ࡥ࡞࡝ࡅࡡࡈࡧࡴࡤࡪ࠰ࡹࡵࠦࡳࡵࡴࡨࡥࡲࠦࡦࡰࡷࡱࡨ࠳ࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࠵"), l11lll_opy_ (u"ࠩࡒࡲ࠲࡚ࡡࡱࡲ࠱ࡘ࡛ࠦࡷࡪ࡮࡯ࠤࡳࡵࡷࠡࡲ࡯ࡥࡾࡀࠠ࡜ࡅࡒࡐࡔࡘࠠࡰࡴࡤࡲ࡬࡫࡝࡜ࡄࡠࠩࡸࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࠶") % (theShow))
        return l1111l_opy_
    except:
        return l11lll_opy_ (u"ࠪࠫ࠷")
def l11l111_opy_(addon):
    if addon == l11lll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡪࡦࡨࡨࡰࡵࡷ࡭ࡳ࡭ࠧ࠸"):
        return l11lll_opy_ (u"ࠬࡌࡁࡃࠢࡌࡔ࡙࡜ࠠࡄࡃࡗࡇࡍ࡛ࡐࠨ࠹")
    if addon == l11lll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡌ࡬ࡢࡹ࡯ࡩࡸࡹࡔࡷࠩ࠺"):
        return l11lll_opy_ (u"ࠧࡇࡎࡄ࡛ࡑࡋࡓࡔࠢࡆࡅ࡙ࡉࡈࡖࡒࠪ࠻")
    if addon == l11lll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡩࡱࡵ࡭ࡿࡵ࡮ࡪࡲࡷࡺࠬ࠼"):
        return l11lll_opy_ (u"ࠩࡋࡓࡗࡏ࡚ࡐࡐࠣࡇࡆ࡚ࡃࡉࡗࡓࠫ࠽")
def findCatchup(query, item, splitlabel=False):
    response = doJSON(query)
    l111l1_opy_    = response[l11lll_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪ࠾")][l11lll_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪ࠿")]
    for file in l111l1_opy_:
        l1l1ll1_opy_ = file[l11lll_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫࡀ")]
        l1l1ll_opy_    = mapping.cleanLabel(l1l1ll1_opy_)
        if splitlabel:
            l1l1ll_opy_ = l1l1ll_opy_.upper()
            l1l1ll_opy_ = l1l1ll_opy_.rsplit(l11lll_opy_ (u"࠭ࠠ࠮ࠢࠪࡁ"), 1)[0]
        else:
            l1l1ll_opy_ = l1l1ll_opy_.upper()
        if l1l1ll_opy_ == item.upper():
            return file[l11lll_opy_ (u"ࠧࡧ࡫࡯ࡩࠬࡂ")]
def doJSON(query):
    l1l111l_opy_  = (l11lll_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࡃ") % query)
    response = xbmc.executeJSONRPC(l1l111l_opy_)
    content  = json.loads(response)
    return content
def l1ll_opy_(addon, name, title, start, stream):
    import time
    dixie.log(l11lll_opy_ (u"ࠩࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࠥࡉࡁࡕࡅࡋࠤ࡚ࡖࠠࡍ࡚ࡗ࡚ࠥࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࠩࡄ"))
    l1lllll_opy_ = stream.split(l11lll_opy_ (u"ࠪࢀࠬࡅ"))
    for url in l1lllll_opy_:
        if (l1ll1l1_opy_ in url) or (l1111ll_opy_ in url):
            dixie.log(l11lll_opy_ (u"ࠫࡑ࡞ࡔࡗࠢࡘࡖࡑ࠴࠮࠯࠼ࠣࠩࡸ࠭ࡆ") % url)
            l111ll_opy_ = url.split(CLOSE_OTT)[0].replace(OPEN_OTT, l11lll_opy_ (u"ࠬ࠭ࡇ"))
            break
    import urllib
    l1l1lll_opy_ = l11111_opy_()
    dixie.log(l11lll_opy_ (u"࠭ࡅࡑࡉࠣࡗࡹࡧࡲࡵࠢࡗ࡭ࡲ࡫࠮࠯࠰࠽ࠤࠪࡹࠧࡈ") % start)
    dixie.log(l11lll_opy_ (u"ࠧࡐࡨࡩࡷࡪࡺࠠࡪࡰࠣࡷࡪࡩ࡯࡯ࡦࡶ࠾ࠥࠫࡳࠨࡉ") % l1l1lll_opy_)
    l11l11l_opy_  =  start - datetime.timedelta(seconds=l1l1lll_opy_)
    dixie.log(l11lll_opy_ (u"ࠨࡕࡷࡥࡷࡺࠠࡕ࡫ࡰࡩࠥࡵࡦࡧࡵࡨࡸ࠿ࠦࠥࡴࠩࡊ") % l11l11l_opy_)
    l1lll1l_opy_     = l1lll1_opy_(l111ll_opy_)
    l11_opy_ = str(l11l11l_opy_)
    l11lll1_opy_   = l11_opy_.split(l11lll_opy_ (u"ࠩࠣࠫࡋ"))[0]
    l1l11ll_opy_  = l11_opy_.split(l11lll_opy_ (u"ࠪࠤࠬࡌ"))[1]
    l11ll1_opy_  = time.strptime(l1l11ll_opy_,  l11lll_opy_ (u"ࠫࠪࡎ࠺ࠦࡏ࠽ࠩࡘ࠭ࡍ"))
    l11ll1_opy_  = time.strftime(l11lll_opy_ (u"ࠬࠫࡉ࠻ࠧࡐࠤࠪࡶࠧࡎ"),  l11ll1_opy_)
    l1l1111_opy_ = time.strptime(l11lll1_opy_,   l11lll_opy_ (u"࡚࠭ࠥ࠯ࠨࡱ࠲ࠫࡤࠨࡏ"))
    l1l1111_opy_ = time.strftime(l11lll_opy_ (u"ࠧࠦࡃ࠯ࠤࠪࡈࠠࠦࡦࠪࡐ"), l1l1111_opy_)
    query = l11lll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸ࠵࠿ࡤࡪࡤࡲࡳ࡫࡬ࡠ࡫ࡧࡁࠪࡹࠦࡥࡣࡷࡩࡂࠫࡳࠧࡦࡤࡸࡪࡥࡴࡪࡶ࡯ࡩࡂࠫࡳࠧ࡫ࡰ࡫ࡂࠬ࡭ࡰࡦࡨࡁࡷ࡫ࡣࡰࡴࡧ࡭ࡳ࡭ࡳࠧࡶ࡬ࡸࡱ࡫࠽ࠦࡵࠪࡑ") % (addon, l1lll1l_opy_, l11lll1_opy_, l1l1111_opy_, l111ll_opy_)
    l1l11l_opy_  = l11lll_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬࡒ") % query
    if not l1lll1l_opy_:
        dixie.DialogOK(l11lll_opy_ (u"ࠪࡗࡴࡸࡲࡺ࠰ࠪࡓ"), l11lll_opy_ (u"ࠫ࡜࡫ࠠࡤࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡪ࡮ࡴࡤࠡࡣࠣࡧࡦࡺࡣࡩࡷࡳࠤࡸ࡫ࡲࡷ࡫ࡦࡩࠥ࡬࡯ࡳࠢࡷ࡬࡮ࡹࠠࡤࡪࡤࡲࡳ࡫࡬࠯ࠩࡔ"), l11lll_opy_ (u"ࠬࡘࡥࡷࡧࡵࡸ࡮ࡴࡧࠡࡤࡤࡧࡰࠦࡴࡰࠢࡏ࡭ࡻ࡫ࠠࡕࡘ࠱ࠫࡕ"))
        return None
    l1lll11_opy_    = xbmc.executeJSONRPC(l1l11l_opy_)
    response   = json.loads(l1lll11_opy_)
    result     = response[l11lll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࡖ")]
    l1ll11l_opy_ = result[l11lll_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࡗ")]
    for l11l1ll_opy_ in l1ll11l_opy_:
        try:
            l1l111_opy_ = l11l1ll_opy_[l11lll_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ࡘ")]
            l1l1ll_opy_   = l11l1ll_opy_[l11lll_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨ࡙")]
            if l11ll1_opy_ in l1l1ll_opy_:
                dixie.DialogOK(l11lll_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡳࡷࡧ࡮ࡨࡧࡠࡇࡦࡺࡣࡩ࠯ࡸࡴࠥࡹࡴࡳࡧࡤࡱࠥ࡬࡯ࡶࡰࡧ࠲ࡠ࠵ࡃࡐࡎࡒࡖࡢ࡚࠭"), l11lll_opy_ (u"ࠫࡔࡴ࠭ࡕࡣࡳࡴ࠳࡚ࡖࠡࡹ࡬ࡰࡱࠦ࡮ࡰࡹࠣࡴࡱࡧࡹ࠻ࠢ࡞ࡇࡔࡒࡏࡓࠢࡲࡶࡦࡴࡧࡦ࡟࡞ࡆࡢࠫࡳ࡜࠱ࡅࡡࡠ࠵ࡃࡐࡎࡒࡖࡢ࡛࠭") % (title))
                return l1l111_opy_
        except Exception, e:
            dixie.log(l11lll_opy_ (u"ࠬࡋࡒࡓࡑࡕ࠾ࠥࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡࡶ࡫ࡶࡴࡽ࡮ࠡ࡫ࡱࠤ࡬࡫ࡴࡍ࡚ࡗ࡚ࡗ࡫ࡣࡰࡴࡧ࡭ࡳ࡭ࠠࠦࡵࠪ࡜") % str(e))
            dixie.DialogOK(l11lll_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠳࠭࡝"), l11lll_opy_ (u"ࠧࡘࡧࠣࡧࡴࡻ࡬ࡥࠢࡱࡳࡹࠦࡦࡪࡰࡧࠤࡦࠦࡣࡢࡶࡦ࡬ࡺࡶࠠࡴࡶࡵࡩࡦࡳࠠࡧࡱࡵࠤࡹ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯࠱ࠫ࡞"), l11lll_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡶࡵࡽࠥࡧࡧࡢ࡫ࡱࠤࡱࡧࡴࡦࡴ࠱ࠫ࡟"))
            return None
def l1lll1_opy_(l111ll_opy_):
    l111ll_opy_ = l111ll_opy_.upper()
    if l111ll_opy_ == l11lll_opy_ (u"ࠩ࠶ࡉࠬࡠ") : return 188
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡅࡇࡉࠠࡆࡃࡖࡘࠬࡡ") : return 363
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡆࡈࡃࠨࡢ") : return 346
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡇࡍࡄࠩࡣ") : return 375
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡁࡍࡋࡅࡍࠥࡏࡒࡆࡎࡄࡒࡉ࠭ࡤ") : return 280
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡂࡐࡌࡑࡆࡒࠠࡑࡎࡄࡒࡊ࡚ࠠࡖࡕࡄࠫࡥ") : return 386
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡃࡑࡍࡒࡇࡌࠡࡒࡏࡅࡓࡋࡔࠨࡦ") : return 19
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡄࡖࡊࡔࡁࠡࡕࡓࡓࡗ࡚ࡓࠡ࠳ࠣࡌࡉࠦࡃࡓࡑࡄࡘࡎࡇࠧࡧ") : return 403
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡅࡗࡋࡎࡂࠢࡖࡔࡔࡘࡔࡔࠢ࠵ࠤࡍࡊࠠࡄࡔࡒࡅ࡙ࡏࡁࠨࡨ") : return 404
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡆࡘࡅࡏࡃࠣࡗࡕࡕࡒࡕࡕࠣ࠷ࠥࡎࡄࠡࡅࡕࡓࡆ࡚ࡉࡂࠩࡩ") : return 405
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡇࡒࡆࡐࡄࠤࡘࡖࡏࡓࡖࡖࠤ࠹ࠦࡈࡅࠢࡆࡖࡔࡇࡔࡊࡃࠪࡪ") : return 406
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡁࡓࡇࡑࡅ࡙ࠥࡐࡐࡔࡗࡗࠥ࠻ࠠࡔࡔࡅࠫ࡫") : return 407
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡂࡖࠣࡘࡍࡋࠠࡓࡃࡆࡉࡘ࠭࡬") : return 273
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡄࡅࡇࠥࡕࡎࡆ࡝ࡋࡈࡢ࠭࡭") : return 210
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡅࡆࡈࠦࡔࡘࡑ࡞ࡌࡉࡣࠧ࡮") : return 211
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡆࡊࡏࡎࠡࡕࡓࡓࡗ࡚ࠠ࠲࠲ࠣࡌࡉ࠮ࡔࡆࡕࡗ࠭ࠬ࡯") : return 300
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡇࡋࡉࡏࠢࡖࡔࡔࡘࡔࠡ࠳࠴ࠤࡍࡊࠨࡕࡇࡖࡘ࠮࠭ࡰ") : return 389
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡈࡅࡊࡐࠣࡗࡕࡕࡒࡕࠢ࠴ࡌࡉ࠮ࡔࡆࡕࡗ࠭ࠬࡱ") : return 285
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡂࡆࡋࡑࠤࡘࡖࡏࡓࡖࠣ࠶ࠥࡎࡄࠩࡖࡈࡗ࡙࠯ࠧࡲ") : return 286
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡃࡇࡌࡒ࡙ࠥࡐࡐࡔࡗࠤ࠸ࠦࡈࡅࠪࡗࡉࡘ࡚ࠩࠨࡳ") : return 287
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡄࡈࡍࡓࠦࡓࡑࡑࡕࡘࠥ࠺ࠠࡉࡆࠫࡘࡊ࡙ࡔࠪࠩࡴ") : return 288
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡅࡉࡎࡔࠠࡔࡒࡒࡖ࡙ࠦ࠵ࠡࡊࡇ࡙ࠬࡋࡓࡕࠫࠪࡵ") : return 289
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡆࡊࡏࡎࠡࡕࡓࡓࡗ࡚ࠠ࠷ࠢࡋࡈ࡚࠭ࡅࡔࡖࠬࠫࡶ") : return 290
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡇࡋࡉࡏࠢࡖࡔࡔࡘࡔࠡ࠹ࠣࡌࡉ࠮ࡔࡆࡕࡗ࠭ࠬࡷ") : return 291
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡈࡅࡊࡐࠣࡗࡕࡕࡒࡕࠢ࠻ࠤࡍࡊࠨࡕࡇࡖࡘ࠮࠭ࡸ") : return 292
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡂࡆࡋࡑࠤࡘࡖࡏࡓࡖࠣ࠽ࠥࡎࡄࠩࡖࡈࡗ࡙࠯ࠧࡹ") : return 293
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡃࡖࠣࡗࡕࡕࡒࡕࠢ࠴ࠤࡍࡊࠠࠩࡖࡈࡗ࡙࠯ࠧࡺ") : return 306
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡄࡗࠤࡘࡖࡏࡓࡖࠣ࠵ࠬࡻ") : return 17
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡅࡘ࡙ࠥࡐࡐࡔࡗࠤ࠷ࠦࡈࡅࠢࠫࡘࡊ࡙ࡔࠪࠩࡼ") : return 307
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡆ࡙ࠦࡓࡑࡑࡕࡘࠥ࠸ࠧࡽ") : return 18
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡇ࡚ࠠࡔࡒࡒࡖ࡙ࠦࡅࡔࡒࡑࠫࡾ") : return 24
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡈࡔࠡࡕࡓࡓࡗ࡚ࠠࡆࡗࡕࡓࡕࡋࠧࡿ") : return 216
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡂࡂࡄ࡜ࠤ࡙࡜ࠧࢀ") : return 299
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡃࡎࡘࡉࠥࡎࡕࡔࡖࡏࡉࡗࠦࡅࡖࡔࡒࡔࡊ࠭ࢁ") : return 241
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡄࡒࡓࡒࡋࡒࡂࡐࡊࠫࢂ") : return 192
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡅࡓ࡝ࠦࡎࡂࡖࡌࡓࡓ࠭ࢃ") : return 185
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡆࡗࡏࡔࡊࡕࡋࠤࡊ࡛ࡒࡐࡕࡓࡓࡗ࡚࠲ࠨࢄ") : return 173
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡇࡘࡉࡕࡋࡖࡌࠥࡋࡕࡓࡑࡖࡔࡔࡘࡔࠨࢅ") : return 182
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡉࡂࡔࠢࡕࡉࡆࡒࡉࡕ࡛ࠪࢆ") : return 190
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡃࡏࡄࡆࠫࢇ") : return 366
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡄࡐࡑࠫ࢈") : return 365
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡅࡄࡖ࡙ࡕࡏࡏࠢࡑࡉ࡙࡝ࡏࡓࡍ࡙ࠣࡐ࠭ࢉ") : return 186
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡆࡅࡗ࡚ࡏࡐࡐࡌࡘࡔ࠭ࢊ") : return 250
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡇࡍࡋࡌࡔࡇࡄࠤ࡙࡜ࠧࢋ") : return 179
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡈࡕࡍࡆࡆ࡜ࠤࡈࡋࡎࡕࡔࡄࡐ࡛ࠥࡓࡂࠩࢌ") : return 374
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡉࡏࡎࡇࡇ࡝ࠥࡉࡅࡏࡖࡕࡅࡑ࠭ࢍ") : return 251
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡃࡐࡏࡈࡈ࡞ࠦࡘࡕࡔࡄࠫࢎ") : return 176
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡄࡔࡌࡑࡊࠦࡉࡏࡘࡈࡗ࡙ࡏࡇࡂࡖࡌࡓࡓ࠭࢏") : return 249
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡆࡄ࡚ࡊ࠭࢐") : return 230
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡇࡍࡘࡉࡏࡗࡇࡕ࡝ࠥࡎࡉࡔࡖࡒࡖ࡞࠭࢑") : return 20
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡈࡎ࡙ࡃࡐࡘࡈࡖ࡞ࠦࡓࡄࡋࡈࡒࡈࡋࠧ࢒") : return 103
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡉࡏࡓࡄࡑ࡙ࡉࡗ࡟ࠠࡕࡗࡕࡆࡔ࠭࢓") : return 102
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡊࡉࡔࡅࡒ࡚ࡊࡘ࡙࠲ࠩ࢔") : return 98
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡄࡊࡕࡆࡓ࡛ࡋࡒ࡚ࠩ࢕") : return 370
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡅࡋࡖࡒࡊ࡟ࡃࡉࡐࡏࠫ࢖") : return 117
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡆࡌࡗࡓࡋ࡙ࡋࡗࡑࡍࡔࡘࠧࢗ") : return 118
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡈࡗࡕࡔࠠ࠳ࠩ࢘") : return 349
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡉࡘࡖࡎࠨ࢙") : return 348
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡊࡊࡅࡏࠢ࠮࠵࢚ࠬ") : return 278
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡋࡉࡓࠢࡖࡔࡔࡘࡔࡔ࢛ࠩ") : return 30
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡅࡖࡔࡒࡒࡊ࡝ࡓࠨ࢜") : return 398
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡇࡑ࡛ࠤࡘࡖࡏࡓࡖࡖࠤ࠶࠭࢝") : return 352
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡈࡒ࡜ࠥࡔࡅࡘࡕࠪ࢞") : return 274
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡊࡓࡑࡊࠠࡖࡍࠪ࢟") : return 277
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡌ࠷ࠦࡕࡌࠩࢠ") : return 271
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡍࡈࡏࠡࡇࡄࡗ࡙࠭ࢡ") : return 376
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡎࡂࡐࠢࡉࡅࡒࡏࡌ࡚ࠩࢢ") : return 377
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡈࡃࡑࠣࡗࡎࡍࡎࡂࡖࡘࡖࡊ࠭ࢣ") : return 378
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡉࡄࡒࠤ࡟ࡕࡎࡆࠩࢤ") : return 379
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡊࡊࡘ࡛࠭ࢥ") : return 384
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡋࡍࡘ࡚ࡏࡓ࡛࡙ࠣࡐ࠭ࢦ") : return 268
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡌࡎ࡙ࡔࡐࡔ࡜ࠤ࡚࡙ࡁࠨࢧ") : return 369
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡍࡕࡍࡆࠢ࠮࠵ࠬࢨ") : return 279
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡎࡏࡓࡔࡒࡖࠥࡉࡈࡂࡐࡑࡉࡑࠦࡕࡌࠩࢩ") : return 183
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡉࡅࠢࡘࡏࠬࢪ") : return 229
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡊࡖ࡙ࠤ࠷࠭ࢫ") : return 208
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡋࡗ࡚ࠥ࠹ࠧࢬ") : return 207
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡌࡘ࡛ࠦ࠴ࠨࢭ") : return 209
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡍ࡙࡜ࠧࢮ") : return 206
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡑࡌࡃࠡࡖ࡙ࠫࢯ") : return 180
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡓࡉࡐࠢࡖࡘࡆࡊࡉࡖࡏࠣ࠵࠵࠸ࠠࡉࡆࠪࢰ") : return 334
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡍࡊࡑࠣࡗ࡙ࡇࡄࡊࡗࡐࠤ࠶࠶࠳ࠡࡊࡇࠫࢱ") : return 335
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡎࡋࡒࠤࡘ࡚ࡁࡅࡋࡘࡑࠥ࠷࠰࠵ࠢࡋࡈࠬࢲ") : return 336
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡏࡌࡓ࡙ࠥࡔࡂࡆࡌ࡙ࡒࠦ࠱࠱࠷ࠣࡌࡉ࠭ࢳ") : return 337
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡐࡍࡔࠦࡓࡕࡃࡇࡍ࡚ࡓࠠ࠲࠲࠹ࠤࡍࡊࠧࢴ") : return 338
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡑࡎࡕࠠࡔࡖࡄࡈࡎ࡛ࡍࠡ࠳࠳࠻ࠥࡎࡄࠨࢵ") : return 333
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡒ࡚ࡖࠡࡄࡄࡗࡊ࠭ࢶ") : return 132
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡓࡔࡗࠢࡇࡅࡓࡉࡅࠨࢷ") : return 131
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡍࡕࡘࠣࡌࡎ࡚ࡓࠢࠩࢸ") : return 135
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡎࡖ࡙ࠤࡒ࡛ࡓࡊࡅࠪࢹ") : return 217
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡏࡗ࡚ࠥࡘࡏࡄࡍࡖࠫࢺ") : return 133
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡐ࡙࡙࡜ࠧࢻ") : return 106
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡑࡔ࡚ࡏࡓࡕ࡙ࠣࡐ࠭ࢼ") : return 215
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡓࡈࡁࠨࢽ") : return 283
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡔࡂࡄࠢࡈࡅࡘ࡚ࠧࢾ") : return 361
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡎࡊࡅࡎࠤ࡙ࡕࡏࡏࡕࠪࢿ") : return 296
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡏࡃࡗࠤࡌࡋࡏ࡙ࠡࡌࡐࡉࠦࡕࡌࠩࣀ") : return 269
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡐࡄࡘࡎࡕࡎࡂࡎࠣࡋࡊࡕࡇࡓࡃࡓࡌࡎࡉࠠࡖࡍࠪࣁ") : return 270
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡑࡅ࡙ࡏࡏࡏࡃࡏࠤࡌࡋࡏࡈࡔࡄࡔࡍࡏࡃࠡࡗࡖࡅࠬࣂ") : return 371
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡒࡎࡉࡋࠡࡌࡘࡒࡎࡕࡒࠨࣃ") : return 297
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡓࡏࡃࡌࠢࡘࡏࠬࣄ") : return 295
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡖࡒࡆࡏࡌࡉࡗ࡙ࡐࡐࡔࡗࡗࠬࣅ") : return 29
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡒࡕࡇࠣࡓࡓࡋࠧࣆ") : return 69
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡓࡖࡈࠤ࡙࡝ࡏ࡜ࡊࡇࡡࠬࣇ") : return 70
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡔࡗࡉࡏࡘࠧࣈ") : return 89
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡕࡅࡈࡏࡎࡈࠢࡘࡏࠬࣉ") : return 26
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡖࡊࡇࡌࠡࡎࡌ࡚ࡊ࡙ࠧ࣊") : return 275
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡘࡑ࡙ࠡࡄࡘࡒࡉࡋࡓࡍࡋࡊࡅࠥ࠷ࠠࡉࡆ࡞ࡈࡊࡣࠧ࣋") : return 408
    if l111ll_opy_ == l11lll_opy_ (u"࡙ࠬࡋ࡚ࠢࡑࡉ࡜࡙ࠧ࣌") : return 263
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡓࡌ࡛ࠣ࠵ࠬ࣍") : return 177
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡔࡍ࡜ࠤ࠷࠭࣎") : return 178
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡕࡎ࡝ࠥࡇࡃࡕࡋࡒࡒࠥࡓࡏࡗࡋࡈࡗ࣏ࠬ") : return 16
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡖࡏ࡞ࠦࡁࡕࡎࡄࡒ࡙ࡏࡃࠨ࣐") : return 174
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡗࡐ࡟ࠠࡄࡑࡐࡉࡉ࡟ࠠࡎࡑ࡙ࡍࡊ࡙࣑ࠧ") : return 34
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡘࡑ࡙ࠡࡆࡕࡅࡒࡇࡒࡐࡏࠣࡑࡔ࡜ࡉࡆࡕ࣒ࠪ") : return 97
    if l111ll_opy_ == l11lll_opy_ (u"࡙ࠬࡋ࡚ࠢࡉࡅࡒࡏࡌ࡚ࠢࡐࡓ࡛ࡏࡅࡔ࣓ࠩ") : return 36
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡓࡌ࡛ࠣࡋࡗࡋࡁࡕࡕࠣࡑࡔ࡜ࡉࡆࡕࠪࣔ") : return 37
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡔࡍ࡜ࠤࡒࡕࡖࡊࡇࡖࠤࡉࡏࡓࡏࡇ࡜ࠫࣕ") : return 220
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡕࡎ࡝ࠥࡖࡒࡆࡏࡌࡉࡗࡋࠠࡎࡑ࡙ࡍࡊ࡙ࠧࣖ") : return 40
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡖࡏ࡞ࠦࡓࡄࡈࡌࡌࡔࡘࡒࡐࡔࠣࡑࡔ࡜ࡉࡆࡕࠪࣗ") : return 41
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡗࡐ࡟ࠠࡔࡇࡏࡉࡈ࡚ࠠࡎࡑ࡙ࡍࡊ࡙ࠧࣘ") : return 42
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡘࡑ࡙ࠡࡕࡓࠤࡓࡋࡗࡔࠢࡋࡕࠬࣙ") : return 175
    if l111ll_opy_ == l11lll_opy_ (u"࡙ࠬࡋ࡚ࠢࡖࡔࡔࡘࡔࠡ࠳ࠣࡌࡉࠦࠨࡕࡇࡖࡘ࠮࠭ࣚ") : return 301
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡓࡌ࡛ࠣࡗࡕࡕࡒࡕࠢ࠵ࠤࡍࡊࠠࠩࡖࡈࡗ࡙࠯ࠧࣛ") : return 302
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡔࡍ࡜ࠤࡘࡖࡏࡓࡖࠣ࠷ࠥࡎࡄࠡࠪࡗࡉࡘ࡚ࠩࠨࣜ") : return 303
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡕࡎ࡝࡙ࠥࡐࡐࡔࡗࠤ࠹ࠦࡈࡅࠢࠫࡘࡊ࡙ࡔࠪࠩࣝ") : return 304
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡖࡏ࡞ࠦࡓࡑࡑࡕࡘࠥ࠻ࠠࡉࡆ࡙ࠣࠬࡋࡓࡕࠫࠪࣞ") : return 305
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡗࡐ࡟ࠠࡔࡒࡒࡖ࡙࡙ࠠ࠲ࠩࣟ") : return 95
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡘࡑ࡙ࠡࡕࡓࡓࡗ࡚ࡓࠡ࠴ࠪ࣠") : return 136
    if l111ll_opy_ == l11lll_opy_ (u"࡙ࠬࡋ࡚ࠢࡖࡔࡔࡘࡔࡔࠢ࠶ࠫ࣡") : return 43
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡓࡌ࡛ࠣࡗࡕࡕࡒࡕࡕࠣ࠸ࠬ࣢") : return 119
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡔࡍ࡜ࠤࡘࡖࡏࡓࡖࡖࠤ࠺ࣣ࠭") : return 120
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡕࡎ࡝࡚ࠥࡈࡓࡋࡏࡐࡊࡘࠠࡎࡑ࡙ࡍࡊ࡙ࠧࣤ") : return 96
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡖࡏ࡞ࠦࡌࡊࡘࡌࡒࡌ࠭ࣥ") : return 298
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡗࡕࡕࡒࡕࡕࠣࡊ࠶ࣦ࠭") : return 45
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡘ࡟ࡆ࡚ࠢࡘࡗࡆ࠭ࣧ") : return 383
    if l111ll_opy_ == l11lll_opy_ (u"࡚ࠬࡃࡎࠢ࠮࠵࡛ࠥࡋࠨࣨ") : return 189
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡔࡈ࠶ࣩࠪ") : return 88
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡕࡕࡑࠤ࠶࠭࣪") : return 339
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡖࡖࡒࠥ࠸ࠧ࣫") : return 340
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡗࡗࡓࠦ࠳ࠨ࣬") : return 341
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡘࡘࡔࠠ࠵࣭ࠩ") : return 342
    if l111ll_opy_ == l11lll_opy_ (u"࡙࡙ࠫࡎࠡ࠷࣮ࠪ") : return 343
    if l111ll_opy_ == l11lll_opy_ (u"࡚ࠬࡖ࠴ࠢࡌࡉ࣯ࠬ") : return 87
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡔࡓࡃ࡙ࡉࡑࠦࡃࡉࡃࡑࡒࡊࡒࠫ࠲ࠢࡘࡏࣰࠬ") : return 184
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡖࡕࡄࠤࡋࡕࡘࠡࡕࡓࡓࡗ࡚ࡓࠨࣱ") : return 347
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡗࡖࡅࠥࡔࡅࡕ࡙ࡒࡖࡐࣲ࠭") : return 344
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡘࡘ࡛ࠦࡉࡆࠩࣳ") : return 272
    if l111ll_opy_ == l11lll_opy_ (u"࡚ࠪࡎ࡜ࡁࠡࡖࡋࡉࠥࡎࡉࡕࡕࠤࠫࣴ") : return 130
    if l111ll_opy_ == l11lll_opy_ (u"࡛ࠫࡏࡁࡔࡃࡗࠤࡌࡕࡌࡇࠩࣵ") : return 125
    if l111ll_opy_ == l11lll_opy_ (u"ࠬ࡝ࡁࡕࡅࡋࠤࡎࡘࡅࡍࡃࡑࡈࣶࠬ") : return 281
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡘ࡙࡚࠴ࠫࣷ") : return 314
    if l111ll_opy_ == l11lll_opy_ (u"࡙࡚࡛ࠧ࠶ࠬࣸ") : return 315
    if l111ll_opy_ == l11lll_opy_ (u"ࠨ࡚࡛࡜࠸ࣹ࠭") : return 316
    if l111ll_opy_ == l11lll_opy_ (u"࡛ࠩ࡜࡝࠺ࣺࠧ") : return 317
    if l111ll_opy_ == l11lll_opy_ (u"ࠪ࡜࡝࡞࠵ࠨࣻ") : return 318
    if l111ll_opy_ == l11lll_opy_ (u"ࠫ࡞ࡋࡓࡕࡇࡕࡈࡆ࡟ࠠࠬ࠳ࠪࣼ") : return 282
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡓࡏࡗ࠶ࡐࡉࡓ࠷ࠧࣽ") : return 33
def getHDTVRecording(name, title, start, stream):
    l1lllll_opy_ = stream.split(l11lll_opy_ (u"࠭ࡼࠨࣾ"))
    for url in l1lllll_opy_:
        url   = url.split(CLOSE_OTT)[1].rsplit(l11lll_opy_ (u"ࠧ࠻ࠩࣿ"))
        l11l1_opy_ = url[0]
        if l11l1_opy_ == l11lll_opy_ (u"ࠨࡊࡇࡘ࡛࠭ऀ"):
            addon = l11lll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡰࡥࡷࡺࡨࡶࡤࠪँ")
        else:
            addon = l11lll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧ࠲ࠨं")
    dixie.log(l11lll_opy_ (u"ࠫࡆࡪࡤࡰࡰࠣࡍࡉ࠴࠮࠯࠼ࠣࠩࡸ࠭ः") % addon)
    Addon  = xbmcaddon.Addon(id=addon)
    path   = Addon.getAddonInfo(l11lll_opy_ (u"ࠬࡶࡡࡵࡪࠪऄ"))
    import sys
    sys.path.insert(0, path)
    import api
    l1l11_opy_ = Addon.getSetting(l11lll_opy_ (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧअ"))
    l11ll11_opy_  = Addon.getSetting(l11lll_opy_ (u"ࠧࡴࡧࡵࡺࡪࡸࠧआ"))
    l1l1l1l_opy_    = l11lll_opy_ (u"ࠨࠨࡧࡁࡰࡵࡤࡪࠨࡶࡁࠬइ") + l1l11_opy_ + l11lll_opy_ (u"ࠩࠩࡳࡂ࠭ई") + l11ll11_opy_
    import urllib
    l1l1lll_opy_ = l11111_opy_()
    dixie.log(l11lll_opy_ (u"ࠪࡉࡕࡍࠠࡔࡶࡤࡶࡹࠦࡔࡪ࡯ࡨ࠲࠳࠴࠺ࠡࠧࡶࠫउ") % start)
    dixie.log(l11lll_opy_ (u"ࠫࡔ࡬ࡦࡴࡧࡷࠤ࡮ࡴࠠࡴࡧࡦࡳࡳࡪࡳ࠻ࠢࠨࡷࠬऊ") % l1l1lll_opy_)
    l11l11l_opy_  =  start - datetime.timedelta(seconds=l1l1lll_opy_)
    dixie.log(l11lll_opy_ (u"࡙ࠬࡴࡢࡴࡷࠤ࡙࡯࡭ࡦࠢࡲࡪ࡫ࡹࡥࡵ࠼ࠣࠩࡸ࠭ऋ") % l11l11l_opy_)
    l11_opy_ = str(l11l11l_opy_)
    l111l11_opy_  = l11_opy_.split(l11lll_opy_ (u"࠭ࠠࠨऌ"))[0]
    l1l11l1_opy_     = l111ll1_opy_(name)
    if not l1l11l1_opy_:
        dixie.DialogOK(l11lll_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠴ࠧऍ"), l11lll_opy_ (u"ࠨ࡙ࡨࠤࡨࡵࡵ࡭ࡦࠣࡲࡴࡺࠠࡧ࡫ࡱࡨࠥࡧࠠࡤࡣࡷࡧ࡭ࡻࡰࠡࡵࡨࡶࡻ࡯ࡣࡦࠢࡩࡳࡷࠦࡴࡩ࡫ࡶࠤࡨ࡮ࡡ࡯ࡰࡨࡰ࠳࠭ऎ"), l11lll_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡷࡶࡾࠦࡡ࡯ࡱࡷ࡬ࡪࡸࠠࡤࡪࡤࡲࡳ࡫࡬࠯ࠩए"))
        return None
    l1ll111_opy_  = l11_opy_.split(l11lll_opy_ (u"ࠪ࠱ࠬऐ"), 1)[-1].rsplit(l11lll_opy_ (u"ࠫ࠿࠭ऑ"), 1)[0]
    theTime    = urllib.quote_plus(l1ll111_opy_)
    response   = api.remote_call( l11lll_opy_ (u"ࠧࡺࡶࡢࡴࡦ࡬࡮ࡼࡥ࠰ࡩࡨࡸࡤࡨࡹࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡡࡤࡲࡩࡥࡤࡢࡶࡨ࠲ࡵ࡮ࡰࠣऒ") , {l11lll_opy_ (u"ࠨࡤࡢࡶࡨࠦओ"): l111l11_opy_, l11lll_opy_ (u"ࠢࡪࡦࠥऔ"): l1l11l1_opy_ } )
    l1ll11l_opy_ = response[l11lll_opy_ (u"ࠣࡤࡲࡨࡾࠨक")]
    if not l1ll11l_opy_:
        dixie.DialogOK(l11lll_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠯ࠩख"), l11lll_opy_ (u"࡛ࠪࡪࠦࡣࡰࡷ࡯ࡨࠥࡴ࡯ࡵࠢࡩ࡭ࡳࡪࠠࡢࠢࡦࡥࡹࡩࡨࡶࡲࠣࡷࡹࡸࡥࡢ࡯ࠣࡪࡴࡸࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲ࠴ࠧग"), l11lll_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡹࡸࡹࠡࡣࡪࡥ࡮ࡴࠠ࡭ࡣࡷࡩࡷ࠴ࠧघ"))
        return None
    for l11l1ll_opy_ in l1ll11l_opy_:
        l1l111_opy_ = l11l1ll_opy_[l11lll_opy_ (u"ࠧࡶ࡬ࡰࡶࠥङ")]
        if l1ll111_opy_ in l1l111_opy_:
            dixie.DialogOK(l11lll_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡯ࡳࡣࡱ࡫ࡪࡣࡃࡢࡶࡦ࡬࠲ࡻࡰࠡࡵࡷࡶࡪࡧ࡭ࠡࡨࡲࡹࡳࡪ࠮࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩच"), l11lll_opy_ (u"ࠧࡐࡰ࠰ࡘࡦࡶࡰ࠯ࡖ࡙ࠤࡼ࡯࡬࡭ࠢࡱࡳࡼࠦࡰ࡭ࡣࡼ࠾ࠥࡡࡃࡐࡎࡒࡖࠥࡵࡲࡢࡰࡪࡩࡢࡡࡂ࡞ࠧࡶ࡟࠴ࡈ࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩछ") % (title))
            return l11l1ll_opy_[l11lll_opy_ (u"ࠣࡷࡵࡰࠧज")] + l1l1l1l_opy_
def l111ll1_opy_(name):
    l1ll11_opy_   = dixie.PROFILE
    l1l_opy_ = os.path.join(l1ll11_opy_, l11lll_opy_ (u"ࠩ࡬ࡲ࡮࠭झ"), l11lll_opy_ (u"ࠪࡧࡦࡺࡣࡩࡷࡳ࠲ࡹࡾࡴࠨञ"))
    l1111l1_opy_   = json.load(open(l1l_opy_))
    for channel in l1111l1_opy_:
        if name.upper() == channel[l11lll_opy_ (u"ࠫࡔ࡚ࡔࡗࠩट")].upper():
            return channel[l11lll_opy_ (u"࡛ࠬࡒࡍࠩठ")]
def l11111_opy_():
    import time
    gmt = time.gmtime()
    loc = time.localtime()
    GMT = datetime.datetime(*gmt[:6]).isoformat(l11lll_opy_ (u"࠭ࠠࠨड"))
    LOC = datetime.datetime(*loc[:6]).isoformat(l11lll_opy_ (u"ࠧࠡࠩढ"))
    dixie.log(gmt)
    dixie.log(loc)
    l1_opy_ = dixie.parseTime(GMT)
    l11ll1l_opy_ = dixie.parseTime(LOC)
    dixie.log(l1_opy_)
    dixie.log(l11ll1l_opy_)
    dixie.log(l11lll_opy_ (u"ࠨࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࠥࡕࡆࡇࡕࡈࡘࠥࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࠪण"))
    l1l1lll_opy_ = l1_opy_ - l11ll1l_opy_
    dixie.log(l1l1lll_opy_)
    l1l1lll_opy_ = ((l1l1lll_opy_.days * 86400) + (l1l1lll_opy_.seconds + 1800)) / 3600
    dixie.log(l1l1lll_opy_)
    l1l1lll_opy_ *= -3600
    dixie.log(l1l1lll_opy_)
    dixie.log(l11lll_opy_ (u"ࠩࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࠫत"))
    return l1l1lll_opy_