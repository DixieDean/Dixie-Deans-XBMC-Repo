# coding: UTF-8
import sys
l1lll1ll_opy_ = sys.version_info [0] == 2
l1ll111_opy_ = 2048
l1ll1l_opy_ = 7
def l1111l_opy_ (ll_opy_):
	global l111_opy_
	l11111l_opy_ = ord (ll_opy_ [-1])
	l1llll1l_opy_ = ll_opy_ [:-1]
	l1ll1_opy_ = l11111l_opy_ % len (l1llll1l_opy_)
	l11l111_opy_ = l1llll1l_opy_ [:l1ll1_opy_] + l1llll1l_opy_ [l1ll1_opy_:]
	if l1lll1ll_opy_:
		l1l1l1l_opy_ = unicode () .join ([unichr (ord (char) - l1ll111_opy_ - (l11l1l_opy_ + l11111l_opy_) % l1ll1l_opy_) for l11l1l_opy_, char in enumerate (l11l111_opy_)])
	else:
		l1l1l1l_opy_ = str () .join ([chr (ord (char) - l1ll111_opy_ - (l11l1l_opy_ + l11111l_opy_) % l1ll1l_opy_) for l11l1l_opy_, char in enumerate (l11l111_opy_)])
	return eval (l1l1l1l_opy_)
import xbmc
import xbmcgui
import json
import time
import datetime
import os
from threading import Timer
import dixie
PATH     =  os.path.join(dixie.PROFILE, l1111l_opy_ (u"ࠪࡸࡪࡳࡰࠨࢋ"))
SETTING  = l1111l_opy_ (u"ࠫࡑࡕࡇࡊࡐࡢࡌࡉ࡚ࡖࠨࢌ")
l1l11l_opy_ =  80
def getURL(url):
    if dixie.validTime(SETTING, 60 * 60 * 8):
        response = json.load(open(PATH))
    else:
        response = l1l1ll11_opy_(url)
        l1lll1_opy_(SETTING)
    stream = url.split(l1111l_opy_ (u"ࠬࡀࠧࢍ"), 1)[-1].lower()
    try:
        result = response[l1111l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࢎ")]
        l1ll1lll_opy_  = result[l1111l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭࢏")]
    except Exception as e:
        l1l1l1l1_opy_(e)
        return None
    for file in l1ll1lll_opy_:
        l1l1lll1_opy_   = file[l1111l_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧ࢐")]
        l1l1lll1_opy_   = l1l1lll1_opy_.replace(l1111l_opy_ (u"ࠩࠣࠤࠬ࢑"), l1111l_opy_ (u"ࠪࠤࠬ࢒")).replace(l1111l_opy_ (u"ࠫࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࢓"), l1111l_opy_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࢔"))
        l1llll1_opy_ = l1l1lll1_opy_.rsplit(l1111l_opy_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ࢕"), 1)[0].split(l1111l_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡸࡪ࡬ࡸࡪࡣࠧ࢖"), 1)[-1]
        if stream == l1llll1_opy_.lower():
            return file[l1111l_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ࢗ")]
    return None
def l1l1ll11_opy_(url):
    try:
        message = l1111l_opy_ (u"ࠩࡏࡳ࡬࡭ࡩ࡯ࡩࠣ࡭ࡳࡺ࡯ࠡࡵࡨࡶࡻ࡫ࡲ࠯ࠢࡒࡲࡪࠦ࡭ࡰ࡯ࡨࡲࡹࠦࡰ࡭ࡧࡤࡷࡪ࠴ࠧ࢘")
        dixie.notify(message)
        dixie.ShowBusy()
        response = l1ll11ll_opy_(url)
        dixie.CloseBusy()
        return response
    except Exception as e:
        l1l1l1l1_opy_(e)
        return {l1111l_opy_ (u"ࠪࡉࡷࡸ࡯ࡳ࢙ࠩ") : l1111l_opy_ (u"ࠫࡕࡲࡵࡨ࡫ࡱࠤࡊࡸࡲࡰࡴ࢚ࠪ")}
def l1ll11ll_opy_(url):
    doJSON(url)
    return json.load(open(PATH))
def doJSON(url):
    l11l1ll_opy_ = l1ll1ll1_opy_(url)
    xbmc.executeJSONRPC(l11l1ll_opy_)
    l1ll1l1l_opy_  = l1ll1111_opy_(url)
    response = xbmc.executeJSONRPC(l1ll1l1l_opy_)
    content = json.loads(response.decode(l1111l_opy_ (u"ࠬࡲࡡࡵ࡫ࡱ࠱࠶࢛࠭"), l1111l_opy_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭࢜")))
    json.dump(content, open(PATH,l1111l_opy_ (u"ࠧࡸࠩ࢝")), indent=0)
    l1ll11l1_opy_(url)
def l1ll1ll1_opy_(url):
    l11111_opy_ = l1llll_opy_(url)
    l11l1ll_opy_   = (l1111l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿ࡰࡥ࡮ࡴ࡟࡭࡫ࡶࡸࠫࡺࡩࡵ࡮ࡨࡁࠫࡻࡲ࡭࠿ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ࢞") % l11111_opy_)
    return l11l1ll_opy_
def l1ll1111_opy_(url):
    l11111_opy_ = l1llll_opy_(url)
    l1ll1l1l_opy_ = (l1111l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴ࠱ࡂࡥࡨࡺࡩࡰࡰࡀࡰ࡮ࡼࡥࡵࡸࡢࡥࡱࡲࠦࡵ࡫ࡷࡰࡪࡃࡁ࡭࡮࠮ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ࢟") % l11111_opy_)
    return l1ll1l1l_opy_
def l1llll_opy_(url):
    if url.startswith(l1111l_opy_ (u"ࠪࡌࡉ࡚ࡖ࠻ࠩࢠ")):
        return l1111l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡬ࡩࡺࡶࠨࢡ")
    if url.startswith(l1111l_opy_ (u"ࠬࡎࡄࡕࡘ࠵࠾ࠬࢢ")):
        return l1111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡵࡺࡣ࡬ࡴࡹࡼࠧࢣ")
    if url.startswith(l1111l_opy_ (u"ࠧࡉࡆࡗ࡚࠸ࡀࠧࢤ")):
        return l1111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥࡹࡼࠧࢥ")
def l1ll11l1_opy_(url):
    name   = dixie.TITLE + l1111l_opy_ (u"ࠩࠣࡌࡉ࡚ࡖࠡࡗࡳࡨࡦࡺࡥࠨࢦ")
    l1ll1l11_opy_ = os.path.join(dixie.HOME, l1111l_opy_ (u"ࠪ࡬ࡩࡺࡶ࠯ࡲࡼࠫࢧ"))
    args   = url
    cmd    = l1111l_opy_ (u"ࠫࡆࡲࡡࡳ࡯ࡆࡰࡴࡩ࡫ࠩࠧࡶ࠰ࠥࡘࡵ࡯ࡕࡦࡶ࡮ࡶࡴࠩࠧࡶ࠰ࠥࠫࡳࠪ࠮ࠣࠩࡩ࠲ࠠࡕࡴࡸࡩ࠮࠭ࢨ") % (name, l1ll1l11_opy_, args, l1l11l_opy_)
    xbmc.executebuiltin(l1111l_opy_ (u"ࠬࡉࡡ࡯ࡥࡨࡰࡆࡲࡡࡳ࡯ࠫࠩࡸ࠲ࡔࡳࡷࡨ࠭ࠬࢩ") % name)
    xbmc.executebuiltin(cmd)
def l1lll1_opy_(l1l1ll1l_opy_):
    now = datetime.datetime.today()
    dixie.SetSetting(l1l1ll1l_opy_, str(now))
def l1l1l1l1_opy_(e):
    l1l1llll_opy_ = l1111l_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠱ࠦࡡ࡯ࠢࡨࡶࡷࡵࡲࠡࡱࡦࡧࡺࡸࡥࡥ࠼ࠣࡎࡘࡕࡎࠡࡇࡵࡶࡴࡸ࠺ࠡࠧࡶࠫࢪ")  %e
    l1l1l1ll_opy_ = l1111l_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡳࡧ࠰ࡰ࡮ࡴ࡫ࠡࡶ࡫࡭ࡸࠦࡣࡩࡣࡱࡲࡪࡲࠠࡢࡰࡧࠤࡹࡸࡹࠡࡣࡪࡥ࡮ࡴ࠮ࠨࢫ")
    l1ll111l_opy_ = l1111l_opy_ (u"ࠨࡗࡶࡩ࠿ࠦࡃࡰࡰࡷࡩࡽࡺࠠࡎࡧࡱࡹࠥࡃ࠾ࠡࡔࡨࡱࡴࡼࡥࠡࡕࡷࡶࡪࡧ࡭ࠨࢬ")
    dixie.log(e)
    dixie.DialogOK(l1l1llll_opy_, l1l1l1ll_opy_, l1ll111l_opy_)
    dixie.SetSetting(SETTING, l1111l_opy_ (u"ࠩࠪࢭ"))
if __name__ == l1111l_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬࢮ"):
    url = sys.argv[1]
    doJSON(url)