# coding: UTF-8
import sys
l1lll1ll_opy_ = sys.version_info [0] == 2
l1ll111_opy_ = 2048
l1ll1l_opy_ = 7
def l1111l_opy_ (ll_opy_):
	global l111_opy_
	l11111l_opy_ = ord (ll_opy_ [-1])
	l1llll1l_opy_ = ll_opy_ [:-1]
	l1ll1_opy_ = l11111l_opy_ % len (l1llll1l_opy_)
	l11l111_opy_ = l1llll1l_opy_ [:l1ll1_opy_] + l1llll1l_opy_ [l1ll1_opy_:]
	if l1lll1ll_opy_:
		l1l1l1l_opy_ = unicode () .join ([unichr (ord (char) - l1ll111_opy_ - (l11l1l_opy_ + l11111l_opy_) % l1ll1l_opy_) for l11l1l_opy_, char in enumerate (l11l111_opy_)])
	else:
		l1l1l1l_opy_ = str () .join ([chr (ord (char) - l1ll111_opy_ - (l11l1l_opy_ + l11111l_opy_) % l1ll1l_opy_) for l11l1l_opy_, char in enumerate (l11l111_opy_)])
	return eval (l1l1l1l_opy_)
import xbmc
import xbmcaddon
import json
import urllib
import os
import dixie
l1l11llll1_opy_   = l1111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡶ࡭ࡷࡺ࡫ࡸࡡ࡯ࡥࡨࠫ৙")
l1l1l1111l_opy_   = l1111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡺࡷࡶࡪࡧ࡭࠮ࡥࡲࡨࡪࡹࠧ৚")
l1l11lll1l_opy_ = l1111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡹࡼࡳࡶࡤࡶࠫ৛")
l1l1l111ll_opy_   = l1111l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡨࡪࡾࠧড়")
l1l1l11ll1_opy_   =  [l1l11llll1_opy_, l1l1l1111l_opy_, l1l11lll1l_opy_, l1l1l111ll_opy_]
def checkAddons():
    for l11l11l_opy_ in l1l1l11ll1_opy_:
        if l1l1l11lll_opy_(l11l11l_opy_):
            l1l1ll1111_opy_(l11l11l_opy_)
def l1l1l11lll_opy_(l11l11l_opy_):
    if xbmc.getCondVisibility(l1111l_opy_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠦࡵࠬࠫঢ়") % l11l11l_opy_) == 1:
        return True
    return False
def l1l1ll1111_opy_(l11l11l_opy_):
    HOME = dixie.PROFILE
    PATH = os.path.join(HOME, l1111l_opy_ (u"࠭ࡩ࡯࡫ࠪ৞"))
    l1l1ll1lll_opy_ = l1l1ll11l1_opy_(l11l11l_opy_) + l1111l_opy_ (u"ࠧ࠯࡫ࡱ࡭ࠬয়")
    l1l1l1llll_opy_  = os.path.join(PATH, l1l1ll1lll_opy_)
    response = l1l1lll1ll_opy_(l11l11l_opy_)
    result   = response[l1111l_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨৠ")]
    l1lll111_opy_ = result[l1111l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨৡ")]
    l1l1lll11l_opy_  = file(l1l1l1llll_opy_, l1111l_opy_ (u"ࠪࡻࠬৢ"))
    l1l1lll11l_opy_.write(l1111l_opy_ (u"ࠫࡠ࠭ৣ"))
    l1l1lll11l_opy_.write(l11l11l_opy_)
    l1l1lll11l_opy_.write(l1111l_opy_ (u"ࠬࡣࠧ৤"))
    l1l1lll11l_opy_.write(l1111l_opy_ (u"࠭࡜࡯ࠩ৥"))
    for l1llll1_opy_ in l1lll111_opy_:
        l1l1lll1_opy_   = l1llll1_opy_[l1111l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭০")]
        stream  = l1llll1_opy_[l1111l_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭১")]
        l1l1l11111_opy_  = l1l11ll1l1_opy_(l11l11l_opy_, l1l1lll1_opy_)
        l1llll1_opy_ = l1l1l11_opy_(l11l11l_opy_, l1l1l11111_opy_)
        l1l1lll11l_opy_.write(l1111l_opy_ (u"ࠩࠨࡷࠬ২") % l1llll1_opy_)
        l1l1lll11l_opy_.write(l1111l_opy_ (u"ࠪࡁࠬ৩"))
        l1l1lll11l_opy_.write(l1111l_opy_ (u"ࠫࠪࡹࠧ৪") % stream)
        l1l1lll11l_opy_.write(l1111l_opy_ (u"ࠬࡢ࡮ࠨ৫"))
    l1l1lll11l_opy_.write(l1111l_opy_ (u"࠭࡜࡯ࠩ৬"))
    l1l1lll11l_opy_.close()
def l1l1ll11l1_opy_(l11l11l_opy_):
    if l11l11l_opy_ == l1l11llll1_opy_:
        return l1111l_opy_ (u"ࠧࡶ࡭ࡷࡺ࡫ࡸࡡ࡯ࡥࡨࠫ৭")
    if l11l11l_opy_ == l1l1l1111l_opy_:
        return l1111l_opy_ (u"ࠨࡺࡷࡶࡪࡧ࡭࠮ࡥࡲࡨࡪࡹࠧ৮")
    if l11l11l_opy_ == l1l11lll1l_opy_:
        return l1111l_opy_ (u"ࠩ࡬ࡴࡹࡼࡳࡶࡤࡶࠫ৯")
    if l11l11l_opy_ == l1l1l111ll_opy_:
        return l1111l_opy_ (u"ࠪࡨࡪࡾࠧৰ")
def l1l1lll1ll_opy_(l11l11l_opy_):
    Addon    =  xbmcaddon.Addon(l11l11l_opy_)
    username =  Addon.getSetting(l1111l_opy_ (u"ࠫࡰࡧࡳࡶࡶࡤ࡮ࡦࡴࡩ࡮࡫ࠪৱ"))
    password =  Addon.getSetting(l1111l_opy_ (u"ࠬࡹࡡ࡭ࡣࡶࡳࡳࡧࠧ৲"))
    l1l1l1l1ll_opy_   = l1111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ৳") + l11l11l_opy_
    l1l11ll11l_opy_     = l1111l_opy_ (u"ࠧ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿ࡶࡸࡷ࡫ࡡ࡮ࡡࡹ࡭ࡩ࡫࡯ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠦࡵ࡫ࡷࡰࡪࡃࡁ࡭࡮ࠩࡹࡷࡲ࠽ࠨ৴")
    l1l1ll11ll_opy_  =  l1l1lll1l1_opy_(l11l11l_opy_)
    l1l11lllll_opy_  =  l1l1l1l1ll_opy_ + l1l11ll11l_opy_ + l1l1ll11ll_opy_
    l1l1l111l1_opy_ = l1111l_opy_ (u"ࠨࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠫ৵") + username + l1111l_opy_ (u"ࠩࠩࡴࡦࡹࡳࡸࡱࡵࡨࡂ࠭৶") + password + l1111l_opy_ (u"ࠪࠪࡹࡿࡰࡦ࠿ࡪࡩࡹࡥ࡬ࡪࡸࡨࡣࡸࡺࡲࡦࡣࡰࡷࠫࡩࡡࡵࡡ࡬ࡨࡂ࠶ࠧ৷")
    l11l1ll_opy_ = l1l1l1l1ll_opy_  + l1111l_opy_ (u"ࠫ࠴ࡅࡡࡤࡶ࡬ࡳࡳࡃࡳࡦࡥࡸࡶ࡮ࡺࡹࡠࡥ࡫ࡩࡨࡱࠦࡦࡺࡷࡶࡦࠬࡰࡢࡩࡨࠪࡵࡲ࡯ࡵࠨࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠫࡺࡩࡵ࡮ࡨࡁࡑ࡯ࡶࡦࠧ࠵࠴࡙࡜ࠦࡶࡴ࡯ࠫ৸")
    query = l1l11lllll_opy_ +  urllib.quote_plus(l1l1l111l1_opy_)
    l1l11ll1ll_opy_ = (l1111l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࠦࡵࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ৹") % l11l1ll_opy_)
    l1l11lll11_opy_ = (l1111l_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࠧࡶࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ৺") % query)
    try:
        xbmc.executeJSONRPC(l1l11ll1ll_opy_)
        response = xbmc.executeJSONRPC(l1l11lll11_opy_)
        content = json.loads(response.decode(l1111l_opy_ (u"ࠧࡶࡶࡩ࠱࠽࠭৻"), l1111l_opy_ (u"ࠨ࡫ࡪࡲࡴࡸࡥࠨৼ")))
        return content
    except Exception as e:
        l1l1l1l1_opy_(e)
        return {l1111l_opy_ (u"ࠩࡈࡶࡷࡵࡲࠨ৽") : l1111l_opy_ (u"ࠪࡔࡱࡻࡧࡪࡰࠣࡉࡷࡸ࡯ࡳࠩ৾")}
def l1l11ll1l1_opy_(l11l11l_opy_, l1l1lll1_opy_):
    if (l11l11l_opy_ == l1l11llll1_opy_) or (l11l11l_opy_ == l1l1l1111l_opy_) or (l11l11l_opy_ == l1l11lll1l_opy_):
        l1l1lll1_opy_ = l1l1lll1_opy_.replace(l1111l_opy_ (u"ࠫࠥࠦࠧ৿"), l1111l_opy_ (u"ࠬࠦࠧ਀")).replace(l1111l_opy_ (u"࠭ࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩਁ"), l1111l_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩਂ"))
        return l1l1lll1_opy_
    if l11l11l_opy_ == l1l1l111ll_opy_:
        l1l1lll1_opy_ = l1l1lll1_opy_.replace(l1111l_opy_ (u"ࠨࠢࠣࠫਃ"), l1111l_opy_ (u"ࠩࠣࠫ਄")).replace(l1111l_opy_ (u"ࠪࠤࡠ࠵ࡂ࡞ࠩਅ"), l1111l_opy_ (u"ࠫࡠ࠵ࡂ࡞ࠩਆ"))
        return l1l1lll1_opy_
def l1l1l11_opy_(l11l11l_opy_, l1l1l11111_opy_):
    if (l11l11l_opy_ == l1l11llll1_opy_) or (l11l11l_opy_ == l1l1l1111l_opy_) or (l11l11l_opy_ == l1l11lll1l_opy_):
        l1llll1_opy_ = l1l1l11111_opy_.rsplit(l1111l_opy_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧਇ"), 1)[0].split(l1111l_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡷࡩ࡫ࡷࡩࡢ࠭ਈ"), 1)[-1]
        return l1llll1_opy_
    if l11l11l_opy_ == l1l1l111ll_opy_:
        l1llll1_opy_ = l1l1l11111_opy_.rsplit(l1111l_opy_ (u"ࠧ࡜࠱ࡅࡡࠬਉ"), 1)[0].split(l1111l_opy_ (u"ࠨ࡝ࡅࡡࠬਊ"), 1)[-1]
        return l1llll1_opy_
def l1l1lll1l1_opy_(l11l11l_opy_, url):
    if (l11l11l_opy_ == l1l11llll1_opy_) or (l11l11l_opy_ == l1l1l1111l_opy_):
        return l1111l_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠶࠻࠳࠷࠸࠸࠰࠴࠷࠾࠴࠱࠶࠷࠽࠼࠵࠶࠰࠰ࡧࡱ࡭࡬ࡳࡡ࠳࠰ࡳ࡬ࡵࡅࠧ਋")
    if l11l11l_opy_ == l1l11lll1l_opy_:
        return l1111l_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠶࠳ࡽࡥ࡭ࡥࡰ࠲ࡹࡼ࠺࠹࠲࠳࠴࠴࡫࡮ࡪࡩࡰࡥ࠷࠴ࡰࡩࡲࡂࠫ਌")
    if l11l11l_opy_ == l1l1l111ll_opy_:
        return l1111l_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠻࠸࠯࠸࠼࠲࠺࠺࠮࠶࠶࠽࠼࠵࠶࠰࠰ࡧࡱ࡭࡬ࡳࡡ࠳࠰ࡳ࡬ࡵࡅࠧ਍")
def l1l1l1l1_opy_(e):
    l1l1llll_opy_ = l1111l_opy_ (u"࡙ࠬ࡯ࡳࡴࡼ࠰ࠥࡧ࡮ࠡࡧࡵࡶࡴࡸࠠࡰࡥࡦࡹࡷ࡫ࡤ࠻ࠢࡍࡗࡔࡔࠠࡆࡴࡵࡳࡷࡀࠠࠦࡵࠪ਎")  %e
    l1l1l1ll_opy_ = l1111l_opy_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡣࡰࡰࡷࡥࡨࡺࠠࡶࡵࠣࡳࡳࠦࡴࡩࡧࠣࡪࡴࡸࡵ࡮࠰ࠪਏ")
    l1ll111l_opy_ = l1111l_opy_ (u"ࠧࡖࡲ࡯ࡳࡦࡪࠠࡢࠢ࡯ࡳ࡬ࠦࡶࡪࡣࠣࡸ࡭࡫ࠠࡢࡦࡧࡳࡳࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠡࡣࡱࡨࠥࡶ࡯ࡴࡶࠣࡸ࡭࡫ࠠ࡭࡫ࡱ࡯࠳࠭ਐ")
    dixie.log(e)
    dixie.DialogOK(l1l1llll_opy_, l1l1l1ll_opy_, l1ll111l_opy_)
    dixie.SetSetting(SETTING, l1111l_opy_ (u"ࠨࠩ਑"))