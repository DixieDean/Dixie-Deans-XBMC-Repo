# coding: UTF-8
import sys
l1llll11_opy_ = sys.version_info [0] == 2
l1ll11l_opy_ = 2048
l1ll1l_opy_ = 7
def l1111l_opy_ (ll_opy_):
	global l111_opy_
	l1111l1_opy_ = ord (ll_opy_ [-1])
	l1lllll1_opy_ = ll_opy_ [:-1]
	l1ll1_opy_ = l1111l1_opy_ % len (l1lllll1_opy_)
	l11l11l_opy_ = l1lllll1_opy_ [:l1ll1_opy_] + l1lllll1_opy_ [l1ll1_opy_:]
	if l1llll11_opy_:
		l1l1ll1_opy_ = unicode () .join ([unichr (ord (char) - l1ll11l_opy_ - (l11l1l_opy_ + l1111l1_opy_) % l1ll1l_opy_) for l11l1l_opy_, char in enumerate (l11l11l_opy_)])
	else:
		l1l1ll1_opy_ = str () .join ([chr (ord (char) - l1ll11l_opy_ - (l11l1l_opy_ + l1111l1_opy_) % l1ll1l_opy_) for l11l1l_opy_, char in enumerate (l11l11l_opy_)])
	return eval (l1l1ll1_opy_)
import xbmc
import xbmcaddon
import json
import os
import shutil
import dixie
l1l1ll11ll_opy_     = l1111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡴࡴࡷࠩঃ")
l1l1lll1l1_opy_     = l1111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡵ࡬ࡶࡸࡶࡰ࠭঄")
l1l1l1ll11_opy_ = [l1l1ll11ll_opy_, l1l1lll1l1_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1111l_opy_ (u"ࠨ࡫ࡱ࡭ࠬঅ"))
def checkAddons():
    for l11l1l1_opy_ in l1l1l1ll11_opy_:
        if l1l1l1ll1l_opy_(l11l1l1_opy_):
            try: l1l1ll1ll1_opy_(l11l1l1_opy_)
            except: pass
def l1l1l1ll1l_opy_(l11l1l1_opy_):
    if xbmc.getCondVisibility(l1111l_opy_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡋࡥࡸࡇࡤࡥࡱࡱࠬࠪࡹࠩࠨআ") % l11l1l1_opy_) == 1:
        return True
    return False
def l1l1ll1ll1_opy_(l11l1l1_opy_):
    l1l1llll1l_opy_ = l1l1lll111_opy_(l11l1l1_opy_) + l1111l_opy_ (u"ࠪ࠲࡮ࡴࡩࠨই")
    l1l1ll1l1l_opy_  = os.path.join(PATH, l1l1llll1l_opy_)
    l1lll11l_opy_ = l1ll11111l_opy_(l11l1l1_opy_)
    l1l1llllll_opy_  = file(l1l1ll1l1l_opy_, l1111l_opy_ (u"ࠫࡼ࠭ঈ"))
    l1l1llllll_opy_.write(l1111l_opy_ (u"ࠬࡡࠧউ"))
    l1l1llllll_opy_.write(l11l1l1_opy_)
    l1l1llllll_opy_.write(l1111l_opy_ (u"࠭࡝ࠨঊ"))
    l1l1llllll_opy_.write(l1111l_opy_ (u"ࠧ࡝ࡰࠪঋ"))
    for channel in l1lll11l_opy_:
        l1l1llll_opy_   = channel[l1111l_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧঌ")]
        l1l1llll_opy_ = l1l1llll_opy_.replace(l1111l_opy_ (u"ࠩࠣ࡟ࠬ঍"), l1111l_opy_ (u"ࠪ࡟ࠬ঎")).replace(l1111l_opy_ (u"ࠫࡢࠦࠧএ"), l1111l_opy_ (u"ࠬࡣࠧঐ")).replace(l1111l_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡡࡲࡷࡤࡡࠬ঑"), l1111l_opy_ (u"ࠧࠨ঒")).replace(l1111l_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬ࡱࡪ࡭ࡲࡦࡧࡱࡡࠬও"), l1111l_opy_ (u"ࠩࠪঔ")).replace(l1111l_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡽࡪࡲ࡬ࡰࡹࡠࠫক"), l1111l_opy_ (u"ࠫࠬখ")).replace(l1111l_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡨ࡬ࡶࡧࡠࠫগ"), l1111l_opy_ (u"࠭ࠧঘ")).replace(l1111l_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡰࡴࡤࡲ࡬࡫࡝ࠨঙ"), l1111l_opy_ (u"ࠨࠩচ")).replace(l1111l_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡵࡩࡩࡣࠧছ"), l1111l_opy_ (u"ࠪࠫজ")).replace(l1111l_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡼ࡮ࡩࡵࡧࡠࠫঝ"), l1111l_opy_ (u"ࠬ࠭ঞ")).replace(l1111l_opy_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨট"), l1111l_opy_ (u"ࠧࠨঠ"))
        stream  = channel[l1111l_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ড")]
        l1l1llllll_opy_.write(l1111l_opy_ (u"ࠩࠨࡷࠬঢ") % l1l1llll_opy_)
        l1l1llllll_opy_.write(l1111l_opy_ (u"ࠪࡁࠬণ"))
        l1l1llllll_opy_.write(l1111l_opy_ (u"ࠫࠪࡹࠧত") % stream)
        l1l1llllll_opy_.write(l1111l_opy_ (u"ࠬࡢ࡮ࠨথ"))
    l1l1llllll_opy_.write(l1111l_opy_ (u"࠭࡜࡯ࠩদ"))
    l1l1llllll_opy_.close()
def l1l1lll111_opy_(l11l1l1_opy_):
    if l11l1l1_opy_ == l1l1ll11ll_opy_:
        return l1111l_opy_ (u"ࠧ࡯ࡶࡹࠫধ")
    if l11l1l1_opy_ == l1l1lll1l1_opy_:
        return l1111l_opy_ (u"ࠨࡷ࡮ࡸࠬন")
def l1ll11111l_opy_(l11l1l1_opy_):
    if l11l1l1_opy_ == l1l1lll1l1_opy_:
        return l1l1ll11l1_opy_(l11l1l1_opy_)
    if l11l1l1_opy_ == l1l1ll11ll_opy_:
        xbmcaddon.Addon(l1l1ll11ll_opy_).setSetting(l1111l_opy_ (u"ࠩࡪࡩࡳࡸࡥࠨ঩"), l1111l_opy_ (u"ࠪࡪࡦࡲࡳࡦࠩপ"))
        xbmcaddon.Addon(l1l1ll11ll_opy_).setSetting(l1111l_opy_ (u"ࠫࡹࡼࡧࡶ࡫ࡧࡩࠬফ"), l1111l_opy_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫব"))
    l1l1ll111l_opy_  = l1111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩভ") + l11l1l1_opy_
    l1l1lll11l_opy_ =  l1ll111111_opy_(l11l1l1_opy_)
    query   =  l1l1ll111l_opy_ + l1l1lll11l_opy_
    return sendJSON(query, l11l1l1_opy_)
def getPluginInfo(streamurl):
    if streamurl.isdigit():
        l1l1l1lll1_opy_   = l1111l_opy_ (u"ࠧࡌࡱࡧ࡭ࠥࡖࡖࡓࠢࡆ࡬ࡦࡴ࡮ࡦ࡮ࠪম")
        l1l1l1llll_opy_ = os.path.join(dixie.RESOURCES, l1111l_opy_ (u"ࠨ࡭ࡲࡨ࡮࠳ࡰࡷࡴ࠱ࡴࡳ࡭ࠧয"))
        return l1l1l1lll1_opy_, l1l1l1llll_opy_
    if streamurl.startswith(l1111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬর")):
        name = streamurl.split(l1111l_opy_ (u"ࠪ࠳࠴࠭঱"), 1)[-1].rsplit(l1111l_opy_ (u"ࠫ࠴࠭ল"), 1)[0]
    if streamurl.startswith(l1111l_opy_ (u"ࠬࡎࡄࡕࡘ࠽ࠫ঳")):
        name = l1111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡮ࡤࡵࡸࠪ঴")
    if streamurl.startswith(l1111l_opy_ (u"ࠧࡉࡆࡗ࡚࠷ࡀࠧ঵")):
        name = l1111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥ࡮ࡶࡴࡷࠩশ")
    if streamurl.startswith(l1111l_opy_ (u"ࠩࡋࡈ࡙࡜࠳࠻ࠩষ")):
        name = l1111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧࡴࡷࠩস")
    if streamurl.startswith(l1111l_opy_ (u"ࠫࡍࡊࡔࡗ࠶࠽ࠫহ")):
        name = l1111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡲࠧ঺")
    if streamurl.startswith(l1111l_opy_ (u"࠭ࡉࡑࡎࡄ࡝࠿࠭঻")):
        name = l1111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡢࡣࡥ࡬ࡴࡱࡧࡹࡦࡴ়ࠪ")
    if streamurl.startswith(l1111l_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠲࠻ࠩঽ")):
        name = l1111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡰࡦࡿࡥࡳࡹࡺࡻࠬা")
    if streamurl.startswith(l1111l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡔ࠽ࠫি")):
        name = l1111l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽࠧী")
    if streamurl.startswith(l1111l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡍ࡙࡜࠺ࠨু")):
        name = l1111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡴࡷࠩূ")
    if streamurl.startswith(l1111l_opy_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠺ࠨৃ")):
        name = l1111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡭࡫ࡹࡩࡲ࡯ࡸࠨৄ")
    if streamurl.startswith(l1111l_opy_ (u"ࠩࡸࡴࡳࡶ࠺ࠨ৅")):
        name = l1111l_opy_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱࡬ࡩ࡮࡯࡮ࡧࡵࡹࡳ࠴ࡶࡪࡧࡺࠫ৆")
    try:
        l1l1l1lll1_opy_   = xbmcaddon.Addon(name).getAddonInfo(l1111l_opy_ (u"ࠫࡳࡧ࡭ࡦࠩে"))
        l1l1l1llll_opy_ = xbmcaddon.Addon(name).getAddonInfo(l1111l_opy_ (u"ࠬ࡯ࡣࡰࡰࠪৈ"))
        l1l1ll1lll_opy_  = l1111l_opy_ (u"ࠨ࡯ࡴ࠰ࡵࡩࡲࡵࡶࡦࠪࡲࡷ࠳ࡶࡡࡵࡪ࠱࡮ࡴ࡯࡮ࠩࡺࡥࡱࡨ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࡒࡤࡸ࡭࠮ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡴࡷࡵࡦࡪ࡮ࡨ࠳ࠬ࠯ࠬࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥ࠴ࡹࡣࡳ࡫ࡳࡸ࠳ࡺࡶࡱࡱࡵࡸࡦࡲ࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠯ࡦࡥࠫ࠮࠯ࠢ৉")
        eval(l1l1ll1lll_opy_)
    except: pass
    return l1l1l1lll1_opy_, l1l1l1llll_opy_
def l1l1ll11l1_opy_(l11l1l1_opy_):
    l1l1ll111l_opy_ = l1111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ৊") + l11l1l1_opy_
    l1l1l1l1l1_opy_ = l1111l_opy_ (u"ࠨ࠱ࡂࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡳ࡯ࡥࡧࡀ࠵ࠫࡴࡡ࡮ࡧࡀࡐ࡮ࡼࡥࠦ࠴࠳ࡘ࡛ࠬࡵࡳ࡮ࡀ࡬ࡹࡺࡰࠦ࠵ࡤࠩ࠷࡬ࠥ࠳ࡨࡰࡩࡹࡧ࡬࡬ࡧࡷࡸࡱ࡫࠮ࡤࡱࠨ࠶࡫࡛ࡋࡕࡷࡵ࡯࠶࠾࠰࠳࠴࠳࠵࠻ࠫ࠲ࡧࡎ࡬ࡺࡪࠫ࠲࠶࠴࠳ࡘ࡛࠴ࡴࡹࡶࠪো")
    l1l1l1l1ll_opy_ = l1111l_opy_ (u"ࠩ࠲ࡃࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࠬ࡭ࡰࡦࡨࡁ࠶ࠬ࡮ࡢ࡯ࡨࡁࡘࡶ࡯ࡳࡶࡶࠪࡺࡸ࡬࠾ࡪࡷࡸࡵࠫ࠳ࡢࠧ࠵ࡪࠪ࠸ࡦ࡮ࡧࡷࡥࡱࡱࡥࡵࡶ࡯ࡩ࠳ࡩ࡯ࠦ࠴ࡩ࡙ࡐ࡚ࡵࡳ࡭࠴࠼࠵࠸࠲࠱࠳࠹ࠩ࠷࡬ࡓࡱࡱࡵࡸࡸࡒࡩࡴࡶ࠱ࡸࡽࡺࠧৌ")
    l1lll111_opy_  = []
    l1lll111_opy_ += sendJSON(l1l1ll111l_opy_ + l1l1l1l1l1_opy_, l11l1l1_opy_)
    l1lll111_opy_ += sendJSON(l1l1ll111l_opy_ + l1l1l1l1ll_opy_, l11l1l1_opy_)
    return l1lll111_opy_
def l1ll111111_opy_(l11l1l1_opy_):
    if l11l1l1_opy_ == l1l1ll11ll_opy_:
        return l1111l_opy_ (u"ࠪ࠳ࡄࡩࡡࡵ࠿࠰࠶ࠫࡳ࡯ࡥࡧࡀ࠶ࠫࡴࡡ࡮ࡧࡀࡑࡾࠫ࠲࠱ࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠩࡹࡷࡲ࠽ࡶࡴ࡯্ࠫ")
def sendJSON(query, l11l1l1_opy_):
    try:
        l11lll_opy_     = l1111l_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࠥࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧৎ") % query
        l1ll111_opy_  = xbmc.executeJSONRPC(l11lll_opy_)
        response = json.loads(l1ll111_opy_)
        result   = response[l1111l_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬ৏")]
        return result[l1111l_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬ৐")]
    except Exception as e:
        l1l1l1ll_opy_(e, l11l1l1_opy_)
        return {l1111l_opy_ (u"ࠧࡆࡴࡵࡳࡷ࠭৑") : l1111l_opy_ (u"ࠨࡒ࡯ࡹ࡬࡯࡮ࠡࡇࡵࡶࡴࡸࠧ৒")}
def l1l1l1ll_opy_(e, l11l1l1_opy_):
    l1ll1111_opy_ = l1111l_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠭ࠢࡤࡲࠥ࡫ࡲࡳࡱࡵࠤࡴࡩࡣࡶࡴࡨࡨ࠿ࠦࡊࡔࡑࡑࠤࡊࡸࡲࡰࡴ࠽ࠤࠪࡹࠬࠡࠧࡶࠫ৓")  % (e, l11l1l1_opy_)
    l1l1ll11_opy_ = l1111l_opy_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡧࡴࡴࡴࡢࡥࡷࠤࡺࡹࠠࡰࡰࠣࡸ࡭࡫ࠠࡧࡱࡵࡹࡲ࠴ࠧ৔")
    l1ll11l1_opy_ = l1111l_opy_ (u"࡚ࠫࡶ࡬ࡰࡣࡧࠤࡦࠦ࡬ࡰࡩࠣࡺ࡮ࡧࠠࡵࡪࡨࠤࡦࡪࡤࡰࡰࠣࡷࡪࡺࡴࡪࡰࡪࡷࠥࡧ࡮ࡥࠢࡳࡳࡸࡺࠠࡵࡪࡨࠤࡱ࡯࡮࡬࠰ࠪ৕")
    dixie.log(l11l1l1_opy_)
    dixie.log(e)
def getPlaylist():
    import requests
    l1l1ll1l11_opy_ = [l1111l_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡭࡯࠳࡮࠱࡭ࡳࡱ࠯࡬ࡱࡧ࡭ࠬ৖"), l1111l_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳ࡩࡨࡣࡩ࠲࠴ࠫৗ"), l1111l_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭࠳ࡩࡣ࡭ࡦ࠱࡭ࡴ࠭৘"), l1111l_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣ࡬ࡳ࠳ࡩࡣ࡭ࡱࡸࡨࡹࡼ࠮ࡰࡴࡪ࠳ࡰࡵࡤࡪࠩ৙")]
    l1l1ll1111_opy_ =  l1111l_opy_ (u"ࠩࠦࡉ࡝࡚ࡍ࠴ࡗࠪ৚")
    for url in l1l1ll1l11_opy_:
        dixie.log(url)
        try:
            request  = requests.get(url)
            l1l1llll11_opy_ = request.text
        except: pass
        if l1l1ll1111_opy_ in l1l1llll11_opy_:
            path = os.path.join(dixie.PROFILE, l1111l_opy_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡳ࠳ࡶࠩ৛"))
            with open(path, l1111l_opy_ (u"ࠫࡼ࠭ড়")) as f:
                f.write(l1l1llll11_opy_)
                break
    import urllib
    l1l1lll1ll_opy_ = os.path.join(PATH, l1111l_opy_ (u"ࠬࡺࡥ࡮ࡲ࡬ࡲ࡮࠭ঢ়"))
    l1l1ll1l1l_opy_  = os.path.join(PATH, l1111l_opy_ (u"࠭ࡩ࡯࡫࠵࠲࡮ࡴࡩࠨ৞"))
    l1l1ll1l11_opy_  = l1111l_opy_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡸࡦࡺࡹࡥࡳࡥࡲࡲࡹ࡫࡮ࡵ࠰ࡦࡳࡲ࠵ࡒࡦࡰࡨ࡫ࡦࡪࡥࡴࡖ࡙࠳ࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡴࡨࡲࡪ࡭ࡡࡥࡧࡶࡸࡻ࠵࡭ࡢࡵࡷࡩࡷ࠵ࡡࡥࡦࡲࡲࡸ࠸࠮ࡪࡰ࡬ࠫয়")
    urllib.urlretrieve(l1l1ll1l11_opy_, l1l1lll1ll_opy_)
    temp = open(l1l1lll1ll_opy_)
    l1l1lllll1_opy_  = open(l1l1ll1l1l_opy_, l1111l_opy_ (u"ࠨࡹࡷࠫৠ"))
    for line in temp:
        l1l1lllll1_opy_.write(line.replace(
                               l1111l_opy_ (u"ࠩ࡞ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡧࡩࡽࡣࠧৡ"), l1111l_opy_ (u"ࠪ࡟ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡽࡾ࡝ࠨৢ"))
                               .replace(l1111l_opy_ (u"ࠫࡠࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡋ࠴ࡔ࠯ࡘࡠࠫৣ"), l1111l_opy_ (u"ࠬࡡࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾࡸࡹ࡟ࠪ৤"))
                               .replace(l1111l_opy_ (u"࡛࠭ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱ࡮ࡤࡽࡪࡸࡷࡸࡹࡠࠫ৥"), l1111l_opy_ (u"ࠧ࡜ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡹࡺࡻࡡࠬ০"))
                               .replace(l1111l_opy_ (u"ࠨ࡝ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡷࡺࡢ࠭১"), l1111l_opy_ (u"ࠩ࡞ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡼࡽࡣࠧ২"))
                               .replace(l1111l_opy_ (u"ࠪ࡟ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡦࡧࡩࡩࡱ࡮ࡤࡽࡪࡸ࡝ࠨ৩"), l1111l_opy_ (u"ࠫࡠࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡾࡸ࡞ࠩ৪"))
                               .replace(l1111l_opy_ (u"ࠬࡡࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡩࡡࡴࡶࡤࡻࡦࡿ࡝ࠨ৫"), l1111l_opy_ (u"࡛࠭ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸࡹࡺࡠࠫ৬"))
                               .replace(l1111l_opy_ (u"ࠧ࡜ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡹ࡮ࡠࠫ৭"), l1111l_opy_ (u"ࠨ࡝ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡺࡻࡼࡢ࠭৮"))
                               )
    temp.close()
    l1l1lllll1_opy_.close()
    os.remove(l1l1lll1ll_opy_)