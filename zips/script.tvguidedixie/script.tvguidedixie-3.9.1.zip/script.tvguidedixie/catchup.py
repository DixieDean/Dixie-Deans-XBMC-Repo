# coding: UTF-8
import sys
l1l111_opy_ = sys.version_info [0] == 2
l11l11_opy_ = 2048
l11l1_opy_ = 7
def l1l1ll_opy_ (ll_opy_):
	global l11lll_opy_
	l11ll_opy_ = ord (ll_opy_ [-1])
	l1l11ll_opy_ = ll_opy_ [:-1]
	l1l1_opy_ = l11ll_opy_ % len (l1l11ll_opy_)
	l11l_opy_ = l1l11ll_opy_ [:l1l1_opy_] + l1l11ll_opy_ [l1l1_opy_:]
	if l1l111_opy_:
		l11111_opy_ = unicode () .join ([unichr (ord (char) - l11l11_opy_ - (l1lll1_opy_ + l11ll_opy_) % l11l1_opy_) for l1lll1_opy_, char in enumerate (l11l_opy_)])
	else:
		l11111_opy_ = str () .join ([chr (ord (char) - l11l11_opy_ - (l1lll1_opy_ + l11ll_opy_) % l11l1_opy_) for l1lll1_opy_, char in enumerate (l11l_opy_)])
	return eval (l11111_opy_)
import xbmc
import xbmcgui
import xbmcaddon
import json
import datetime
import os
import dixie
l1l1111_opy_   = l1l1ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰ࡮ࡻࡸ࠯ࡶࡹࠫࠀ")
l1111l_opy_ = l1l1ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡺࡲࡦࡣࡰࡷࡪࡧࡳࡺ࠰ࡷࡺࠬࠁ")
l1ll1ll_opy_ = l1l1ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹ࡭ࡢࡴࡷ࡬ࡺࡨࠧࠂ")
l1l1l_opy_ = l1l1ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࠶ࠬࠃ")
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
def isValid(stream):
    dixie.log(l1l1ll_opy_ (u"ࠨ࠯࠰࠱ࠥࡉࡨࡦࡥ࡮ࠤࡎ࡙ࠠࡗࡃࡏࡍࡉࠦࡳࡵࡴࡨࡥࡲࠦ࠭࠮࠯ࠪࠄ"))
    dixie.log(stream)
    if l1l1ll_opy_ (u"ࠩࡋࡈ࡙࡜ࠧࠅ") in stream:
        dixie.log(l1l1ll_opy_ (u"ࠪ࠱࠲࠳ࠠࡉࡆࡗ࡚࡚ࠥࡒࡖࡇࠣ࠱࠲࠳ࠧࠆ"))
        return True
    if l1l1111_opy_ in stream:
        dixie.log(l1l1ll_opy_ (u"ࠫ࠲࠳࠭ࠡࡎࡌ࡙࡝ࠦࡔࡓࡗࡈࠤ࠲࠳࠭ࠨࠇ"))
        return True
    if l1111l_opy_ in stream:
        dixie.log(l1l1ll_opy_ (u"ࠬ࠳࠭࠮ࠢࡖࡘࡊࡇࡓ࡚ࠢࡗࡖ࡚ࡋࠠ࠮࠯࠰ࠫࠈ"))
        return True
    dixie.log(l1l1ll_opy_ (u"࠭࠭࠮࠯࡚ࠣࡆࡒࡉࡅࠢࡉࡅࡑ࡙ࡅࠡ࠯࠰࠱ࠬࠉ"))
    return False
def getRecording(name, title, start, stream):
    if l1l1ll_opy_ (u"ࠧࡉࡆࡗ࡚ࠬࠊ") in stream:
        dixie.log(l1l1ll_opy_ (u"ࠨ࠯࠰࠱ࠥࡎࡄࡕࡘ࠽ࠤ࡮ࡴࠠࡴࡶࡵࡩࡦࡳࠠ࠮࠯࠰ࠫࠋ"))
        return getHDTVRecording(name, title, start, stream)
    if l1l1111_opy_ in stream:
        dixie.log(l1l1ll_opy_ (u"ࠩ࠰࠱࠲ࠦࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲࡩࡶࡺ࠱ࡸࡻࠦࡩ࡯ࠢࡶࡸࡷ࡫ࡡ࡮ࠢ࠰࠱࠲࠭ࠌ"))
        addon = l1l1111_opy_
        return l1ll_opy_(addon, name, title, start, stream)
    if l1111l_opy_ in stream:
        dixie.log(l1l1ll_opy_ (u"ࠪ࠱࠲࠳ࠠࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡵࡴࡨࡥࡲࡹࡥࡢࡵࡼ࠲ࡹࡼࠠࡪࡰࠣࡷࡹࡸࡥࡢ࡯ࠣ࠱࠲࠳ࠧࠍ"))
        addon = l1111l_opy_
        return l1ll_opy_(addon, name, title, start, stream)
def l1ll_opy_(addon, name, title, start, stream):
    import time
    dixie.log(l1l1ll_opy_ (u"ࠫࡤࡥ࡟ࡠࡡࡢࡣࡤࡥࠠࡄࡃࡗࡇࡍࠦࡕࡑࠢࡏ࡜࡙࡜ࠠࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࠫࠎ"))
    l11l1l_opy_ = stream.split(l1l1ll_opy_ (u"ࠬࢂࠧࠏ"))
    for url in l11l1l_opy_:
        if (l1111l_opy_ in url) or (l1l1111_opy_ in url):
            dixie.log(l1l1ll_opy_ (u"࠭ࡌ࡙ࡖ࡙ࠤ࡚ࡘࡌ࠯࠰࠱࠾ࠥࠫࡳࠨࠐ") % url)
            l1l11l_opy_ = url.split(CLOSE_OTT)[0].replace(OPEN_OTT, l1l1ll_opy_ (u"ࠧࠨࠑ"))
            break
    import urllib
    l1lll1l_opy_ = l11ll1_opy_()
    dixie.log(l1l1ll_opy_ (u"ࠨࡇࡓࡋ࡙ࠥࡴࡢࡴࡷࠤ࡙࡯࡭ࡦ࠰࠱࠲࠿ࠦࠥࡴࠩࠒ") % start)
    dixie.log(l1l1ll_opy_ (u"ࠩࡒࡪ࡫ࡹࡥࡵࠢ࡬ࡲࠥࡹࡥࡤࡱࡱࡨࡸࡀࠠࠦࡵࠪࠓ") % l1lll1l_opy_)
    l1l1l11_opy_  =  start - datetime.timedelta(seconds=l1lll1l_opy_)
    dixie.log(l1l1ll_opy_ (u"ࠪࡗࡹࡧࡲࡵࠢࡗ࡭ࡲ࡫ࠠࡰࡨࡩࡷࡪࡺ࠺ࠡࠧࡶࠫࠔ") % l1l1l11_opy_)
    l111ll_opy_     = l111l_opy_(l1l11l_opy_)
    l1l11_opy_ = str(l1l1l11_opy_)
    l1l1lll_opy_   = l1l11_opy_.split(l1l1ll_opy_ (u"ࠫࠥ࠭ࠕ"))[0]
    l1ll1l1_opy_  = l1l11_opy_.split(l1l1ll_opy_ (u"ࠬࠦࠧࠖ"))[1]
    l1l1l1_opy_  = time.strptime(l1ll1l1_opy_,  l1l1ll_opy_ (u"࠭ࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠨࠗ"))
    l1l1l1_opy_  = time.strftime(l1l1ll_opy_ (u"ࠧࠦࡋ࠽ࠩࡒࠦࠥࡱࠩ࠘"),  l1l1l1_opy_)
    l1ll111_opy_ = time.strptime(l1l1lll_opy_,   l1l1ll_opy_ (u"ࠨࠧ࡜࠱ࠪࡳ࠭ࠦࡦࠪ࠙"))
    l1ll111_opy_ = time.strftime(l1l1ll_opy_ (u"ࠩࠨࡅ࠱ࠦࠥࡃࠢࠨࡨࠬࠚ"), l1ll111_opy_)
    query = l1l1ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳ࠰ࡁࡦ࡬ࡦࡴ࡮ࡦ࡮ࡢ࡭ࡩࡃࠥࡴࠨࡧࡥࡹ࡫࠽ࠦࡵࠩࡨࡦࡺࡥࡠࡶ࡬ࡸࡱ࡫࠽ࠦࡵࠩ࡭ࡲ࡭࠽ࠧ࡯ࡲࡨࡪࡃࡲࡦࡥࡲࡶࡩ࡯࡮ࡨࡵࠩࡸ࡮ࡺ࡬ࡦ࠿ࠨࡷࠬࠛ") % (addon, l111ll_opy_, l1l1lll_opy_, l1ll111_opy_, l1l11l_opy_)
    l1ll1l_opy_  = l1l1ll_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࠥࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࠜ") % query
    if not l111ll_opy_:
        dixie.DialogOK(l1l1ll_opy_ (u"࡙ࠬ࡯ࡳࡴࡼ࠲ࠬࠝ"), l1l1ll_opy_ (u"࠭ࡗࡦࠢࡦࡳࡺࡲࡤࠡࡰࡲࡸࠥ࡬ࡩ࡯ࡦࠣࡥࠥࡩࡡࡵࡥ࡫ࡹࡵࠦࡳࡦࡴࡹ࡭ࡨ࡫ࠠࡧࡱࡵࠤࡹ࡮ࡩࡴࠢࡦ࡬ࡦࡴ࡮ࡦ࡮࠱ࠫࠞ"), l1l1ll_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡵࡴࡼࠤࡦࡴ࡯ࡵࡪࡨࡶࠥࡩࡨࡢࡰࡱࡩࡱ࠴ࠧࠟ"))
        return None
    l111l1_opy_    = xbmc.executeJSONRPC(l1ll1l_opy_)
    response   = json.loads(l111l1_opy_)
    result     = response[l1l1ll_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨࠠ")]
    l1lllll_opy_ = result[l1l1ll_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨࠡ")]
    for l1l1l1l_opy_ in l1lllll_opy_:
        try:
            l1ll11_opy_ = l1l1l1l_opy_[l1l1ll_opy_ (u"ࠪࡪ࡮ࡲࡥࠨࠢ")]
            l1llll_opy_   = l1l1l1l_opy_[l1l1ll_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪࠣ")]
            if l1l1l1_opy_ in l1llll_opy_:
                dixie.DialogOK(l1l1ll_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡵࡲࡢࡰࡪࡩࡢࡉࡡࡵࡥ࡫࠱ࡺࡶࠠࡴࡶࡵࡩࡦࡳࠠࡧࡱࡸࡲࡩ࠴࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨࠤ"), l1l1ll_opy_ (u"࠭ࡏ࡯࠯ࡗࡥࡵࡶ࠮ࡕࡘࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡻࠥࡶ࡬ࡢࡻ࠽ࠤࡠࡉࡏࡍࡑࡕࠤࡴࡸࡡ࡯ࡩࡨࡡࡠࡈ࡝ࠦࡵ࡞࠳ࡇࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨࠥ") % (title))
                return l1ll11_opy_
        except Exception, e:
            dixie.log(l1l1ll_opy_ (u"ࠧࡆࡔࡕࡓࡗࡀࠠࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣࡸ࡭ࡸ࡯ࡸࡰࠣ࡭ࡳࠦࡧࡦࡶࡏ࡜࡙࡜ࡒࡦࡥࡲࡶࡩ࡯࡮ࡨࠢࠨࡷࠬࠦ") % str(e))
            dixie.DialogOK(l1l1ll_opy_ (u"ࠨࡕࡲࡶࡷࡿ࠮ࠨࠧ"), l1l1ll_opy_ (u"࡚ࠩࡩࠥࡩ࡯ࡶ࡮ࡧࠤࡳࡵࡴࠡࡨ࡬ࡲࡩࠦࡡࠡࡥࡤࡸࡨ࡮ࡵࡱࠢࡶࡸࡷ࡫ࡡ࡮ࠢࡩࡳࡷࠦࡴࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱ࠳࠭ࠨ"), l1l1ll_opy_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡸࡷࡿࠠࡢࡩࡤ࡭ࡳࠦ࡬ࡢࡶࡨࡶ࠳࠭ࠩ"))
            return None
def l111l_opy_(l1l11l_opy_):
    l1l11l_opy_ = l1l11l_opy_.upper()
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫ࠸ࡋࠧࠪ") : return 188
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠬࡇࡂࡄࠢࡈࡅࡘ࡚ࠧࠫ") : return 363
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡁࡃࡅࠪࠬ") : return 346
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡂࡏࡆࠫ࠭") : return 375
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡃࡏࡍࡇࡏࠠࡊࡔࡈࡐࡆࡔࡄࠨ࠮") : return 280
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡄࡒࡎࡓࡁࡍࠢࡓࡐࡆࡔࡅࡕࠢࡘࡗࡆ࠭࠯") : return 386
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪࡅࡓࡏࡍࡂࡎࠣࡔࡑࡇࡎࡆࡖࠪ࠰") : return 19
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫࡆࡘࡅࡏࡃࠣࡗࡕࡕࡒࡕࡕࠣ࠵ࠥࡎࡄࠡࡅࡕࡓࡆ࡚ࡉࡂࠩ࠱") : return 403
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠬࡇࡒࡆࡐࡄࠤࡘࡖࡏࡓࡖࡖࠤ࠷ࠦࡈࡅࠢࡆࡖࡔࡇࡔࡊࡃࠪ࠲") : return 404
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡁࡓࡇࡑࡅ࡙ࠥࡐࡐࡔࡗࡗࠥ࠹ࠠࡉࡆࠣࡇࡗࡕࡁࡕࡋࡄࠫ࠳") : return 405
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡂࡔࡈࡒࡆࠦࡓࡑࡑࡕࡘࡘࠦ࠴ࠡࡊࡇࠤࡈࡘࡏࡂࡖࡌࡅࠬ࠴") : return 406
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡃࡕࡉࡓࡇࠠࡔࡒࡒࡖ࡙࡙ࠠ࠶ࠢࡖࡖࡇ࠭࠵") : return 407
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡄࡘ࡚ࠥࡈࡆࠢࡕࡅࡈࡋࡓࠨ࠶") : return 273
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪࡆࡇࡉࠠࡐࡐࡈ࡟ࡍࡊ࡝ࠨ࠷") : return 210
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫࡇࡈࡃࠡࡖ࡚ࡓࡠࡎࡄ࡞ࠩ࠸") : return 211
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠬࡈࡅࡊࡐࠣࡗࡕࡕࡒࡕࠢ࠴࠴ࠥࡎࡄࠩࡖࡈࡗ࡙࠯ࠧ࠹") : return 300
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡂࡆࡋࡑࠤࡘࡖࡏࡓࡖࠣ࠵࠶ࠦࡈࡅࠪࡗࡉࡘ࡚ࠩࠨ࠺") : return 389
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡃࡇࡌࡒ࡙ࠥࡐࡐࡔࡗࠤ࠶ࡎࡄࠩࡖࡈࡗ࡙࠯ࠧ࠻") : return 285
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡄࡈࡍࡓࠦࡓࡑࡑࡕࡘࠥ࠸ࠠࡉࡆࠫࡘࡊ࡙ࡔࠪࠩ࠼") : return 286
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡅࡉࡎࡔࠠࡔࡒࡒࡖ࡙ࠦ࠳ࠡࡊࡇ࡙ࠬࡋࡓࡕࠫࠪ࠽") : return 287
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪࡆࡊࡏࡎࠡࡕࡓࡓࡗ࡚ࠠ࠵ࠢࡋࡈ࡚࠭ࡅࡔࡖࠬࠫ࠾") : return 288
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫࡇࡋࡉࡏࠢࡖࡔࡔࡘࡔࠡ࠷ࠣࡌࡉ࠮ࡔࡆࡕࡗ࠭ࠬ࠿") : return 289
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠬࡈࡅࡊࡐࠣࡗࡕࡕࡒࡕࠢ࠹ࠤࡍࡊࠨࡕࡇࡖࡘ࠮࠭ࡀ") : return 290
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡂࡆࡋࡑࠤࡘࡖࡏࡓࡖࠣ࠻ࠥࡎࡄࠩࡖࡈࡗ࡙࠯ࠧࡁ") : return 291
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡃࡇࡌࡒ࡙ࠥࡐࡐࡔࡗࠤ࠽ࠦࡈࡅࠪࡗࡉࡘ࡚ࠩࠨࡂ") : return 292
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡄࡈࡍࡓࠦࡓࡑࡑࡕࡘࠥ࠿ࠠࡉࡆࠫࡘࡊ࡙ࡔࠪࠩࡃ") : return 293
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡅࡘ࡙ࠥࡐࡐࡔࡗࠤ࠶ࠦࡈࡅࠢࠫࡘࡊ࡙ࡔࠪࠩࡄ") : return 306
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪࡆ࡙ࠦࡓࡑࡑࡕࡘࠥ࠷ࠧࡅ") : return 17
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫࡇ࡚ࠠࡔࡒࡒࡖ࡙ࠦ࠲ࠡࡊࡇࠤ࡚࠭ࡅࡔࡖࠬࠫࡆ") : return 307
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠬࡈࡔࠡࡕࡓࡓࡗ࡚ࠠ࠳ࠩࡇ") : return 18
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡂࡕࠢࡖࡔࡔࡘࡔࠡࡇࡖࡔࡓ࠭ࡈ") : return 24
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡃࡖࠣࡗࡕࡕࡒࡕࠢࡈ࡙ࡗࡕࡐࡆࠩࡉ") : return 216
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡄࡄࡆ࡞ࠦࡔࡗࠩࡊ") : return 299
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡅࡐ࡚ࡋࠠࡉࡗࡖࡘࡑࡋࡒࠡࡇࡘࡖࡔࡖࡅࠨࡋ") : return 241
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪࡆࡔࡕࡍࡆࡔࡄࡒࡌ࠭ࡌ") : return 192
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫࡇࡕࡘࠡࡐࡄࡘࡎࡕࡎࠨࡍ") : return 185
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠬࡈࡒࡊࡖࡌࡗࡍࠦࡅࡖࡔࡒࡗࡕࡕࡒࡕ࠴ࠪࡎ") : return 173
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡂࡓࡋࡗࡍࡘࡎࠠࡆࡗࡕࡓࡘࡖࡏࡓࡖࠪࡏ") : return 182
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡄࡄࡖࠤࡗࡋࡁࡍࡋࡗ࡝ࠬࡐ") : return 190
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡅࡑࡆࡈ࠭ࡑ") : return 366
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡆࡒࡓ࠭ࡒ") : return 365
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪࡇࡆࡘࡔࡐࡑࡑࠤࡓࡋࡔࡘࡑࡕࡏ࡛ࠥࡋࠨࡓ") : return 186
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫࡈࡇࡒࡕࡑࡒࡒࡎ࡚ࡏࠨࡔ") : return 250
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠬࡉࡈࡆࡎࡖࡉࡆࠦࡔࡗࠩࡕ") : return 179
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡃࡐࡏࡈࡈ࡞ࠦࡃࡆࡐࡗࡖࡆࡒࠠࡖࡕࡄࠫࡖ") : return 374
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡄࡑࡐࡉࡉ࡟ࠠࡄࡇࡑࡘࡗࡇࡌࠨࡗ") : return 251
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡅࡒࡑࡊࡊ࡙࡚ࠡࡗࡖࡆ࠭ࡘ") : return 176
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡆࡖࡎࡓࡅࠡࡋࡑ࡚ࡊ࡙ࡔࡊࡉࡄࡘࡎࡕࡎࠨ࡙") : return 249
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪࡈࡆ࡜ࡅࠨ࡚") : return 230
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫࡉࡏࡓࡄࡑ࡙ࡉࡗ࡟ࠠࡉࡋࡖࡘࡔࡘ࡙ࠨ࡛") : return 20
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠬࡊࡉࡔࡅࡒ࡚ࡊࡘ࡙ࠡࡕࡆࡍࡊࡔࡃࡆࠩ࡜") : return 103
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡄࡊࡕࡆࡓ࡛ࡋࡒ࡚ࠢࡗ࡙ࡗࡈࡏࠨ࡝") : return 102
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡅࡋࡖࡇࡔ࡜ࡅࡓ࡛࠴ࠫ࡞") : return 98
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡆࡌࡗࡈࡕࡖࡆࡔ࡜ࠫ࡟") : return 370
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡇࡍࡘࡔࡅ࡚ࡅࡋࡒࡑ࠭ࡠ") : return 117
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪࡈࡎ࡙ࡎࡆ࡛ࡍ࡙ࡓࡏࡏࡓࠩࡡ") : return 118
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫࡊ࡙ࡐࡏࠢ࠵ࠫࡢ") : return 349
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠬࡋࡓࡑࡐࠪࡣ") : return 348
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡅࡅࡇࡑࠤ࠰࠷ࠧࡤ") : return 278
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡆࡋࡕࠤࡘࡖࡏࡓࡖࡖࠫࡥ") : return 30
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡇࡘࡖࡔࡔࡅࡘࡕࠪࡦ") : return 398
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡉࡓ࡝ࠦࡓࡑࡑࡕࡘࡘࠦ࠱ࠨࡧ") : return 352
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪࡊࡔ࡞ࠠࡏࡇ࡚ࡗࠬࡨ") : return 274
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫࡌࡕࡌࡅࠢࡘࡏࠬࡩ") : return 277
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠬࡎ࠲ࠡࡗࡎࠫࡪ") : return 271
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡈࡃࡑࠣࡉࡆ࡙ࡔࠨ࡫") : return 376
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡉࡄࡒࠤࡋࡇࡍࡊࡎ࡜ࠫ࡬") : return 377
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡊࡅࡓ࡙ࠥࡉࡈࡐࡄࡘ࡚ࡘࡅࠨ࡭") : return 378
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡋࡆࡔ࡚ࠦࡐࡐࡈࠫ࡮") : return 379
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪࡌࡌ࡚ࡖࠨ࡯") : return 384
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫࡍࡏࡓࡕࡑࡕ࡝࡛ࠥࡋࠨࡰ") : return 268
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠬࡎࡉࡔࡖࡒࡖ࡞ࠦࡕࡔࡃࠪࡱ") : return 369
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡈࡐࡏࡈࠤ࠰࠷ࠧࡲ") : return 279
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡉࡑࡕࡖࡔࡘࠠࡄࡊࡄࡒࡓࡋࡌࠡࡗࡎࠫࡳ") : return 183
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡋࡇࠤ࡚ࡑࠧࡴ") : return 229
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡌࡘ࡛ࠦ࠲ࠨࡵ") : return 208
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪࡍ࡙࡜ࠠ࠴ࠩࡶ") : return 207
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫࡎ࡚ࡖࠡ࠶ࠪࡷ") : return 209
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠬࡏࡔࡗࠩࡸ") : return 206
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡌࡇࡅࠣࡘ࡛࠭ࡹ") : return 180
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡎࡋࡒࠤࡘ࡚ࡁࡅࡋࡘࡑࠥ࠷࠰࠳ࠢࡋࡈࠬࡺ") : return 334
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡏࡌࡓ࡙ࠥࡔࡂࡆࡌ࡙ࡒࠦ࠱࠱࠵ࠣࡌࡉ࠭ࡻ") : return 335
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡐࡍࡔࠦࡓࡕࡃࡇࡍ࡚ࡓࠠ࠲࠲࠷ࠤࡍࡊࠧࡼ") : return 336
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪࡑࡎࡕࠠࡔࡖࡄࡈࡎ࡛ࡍࠡ࠳࠳࠹ࠥࡎࡄࠨࡽ") : return 337
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫࡒࡏࡏࠡࡕࡗࡅࡉࡏࡕࡎࠢ࠴࠴࠻ࠦࡈࡅࠩࡾ") : return 338
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠬࡓࡉࡐࠢࡖࡘࡆࡊࡉࡖࡏࠣ࠵࠵࠽ࠠࡉࡆࠪࡿ") : return 333
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡍࡕࡘࠣࡆࡆ࡙ࡅࠨࢀ") : return 132
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡎࡖ࡙ࠤࡉࡇࡎࡄࡇࠪࢁ") : return 131
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡏࡗ࡚ࠥࡎࡉࡕࡕࠤࠫࢂ") : return 135
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡐࡘ࡛ࠦࡍࡖࡕࡌࡇࠬࢃ") : return 217
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪࡑ࡙࡜ࠠࡓࡑࡆࡏࡘ࠭ࢄ") : return 133
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫࡒ࡛ࡔࡗࠩࢅ") : return 106
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠬࡓࡏࡕࡑࡕࡗ࡛ࠥࡋࠨࢆ") : return 215
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡎࡃࡃࠪࢇ") : return 283
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡏࡄࡆࠤࡊࡇࡓࡕࠩ࢈") : return 361
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡐࡌࡇࡐࠦࡔࡐࡑࡑࡗࠬࢉ") : return 296
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡑࡅ࡙ࠦࡇࡆࡑ࡛ࠣࡎࡒࡄࠡࡗࡎࠫࢊ") : return 269
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪࡒࡆ࡚ࡉࡐࡐࡄࡐࠥࡍࡅࡐࡉࡕࡅࡕࡎࡉࡄࠢࡘࡏࠬࢋ") : return 270
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫࡓࡇࡔࡊࡑࡑࡅࡑࠦࡇࡆࡑࡊࡖࡆࡖࡈࡊࡅ࡙ࠣࡘࡇࠧࢌ") : return 371
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠬࡔࡉࡄࡍࠣࡎ࡚ࡔࡉࡐࡔࠪࢍ") : return 297
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡎࡊࡅࡎࠤ࡚ࡑࠧࢎ") : return 295
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡑࡔࡈࡑࡎࡋࡒࡔࡒࡒࡖ࡙࡙ࠧ࢏") : return 29
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡔࡗࡉࠥࡕࡎࡆࠩ࢐") : return 69
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡕࡘࡊࠦࡔࡘࡑ࡞ࡌࡉࡣࠧ࢑") : return 70
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪࡖ࡙ࡋࡊࡓࠩ࢒") : return 89
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫࡗࡇࡃࡊࡐࡊࠤ࡚ࡑࠧ࢓") : return 26
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠬࡘࡅࡂࡎࠣࡐࡎ࡜ࡅࡔࠩ࢔") : return 275
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡓࡌ࡛ࠣࡆ࡚ࡔࡄࡆࡕࡏࡍࡌࡇࠠ࠲ࠢࡋࡈࡠࡊࡅ࡞ࠩ࢕") : return 408
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡔࡍ࡜ࠤࡓࡋࡗࡔࠩ࢖") : return 263
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡕࡎ࡝ࠥ࠷ࠧࢗ") : return 177
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡖࡏ࡞ࠦ࠲ࠨ࢘") : return 178
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪࡗࡐ࡟ࠠࡂࡅࡗࡍࡔࡔࠠࡎࡑ࡙ࡍࡊ࡙࢙ࠧ") : return 16
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫࡘࡑ࡙ࠡࡃࡗࡐࡆࡔࡔࡊࡅ࢚ࠪ") : return 174
    if l1l11l_opy_ == l1l1ll_opy_ (u"࡙ࠬࡋ࡚ࠢࡆࡓࡒࡋࡄ࡚ࠢࡐࡓ࡛ࡏࡅࡔ࢛ࠩ") : return 34
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡓࡌ࡛ࠣࡈࡗࡇࡍࡂࡔࡒࡑࠥࡓࡏࡗࡋࡈࡗࠬ࢜") : return 97
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡔࡍ࡜ࠤࡋࡇࡍࡊࡎ࡜ࠤࡒࡕࡖࡊࡇࡖࠫ࢝") : return 36
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡕࡎ࡝ࠥࡍࡒࡆࡃࡗࡗࠥࡓࡏࡗࡋࡈࡗࠬ࢞") : return 37
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡖࡏ࡞ࠦࡍࡐࡘࡌࡉࡘࠦࡄࡊࡕࡑࡉ࡞࠭࢟") : return 220
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪࡗࡐ࡟ࠠࡑࡔࡈࡑࡎࡋࡒࡆࠢࡐࡓ࡛ࡏࡅࡔࠩࢠ") : return 40
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫࡘࡑ࡙ࠡࡕࡆࡊࡎࡎࡏࡓࡔࡒࡖࠥࡓࡏࡗࡋࡈࡗࠬࢡ") : return 41
    if l1l11l_opy_ == l1l1ll_opy_ (u"࡙ࠬࡋ࡚ࠢࡖࡉࡑࡋࡃࡕࠢࡐࡓ࡛ࡏࡅࡔࠩࢢ") : return 42
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡓࡌ࡛ࠣࡗࡕࠦࡎࡆ࡙ࡖࠤࡍࡗࠧࢣ") : return 175
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡔࡍ࡜ࠤࡘࡖࡏࡓࡖࠣ࠵ࠥࡎࡄࠡࠪࡗࡉࡘ࡚ࠩࠨࢤ") : return 301
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡕࡎ࡝࡙ࠥࡐࡐࡔࡗࠤ࠷ࠦࡈࡅࠢࠫࡘࡊ࡙ࡔࠪࠩࢥ") : return 302
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡖࡏ࡞ࠦࡓࡑࡑࡕࡘࠥ࠹ࠠࡉࡆ࡙ࠣࠬࡋࡓࡕࠫࠪࢦ") : return 303
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪࡗࡐ࡟ࠠࡔࡒࡒࡖ࡙ࠦ࠴ࠡࡊࡇࠤ࡚࠭ࡅࡔࡖࠬࠫࢧ") : return 304
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫࡘࡑ࡙ࠡࡕࡓࡓࡗ࡚ࠠ࠶ࠢࡋࡈࠥ࠮ࡔࡆࡕࡗ࠭ࠬࢨ") : return 305
    if l1l11l_opy_ == l1l1ll_opy_ (u"࡙ࠬࡋ࡚ࠢࡖࡔࡔࡘࡔࡔࠢ࠴ࠫࢩ") : return 95
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡓࡌ࡛ࠣࡗࡕࡕࡒࡕࡕࠣ࠶ࠬࢪ") : return 136
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡔࡍ࡜ࠤࡘࡖࡏࡓࡖࡖࠤ࠸࠭ࢫ") : return 43
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡕࡎ࡝࡙ࠥࡐࡐࡔࡗࡗࠥ࠺ࠧࢬ") : return 119
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡖࡏ࡞ࠦࡓࡑࡑࡕࡘࡘࠦ࠵ࠨࢭ") : return 120
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪࡗࡐ࡟ࠠࡕࡊࡕࡍࡑࡒࡅࡓࠢࡐࡓ࡛ࡏࡅࡔࠩࢮ") : return 96
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫࡘࡑ࡙ࠡࡎࡌ࡚ࡎࡔࡇࠨࢯ") : return 298
    if l1l11l_opy_ == l1l1ll_opy_ (u"࡙ࠬࡐࡐࡔࡗࡗࠥࡌ࠱ࠨࢰ") : return 45
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡓ࡚ࡈ࡜ࠤ࡚࡙ࡁࠨࢱ") : return 383
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡕࡅࡐࠤ࠰࠷ࠠࡖࡍࠪࢲ") : return 189
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡖࡊ࠸ࠬࢳ") : return 88
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡗࡗࡓࠦ࠱ࠨࢴ") : return 339
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪࡘࡘࡔࠠ࠳ࠩࢵ") : return 340
    if l1l11l_opy_ == l1l1ll_opy_ (u"࡙࡙ࠫࡎࠡ࠵ࠪࢶ") : return 341
    if l1l11l_opy_ == l1l1ll_opy_ (u"࡚ࠬࡓࡏࠢ࠷ࠫࢷ") : return 342
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡔࡔࡐࠣ࠹ࠬࢸ") : return 343
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡕࡘ࠶ࠤࡎࡋࠧࢹ") : return 87
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨࡖࡕࡅ࡛ࡋࡌࠡࡅࡋࡅࡓࡔࡅࡍ࠭࠴ࠤ࡚ࡑࠧࢺ") : return 184
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠩࡘࡗࡆࠦࡆࡐ࡚ࠣࡗࡕࡕࡒࡕࡕࠪࢻ") : return 347
    if l1l11l_opy_ == l1l1ll_opy_ (u"࡙ࠪࡘࡇࠠࡏࡇࡗ࡛ࡔࡘࡋࠨࢼ") : return 344
    if l1l11l_opy_ == l1l1ll_opy_ (u"࡚࡚ࠫࡖࠡࡋࡈࠫࢽ") : return 272
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠬ࡜ࡉࡗࡃࠣࡘࡍࡋࠠࡉࡋࡗࡗࠦ࠭ࢾ") : return 130
    if l1l11l_opy_ == l1l1ll_opy_ (u"࠭ࡖࡊࡃࡖࡅ࡙ࠦࡇࡐࡎࡉࠫࢿ") : return 125
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡘࡃࡗࡇࡍࠦࡉࡓࡇࡏࡅࡓࡊࠧࣀ") : return 281
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠨ࡚࡛࡜࠶࠭ࣁ") : return 314
    if l1l11l_opy_ == l1l1ll_opy_ (u"࡛ࠩ࡜࡝࠸ࠧࣂ") : return 315
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠪ࡜࡝࡞࠳ࠨࣃ") : return 316
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠫ࡝࡞ࡘ࠵ࠩࣄ") : return 317
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠬ࡞ࡘ࡙࠷ࠪࣅ") : return 318
    if l1l11l_opy_ == l1l1ll_opy_ (u"࡙࠭ࡆࡕࡗࡉࡗࡊࡁ࡚ࠢ࠮࠵ࠬࣆ") : return 282
    if l1l11l_opy_ == l1l1ll_opy_ (u"ࠧࡎࡑ࡙࠸ࡒࡋࡎ࠲ࠩࣇ") : return 33
def getHDTVRecording(name, title, start, stream):
    l11l1l_opy_ = stream.split(l1l1ll_opy_ (u"ࠨࡾࠪࣈ"))
    for url in l11l1l_opy_:
        url   = url.split(CLOSE_OTT)[1].rsplit(l1l1ll_opy_ (u"ࠩ࠽ࠫࣉ"))
        l11_opy_ = url[0]
        if l11_opy_ == l1l1ll_opy_ (u"ࠪࡌࡉ࡚ࡖࠨ࣊"):
            addon = l1l1ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡲࡧࡲࡵࡪࡸࡦࠬ࣋")
        else:
            addon = l1l1ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢ࠴ࠪ࣌")
    dixie.log(l1l1ll_opy_ (u"࠭ࡁࡥࡦࡲࡲࠥࡏࡄ࠯࠰࠱࠾ࠥࠫࡳࠨ࣍") % addon)
    Addon  = xbmcaddon.Addon(id=addon)
    path   = Addon.getAddonInfo(l1l1ll_opy_ (u"ࠧࡱࡣࡷ࡬ࠬ࣎"))
    import sys
    sys.path.insert(0, path)
    import api
    l1ll1_opy_ = Addon.getSetting(l1l1ll_opy_ (u"ࠨࡵࡨࡷࡸ࡯࡯࡯࣏ࠩ"))
    l1l1ll1_opy_  = Addon.getSetting(l1l1ll_opy_ (u"ࠩࡶࡩࡷࡼࡥࡳ࣐ࠩ"))
    l1lll11_opy_    = l1l1ll_opy_ (u"ࠪࠪࡩࡃ࡫ࡰࡦ࡬ࠪࡸࡃ࣑ࠧ") + l1ll1_opy_ + l1l1ll_opy_ (u"ࠫࠫࡵ࠽ࠨ࣒") + l1l1ll1_opy_
    import urllib
    l1lll1l_opy_ = l11ll1_opy_()
    dixie.log(l1l1ll_opy_ (u"ࠬࡋࡐࡈࠢࡖࡸࡦࡸࡴࠡࡖ࡬ࡱࡪ࠴࠮࠯࠼ࠣࠩࡸ࣓࠭") % start)
    dixie.log(l1l1ll_opy_ (u"࠭ࡏࡧࡨࡶࡩࡹࠦࡩ࡯ࠢࡶࡩࡨࡵ࡮ࡥࡵ࠽ࠤࠪࡹࠧࣔ") % l1lll1l_opy_)
    l1l1l11_opy_  =  start - datetime.timedelta(seconds=l1lll1l_opy_)
    dixie.log(l1l1ll_opy_ (u"ࠧࡔࡶࡤࡶࡹࠦࡔࡪ࡯ࡨࠤࡴ࡬ࡦࡴࡧࡷ࠾ࠥࠫࡳࠨࣕ") % l1l1l11_opy_)
    l1l11_opy_ = str(l1l1l11_opy_)
    l1l111l_opy_  = l1l11_opy_.split(l1l1ll_opy_ (u"ࠨࠢࠪࣖ"))[0]
    l1ll11l_opy_     = l1l11l1_opy_(name)
    if not l1ll11l_opy_:
        dixie.DialogOK(l1l1ll_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠯ࠩࣗ"), l1l1ll_opy_ (u"࡛ࠪࡪࠦࡣࡰࡷ࡯ࡨࠥࡴ࡯ࡵࠢࡩ࡭ࡳࡪࠠࡢࠢࡦࡥࡹࡩࡨࡶࡲࠣࡷࡪࡸࡶࡪࡥࡨࠤ࡫ࡵࡲࠡࡶ࡫࡭ࡸࠦࡣࡩࡣࡱࡲࡪࡲ࠮ࠨࣘ"), l1l1ll_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡹࡸࡹࠡࡣࡱࡳࡹ࡮ࡥࡳࠢࡦ࡬ࡦࡴ࡮ࡦ࡮࠱ࠫࣙ"))
        return None
    l1llll1_opy_  = l1l11_opy_.split(l1l1ll_opy_ (u"ࠬ࠳ࠧࣚ"), 1)[-1].rsplit(l1l1ll_opy_ (u"࠭࠺ࠨࣛ"), 1)[0]
    l111_opy_    = urllib.quote_plus(l1llll1_opy_)
    response   = api.remote_call( l1l1ll_opy_ (u"ࠢࡵࡸࡤࡶࡨ࡮ࡩࡷࡧ࠲࡫ࡪࡺ࡟ࡣࡻࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡣࡦࡴࡤࡠࡦࡤࡸࡪ࠴ࡰࡩࡲࠥࣜ") , {l1l1ll_opy_ (u"ࠣࡦࡤࡸࡪࠨࣝ"): l1l111l_opy_, l1l1ll_opy_ (u"ࠤ࡬ࡨࠧࣞ"): l1ll11l_opy_ } )
    l1lllll_opy_ = response[l1l1ll_opy_ (u"ࠥࡦࡴࡪࡹࠣࣟ")]
    if not l1lllll_opy_:
        dixie.DialogOK(l1l1ll_opy_ (u"ࠫࡘࡵࡲࡳࡻ࠱ࠫ࣠"), l1l1ll_opy_ (u"ࠬ࡝ࡥࠡࡥࡲࡹࡱࡪࠠ࡯ࡱࡷࠤ࡫࡯࡮ࡥࠢࡤࠤࡨࡧࡴࡤࡪࡸࡴࠥࡹࡴࡳࡧࡤࡱࠥ࡬࡯ࡳࠢࡷ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭࠯ࠩ࣡"), l1l1ll_opy_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡴࡳࡻࠣࡥ࡬ࡧࡩ࡯ࠢ࡯ࡥࡹ࡫ࡲ࠯ࠩ࣢"))
        return None
    for l1l1l1l_opy_ in l1lllll_opy_:
        l1ll11_opy_ = l1l1l1l_opy_[l1l1ll_opy_ (u"ࠢࡱ࡮ࡲࡸࣣࠧ")]
        if l1llll1_opy_ in l1ll11_opy_:
            dixie.DialogOK(l1l1ll_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡱࡵࡥࡳ࡭ࡥ࡞ࡅࡤࡸࡨ࡮࠭ࡶࡲࠣࡷࡹࡸࡥࡢ࡯ࠣࡪࡴࡻ࡮ࡥ࠰࡞࠳ࡈࡕࡌࡐࡔࡠࠫࣤ"), l1l1ll_opy_ (u"ࠩࡒࡲ࠲࡚ࡡࡱࡲ࠱ࡘ࡛ࠦࡷࡪ࡮࡯ࠤࡳࡵࡷࠡࡲ࡯ࡥࡾࡀࠠ࡜ࡅࡒࡐࡔࡘࠠࡰࡴࡤࡲ࡬࡫࡝࡜ࡄࡠࠩࡸࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫࣥ") % (title))
            return l1l1l1l_opy_[l1l1ll_opy_ (u"ࠥࡹࡷࡲࣦࠢ")] + l1lll11_opy_
def l1l11l1_opy_(name):
    l1111_opy_   = dixie.PROFILE
    l1l_opy_ = os.path.join(l1111_opy_, l1l1ll_opy_ (u"ࠫ࡮ࡴࡩࠨࣧ"), l1l1ll_opy_ (u"ࠬࡩࡡࡵࡥ࡫ࡹࡵ࠴ࡴࡹࡶࠪࣨ"))
    l11llll_opy_   = json.load(open(l1l_opy_))
    for channel in l11llll_opy_:
        if name.upper() == channel[l1l1ll_opy_ (u"࠭ࡏࡕࡖ࡙ࣩࠫ")].upper():
            return channel[l1l1ll_opy_ (u"ࠧࡖࡔࡏࠫ࣪")]
def l11ll1_opy_():
    import time
    gmt = time.gmtime()
    loc = time.localtime()
    GMT = datetime.datetime(*gmt[:6]).isoformat(l1l1ll_opy_ (u"ࠨࠢࠪ࣫"))
    LOC = datetime.datetime(*loc[:6]).isoformat(l1l1ll_opy_ (u"ࠩࠣࠫ࣬"))
    dixie.log(gmt)
    dixie.log(loc)
    l1_opy_ = dixie.parseTime(GMT)
    l1lll_opy_ = dixie.parseTime(LOC)
    dixie.log(l1_opy_)
    dixie.log(l1lll_opy_)
    dixie.log(l1l1ll_opy_ (u"ࠪࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥࠠࡐࡈࡉࡗࡊ࡚ࠠࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣ࣭ࠬ"))
    l1lll1l_opy_ = l1_opy_ - l1lll_opy_
    dixie.log(l1lll1l_opy_)
    l1lll1l_opy_ = ((l1lll1l_opy_.days * 86400) + (l1lll1l_opy_.seconds + 1800)) / 3600
    dixie.log(l1lll1l_opy_)
    l1lll1l_opy_ *= -3600
    dixie.log(l1lll1l_opy_)
    dixie.log(l1l1ll_opy_ (u"ࠫࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤ࣮࠭"))
    return l1lll1l_opy_