# coding: UTF-8
import sys
l1l111l_opy_ = sys.version_info [0] == 2
l11111_opy_ = 2048
l1111_opy_ = 7
def l11ll1_opy_ (ll_opy_):
	global l1111l_opy_
	l1l11l1_opy_ = ord (ll_opy_ [-1])
	l111ll_opy_ = ll_opy_ [:-1]
	l1ll1l1_opy_ = l1l11l1_opy_ % len (l111ll_opy_)
	l1ll1_opy_ = l111ll_opy_ [:l1ll1l1_opy_] + l111ll_opy_ [l1ll1l1_opy_:]
	if l1l111l_opy_:
		l1lll1l_opy_ = unicode () .join ([unichr (ord (char) - l11111_opy_ - (l11lll_opy_ + l1l11l1_opy_) % l1111_opy_) for l11lll_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1lll1l_opy_ = str () .join ([chr (ord (char) - l11111_opy_ - (l11lll_opy_ + l1l11l1_opy_) % l1111_opy_) for l11lll_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1lll1l_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l11ll1l11_opy_    = l11ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡳࡺࡶࠨऒ")
l11l1llll_opy_ = l11ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡽ࡬ࡪࡲࡷࡺࠬओ")
l11lllll1_opy_    = l11ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡵ࡬ࡶࡸࡶࡰ࠭औ")
locked = l11ll1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡭ࡱࡦ࡯ࡪࡪࡴࡷࠩक")
l11l1l1ll_opy_     = l11ll1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡷ࡯ࡸ࡮ࡳࡡࡵࡧࡰࡥࡳ࡯ࡡࠨख")
l11l1ll1l_opy_   = l11ll1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡯࡭ࡺࡾ࠮ࡵࡸࠪग")
l11ll111l_opy_    = l11ll1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡈࡈ࡙ࡰࡰࡴࡷࡷࠬघ")
l11llll1l_opy_ = l11ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷ࡫ࡢࡰࡱࡷࠫङ")
l11ll1ll1_opy_    = l11ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡩ࡬ࡶ࡫ࡳࡸࡻ࠭च")
l11lll11l_opy_ = l11ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࡭ࡵࡺࡶࠨछ")
l11ll11_opy_ = [l11ll1l11_opy_, locked, l11l1ll1l_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l11ll1_opy_ (u"ࠨ࡫ࡱ࡭ࠬज"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1l1l11_opy_ = l11ll1_opy_ (u"ࠩࠪझ")
def l11l1ll_opy_(i, t1, l1l11ll_opy_=[]):
 t = l1l1l11_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l11ll_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1l1l_opy_ = l11l1ll_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11_opy_ = l11l1ll_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l11ll11_opy_:
        if l11lll1_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l11lll1_opy_(addon):
    if xbmc.getCondVisibility(l11ll1_opy_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡌࡦࡹࡁࡥࡦࡲࡲ࠭ࠫࡳࠪࠩञ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l1lllll_opy_ = str(addon).split(l11ll1_opy_ (u"ࠫ࠳࠭ट"))[2] + l11ll1_opy_ (u"ࠬ࠴ࡩ࡯࡫ࠪठ")
    l1l_opy_  = os.path.join(PATH, l1lllll_opy_)
    try:
        l1l1lll_opy_ = l1_opy_(addon)
    except KeyError:
        dixie.log(l11ll1_opy_ (u"࠭࠭࠮࠯࠰࠱ࠥࡑࡥࡺࡇࡵࡶࡴࡸࠠࡪࡰࠣ࡫ࡪࡺࡆࡪ࡮ࡨࡷࠥ࠳࠭࠮࠯࠰ࠤࠬड") + addon)
        result = {l11ll1_opy_ (u"ࡵࠨࡨ࡬ࡰࡪࡹࠧढ"): [{l11ll1_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫण"): l11ll1_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࠨत"), l11ll1_opy_ (u"ࡸࠫࡹࡿࡰࡦࠩथ"): l11ll1_opy_ (u"ࡹࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭द"), l11ll1_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࠫध"): l11ll1_opy_ (u"ࡻࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡺࡻࡼࠬन"), l11ll1_opy_ (u"ࡵࠨ࡮ࡤࡦࡪࡲࠧऩ"): l11ll1_opy_ (u"ࡶࠩࡑࡓࠥࡉࡈࡂࡐࡑࡉࡑ࡙ࠧप")}], l11ll1_opy_ (u"ࡷࠪࡰ࡮ࡳࡩࡵࡵࠪफ"):{l11ll1_opy_ (u"ࡸࠫࡸࡺࡡࡳࡶࠪब"): 0, l11ll1_opy_ (u"ࡹࠬࡺ࡯ࡵࡣ࡯ࠫभ"): 1, l11ll1_opy_ (u"ࡺ࠭ࡥ࡯ࡦࠪम"): 1}}
    l11l11_opy_  = l11ll1_opy_ (u"࡛࠭ࠨय") + addon + l11ll1_opy_ (u"ࠧ࡞࡞ࡱࠫर")
    l1l1ll1_opy_  =  file(l1l_opy_, l11ll1_opy_ (u"ࠨࡹࠪऱ"))
    l1l1ll1_opy_.write(l11l11_opy_)
    l1ll1l_opy_ = []
    for channel in l1l1lll_opy_:
        l1l111_opy_ = dixie.cleanLabel(channel[l11ll1_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨल")])
        l1lll_opy_ = dixie.mapChannelName(l1l111_opy_)
        stream   = channel[l11ll1_opy_ (u"ࠪࡪ࡮ࡲࡥࠨळ")]
        l11ll_opy_ = l1lll_opy_ + l11ll1_opy_ (u"ࠫࡂ࠭ऴ") + stream
        l1ll1l_opy_.append(l11ll_opy_)
        l1ll1l_opy_.sort()
    for item in l1ll1l_opy_:
        l1l1ll1_opy_.write(l11ll1_opy_ (u"ࠧࠫࡳ࡝ࡰࠥव") % item)
    l1l1ll1_opy_.close()
def l1_opy_(addon):
    if (addon == l11ll1l11_opy_) or (addon == l11l1llll_opy_) or (addon == l11lll11l_opy_):
        try:
            if xbmcaddon.Addon(addon).getSetting(l11ll1_opy_ (u"࠭ࡧࡦࡰࡵࡩࠬश")) == l11ll1_opy_ (u"ࠧࡵࡴࡸࡩࠬष"):
                xbmcaddon.Addon(addon).setSetting(l11ll1_opy_ (u"ࠨࡩࡨࡲࡷ࡫ࠧस"), l11ll1_opy_ (u"ࠩࡩࡥࡱࡹࡥࠨह"))
                xbmcgui.Window(10000).setProperty(l11ll1_opy_ (u"ࠪࡔࡑ࡛ࡇࡊࡐࡢࡋࡊࡔࡒࡆࠩऺ"), l11ll1_opy_ (u"࡙ࠫࡸࡵࡦࠩऻ"))
            if xbmcaddon.Addon(addon).getSetting(l11ll1_opy_ (u"ࠬࡺࡶࡨࡷ࡬ࡨࡪ़࠭")) == l11ll1_opy_ (u"࠭ࡴࡳࡷࡨࠫऽ"):
                xbmcaddon.Addon(addon).setSetting(l11ll1_opy_ (u"ࠧࡵࡸࡪࡹ࡮ࡪࡥࠨा"), l11ll1_opy_ (u"ࠨࡨࡤࡰࡸ࡫ࠧि"))
                xbmcgui.Window(10000).setProperty(l11ll1_opy_ (u"ࠩࡓࡐ࡚ࡍࡉࡏࡡࡗ࡚ࡌ࡛ࡉࡅࡇࠪी"), l11ll1_opy_ (u"ࠪࡘࡷࡻࡥࠨु"))
        except: pass
        l11l1lll1_opy_  = l11ll1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧू") + addon
        l11lll1ll_opy_ =  l1l11111l_opy_(addon)
        query   =  l11l1lll1_opy_ + l11lll1ll_opy_
        return sendJSON(query, addon)
    return l11ll1lll_opy_(addon)
def l11ll1lll_opy_(addon):
    if addon == l11l1ll1l_opy_:
        l11lll111_opy_ = [l11ll1_opy_ (u"ࠬ࠻ࠧृ"), l11ll1_opy_ (u"࠭࠱࠱࠸ࠪॄ"), l11ll1_opy_ (u"ࠧ࠵ࠩॅ"), l11ll1_opy_ (u"ࠨ࠴࠹࠷ࠬॆ"), l11ll1_opy_ (u"ࠩ࠴࠷࠷࠭े")]
    if addon == locked:
        l11lll111_opy_ = [l11ll1_opy_ (u"ࠪ࠷࠵࠭ै"), l11ll1_opy_ (u"ࠫ࠸࠷ࠧॉ"), l11ll1_opy_ (u"ࠬ࠹࠲ࠨॊ"), l11ll1_opy_ (u"࠭࠳࠴ࠩो"), l11ll1_opy_ (u"ࠧ࠴࠶ࠪौ"), l11ll1_opy_ (u"ࠨ࠵࠸्ࠫ"), l11ll1_opy_ (u"ࠩ࠶࠼ࠬॎ"), l11ll1_opy_ (u"ࠪ࠸࠵࠭ॏ"), l11ll1_opy_ (u"ࠫ࠹࠷ࠧॐ"), l11ll1_opy_ (u"ࠬ࠺࠵ࠨ॑"), l11ll1_opy_ (u"࠭࠴࠸॒ࠩ"), l11ll1_opy_ (u"ࠧ࠵࠻ࠪ॓"), l11ll1_opy_ (u"ࠨ࠷࠵ࠫ॔")]
    if addon == l11l1l1ll_opy_:
        l11lll111_opy_ = [l11ll1_opy_ (u"ࠩ࠵࠹ࠬॕ"), l11ll1_opy_ (u"ࠪ࠶࠻࠭ॖ"), l11ll1_opy_ (u"ࠫ࠷࠽ࠧॗ"), l11ll1_opy_ (u"ࠬ࠸࠹ࠨक़"), l11ll1_opy_ (u"࠭࠳࠱ࠩख़"), l11ll1_opy_ (u"ࠧ࠴࠳ࠪग़"), l11ll1_opy_ (u"ࠨ࠵࠵ࠫज़"), l11ll1_opy_ (u"ࠩ࠶࠹ࠬड़"), l11ll1_opy_ (u"ࠪ࠷࠻࠭ढ़"), l11ll1_opy_ (u"ࠫ࠸࠽ࠧफ़"), l11ll1_opy_ (u"ࠬ࠹࠸ࠨय़"), l11ll1_opy_ (u"࠭࠳࠺ࠩॠ"), l11ll1_opy_ (u"ࠧ࠵࠲ࠪॡ"), l11ll1_opy_ (u"ࠨ࠶࠴ࠫॢ"), l11ll1_opy_ (u"ࠩ࠷࠼ࠬॣ"), l11ll1_opy_ (u"ࠪ࠸࠾࠭।"), l11ll1_opy_ (u"ࠫ࠺࠶ࠧ॥"), l11ll1_opy_ (u"ࠬ࠻࠲ࠨ०"), l11ll1_opy_ (u"࠭࠵࠵ࠩ१"), l11ll1_opy_ (u"ࠧ࠶࠸ࠪ२"), l11ll1_opy_ (u"ࠨ࠷࠺ࠫ३"), l11ll1_opy_ (u"ࠩ࠸࠼ࠬ४"), l11ll1_opy_ (u"ࠪ࠹࠾࠭५"), l11ll1_opy_ (u"ࠫ࠻࠶ࠧ६"), l11ll1_opy_ (u"ࠬ࠼࠱ࠨ७"), l11ll1_opy_ (u"࠭࠶࠳ࠩ८"), l11ll1_opy_ (u"ࠧ࠷࠵ࠪ९"), l11ll1_opy_ (u"ࠨ࠸࠸ࠫ॰"), l11ll1_opy_ (u"ࠩ࠹࠺ࠬॱ"), l11ll1_opy_ (u"ࠪ࠺࠼࠭ॲ"), l11ll1_opy_ (u"ࠫ࠻࠿ࠧॳ"), l11ll1_opy_ (u"ࠬ࠽࠰ࠨॴ"), l11ll1_opy_ (u"࠭࠷࠵ࠩॵ"), l11ll1_opy_ (u"ࠧ࠸࠹ࠪॶ"), l11ll1_opy_ (u"ࠨ࠹࠻ࠫॷ"), l11ll1_opy_ (u"ࠩ࠻࠴ࠬॸ"), l11ll1_opy_ (u"ࠪ࠼࠶࠭ॹ")]
    login = l11ll1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴ࠱ࠪॺ") % addon
    sendJSON(login, addon)
    l111l1_opy_ = []
    for l11llllll_opy_ in l11lll111_opy_:
        if addon == l11l1ll1l_opy_:
            query = l11ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠦࡵ࠲ࡃࡲࡵࡤࡦࡡ࡬ࡨࡂࡩࡨࡢࡰࡱࡩࡱࡹࠦ࡮ࡱࡧࡩࡂࡩࡨࡢࡰࡱࡩࡱࡹࠦࡴࡧࡦࡸ࡮ࡵ࡮ࡠ࡫ࡧࡁࠪࡹࠧॻ") % (addon, l11llllll_opy_)
        if (addon == locked) or (addon == l11l1l1ll_opy_):
            query = l11ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶ࠳ࡄࡻࡲ࡭࠿ࠨࡷࠫࡳ࡯ࡥࡧࡀ࠸ࠫࡴࡡ࡮ࡧࡀࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧࡲ࡯ࡥࡾࡃࠦࡥࡣࡷࡩࡂࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࡁࠫࡶࡡࡨࡧࡀࠫॼ") % (addon, l11llllll_opy_)
        response = sendJSON(query, addon)
        l111l1_opy_.extend(response)
    return l111l1_opy_
def sendJSON(query, addon):
    l11llll11_opy_     = l11ll1_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪॽ") % query
    l11ll1l1l_opy_  = xbmc.executeJSONRPC(l11llll11_opy_)
    response = json.loads(l11ll1l1l_opy_)
    result   = response[l11ll1_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨॾ")]
    if xbmcgui.Window(10000).getProperty(l11ll1_opy_ (u"ࠩࡓࡐ࡚ࡍࡉࡏࡡࡊࡉࡓࡘࡅࠨॿ")) == l11ll1_opy_ (u"ࠪࡘࡷࡻࡥࠨঀ"):
        xbmcaddon.Addon(addon).setSetting(l11ll1_opy_ (u"ࠫ࡬࡫࡮ࡳࡧࠪঁ"), l11ll1_opy_ (u"ࠬࡺࡲࡶࡧࠪং"))
    if xbmcgui.Window(10000).getProperty(l11ll1_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡔࡗࡉࡘࡍࡉࡋࠧঃ")) == l11ll1_opy_ (u"ࠧࡕࡴࡸࡩࠬ঄"):
        xbmcaddon.Addon(addon).setSetting(l11ll1_opy_ (u"ࠨࡶࡹ࡫ࡺ࡯ࡤࡦࠩঅ"), l11ll1_opy_ (u"ࠩࡷࡶࡺ࡫ࠧআ"))
    return result[l11ll1_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩই")]
def l1l11111l_opy_(addon):
    if (addon == l11ll1l11_opy_) or (addon == l11l1llll_opy_):
        return l11ll1_opy_ (u"ࠫ࠴ࡅࡣࡢࡶࡀ࠱࠷ࠬࡤࡢࡶࡨࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠨࡨࡲࡩࡊࡡࡵࡧࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦ࡮ࡱࡧࡩࡂ࠸ࠦ࡯ࡣࡰࡩࡂࡓࡹࠦ࠴࠳ࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡸࡥࡤࡱࡵࡨࡳࡧ࡭ࡦࠨࡶࡸࡦࡸࡴࡅࡣࡷࡩࠫࡻࡲ࡭࠿ࡸࡶࡱ࠭ঈ")
    if addon == l11lll11l_opy_:
        return l11ll1_opy_ (u"ࠬ࠵࠿ࡢࡥࡷ࡭ࡴࡴ࠽࡭࡫ࡹࡩࡹࡼ࡟ࡢ࡮࡯ࠪࡪࡾࡴࡳࡣࠩࡴࡦ࡭ࡥࠧࡲ࡯ࡳࡹࠬࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠿ࠩࡸ࡮ࡺ࡬ࡦ࠿ࡄࡰࡱࠫ࠲࠱ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠩࡹࡷࡲࠧউ")
    return l11ll1_opy_ (u"࠭ࠧঊ")
def l111l_opy_():
    modules = map(__import__, [l11l1ll_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1l1l_opy_)):
        return l11ll1_opy_ (u"ࠧࡕࡴࡸࡩࠬঋ")
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l11ll1_opy_ (u"ࠨࡖࡵࡹࡪ࠭ঌ")
    return l11ll1_opy_ (u"ࠩࡉࡥࡱࡹࡥࠨ঍")
def l1ll111_opy_(e, addon):
    l1l11l_opy_ = l11ll1_opy_ (u"ࠪࡗࡴࡸࡲࡺ࠮ࠣࡥࡳࠦࡥࡳࡴࡲࡶࠥࡵࡣࡤࡷࡵࡩࡩࡀࠠࡋࡕࡒࡒࠥࡋࡲࡳࡱࡵ࠾ࠥࠫࡳ࠭ࠢࠨࡷࠬ঎")  % (e, addon)
    l11l1_opy_ = l11ll1_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡨࡵ࡮ࡵࡣࡦࡸࠥࡻࡳࠡࡱࡱࠤࡹ࡮ࡥࠡࡨࡲࡶࡺࡳ࠮ࠨএ")
    l1l1ll_opy_ = l11ll1_opy_ (u"࡛ࠬࡰ࡭ࡱࡤࡨࠥࡧࠠ࡭ࡱࡪࠤࡻ࡯ࡡࠡࡶ࡫ࡩࠥࡧࡤࡥࡱࡱࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸࠦࡡ࡯ࡦࠣࡴࡴࡹࡴࠡࡶ࡫ࡩࠥࡲࡩ࡯࡭࠱ࠫঐ")
    dixie.log(addon)
    dixie.log(e)
def getPluginInfo(streamurl):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l11l1l1l1_opy_   = l11ll1_opy_ (u"࠭ࡋࡰࡦ࡬ࠤࡕ࡜ࡒࠨ঑")
            l11l1ll11_opy_ = os.path.join(dixie.RESOURCES, l11ll1_opy_ (u"ࠧ࡬ࡱࡧ࡭࠲ࡶࡶࡳ࠰ࡳࡲ࡬࠭঒"))
            return l11l1l1l1_opy_, l11l1ll11_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l11ll1_opy_ (u"ࠨࡴࡷࡱࡵ࠭ও")) or url.startswith(l11ll1_opy_ (u"ࠩࡵࡸࡲࡶࡥࠨঔ")) or url.startswith(l11ll1_opy_ (u"ࠪࡶࡹࡹࡰࠨক")) or url.startswith(l11ll1_opy_ (u"ࠫ࡭ࡺࡴࡱࠩখ")):
            l11l1l1l1_opy_   = l11ll1_opy_ (u"ࠬࡳ࠳ࡶࠢࡓࡰࡦࡿ࡬ࡪࡵࡷࠫগ")
            l11l1ll11_opy_ = os.path.join(dixie.RESOURCES, l11ll1_opy_ (u"࠭ࡩࡱࡶࡹ࠱ࡵࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡰ࡯ࡩࠪঘ"))
            return l11l1l1l1_opy_, l11l1ll11_opy_
    except:
        pass
    if streamurl.startswith(l11ll1_opy_ (u"ࠧࡱࡸࡵ࠾࠴࠵ࠧঙ")):
        l11l1l1l1_opy_   = l11ll1_opy_ (u"ࠨࡍࡲࡨ࡮ࠦࡐࡗࡔࠪচ")
        l11l1ll11_opy_ = os.path.join(dixie.RESOURCES, l11ll1_opy_ (u"ࠩ࡮ࡳࡩ࡯࠭ࡱࡸࡵ࠲ࡵࡴࡧࠨছ"))
        return l11l1l1l1_opy_, l11l1ll11_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        l11ll11ll_opy_ = streamurl.split(l11ll1_opy_ (u"ࠪࡡࡔ࡚ࡔࡠࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫজ"), 1)[-1].split(l11ll1_opy_ (u"ࠫ࠴࠭ঝ"), 1)[0]
    if l11ll1_opy_ (u"ࠬࡣࡏࡕࡖࡢࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭ঞ") in streamurl:
        l11ll11ll_opy_ = streamurl.split(l11ll1_opy_ (u"࠭࡝ࡐࡖࡗࡣࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧট"), 1)[-1].split(l11ll1_opy_ (u"ࠧ࠰ࠩঠ"), 1)[0]
    if streamurl.startswith(l11ll1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫড")):
        l11ll11ll_opy_ = streamurl.split(l11ll1_opy_ (u"ࠩ࠲࠳ࠬঢ"), 1)[-1].split(l11ll1_opy_ (u"ࠪ࠳ࠬণ"), 1)[0]
    if l11ll1_opy_ (u"ࠫࡤࡥࡓࡇࡡࡢࠫত") in streamurl:
        l11ll11ll_opy_ = l11ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡶࡲࡰࡩࡵࡥࡲ࠴ࡳࡶࡲࡨࡶ࠳࡬ࡡࡷࡱࡸࡶ࡮ࡺࡥࡴࠩথ")
    if l11ll1_opy_ (u"࠭ࡈࡅࡖ࡙࠾ࠬদ") in streamurl:
        l11ll11ll_opy_ = l11ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳ࡮ࡣࡵࡸ࡭ࡻࡢࠨধ")
    if l11ll1_opy_ (u"ࠨࡊࡇࡘ࡛࠸࠺ࠨন") in streamurl:
        l11ll11ll_opy_ = l11ll1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࠸ࠧ঩")
    if l11ll1_opy_ (u"ࠪࡌࡉ࡚ࡖ࠴࠼ࠪপ") in streamurl:
        l11ll11ll_opy_ = l11ll1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡺࡿࡡ࠳ࠩফ")
    if l11ll1_opy_ (u"ࠬࡎࡄࡕࡘ࠷࠾ࠬব") in streamurl:
        l11ll11ll_opy_ = l11ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾ࡬ࠨভ")
    if l11ll1_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡀࠧম") in streamurl:
        l11ll11ll_opy_ = l11ll1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡣࡤࡦ࡭ࡵࡲࡡࡺࡧࡵࠫয")
    if l11ll1_opy_ (u"ࠩࡌࡔࡑࡇ࡙࠳࠼ࠪর") in streamurl:
        l11ll11ll_opy_ = l11ll1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠭঱")
    if l11ll1_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡕ࠾ࠬল") in streamurl:
        l11ll11ll_opy_ = l11ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶ࡬ࡢࡻࡨࡶࡼࡽࡷࠨ঳")
    if l11ll1_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡎ࡚ࡖ࠻ࠩ঴") in streamurl:
        l11ll11ll_opy_ = l11ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡵࡸࠪ঵")
    if l11ll1_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡄ࠻ࠩশ") in streamurl:
        l11ll11ll_opy_ = l11ll1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡦࡨࡼࠬষ")
    if l11ll1_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡔࡅ࠾ࠬস") in streamurl:
        l11ll11ll_opy_ = l11ll1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡪࡨ࡯ࡰࡶࠪহ")
    if l11ll1_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡇࡑ࡛࠺ࠨ঺") in streamurl:
        l11ll11ll_opy_ = l11ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡩ࡬ࡶ࡫ࡳࡸࡻ࠭঻")
    if l11ll1_opy_ (u"ࠧࡊࡒࡗࡗ়ࠬ") in streamurl:
        l11ll11ll_opy_ = l11ll1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥ࡮ࡶࡴࡷࠩঽ")
    if l11ll1_opy_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠼ࠪা") in streamurl:
        l11ll11ll_opy_ = l11ll1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡯࡭ࡻ࡫࡭ࡪࡺࠪি")
    if l11ll1_opy_ (u"ࠫࡋࡒࡁ࠻ࠩী") in streamurl:
        l11ll11ll_opy_ = l11ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡋࡲࡡࡸ࡮ࡨࡷࡸ࡚ࡶࠨু")
    if l11ll1_opy_ (u"࠭ࡆࡍࡃࡖ࠾ࠬূ") in streamurl:
        l11ll11ll_opy_ = l11ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡆ࡭ࡣࡺࡰࡪࡹࡳࡕࡸࠪৃ")
    if l11ll1_opy_ (u"ࠨࡷࡳࡲࡵࡀࠧৄ") in streamurl:
        l11ll11ll_opy_ = l11ll1_opy_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰࡫ࡨ࡭ࡵ࡭ࡦࡴࡸࡲ࠳ࡼࡩࡦࡹࠪ৅")
    return l11lll1l1_opy_(l11ll11ll_opy_)
def l11lll1l1_opy_(l11ll11ll_opy_):
    l11l1l1l1_opy_   = l11ll1_opy_ (u"ࠪࠫ৆")
    l11l1ll11_opy_ = l11ll1_opy_ (u"ࠫࠬে")
    if l11ll11ll_opy_ == l11ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸࠨৈ"):
        l11l1l1l1_opy_   = l11ll1_opy_ (u"࠭ࡄࡦࡺࡷࡩࡷ࡚ࡖࠡࡎ࡬ࡸࡪ࠭৉")
        l11l1ll11_opy_ = xbmcaddon.Addon(l11ll11ll_opy_).getAddonInfo(l11ll1_opy_ (u"ࠧࡪࡥࡲࡲࠬ৊"))
        return l11l1l1l1_opy_, l11l1ll11_opy_
    try:
        l11l1l1l1_opy_   = xbmcaddon.Addon(l11ll11ll_opy_).getAddonInfo(l11ll1_opy_ (u"ࠨࡰࡤࡱࡪ࠭ো"))
        l11l1ll11_opy_ = xbmcaddon.Addon(l11ll11ll_opy_).getAddonInfo(l11ll1_opy_ (u"ࠩ࡬ࡧࡴࡴࠧৌ"))
        return l11l1l1l1_opy_, l11l1ll11_opy_
    except:
        l11l1l1l1_opy_   = l11ll1_opy_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡘࡵࡵࡳࡥࡨ্ࠫ")
        l11l1ll11_opy_ =  dixie.ICON
        return l11l1l1l1_opy_, l11l1ll11_opy_
    return l11l1l1l1_opy_, l11l1ll11_opy_
def selectStream(url, channel):
    l11l1l11l_opy_ = url.split(l11ll1_opy_ (u"ࠫࢁ࠭ৎ"))
    if len(l11l1l11l_opy_) == 0:
        return None
    options, l11ll1l_opy_ = getOptions(l11l1l11l_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l11l1l11l_opy_) == 1:
            return l11ll1l_opy_[0]
    import selectDialog
    l1l111111_opy_ = selectDialog.select(l11ll1_opy_ (u"࡙ࠬࡥ࡭ࡧࡦࡸࠥࡧࠠࡴࡶࡵࡩࡦࡳࠧ৏"), options)
    if l1l111111_opy_ < 0:
        raise Exception(l11ll1_opy_ (u"࠭ࡓࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡆࡥࡳࡩࡥ࡭ࠩ৐"))
    return l11ll1l_opy_[l1l111111_opy_]
def getOptions(l11l1l11l_opy_, channel, addmore=True):
    options = []
    l11ll1l_opy_    = []
    for index, stream in enumerate(l11l1l11l_opy_):
        l11l1l1l1_opy_ = getPluginInfo(stream)
        l1l111_opy_ = l11l1l1l1_opy_[0]
        l11ll1111_opy_  = l11l1l1l1_opy_[1]
        l1l111_opy_ = l11ll1_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡰࡴࡤࡲ࡬࡫࡝࡜ࠩ৑") + l1l111_opy_ + l11ll1_opy_ (u"ࠨ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠤࠬ৒")
        if stream.startswith(OPEN_OTT):
            l11ll11l1_opy_ = stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l11ll1_opy_ (u"ࠩࠪ৓"))
            l1l111_opy_  = l1l111_opy_ + l11ll11l1_opy_
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l11ll1_opy_ (u"ࠪࠫ৔"))
        else:
            l1l111_opy_  = l1l111_opy_ + channel
        options.append([l1l111_opy_, index, l11ll1111_opy_])
        l11ll1l_opy_.append(stream)
    if addmore:
        options.append([l11ll1_opy_ (u"ࠫࡆࡪࡤࠡ࡯ࡲࡶࡪ࠴࠮࠯ࠩ৕"), index + 1, dixie.ICON])
        l11ll1l_opy_.append(l11ll1_opy_ (u"ࠬࡧࡤࡥࡏࡲࡶࡪ࠭৖"))
    return options, l11ll1l_opy_
if __name__ == l11ll1_opy_ (u"࠭࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠨৗ"):
    checkAddons()