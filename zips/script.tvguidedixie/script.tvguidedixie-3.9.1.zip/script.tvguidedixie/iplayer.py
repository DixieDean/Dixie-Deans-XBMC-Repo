# coding: UTF-8
import sys
l1l111l_opy_ = sys.version_info [0] == 2
l11111_opy_ = 2048
l1111_opy_ = 7
def l11ll1_opy_ (ll_opy_):
	global l1111l_opy_
	l1l11l1_opy_ = ord (ll_opy_ [-1])
	l111ll_opy_ = ll_opy_ [:-1]
	l1ll1l1_opy_ = l1l11l1_opy_ % len (l111ll_opy_)
	l1ll1_opy_ = l111ll_opy_ [:l1ll1l1_opy_] + l111ll_opy_ [l1ll1l1_opy_:]
	if l1l111l_opy_:
		l1lll1l_opy_ = unicode () .join ([unichr (ord (char) - l11111_opy_ - (l11lll_opy_ + l1l11l1_opy_) % l1111_opy_) for l11lll_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1lll1l_opy_ = str () .join ([chr (ord (char) - l11111_opy_ - (l11lll_opy_ + l1l11l1_opy_) % l1111_opy_) for l11lll_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1lll1l_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
ADDON    = dixie.ADDON
l1l1l1_opy_ = dixie.PROFILE
l1ll11l_opy_  = os.path.join(l1l1l1_opy_, l11ll1_opy_ (u"ࠫ࡮ࡴࡩࠨࠀ"))
l1l1l11_opy_ = l11ll1_opy_ (u"ࠬ࠭ࠁ")
def l11l1ll_opy_(i, t1, l1l11ll_opy_=[]):
 t = l1l1l11_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l11ll_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1l1l_opy_ = l11l1ll_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11_opy_ = l11l1ll_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1lll11_opy_ = l11ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡌ࡬ࡢࡹ࡯ࡩࡸࡹࡔࡷࠩࠂ")
dexter   = l11ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡤࡦࡺࠪࠃ")
l11ll11_opy_   = [l1lll11_opy_, dexter]
def checkAddons():
    for addon in l11ll11_opy_:
        if l11lll1_opy_(addon):
            createINI(addon)
def l11lll1_opy_(addon):
    if xbmc.getCondVisibility(l11ll1_opy_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫࠩࡸ࠯ࠧࠄ") % addon) == 1:
        return True
    else:
        return False
def createINI(addon):
    HOME  = dixie.PROFILE
    l1ll11_opy_ = os.path.join(HOME, l11ll1_opy_ (u"ࠩ࡬ࡲ࡮࠭ࠅ"))
    l1lllll_opy_  = str(addon).split(l11ll1_opy_ (u"ࠪ࠲ࠬࠆ"))[2] + l11ll1_opy_ (u"ࠫ࠳࡯࡮ࡪࠩࠇ")
    l1l_opy_   = os.path.join(l1ll11_opy_, l1lllll_opy_)
    response = l1_opy_(addon)
    l1l1lll_opy_ = response[l11ll1_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬࠈ")][l11ll1_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬࠉ")]
    l11l11_opy_  = l11ll1_opy_ (u"ࠧ࡜ࠩࠊ") + addon + l11ll1_opy_ (u"ࠨ࡟࡟ࡲࠬࠋ")
    l1l1ll1_opy_  =  file(l1l_opy_, l11ll1_opy_ (u"ࠩࡺࠫࠌ"))
    l1l1ll1_opy_.write(l11l11_opy_)
    l1ll1l_opy_ = []
    for channel in l1l1lll_opy_:
        l11llll_opy_ = l1l11_opy_(addon, channel)
        l1ll1ll_opy_ = l11llll_opy_
        l1lll1_opy_ = l1l1111_opy_(addon)
        l1lll_opy_  = dixie.mapChannelName(l11llll_opy_)
        stream    = l1lll1_opy_ + l1ll1ll_opy_
        l11ll_opy_   = l1lll_opy_ + l11ll1_opy_ (u"ࠪࡁࠬࠍ") + stream
        if l11ll_opy_ not in l1ll1l_opy_:
            l1ll1l_opy_.append(l11ll_opy_)
    l1ll1l_opy_.sort()
    for item in l1ll1l_opy_:
        l1l1ll1_opy_.write(l11ll1_opy_ (u"ࠦࠪࡹ࡜࡯ࠤࠎ") % item)
    l1l1ll1_opy_.close()
def l1l11_opy_(addon, file):
    l1l111_opy_ = file[l11ll1_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫࠏ")].split(l11ll1_opy_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࠐ"), 1)[0]
    l1l111_opy_ = dixie.cleanLabel(l1l111_opy_)
    return l1l111_opy_
def l1l1111_opy_(addon):
    if addon == l1lll11_opy_:
        return l11ll1_opy_ (u"ࠧࡇࡎࡄ࠾ࠬࠑ")
    if addon == dexter:
        return l11ll1_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡄ࠻ࠩࠒ")
def getURL(url):
    if url.startswith(l11ll1_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡄࡎࡘ࠾ࠬࠓ")):
        url = url.replace(l11ll1_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡅࡏ࡙࠿࠭ࠔ"), l11ll1_opy_ (u"ࠫࠬࠕ")).replace(l11ll1_opy_ (u"ࠬ࠳࠭ࡶࡵࡨࡶ࠲ࡧࡧࡦࡰࡷࠫࠖ"), l11ll1_opy_ (u"࠭ࡼࡶࡵࡨࡶ࠲ࡧࡧࡦࡰࡷࠫࠗ"))
        return url
    if url.startswith(l11ll1_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡊࠧ࠘")):
        return l1ll_opy_(url, dexter)
    if url.startswith(l11ll1_opy_ (u"ࠨࡈࡏࡅࠬ࠙")):
        return l1ll_opy_(url, l1lll11_opy_)
    response = l1l1_opy_(url)
    stream   = url.split(l11ll1_opy_ (u"ࠩ࠽ࠫࠚ"), 1)[-1]
    try:
        result = response[l11ll1_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪࠛ")]
        l111l1_opy_  = result[l11ll1_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪࠜ")]
    except Exception as e:
        l1ll111_opy_(e)
        return None
    for file in l111l1_opy_:
        l1l111_opy_ = file[l11ll1_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫࠝ")]
        if stream in l1l111_opy_:
            return file[l11ll1_opy_ (u"࠭ࡦࡪ࡮ࡨࠫࠞ")]
    return None
def l1ll_opy_(url, addon):
    PATH = l111_opy_(addon)
    try:
        response = json.load(open(PATH))
    except:
        response = l1_opy_(addon)
    l1llll1_opy_ = url.split(l11ll1_opy_ (u"ࠧ࠻ࠩࠟ"))[0]
    l11ll1l_opy_     = url.split(l11ll1_opy_ (u"ࠨ࠼ࠪࠠ"), 1)[-1]
    stream   = l11ll1l_opy_.split(l11ll1_opy_ (u"ࠩࠣ࡟ࠬࠡ"), 1)[0]
    stream   = dixie.cleanLabel(stream)
    l111l1_opy_  = response[l11ll1_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪࠢ")][l11ll1_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪࠣ")]
    for file in l111l1_opy_:
        l1l111_opy_ = l1l11_opy_(addon, file)
        if stream in l1l111_opy_:
            l11l_opy_ = file[l11ll1_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪࠤ")]
            if l1llll1_opy_ == l11ll1_opy_ (u"࠭ࡆࡍࡃࡖࠫࠥ"):
                return l11l_opy_
            l11l_opy_ = l11l_opy_.replace(l11ll1_opy_ (u"ࠧ࠯ࡶࡶࠫࠦ"), l11ll1_opy_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧࠧ"))
            return l11l_opy_
def l1_opy_(addon):
    PATH = l111_opy_(addon)
    if addon == l1lll11_opy_:
        query = l11ll1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡊࡱࡧࡷ࡭ࡧࡶࡷ࡙ࡼ࠯ࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡵࡷࡶࡪࡧ࡭ࡠࡸ࡬ࡨࡪࡵࠦࡦࡺࡷࡶࡦࠬࡰࡢࡩࡨࠪࡵࡲ࡯ࡵࠨࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡂࠬࡴࡪࡶ࡯ࡩࡂࡇ࡬࡭ࠨࡸࡶࡱࡃ࠰ࠨࠨ")
    if addon == dexter:
        query = l1llll_opy_(addon)
    try:
        return json.load(open(PATH))
    except:
        content = doJSON(query)
        return l11l1l_opy_(PATH, addon, content)
def l11l1l_opy_(PATH, addon, content):
    json.dump(content, open(PATH,l11ll1_opy_ (u"ࠪࡻࠬࠩ")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    l1l1l1l_opy_  = (l11ll1_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࠥࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࠪ") % query)
    response = xbmc.executeJSONRPC(l1l1l1l_opy_)
    content  = json.loads(response)
    return content
def l111_opy_(addon):
    if addon == l1lll11_opy_:
        return os.path.join(dixie.PROFILE, l11ll1_opy_ (u"ࠬ࡬ࡴࡦ࡯ࡳࠫࠫ"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l11ll1_opy_ (u"࠭ࡤࡵࡧࡰࡴࠬࠬ"))
def l1llll_opy_(addon):
    if addon == dexter:
        query = l11ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡦࡨࡼࠬ࠭")
        response = doJSON(query)
        l111l1_opy_    = response[l11ll1_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨ࠮")][l11ll1_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨ࠯")]
        for file in l111l1_opy_:
            l1l111_opy_ = file[l11ll1_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩ࠰")]
            if l1l111_opy_ == l11ll1_opy_ (u"ࠫࡆࡲ࡬ࠨ࠱"):
                login = file[l11ll1_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪ࠲")]
                return login
def l1l1_opy_(url):
    if url.startswith(l11ll1_opy_ (u"࠭ࡉࡑࡎࡄ࡝࠿࠭࠳")):
        l1l1l1l_opy_ = (l11ll1_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡦࡧࡩࡩࡱ࡮ࡤࡽࡪࡸ࠯ࡀࡷࡵࡰࡂࡻࡲ࡭ࠨࡰࡳࡩ࡫࠽࠳ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡹࡩࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴ࠽ࠧࡋࡓࡍࡉࡃࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬ࠴"))
    if url.startswith(l11ll1_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠲࠻ࠩ࠵")):
        l1l1l1l_opy_ = (l11ll1_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰ࡭ࡣࡼࡩࡷࡽࡷࡸ࠱ࡂࡹࡷࡲ࠽ࡶࡴ࡯ࠪࡲࡵࡤࡦ࠿࠴࠴࠶ࠬ࡮ࡢ࡯ࡨࡁ࡜ࡧࡴࡤࡪ࠮ࡐ࡮ࡼࡥࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࡀࠪࡸࡻࡢࡵ࡫ࡷࡰࡪࡹ࡟ࡶࡴ࡯ࡁࠫࡲ࡯ࡨࡩࡨࡨࡤ࡯࡮࠾ࡈࡤࡰࡸ࡫ࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬ࠶"))
    if url.startswith(l11ll1_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡔ࠽ࠫ࠷")):
        l1l1l1l_opy_ = (l11ll1_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺ࠳ࡄࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠩࡰࡴ࡭ࡧࡦࡦࡢ࡭ࡳࡃࡆࡢ࡮ࡶࡩࠫࡳ࡯ࡥࡧࡀ࠵࠶࠹ࠦ࡯ࡣࡰࡩࡂࡒࡩࡴࡶࡨࡲࠪ࠸࠰ࡍ࡫ࡹࡩࠫࡹࡵࡣࡶ࡬ࡸࡱ࡫ࡳࡠࡷࡵࡰࠫࡻࡲ࡭࠿ࡸࡶࡱࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫ࠸"))
    if url.startswith(l11ll1_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡍ࡙࡜࠺ࠨ࠹")):
        l1l1l1l_opy_ = (l11ll1_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡸࡻࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫ࠺"))
    if url.startswith(l11ll1_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡊ࠺ࠨ࠻")):
        l1l1l1l_opy_ = (l11ll1_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿ࡤࡰࡱࠬࡥࡹࡶࡵࡥࠫࡶࡡࡨࡧࠩࡴࡱࡵࡴࠧࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡁࠫࡺࡩࡵ࡮ࡨࡁࠪ࠻ࡢࡄࡑࡏࡓࡗࠫ࠲࠱ࡹ࡫࡭ࡹ࡫ࠥ࠶ࡦࡄࡰࡱࠫ࠲࠱ࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠨ࠹ࡧࠫ࠲ࡧࡅࡒࡐࡔࡘࠥ࠶ࡦࠩࡹࡷࡲࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬ࠼"))
    if url.startswith(l11ll1_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡓࡄ࠽ࠫ࠽")):
        l1l1l1l_opy_ = (l11ll1_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡦࡤࡲࡳࡹ࠵࠿ࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠫ࡬ࡡ࡯ࡣࡵࡸࡂࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࠩࡱࡴࡪࡥ࠾࠹ࠩࡴ࡮ࡲ࡬ࡰࡹࡀࡐ࡮ࡼࡥࠦ࠴࠳ࡗࡹࡸࡥࡢ࡯ࡶࠪࡺࡸ࡬࠾ࡴࡤࡲࡩࡵ࡭ࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭࠾"))
    if url.startswith(l11ll1_opy_ (u"ࠫࡎࡖࡔࡔ࠼ࠪ࠿")):
        l1l1l1l_opy_ = (l11ll1_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࡯ࡰࡵࡸ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡱ࡯ࡶࡦࡶࡹࡣࡦࡲ࡬ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠦࡵ࡫ࡷࡰࡪࡃࡁ࡭࡮ࠨ࠶࠵ࡩࡨࡢࡰࡱࡩࡱࡹࠦࡶࡴ࡯ࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩࡀ"))
    try:
        dixie.ShowBusy()
        addon =  l1l1l1l_opy_.split(l11ll1_opy_ (u"࠭࠯࠰ࠩࡁ"), 1)[-1].split(l11ll1_opy_ (u"ࠧ࠰ࠩࡂ"), 1)[0]
        login = l11ll1_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ࡃ") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1l1l1l_opy_)
        dixie.log(response)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1ll111_opy_(e)
        return {l11ll1_opy_ (u"ࠩࡈࡶࡷࡵࡲࠨࡄ") : l11ll1_opy_ (u"ࠪࡔࡱࡻࡧࡪࡰࠣࡉࡷࡸ࡯ࡳࠩࡅ")}
def l111l_opy_():
    modules = map(__import__, [l11l1ll_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1l1l_opy_)):
        return l11ll1_opy_ (u"࡙ࠫࡸࡵࡦࠩࡆ")
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l11ll1_opy_ (u"࡚ࠬࡲࡶࡧࠪࡇ")
    return l11ll1_opy_ (u"࠭ࡆࡢ࡮ࡶࡩࠬࡈ")
def l1ll111_opy_(e):
    l1l11l_opy_ = l11ll1_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠲ࠠࡢࡰࠣࡩࡷࡸ࡯ࡳࠢࡲࡧࡨࡻࡲࡦࡦ࠽ࠤࡏ࡙ࡏࡏࠢࡈࡶࡷࡵࡲ࠻ࠢࠨࡷࠬࡉ")  %e
    l11l1_opy_ = l11ll1_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡴࡨ࠱ࡱ࡯࡮࡬ࠢࡷ࡬࡮ࡹࠠࡤࡪࡤࡲࡳ࡫࡬ࠡࡣࡱࡨࠥࡺࡲࡺࠢࡤ࡫ࡦ࡯࡮࠯ࠩࡊ")
    l1l1ll_opy_ = l11ll1_opy_ (u"ࠩࡘࡷࡪࡀࠠࡄࡱࡱࡸࡪࡾࡴࠡࡏࡨࡲࡺࠦ࠽࠿ࠢࡕࡩࡲࡵࡶࡦࠢࡖࡸࡷ࡫ࡡ࡮ࠩࡋ")
    dixie.log(e)
    dixie.DialogOK(l1l11l_opy_, l11l1_opy_, l1l1ll_opy_)
if __name__ == l11ll1_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬࡌ"):
    checkAddons()