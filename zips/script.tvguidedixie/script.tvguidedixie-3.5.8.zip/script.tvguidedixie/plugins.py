# coding: UTF-8
import sys
l11ll111_opy_ = sys.version_info [0] == 2
l1lll1l1_opy_ = 2048
l11lllll_opy_ = 7
def l1l11_opy_ (l11ll1_opy_):
	global l1llll11_opy_
	l1ll1111_opy_ = ord (l11ll1_opy_ [-1])
	l11ll11l_opy_ = l11ll1_opy_ [:-1]
	l11l11l_opy_ = l1ll1111_opy_ % len (l11ll11l_opy_)
	l111l1_opy_ = l11ll11l_opy_ [:l11l11l_opy_] + l11ll11l_opy_ [l11l11l_opy_:]
	if l11ll111_opy_:
		l1lll1_opy_ = unicode () .join ([unichr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	else:
		l1lll1_opy_ = str () .join ([chr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	return eval (l1lll1_opy_)
import xbmc
import xbmcaddon
import json
import os
import shutil
import dixie
l1lll11ll_opy_     = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡯ࡶࡹࠫ࡟")
l111111l_opy_     = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡷ࡮ࡸࡺࡸ࡫ࠨࡠ")
l1ll1l11l_opy_ = [l1lll11ll_opy_, l111111l_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1l11_opy_ (u"ࠪ࡭ࡳ࡯ࠧࡡ"))
def checkAddons():
    for l1lll1111_opy_ in l1ll1l11l_opy_:
        if l1ll1l1l1_opy_(l1lll1111_opy_):
            try: l1llll111_opy_(l1lll1111_opy_)
            except: pass
def l1ll1l1l1_opy_(l1lll1111_opy_):
    if xbmc.getCondVisibility(l1l11_opy_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡍࡧࡳࡂࡦࡧࡳࡳ࠮ࠥࡴࠫࠪࡢ") % l1lll1111_opy_) == 1:
        return True
    return False
def l1llll111_opy_(l1lll1111_opy_):
    l1111l11_opy_ = l1llll1l1_opy_(l1lll1111_opy_) + l1l11_opy_ (u"ࠬ࠴ࡩ࡯࡫ࠪࡣ")
    l1lll1lll_opy_  = os.path.join(PATH, l1111l11_opy_)
    l1ll1llll_opy_ = l111l111_opy_(l1lll1111_opy_)
    l1111ll1_opy_  = file(l1lll1lll_opy_, l1l11_opy_ (u"࠭ࡷࠨࡤ"))
    l1111ll1_opy_.write(l1l11_opy_ (u"ࠧ࡜ࠩࡥ"))
    l1111ll1_opy_.write(l1lll1111_opy_)
    l1111ll1_opy_.write(l1l11_opy_ (u"ࠨ࡟ࠪࡦ"))
    l1111ll1_opy_.write(l1l11_opy_ (u"ࠩ࡟ࡲࠬࡧ"))
    for channel in l1ll1llll_opy_:
        l1lllll1l_opy_   = channel[l1l11_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࡨ")]
        l1lllll1l_opy_ = l1lllll1l_opy_.replace(l1l11_opy_ (u"ࠫࠥࡡࠧࡩ"), l1l11_opy_ (u"ࠬࡡࠧࡪ")).replace(l1l11_opy_ (u"࠭࡝ࠡࠩ࡫"), l1l11_opy_ (u"ࠧ࡞ࠩ࡬")).replace(l1l11_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡣࡴࡹࡦࡣࠧ࡭"), l1l11_opy_ (u"ࠩࠪ࡮")).replace(l1l11_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮ࡳࡥࡨࡴࡨࡩࡳࡣࠧ࡯"), l1l11_opy_ (u"ࠫࠬࡰ")).replace(l1l11_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡿࡥ࡭࡮ࡲࡻࡢ࠭ࡱ"), l1l11_opy_ (u"࠭ࠧࡲ")).replace(l1l11_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢ࠭ࡳ"), l1l11_opy_ (u"ࠨࠩࡴ")).replace(l1l11_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡲࡶࡦࡴࡧࡦ࡟ࠪࡵ"), l1l11_opy_ (u"ࠪࠫࡶ")).replace(l1l11_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞ࠩࡷ"), l1l11_opy_ (u"ࠬ࠭ࡸ")).replace(l1l11_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡷࡩ࡫ࡷࡩࡢ࠭ࡹ"), l1l11_opy_ (u"ࠧࠨࡺ")).replace(l1l11_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࡻ"), l1l11_opy_ (u"ࠩࠪࡼ"))
        stream  = channel[l1l11_opy_ (u"ࠪࡪ࡮ࡲࡥࠨࡽ")]
        l1111ll1_opy_.write(l1l11_opy_ (u"ࠫࠪࡹࠧࡾ") % l1lllll1l_opy_)
        l1111ll1_opy_.write(l1l11_opy_ (u"ࠬࡃࠧࡿ"))
        l1111ll1_opy_.write(l1l11_opy_ (u"࠭ࠥࡴࠩࢀ") % stream)
        l1111ll1_opy_.write(l1l11_opy_ (u"ࠧ࡝ࡰࠪࢁ"))
    l1111ll1_opy_.write(l1l11_opy_ (u"ࠨ࡞ࡱࠫࢂ"))
    l1111ll1_opy_.close()
def l1llll1l1_opy_(l1lll1111_opy_):
    if l1lll1111_opy_ == l1lll11ll_opy_:
        return l1l11_opy_ (u"ࠩࡱࡸࡻ࠭ࢃ")
    if l1lll1111_opy_ == l111111l_opy_:
        return l1l11_opy_ (u"ࠪࡹࡰࡺࠧࢄ")
def l111l111_opy_(l1lll1111_opy_):
    if l1lll1111_opy_ == l111111l_opy_:
        return l1lll11l1_opy_(l1lll1111_opy_)
    if l1lll1111_opy_ == l1lll11ll_opy_:
        xbmcaddon.Addon(l1lll11ll_opy_).setSetting(l1l11_opy_ (u"ࠫ࡬࡫࡮ࡳࡧࠪࢅ"), l1l11_opy_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫࢆ"))
        xbmcaddon.Addon(l1lll11ll_opy_).setSetting(l1l11_opy_ (u"࠭ࡴࡷࡩࡸ࡭ࡩ࡫ࠧࢇ"), l1l11_opy_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭࢈"))
    l1ll1lll1_opy_  = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫࢉ") + l1lll1111_opy_
    l1llll1ll_opy_ =  l1111lll_opy_(l1lll1111_opy_)
    query   =  l1ll1lll1_opy_ + l1llll1ll_opy_
    return sendJSON(query, l1lll1111_opy_)
def getPluginInfo(streamurl):
    if streamurl.isdigit():
        l1ll1l1ll_opy_   = l1l11_opy_ (u"ࠩࡎࡳࡩ࡯ࠠࡑࡘࡕࠤࡈ࡮ࡡ࡯ࡰࡨࡰࠬࢊ")
        l1ll1ll11_opy_ = os.path.join(dixie.RESOURCES, l1l11_opy_ (u"ࠪ࡯ࡴࡪࡩ࠮ࡲࡹࡶ࠳ࡶ࡮ࡨࠩࢋ"))
        return l1ll1l1ll_opy_, l1ll1ll11_opy_
    if streamurl.startswith(l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧࢌ")):
        name = streamurl.split(l1l11_opy_ (u"ࠬ࠵࠯ࠨࢍ"), 1)[-1].split(l1l11_opy_ (u"࠭࠯ࠨࢎ"), 1)[0]
    if streamurl.startswith(l1l11_opy_ (u"ࠧࡉࡆࡗ࡚࠿࠭࢏")):
        name = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡩࡦࡷࡺࠬ࢐")
    if streamurl.startswith(l1l11_opy_ (u"ࠩࡋࡈ࡙࡜࠲࠻ࠩ࢑")):
        name = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧࡩࡱࡶࡹࠫ࢒")
    if streamurl.startswith(l1l11_opy_ (u"ࠫࡍࡊࡔࡗ࠵࠽ࠫ࢓")):
        name = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢࡶࡹࠫ࢔")
    if streamurl.startswith(l1l11_opy_ (u"࠭ࡈࡅࡖ࡙࠸࠿࠭࢕")):
        name = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸ࡭ࠩ࢖")
    if streamurl.startswith(l1l11_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠺ࠨࢗ")):
        name = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡤࡥࡧ࡮ࡶ࡬ࡢࡻࡨࡶࠬ࢘")
    if streamurl.startswith(l1l11_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠴࠽࢙ࠫ")):
        name = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽ࢚ࠧ")
    if streamurl.startswith(l1l11_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖ࠿࢛࠭")):
        name = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰ࡭ࡣࡼࡩࡷࡽࡷࡸࠩ࢜")
    if streamurl.startswith(l1l11_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡏࡔࡗ࠼ࠪ࢝")):
        name = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡶࡹࠫ࢞")
    if streamurl.startswith(l1l11_opy_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠼ࠪ࢟")):
        name = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡯࡭ࡻ࡫࡭ࡪࡺࠪࢠ")
    if streamurl.startswith(l1l11_opy_ (u"ࠫࡺࡶ࡮ࡱ࠼ࠪࢡ")):
        name = l1l11_opy_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳࡮ࡤࡩࡱࡰࡩࡷࡻ࡮࠯ࡸ࡬ࡩࡼ࠭ࢢ")
    if streamurl.startswith(l1l11_opy_ (u"࠭࡟ࡠࡕࡉࡣࡤ࠭ࢣ")):
        name = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡱࡴࡲ࡫ࡷࡧ࡭࠯ࡵࡸࡴࡪࡸ࠮ࡧࡣࡹࡳࡺࡸࡩࡵࡧࡶࠫࢤ")
    try:
        l1ll1l1ll_opy_   = xbmcaddon.Addon(name).getAddonInfo(l1l11_opy_ (u"ࠨࡰࡤࡱࡪ࠭ࢥ"))
        l1ll1ll11_opy_ = xbmcaddon.Addon(name).getAddonInfo(l1l11_opy_ (u"ࠩ࡬ࡧࡴࡴࠧࢦ"))
    except:
        l1ll1l1ll_opy_   = l1l11_opy_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡸࡺࡲࡦࡣࡰࠤࡴࡸࠠࡢࡦࡧ࠱ࡴࡴࠧࢧ")
        l1ll1ll11_opy_ =  dixie.ICON
    return l1ll1l1ll_opy_, l1ll1ll11_opy_
def l1lll11l1_opy_(l1lll1111_opy_):
    l1ll1lll1_opy_ = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧࢨ") + l1lll1111_opy_
    l1ll11lll_opy_ = l1l11_opy_ (u"ࠬ࠵࠿ࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡰࡳࡩ࡫࠽࠲ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡹࡩࠪ࠸࠰ࡕࡘࠩࡹࡷࡲ࠽ࡩࡶࡷࡴࠪ࠹ࡡࠦ࠴ࡩࠩ࠷࡬࡭ࡦࡶࡤࡰࡰ࡫ࡴࡵ࡮ࡨ࠲ࡨࡵࠥ࠳ࡨࡘࡏ࡙ࡻࡲ࡬࠳࠻࠴࠷࠸࠰࠲࠸ࠨ࠶࡫ࡒࡩࡷࡧࠨ࠶࠺࠸࠰ࡕࡘ࠱ࡸࡽࡺࠧࢩ")
    l1ll1l111_opy_ = l1l11_opy_ (u"࠭࠯ࡀࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࠩࡱࡴࡪࡥ࠾࠳ࠩࡲࡦࡳࡥ࠾ࡕࡳࡳࡷࡺࡳࠧࡷࡵࡰࡂ࡮ࡴࡵࡲࠨ࠷ࡦࠫ࠲ࡧࠧ࠵ࡪࡲ࡫ࡴࡢ࡮࡮ࡩࡹࡺ࡬ࡦ࠰ࡦࡳࠪ࠸ࡦࡖࡍࡗࡹࡷࡱ࠱࠹࠲࠵࠶࠵࠷࠶ࠦ࠴ࡩࡗࡵࡵࡲࡵࡵࡏ࡭ࡸࡺ࠮ࡵࡺࡷࠫࢪ")
    l1lll1ll1_opy_  = []
    l1lll1ll1_opy_ += sendJSON(l1ll1lll1_opy_ + l1ll11lll_opy_, l1lll1111_opy_)
    l1lll1ll1_opy_ += sendJSON(l1ll1lll1_opy_ + l1ll1l111_opy_, l1lll1111_opy_)
    return l1lll1ll1_opy_
def l1111lll_opy_(l1lll1111_opy_):
    if l1lll1111_opy_ == l1lll11ll_opy_:
        return l1l11_opy_ (u"ࠧ࠰ࡁࡦࡥࡹࡃ࠭࠳ࠨࡰࡳࡩ࡫࠽࠳ࠨࡱࡥࡲ࡫࠽ࡎࡻࠨ࠶࠵ࡉࡨࡢࡰࡱࡩࡱࡹࠦࡶࡴ࡯ࡁࡺࡸ࡬ࠨࢫ")
def sendJSON(query, l1lll1111_opy_):
    try:
        l1lllll11_opy_     = l1l11_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࢬ") % query
        l1lll1l11_opy_  = xbmc.executeJSONRPC(l1lllll11_opy_)
        response = json.loads(l1lll1l11_opy_)
        result   = response[l1l11_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩࢭ")]
        return result[l1l11_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩࢮ")]
    except Exception as e:
        l1lll111l_opy_(e, l1lll1111_opy_)
        return {l1l11_opy_ (u"ࠫࡊࡸࡲࡰࡴࠪࢯ") : l1l11_opy_ (u"ࠬࡖ࡬ࡶࡩ࡬ࡲࠥࡋࡲࡳࡱࡵࠫࢰ")}
def l1lll111l_opy_(e, l1lll1111_opy_):
    l1llllll1_opy_ = l1l11_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠱ࠦࡡ࡯ࠢࡨࡶࡷࡵࡲࠡࡱࡦࡧࡺࡸࡥࡥ࠼ࠣࡎࡘࡕࡎࠡࡇࡵࡶࡴࡸ࠺ࠡࠧࡶ࠰ࠥࠫࡳࠨࢱ")  % (e, l1lll1111_opy_)
    l1lllllll_opy_ = l1l11_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡤࡱࡱࡸࡦࡩࡴࠡࡷࡶࠤࡴࡴࠠࡵࡪࡨࠤ࡫ࡵࡲࡶ࡯࠱ࠫࢲ")
    l1111111_opy_ = l1l11_opy_ (u"ࠨࡗࡳࡰࡴࡧࡤࠡࡣࠣࡰࡴ࡭ࠠࡷ࡫ࡤࠤࡹ࡮ࡥࠡࡣࡧࡨࡴࡴࠠࡴࡧࡷࡸ࡮ࡴࡧࡴࠢࡤࡲࡩࠦࡰࡰࡵࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰ࠴ࠧࢳ")
    dixie.log(l1lll1111_opy_)
    dixie.log(e)
def getPlaylist():
    try:
        l1llll11l_opy_  = l1l11_opy_ (u"ࠤࡲࡷ࠳ࡸࡥ࡮ࡱࡹࡩ࠭ࡵࡳ࠯ࡲࡤࡸ࡭࠴ࡪࡰ࡫ࡱࠬࡽࡨ࡭ࡤ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࡕࡧࡴࡩࠪࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡰࡳࡱࡩ࡭ࡱ࡫࠯ࠨࠫ࠯ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡ࠰ࡵࡦࡶ࡮ࡶࡴ࠯ࡶࡹࡴࡴࡸࡴࡢ࡮࠲ࡴࡷࡵࡧࡳࡣࡰ࠲ࡩࡨࠧࠪࠫࠥࢴ")
        eval(l1llll11l_opy_)
    except: pass
    import requests
    l1lll1l1l_opy_ = [l1l11_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡫ࡴ࠸࡬࠯࡫ࡱ࡯࠴ࡱ࡯ࡥ࡫ࠪࢵ"), l1l11_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱ࡧࡦࡨ࡮࠰࠲ࠩࢶ"), l1l11_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫࠱ࡧࡨࡲࡤ࠯࡫ࡲࠫࢷ"), l1l11_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡࡪࡱ࠱ࡧࡨࡲ࡯ࡶࡦࡷࡺ࠳ࡵࡲࡨ࠱࡮ࡳࡩ࡯ࠧࢸ")]
    l1ll1ll1l_opy_ =  l1l11_opy_ (u"ࠧࠤࡇ࡛ࡘࡒ࠹ࡕࠨࢹ")
    for url in l1lll1l1l_opy_:
        dixie.log(url)
        try:
            request  = requests.get(url)
            l11111ll_opy_ = request.text
        except: pass
        if l1ll1ll1l_opy_ in l11111ll_opy_:
            path = os.path.join(dixie.PROFILE, l1l11_opy_ (u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡱ࠸ࡻࠧࢺ"))
            with open(path, l1l11_opy_ (u"ࠩࡺࠫࢻ")) as f:
                f.write(l11111ll_opy_)
                break
    import urllib
    l11111l1_opy_ = os.path.join(PATH, l1l11_opy_ (u"ࠪࡸࡪࡳࡰࡪࡰ࡬ࠫࢼ"))
    l1lll1lll_opy_  = os.path.join(PATH, l1l11_opy_ (u"ࠫ࡮ࡴࡩ࠳࠰࡬ࡲ࡮࠭ࢽ"))
    l1lll1l1l_opy_  = l1l11_opy_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡲࡢࡹ࠱࡫࡮ࡺࡨࡶࡤࡸࡷࡪࡸࡣࡰࡰࡷࡩࡳࡺ࠮ࡤࡱࡰ࠳ࡗ࡫࡮ࡦࡩࡤࡨࡪࡹࡔࡗ࠱ࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡲࡦࡰࡨ࡫ࡦࡪࡥࡴࡶࡹ࠳ࡲࡧࡳࡵࡧࡵ࠳ࡦࡪࡤࡰࡰࡶ࠶࠳࡯࡮ࡪࠩࢾ")
    urllib.urlretrieve(l1lll1l1l_opy_, l11111l1_opy_)
    temp = open(l11111l1_opy_)
    l1111l1l_opy_  = open(l1lll1lll_opy_, l1l11_opy_ (u"࠭ࡷࡵࠩࢿ"))
    for line in temp:
        l1111l1l_opy_.write(line.replace(
                               l1l11_opy_ (u"ࠧ࡜ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡥࡧࡻࡡࠬࣀ"), l1l11_opy_ (u"ࠨ࡝ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡺࡻࡼࡢ࠭ࣁ"))
                               .replace(l1l11_opy_ (u"ࠩ࡞ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡉ࠲࡙࠴ࡖ࡞ࠩࣂ"), l1l11_opy_ (u"ࠪ࡟ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡽࡾ࡝ࠨࣃ"))
                               .replace(l1l11_opy_ (u"ࠫࡠࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶ࡬ࡢࡻࡨࡶࡼࡽࡷ࡞ࠩࣄ"), l1l11_opy_ (u"ࠬࡡࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾࡸࡹ࡟ࠪࣅ"))
                               .replace(l1l11_opy_ (u"࡛࠭ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡵࡸࡠࠫࣆ"), l1l11_opy_ (u"ࠧ࡜ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡹࡺࡻࡡࠬࣇ"))
                               .replace(l1l11_opy_ (u"ࠨ࡝ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡤࡥࡧ࡮ࡶ࡬ࡢࡻࡨࡶࡢ࠭ࣈ"), l1l11_opy_ (u"ࠩ࡞ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡼࡽࡣࠧࣉ"))
                               .replace(l1l11_opy_ (u"ࠪ࡟ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡧࡦࡹࡴࡢࡹࡤࡽࡢ࠭࣊"), l1l11_opy_ (u"ࠫࡠࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡾࡸ࡞ࠩ࣋"))
                               .replace(l1l11_opy_ (u"ࠬࡡࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾ࡬࡞ࠩ࣌"), l1l11_opy_ (u"࡛࠭ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸࡹࡺࡠࠫ࣍"))
                               )
    temp.close()
    l1111l1l_opy_.close()
    os.remove(l11111l1_opy_)