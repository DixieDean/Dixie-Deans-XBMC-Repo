# coding: UTF-8
import sys
l1llll_opy_ = sys.version_info [0] == 2
l1ll1_opy_ = 2048
l11l_opy_ = 7
def l11l1_opy_ (ll_opy_):
	global l1lll1_opy_
	l11ll1_opy_ = ord (ll_opy_ [-1])
	l1111_opy_ = ll_opy_ [:-1]
	l1_opy_ = l11ll1_opy_ % len (l1111_opy_)
	l1l1l1_opy_ = l1111_opy_ [:l1_opy_] + l1111_opy_ [l1_opy_:]
	if l1llll_opy_:
		l1ll11_opy_ = unicode () .join ([unichr (ord (char) - l1ll1_opy_ - (l11ll_opy_ + l11ll1_opy_) % l11l_opy_) for l11ll_opy_, char in enumerate (l1l1l1_opy_)])
	else:
		l1ll11_opy_ = str () .join ([chr (ord (char) - l1ll1_opy_ - (l11ll_opy_ + l11ll1_opy_) % l11l_opy_) for l11ll_opy_, char in enumerate (l1l1l1_opy_)])
	return eval (l1ll11_opy_)
import xbmc
import xbmcaddon
import json
import urllib
import os
import dixie
l111l1ll1_opy_   = l11l1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡵ࡬ࡶࡹࡪࡷࡧ࡮ࡤࡧࠪଌ")
l111ll1ll_opy_   = l11l1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡹࡶࡵࡩࡦࡳ࠭ࡤࡱࡧࡩࡸ࠭଍")
l111l11ll_opy_ = l11l1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࡯ࡰࡵࡸࠪ଎")
l1111llll_opy_    = l11l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡴࡹ࡮ࡩ࡫ࡪࡲࡷࡺࠬଏ")
l111ll111_opy_   = l11l1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡪࡺࡺࡵࡳࡧࡶࡸࡷ࡫ࡡ࡮ࡵࠪଐ")
l111l1111_opy_    = l11l1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡶࡩ࡯ࡼࠪ଑")
l111ll1l1_opy_  = l11l1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹࡴࡦࡣ࡯ࡸ࡭ࡻ࡮ࡥࡧࡵ࡫ࡷࡵࡵ࡯ࡦࠪ଒")
l1111ll1l_opy_     = l11l1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡯ࡵࡶࡤࡰࡵ࡮ࡡࠨଓ")
l1l111l_opy_   =  [l111l1ll1_opy_, l111ll1ll_opy_, l1111llll_opy_, l111ll111_opy_, l111l1111_opy_, l111ll1l1_opy_, l1111ll1l_opy_]
def checkAddons():
    for addon in l1l111l_opy_:
        if l1ll1l1_opy_(addon):
            createINI(addon)
def l1ll1l1_opy_(addon):
    if xbmc.getCondVisibility(l11l1_opy_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫࠩࡸ࠯ࠧଔ") % addon) == 1:
        return True
    else:
        return False
def createINI(addon):
    HOME = dixie.PROFILE
    PATH = os.path.join(HOME, l11l1_opy_ (u"ࠩ࡬ࡲ࡮࠭କ"))
    l11l11_opy_ = str(addon).split(l11l1_opy_ (u"ࠪ࠲ࠬଖ"))[2] + l11l1_opy_ (u"ࠫ࠳࡯࡮ࡪࠩଗ")
    l1l11l1_opy_  = os.path.join(PATH, l11l11_opy_)
    response = l111ll_opy_(addon)
    try:
        result = response[l11l1_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬଘ")]
    except KeyError:
        dixie.log(l11l1_opy_ (u"࠭࠭࠮࠯࠰࠱ࠥࡑࡥࡺࡇࡵࡶࡴࡸࠠࡪࡰࠣ࡫ࡪࡺࡆࡪ࡮ࡨࡷࠥ࠳࠭࠮࠯࠰ࠤࠬଙ") + addon)
        result = {l11l1_opy_ (u"ࡵࠨࡨ࡬ࡰࡪࡹࠧଚ"): [{l11l1_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫଛ"): l11l1_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࠨଜ"), l11l1_opy_ (u"ࡸࠫࡹࡿࡰࡦࠩଝ"): l11l1_opy_ (u"ࡹࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭ଞ"), l11l1_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࠫଟ"): l11l1_opy_ (u"ࡻࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡺࡻࡼࠬଠ"), l11l1_opy_ (u"ࡵࠨ࡮ࡤࡦࡪࡲࠧଡ"): l11l1_opy_ (u"ࡶࠩࡑࡓࠥࡉࡈࡂࡐࡑࡉࡑ࡙ࠧଢ")}], l11l1_opy_ (u"ࡷࠪࡰ࡮ࡳࡩࡵࡵࠪଣ"): {l11l1_opy_ (u"ࡸࠫࡸࡺࡡࡳࡶࠪତ"): 0, l11l1_opy_ (u"ࡹࠬࡺ࡯ࡵࡣ࡯ࠫଥ"): 1, l11l1_opy_ (u"ࡺ࠭ࡥ࡯ࡦࠪଦ"): 1}}
    l1l_opy_ = result[l11l1_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬଧ")]
    l1l11l_opy_  = file(l1l11l1_opy_, l11l1_opy_ (u"ࠧࡸࠩନ"))
    l1l11l_opy_.write(l11l1_opy_ (u"ࠨ࡝ࠪ଩"))
    l1l11l_opy_.write(addon)
    l1l11l_opy_.write(l11l1_opy_ (u"ࠩࡠࠫପ"))
    l1l11l_opy_.write(l11l1_opy_ (u"ࠪࡠࡳ࠭ଫ"))
    l1ll11l_opy_ = []
    for channel in l1l_opy_:
        if addon == l1111ll1l_opy_:
            l1111lll1_opy_ = channel[l11l1_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪବ")].split(l11l1_opy_ (u"ࠬࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩଭ"), 1)[0].replace(l11l1_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡳࡵࡧࡨࡰࡧࡲࡵࡦ࡟ࠪମ"), l11l1_opy_ (u"ࠧࠨଯ"))
            l1111lll1_opy_ = l1111lll1_opy_.replace(l11l1_opy_ (u"ࠨࡗࡎ࠾ࠥ࠭ର"), l11l1_opy_ (u"ࠩࠪ଱"))
        else:
            l1111lll1_opy_ = channel[l11l1_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩଲ")].split(l11l1_opy_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ଳ"), 1)[0].replace(l11l1_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡽࡨࡪࡶࡨࡡࠬ଴"), l11l1_opy_ (u"࠭ࠧଵ"))
            l1111lll1_opy_ = l1111lll1_opy_.replace(l11l1_opy_ (u"ࠧࠡࠢࠪଶ"), l11l1_opy_ (u"ࠨࠩଷ"))
            l1111lll1_opy_ = l1111lll1_opy_.replace(l11l1_opy_ (u"ࠩࡘࡏ࠿ࠦࠧସ"), l11l1_opy_ (u"ࠪࠫହ"))
            l1111lll1_opy_ = l1111lll1_opy_.replace(l11l1_opy_ (u"࡚࡙ࠫࡁ࠻ࠢࠪ଺"), l11l1_opy_ (u"ࠬ࠭଻"))
            l1111lll1_opy_ = l1111lll1_opy_.replace(l11l1_opy_ (u"࠭ࡃࡂ࠼଼ࠣࠫ"), l11l1_opy_ (u"ࠧࠨଽ"))
            l1111lll1_opy_ = l1111lll1_opy_.replace(l11l1_opy_ (u"ࠨࡋࡑࡘ࠿ࠦࠧା"), l11l1_opy_ (u"ࠩࠪି"))
        l1l11_opy_  = dixie.mapChannelName(l1111lll1_opy_)
        stream = channel[l11l1_opy_ (u"ࠪࡪ࡮ࡲࡥࠨୀ")]
        l1lllll_opy_ = l1l11_opy_ + l11l1_opy_ (u"ࠫࡂ࠭ୁ") + stream
        l1ll11l_opy_.append(l1lllll_opy_)
        l1ll11l_opy_.sort()
    for item in l1ll11l_opy_:
      l1l11l_opy_.write(l11l1_opy_ (u"ࠧࠫࡳ࡝ࡰࠥୂ") % item)
    l1l11l_opy_.close()
def l111ll_opy_(addon):
    l111l1l11_opy_ = (l11l1_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࠧࡶࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩୃ") % addon)
    if addon == l111ll1l1_opy_:
        login = l11l1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡷࡩࡦࡲࡴࡩࡷࡱࡨࡪࡸࡧࡳࡱࡸࡲࡩ࠵࠿࡮ࡱࡧࡩࡂ࡭ࡥ࡯ࡴࡨࡷࠫࡶ࡯ࡳࡶࡤࡰࡂࠫ࠷ࡣࠧ࠵࠶ࡳࡧ࡭ࡦࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࠩ࠷࠸ࠥ࠶ࡤࡌࠩ࠺ࡪࠥ࠶ࡤࡆࡓࡑࡕࡒࠦ࠴࠳ࡻ࡭࡯ࡴࡦࠧ࠸ࡨࡈࡲࡩࡤ࡭ࠨ࠶࠵࡚࡯ࠦ࠴࠳࡚࡮࡫ࡷࠦ࠴࠳ࡘ࡭࡫ࠥ࠳࠲ࡏ࡭ࡸࡺࠥ࠳࠲ࡒࡪࠪ࠸࠰ࡄࡪࡤࡲࡳ࡫࡬ࡴࠧ࠸ࡦࠪ࠸ࡦࡄࡑࡏࡓࡗࠫ࠵ࡥࠧ࠸ࡦࠪ࠸ࡦࡊࠧ࠸ࡨࠪ࠸࠲ࠦ࠴ࡦࠩ࠷࠶ࠥ࠳࠴ࡳࡥࡷ࡫࡮ࡵࡣ࡯ࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࠫ࠲࠳ࡨࡤࡰࡸ࡫ࠥ࠳࠴ࠨ࠶ࡨࠫ࠲࠱ࠧ࠵࠶ࡺࡸ࡬ࠦ࠴࠵ࠩ࠸ࡧࠥ࠳࠲ࠨ࠶࠷࡮ࡴࡵࡲࠨ࠷ࡦࠫ࠲ࡧࠧ࠵ࡪࡲࡽ࠱࠯࡫ࡳࡸࡻ࠼࠶࠯ࡶࡹࠩ࠷࠸ࠥ࠳ࡥࠨ࠶࠵ࠫ࠲࠳ࡲࡳࡥࡸࡹࡷࡰࡴࡧࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࠫ࠲࠳࠲࠳࠴࠵ࠫ࠲࠳ࠧ࠵ࡧࠪ࠸࠰ࠦ࠴࠵ࡱࡦࡩࠥ࠳࠴ࠨ࠷ࡦࠫ࠲࠱ࠧ࠵࠶࠵࠶ࠥ࠴ࡣ࠴ࡅࠪ࠹ࡡ࠸࠺ࠨ࠷ࡦ࠺࠳ࠦ࠵ࡤ࠵࠷ࠫ࠳ࡢ࠹࠷ࠩ࠷࠸ࠥ࠳ࡥࠨ࠶࠵ࠫ࠲࠳ࡵࡨࡶ࡮ࡧ࡬ࠦ࠴࠵ࠩ࠸ࡧࠥ࠳࠲ࠨ࠻ࡧࠫ࠲࠳ࡵࡨࡲࡩࡥࡳࡦࡴ࡬ࡥࡱࠫ࠲࠳ࠧ࠶ࡥࠪ࠸࠰ࡵࡴࡸࡩࠪ࠸ࡣࠦ࠴࠳ࠩ࠷࠸ࡣࡶࡵࡷࡳࡲࠫ࠲࠳ࠧ࠶ࡥࠪ࠸࠰ࡵࡴࡸࡩࠪ࠸ࡣࠦ࠴࠳ࠩ࠷࠸ࡳ࡯ࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࠩ࠷࠸ࠥ࠳࠴ࠨ࠶ࡨࠫ࠲࠱ࠧ࠵࠶ࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࠥ࠳࠴ࠨ࠷ࡦࠫ࠲࠱ࠧ࠵࠶ࠪ࠸࠲ࠦ࠴ࡦࠩ࠷࠶ࠥ࠳࠴ࡧࡩࡻ࡯ࡣࡦࡡ࡬ࡨ࠷ࠫ࠲࠳ࠧ࠶ࡥࠪ࠸࠰ࠦ࠴࠵ࠩ࠷࠸ࠥ࠳ࡥࠨ࠶࠵ࠫ࠲࠳ࡦࡨࡺ࡮ࡩࡥࡠ࡫ࡧࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࠫ࠲࠳ࠧ࠵࠶ࠪ࠽ࡤࠦ࠴ࡦࠩ࠷࠶ࠥ࠳࠴ࡳࡥࡸࡹࡷࡰࡴࡧࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࡴࡵ࡭࡮ࠨ࠶ࡨࠫ࠲࠱ࠧ࠵࠶ࡱࡵࡧࡪࡰࠨ࠶࠷ࠫ࠳ࡢࠧ࠵࠴ࡳࡻ࡬࡭ࠧ࠺ࡨࠬୄ")
    else:
        login = l11l1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫ୅") + addon + l11l1_opy_ (u"ࠩ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡸ࡫ࡣࡶࡴ࡬ࡸࡾࡥࡣࡩࡧࡦ࡯ࠫ࡫ࡸࡵࡴࡤࠪࡵࡧࡧࡦࠨࡳࡰࡴࡺࠦࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠩࡸ࡮ࡺ࡬ࡦ࠿ࡏ࡭ࡻ࡫ࠥ࠳࠲ࡗ࡚ࠫࡻࡲ࡭ࠩ୆")
    try:
        query = l111lll1l_opy_(addon)
    except: pass
    l111l111l_opy_ = (l11l1_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭େ") % login)
    l111l11l1_opy_ = (l11l1_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࠥࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧୈ") % query)
    try:
        xbmc.executeJSONRPC(l111l1l11_opy_)
        if addon != l111l11ll_opy_:
            xbmc.executeJSONRPC(l111l111l_opy_)
        response = xbmc.executeJSONRPC(l111l11l1_opy_)
        content  = json.loads(response.decode(l11l1_opy_ (u"ࠬࡻࡴࡧ࠯࠻ࠫ୉"), l11l1_opy_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭୊")))
        return content
    except:
        dixie.log(l11l1_opy_ (u"ࠧ࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮ࠢࡓࡰࡺ࡭ࡩ࡯ࠢࡈࡶࡷࡵࡲࠡ࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯ࠪୋ"))
        return {l11l1_opy_ (u"ࠨࡇࡵࡶࡴࡸࠧୌ") : l11l1_opy_ (u"ࠩࡓࡰࡺ࡭ࡩ࡯ࠢࡈࡶࡷࡵࡲࠨ୍")}
def l111lll1l_opy_(addon):
    if addon == l111l11ll_opy_:
        return l11l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢ࡫ࡳࡸࡻ࠵࠿ࡢࡥࡷ࡭ࡴࡴ࠽࡭࡫ࡹࡩࡹࡼ࡟ࡢ࡮࡯ࠪࡪࡾࡴࡳࡣࠩࡴࡦ࡭ࡥࠧࡲ࡯ࡳࡹࠬࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠿ࠨ࠶࡫࡛ࡳࡦࡴࡶࠩ࠷࡬ࡲࡪࡥ࡫ࡥࡷࡪࠥ࠳ࡨࡏ࡭ࡧࡸࡡࡳࡻࠨ࠶࡫ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࠨ࠶࠵࡙ࡵࡱࡲࡲࡶࡹࠫ࠲ࡧࡍࡲࡨ࡮ࠫ࠲ࡧࡣࡧࡨࡴࡴࡳࠦ࠴ࡩࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡹࡼࡳࡶࡤࡶ࠶࠳࠺ࠥ࠳ࡨࡵࡩࡸࡵࡵࡳࡥࡨࡷࠪ࠸ࡦࡪ࡯ࡪࠩ࠷࡬ࡨࡰࡶ࠱ࡴࡳ࡭ࠦࡵ࡫ࡷࡰࡪࡃࡁ࡭࡮ࠨ࠶࠵ࡩࡨࡢࡰࡱࡩࡱࡹࠦࡶࡴ࡯ࠫ୎")
    if addon == l1111llll_opy_:
        return l11l1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡷࡵࡪࡥ࡮࡭ࡵࡺࡶ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿ࡶࡸࡷ࡫ࡡ࡮ࡡࡹ࡭ࡩ࡫࡯ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠦࡵ࡫ࡷࡰࡪࡃࡁ࡭࡮ࠩࡹࡷࡲ࠽࠱ࠩ୏")
    if addon == l111ll111_opy_:
        return l11l1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡦࡶࡶࡸࡶࡪࡹࡴࡳࡧࡤࡱࡸ࠵࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࡴࡶࡵࡩࡦࡳ࡟ࡷ࡫ࡧࡩࡴࠬࡥࡹࡶࡵࡥࠫࡶࡡࡨࡧࠩࡴࡱࡵࡴࠧࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡁࠫࡺࡩࡵ࡮ࡨࡁࡆࡲ࡬ࠧࡷࡵࡰࡂ࠶ࠧ୐")
    if addon == l111ll1l1_opy_:
        return l11l1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡶࡨࡥࡱࡺࡨࡶࡰࡧࡩࡷ࡭ࡲࡰࡷࡱࡨ࠴ࡅࡧࡦࡰࡵࡩࡤࡴࡡ࡮ࡧࡀࡅࡱࡲࠦࡱࡱࡵࡸࡦࡲ࠽ࠦ࠹ࡅࠩ࠷࠸࡮ࡢ࡯ࡨࠩ࠷࠸ࠥ࠴ࡃ࠮ࠩ࠷࠸ࠥ࠶ࡄࡌࠩ࠺ࡊࠥ࠶ࡄࡆࡓࡑࡕࡒࠬࡹ࡫࡭ࡹ࡫ࠥ࠶ࡆࡆࡰ࡮ࡩ࡫ࠬࡖࡲ࠯࡛࡯ࡥࡸ࠭ࡗ࡬ࡪ࠱ࡌࡪࡵࡷ࠯ࡔ࡬ࠫࡄࡪࡤࡲࡳ࡫࡬ࡴࠧ࠸ࡆࠪ࠸ࡆࡄࡑࡏࡓࡗࠫ࠵ࡅࠧ࠸ࡆࠪ࠸ࡆࡊࠧ࠸ࡈࠪ࠸࠲ࠦ࠴ࡆ࠯ࠪ࠸࠲ࡱࡣࡵࡩࡳࡺࡡ࡭ࠧ࠵࠶ࠪ࠹ࡁࠬࠧ࠵࠶࡫ࡧ࡬ࡴࡧࠨ࠶࠷ࠫ࠲ࡄ࠭ࠨ࠶࠷ࡻࡲ࡭ࠧ࠵࠶ࠪ࠹ࡁࠬࠧ࠵࠶࡭ࡺࡴࡱࠧ࠶ࡅࠪ࠸ࡆࠦ࠴ࡉࡱࡼ࠷࠮ࡪࡲࡷࡺ࠻࠼࠮ࡵࡸࠨ࠶࠷ࠫ࠲ࡄ࠭ࠨ࠶࠷ࡶࡰࡢࡵࡶࡻࡴࡸࡤࠦ࠴࠵ࠩ࠸ࡇࠫࠦ࠴࠵࠴࠵࠶࠰ࠦ࠴࠵ࠩ࠷ࡉࠫࠦ࠴࠵ࡱࡦࡩࠥ࠳࠴ࠨ࠷ࡆ࠱ࠥ࠳࠴࠳࠴ࠪ࠹ࡁ࠲ࡃࠨ࠷ࡆ࠽࠸ࠦ࠵ࡄ࠸࠸ࠫ࠳ࡂ࠳࠵ࠩ࠸ࡇ࠷࠵ࠧ࠵࠶ࠪ࠸ࡃࠬࠧ࠵࠶ࡸ࡫ࡲࡪࡣ࡯ࠩ࠷࠸ࠥ࠴ࡃ࠮ࠩ࠼ࡈࠥ࠳࠴ࡶࡩࡳࡪ࡟ࡴࡧࡵ࡭ࡦࡲࠥ࠳࠴ࠨ࠷ࡆ࠱ࡴࡳࡷࡨࠩ࠷ࡉࠫࠦ࠴࠵ࡧࡺࡹࡴࡰ࡯ࠨ࠶࠷ࠫ࠳ࡂ࠭ࡷࡶࡺ࡫ࠥ࠳ࡅ࠮ࠩ࠷࠸ࡳ࡯ࠧ࠵࠶ࠪ࠹ࡁࠬࠧ࠵࠶ࠪ࠸࠲ࠦ࠴ࡆ࠯ࠪ࠸࠲ࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࠨ࠶࠷ࠫ࠳ࡂ࠭ࠨ࠶࠷ࠫ࠲࠳ࠧ࠵ࡇ࠰ࠫ࠲࠳ࡦࡨࡺ࡮ࡩࡥࡠ࡫ࡧ࠶ࠪ࠸࠲ࠦ࠵ࡄ࠯ࠪ࠸࠲ࠦ࠴࠵ࠩ࠷ࡉࠫࠦ࠴࠵ࡨࡪࡼࡩࡤࡧࡢ࡭ࡩࠫ࠲࠳ࠧ࠶ࡅ࠰ࠫ࠲࠳ࠧ࠵࠶ࠪ࠽ࡄࠦ࠴ࡆ࠯ࠪ࠸࠲ࡱࡣࡶࡷࡼࡵࡲࡥࠧ࠵࠶ࠪ࠹ࡁࠬࡰࡸࡰࡱࠫ࠲ࡄ࠭ࠨ࠶࠷ࡲ࡯ࡨ࡫ࡱࠩ࠷࠸ࠥ࠴ࡃ࠮ࡲࡺࡲ࡬ࠦ࠹ࡇࠪࡲࡵࡤࡦ࠿ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪ࡬࡫࡮ࡳࡧࡢ࡭ࡩࡃࠥ࠳ࡃࠪ୑")
    else:
        Addon = xbmcaddon.Addon(addon)
        if addon == l1111ll1l_opy_:
            username =  Addon.getSetting(l11l1_opy_ (u"ࠧࡖࡵࡨࡶࡳࡧ࡭ࡦࠩ୒"))
            password =  Addon.getSetting(l11l1_opy_ (u"ࠨࡒࡤࡷࡸࡽ࡯ࡳࡦࠪ୓"))
        else:
            username =  Addon.getSetting(l11l1_opy_ (u"ࠩ࡮ࡥࡸࡻࡴࡢ࡬ࡤࡲ࡮ࡳࡩࠨ୔"))
            password =  Addon.getSetting(l11l1_opy_ (u"ࠪࡷࡦࡲࡡࡴࡱࡱࡥࠬ୕"))
        l1111ll11_opy_     = l11l1_opy_ (u"ࠫ࠴ࡅࡡࡤࡶ࡬ࡳࡳࡃࡳࡵࡴࡨࡥࡲࡥࡶࡪࡦࡨࡳࠫ࡫ࡸࡵࡴࡤࠪࡵࡧࡧࡦࠨࡳࡰࡴࡺࠦࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡀࠪࡹ࡯ࡴ࡭ࡧࡀࡅࡱࡲࠦࡶࡴ࡯ࡁࠬୖ")
        l11lllll1_opy_  =  l1l1111ll_opy_(addon)
        l11ll1l11_opy_   = l11l1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨୗ") + addon
        l111l1lll_opy_  =  l11ll1l11_opy_ + l1111ll11_opy_ + l11lllll1_opy_
        l111lll11_opy_ = l11l1_opy_ (u"࠭ࡵࡴࡧࡵࡲࡦࡳࡥ࠾ࠩ୘") + username + l11l1_opy_ (u"ࠧࠧࡲࡤࡷࡸࡽ࡯ࡳࡦࡀࠫ୙") + password + l11l1_opy_ (u"ࠨࠨࡷࡽࡵ࡫࠽ࡨࡧࡷࡣࡱ࡯ࡶࡦࡡࡶࡸࡷ࡫ࡡ࡮ࡵࠩࡧࡦࡺ࡟ࡪࡦࡀ࠴ࠬ୚")
        return l111l1lll_opy_ + urllib.quote_plus(l111lll11_opy_)
def l1l1111ll_opy_(addon):
    if (addon == l111l1ll1_opy_) or (addon == l111ll1ll_opy_):
        return l11l1_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠶࠻࠳࠷࠸࠸࠰࠴࠷࠾࠴࠱࠶࠷࠽࠼࠵࠶࠰࠰ࡧࡱ࡭࡬ࡳࡡ࠳࠰ࡳ࡬ࡵࡅࠧ୛")
    if addon == l111l1111_opy_:
        return l11l1_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡵ࡯࡮ࡻࡶࡹࡴࡷࡵ࠮ࡵ࡭࠽࠼࠵࠶࠰࠰ࡧࡱ࡭࡬ࡳࡡ࠳࠰ࡳ࡬ࡵࡅࠧଡ଼")
    if addon == l1111ll1l_opy_:
        return l11l1_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡴࡺࡴࡵࡸ࠱࡫ࡦࡀ࠲࠱࠻࠸࠳ࡪࡴࡩࡨ࡯ࡤ࠶࠳ࡶࡨࡱࡁࠪଢ଼")
def l11111_opy_(addon, l1l11_opy_):
    if (addon == l111l1ll1_opy_) or (addon == l111ll1ll_opy_):
        l1l11_opy_ = l1l11_opy_.replace(l11l1_opy_ (u"ࠬࠦࠠࠨ୞"), l11l1_opy_ (u"࠭ࠠࠨୟ")).replace(l11l1_opy_ (u"ࠧࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪୠ"), l11l1_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪୡ"))
        return l1l11_opy_
    return l1l11_opy_
def l111l1l1l_opy_(addon, l111ll11l_opy_):
    if (addon == l111l1ll1_opy_) or (addon == l111ll1ll_opy_):
        channel = l111ll11l_opy_.rsplit(l11l1_opy_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫୢ"), 1)[0].split(l11l1_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡻ࡭࡯ࡴࡦ࡟ࠪୣ"), 1)[-1]
        channel = channel.replace(l11l1_opy_ (u"ࠫࡇࡈࡃࠡ࠳ࠪ୤"), l11l1_opy_ (u"ࠬࡈࡂࡄࠢࡒࡲࡪ࠭୥")).replace(l11l1_opy_ (u"࠭ࡂࡃࡅࠣ࠶ࠬ୦"), l11l1_opy_ (u"ࠧࡃࡄࡆࠤ࡙ࡽ࡯ࠨ୧")).replace(l11l1_opy_ (u"ࠨࡄࡅࡇࠥ࠺ࠧ୨"), l11l1_opy_ (u"ࠩࡅࡆࡈࠦࡆࡐࡗࡕࠫ୩")).replace(l11l1_opy_ (u"ࠪࡍ࡙࡜ࠠ࠲ࠩ୪"), l11l1_opy_ (u"ࠫࡎ࡚ࡖ࠲ࠩ୫")).replace(l11l1_opy_ (u"ࠬࡏࡔࡗࠢ࠵ࠫ୬"), l11l1_opy_ (u"࠭ࡉࡕࡘ࠵ࠫ୭")).replace(l11l1_opy_ (u"ࠧࡊࡖ࡙ࠤ࠸࠭୮"), l11l1_opy_ (u"ࠨࡋࡗ࡚࠸࠭୯")).replace(l11l1_opy_ (u"ࠩࡌࡘ࡛ࠦ࠴ࠨ୰"), l11l1_opy_ (u"ࠪࡍ࡙࡜࠴ࠨୱ"))
        return channel
    if (addon == l1111llll_opy_) or (addon == l111ll111_opy_):
        channel = l111ll11l_opy_.rsplit(l11l1_opy_ (u"ࠫࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ୲"))[0].replace(l11l1_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡽࡨࡪࡶࡨࡡࠬ୳"), l11l1_opy_ (u"࠭ࠧ୴"))
        channel = channel.replace(l11l1_opy_ (u"ࠧ࠻ࠩ୵"), l11l1_opy_ (u"ࠨࠩ୶")).replace(l11l1_opy_ (u"ࠩࡅࡆࡈࠦ࠱ࠨ୷"), l11l1_opy_ (u"ࠪࡆࡇࡉࠠࡐࡰࡨࠫ୸")).replace(l11l1_opy_ (u"ࠫࡇࡈࡃࠡ࠴ࠪ୹"), l11l1_opy_ (u"ࠬࡈࡂࡄࠢࡗࡻࡴ࠭୺")).replace(l11l1_opy_ (u"࠭ࡂࡃࡅࠣ࠸ࠬ୻"), l11l1_opy_ (u"ࠧࡃࡄࡆࠤࡋࡕࡕࡓࠩ୼")).replace(l11l1_opy_ (u"ࠨࡋࡗ࡚ࠥ࠷ࠧ୽"), l11l1_opy_ (u"ࠩࡌࡘ࡛࠷ࠧ୾")).replace(l11l1_opy_ (u"ࠪࡍ࡙࡜ࠠ࠳ࠩ୿"), l11l1_opy_ (u"ࠫࡎ࡚ࡖ࠳ࠩ஀")).replace(l11l1_opy_ (u"ࠬࡏࡔࡗࠢ࠶ࠫ஁"), l11l1_opy_ (u"࠭ࡉࡕࡘ࠶ࠫஂ")).replace(l11l1_opy_ (u"ࠧࡊࡖ࡙ࠤ࠹࠭ஃ"), l11l1_opy_ (u"ࠨࡋࡗ࡚࠹࠭஄"))
        return channel
    else:
        channel = l111ll11l_opy_.replace(l11l1_opy_ (u"ࠩࡅࡆࡈࠦ࠱ࠨஅ"), l11l1_opy_ (u"ࠪࡆࡇࡉࠠࡐࡰࡨࠫஆ")).replace(l11l1_opy_ (u"ࠫࡇࡈࡃࠡ࠴ࠪஇ"), l11l1_opy_ (u"ࠬࡈࡂࡄࠢࡗࡻࡴ࠭ஈ")).replace(l11l1_opy_ (u"࠭ࡂࡃࡅࠣ࠸ࠬஉ"), l11l1_opy_ (u"ࠧࡃࡄࡆࠤࡋࡕࡕࡓࠩஊ")).replace(l11l1_opy_ (u"ࠨࡋࡗ࡚ࠥ࠷ࠧ஋"), l11l1_opy_ (u"ࠩࡌࡘ࡛࠷ࠧ஌")).replace(l11l1_opy_ (u"ࠪࡍ࡙࡜ࠠ࠳ࠩ஍"), l11l1_opy_ (u"ࠫࡎ࡚ࡖ࠳ࠩஎ")).replace(l11l1_opy_ (u"ࠬࡏࡔࡗࠢ࠶ࠫஏ"), l11l1_opy_ (u"࠭ࡉࡕࡘ࠶ࠫஐ")).replace(l11l1_opy_ (u"ࠧࡊࡖ࡙ࠤ࠹࠭஑"), l11l1_opy_ (u"ࠨࡋࡗ࡚࠹࠭ஒ"))
        return channel
def l1llllll_opy_(e):
    l111ll1_opy_ = l11l1_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠭ࠢࡤࡲࠥ࡫ࡲࡳࡱࡵࠤࡴࡩࡣࡶࡴࡨࡨ࠿ࠦࡊࡔࡑࡑࠤࡊࡸࡲࡰࡴ࠽ࠤࠪࡹࠧஓ")  %e
    l11ll11_opy_ = l11l1_opy_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡧࡴࡴࡴࡢࡥࡷࠤࡺࡹࠠࡰࡰࠣࡸ࡭࡫ࠠࡧࡱࡵࡹࡲ࠴ࠧஔ")
    l11l111_opy_ = l11l1_opy_ (u"࡚ࠫࡶ࡬ࡰࡣࡧࠤࡦࠦ࡬ࡰࡩࠣࡺ࡮ࡧࠠࡵࡪࡨࠤࡦࡪࡤࡰࡰࠣࡷࡪࡺࡴࡪࡰࡪࡷࠥࡧ࡮ࡥࠢࡳࡳࡸࡺࠠࡵࡪࡨࠤࡱ࡯࡮࡬࠰ࠪக")
    dixie.log(e)
    dixie.DialogOK(l111ll1_opy_, l11ll11_opy_, l11l111_opy_)
    dixie.SetSetting(SETTING, l11l1_opy_ (u"ࠬ࠭஖"))
if __name__ == l11l1_opy_ (u"࠭࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠨ஗"):
    checkAddons()