# coding: UTF-8
import sys
l1llll_opy_ = sys.version_info [0] == 2
l1ll1_opy_ = 2048
l11l_opy_ = 7
def l11l1_opy_ (ll_opy_):
	global l1lll1_opy_
	l11ll1_opy_ = ord (ll_opy_ [-1])
	l1111_opy_ = ll_opy_ [:-1]
	l1_opy_ = l11ll1_opy_ % len (l1111_opy_)
	l1l1l1_opy_ = l1111_opy_ [:l1_opy_] + l1111_opy_ [l1_opy_:]
	if l1llll_opy_:
		l1ll11_opy_ = unicode () .join ([unichr (ord (char) - l1ll1_opy_ - (l11ll_opy_ + l11ll1_opy_) % l11l_opy_) for l11ll_opy_, char in enumerate (l1l1l1_opy_)])
	else:
		l1ll11_opy_ = str () .join ([chr (ord (char) - l1ll1_opy_ - (l11ll_opy_ + l11ll1_opy_) % l11l_opy_) for l11ll_opy_, char in enumerate (l1l1l1_opy_)])
	return eval (l1ll11_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
ADDON    = dixie.ADDON
l111lll_opy_ = dixie.PROFILE
l111111_opy_  = os.path.join(l111lll_opy_, l11l1_opy_ (u"ࠪ࡭ࡳ࡯ࠧࡌ"))
l1lllll1_opy_ = l11l1_opy_ (u"ࠫࠬࡍ")
def l1lll111_opy_(i, t1, l1llll1l_opy_=[]):
 t = l1lllll1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1llll1l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11l1ll_opy_ = l1lll111_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11l1l1_opy_ = l1lll111_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1llll11_opy_ = l11l1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡋࡲࡡࡸ࡮ࡨࡷࡸ࡚ࡶࠨࡎ")
dexter   = l11l1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡪࡥࡹࠩࡏ")
l1l111l_opy_   = [l1llll11_opy_, dexter]
def checkAddons():
    for addon in l1l111l_opy_:
        if l1ll1l1_opy_(addon):
            createINI(addon)
def l1ll1l1_opy_(addon):
    if xbmc.getCondVisibility(l11l1_opy_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡉࡣࡶࡅࡩࡪ࡯࡯ࠪࠨࡷ࠮࠭ࡐ") % addon) == 1:
        return True
    else:
        return False
def createINI(addon):
    l11llll_opy_ = os.path.join(l111111_opy_, l11l1_opy_ (u"ࠨࡦࡨࡼࡹ࡫ࡲ࠯࡫ࡱ࡭ࠬࡑ"))
    if os.path.exists(l11llll_opy_):
        os.remove(l11llll_opy_)
    HOME  = dixie.PROFILE
    l1lll11_opy_ = os.path.join(HOME, l11l1_opy_ (u"ࠩ࡬ࡲ࡮࠭ࡒ"))
    l11l11_opy_  = str(addon).split(l11l1_opy_ (u"ࠪ࠲ࠬࡓ"))[2] + l11l1_opy_ (u"ࠫ࠳࡯࡮ࡪࠩࡔ")
    l1l11l1_opy_   = os.path.join(l1lll11_opy_, l11l11_opy_)
    response = l111ll_opy_(addon)
    l1l_opy_ = response[l11l1_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬࡕ")][l11l1_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬࡖ")]
    l1ll1ll_opy_  = l11l1_opy_ (u"ࠧ࡜ࠩࡗ") + addon + l11l1_opy_ (u"ࠨ࡟࡟ࡲࠬࡘ")
    l1l11l_opy_  =  file(l1l11l1_opy_, l11l1_opy_ (u"ࠩࡺ࡙ࠫ"))
    l1l11l_opy_.write(l1ll1ll_opy_)
    l1ll11l_opy_ = []
    for channel in l1l_opy_:
        l1l1l11_opy_ = channel[l11l1_opy_ (u"ࠪࡰࡦࡨࡥ࡭࡚ࠩ")]
        l1l11ll_opy_ = l11111_opy_(l1l1l11_opy_)
        l1ll111_opy_ = l1l11ll_opy_
        l1llll1_opy_ = l1lll1l_opy_(addon)
        l1111l_opy_  = dixie.mapChannelName(l1l11ll_opy_)
        stream    = l1llll1_opy_ + l1ll111_opy_
        l1lllll_opy_   = l1111l_opy_ + l11l1_opy_ (u"ࠫࡂ࡛࠭") + stream
        if l1lllll_opy_ not in l1ll11l_opy_:
            l1ll11l_opy_.append(l1lllll_opy_)
    l1ll11l_opy_.sort()
    for item in l1ll11l_opy_:
        l1l11l_opy_.write(l11l1_opy_ (u"ࠧࠫࡳ࡝ࡰࠥ࡜") % item)
    l1l11l_opy_.close()
def l1lll1l_opy_(addon):
    if addon == l1llll11_opy_:
        return l11l1_opy_ (u"࠭ࡆࡍࡃ࠽ࠫ࡝")
    if addon == dexter:
        return l11l1_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡊ࠺ࠨ࡞")
def l11111_opy_(l1l11_opy_):
    l111l1_opy_ = l1l11_opy_.split(l11l1_opy_ (u"ࠨࠢ࡞ࠫ࡟"), 1)
    l1l11_opy_  = l111l1_opy_[0]
    return l11l1l_opy_(l1l11_opy_)
def l11l1l_opy_(name):
    import re
    name  = re.sub(l11l1_opy_ (u"ࠩ࡟ࠬࡠ࠶࠭࠺ࠫࡠ࠮ࡡ࠯ࠧࡠ"), l11l1_opy_ (u"ࠪࠫࡡ"), name)
    items = name.split(l11l1_opy_ (u"ࠫࡢ࠭ࡢ"))
    name  = l11l1_opy_ (u"ࠬ࠭ࡣ")
    for item in items:
        if len(item) == 0:
            continue
        item += l11l1_opy_ (u"࠭࡝ࠨࡤ")
        item  = re.sub(l11l1_opy_ (u"ࠧ࡝࡝࡞ࡢ࠮ࡣࠪ࡝࡟ࠪࡥ"), l11l1_opy_ (u"ࠨࠩࡦ"), item)
        if len(item) > 0:
            name += item
    name  = name.replace(l11l1_opy_ (u"ࠩ࡞ࠫࡧ"), l11l1_opy_ (u"ࠪࠫࡨ"))
    name  = name.replace(l11l1_opy_ (u"ࠫࡢ࠭ࡩ"), l11l1_opy_ (u"ࠬ࠭ࡪ"))
    name  = name.strip()
    while True:
        length = len(name)
        name = name.replace(l11l1_opy_ (u"࠭ࠠࠡࠩ࡫"), l11l1_opy_ (u"ࠧࠡࠩ࡬"))
        if length == len(name):
            break
    return name.strip()
def getURL(url):
    if url.startswith(l11l1_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡃࡍࡗ࠽ࠫ࡭")):
        url = url.replace(l11l1_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡄࡎࡘ࠾ࠬ࡮"), l11l1_opy_ (u"ࠪࠫ࡯")).replace(l11l1_opy_ (u"ࠫ࠲࠳ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪࡰ"), l11l1_opy_ (u"ࠬࢂࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪࡱ"))
        return url
    if url.startswith(l11l1_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡉ࠭ࡲ")):
        return l11lll1_opy_(url, dexter)
    if url.startswith(l11l1_opy_ (u"ࠧࡇࡎࡄࠫࡳ")):
        return l11lll1_opy_(url, l1llll11_opy_)
    response = l1lll1l1_opy_(url)
    stream   = url.split(l11l1_opy_ (u"ࠨ࠼ࠪࡴ"), 1)[-1]
    try:
        result = response[l11l1_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩࡵ")]
        l1111ll_opy_  = result[l11l1_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩࡶ")]
    except Exception as e:
        l1llllll_opy_(e)
        return None
    for file in l1111ll_opy_:
        l1l11_opy_ = file[l11l1_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪࡷ")]
        if stream in l1l11_opy_:
            return file[l11l1_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪࡸ")]
    return None
def l11lll1_opy_(url, addon):
    PATH = l11ll1l_opy_(addon)
    if os.path.exists(PATH):
        response = json.load(open(PATH))
    else:
        response = l111ll_opy_(addon)
    l11111l_opy_ = url.split(l11l1_opy_ (u"࠭࠺ࠨࡹ"))[0]
    l1lll11l_opy_    = url.split(l11l1_opy_ (u"ࠧ࠻ࠩࡺ"), 1)[-1]
    l1lll1ll_opy_ = l1lll11l_opy_.split(l11l1_opy_ (u"ࠨࠢ࡞ࠫࡻ"), 1)
    stream  = l1lll1ll_opy_[0]
    l1111ll_opy_  = response[l11l1_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩࡼ")][l11l1_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩࡽ")]
    for file in l1111ll_opy_:
        l111l1_opy_ = file[l11l1_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪࡾ")].split(l11l1_opy_ (u"࡛ࠬࠦࠨࡿ"), 1)
        l1l11_opy_  = l111l1_opy_[0]
        l1l11_opy_  = l1l11_opy_.replace(l11l1_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡷࡩ࡫ࡷࡩࡢ࠭ࢀ"), l11l1_opy_ (u"ࠧࠨࢁ"))
        if stream in l1l11_opy_:
            l1111l1_opy_ = file[l11l1_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ࢂ")]
            if l11111l_opy_ == l11l1_opy_ (u"ࠩࡉࡐࡆ࡙ࠧࢃ"):
                return l1111l1_opy_
            l1111l1_opy_ = l1111l1_opy_.replace(l11l1_opy_ (u"ࠪ࠲ࡹࡹࠧࢄ"), l11l1_opy_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪࢅ"))
            return l1111l1_opy_
def l111ll_opy_(addon):
    if addon == l1llll11_opy_:
        query = l11l1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡆ࡭ࡣࡺࡰࡪࡹࡳࡕࡸ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡸࡺࡲࡦࡣࡰࡣࡻ࡯ࡤࡦࡱࠩࡩࡽࡺࡲࡢࠨࡳࡥ࡬࡫ࠦࡱ࡮ࡲࡸࠫࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠾ࠨࡷ࡭ࡹࡲࡥ࠾ࡃ࡯ࡰࠫࡻࡲ࡭࠿࠳ࠫࢆ")
        content = doJSON(query)
        return l111l11_opy_(addon, content)
    if addon == dexter:
        query   = l11l11l_opy_(dexter)
        content = doJSON(query)
        return l111l11_opy_(dexter, content)
def l111l11_opy_(addon, content):
    PATH  = l11ll1l_opy_(addon)
    json.dump(content, open(PATH,l11l1_opy_ (u"࠭ࡷࠨࢇ")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    l1l1ll1_opy_  = (l11l1_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ࢈") % query)
    response = xbmc.executeJSONRPC(l1l1ll1_opy_)
    content  = json.loads(response)
    return content
def l11ll1l_opy_(addon):
    if addon == l1llll11_opy_:
        return os.path.join(dixie.PROFILE, l11l1_opy_ (u"ࠨࡨࡷࡩࡲࡶࠧࢉ"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l11l1_opy_ (u"ࠩࡧࡸࡪࡳࡰࠨࢊ"))
def l11l11l_opy_(addon):
    if addon == dexter:
        query = l11l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸࠨࢋ")
        response = doJSON(query)
        l1111ll_opy_    = response[l11l1_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫࢌ")][l11l1_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫࢍ")]
        for file in l1111ll_opy_:
            l1l11_opy_ = file[l11l1_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬࢎ")]
            if l1l11_opy_ == l11l1_opy_ (u"ࠧࡂ࡮࡯ࠫ࢏"):
                login = file[l11l1_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭࢐")]
                return login
def l1lll1l1_opy_(url):
    if url.startswith(l11l1_opy_ (u"ࠩࡌࡔࡑࡇ࡙࠻ࠩ࢑")):
        l1l1ll1_opy_ = (l11l1_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡢࡣࡥ࡬ࡴࡱࡧࡹࡦࡴ࠲ࡃࡺࡸ࡬࠾ࡷࡵࡰࠫࡳ࡯ࡥࡧࡀ࠶ࠫࡴࡡ࡮ࡧࡀࡐ࡮ࡼࡥࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࡀࠪࡎࡖࡉࡅ࠿ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ࢒"))
    if url.startswith(l11l1_opy_ (u"ࠫࡎࡖࡌࡂ࡛࠵࠾ࠬ࢓")):
        l1l1ll1_opy_ = (l11l1_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡰࡦࡿࡥࡳࡹࡺࡻ࠴ࡅࡵࡳ࡮ࡀࡹࡷࡲࠦ࡮ࡱࡧࡩࡂ࠷࠰࠲ࠨࡱࡥࡲ࡫࠽ࡘࡣࡷࡧ࡭࠱ࡌࡪࡸࡨࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࡃࠦࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡵࡢࡹࡷࡲ࠽ࠧ࡮ࡲ࡫࡬࡫ࡤࡠ࡫ࡱࡁࡋࡧ࡬ࡴࡧࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ࢔"))
    if url.startswith(l11l1_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡗࡀࠧ࢕")):
        l1l1ll1_opy_ = (l11l1_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽ࠯ࡀࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬ࠬ࡬ࡰࡩࡪࡩࡩࡥࡩ࡯࠿ࡉࡥࡱࡹࡥࠧ࡯ࡲࡨࡪࡃ࠱࠲࠵ࠩࡲࡦࡳࡥ࠾ࡎ࡬ࡷࡹ࡫࡮ࠦ࠴࠳ࡐ࡮ࡼࡥࠧࡵࡸࡦࡹ࡯ࡴ࡭ࡧࡶࡣࡺࡸ࡬ࠧࡷࡵࡰࡂࡻࡲ࡭ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧ࢖"))
    if url.startswith(l11l1_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡉࡕࡘ࠽ࠫࢗ")):
        l1l1ll1_opy_ = (l11l1_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡴࡷࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧ࢘"))
    if url.startswith(l11l1_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡆ࠽࢙ࠫ")):
        l1l1ll1_opy_ = (l11l1_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡥࡧࡻ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡧ࡬࡭ࠨࡨࡼࡹࡸࡡࠧࡲࡤ࡫ࡪࠬࡰ࡭ࡱࡷࠪࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠽ࠧࡶ࡬ࡸࡱ࡫࠽ࠦ࠷ࡥࡇࡔࡒࡏࡓࠧ࠵࠴ࡼ࡮ࡩࡵࡧࠨ࠹ࡩࡇ࡬࡭ࠧ࠵࠴ࡈ࡮ࡡ࡯ࡰࡨࡰࡸࠫ࠵ࡣࠧ࠵ࡪࡈࡕࡌࡐࡔࠨ࠹ࡩࠬࡵࡳ࡮ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ࢚"))
    if url.startswith(l11l1_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖࡇࡀ࢛ࠧ")):
        l1l1ll1_opy_ = (l11l1_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡩࡧࡵ࡯ࡵ࠱ࡂࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠧࡨࡤࡲࡦࡸࡴ࠾ࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࠬ࡭ࡰࡦࡨࡁ࠼ࠬࡰࡪ࡮࡯ࡳࡼࡃࡌࡪࡸࡨࠩ࠷࠶ࡓࡵࡴࡨࡥࡲࡹࠦࡶࡴ࡯ࡁࡷࡧ࡮ࡥࡱࡰࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ࢜"))
    if url.startswith(l11l1_opy_ (u"ࠧࡊࡒࡗࡗ࠿࠭࢝")):
        l1l1ll1_opy_ = (l11l1_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢ࡫ࡳࡸࡻ࠵࠿ࡢࡥࡷ࡭ࡴࡴ࠽࡭࡫ࡹࡩࡹࡼ࡟ࡢ࡮࡯ࠪࡪࡾࡴࡳࡣࠩࡴࡦ࡭ࡥࠧࡲ࡯ࡳࡹࠬࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠿ࠩࡸ࡮ࡺ࡬ࡦ࠿ࡄࡰࡱࠫ࠲࠱ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠩࡹࡷࡲࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬ࢞"))
    try:
        dixie.ShowBusy()
        addon =  l1l1ll1_opy_.split(l11l1_opy_ (u"ࠩ࠲࠳ࠬ࢟"), 1)[-1].split(l11l1_opy_ (u"ࠪ࠳ࠬࢠ"), 1)[0]
        login = l11l1_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩࢡ") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1l1ll1_opy_)
        dixie.log(response)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1llllll_opy_(e)
        return {l11l1_opy_ (u"ࠬࡋࡲࡳࡱࡵࠫࢢ") : l11l1_opy_ (u"࠭ࡐ࡭ࡷࡪ࡭ࡳࠦࡅࡳࡴࡲࡶࠬࢣ")}
def l111l1l_opy_():
    modules = map(__import__, [l1lll111_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11l1ll_opy_)):
        return l11l1_opy_ (u"ࠧࡕࡴࡸࡩࠬࢤ")
    if len(modules[-1].Window(10**4).getProperty(l11l1l1_opy_)):
        return l11l1_opy_ (u"ࠨࡖࡵࡹࡪ࠭ࢥ")
    return l11l1_opy_ (u"ࠩࡉࡥࡱࡹࡥࠨࢦ")
def l1llllll_opy_(e):
    l111ll1_opy_ = l11l1_opy_ (u"ࠪࡗࡴࡸࡲࡺ࠮ࠣࡥࡳࠦࡥࡳࡴࡲࡶࠥࡵࡣࡤࡷࡵࡩࡩࡀࠠࡋࡕࡒࡒࠥࡋࡲࡳࡱࡵ࠾ࠥࠫࡳࠨࢧ")  %e
    l11ll11_opy_ = l11l1_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡷ࡫࠭࡭࡫ࡱ࡯ࠥࡺࡨࡪࡵࠣࡧ࡭ࡧ࡮࡯ࡧ࡯ࠤࡦࡴࡤࠡࡶࡵࡽࠥࡧࡧࡢ࡫ࡱ࠲ࠬࢨ")
    l11l111_opy_ = l11l1_opy_ (u"࡛ࠬࡳࡦ࠼ࠣࡇࡴࡴࡴࡦࡺࡷࠤࡒ࡫࡮ࡶࠢࡀࡂࠥࡘࡥ࡮ࡱࡹࡩ࡙ࠥࡴࡳࡧࡤࡱࠬࢩ")
    dixie.log(e)
    dixie.DialogOK(l111ll1_opy_, l11ll11_opy_, l11l111_opy_)
if __name__ == l11l1_opy_ (u"࠭࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠨࢪ"):
    checkAddons()