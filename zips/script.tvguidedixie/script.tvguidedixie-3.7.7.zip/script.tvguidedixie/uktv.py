# coding: UTF-8
import sys
l11ll111_opy_ = sys.version_info [0] == 2
l1lll1l1_opy_ = 2048
l11lllll_opy_ = 7
def l1l11_opy_ (l11ll1_opy_):
	global l1llll11_opy_
	l1ll1111_opy_ = ord (l11ll1_opy_ [-1])
	l11ll11l_opy_ = l11ll1_opy_ [:-1]
	l11l11l_opy_ = l1ll1111_opy_ % len (l11ll11l_opy_)
	l111l1_opy_ = l11ll11l_opy_ [:l11l11l_opy_] + l11ll11l_opy_ [l11l11l_opy_:]
	if l11ll111_opy_:
		l1lll1_opy_ = unicode () .join ([unichr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	else:
		l1lll1_opy_ = str () .join ([chr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	return eval (l1lll1_opy_)
import xbmc
import xbmcaddon
import json
import urllib
import os
import dixie
l1l11l1l1_opy_   = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸ࡯ࡹࡼࡦࡳࡣࡱࡧࡪ࠭थ")
l1l11llll_opy_   = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡹࡸࡥࡢ࡯࠰ࡧࡴࡪࡥࡴࠩद")
l1l111ll1_opy_ = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢ࡫ࡳࡸࡻ࠭ध")
l1l1111l1_opy_    = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡷࡵࡪࡥ࡮࡭ࡵࡺࡶࠨन")
l1l11ll11_opy_   = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡦࡶࡶࡸࡶࡪࡹࡴࡳࡧࡤࡱࡸ࠭ऩ")
l1l1111ll_opy_    = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡲ࡬ࡲࡿ࠭प")
l1l11lll1_opy_  = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡷࡩࡦࡲࡴࡩࡷࡱࡨࡪࡸࡧࡳࡱࡸࡲࡩ࠭फ")
l11llllll_opy_     = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡲࡸࡹࡧ࡬ࡱࡪࡤࠫब")
l1l11l11l_opy_ = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡊࡱࡧࡷ࡭ࡧࡶࡷ࡙ࡼࠧभ")
l1l1l1ll1_opy_   =  [l1l11l1l1_opy_, l1l11llll_opy_, l1l1111l1_opy_, l1l11ll11_opy_, l1l1111ll_opy_, l1l11lll1_opy_, l11llllll_opy_, l1l11l11l_opy_]
def checkAddons():
    for addon in l1l1l1ll1_opy_:
        if l1l1ll111_opy_(addon):
            createINI(addon)
def l1l1ll111_opy_(addon):
    if xbmc.getCondVisibility(l1l11_opy_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠦࡵࠬࠫम") % addon) == 1:
        return True
    else:
        return False
def createINI(addon):
    HOME = dixie.PROFILE
    PATH = os.path.join(HOME, l1l11_opy_ (u"࠭ࡩ࡯࡫ࠪय"))
    l1111l1l_opy_ = str(addon).split(l1l11_opy_ (u"ࠧ࠯ࠩर"))[2] + l1l11_opy_ (u"ࠨ࠰࡬ࡲ࡮࠭ऱ")
    l1ll1lll1_opy_  = os.path.join(PATH, l1111l1l_opy_)
    response = l111l111_opy_(addon)
    try:
        result = response[l1l11_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩल")]
    except KeyError:
        dixie.log(l1l11_opy_ (u"ࠪ࠱࠲࠳࠭࠮ࠢࡎࡩࡾࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡨࡧࡷࡊ࡮ࡲࡥࡴࠢ࠰࠱࠲࠳࠭ࠡࠩळ") + addon)
        result = {l1l11_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࡶࠫऴ"): [{l1l11_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨव"): l1l11_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࠬश"), l1l11_opy_ (u"ࡵࠨࡶࡼࡴࡪ࠭ष"): l1l11_opy_ (u"ࡶࠩࡸࡲࡰࡴ࡯ࡸࡰࠪस"), l1l11_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࠨह"): l1l11_opy_ (u"ࡸࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾࡸࡹࠩऺ"), l1l11_opy_ (u"ࡹࠬࡲࡡࡣࡧ࡯ࠫऻ"): l1l11_opy_ (u"ࡺ࠭ࡎࡐࠢࡆࡌࡆࡔࡎࡆࡎࡖ़ࠫ")}], l1l11_opy_ (u"ࡻࠧ࡭࡫ࡰ࡭ࡹࡹࠧऽ"): {l1l11_opy_ (u"ࡵࠨࡵࡷࡥࡷࡺࠧा"): 0, l1l11_opy_ (u"ࡶࠩࡷࡳࡹࡧ࡬ࠨि"): 1, l1l11_opy_ (u"ࡷࠪࡩࡳࡪࠧी"): 1}}
    l111111l_opy_ = result[l1l11_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩु")]
    l1l1lllll_opy_  = file(l1ll1lll1_opy_, l1l11_opy_ (u"ࠫࡼ࠭ू"))
    l1l1lllll_opy_.write(l1l11_opy_ (u"ࠬࡡࠧृ"))
    l1l1lllll_opy_.write(addon)
    l1l1lllll_opy_.write(l1l11_opy_ (u"࠭࡝ࠨॄ"))
    l1l1lllll_opy_.write(l1l11_opy_ (u"ࠧ࡝ࡰࠪॅ"))
    l1ll1l1l1_opy_ = []
    for channel in l111111l_opy_:
        if addon == l11llllll_opy_:
            l1l11111l_opy_ = channel[l1l11_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧॆ")].split(l1l11_opy_ (u"ࠩࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭े"), 1)[0].replace(l1l11_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡷࡹ࡫ࡥ࡭ࡤ࡯ࡹࡪࡣࠧै"), l1l11_opy_ (u"ࠫࠬॉ"))
            l1l11111l_opy_ = l1l11111l_opy_.replace(l1l11_opy_ (u"࡛ࠬࡋ࠻ࠢࠪॊ"), l1l11_opy_ (u"࠭ࠧो"))
        else:
            l1l11111l_opy_ = channel[l1l11_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ौ")].split(l1l11_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟्ࠪ"), 1)[0].replace(l1l11_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡺ࡬࡮ࡺࡥ࡞ࠩॎ"), l1l11_opy_ (u"ࠪࠫॏ"))
            l1l11111l_opy_ = l1l11111l_opy_.replace(l1l11_opy_ (u"ࠫࠥࠦࠧॐ"), l1l11_opy_ (u"ࠬ࠭॑"))
            l1l11111l_opy_ = l1l11111l_opy_.replace(l1l11_opy_ (u"࠭ࡕࡌ࠼॒ࠣࠫ"), l1l11_opy_ (u"ࠧࠨ॓"))
            l1l11111l_opy_ = l1l11111l_opy_.replace(l1l11_opy_ (u"ࠨࡗࡖࡅ࠿ࠦࠧ॔"), l1l11_opy_ (u"ࠩࠪॕ"))
            l1l11111l_opy_ = l1l11111l_opy_.replace(l1l11_opy_ (u"ࠪࡇࡆࡀࠠࠨॖ"), l1l11_opy_ (u"ࠫࠬॗ"))
            l1l11111l_opy_ = l1l11111l_opy_.replace(l1l11_opy_ (u"ࠬࡏࡎࡕ࠼ࠣࠫक़"), l1l11_opy_ (u"࠭ࠧख़"))
        l1lll11ll_opy_  = dixie.mapChannelName(l1l11111l_opy_)
        stream = channel[l1l11_opy_ (u"ࠧࡧ࡫࡯ࡩࠬग़")]
        l1llllll1_opy_ = l1lll11ll_opy_ + l1l11_opy_ (u"ࠨ࠿ࠪज़") + stream
        l1ll1l1l1_opy_.append(l1llllll1_opy_)
        l1ll1l1l1_opy_.sort()
    for item in l1ll1l1l1_opy_:
      l1l1lllll_opy_.write(l1l11_opy_ (u"ࠤࠨࡷࡡࡴࠢड़") % item)
    l1l1lllll_opy_.close()
def l111l111_opy_(addon):
    l1l111lll_opy_ = (l1l11_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ढ़") % addon)
    if addon == l1l11lll1_opy_:
        login = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹࡴࡦࡣ࡯ࡸ࡭ࡻ࡮ࡥࡧࡵ࡫ࡷࡵࡵ࡯ࡦ࠲ࡃࡲࡵࡤࡦ࠿ࡪࡩࡳࡸࡥࡴࠨࡳࡳࡷࡺࡡ࡭࠿ࠨ࠻ࡧࠫ࠲࠳ࡰࡤࡱࡪࠫ࠲࠳ࠧ࠶ࡥࠪ࠸࠰ࠦ࠴࠵ࠩ࠺ࡨࡉࠦ࠷ࡧࠩ࠺ࡨࡃࡐࡎࡒࡖࠪ࠸࠰ࡸࡪ࡬ࡸࡪࠫ࠵ࡥࡅ࡯࡭ࡨࡱࠥ࠳࠲ࡗࡳࠪ࠸࠰ࡗ࡫ࡨࡻࠪ࠸࠰ࡕࡪࡨࠩ࠷࠶ࡌࡪࡵࡷࠩ࠷࠶ࡏࡧࠧ࠵࠴ࡈ࡮ࡡ࡯ࡰࡨࡰࡸࠫ࠵ࡣࠧ࠵ࡪࡈࡕࡌࡐࡔࠨ࠹ࡩࠫ࠵ࡣࠧ࠵ࡪࡎࠫ࠵ࡥࠧ࠵࠶ࠪ࠸ࡣࠦ࠴࠳ࠩ࠷࠸ࡰࡢࡴࡨࡲࡹࡧ࡬ࠦ࠴࠵ࠩ࠸ࡧࠥ࠳࠲ࠨ࠶࠷࡬ࡡ࡭ࡵࡨࠩ࠷࠸ࠥ࠳ࡥࠨ࠶࠵ࠫ࠲࠳ࡷࡵࡰࠪ࠸࠲ࠦ࠵ࡤࠩ࠷࠶ࠥ࠳࠴࡫ࡸࡹࡶࠥ࠴ࡣࠨ࠶࡫ࠫ࠲ࡧ࡯ࡺ࠵࠳࡯ࡰࡵࡸ࠹࠺࠳ࡺࡶࠦ࠴࠵ࠩ࠷ࡩࠥ࠳࠲ࠨ࠶࠷ࡶࡰࡢࡵࡶࡻࡴࡸࡤࠦ࠴࠵ࠩ࠸ࡧࠥ࠳࠲ࠨ࠶࠷࠶࠰࠱࠲ࠨ࠶࠷ࠫ࠲ࡤࠧ࠵࠴ࠪ࠸࠲࡮ࡣࡦࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࠫ࠲࠳࠲࠳ࠩ࠸ࡧ࠱ࡂࠧ࠶ࡥ࠼࠾ࠥ࠴ࡣ࠷࠷ࠪ࠹ࡡ࠲࠴ࠨ࠷ࡦ࠽࠴ࠦ࠴࠵ࠩ࠷ࡩࠥ࠳࠲ࠨ࠶࠷ࡹࡥࡳ࡫ࡤࡰࠪ࠸࠲ࠦ࠵ࡤࠩ࠷࠶ࠥ࠸ࡤࠨ࠶࠷ࡹࡥ࡯ࡦࡢࡷࡪࡸࡩࡢ࡮ࠨ࠶࠷ࠫ࠳ࡢࠧ࠵࠴ࡹࡸࡵࡦࠧ࠵ࡧࠪ࠸࠰ࠦ࠴࠵ࡧࡺࡹࡴࡰ࡯ࠨ࠶࠷ࠫ࠳ࡢࠧ࠵࠴ࡹࡸࡵࡦࠧ࠵ࡧࠪ࠸࠰ࠦ࠴࠵ࡷࡳࠫ࠲࠳ࠧ࠶ࡥࠪ࠸࠰ࠦ࠴࠵ࠩ࠷࠸ࠥ࠳ࡥࠨ࠶࠵ࠫ࠲࠳ࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࠫ࠲࠳ࠧ࠵࠶ࠪ࠸ࡣࠦ࠴࠳ࠩ࠷࠸ࡤࡦࡸ࡬ࡧࡪࡥࡩࡥ࠴ࠨ࠶࠷ࠫ࠳ࡢࠧ࠵࠴ࠪ࠸࠲ࠦ࠴࠵ࠩ࠷ࡩࠥ࠳࠲ࠨ࠶࠷ࡪࡥࡷ࡫ࡦࡩࡤ࡯ࡤࠦ࠴࠵ࠩ࠸ࡧࠥ࠳࠲ࠨ࠶࠷ࠫ࠲࠳ࠧ࠺ࡨࠪ࠸ࡣࠦ࠴࠳ࠩ࠷࠸ࡰࡢࡵࡶࡻࡴࡸࡤࠦ࠴࠵ࠩ࠸ࡧࠥ࠳࠲ࡱࡹࡱࡲࠥ࠳ࡥࠨ࠶࠵ࠫ࠲࠳࡮ࡲ࡫࡮ࡴࠥ࠳࠴ࠨ࠷ࡦࠫ࠲࠱ࡰࡸࡰࡱࠫ࠷ࡥࠩफ़")
    else:
        login = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨय़") + addon + l1l11_opy_ (u"࠭࠯ࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡵࡨࡧࡺࡸࡩࡵࡻࡢࡧ࡭࡫ࡣ࡬ࠨࡨࡼࡹࡸࡡࠧࡲࡤ࡫ࡪࠬࡰ࡭ࡱࡷࠪࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠦࡵ࡫ࡷࡰࡪࡃࡌࡪࡸࡨࠩ࠷࠶ࡔࡗࠨࡸࡶࡱ࠭ॠ")
    query = l1l1l111l_opy_(addon)
    l1l111l11_opy_ = (l1l11_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪॡ") % login)
    l1l111l1l_opy_ = (l1l11_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫॢ") % query)
    try:
        xbmc.executeJSONRPC(l1l111lll_opy_)
        if addon != l1l111ll1_opy_:
            xbmc.executeJSONRPC(l1l111l11_opy_)
        response = xbmc.executeJSONRPC(l1l111l1l_opy_)
        content  = json.loads(response.decode(l1l11_opy_ (u"ࠩࡸࡸ࡫࠳࠸ࠨॣ"), l1l11_opy_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪ।")))
        return content
    except:
        dixie.log(l1l11_opy_ (u"ࠫ࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲ࠦࡐ࡭ࡷࡪ࡭ࡳࠦࡅࡳࡴࡲࡶࠥ࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳ࠧ॥"))
        return {l1l11_opy_ (u"ࠬࡋࡲࡳࡱࡵࠫ०") : l1l11_opy_ (u"࠭ࡐ࡭ࡷࡪ࡭ࡳࠦࡅࡳࡴࡲࡶࠬ१")}
def l1l1l111l_opy_(addon):
    if addon == l1l11l11l_opy_:
        return l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡈ࡯ࡥࡼࡲࡥࡴࡵࡗࡺ࠴ࡅࡡࡤࡶ࡬ࡳࡳࡃࡳࡵࡴࡨࡥࡲࡥࡶࡪࡦࡨࡳࠫ࡫ࡸࡵࡴࡤࠪࡵࡧࡧࡦࠨࡳࡰࡴࡺࠦࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡀࠪࡹ࡯ࡴ࡭ࡧࡀࡅࡱࡲࠦࡶࡴ࡯ࡁ࠵࠭२")
    if addon == l1l111ll1_opy_:
        return l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧࡩࡱࡶࡹ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡲࡩࡷࡧࡷࡺࡤࡧ࡬࡭ࠨࡨࡼࡹࡸࡡࠧࡲࡤ࡫ࡪࠬࡰ࡭ࡱࡷࠪࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠽ࠦ࠴ࡩ࡙ࡸ࡫ࡲࡴࠧ࠵ࡪࡷ࡯ࡣࡩࡣࡵࡨࠪ࠸ࡦࡍ࡫ࡥࡶࡦࡸࡹࠦ࠴ࡩࡅࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮ࠦ࠴࠳ࡗࡺࡶࡰࡰࡴࡷࠩ࠷࡬ࡋࡰࡦ࡬ࠩ࠷࡬ࡡࡥࡦࡲࡲࡸࠫ࠲ࡧࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲࡷࡺࡸࡻࡢࡴ࠴࠱࠸ࠪ࠸ࡦࡳࡧࡶࡳࡺࡸࡣࡦࡵࠨ࠶࡫࡯࡭ࡨࠧ࠵ࡪ࡭ࡵࡴ࠯ࡲࡱ࡫ࠫࡺࡩࡵ࡮ࡨࡁࡆࡲ࡬ࠦ࠴࠳ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡻࡲ࡭ࠩ३")
    if addon == l1l1111l1_opy_:
        return l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡵࡺ࡯ࡣ࡬࡫ࡳࡸࡻ࠵࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࡴࡶࡵࡩࡦࡳ࡟ࡷ࡫ࡧࡩࡴࠬࡥࡹࡶࡵࡥࠫࡶࡡࡨࡧࠩࡴࡱࡵࡴࠧࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡁࠫࡺࡩࡵ࡮ࡨࡁࡆࡲ࡬ࠧࡷࡵࡰࡂ࠶ࠧ४")
    if addon == l1l11ll11_opy_:
        return l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡫ࡻࡴࡶࡴࡨࡷࡹࡸࡥࡢ࡯ࡶ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡹࡴࡳࡧࡤࡱࡤࡼࡩࡥࡧࡲࠪࡪࡾࡴࡳࡣࠩࡴࡦ࡭ࡥࠧࡲ࡯ࡳࡹࠬࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠿ࠩࡸ࡮ࡺ࡬ࡦ࠿ࡄࡰࡱࠬࡵࡳ࡮ࡀ࠴ࠬ५")
    if addon == l1l11lll1_opy_:
        return l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹࡴࡦࡣ࡯ࡸ࡭ࡻ࡮ࡥࡧࡵ࡫ࡷࡵࡵ࡯ࡦ࠲ࡃ࡬࡫࡮ࡳࡧࡢࡲࡦࡳࡥ࠾ࡃ࡯ࡰࠫࡶ࡯ࡳࡶࡤࡰࡂࠫ࠷ࡃࠧ࠵࠶ࡳࡧ࡭ࡦࠧ࠵࠶ࠪ࠹ࡁࠬࠧ࠵࠶ࠪ࠻ࡂࡊࠧ࠸ࡈࠪ࠻ࡂࡄࡑࡏࡓࡗ࠱ࡷࡩ࡫ࡷࡩࠪ࠻ࡄࡄ࡮࡬ࡧࡰ࠱ࡔࡰ࡙࠭࡭ࡪࡽࠫࡕࡪࡨ࠯ࡑ࡯ࡳࡵ࠭ࡒࡪ࠰ࡉࡨࡢࡰࡱࡩࡱࡹࠥ࠶ࡄࠨ࠶ࡋࡉࡏࡍࡑࡕࠩ࠺ࡊࠥ࠶ࡄࠨ࠶ࡋࡏࠥ࠶ࡆࠨ࠶࠷ࠫ࠲ࡄ࠭ࠨ࠶࠷ࡶࡡࡳࡧࡱࡸࡦࡲࠥ࠳࠴ࠨ࠷ࡆ࠱ࠥ࠳࠴ࡩࡥࡱࡹࡥࠦ࠴࠵ࠩ࠷ࡉࠫࠦ࠴࠵ࡹࡷࡲࠥ࠳࠴ࠨ࠷ࡆ࠱ࠥ࠳࠴࡫ࡸࡹࡶࠥ࠴ࡃࠨ࠶ࡋࠫ࠲ࡇ࡯ࡺ࠵࠳࡯ࡰࡵࡸ࠹࠺࠳ࡺࡶࠦ࠴࠵ࠩ࠷ࡉࠫࠦ࠴࠵ࡴࡵࡧࡳࡴࡹࡲࡶࡩࠫ࠲࠳ࠧ࠶ࡅ࠰ࠫ࠲࠳࠲࠳࠴࠵ࠫ࠲࠳ࠧ࠵ࡇ࠰ࠫ࠲࠳࡯ࡤࡧࠪ࠸࠲ࠦ࠵ࡄ࠯ࠪ࠸࠲࠱࠲ࠨ࠷ࡆ࠷ࡁࠦ࠵ࡄ࠻࠽ࠫ࠳ࡂ࠶࠶ࠩ࠸ࡇ࠱࠳ࠧ࠶ࡅ࠼࠺ࠥ࠳࠴ࠨ࠶ࡈ࠱ࠥ࠳࠴ࡶࡩࡷ࡯ࡡ࡭ࠧ࠵࠶ࠪ࠹ࡁࠬࠧ࠺ࡆࠪ࠸࠲ࡴࡧࡱࡨࡤࡹࡥࡳ࡫ࡤࡰࠪ࠸࠲ࠦ࠵ࡄ࠯ࡹࡸࡵࡦࠧ࠵ࡇ࠰ࠫ࠲࠳ࡥࡸࡷࡹࡵ࡭ࠦ࠴࠵ࠩ࠸ࡇࠫࡵࡴࡸࡩࠪ࠸ࡃࠬࠧ࠵࠶ࡸࡴࠥ࠳࠴ࠨ࠷ࡆ࠱ࠥ࠳࠴ࠨ࠶࠷ࠫ࠲ࡄ࠭ࠨ࠶࠷ࡹࡩࡨࡰࡤࡸࡺࡸࡥࠦ࠴࠵ࠩ࠸ࡇࠫࠦ࠴࠵ࠩ࠷࠸ࠥ࠳ࡅ࠮ࠩ࠷࠸ࡤࡦࡸ࡬ࡧࡪࡥࡩࡥ࠴ࠨ࠶࠷ࠫ࠳ࡂ࠭ࠨ࠶࠷ࠫ࠲࠳ࠧ࠵ࡇ࠰ࠫ࠲࠳ࡦࡨࡺ࡮ࡩࡥࡠ࡫ࡧࠩ࠷࠸ࠥ࠴ࡃ࠮ࠩ࠷࠸ࠥ࠳࠴ࠨ࠻ࡉࠫ࠲ࡄ࠭ࠨ࠶࠷ࡶࡡࡴࡵࡺࡳࡷࡪࠥ࠳࠴ࠨ࠷ࡆ࠱࡮ࡶ࡮࡯ࠩ࠷ࡉࠫࠦ࠴࠵ࡰࡴ࡭ࡩ࡯ࠧ࠵࠶ࠪ࠹ࡁࠬࡰࡸࡰࡱࠫ࠷ࡅࠨࡰࡳࡩ࡫࠽ࡤࡪࡤࡲࡳ࡫࡬ࡴࠨࡪࡩࡳࡸࡥࡠ࡫ࡧࡁࠪ࠸ࡁࠨ६")
    else:
        Addon = xbmcaddon.Addon(addon)
        if addon == l11llllll_opy_:
            username =  Addon.getSetting(l1l11_opy_ (u"࡛ࠬࡳࡦࡴࡱࡥࡲ࡫ࠧ७"))
            password =  Addon.getSetting(l1l11_opy_ (u"࠭ࡐࡢࡵࡶࡻࡴࡸࡤࠨ८"))
        else:
            username =  Addon.getSetting(l1l11_opy_ (u"ࠧ࡬ࡣࡶࡹࡹࡧࡪࡢࡰ࡬ࡱ࡮࠭९"))
            password =  Addon.getSetting(l1l11_opy_ (u"ࠨࡵࡤࡰࡦࡹ࡯࡯ࡣࠪ॰"))
        l11lllll1_opy_     = l1l11_opy_ (u"ࠩ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡸࡺࡲࡦࡣࡰࡣࡻ࡯ࡤࡦࡱࠩࡩࡽࡺࡲࡢࠨࡳࡥ࡬࡫ࠦࡱ࡮ࡲࡸࠫࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠾ࠨࡷ࡭ࡹࡲࡥ࠾ࡃ࡯ࡰࠫࡻࡲ࡭࠿ࠪॱ")
        l1lll111l_opy_  =  l1111lll_opy_(addon)
        l1l1llll1_opy_   = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭ॲ") + addon
        l1l11l1ll_opy_  =  l1l1llll1_opy_ + l11lllll1_opy_ + l1lll111l_opy_
        l1l1l1111_opy_ = l1l11_opy_ (u"ࠫࡺࡹࡥࡳࡰࡤࡱࡪࡃࠧॳ") + username + l1l11_opy_ (u"ࠬࠬࡰࡢࡵࡶࡻࡴࡸࡤ࠾ࠩॴ") + password + l1l11_opy_ (u"࠭ࠦࡵࡻࡳࡩࡂ࡭ࡥࡵࡡ࡯࡭ࡻ࡫࡟ࡴࡶࡵࡩࡦࡳࡳࠧࡥࡤࡸࡤ࡯ࡤ࠾࠲ࠪॵ")
        return l1l11l1ll_opy_ + urllib.quote_plus(l1l1l1111_opy_)
def l1111lll_opy_(addon):
    if (addon == l1l11l1l1_opy_) or (addon == l1l11llll_opy_):
        return l1l11_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠴࠹࠱࠵࠽࠽࠮࠲࠵࠼࠲࠶࠻࠵࠻࠺࠳࠴࠵࠵ࡥ࡯࡫ࡪࡱࡦ࠸࠮ࡱࡪࡳࡃࠬॶ")
    if addon == l1l1111ll_opy_:
        return l1l11_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡳ࡭ࡳࢀࡴࡷࡲࡵࡳ࠳ࡺ࡫࠻࠺࠳࠴࠵࠵ࡥ࡯࡫ࡪࡱࡦ࠸࠮ࡱࡪࡳࡃࠬॷ")
    if addon == l11llllll_opy_:
        return l1l11_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡲࡸࡹࡺࡶ࠯ࡩࡤ࠾࠷࠶࠹࠶࠱ࡨࡲ࡮࡭࡭ࡢ࠴࠱ࡴ࡭ࡶ࠿ࠨॸ")
def l1l111111_opy_(addon, l1lll11ll_opy_):
    if (addon == l1l11l1l1_opy_) or (addon == l1l11llll_opy_):
        l1lll11ll_opy_ = l1lll11ll_opy_.replace(l1l11_opy_ (u"ࠪࠤࠥ࠭ॹ"), l1l11_opy_ (u"ࠫࠥ࠭ॺ")).replace(l1l11_opy_ (u"࡛ࠬࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨॻ"), l1l11_opy_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨॼ"))
        return l1lll11ll_opy_
    return l1lll11ll_opy_
def l1l11l111_opy_(addon, l1l11ll1l_opy_):
    if (addon == l1l11l1l1_opy_) or (addon == l1l11llll_opy_):
        channel = l1l11ll1l_opy_.rsplit(l1l11_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩॽ"), 1)[0].split(l1l11_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡹ࡫࡭ࡹ࡫࡝ࠨॾ"), 1)[-1]
        channel = channel.replace(l1l11_opy_ (u"ࠩࡅࡆࡈࠦ࠱ࠨॿ"), l1l11_opy_ (u"ࠪࡆࡇࡉࠠࡐࡰࡨࠫঀ")).replace(l1l11_opy_ (u"ࠫࡇࡈࡃࠡ࠴ࠪঁ"), l1l11_opy_ (u"ࠬࡈࡂࡄࠢࡗࡻࡴ࠭ং")).replace(l1l11_opy_ (u"࠭ࡂࡃࡅࠣ࠸ࠬঃ"), l1l11_opy_ (u"ࠧࡃࡄࡆࠤࡋࡕࡕࡓࠩ঄")).replace(l1l11_opy_ (u"ࠨࡋࡗ࡚ࠥ࠷ࠧঅ"), l1l11_opy_ (u"ࠩࡌࡘ࡛࠷ࠧআ")).replace(l1l11_opy_ (u"ࠪࡍ࡙࡜ࠠ࠳ࠩই"), l1l11_opy_ (u"ࠫࡎ࡚ࡖ࠳ࠩঈ")).replace(l1l11_opy_ (u"ࠬࡏࡔࡗࠢ࠶ࠫউ"), l1l11_opy_ (u"࠭ࡉࡕࡘ࠶ࠫঊ")).replace(l1l11_opy_ (u"ࠧࡊࡖ࡙ࠤ࠹࠭ঋ"), l1l11_opy_ (u"ࠨࡋࡗ࡚࠹࠭ঌ"))
        return channel
    if (addon == l1l1111l1_opy_) or (addon == l1l11ll11_opy_):
        channel = l1l11ll1l_opy_.rsplit(l1l11_opy_ (u"ࠩࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ঍"))[0].replace(l1l11_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡻ࡭࡯ࡴࡦ࡟ࠪ঎"), l1l11_opy_ (u"ࠫࠬএ"))
        channel = channel.replace(l1l11_opy_ (u"ࠬࡀࠧঐ"), l1l11_opy_ (u"࠭ࠧ঑")).replace(l1l11_opy_ (u"ࠧࡃࡄࡆࠤ࠶࠭঒"), l1l11_opy_ (u"ࠨࡄࡅࡇࠥࡕ࡮ࡦࠩও")).replace(l1l11_opy_ (u"ࠩࡅࡆࡈࠦ࠲ࠨঔ"), l1l11_opy_ (u"ࠪࡆࡇࡉࠠࡕࡹࡲࠫক")).replace(l1l11_opy_ (u"ࠫࡇࡈࡃࠡ࠶ࠪখ"), l1l11_opy_ (u"ࠬࡈࡂࡄࠢࡉࡓ࡚ࡘࠧগ")).replace(l1l11_opy_ (u"࠭ࡉࡕࡘࠣ࠵ࠬঘ"), l1l11_opy_ (u"ࠧࡊࡖ࡙࠵ࠬঙ")).replace(l1l11_opy_ (u"ࠨࡋࡗ࡚ࠥ࠸ࠧচ"), l1l11_opy_ (u"ࠩࡌࡘ࡛࠸ࠧছ")).replace(l1l11_opy_ (u"ࠪࡍ࡙࡜ࠠ࠴ࠩজ"), l1l11_opy_ (u"ࠫࡎ࡚ࡖ࠴ࠩঝ")).replace(l1l11_opy_ (u"ࠬࡏࡔࡗࠢ࠷ࠫঞ"), l1l11_opy_ (u"࠭ࡉࡕࡘ࠷ࠫট"))
        return channel
    else:
        channel = l1l11ll1l_opy_.replace(l1l11_opy_ (u"ࠧࡃࡄࡆࠤ࠶࠭ঠ"), l1l11_opy_ (u"ࠨࡄࡅࡇࠥࡕ࡮ࡦࠩড")).replace(l1l11_opy_ (u"ࠩࡅࡆࡈࠦ࠲ࠨঢ"), l1l11_opy_ (u"ࠪࡆࡇࡉࠠࡕࡹࡲࠫণ")).replace(l1l11_opy_ (u"ࠫࡇࡈࡃࠡ࠶ࠪত"), l1l11_opy_ (u"ࠬࡈࡂࡄࠢࡉࡓ࡚ࡘࠧথ")).replace(l1l11_opy_ (u"࠭ࡉࡕࡘࠣ࠵ࠬদ"), l1l11_opy_ (u"ࠧࡊࡖ࡙࠵ࠬধ")).replace(l1l11_opy_ (u"ࠨࡋࡗ࡚ࠥ࠸ࠧন"), l1l11_opy_ (u"ࠩࡌࡘ࡛࠸ࠧ঩")).replace(l1l11_opy_ (u"ࠪࡍ࡙࡜ࠠ࠴ࠩপ"), l1l11_opy_ (u"ࠫࡎ࡚ࡖ࠴ࠩফ")).replace(l1l11_opy_ (u"ࠬࡏࡔࡗࠢ࠷ࠫব"), l1l11_opy_ (u"࠭ࡉࡕࡘ࠷ࠫভ"))
        return channel
def l1ll1111l_opy_(e):
    l1lll1l11_opy_ = l1l11_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠲ࠠࡢࡰࠣࡩࡷࡸ࡯ࡳࠢࡲࡧࡨࡻࡲࡦࡦ࠽ࠤࡏ࡙ࡏࡏࠢࡈࡶࡷࡵࡲ࠻ࠢࠨࡷࠬম")  %e
    l1lllll11_opy_ = l1l11_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡥࡲࡲࡹࡧࡣࡵࠢࡸࡷࠥࡵ࡮ࠡࡶ࡫ࡩࠥ࡬࡯ࡳࡷࡰ࠲ࠬয")
    l1lll1ll1_opy_ = l1l11_opy_ (u"ࠩࡘࡴࡱࡵࡡࡥࠢࡤࠤࡱࡵࡧࠡࡸ࡬ࡥࠥࡺࡨࡦࠢࡤࡨࡩࡵ࡮ࠡࡵࡨࡸࡹ࡯࡮ࡨࡵࠣࡥࡳࡪࠠࡱࡱࡶࡸࠥࡺࡨࡦࠢ࡯࡭ࡳࡱ࠮ࠨর")
    dixie.log(e)
    dixie.DialogOK(l1lll1l11_opy_, l1lllll11_opy_, l1lll1ll1_opy_)
    dixie.SetSetting(SETTING, l1l11_opy_ (u"ࠪࠫ঱"))