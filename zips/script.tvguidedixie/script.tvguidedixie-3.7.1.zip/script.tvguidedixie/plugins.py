# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l1lll1_opy_ = 2048
l111_opy_ = 7
def l111l_opy_ (ll_opy_):
	global l1llll_opy_
	l1l111_opy_ = ord (ll_opy_ [-1])
	l11l1_opy_ = ll_opy_ [:-1]
	l1l_opy_ = l1l111_opy_ % len (l11l1_opy_)
	l11_opy_ = l11l1_opy_ [:l1l_opy_] + l11l1_opy_ [l1l_opy_:]
	if l1_opy_:
		l1ll1l_opy_ = unicode () .join ([unichr (ord (char) - l1lll1_opy_ - (l11ll_opy_ + l1l111_opy_) % l111_opy_) for l11ll_opy_, char in enumerate (l11_opy_)])
	else:
		l1ll1l_opy_ = str () .join ([chr (ord (char) - l1lll1_opy_ - (l11ll_opy_ + l1l111_opy_) % l111_opy_) for l11ll_opy_, char in enumerate (l11_opy_)])
	return eval (l1ll1l_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l1ll11l11_opy_    = l111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡱࡸࡻ࠭ࢄ")
l1ll1llll_opy_    = l111l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡹࡰࡺࡵࡳ࡭ࠪࢅ")
locked = l111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡱࡵࡣ࡬ࡧࡧࡸࡻ࠭ࢆ")
l1lll1lll_opy_   = l111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹࡴࡳࡧࡤࡱࡹࡼࡢࡰࡺࠪࢇ")
l1lll1111_opy_     = l111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡱࡱࡵࡸࡸࡳࡡ࡯࡫ࡤࠫ࢈")
l1lll1ll1_opy_     = l111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡲࡲࡶࡹࡹ࡮ࡢࡶ࡬ࡳࡳ࡮ࡤࡵࡸࠪࢉ")
l1l1ll1ll_opy_     = l111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡷ࡯ࡸ࡮ࡳࡡࡵࡧࡰࡥࡳ࡯ࡡࠨࢊ")
l1l1l11ll_opy_   = l111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡯࡭ࡺࡾ࠮ࡵࡸࠪࢋ")
l1ll1111l_opy_    = l111l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡈࡈ࡙ࡰࡰࡴࡷࡷࠬࢌ")
l1ll1lll1_opy_ = l111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷ࡫ࡢࡰࡱࡷࠫࢍ")
l1ll1l1ll_opy_    = l111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡩ࡬ࡶ࡫ࡳࡸࡻ࠭ࢎ")
l1l1l1l1l_opy_ = [l1ll1llll_opy_, l1ll11l11_opy_, l1l1l11ll_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l111l_opy_ (u"ࠧࡪࡰ࡬ࠫ࢏"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1l1l1_opy_ = l111l_opy_ (u"ࠨࠩ࢐")
def l11l1l_opy_(i, t1, l1l11l_opy_=[]):
 t = l1l1l1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l11l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1ll_opy_ = l11l1l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l1l1_opy_ = l11l1l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    if not l11l_opy_() == l111l_opy_ (u"ࠩࡗࡶࡺ࡫ࠧ࢑"):
        return
    for addon in l1l1l1l1l_opy_:
        if l1l1l1lll_opy_(addon):
            try: l1ll1l1l1_opy_(addon)
            except: pass
def l1l1l1lll_opy_(addon):
    if xbmc.getCondVisibility(l111l_opy_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡌࡦࡹࡁࡥࡦࡲࡲ࠭ࠫࡳࠪࠩ࢒") % addon) == 1:
        return True
    return False
def l1ll1l1l1_opy_(addon):
    l1lll1l11_opy_ = str(addon).split(l111l_opy_ (u"ࠫ࠳࠭࢓"))[2] + l111l_opy_ (u"ࠬ࠴ࡩ࡯࡫ࠪ࢔")
    l1ll1l11l_opy_  = os.path.join(PATH, l1lll1l11_opy_)
    l1lll1l1l_opy_ = l1llll11l_opy_(addon)
    l1l1lllll_opy_  = file(l1ll1l11l_opy_, l111l_opy_ (u"࠭ࡷࠨ࢕"))
    l1l1lllll_opy_.write(l111l_opy_ (u"ࠧ࡜ࠩ࢖"))
    l1l1lllll_opy_.write(addon)
    l1l1lllll_opy_.write(l111l_opy_ (u"ࠨ࡟ࠪࢗ"))
    l1l1lllll_opy_.write(l111l_opy_ (u"ࠩ࡟ࡲࠬ࢘"))
    for channel in l1lll1l1l_opy_:
        l1l11_opy_  = channel[l111l_opy_ (u"ࠪࡰࡦࡨࡥ࡭࢙ࠩ")]
        l1l11_opy_  = l1l11_opy_.replace(l111l_opy_ (u"ࠫ࠳࠴࠮࠯࠰࢚ࠪ"), l111l_opy_ (u"࢛ࠬ࠭")).replace(l111l_opy_ (u"࠭࠺ࠨ࢜"), l111l_opy_ (u"ࠧࠨ࢝")).replace(l111l_opy_ (u"ࠨࠢ࡞ࠫ࢞"), l111l_opy_ (u"ࠩ࡞ࠫ࢟")).replace(l111l_opy_ (u"ࠪࡡࠥ࠭ࢠ"), l111l_opy_ (u"ࠫࡢ࠭ࢡ")).replace(l111l_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡧࡱࡶࡣࡠࠫࢢ"), l111l_opy_ (u"࠭ࠧࢣ")).replace(l111l_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠ࡭࡫ࡰࡩ࡬ࡸࡥࡦࡰࡠࠫࢤ"), l111l_opy_ (u"ࠨࠩࢥ")).replace(l111l_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡪࡶࡪ࡫࡮࡞ࠩࢦ"), l111l_opy_ (u"ࠪࠫࢧ")).replace(l111l_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡾ࡫࡬࡭ࡱࡺࡡࠬࢨ"), l111l_opy_ (u"ࠬ࠭ࢩ")).replace(l111l_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࠬࢪ"), l111l_opy_ (u"ࠧࠨࢫ")).replace(l111l_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡱࡵࡥࡳ࡭ࡥ࡞ࠩࢬ"), l111l_opy_ (u"ࠩࠪࢭ")).replace(l111l_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࠨࢮ"), l111l_opy_ (u"ࠫࠬࢯ")).replace(l111l_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡽࡨࡪࡶࡨࡡࠬࢰ"), l111l_opy_ (u"࠭ࠧࢱ")).replace(l111l_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࢲ"), l111l_opy_ (u"ࠨࠩࢳ")).replace(l111l_opy_ (u"ࠩ࡞ࡍࡢ࠭ࢴ"), l111l_opy_ (u"ࠪࠫࢵ")).replace(l111l_opy_ (u"ࠫࡠ࠵ࡉ࡞ࠩࢶ"), l111l_opy_ (u"ࠬ࠭ࢷ")).replace(l111l_opy_ (u"࡛࠭ࡃ࡟ࠪࢸ"), l111l_opy_ (u"ࠧࠨࢹ")).replace(l111l_opy_ (u"ࠨ࡝࠲ࡆࡢ࠭ࢺ"), l111l_opy_ (u"ࠩࠪࢻ"))
        stream = channel[l111l_opy_ (u"ࠪࡪ࡮ࡲࡥࠨࢼ")]
        l1l1lllll_opy_.write(l111l_opy_ (u"ࠫࠪࡹࠧࢽ") % l1l11_opy_)
        l1l1lllll_opy_.write(l111l_opy_ (u"ࠬࡃࠧࢾ"))
        l1l1lllll_opy_.write(l111l_opy_ (u"࠭ࠥࡴࠩࢿ") % stream)
        l1l1lllll_opy_.write(l111l_opy_ (u"ࠧ࡝ࡰࠪࣀ"))
    l1l1lllll_opy_.write(l111l_opy_ (u"ࠨ࡞ࡱࠫࣁ"))
    l1l1lllll_opy_.close()
def l1llll11l_opy_(addon):
    if addon == l1ll1llll_opy_:
        return l1ll111ll_opy_(addon)
    if addon == l1ll1111l_opy_:
        return l1lll11ll_opy_(addon)
    try:
        if xbmcaddon.Addon(addon).getSetting(l111l_opy_ (u"ࠩࡪࡩࡳࡸࡥࠨࣂ")) == l111l_opy_ (u"ࠪࡸࡷࡻࡥࠨࣃ"):
            xbmcaddon.Addon(addon).setSetting(l111l_opy_ (u"ࠫ࡬࡫࡮ࡳࡧࠪࣄ"), l111l_opy_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫࣅ"))
            xbmcgui.Window(10000).setProperty(l111l_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡇࡆࡐࡕࡉࠬࣆ"), l111l_opy_ (u"ࠧࡕࡴࡸࡩࠬࣇ"))
        if xbmcaddon.Addon(addon).getSetting(l111l_opy_ (u"ࠨࡶࡹ࡫ࡺ࡯ࡤࡦࠩࣈ")) == l111l_opy_ (u"ࠩࡷࡶࡺ࡫ࠧࣉ"):
            xbmcaddon.Addon(addon).setSetting(l111l_opy_ (u"ࠪࡸࡻ࡭ࡵࡪࡦࡨࠫ࣊"), l111l_opy_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪ࣋"))
            xbmcgui.Window(10000).setProperty(l111l_opy_ (u"ࠬࡖࡌࡖࡉࡌࡒࡤ࡚ࡖࡈࡗࡌࡈࡊ࠭࣌"), l111l_opy_ (u"࠭ࡔࡳࡷࡨࠫ࣍"))
    except: pass
    l1l1llll1_opy_  = l111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ࣎") + addon
    l1ll1ll11_opy_ =  l1llll111_opy_(addon)
    query   =  l1l1llll1_opy_ + l1ll1ll11_opy_
    return sendJSON(query, addon)
def l1l1ll1l1_opy_(addon):
    l1ll11l1l_opy_   =  []
    query    = l111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲࣏ࠫ") + addon
    response =  sendJSON(query, addon)
    for item in response:
        if not l111l_opy_ (u"ࠩ࠱࣐ࠫ") in item[l111l_opy_ (u"ࠪࡰࡦࡨࡥ࡭࣑ࠩ")]:
            l1ll11l1l_opy_.append(item[l111l_opy_ (u"ࠫ࡫࡯࡬ࡦ࣒ࠩ")])
    l1111_opy_ = []
    for l1ll111l1_opy_ in l1ll11l1l_opy_:
        response = sendJSON(l1ll111l1_opy_, addon)
        l1111_opy_.extend(response)
    return l1111_opy_
def l1ll111ll_opy_(addon):
    l1l1llll1_opy_ = l111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ࣓") + addon
    l1l1l11l1_opy_  = l111l_opy_ (u"࠭࠿ࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࡪࡷࡸࡵࠫ࠳ࡢࠧ࠵ࡪࠪ࠸ࡦ࡮ࡧࡷࡥࡱࡱࡥࡵࡶ࡯ࡩ࠳ࡩ࡯ࠦ࠴ࡩ࡙ࡐ࡚ࡵࡳ࡭࠴࠼࠵࠸࠲࠱࠳࠹ࠩ࠷࡬ࡴࡩࡷࡰࡦࡸࠫ࠲ࡧࡰࡨࡻࠪ࠸ࡦࡖ࡭ࠨ࠶࠺࠸࠰ࡵࡷࡵ࡯ࠪ࠸࠵࠳࠲ࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸࠫ࠲࠶࠴࠳ࡰ࡮ࡼࡥࠦ࠴࠸࠶࠵ࡺࡶ࠯࡬ࡳ࡫ࠫࡳ࡯ࡥࡧࡀ࠵ࠫࡴࡡ࡮ࡧࡀࡐ࡮ࡼࡥࠦ࠴࠳ࡘ࡛ࠬࡵࡳ࡮ࡀ࡬ࡹࡺࡰࠦ࠵ࡤࠩ࠷࡬ࠥ࠳ࡨࡰࡩࡹࡧ࡬࡬ࡧࡷࡸࡱ࡫࠮ࡤࡱࠨ࠶࡫࡛ࡋࡕࡷࡵ࡯࠶࠾࠰࠳࠴࠳࠵࠻ࠫ࠲ࡧࡎ࡬ࡺࡪࠫ࠲࠶࠴࠳ࡘ࡛࠴ࡴࡹࡶࠪࣔ")
    l1111_opy_  = []
    l1111_opy_ += sendJSON(l1l1llll1_opy_ + l1l1l11l1_opy_, addon)
    l1111_opy_.sort()
    return l1111_opy_
def l1lll11ll_opy_(addon):
    l1l1llll1_opy_ = l111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪࣕ") + addon
    l1l1l11l1_opy_ = l111l_opy_ (u"ࠨ࠱ࡂࡪࡦࡴࡡࡳࡶࡀ࡬ࡹࡺࡰࠦ࠵ࡤࠩ࠷࡬ࠥ࠳ࡨࡪࡳࡴ࠴ࡧ࡭ࠧ࠵ࡪ࡝ࡪࡆ࠳࠺ࡗࠪࡲࡵࡤࡦ࠿࠴ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡻ࡫ࠥ࠳࠲ࡘࡏࠪ࠸࠰ࡔࡲࡲࡶࡹࡹࠦࡶࡴ࡯ࡁ࡭ࡺࡴࡱࡵࠨ࠷ࡦࠫ࠲ࡧࠧ࠵ࡪ࡬ࡵ࡯࠯ࡩ࡯ࠩ࠷࡬࠵ࡲࡓࡪࡉ࠹࠭ࣖ")
    l1l1l1l11_opy_ = l111l_opy_ (u"ࠩ࠲ࡃ࡫ࡧ࡮ࡢࡴࡷࡁ࡭ࡺࡴࡱࡵࠨ࠷ࡦࠫ࠲ࡧࠧ࠵ࡪ࡬ࡵ࡯࠯ࡩ࡯ࠩ࠷࡬ࡆࡨ࡙ࡐ࡯࡟ࠬ࡭ࡰࡦࡨࡁ࠶ࠬ࡮ࡢ࡯ࡨࡁࡑ࡯ࡶࡦࠧ࠵࠴࡚࡙ࠥ࠳ࡨࡆࡅࡓࠫ࠲࠱ࡕࡳࡳࡷࡺࡳࠧࡷࡵࡰࡂ࡮ࡴࡵࡲࡶࠩ࠸ࡧࠥ࠳ࡨࠨ࠶࡫࡭࡯ࡰ࠰ࡪࡰࠪ࠸ࡦࡧ࠻࡭࡫࠽ࡔࠧࣗ")
    l1111_opy_  = []
    l1111_opy_ += sendJSON(l1l1llll1_opy_ + l1l1l11l1_opy_, addon)
    l1111_opy_ += sendJSON(l1l1llll1_opy_ + l1l1l1l11_opy_, addon)
    return l1111_opy_
def l1llll111_opy_(addon):
    if addon == l1ll11l11_opy_:
        return l111l_opy_ (u"ࠪ࠳ࡄࡩࡡࡵ࠿࠰࠶ࠫࡳ࡯ࡥࡧࡀ࠶ࠫࡴࡡ࡮ࡧࡀࡑࡾࠫ࠲࠱ࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠩࡹࡷࡲ࠽ࡶࡴ࡯ࠫࣘ")
    return l111l_opy_ (u"ࠫࠬࣙ")
def l11l_opy_():
    modules = map(__import__, [l11l1l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1ll_opy_)):
        return l111l_opy_ (u"࡚ࠬࡲࡶࡧࠪࣚ")
    if len(modules[-1].Window(10**4).getProperty(l1l1_opy_)):
        return l111l_opy_ (u"࠭ࡔࡳࡷࡨࠫࣛ")
    return l111l_opy_ (u"ࠧࡇࡣ࡯ࡷࡪ࠭ࣜ")
def sendJSON(query, addon):
    try:
        l1ll1ll1l_opy_     = l111l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࣝ") % query
        l1ll11ll1_opy_  = xbmc.executeJSONRPC(l1ll1ll1l_opy_)
        response = json.loads(l1ll11ll1_opy_)
        if xbmcgui.Window(10000).getProperty(l111l_opy_ (u"ࠩࡓࡐ࡚ࡍࡉࡏࡡࡊࡉࡓࡘࡅࠨࣞ")) == l111l_opy_ (u"ࠪࡘࡷࡻࡥࠨࣟ"):
            xbmcaddon.Addon(addon).setSetting(l111l_opy_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ࣠"), l111l_opy_ (u"ࠬࡺࡲࡶࡧࠪ࣡"))
            xbmcgui.Window(10000).clearProperty(l111l_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡇࡆࡐࡕࡉࠬ࣢"))
        if xbmcgui.Window(10000).getProperty(l111l_opy_ (u"ࠧࡑࡎࡘࡋࡎࡔ࡟ࡕࡘࡊ࡙ࡎࡊࡅࠨࣣ")) == l111l_opy_ (u"ࠨࡖࡵࡹࡪ࠭ࣤ"):
            xbmcaddon.Addon(addon).setSetting(l111l_opy_ (u"ࠩࡷࡺ࡬ࡻࡩࡥࡧࠪࣥ"), l111l_opy_ (u"ࠪࡸࡷࡻࡥࠨࣦ"))
            xbmcgui.Window(10000).clearProperty(l111l_opy_ (u"ࠫࡕࡒࡕࡈࡋࡑࡣ࡙࡜ࡇࡖࡋࡇࡉࠬࣧ"))
        return response[l111l_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬࣨ")][l111l_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࣩࠬ")]
    except Exception as e:
        l1ll11_opy_(e, addon)
        return {l111l_opy_ (u"ࠧࡆࡴࡵࡳࡷ࠭࣪") : l111l_opy_ (u"ࠨࡒ࡯ࡹ࡬࡯࡮ࠡࡇࡵࡶࡴࡸࠧ࣫")}
def l1ll11_opy_(e, addon):
    l1l1l_opy_ = l111l_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠭ࠢࡤࡲࠥ࡫ࡲࡳࡱࡵࠤࡴࡩࡣࡶࡴࡨࡨ࠿ࠦࡊࡔࡑࡑࠤࡊࡸࡲࡰࡴ࠽ࠤࠪࡹࠬࠡࠧࡶࠫ࣬")  % (e, addon)
    l1ll1_opy_ = l111l_opy_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡧࡴࡴࡴࡢࡥࡷࠤࡺࡹࠠࡰࡰࠣࡸ࡭࡫ࠠࡧࡱࡵࡹࡲ࠴࣭ࠧ")
    l1lll_opy_ = l111l_opy_ (u"࡚ࠫࡶ࡬ࡰࡣࡧࠤࡦࠦ࡬ࡰࡩࠣࡺ࡮ࡧࠠࡵࡪࡨࠤࡦࡪࡤࡰࡰࠣࡷࡪࡺࡴࡪࡰࡪࡷࠥࡧ࡮ࡥࠢࡳࡳࡸࡺࠠࡵࡪࡨࠤࡱ࡯࡮࡬࠰࣮ࠪ")
    dixie.log(addon)
    dixie.log(e)
def getPlaylist():
    import requests
    l1ll11lll_opy_ = [l111l_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲ࡌࡊࡠ࠵࡛ࡻ࡬ࡎࡪ࡝࣯ࠧ"), l111l_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳ࡽ࡬࠵ࡊ࠵ࡋࡓࡩ࡟ࡎࠨࣰ"), l111l_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡹ࠰ࡦࡳ࠴࡛ࡌࡤ࠲࠴ࡑࡔࡒࡧࡄࣱࠩ"), l111l_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡺ࠱ࡧࡴ࠵ࡪࡶࡐࡐࡒ࡬ࡽࡪࡑ࠲ࣲࠪ"), l111l_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡻ࠲ࡨࡵ࠯ࡥ࡬ࡅࡥ࠶ࡴࡶ࠺ࡉࡽࠫࣳ"), l111l_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡼ࠳ࡩ࡯࠰ࡰ࡙ࡷࡶࡩࡧࡤࡥ࠼ࡽࠬࣴ"), l111l_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱ࡻࡐࡈ࠿࠴ࡆࡘࡔࡺ࡞࠭ࣵ"), l111l_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲ࡸࡸࡋ࠳ࡋࡒࡷࡪࡒࡸࣶࠧ"), l111l_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳ࡪ࡜ࡖࡂࡹࡎࡍࡸ࡙ࡨࠨࣷ"), l111l_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡹ࠰ࡦࡳ࠴ࡾࡑࡱࡈࡍ࡛࡬࡯ࡧ࡫ࠩࣸ")]
    l1l1lll1l_opy_ =  l111l_opy_ (u"ࠨࠥࡈ࡜࡙ࡓ࠳ࡖࣹࠩ")
    for url in l1ll11lll_opy_:
        try:
            request  = requests.get(url)
            l1lll111l_opy_ = request.text
        except: pass
        if l1l1lll1l_opy_ in l1lll111l_opy_:
            path = os.path.join(dixie.PROFILE, l111l_opy_ (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡲ࠹ࡵࠨࣺ"))
            with open(path, l111l_opy_ (u"ࠪࡻࠬࣻ")) as f:
                f.write(l1lll111l_opy_)
                break
def getPluginInfo(streamurl):
    if not l11l_opy_() == l111l_opy_ (u"࡙ࠫࡸࡵࡦࠩࣼ"):
        return
    if streamurl.isdigit():
        l1l1ll11l_opy_   = l111l_opy_ (u"ࠬࡑ࡯ࡥ࡫ࠣࡔ࡛ࡘࠠࡄࡪࡤࡲࡳ࡫࡬ࠨࣽ")
        l1l1lll11_opy_ = os.path.join(dixie.RESOURCES, l111l_opy_ (u"࠭࡫ࡰࡦ࡬࠱ࡵࡼࡲ࠯ࡲࡱ࡫ࠬࣾ"))
        return l1l1ll11l_opy_, l1l1lll11_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        name = streamurl.split(l111l_opy_ (u"ࠧ࡞ࡑࡗࡘࡤࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨࣿ"), 1)[-1].split(l111l_opy_ (u"ࠨ࠱ࠪऀ"), 1)[0]
    if streamurl.startswith(l111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬँ")):
        name = streamurl.split(l111l_opy_ (u"ࠪ࠳࠴࠭ं"), 1)[-1].split(l111l_opy_ (u"ࠫ࠴࠭ः"), 1)[0]
    if l111l_opy_ (u"ࠬࡥ࡟ࡔࡈࡢࡣࠬऄ") in streamurl:
        name = l111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡰࡳࡱࡪࡶࡦࡳ࠮ࡴࡷࡳࡩࡷ࠴ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵࠪअ")
    if l111l_opy_ (u"ࠧࡉࡆࡗ࡚࠿࠭आ") in streamurl:
        name = l111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡩࡦࡷࡺࠬइ")
    if l111l_opy_ (u"ࠩࡋࡈ࡙࡜࠲࠻ࠩई") in streamurl:
        name = l111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧࡩࡱࡶࡹࠫउ")
    if l111l_opy_ (u"ࠫࡍࡊࡔࡗ࠵࠽ࠫऊ") in streamurl:
        name = l111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢࡶࡹࠫऋ")
    if l111l_opy_ (u"࠭ࡈࡅࡖ࡙࠸࠿࠭ऌ") in streamurl:
        name = l111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸ࡭ࠩऍ")
    if l111l_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠺ࠨऎ") in streamurl:
        name = l111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡤࡥࡧ࡮ࡶ࡬ࡢࡻࡨࡶࠬए")
    if l111l_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠴࠽ࠫऐ") in streamurl:
        name = l111l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽࠧऑ")
    if l111l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖ࠿࠭ऒ") in streamurl:
        name = l111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰ࡭ࡣࡼࡩࡷࡽࡷࡸࠩओ")
    if l111l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡏࡔࡗ࠼ࠪऔ") in streamurl:
        name = l111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡶࡹࠫक")
    if l111l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪख") in streamurl:
        name = l111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡧࡩࡽ࠭ग")
    if l111l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡕࡆ࠿࠭घ") in streamurl:
        name = l111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷ࡫ࡢࡰࡱࡷࠫङ")
    if l111l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡈࡒࡕ࠻ࠩच") in streamurl:
        name = l111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡣ࡭ࡷ࡬ࡴࡹࡼࠧछ")
    if l111l_opy_ (u"ࠨࡋࡓࡘࡘ࠭ज") in streamurl:
        name = l111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࡯ࡰࡵࡸࠪझ")
    if l111l_opy_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠽ࠫञ") in streamurl:
        name = l111l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰ࡮ࡼࡥ࡮࡫ࡻࠫट")
    if l111l_opy_ (u"ࠬࡻࡰ࡯ࡲ࠽ࠫठ") in streamurl:
        name = l111l_opy_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴ࡨࡥࡪࡲࡱࡪࡸࡵ࡯࠰ࡹ࡭ࡪࡽࠧड")
    try:
        l1l1ll11l_opy_   = xbmcaddon.Addon(name).getAddonInfo(l111l_opy_ (u"ࠧ࡯ࡣࡰࡩࠬढ"))
        l1l1lll11_opy_ = xbmcaddon.Addon(name).getAddonInfo(l111l_opy_ (u"ࠨ࡫ࡦࡳࡳ࠭ण"))
    except:
        l1l1ll11l_opy_   = l111l_opy_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠣࡗࡴࡻࡲࡤࡧࠪत")
        l1l1lll11_opy_ =  dixie.ICON
    return l1l1ll11l_opy_, l1l1lll11_opy_
def selectStream(url, channel):
    url = url.replace(l111l_opy_ (u"ࠪࢀࡺࡹࡥࡳ࠯ࡤ࡫ࡪࡴࡴࠨथ"), l111l_opy_ (u"ࠫ࠲࠳ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪद"))
    l1l1ll111_opy_ = url.split(l111l_opy_ (u"ࠬࢂࠧध"))
    if len(l1l1ll111_opy_) == 0:
        return None
    options, l1l1l1ll1_opy_ = getOptions(l1l1ll111_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l1l1ll111_opy_) == 1:
            return l1l1l1ll1_opy_[0]
    import selectDialog
    l1ll1l111_opy_ = selectDialog.select(l111l_opy_ (u"࠭ࡓࡦ࡮ࡨࡧࡹࠦࡡࠡࡵࡷࡶࡪࡧ࡭ࠨन"), options)
    if l1ll1l111_opy_ < 0:
        raise Exception(l111l_opy_ (u"ࠧࡔࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡇࡦࡴࡣࡦ࡮ࠪऩ"))
    return l1l1l1ll1_opy_[l1ll1l111_opy_]
def getOptions(l1l1ll111_opy_, channel, l1lll11l1_opy_=True):
    if not l11l_opy_() == l111l_opy_ (u"ࠨࡖࡵࡹࡪ࠭प"):
        return
    options = []
    l1l1l1ll1_opy_    = []
    for index, stream in enumerate(l1l1ll111_opy_):
        l1l1ll11l_opy_ = getPluginInfo(stream)
        l1l11_opy_ = l1l1ll11l_opy_[0]
        l1ll11111_opy_  = l1l1ll11l_opy_[1]
        l1l11_opy_  = l111l_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡲࡶࡦࡴࡧࡦ࡟࡞ࠫफ") + l1l11_opy_ + l111l_opy_ (u"ࠪࡡࡠ࠵ࡃࡐࡎࡒࡖࡢࠦࠧब")
        if stream.startswith(OPEN_OTT):
            l1l11_opy_  = l1l11_opy_ + stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l111l_opy_ (u"ࠫࠬभ"))
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l111l_opy_ (u"ࠬ࠭म"))
        else:
            l1l11_opy_  = l1l11_opy_ + channel
        options.append([l1l11_opy_, index, l1ll11111_opy_])
        l1l1l1ll1_opy_.append(stream)
    if l1lll11l1_opy_:
        options.append([l111l_opy_ (u"࠭ࡁࡥࡦࠣࡱࡴࡸࡥ࠯࠰࠱ࠫय"), index + 1, dixie.ICON])
        l1l1l1ll1_opy_.append(l111l_opy_ (u"ࠧࡢࡦࡧࡑࡴࡸࡥࠨर"))
    return options, l1l1l1ll1_opy_