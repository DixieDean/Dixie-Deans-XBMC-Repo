# coding: UTF-8
import sys
l1111_opy_ = sys.version_info [0] == 2
l11l11_opy_ = 2048
l11l1_opy_ = 7
def l111ll_opy_ (l11l1l_opy_):
	global l11111_opy_
	l11lll_opy_ = ord (l11l1l_opy_ [-1])
	l11ll_opy_ = l11l1l_opy_ [:-1]
	l1111l_opy_ = l11lll_opy_ % len (l11ll_opy_)
	l1l1l1_opy_ = l11ll_opy_ [:l1111l_opy_] + l11ll_opy_ [l1111l_opy_:]
	if l1111_opy_:
		l1l1ll_opy_ = unicode () .join ([unichr (ord (char) - l11l11_opy_ - (l1l1l_opy_ + l11lll_opy_) % l11l1_opy_) for l1l1l_opy_, char in enumerate (l1l1l1_opy_)])
	else:
		l1l1ll_opy_ = str () .join ([chr (ord (char) - l11l11_opy_ - (l1l1l_opy_ + l11lll_opy_) % l11l1_opy_) for l1l1l_opy_, char in enumerate (l1l1l1_opy_)])
	return eval (l1l1ll_opy_)
import xbmc
import xbmcaddon
import json
import urllib
import os
import dixie
l1l11l11l_opy_   = l111ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡹࡰࡺࡶࡧࡴࡤࡲࡨ࡫ࠧ෽")
l1l111111_opy_   = l111ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡺࡲࡦࡣࡰ࠱ࡨࡵࡤࡦࡵࠪ෾")
l1l111ll1_opy_ = l111ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡵࡺࡣ࡬ࡴࡹࡼࠧ෿")
l11lll11l_opy_    = l111ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡱࡶ࡫ࡦ࡯࡮ࡶࡴࡷࠩ฀")
l11lll1l1_opy_   = l111ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡧࡷࡷࡹࡷ࡫ࡳࡵࡴࡨࡥࡲࡹࠧก")
l1l11l111_opy_  = l111ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡷࡩࡦࡲࡴࡩࡷࡱࡨࡪࡸࡧࡳࡱࡸࡲࡩ࠭ข")
l1l1l111l_opy_   =  [l1l11l11l_opy_, l1l111111_opy_, l11lll11l_opy_, l11lll1l1_opy_, l1l11l111_opy_]
def checkAddons():
    for addon in l1l1l111l_opy_:
        if l1ll11l11_opy_(addon):
            l1ll11l1l_opy_(addon)
def l1ll11l11_opy_(addon):
    if xbmc.getCondVisibility(l111ll_opy_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡌࡦࡹࡁࡥࡦࡲࡲ࠭ࠫࡳࠪࠩฃ") % addon) == 1:
        return True
    else:
        return False
def l1ll11l1l_opy_(addon):
    HOME = dixie.PROFILE
    PATH = os.path.join(HOME, l111ll_opy_ (u"ࠫ࡮ࡴࡩࠨค"))
    l1ll1llll_opy_ = l1l111l1l_opy_(addon) + l111ll_opy_ (u"ࠬ࠴ࡩ࡯࡫ࠪฅ")
    l1l1l11ll_opy_  = os.path.join(PATH, l1ll1llll_opy_)
    response = l1lll1l11_opy_(addon)
    try:
        result = response[l111ll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ฆ")]
    except KeyError:
        dixie.log(l111ll_opy_ (u"ࠧ࠮࠯࠰࠱࠲ࠦࡋࡦࡻࡈࡶࡷࡵࡲࠡ࡫ࡱࠤ࡬࡫ࡴࡇ࡫࡯ࡩࡸࠦ࠭࠮࠯࠰࠱ࠥ࠭ง") + addon)
        result = {l111ll_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࡳࠨจ"): [{l111ll_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬฉ"): l111ll_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࠩช"), l111ll_opy_ (u"ࡹࠬࡺࡹࡱࡧࠪซ"): l111ll_opy_ (u"ࡺ࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧฌ"), l111ll_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࠬญ"): l111ll_opy_ (u"ࡵࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡼࡽ࠭ฎ"), l111ll_opy_ (u"ࡶࠩ࡯ࡥࡧ࡫࡬ࠨฏ"): l111ll_opy_ (u"ࡷࠪࡒࡔࠦࡃࡉࡃࡑࡒࡊࡒࡓࠨฐ")}], l111ll_opy_ (u"ࡸࠫࡱ࡯࡭ࡪࡶࡶࠫฑ"): {l111ll_opy_ (u"ࡹࠬࡹࡴࡢࡴࡷࠫฒ"): 0, l111ll_opy_ (u"ࡺ࠭ࡴࡰࡶࡤࡰࠬณ"): 1, l111ll_opy_ (u"ࡻࠧࡦࡰࡧࠫด"): 1}}
    l1lll1111_opy_ = result[l111ll_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ต")]
    l1l1ll1l1_opy_  = file(l1l1l11ll_opy_, l111ll_opy_ (u"ࠨࡹࠪถ"))
    l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠩ࡞ࠫท"))
    l1l1ll1l1_opy_.write(addon)
    l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠪࡡࠬธ"))
    l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠫࡡࡴࠧน"))
    l1l11111l_opy_ = []
    for channel in l1lll1111_opy_:
        l1l111l11_opy_ = channel[l111ll_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫบ")]
        stream = channel[l111ll_opy_ (u"࠭ࡦࡪ࡮ࡨࠫป")]
        l1l1111ll_opy_  = l11llll11_opy_(addon, l1l111l11_opy_)
        channel = l11llll1l_opy_(addon, l1l1111ll_opy_)
        if addon == l1l111ll1_opy_:
            l1l11l1l1_opy_ = channel + l111ll_opy_ (u"ࠧ࠾ࡋࡓࡘࡘࡀࠧผ") + l1l111l11_opy_
        else:
            l1l11l1l1_opy_ = channel + l111ll_opy_ (u"ࠨ࠿ࠪฝ") + stream
        l1l11111l_opy_.append(l1l11l1l1_opy_)
        l1l11111l_opy_.sort()
    for item in l1l11111l_opy_:
      l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠤࠨࡷࡡࡴࠢพ") % item)
    l1l1ll1l1_opy_.close()
def l1l111l1l_opy_(addon):
    if addon == l1l11l11l_opy_:
        return l111ll_opy_ (u"ࠪࡹࡰࡺࡶࡧࡴࡤࡲࡨ࡫ࠧฟ")
    if addon == l1l111111_opy_:
        return l111ll_opy_ (u"ࠫࡽࡺࡲࡦࡣࡰ࠱ࡨࡵࡤࡦࡵࠪภ")
    if addon == l1l111ll1_opy_:
        return l111ll_opy_ (u"ࠬ࡯ࡰࡵࡸࡶࡹࡧࡹࠧม")
    if addon == l11lll11l_opy_:
        return l111ll_opy_ (u"࠭ࡱࡶ࡫ࡦ࡯ࠬย")
    if addon == l11lll1l1_opy_:
        return l111ll_opy_ (u"ࠧࡧࡷࡷࡹࡷ࡫ࠧร")
    if addon == l1l11l111_opy_:
        return l111ll_opy_ (u"ࠨࡵࡷࡩࡦࡲࡴࡩࠩฤ")
def l1lll1l11_opy_(addon):
    l1l111lll_opy_ = (l111ll_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬล") % addon)
    if addon == l1l11l111_opy_:
        l11lll111_opy_ = l111ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡺࡥࡢ࡮ࡷ࡬ࡺࡴࡤࡦࡴࡪࡶࡴࡻ࡮ࡥ࠱ࡂࡱࡴࡪࡥ࠾ࡩࡨࡲࡷ࡫ࡳࠧࡲࡲࡶࡹࡧ࡬࠾ࠧ࠺ࡦࠪ࠸࠲࡯ࡣࡰࡩࠪ࠸࠲ࠦ࠵ࡤࠩ࠷࠶ࠥ࠳࠴ࠨ࠹ࡧࡏࠥ࠶ࡦࠨ࠹ࡧࡉࡏࡍࡑࡕࠩ࠷࠶ࡷࡩ࡫ࡷࡩࠪ࠻ࡤࡄ࡮࡬ࡧࡰࠫ࠲࠱ࡖࡲࠩ࠷࠶ࡖࡪࡧࡺࠩ࠷࠶ࡔࡩࡧࠨ࠶࠵ࡒࡩࡴࡶࠨ࠶࠵ࡕࡦࠦ࠴࠳ࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠪ࠻ࡢࠦ࠴ࡩࡇࡔࡒࡏࡓࠧ࠸ࡨࠪ࠻ࡢࠦ࠴ࡩࡍࠪ࠻ࡤࠦ࠴࠵ࠩ࠷ࡩࠥ࠳࠲ࠨ࠶࠷ࡶࡡࡳࡧࡱࡸࡦࡲࠥ࠳࠴ࠨ࠷ࡦࠫ࠲࠱ࠧ࠵࠶࡫ࡧ࡬ࡴࡧࠨ࠶࠷ࠫ࠲ࡤࠧ࠵࠴ࠪ࠸࠲ࡶࡴ࡯ࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࠫ࠲࠳ࡪࡷࡸࡵࠫ࠳ࡢࠧ࠵ࡪࠪ࠸ࡦ࡮ࡹ࠴࠲࡮ࡶࡴࡷ࠸࠹࠲ࡹࡼࠥ࠳࠴ࠨ࠶ࡨࠫ࠲࠱ࠧ࠵࠶ࡵࡶࡡࡴࡵࡺࡳࡷࡪࠥ࠳࠴ࠨ࠷ࡦࠫ࠲࠱ࠧ࠵࠶࠵࠶࠰࠱ࠧ࠵࠶ࠪ࠸ࡣࠦ࠴࠳ࠩ࠷࠸࡭ࡢࡥࠨ࠶࠷ࠫ࠳ࡢࠧ࠵࠴ࠪ࠸࠲࠱࠲ࠨ࠷ࡦ࠷ࡁࠦ࠵ࡤ࠻࠽ࠫ࠳ࡢ࠶࠶ࠩ࠸ࡧ࠱࠳ࠧ࠶ࡥ࠼࠺ࠥ࠳࠴ࠨ࠶ࡨࠫ࠲࠱ࠧ࠵࠶ࡸ࡫ࡲࡪࡣ࡯ࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࠫ࠷ࡣࠧ࠵࠶ࡸ࡫࡮ࡥࡡࡶࡩࡷ࡯ࡡ࡭ࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࡸࡷࡻࡥࠦ࠴ࡦࠩ࠷࠶ࠥ࠳࠴ࡦࡹࡸࡺ࡯࡮ࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࡸࡷࡻࡥࠦ࠴ࡦࠩ࠷࠶ࠥ࠳࠴ࡶࡲࠪ࠸࠲ࠦ࠵ࡤࠩ࠷࠶ࠥ࠳࠴ࠨ࠶࠷ࠫ࠲ࡤࠧ࠵࠴ࠪ࠸࠲ࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࠨ࠶࠷ࠫ࠳ࡢࠧ࠵࠴ࠪ࠸࠲ࠦ࠴࠵ࠩ࠷ࡩࠥ࠳࠲ࠨ࠶࠷ࡪࡥࡷ࡫ࡦࡩࡤ࡯ࡤ࠳ࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࠩ࠷࠸ࠥ࠳࠴ࠨ࠶ࡨࠫ࠲࠱ࠧ࠵࠶ࡩ࡫ࡶࡪࡥࡨࡣ࡮ࡪࠥ࠳࠴ࠨ࠷ࡦࠫ࠲࠱ࠧ࠵࠶ࠪ࠸࠲ࠦ࠹ࡧࠩ࠷ࡩࠥ࠳࠲ࠨ࠶࠷ࡶࡡࡴࡵࡺࡳࡷࡪࠥ࠳࠴ࠨ࠷ࡦࠫ࠲࠱ࡰࡸࡰࡱࠫ࠲ࡤࠧ࠵࠴ࠪ࠸࠲࡭ࡱࡪ࡭ࡳࠫ࠲࠳ࠧ࠶ࡥࠪ࠸࠰࡯ࡷ࡯ࡰࠪ࠽ࡤࠨฦ")
    else:
        l11lll111_opy_ = l111ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧว") + addon + l111ll_opy_ (u"ࠬ࠵࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࡴࡧࡦࡹࡷ࡯ࡴࡺࡡࡦ࡬ࡪࡩ࡫ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠬࡴࡪࡶ࡯ࡩࡂࡒࡩࡷࡧࠨ࠶࠵࡚ࡖࠧࡷࡵࡰࠬศ")
    query = l1l1111l1_opy_(addon)
    l1l11l1ll_opy_ = (l111ll_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࠧࡶࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩษ") % l11lll111_opy_)
    l1l11ll11_opy_ = (l111ll_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪส") % query)
    try:
        xbmc.executeJSONRPC(l1l111lll_opy_)
        if addon != l1l111ll1_opy_:
            xbmc.executeJSONRPC(l1l11l1ll_opy_)
        response = xbmc.executeJSONRPC(l1l11ll11_opy_)
        content  = json.loads(response.decode(l111ll_opy_ (u"ࠨࡷࡷࡪ࠲࠾ࠧห"), l111ll_opy_ (u"ࠩ࡬࡫ࡳࡵࡲࡦࠩฬ")))
        return content
    except:
        dixie.log(l111ll_opy_ (u"ࠪ࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱ࠥࡖ࡬ࡶࡩ࡬ࡲࠥࡋࡲࡳࡱࡵࠤ࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠭อ"))
        return {l111ll_opy_ (u"ࠫࡊࡸࡲࡰࡴࠪฮ") : l111ll_opy_ (u"ࠬࡖ࡬ࡶࡩ࡬ࡲࠥࡋࡲࡳࡱࡵࠫฯ")}
def l1l1111l1_opy_(addon):
    if addon == l1l111ll1_opy_:
        return l111ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥ࡮ࡶࡴࡷ࠱ࡂࡥࡨࡺࡩࡰࡰࡀࡰ࡮ࡼࡥࡵࡸࡢࡥࡱࡲࠦࡦࡺࡷࡶࡦࠬࡰࡢࡩࡨࠪࡵࡲ࡯ࡵࠨࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡂࠫ࠲ࡧࡗࡶࡩࡷࡹࠥ࠳ࡨࡵ࡭ࡨ࡮ࡡࡳࡦࠨ࠶࡫ࡒࡩࡣࡴࡤࡶࡾࠫ࠲ࡧࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࠫ࠲࠱ࡕࡸࡴࡵࡵࡲࡵࠧ࠵ࡪࡐࡵࡤࡪࠧ࠵ࡪࡦࡪࡤࡰࡰࡶࠩ࠷࡬ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰࡵࡸࡶࡹࡧࡹ࠲࠯࠶ࠨ࠶࡫ࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠦ࠴ࡩ࡭ࡲ࡭ࠥ࠳ࡨ࡫ࡳࡹ࠴ࡰ࡯ࡩࠩࡸ࡮ࡺ࡬ࡦ࠿ࡄࡰࡱࠫ࠲࠱ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠩࡹࡷࡲࠧะ")
    if addon == l11lll11l_opy_:
        return l111ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡳࡸ࡭ࡨࡱࡩࡱࡶࡹ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡹࡴࡳࡧࡤࡱࡤࡼࡩࡥࡧࡲࠪࡪࡾࡴࡳࡣࠩࡴࡦ࡭ࡥࠧࡲ࡯ࡳࡹࠬࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠿ࠩࡸ࡮ࡺ࡬ࡦ࠿ࡄࡰࡱࠬࡵࡳ࡮ࡀ࠴ࠬั")
    if addon == l11lll1l1_opy_:
        return l111ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡩࡹࡹࡻࡲࡦࡵࡷࡶࡪࡧ࡭ࡴ࠱ࡂࡥࡨࡺࡩࡰࡰࡀࡷࡹࡸࡥࡢ࡯ࡢࡺ࡮ࡪࡥࡰࠨࡨࡼࡹࡸࡡࠧࡲࡤ࡫ࡪࠬࡰ࡭ࡱࡷࠪࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠽ࠧࡶ࡬ࡸࡱ࡫࠽ࡂ࡮࡯ࠪࡺࡸ࡬࠾࠲ࠪา")
    if addon == l1l11l111_opy_:
        return l111ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡹ࡫ࡡ࡭ࡶ࡫ࡹࡳࡪࡥࡳࡩࡵࡳࡺࡴࡤ࠰ࡁࡪࡩࡳࡸࡥࡠࡰࡤࡱࡪࡃࡁ࡭࡮ࠩࡴࡴࡸࡴࡢ࡮ࡀࠩ࠼ࡈࠥ࠳࠴ࡱࡥࡲ࡫ࠥ࠳࠴ࠨ࠷ࡆ࠱ࠥ࠳࠴ࠨ࠹ࡇࡏࠥ࠶ࡆࠨ࠹ࡇࡉࡏࡍࡑࡕ࠯ࡼ࡮ࡩࡵࡧࠨ࠹ࡉࡉ࡬ࡪࡥ࡮࠯࡙ࡵࠫࡗ࡫ࡨࡻ࠰࡚ࡨࡦ࠭ࡏ࡭ࡸࡺࠫࡐࡨ࠮ࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠪ࠻ࡂࠦ࠴ࡉࡇࡔࡒࡏࡓࠧ࠸ࡈࠪ࠻ࡂࠦ࠴ࡉࡍࠪ࠻ࡄࠦ࠴࠵ࠩ࠷ࡉࠫࠦ࠴࠵ࡴࡦࡸࡥ࡯ࡶࡤࡰࠪ࠸࠲ࠦ࠵ࡄ࠯ࠪ࠸࠲ࡧࡣ࡯ࡷࡪࠫ࠲࠳ࠧ࠵ࡇ࠰ࠫ࠲࠳ࡷࡵࡰࠪ࠸࠲ࠦ࠵ࡄ࠯ࠪ࠸࠲ࡩࡶࡷࡴࠪ࠹ࡁࠦ࠴ࡉࠩ࠷ࡌ࡭ࡸ࠳࠱࡭ࡵࡺࡶ࠷࠸࠱ࡸࡻࠫ࠲࠳ࠧ࠵ࡇ࠰ࠫ࠲࠳ࡲࡳࡥࡸࡹࡷࡰࡴࡧࠩ࠷࠸ࠥ࠴ࡃ࠮ࠩ࠷࠸࠰࠱࠲࠳ࠩ࠷࠸ࠥ࠳ࡅ࠮ࠩ࠷࠸࡭ࡢࡥࠨ࠶࠷ࠫ࠳ࡂ࠭ࠨ࠶࠷࠶࠰ࠦ࠵ࡄ࠵ࡆࠫ࠳ࡂ࠹࠻ࠩ࠸ࡇ࠴࠴ࠧ࠶ࡅ࠶࠸ࠥ࠴ࡃ࠺࠸ࠪ࠸࠲ࠦ࠴ࡆ࠯ࠪ࠸࠲ࡴࡧࡵ࡭ࡦࡲࠥ࠳࠴ࠨ࠷ࡆ࠱ࠥ࠸ࡄࠨ࠶࠷ࡹࡥ࡯ࡦࡢࡷࡪࡸࡩࡢ࡮ࠨ࠶࠷ࠫ࠳ࡂ࠭ࡷࡶࡺ࡫ࠥ࠳ࡅ࠮ࠩ࠷࠸ࡣࡶࡵࡷࡳࡲࠫ࠲࠳ࠧ࠶ࡅ࠰ࡺࡲࡶࡧࠨ࠶ࡈ࠱ࠥ࠳࠴ࡶࡲࠪ࠸࠲ࠦ࠵ࡄ࠯ࠪ࠸࠲ࠦ࠴࠵ࠩ࠷ࡉࠫࠦ࠴࠵ࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࠫ࠲࠳ࠧ࠶ࡅ࠰ࠫ࠲࠳ࠧ࠵࠶ࠪ࠸ࡃࠬࠧ࠵࠶ࡩ࡫ࡶࡪࡥࡨࡣ࡮ࡪ࠲ࠦ࠴࠵ࠩ࠸ࡇࠫࠦ࠴࠵ࠩ࠷࠸ࠥ࠳ࡅ࠮ࠩ࠷࠸ࡤࡦࡸ࡬ࡧࡪࡥࡩࡥࠧ࠵࠶ࠪ࠹ࡁࠬࠧ࠵࠶ࠪ࠸࠲ࠦ࠹ࡇࠩ࠷ࡉࠫࠦ࠴࠵ࡴࡦࡹࡳࡸࡱࡵࡨࠪ࠸࠲ࠦ࠵ࡄ࠯ࡳࡻ࡬࡭ࠧ࠵ࡇ࠰ࠫ࠲࠳࡮ࡲ࡫࡮ࡴࠥ࠳࠴ࠨ࠷ࡆ࠱࡮ࡶ࡮࡯ࠩ࠼ࡊࠦ࡮ࡱࡧࡩࡂࡩࡨࡢࡰࡱࡩࡱࡹࠦࡨࡧࡱࡶࡪࡥࡩࡥ࠿ࠨ࠶ࡆ࠭ำ")
    else:
        Addon = xbmcaddon.Addon(addon)
        username =  Addon.getSetting(l111ll_opy_ (u"ࠪ࡯ࡦࡹࡵࡵࡣ࡭ࡥࡳ࡯࡭ࡪࠩิ"))
        password =  Addon.getSetting(l111ll_opy_ (u"ࠫࡸࡧ࡬ࡢࡵࡲࡲࡦ࠭ี"))
        l11lll1ll_opy_     = l111ll_opy_ (u"ࠬ࠵࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࡴࡶࡵࡩࡦࡳ࡟ࡷ࡫ࡧࡩࡴࠬࡥࡹࡶࡵࡥࠫࡶࡡࡨࡧࠩࡴࡱࡵࡴࠧࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡁࠫࡺࡩࡵ࡮ࡨࡁࡆࡲ࡬ࠧࡷࡵࡰࡂ࠭ึ")
        l1ll11ll1_opy_  =  l1lll11ll_opy_(addon)
        l1l1ll11l_opy_   = l111ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩื") + addon
        l11lllll1_opy_  =  l1l1ll11l_opy_ + l11lll1ll_opy_ + l1ll11ll1_opy_
        l1l11ll1l_opy_ = l111ll_opy_ (u"ࠧࡶࡵࡨࡶࡳࡧ࡭ࡦ࠿ุࠪ") + username + l111ll_opy_ (u"ࠨࠨࡳࡥࡸࡹࡷࡰࡴࡧࡁูࠬ") + password + l111ll_opy_ (u"ࠩࠩࡸࡾࡶࡥ࠾ࡩࡨࡸࡤࡲࡩࡷࡧࡢࡷࡹࡸࡥࡢ࡯ࡶࠪࡨࡧࡴࡠ࡫ࡧࡁ࠵ฺ࠭")
        return l11lllll1_opy_ + urllib.quote_plus(l1l11ll1l_opy_)
def l1lll11ll_opy_(addon):
    if (addon == l1l11l11l_opy_) or (addon == l1l111111_opy_):
        return l111ll_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠷࠼࠴࠱࠹࠹࠱࠵࠸࠿࠮࠲࠷࠸࠾࠽࠶࠰࠱࠱ࡨࡲ࡮࡭࡭ࡢ࠴࠱ࡴ࡭ࡶ࠿ࠨ฻")
def l11llll11_opy_(addon, l1ll1l111_opy_):
    if (addon == l1l11l11l_opy_) or (addon == l1l111111_opy_) or (addon == l1l111ll1_opy_):
        l1ll1l111_opy_ = l1ll1l111_opy_.replace(l111ll_opy_ (u"ࠫࠥࠦࠧ฼"), l111ll_opy_ (u"ࠬࠦࠧ฽")).replace(l111ll_opy_ (u"࠭ࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ฾"), l111ll_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ฿"))
        return l1ll1l111_opy_
    if (addon == l11lll11l_opy_) or (addon == l11lll1l1_opy_) or (addon == l1l11l111_opy_):
        return l1ll1l111_opy_
def l11llll1l_opy_(addon, l11llllll_opy_):
    if (addon == l1l11l11l_opy_) or (addon == l1l111111_opy_) or (addon == l1l111ll1_opy_):
        channel = l11llllll_opy_.rsplit(l111ll_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪเ"), 1)[0].split(l111ll_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡺ࡬࡮ࡺࡥ࡞ࠩแ"), 1)[-1]
        channel = channel.replace(l111ll_opy_ (u"ࠪࡆࡇࡉࠠ࠲ࠩโ"), l111ll_opy_ (u"ࠫࡇࡈࡃࠡࡑࡱࡩࠬใ")).replace(l111ll_opy_ (u"ࠬࡈࡂࡄࠢ࠵ࠫไ"), l111ll_opy_ (u"࠭ࡂࡃࡅࠣࡘࡼࡵࠧๅ")).replace(l111ll_opy_ (u"ࠧࡃࡄࡆࠤ࠹࠭ๆ"), l111ll_opy_ (u"ࠨࡄࡅࡇࠥࡌࡏࡖࡔࠪ็")).replace(l111ll_opy_ (u"ࠩࡌࡘ࡛ࠦ࠱ࠨ่"), l111ll_opy_ (u"ࠪࡍ࡙࡜࠱ࠨ้")).replace(l111ll_opy_ (u"ࠫࡎ࡚ࡖࠡ࠴๊ࠪ"), l111ll_opy_ (u"ࠬࡏࡔࡗ࠴๋ࠪ")).replace(l111ll_opy_ (u"࠭ࡉࡕࡘࠣ࠷ࠬ์"), l111ll_opy_ (u"ࠧࡊࡖ࡙࠷ࠬํ")).replace(l111ll_opy_ (u"ࠨࡋࡗ࡚ࠥ࠺ࠧ๎"), l111ll_opy_ (u"ࠩࡌࡘ࡛࠺ࠧ๏"))
        return channel
    if (addon == l11lll11l_opy_) or (addon == l11lll1l1_opy_):
        channel = l11llllll_opy_.rsplit(l111ll_opy_ (u"ࠪࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭๐"))[0].replace(l111ll_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡼ࡮ࡩࡵࡧࡠࠫ๑"), l111ll_opy_ (u"ࠬ࠭๒"))
        channel = channel.replace(l111ll_opy_ (u"࠭࠺ࠨ๓"), l111ll_opy_ (u"ࠧࠨ๔")).replace(l111ll_opy_ (u"ࠨࡄࡅࡇࠥ࠷ࠧ๕"), l111ll_opy_ (u"ࠩࡅࡆࡈࠦࡏ࡯ࡧࠪ๖")).replace(l111ll_opy_ (u"ࠪࡆࡇࡉࠠ࠳ࠩ๗"), l111ll_opy_ (u"ࠫࡇࡈࡃࠡࡖࡺࡳࠬ๘")).replace(l111ll_opy_ (u"ࠬࡈࡂࡄࠢ࠷ࠫ๙"), l111ll_opy_ (u"࠭ࡂࡃࡅࠣࡊࡔ࡛ࡒࠨ๚")).replace(l111ll_opy_ (u"ࠧࡊࡖ࡙ࠤ࠶࠭๛"), l111ll_opy_ (u"ࠨࡋࡗ࡚࠶࠭๜")).replace(l111ll_opy_ (u"ࠩࡌࡘ࡛ࠦ࠲ࠨ๝"), l111ll_opy_ (u"ࠪࡍ࡙࡜࠲ࠨ๞")).replace(l111ll_opy_ (u"ࠫࡎ࡚ࡖࠡ࠵ࠪ๟"), l111ll_opy_ (u"ࠬࡏࡔࡗ࠵ࠪ๠")).replace(l111ll_opy_ (u"࠭ࡉࡕࡘࠣ࠸ࠬ๡"), l111ll_opy_ (u"ࠧࡊࡖ࡙࠸ࠬ๢"))
        return channel
    else:
        channel = l11llllll_opy_.replace(l111ll_opy_ (u"ࠨࡄࡅࡇࠥ࠷ࠧ๣"), l111ll_opy_ (u"ࠩࡅࡆࡈࠦࡏ࡯ࡧࠪ๤")).replace(l111ll_opy_ (u"ࠪࡆࡇࡉࠠ࠳ࠩ๥"), l111ll_opy_ (u"ࠫࡇࡈࡃࠡࡖࡺࡳࠬ๦")).replace(l111ll_opy_ (u"ࠬࡈࡂࡄࠢ࠷ࠫ๧"), l111ll_opy_ (u"࠭ࡂࡃࡅࠣࡊࡔ࡛ࡒࠨ๨")).replace(l111ll_opy_ (u"ࠧࡊࡖ࡙ࠤ࠶࠭๩"), l111ll_opy_ (u"ࠨࡋࡗ࡚࠶࠭๪")).replace(l111ll_opy_ (u"ࠩࡌࡘ࡛ࠦ࠲ࠨ๫"), l111ll_opy_ (u"ࠪࡍ࡙࡜࠲ࠨ๬")).replace(l111ll_opy_ (u"ࠫࡎ࡚ࡖࠡ࠵ࠪ๭"), l111ll_opy_ (u"ࠬࡏࡔࡗ࠵ࠪ๮")).replace(l111ll_opy_ (u"࠭ࡉࡕࡘࠣ࠸ࠬ๯"), l111ll_opy_ (u"ࠧࡊࡖ࡙࠸ࠬ๰"))
        return channel
def l1l1ll1ll_opy_(e):
    l1ll1l11l_opy_ = l111ll_opy_ (u"ࠨࡕࡲࡶࡷࡿࠬࠡࡣࡱࠤࡪࡸࡲࡰࡴࠣࡳࡨࡩࡵࡳࡧࡧ࠾ࠥࡐࡓࡐࡐࠣࡉࡷࡸ࡯ࡳ࠼ࠣࠩࡸ࠭๱")  %e
    l1ll1l1l1_opy_ = l111ll_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡹࡸࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡦࡰࡴࡸࡱ࠳࠭๲")
    l1ll1l1ll_opy_ = l111ll_opy_ (u"࡙ࠪࡵࡲ࡯ࡢࡦࠣࡥࠥࡲ࡯ࡨࠢࡹ࡭ࡦࠦࡴࡩࡧࠣࡥࡩࡪ࡯࡯ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠤࡦࡴࡤࠡࡲࡲࡷࡹࠦࡴࡩࡧࠣࡰ࡮ࡴ࡫࠯ࠩ๳")
    dixie.log(e)
    dixie.DialogOK(l1ll1l11l_opy_, l1ll1l1l1_opy_, l1ll1l1ll_opy_)
    dixie.SetSetting(SETTING, l111ll_opy_ (u"ࠫࠬ๴"))