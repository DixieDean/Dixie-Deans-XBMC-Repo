# coding: UTF-8
import sys
l1llll_opy_ = sys.version_info [0] == 2
l1ll1_opy_ = 2048
l11l_opy_ = 7
def l11l1_opy_ (ll_opy_):
	global l1lll1_opy_
	l11ll1_opy_ = ord (ll_opy_ [-1])
	l1111_opy_ = ll_opy_ [:-1]
	l1_opy_ = l11ll1_opy_ % len (l1111_opy_)
	l1l1l1_opy_ = l1111_opy_ [:l1_opy_] + l1111_opy_ [l1_opy_:]
	if l1llll_opy_:
		l1ll11_opy_ = unicode () .join ([unichr (ord (char) - l1ll1_opy_ - (l11ll_opy_ + l11ll1_opy_) % l11l_opy_) for l11ll_opy_, char in enumerate (l1l1l1_opy_)])
	else:
		l1ll11_opy_ = str () .join ([chr (ord (char) - l1ll1_opy_ - (l11ll_opy_ + l11ll1_opy_) % l11l_opy_) for l11ll_opy_, char in enumerate (l1l1l1_opy_)])
	return eval (l1ll11_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l11lll11l_opy_    = l11l1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡯ࡶࡹࠫন")
l11ll1l1l_opy_ = l11l1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡹ࡯࡭ࡵࡺࡶࠨ঩")
l1l111111_opy_    = l11l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸ࡯ࡹࡻࡲ࡬ࠩপ")
locked = l11l1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰࡴࡩ࡫ࡦࡦࡷࡺࠬফ")
l11ll1111_opy_     = l11l1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡲࡴࡪ࡯ࡤࡸࡪࡳࡡ࡯࡫ࡤࠫব")
l11l1ll11_opy_   = l11l1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲࡩࡶࡺ࠱ࡸࡻ࠭ভ")
l11ll1lll_opy_    = l11l1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡄࡄࡕࡳࡳࡷࡺࡳࠨম")
l11llllll_opy_ = l11l1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡧࡥࡳࡴࡺࠧয")
l11llll11_opy_    = l11l1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡥ࡯ࡹ࡮ࡶࡴࡷࠩর")
l11l1lll1_opy_ = l11l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧࡩࡱࡶࡹࠫ঱")
l1l111l_opy_ = [l11lll11l_opy_, locked, l11l1ll11_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l11l1_opy_ (u"ࠫ࡮ࡴࡩࠨল"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1lllll1_opy_ = l11l1_opy_ (u"ࠬ࠭঳")
def l1lll111_opy_(i, t1, l1llll1l_opy_=[]):
 t = l1lllll1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1llll1l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11l1ll_opy_ = l1lll111_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11l1l1_opy_ = l1lll111_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1l111l_opy_:
        if l1ll1l1_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1ll1l1_opy_(addon):
    if xbmc.getCondVisibility(l11l1_opy_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡈࡢࡵࡄࡨࡩࡵ࡮ࠩࠧࡶ࠭ࠬ঴") % addon) == 1:
        return True
    return False
def createINI(addon):
    l11l11_opy_ = str(addon).split(l11l1_opy_ (u"ࠧ࠯ࠩ঵"))[2] + l11l1_opy_ (u"ࠨ࠰࡬ࡲ࡮࠭শ")
    l1l11l1_opy_  = os.path.join(PATH, l11l11_opy_)
    try:
        l1l_opy_ = l111ll_opy_(addon)
    except KeyError:
        dixie.log(l11l1_opy_ (u"ࠩ࠰࠱࠲࠳࠭ࠡࡍࡨࡽࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡧࡦࡶࡉ࡭ࡱ࡫ࡳࠡ࠯࠰࠱࠲࠳ࠠࠨষ") + addon)
        result = {l11l1_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࡵࠪস"): [{l11l1_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧহ"): l11l1_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࠫ঺"), l11l1_opy_ (u"ࡻࠧࡵࡻࡳࡩࠬ঻"): l11l1_opy_ (u"ࡵࠨࡷࡱ࡯ࡳࡵࡷ࡯়ࠩ"), l11l1_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࠧঽ"): l11l1_opy_ (u"ࡷࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡾࡸࠨা"), l11l1_opy_ (u"ࡸࠫࡱࡧࡢࡦ࡮ࠪি"): l11l1_opy_ (u"ࡹࠬࡔࡏࠡࡅࡋࡅࡓࡔࡅࡍࡕࠪী")}], l11l1_opy_ (u"ࡺ࠭࡬ࡪ࡯࡬ࡸࡸ࠭ু"):{l11l1_opy_ (u"ࡻࠧࡴࡶࡤࡶࡹ࠭ূ"): 0, l11l1_opy_ (u"ࡵࠨࡶࡲࡸࡦࡲࠧৃ"): 1, l11l1_opy_ (u"ࡶࠩࡨࡲࡩ࠭ৄ"): 1}}
    l1l11l_opy_  = file(l1l11l1_opy_, l11l1_opy_ (u"ࠩࡺࠫ৅"))
    l1l11l_opy_.write(l11l1_opy_ (u"ࠪ࡟ࠬ৆"))
    l1l11l_opy_.write(addon)
    l1l11l_opy_.write(l11l1_opy_ (u"ࠫࡢ࠭ে"))
    l1l11l_opy_.write(l11l1_opy_ (u"ࠬࡢ࡮ࠨৈ"))
    l1ll11l_opy_ = []
    for channel in l1l_opy_:
        l1l11_opy_ = channel[l11l1_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬ৉")]
        l1l11_opy_ = l11l1l_opy_(l1l11_opy_)
        l1111l_opy_ = dixie.mapChannelName(l1l11_opy_)
        stream   = channel[l11l1_opy_ (u"ࠧࡧ࡫࡯ࡩࠬ৊")]
        l1lllll_opy_ = l1111l_opy_ + l11l1_opy_ (u"ࠨ࠿ࠪো") + stream
        l1ll11l_opy_.append(l1lllll_opy_)
        l1ll11l_opy_.sort()
    for item in l1ll11l_opy_:
        l1l11l_opy_.write(l11l1_opy_ (u"ࠤࠨࡷࡡࡴࠢৌ") % item)
    l1l11l_opy_.close()
def l11l1l_opy_(name):
    import re
    name  = re.sub(l11l1_opy_ (u"ࠪࡠ࠭ࡡ࠰࠮࠻ࠬࡡ࠯ࡢࠩࠨ্"), l11l1_opy_ (u"ࠫࠬৎ"), name)
    items = name.split(l11l1_opy_ (u"ࠬࡣࠧ৏"))
    name  = l11l1_opy_ (u"࠭ࠧ৐")
    for item in items:
        if len(item) == 0:
            continue
        item += l11l1_opy_ (u"ࠧ࡞ࠩ৑")
        item  = re.sub(l11l1_opy_ (u"ࠨ࡞࡞࡟ࡣ࠯࡝ࠫ࡞ࡠࠫ৒"), l11l1_opy_ (u"ࠩࠪ৓"), item)
        if len(item) > 0:
            name += item
    name  = name.replace(l11l1_opy_ (u"ࠪ࡟ࠬ৔"), l11l1_opy_ (u"ࠫࠬ৕"))
    name  = name.replace(l11l1_opy_ (u"ࠬࡣࠧ৖"), l11l1_opy_ (u"࠭ࠧৗ"))
    name  = name.strip()
    while True:
        length = len(name)
        name = name.replace(l11l1_opy_ (u"ࠧࠡࠢࠪ৘"), l11l1_opy_ (u"ࠨࠢࠪ৙"))
        if length == len(name):
            break
    return name.strip()
def l111ll_opy_(addon):
    if (addon == l11lll11l_opy_) or (addon == l11ll1l1l_opy_) or (addon == l11l1lll1_opy_):
        try:
            if xbmcaddon.Addon(addon).getSetting(l11l1_opy_ (u"ࠩࡪࡩࡳࡸࡥࠨ৚")) == l11l1_opy_ (u"ࠪࡸࡷࡻࡥࠨ৛"):
                xbmcaddon.Addon(addon).setSetting(l11l1_opy_ (u"ࠫ࡬࡫࡮ࡳࡧࠪড়"), l11l1_opy_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫঢ়"))
                xbmcgui.Window(10000).setProperty(l11l1_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡇࡆࡐࡕࡉࠬ৞"), l11l1_opy_ (u"ࠧࡕࡴࡸࡩࠬয়"))
            if xbmcaddon.Addon(addon).getSetting(l11l1_opy_ (u"ࠨࡶࡹ࡫ࡺ࡯ࡤࡦࠩৠ")) == l11l1_opy_ (u"ࠩࡷࡶࡺ࡫ࠧৡ"):
                xbmcaddon.Addon(addon).setSetting(l11l1_opy_ (u"ࠪࡸࡻ࡭ࡵࡪࡦࡨࠫৢ"), l11l1_opy_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪৣ"))
                xbmcgui.Window(10000).setProperty(l11l1_opy_ (u"ࠬࡖࡌࡖࡉࡌࡒࡤ࡚ࡖࡈࡗࡌࡈࡊ࠭৤"), l11l1_opy_ (u"࠭ࡔࡳࡷࡨࠫ৥"))
        except: pass
        l11ll1l11_opy_  = l11l1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ০") + addon
        l11lllll1_opy_ =  l1l1111ll_opy_(addon)
        query   =  l11ll1l11_opy_ + l11lllll1_opy_
        return sendJSON(query, addon)
    return l1ll1lll_opy_(addon)
def l1ll1lll_opy_(addon):
    if addon == l11l1ll11_opy_:
        l1ll1111_opy_ = [l11l1_opy_ (u"ࠨ࠷ࠪ১"), l11l1_opy_ (u"ࠩ࠴࠴࠻࠭২"), l11l1_opy_ (u"ࠪ࠸ࠬ৩"), l11l1_opy_ (u"ࠫ࠷࠼࠳ࠨ৪"), l11l1_opy_ (u"ࠬ࠷࠳࠳ࠩ৫")]
    if addon == locked:
        l1ll1111_opy_ = [l11l1_opy_ (u"࠭࠳࠱ࠩ৬"), l11l1_opy_ (u"ࠧ࠴࠳ࠪ৭"), l11l1_opy_ (u"ࠨ࠵࠵ࠫ৮"), l11l1_opy_ (u"ࠩ࠶࠷ࠬ৯"), l11l1_opy_ (u"ࠪ࠷࠹࠭ৰ"), l11l1_opy_ (u"ࠫ࠸࠻ࠧৱ"), l11l1_opy_ (u"ࠬ࠹࠸ࠨ৲"), l11l1_opy_ (u"࠭࠴࠱ࠩ৳"), l11l1_opy_ (u"ࠧ࠵࠳ࠪ৴"), l11l1_opy_ (u"ࠨ࠶࠸ࠫ৵"), l11l1_opy_ (u"ࠩ࠷࠻ࠬ৶"), l11l1_opy_ (u"ࠪ࠸࠾࠭৷"), l11l1_opy_ (u"ࠫ࠺࠸ࠧ৸")]
    if addon == l11ll1111_opy_:
        l1ll1111_opy_ = [l11l1_opy_ (u"ࠬ࠸࠵ࠨ৹"), l11l1_opy_ (u"࠭࠲࠷ࠩ৺"), l11l1_opy_ (u"ࠧ࠳࠹ࠪ৻"), l11l1_opy_ (u"ࠨ࠴࠼ࠫৼ"), l11l1_opy_ (u"ࠩ࠶࠴ࠬ৽"), l11l1_opy_ (u"ࠪ࠷࠶࠭৾"), l11l1_opy_ (u"ࠫ࠸࠸ࠧ৿"), l11l1_opy_ (u"ࠬ࠹࠵ࠨ਀"), l11l1_opy_ (u"࠭࠳࠷ࠩਁ"), l11l1_opy_ (u"ࠧ࠴࠹ࠪਂ"), l11l1_opy_ (u"ࠨ࠵࠻ࠫਃ"), l11l1_opy_ (u"ࠩ࠶࠽ࠬ਄"), l11l1_opy_ (u"ࠪ࠸࠵࠭ਅ"), l11l1_opy_ (u"ࠫ࠹࠷ࠧਆ"), l11l1_opy_ (u"ࠬ࠺࠸ࠨਇ"), l11l1_opy_ (u"࠭࠴࠺ࠩਈ"), l11l1_opy_ (u"ࠧ࠶࠲ࠪਉ"), l11l1_opy_ (u"ࠨ࠷࠵ࠫਊ"), l11l1_opy_ (u"ࠩ࠸࠸ࠬ਋"), l11l1_opy_ (u"ࠪ࠹࠻࠭਌"), l11l1_opy_ (u"ࠫ࠺࠽ࠧ਍"), l11l1_opy_ (u"ࠬ࠻࠸ࠨ਎"), l11l1_opy_ (u"࠭࠵࠺ࠩਏ"), l11l1_opy_ (u"ࠧ࠷࠲ࠪਐ"), l11l1_opy_ (u"ࠨ࠸࠴ࠫ਑"), l11l1_opy_ (u"ࠩ࠹࠶ࠬ਒"), l11l1_opy_ (u"ࠪ࠺࠸࠭ਓ"), l11l1_opy_ (u"ࠫ࠻࠻ࠧਔ"), l11l1_opy_ (u"ࠬ࠼࠶ࠨਕ"), l11l1_opy_ (u"࠭࠶࠸ࠩਖ"), l11l1_opy_ (u"ࠧ࠷࠻ࠪਗ"), l11l1_opy_ (u"ࠨ࠹࠳ࠫਘ"), l11l1_opy_ (u"ࠩ࠺࠸ࠬਙ"), l11l1_opy_ (u"ࠪ࠻࠼࠭ਚ"), l11l1_opy_ (u"ࠫ࠼࠾ࠧਛ"), l11l1_opy_ (u"ࠬ࠾࠰ࠨਜ"), l11l1_opy_ (u"࠭࠸࠲ࠩਝ")]
    login = l11l1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷ࠴࠭ਞ") % addon
    sendJSON(login, addon)
    l1111ll_opy_ = []
    for l1ll1l1l_opy_ in l1ll1111_opy_:
        if addon == l11l1ll11_opy_:
            query = l11l1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸ࠵࠿࡮ࡱࡧࡩࡤ࡯ࡤ࠾ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠩࡱࡴࡪࡥ࠾ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠩࡷࡪࡩࡴࡪࡱࡱࡣ࡮ࡪ࠽ࠦࡵࠪਟ") % (addon, l1ll1l1l_opy_)
        if (addon == locked) or (addon == l11ll1111_opy_):
            query = l11l1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠪࡹ࠯ࡀࡷࡵࡰࡂࠫࡳࠧ࡯ࡲࡨࡪࡃ࠴ࠧࡰࡤࡱࡪࡃࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡵࡲࡡࡺ࠿ࠩࡨࡦࡺࡥ࠾ࠨࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴ࠽ࠧࡲࡤ࡫ࡪࡃࠧਠ") % (addon, l1ll1l1l_opy_)
        response = sendJSON(query, addon)
        l1111ll_opy_.extend(response)
    return l1111ll_opy_
def sendJSON(query, addon):
    l1ll11ll_opy_     = l11l1_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ਡ") % query
    l1ll1ll1_opy_  = xbmc.executeJSONRPC(l1ll11ll_opy_)
    response = json.loads(l1ll1ll1_opy_)
    result   = response[l11l1_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫਢ")]
    if xbmcgui.Window(10000).getProperty(l11l1_opy_ (u"ࠬࡖࡌࡖࡉࡌࡒࡤࡍࡅࡏࡔࡈࠫਣ")) == l11l1_opy_ (u"࠭ࡔࡳࡷࡨࠫਤ"):
        xbmcaddon.Addon(addon).setSetting(l11l1_opy_ (u"ࠧࡨࡧࡱࡶࡪ࠭ਥ"), l11l1_opy_ (u"ࠨࡶࡵࡹࡪ࠭ਦ"))
    if xbmcgui.Window(10000).getProperty(l11l1_opy_ (u"ࠩࡓࡐ࡚ࡍࡉࡏࡡࡗ࡚ࡌ࡛ࡉࡅࡇࠪਧ")) == l11l1_opy_ (u"ࠪࡘࡷࡻࡥࠨਨ"):
        xbmcaddon.Addon(addon).setSetting(l11l1_opy_ (u"ࠫࡹࡼࡧࡶ࡫ࡧࡩࠬ਩"), l11l1_opy_ (u"ࠬࡺࡲࡶࡧࠪਪ"))
    return result[l11l1_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬਫ")]
def l1l1111ll_opy_(addon):
    if (addon == l11lll11l_opy_) or (addon == l11ll1l1l_opy_):
        return l11l1_opy_ (u"ࠧ࠰ࡁࡦࡥࡹࡃ࠭࠳ࠨࡧࡥࡹ࡫ࠦࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠫ࡫࡮ࡥࡆࡤࡸࡪࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࠩࡱࡴࡪࡥ࠾࠴ࠩࡲࡦࡳࡥ࠾ࡏࡼࠩ࠷࠶ࡃࡩࡣࡱࡲࡪࡲࡳࠧࡴࡨࡧࡴࡸࡤ࡯ࡣࡰࡩࠫࡹࡴࡢࡴࡷࡈࡦࡺࡥࠧࡷࡵࡰࡂࡻࡲ࡭ࠩਬ")
    if addon == l11l1lll1_opy_:
        return l11l1_opy_ (u"ࠨ࠱ࡂࡥࡨࡺࡩࡰࡰࡀࡰ࡮ࡼࡥࡵࡸࡢࡥࡱࡲࠦࡦࡺࡷࡶࡦࠬࡰࡢࡩࡨࠪࡵࡲ࡯ࡵࠨࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡂࠬࡴࡪࡶ࡯ࡩࡂࡇ࡬࡭ࠧ࠵࠴ࡨ࡮ࡡ࡯ࡰࡨࡰࡸࠬࡵࡳ࡮ࠪਭ")
    return l11l1_opy_ (u"ࠩࠪਮ")
def l111l1l_opy_():
    modules = map(__import__, [l1lll111_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11l1ll_opy_)):
        return l11l1_opy_ (u"ࠪࡘࡷࡻࡥࠨਯ")
    if len(modules[-1].Window(10**4).getProperty(l11l1l1_opy_)):
        return l11l1_opy_ (u"࡙ࠫࡸࡵࡦࠩਰ")
    return l11l1_opy_ (u"ࠬࡌࡡ࡭ࡵࡨࠫ਱")
def l1llllll_opy_(e, addon):
    l111ll1_opy_ = l11l1_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠱ࠦࡡ࡯ࠢࡨࡶࡷࡵࡲࠡࡱࡦࡧࡺࡸࡥࡥ࠼ࠣࡎࡘࡕࡎࠡࡇࡵࡶࡴࡸ࠺ࠡࠧࡶ࠰ࠥࠫࡳࠨਲ")  % (e, addon)
    l11ll11_opy_ = l11l1_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡤࡱࡱࡸࡦࡩࡴࠡࡷࡶࠤࡴࡴࠠࡵࡪࡨࠤ࡫ࡵࡲࡶ࡯࠱ࠫਲ਼")
    l11l111_opy_ = l11l1_opy_ (u"ࠨࡗࡳࡰࡴࡧࡤࠡࡣࠣࡰࡴ࡭ࠠࡷ࡫ࡤࠤࡹ࡮ࡥࠡࡣࡧࡨࡴࡴࠠࡴࡧࡷࡸ࡮ࡴࡧࡴࠢࡤࡲࡩࠦࡰࡰࡵࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰ࠴ࠧ਴")
    dixie.log(addon)
    dixie.log(e)
def getPlaylist():
    import requests
    l11lll1l1_opy_ = [l11l1_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡻ࠲ࡨࡵ࠯ࡉࡇ࡝࠹࡟ࡿࡩࡋࡧ࡚ࠫਵ"), l11l1_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡼ࠳ࡩ࡯࠰ࡺࡩ࠹ࡎ࠹ࡈࡐࡦ࡜ࡒࠬਸ਼"), l11l1_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱ࡘࡐࡨ࠶࠱ࡎࡑࡏ࡫ࡈ࠭਷"), l11l1_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲࡮ࡺࡔࡍࡏࡩࡺ࡮ࡕ࠶ࠧਸ"), l11l1_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳ࡩࡰࡂࡢ࠳ࡱࡺ࠾ࡍࡺࠨਹ"), l11l1_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡹ࠰ࡦࡳ࠴ࡴࡖࡴࡳࡦ࡫ࡨࡩ࠹ࡺࠩ਺"), l11l1_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡺ࠱ࡧࡴ࠵ࡸࡍࡅ࠼࠸ࡊ࡜ࡑࡷ࡛ࠪ਻"), l11l1_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡻ࠲ࡨࡵ࠯ࡵࡵࡈ࠷ࡏࡖࡴࡧࡏࡵ਼ࠫ"), l11l1_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡼ࠳ࡩ࡯࠰ࡧ࡙࡚ࡆࡽࡋࡊࡵࡖ࡬ࠬ਽"), l11l1_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱ࡻࡕࡵࡌࡊࡘࡩ࡬࡫࡯࠭ਾ")]
    l11ll11ll_opy_ =  l11l1_opy_ (u"ࠬࠩࡅ࡙ࡖࡐ࠷࡚࠭ਿ")
    for url in l11lll1l1_opy_:
        try:
            request  = requests.get(url)
            l1l11111l_opy_ = request.text
        except: pass
        if l11ll11ll_opy_ in l1l11111l_opy_:
            path = os.path.join(dixie.PROFILE, l11l1_opy_ (u"࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴ࠯࡯࠶ࡹࠬੀ"))
            with open(path, l11l1_opy_ (u"ࠧࡸࠩੁ")) as f:
                f.write(l1l11111l_opy_)
                break
def l11ll111l_opy_(addon):
    l11ll1l11_opy_ = l11l1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫੂ") + addon
    l11l1l1ll_opy_  = l11l1_opy_ (u"ࠩࡂࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁ࡭ࡺࡴࡱࠧ࠶ࡥࠪ࠸ࡦࠦ࠴ࡩࡱࡪࡺࡡ࡭࡭ࡨࡸࡹࡲࡥ࠯ࡥࡲࠩ࠷࡬ࡕࡌࡖࡸࡶࡰ࠷࠸࠱࠴࠵࠴࠶࠼ࠥ࠳ࡨࡷ࡬ࡺࡳࡢࡴࠧ࠵ࡪࡳ࡫ࡷࠦ࠴ࡩ࡙ࡰࠫ࠲࠶࠴࠳ࡸࡺࡸ࡫ࠦ࠴࠸࠶࠵ࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠧ࠵࠹࠷࠶࡬ࡪࡸࡨࠩ࠷࠻࠲࠱ࡶࡹ࠲࡯ࡶࡧࠧ࡯ࡲࡨࡪࡃ࠱ࠧࡰࡤࡱࡪࡃࡌࡪࡸࡨࠩ࠷࠶ࡔࡗࠨࡸࡶࡱࡃࡨࡵࡶࡳࠩ࠸ࡧࠥ࠳ࡨࠨ࠶࡫ࡳࡥࡵࡣ࡯࡯ࡪࡺࡴ࡭ࡧ࠱ࡧࡴࠫ࠲ࡧࡗࡎࡘࡺࡸ࡫࠲࠺࠳࠶࠷࠶࠱࠷ࠧ࠵ࡪࡑ࡯ࡶࡦࠧ࠵࠹࠷࠶ࡔࡗ࠰ࡷࡼࡹ࠭੃")
    l1111ll_opy_  = []
    l1111ll_opy_ += sendJSON(l11ll1l11_opy_ + l11l1l1ll_opy_, addon)
    l1111ll_opy_.sort()
    return l1111ll_opy_
def l1l1111l1_opy_(addon):
    l11ll1l11_opy_ = l11l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭੄") + addon
    l11l1l1ll_opy_ = l11l1_opy_ (u"ࠫ࠴ࡅࡦࡢࡰࡤࡶࡹࡃࡨࡵࡶࡳࠩ࠸ࡧࠥ࠳ࡨࠨ࠶࡫࡭࡯ࡰ࠰ࡪࡰࠪ࠸ࡦ࡙ࡦࡉ࠶࠽࡚ࠦ࡮ࡱࡧࡩࡂ࠷ࠦ࡯ࡣࡰࡩࡂࡒࡩࡷࡧࠨ࠶࠵࡛ࡋࠦ࠴࠳ࡗࡵࡵࡲࡵࡵࠩࡹࡷࡲ࠽ࡩࡶࡷࡴࡸࠫ࠳ࡢࠧ࠵ࡪࠪ࠸ࡦࡨࡱࡲ࠲࡬ࡲࠥ࠳ࡨ࠸ࡵࡖ࡭ࡅ࠵ࠩ੅")
    l11l1ll1l_opy_ = l11l1_opy_ (u"ࠬ࠵࠿ࡧࡣࡱࡥࡷࡺ࠽ࡩࡶࡷࡴࡸࠫ࠳ࡢࠧ࠵ࡪࠪ࠸ࡦࡨࡱࡲ࠲࡬ࡲࠥ࠳ࡨࡉ࡫࡜ࡓ࡫࡛ࠨࡰࡳࡩ࡫࠽࠲ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡹࡩࠪ࠸࠰ࡖࡕࠨ࠶࡫ࡉࡁࡏࠧ࠵࠴ࡘࡶ࡯ࡳࡶࡶࠪࡺࡸ࡬࠾ࡪࡷࡸࡵࡹࠥ࠴ࡣࠨ࠶࡫ࠫ࠲ࡧࡩࡲࡳ࠳࡭࡬ࠦ࠴ࡩࡪ࠾ࡰࡧ࠹ࡐࠪ੆")
    l1111ll_opy_  = []
    l1111ll_opy_ += sendJSON(l11ll1l11_opy_ + l11l1l1ll_opy_, addon)
    l1111ll_opy_ += sendJSON(l11ll1l11_opy_ + l11l1ll1l_opy_, addon)
    return l1111ll_opy_
def getPluginInfo(streamurl):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l11l1llll_opy_   = l11l1_opy_ (u"࠭ࡋࡰࡦ࡬ࠤࡕ࡜ࡒࠨੇ")
            l11ll11l1_opy_ = os.path.join(dixie.RESOURCES, l11l1_opy_ (u"ࠧ࡬ࡱࡧ࡭࠲ࡶࡶࡳ࠰ࡳࡲ࡬࠭ੈ"))
            return l11l1llll_opy_, l11ll11l1_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l11l1_opy_ (u"ࠨࡴࡷࡱࡵ࠭੉")) or url.startswith(l11l1_opy_ (u"ࠩࡵࡸࡲࡶࡥࠨ੊")) or url.startswith(l11l1_opy_ (u"ࠪࡶࡹࡹࡰࠨੋ")) or url.startswith(l11l1_opy_ (u"ࠫ࡭ࡺࡴࡱࠩੌ")):
            l11l1llll_opy_   = l11l1_opy_ (u"ࠬࡳ࠳ࡶࠢࡓࡰࡦࡿ࡬ࡪࡵࡷ੍ࠫ")
            l11ll11l1_opy_ = os.path.join(dixie.RESOURCES, l11l1_opy_ (u"࠭ࡩࡱࡶࡹ࠱ࡵࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡰ࡯ࡩࠪ੎"))
            return l11l1llll_opy_, l11ll11l1_opy_
    except:
        pass
    if streamurl.startswith(dixie.OPEN_OTT):
        l11lll111_opy_ = streamurl.split(l11l1_opy_ (u"ࠧ࡞ࡑࡗࡘࡤࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ੏"), 1)[-1].split(l11l1_opy_ (u"ࠨ࠱ࠪ੐"), 1)[0]
    if l11l1_opy_ (u"ࠩࡠࡓ࡙࡚࡟ࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪੑ") in streamurl:
        l11lll111_opy_ = streamurl.split(l11l1_opy_ (u"ࠪࡡࡔ࡚ࡔࡠࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫ੒"), 1)[-1].split(l11l1_opy_ (u"ࠫ࠴࠭੓"), 1)[0]
    if streamurl.startswith(l11l1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ੔")):
        l11lll111_opy_ = streamurl.split(l11l1_opy_ (u"࠭࠯࠰ࠩ੕"), 1)[-1].split(l11l1_opy_ (u"ࠧ࠰ࠩ੖"), 1)[0]
    if l11l1_opy_ (u"ࠨࡡࡢࡗࡋࡥ࡟ࠨ੗") in streamurl:
        l11lll111_opy_ = l11l1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡳࡶࡴ࡭ࡲࡢ࡯࠱ࡷࡺࡶࡥࡳ࠰ࡩࡥࡻࡵࡵࡳ࡫ࡷࡩࡸ࠭੘")
    if l11l1_opy_ (u"ࠪࡌࡉ࡚ࡖ࠻ࠩਖ਼") in streamurl:
        l11lll111_opy_ = l11l1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡲࡧࡲࡵࡪࡸࡦࠬਗ਼")
    if l11l1_opy_ (u"ࠬࡎࡄࡕࡘ࠵࠾ࠬਜ਼") in streamurl:
        l11lll111_opy_ = l11l1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡵࡺࡣ࠵ࠫੜ")
    if l11l1_opy_ (u"ࠧࡉࡆࡗ࡚࠸ࡀࠧ੝") in streamurl:
        l11lll111_opy_ = l11l1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥ࠷࠭ਫ਼")
    if l11l1_opy_ (u"ࠩࡋࡈ࡙࡜࠴࠻ࠩ੟") in streamurl:
        l11lll111_opy_ = l11l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡰࠬ੠")
    if l11l1_opy_ (u"ࠫࡎࡖࡌࡂ࡛࠽ࠫ੡") in streamurl:
        l11lll111_opy_ = l11l1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡧࡨࡣࡪࡲ࡯ࡥࡾ࡫ࡲࠨ੢")
    if l11l1_opy_ (u"࠭ࡉࡑࡎࡄ࡝࠷ࡀࠧ੣") in streamurl:
        l11lll111_opy_ = l11l1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱ࡮ࡤࡽࡪࡸࡷࡸࡹࠪ੤")
    if l11l1_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡒ࠻ࠩ੥") in streamurl:
        l11lll111_opy_ = l11l1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡰࡦࡿࡥࡳࡹࡺࡻࠬ੦")
    if l11l1_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡋࡗ࡚࠿࠭੧") in streamurl:
        l11lll111_opy_ = l11l1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡹࡼࠧ੨")
    if l11l1_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡈ࠿࠭੩") in streamurl:
        l11lll111_opy_ = l11l1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡪࡥࡹࠩ੪")
    if l11l1_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡘࡂ࠻ࠩ੫") in streamurl:
        l11lll111_opy_ = l11l1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡧࡥࡳࡴࡺࠧ੬")
    if l11l1_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡄࡎࡘ࠾ࠬ੭") in streamurl:
        l11lll111_opy_ = l11l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡦࡰࡺ࡯ࡰࡵࡸࠪ੮")
    if l11l1_opy_ (u"ࠫࡎࡖࡔࡔࠩ੯") in streamurl:
        l11lll111_opy_ = l11l1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢ࡫ࡳࡸࡻ࠭ੰ")
    if l11l1_opy_ (u"࠭ࡌࡊࡘࡈࡘ࡛ࡀࠧੱ") in streamurl:
        l11lll111_opy_ = l11l1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡬ࡪࡸࡨࡱ࡮ࡾࠧੲ")
    if l11l1_opy_ (u"ࠨࡈࡏࡅ࠿࠭ੳ") in streamurl:
        l11lll111_opy_ = l11l1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡈ࡯ࡥࡼࡲࡥࡴࡵࡗࡺࠬੴ")
    if l11l1_opy_ (u"ࠪࡊࡑࡇࡓ࠻ࠩੵ") in streamurl:
        l11lll111_opy_ = l11l1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡊࡱࡧࡷ࡭ࡧࡶࡷ࡙ࡼࠧ੶")
    if l11l1_opy_ (u"ࠬࡻࡰ࡯ࡲ࠽ࠫ੷") in streamurl:
        l11lll111_opy_ = l11l1_opy_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴ࡨࡥࡪࡲࡱࡪࡸࡵ࡯࠰ࡹ࡭ࡪࡽࠧ੸")
    return l11llll1l_opy_(l11lll111_opy_)
def l11llll1l_opy_(l11lll111_opy_):
    l11l1llll_opy_   = l11l1_opy_ (u"ࠧࠨ੹")
    l11ll11l1_opy_ = l11l1_opy_ (u"ࠨࠩ੺")
    if l11lll111_opy_ == l11l1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡦࡨࡼࠬ੻"):
        l11l1llll_opy_   = l11l1_opy_ (u"ࠪࡈࡪࡾࡴࡦࡴࡗ࡚ࠥࡒࡩࡵࡧࠪ੼")
        l11ll11l1_opy_ = xbmcaddon.Addon(l11lll111_opy_).getAddonInfo(l11l1_opy_ (u"ࠫ࡮ࡩ࡯࡯ࠩ੽"))
        return l11l1llll_opy_, l11ll11l1_opy_
    try:
        l11l1llll_opy_   = xbmcaddon.Addon(l11lll111_opy_).getAddonInfo(l11l1_opy_ (u"ࠬࡴࡡ࡮ࡧࠪ੾"))
        l11ll11l1_opy_ = xbmcaddon.Addon(l11lll111_opy_).getAddonInfo(l11l1_opy_ (u"࠭ࡩࡤࡱࡱࠫ੿"))
        return l11l1llll_opy_, l11ll11l1_opy_
    except:
        l11l1llll_opy_   = l11l1_opy_ (u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡕࡲࡹࡷࡩࡥࠨ઀")
        l11ll11l1_opy_ =  dixie.ICON
        return l11l1llll_opy_, l11ll11l1_opy_
    return l11l1llll_opy_, l11ll11l1_opy_
def selectStream(url, channel):
    url = url.replace(l11l1_opy_ (u"ࠨࡾࡸࡷࡪࡸ࠭ࡢࡩࡨࡲࡹ࠭ઁ"), l11l1_opy_ (u"ࠩ࠰࠱ࡺࡹࡥࡳ࠯ࡤ࡫ࡪࡴࡴࠨં"))
    l1lll1ll_opy_ = url.split(l11l1_opy_ (u"ࠪࢀࠬઃ"))
    if len(l1lll1ll_opy_) == 0:
        return None
    options, l1lll11l_opy_ = getOptions(l1lll1ll_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l1lll1ll_opy_) == 1:
            return l1lll11l_opy_[0]
    import selectDialog
    l11lll1ll_opy_ = selectDialog.select(l11l1_opy_ (u"ࠫࡘ࡫࡬ࡦࡥࡷࠤࡦࠦࡳࡵࡴࡨࡥࡲ࠭઄"), options)
    if l11lll1ll_opy_ < 0:
        raise Exception(l11l1_opy_ (u"࡙ࠬࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡࡅࡤࡲࡨ࡫࡬ࠨઅ"))
    return l1lll11l_opy_[l11lll1ll_opy_]
def getOptions(l1lll1ll_opy_, channel, addmore=True):
    options = []
    l1lll11l_opy_    = []
    for index, stream in enumerate(l1lll1ll_opy_):
        l11l1llll_opy_ = getPluginInfo(stream)
        l1l11_opy_ = l11l1llll_opy_[0]
        l11ll1ll1_opy_  = l11l1llll_opy_[1]
        l1l11_opy_ = l11l1_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡯ࡳࡣࡱ࡫ࡪࡣ࡛ࠨઆ") + l1l11_opy_ + l11l1_opy_ (u"ࠧ࡞࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࠫઇ")
        if stream.startswith(OPEN_OTT):
            l1l11_opy_  = l1l11_opy_ + stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l11l1_opy_ (u"ࠨࠩઈ"))
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l11l1_opy_ (u"ࠩࠪઉ"))
        else:
            l1l11_opy_  = l1l11_opy_ + channel
        options.append([l1l11_opy_, index, l11ll1ll1_opy_])
        l1lll11l_opy_.append(stream)
    if addmore:
        options.append([l11l1_opy_ (u"ࠪࡅࡩࡪࠠ࡮ࡱࡵࡩ࠳࠴࠮ࠨઊ"), index + 1, dixie.ICON])
        l1lll11l_opy_.append(l11l1_opy_ (u"ࠫࡦࡪࡤࡎࡱࡵࡩࠬઋ"))
    return options, l1lll11l_opy_
if __name__ == l11l1_opy_ (u"ࠬࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠧઌ"):
    checkAddons()
    getPlaylist()