# -*- coding: utf-8 -*-
import sys
l1l111_opy_ = sys.version_info [0] == 2
l11l11_opy_ = 2048
l11l1_opy_ = 7
def l1l1ll_opy_ (ll_opy_):
	global l11lll_opy_
	l11ll_opy_ = ord (ll_opy_ [-1])
	l1l11ll_opy_ = ll_opy_ [:-1]
	l1l1_opy_ = l11ll_opy_ % len (l1l11ll_opy_)
	l11l_opy_ = l1l11ll_opy_ [:l1l1_opy_] + l1l11ll_opy_ [l1l1_opy_:]
	if l1l111_opy_:
		l11111_opy_ = unicode () .join ([unichr (ord (char) - l11l11_opy_ - (l1lll1_opy_ + l11ll_opy_) % l11l1_opy_) for l1lll1_opy_, char in enumerate (l11l_opy_)])
	else:
		l11111_opy_ = str () .join ([chr (ord (char) - l11l11_opy_ - (l1lll1_opy_ + l11ll_opy_) % l11l1_opy_) for l1lll1_opy_, char in enumerate (l11l_opy_)])
	return eval (l11111_opy_)
import os
import dixie
l1111_opy_ = dixie.PROFILE
def loadPlaylists():
    dixie.log(l1l1ll_opy_ (u"ࠨ࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠡࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠤࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࠪঽ"))
    source = dixie.GetSetting(l1l1ll_opy_ (u"ࠩ࡬ࡴࡹࡼ࠮ࡴࡱࡸࡶࡨ࡫ࠧা"))
    dixie.log(source)
    if source == l1l1ll_opy_ (u"ࠪ࠵ࠬি"):
        return l11ll1111_opy_()
    return l11ll1l1l_opy_()
def l11ll1l1l_opy_():
    dixie.log(l1l1ll_opy_ (u"ࠫࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࠤࡓࡋࡗࠡ࡮ࡲࡥࡩࡏࡐࡕࡘࠣࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠩী"))
    l11lll11l_opy_ = []
    if dixie.GetSetting(l1l1ll_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠴ࠬু")) == l1l1ll_opy_ (u"࠭ࡴࡳࡷࡨࠫূ"):
        l11ll1ll1_opy_  = dixie.GetSetting(l1l1ll_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠶࡟ࡖࡔࡏࠫৃ"))
        l11l1l1ll_opy_ = dixie.GetSetting(l1l1ll_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠰ࡠࡒࡒࡖ࡙࠭ৄ"))
        l11ll11ll_opy_ = dixie.GetSetting(l1l1ll_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠱ࡡࡗ࡝ࡕࡋࠧ৅"))
        l11l1ll1l_opy_ = dixie.GetSetting(l1l1ll_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠲ࡢ࡙ࡘࡋࡒࠨ৆"))
        l11l1llll_opy_ = dixie.GetSetting(l1l1ll_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠳ࡣࡕࡇࡓࡔࠩে"))
        l11l11lll_opy_ = l11l1ll11_opy_(l11ll1ll1_opy_, l11l1l1ll_opy_, l11ll11ll_opy_, l11l1ll1l_opy_, l11l1llll_opy_)
        l11lll11l_opy_.append((l11l11lll_opy_, l1l1ll_opy_ (u"ࠬࡏࡐࡕࡘ࠴࠾ࠥ࠭ৈ")))
    if dixie.GetSetting(l1l1ll_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠶࠭৉")) == l1l1ll_opy_ (u"ࠧࡵࡴࡸࡩࠬ৊"):
        l11ll1ll1_opy_  = dixie.GetSetting(l1l1ll_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠱ࡠࡗࡕࡐࠬো"))
        l11l1l1ll_opy_ = dixie.GetSetting(l1l1ll_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠲ࡡࡓࡓࡗ࡚ࠧৌ"))
        l11ll11ll_opy_ = dixie.GetSetting(l1l1ll_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠳ࡢࡘ࡞ࡖࡅࠨ্"))
        l11l1ll1l_opy_ = dixie.GetSetting(l1l1ll_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠴ࡣ࡚࡙ࡅࡓࠩৎ"))
        l11l1llll_opy_ = dixie.GetSetting(l1l1ll_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠵ࡤࡖࡁࡔࡕࠪ৏"))
        l11l1l1l1_opy_ = l11l1ll11_opy_(l11ll1ll1_opy_, l11l1l1ll_opy_, l11ll11ll_opy_, l11l1ll1l_opy_, l11l1llll_opy_)
        l11lll11l_opy_.append((l11l1l1l1_opy_, l1l1ll_opy_ (u"࠭ࡉࡑࡖ࡙࠶࠿ࠦࠧ৐")))
    if dixie.GetSetting(l1l1ll_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠸ࠧ৑")) == l1l1ll_opy_ (u"ࠨࡶࡵࡹࡪ࠭৒"):
        l11ll1ll1_opy_  = dixie.GetSetting(l1l1ll_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠳ࡡࡘࡖࡑ࠭৓"))
        l11l1l1ll_opy_ = dixie.GetSetting(l1l1ll_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠴ࡢࡔࡔࡘࡔࠨ৔"))
        l11ll11ll_opy_ = dixie.GetSetting(l1l1ll_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠵ࡣ࡙࡟ࡐࡆࠩ৕"))
        l11l1ll1l_opy_ = dixie.GetSetting(l1l1ll_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠶ࡤ࡛ࡓࡆࡔࠪ৖"))
        l11l1llll_opy_ = dixie.GetSetting(l1l1ll_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠷ࡥࡐࡂࡕࡖࠫৗ"))
        l11l1l11l_opy_ = l11l1ll11_opy_(l11ll1ll1_opy_, l11l1l1ll_opy_, l11ll11ll_opy_, l11l1ll1l_opy_, l11l1llll_opy_)
        l11lll11l_opy_.append((l11l1l11l_opy_, l1l1ll_opy_ (u"ࠧࡊࡒࡗ࡚࠸ࡀࠠࠨ৘")))
    dixie.log(l11lll11l_opy_)
    playlists = []
    for item in l11lll11l_opy_:
        url = item[0]
        l11ll111l_opy_ = item[1]
        l11ll1lll_opy_ = l11ll1l11_opy_(url, l11ll111l_opy_)
        playlists.extend(l11ll1lll_opy_)
    return playlists
def l11l1ll11_opy_(l11ll1ll1_opy_, l11l1l1ll_opy_, l11ll11ll_opy_, l11l1ll1l_opy_, l11l1llll_opy_):
    url  = l1l1ll_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩ৙")
    url +=  l11ll1ll1_opy_
    url +=  l11l11ll1_opy_(l11l1l1ll_opy_)
    url += l1l1ll_opy_ (u"ࠩ࠲࡫ࡪࡺ࠮ࡱࡪࡳࡃࡺࡹࡥࡳࡰࡤࡱࡪࡃࠧ৚")
    url +=  l11l1ll1l_opy_
    url += l1l1ll_opy_ (u"ࠪࠪࡵࡧࡳࡴࡹࡲࡶࡩࡃࠧ৛")
    url +=  l11l1llll_opy_
    url += l1l1ll_opy_ (u"ࠫࠫࡺࡹࡱࡧࡀࡱ࠸ࡻ࡟ࡱ࡮ࡸࡷࠫࡵࡵࡵࡲࡸࡸࡂ࠭ড়")
    url +=  l11ll11l1_opy_(l11ll11ll_opy_)
    dixie.log(l1l1ll_opy_ (u"ࠬࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࠥࡨࡵࡪ࡮ࡧ࡙ࡗࡒࠠ࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂ࠭ঢ়"))
    dixie.log(url)
    return url
def l11l11ll1_opy_(l11l1l1ll_opy_):
    if not l11l1l1ll_opy_ == l1l1ll_opy_ (u"࠭ࠧ৞"):
        return l1l1ll_opy_ (u"ࠧ࠻ࠩয়") + l11l1l1ll_opy_
    return l1l1ll_opy_ (u"ࠨࠩৠ")
def l11ll11l1_opy_(l11ll11ll_opy_):
    if l11ll11ll_opy_ == l1l1ll_opy_ (u"ࠩ࠳ࠫৡ"):
        return l1l1ll_opy_ (u"ࠪࡱ࠸ࡻ࠸ࠨৢ")
    if l11ll11ll_opy_ == l1l1ll_opy_ (u"ࠫ࠶࠭ৣ"):
        return l1l1ll_opy_ (u"ࠬࡳࡰࡦࡩࡷࡷࠬ৤")
def l11ll1l11_opy_(url, l11ll111l_opy_):
    l11l1l111_opy_   = list()
    l1llll_opy_     = l1l1ll_opy_ (u"࠭ࠧ৥")
    value     = l1l1ll_opy_ (u"ࠧࠨ০")
    dixie.log(l1l1ll_opy_ (u"ࠨ࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡮ࡲࡥࡩࡖ࡬ࡢࡻ࡯࡭ࡸࡺࠠ࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂ࠭১"))
    import requests
    request = requests.get(url)
    for line in request.iter_lines():
        if line.startswith(l1l1ll_opy_ (u"ࠩࠦࡉ࡝࡚ࡉࡏࡈ࠽ࠫ২")):
            l1l1l11l_opy_ = line.split(l1l1ll_opy_ (u"ࠪ࠰ࠬ৩"))[-1].strip()
            l1l1l11l_opy_ = l1l1l11l_opy_.replace(l1l1ll_opy_ (u"࡚ࠫࡑࠧ৪"), l1l1ll_opy_ (u"ࠬ࠭৫")).replace(l1l1ll_opy_ (u"࠭࠺ࠡࠩ৬"), l1l1ll_opy_ (u"ࠧࠨ৭"))
            l1l1l11l_opy_ = l1l1l11l_opy_.replace(l1l1ll_opy_ (u"ࠨࡗࡖࡅࠬ৮"), l1l1ll_opy_ (u"ࠩࠪ৯")).replace(l1l1ll_opy_ (u"ࠪ࠾ࠥ࠭ৰ"), l1l1ll_opy_ (u"ࠫࠬৱ"))
            l1l1l11l_opy_ = l1l1l11l_opy_.replace(l1l1ll_opy_ (u"ࠬࡉࡁࠨ৲"), l1l1ll_opy_ (u"࠭ࠧ৳")).replace(l1l1ll_opy_ (u"ࠧ࠻ࠢࠪ৴"), l1l1ll_opy_ (u"ࠨࠩ৵"))
            l1l1l11l_opy_ = l1l1l11l_opy_.replace(l1l1ll_opy_ (u"ࠩࡌࡒ࡙࠭৶"), l1l1ll_opy_ (u"ࠪࠫ৷")).replace(l1l1ll_opy_ (u"ࠫ࠿ࠦࠧ৸"), l1l1ll_opy_ (u"ࠬ࠭৹"))
            l1llll_opy_ = dixie.mapChannelName(l1l1l11l_opy_)
            l1llll_opy_ = l11ll111l_opy_ + l1llll_opy_
        elif line.startswith(l1l1ll_opy_ (u"࠭ࡨࡵࡶࡳࠫ৺")):
            value = line.replace(l1l1ll_opy_ (u"ࠧ࡝ࡰࠪ৻"), l1l1ll_opy_ (u"ࠨࠩৼ"))
            l11l1l111_opy_.append((l1llll_opy_, value))
    return l11l1l111_opy_
def l11ll1111_opy_():
    dixie.log(l1l1ll_opy_ (u"ࠩࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡯ࡳࡦࡪࡌࡦࡩࡤࡧࡾࡏࡐࡕࡘࠣࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠩ৽"))
    l11lll111_opy_ = dixie.GetSetting(l1l1ll_opy_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡺࡹࡱࡧࠪ৾"))
    l11l1lll1_opy_  = l1l1ll_opy_ (u"ࠫ࠵࠭৿")
    l11l11l1l_opy_ = l1l1ll_opy_ (u"ࠬ࠷ࠧ਀")
    l11l1l111_opy_   = list()
    l1llll_opy_     = l1l1ll_opy_ (u"࠭ࠧਁ")
    value     = l1l1ll_opy_ (u"ࠧࠨਂ")
    if l11lll111_opy_ == l11l11l1l_opy_:
        path = os.path.join(dixie.GetSetting(l1l1ll_opy_ (u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡪ࡮ࡲࡥࠨਃ")))
    else:
        url  = dixie.GetSetting(l1l1ll_opy_ (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡺࡸ࡬ࠨ਄"))
        path = os.path.join(l1111_opy_, l1l1ll_opy_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡳ࠳ࡶࠩਅ"))
        if url == l1l1ll_opy_ (u"ࠫࠬਆ"):
            path = os.path.join(l1111_opy_, l1l1ll_opy_ (u"ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠮࡮࠵ࡸࠫਇ"))
        else:
            request  = requests.get(url)
            l11ll1lll_opy_ = request.content
            with open(path, l1l1ll_opy_ (u"࠭ࡷࡣࠩਈ")) as f:
                f.write(l11ll1lll_opy_)
    if os.path.exists(path):
        f = open(path)
        l11ll1lll_opy_ = f.readlines()
        f.close()
        for line in l11ll1lll_opy_:
            if line.startswith(l1l1ll_opy_ (u"ࠧࠤࡇ࡛ࡘࡎࡔࡆ࠻ࠩਉ")):
                l1llll_opy_ = line.split(l1l1ll_opy_ (u"ࠨ࠮ࠪਊ"))[-1].strip()
            elif line.startswith(l1l1ll_opy_ (u"ࠩࡵࡸࡲࡶࠧ਋")) or line.startswith(l1l1ll_opy_ (u"ࠪࡶࡹࡳࡰࡦࠩ਌")) or line.startswith(l1l1ll_opy_ (u"ࠫࡷࡺࡳࡱࠩ਍")) or line.startswith(l1l1ll_opy_ (u"ࠬ࡮ࡴࡵࡲࠪ਎")):
                value = line.replace(l1l1ll_opy_ (u"࠭ࡲࡵ࡯ࡳ࠾࠴࠵ࠤࡐࡒࡗ࠾ࡷࡺ࡭ࡱ࠯ࡵࡥࡼࡃࠧਏ"), l1l1ll_opy_ (u"ࠧࠨਐ")).replace(l1l1ll_opy_ (u"ࠨ࡞ࡱࠫ਑"), l1l1ll_opy_ (u"ࠩࠪ਒"))
                l11l1l111_opy_.append((l1llll_opy_, value))
        l11l1l111_opy_.sort()
        return l11l1l111_opy_