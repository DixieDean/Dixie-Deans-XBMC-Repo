# coding: UTF-8
import sys
l1llll_opy_ = sys.version_info [0] == 2
l1ll1_opy_ = 2048
l11l_opy_ = 7
def l11l1_opy_ (ll_opy_):
	global l1lll1_opy_
	l11ll1_opy_ = ord (ll_opy_ [-1])
	l1111_opy_ = ll_opy_ [:-1]
	l1_opy_ = l11ll1_opy_ % len (l1111_opy_)
	l1l1l1_opy_ = l1111_opy_ [:l1_opy_] + l1111_opy_ [l1_opy_:]
	if l1llll_opy_:
		l1ll11_opy_ = unicode () .join ([unichr (ord (char) - l1ll1_opy_ - (l11ll_opy_ + l11ll1_opy_) % l11l_opy_) for l11ll_opy_, char in enumerate (l1l1l1_opy_)])
	else:
		l1ll11_opy_ = str () .join ([chr (ord (char) - l1ll1_opy_ - (l11ll_opy_ + l11ll1_opy_) % l11l_opy_) for l11ll_opy_, char in enumerate (l1l1l1_opy_)])
	return eval (l1ll11_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l1ll11l1_opy_   = l11l1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡵࡴࡨࡥࡲࡺࡶࡣࡱࡻࠫࢫ")
l1ll111l_opy_     = l11l1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡲࡲࡶࡹࡹ࡭ࡢࡰ࡬ࡥࠬࢬ")
l1l1llll_opy_     = l11l1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡳࡳࡷࡺࡳ࡯ࡣࡷ࡭ࡴࡴࡨࡥࡶࡹࠫࢭ")
l1ll1l11_opy_ = l11l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡸࡷ࡫ࡡ࡮ࡵࡨࡥࡸࡿ࠮ࡵࡸࠪࢮ")
l1l111l_opy_ = [l1ll1l11_opy_, l1ll11l1_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l11l1_opy_ (u"ࠫ࡮ࡴࡩࠨࢯ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1lllll1_opy_ = l11l1_opy_ (u"ࠬ࠭ࢰ")
def l1lll111_opy_(i, t1, l1llll1l_opy_=[]):
 t = l1lllll1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1llll1l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11l1ll_opy_ = l1lll111_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11l1l1_opy_ = l1lll111_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1l111l_opy_:
        if l1ll1l1_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1ll1l1_opy_(addon):
    if xbmc.getCondVisibility(l11l1_opy_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡈࡢࡵࡄࡨࡩࡵ࡮ࠩࠧࡶ࠭ࠬࢱ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l11l11_opy_ = str(addon).split(l11l1_opy_ (u"ࠧ࠯ࠩࢲ"))[2] + l11l1_opy_ (u"ࠨ࠰࡬ࡲ࡮࠭ࢳ")
    l1l11l1_opy_  = os.path.join(PATH, l11l11_opy_)
    try:
        l1l_opy_ = l111ll_opy_(addon)
    except KeyError:
        dixie.log(l11l1_opy_ (u"ࠩ࠰࠱࠲࠳࠭ࠡࡍࡨࡽࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡧࡦࡶࡉ࡭ࡱ࡫ࡳࠡ࠯࠰࠱࠲࠳ࠠࠨࢴ") + addon)
        result = {l11l1_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࡵࠪࢵ"): [{l11l1_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧࢶ"): l11l1_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࠫࢷ"), l11l1_opy_ (u"ࡻࠧࡵࡻࡳࡩࠬࢸ"): l11l1_opy_ (u"ࡵࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩࢹ"), l11l1_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࠧࢺ"): l11l1_opy_ (u"ࡷࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡾࡸࠨࢻ"), l11l1_opy_ (u"ࡸࠫࡱࡧࡢࡦ࡮ࠪࢼ"): l11l1_opy_ (u"ࡹࠬࡔࡏࠡࡅࡋࡅࡓࡔࡅࡍࡕࠪࢽ")}], l11l1_opy_ (u"ࡺ࠭࡬ࡪ࡯࡬ࡸࡸ࠭ࢾ"):{l11l1_opy_ (u"ࡻࠧࡴࡶࡤࡶࡹ࠭ࢿ"): 0, l11l1_opy_ (u"ࡵࠨࡶࡲࡸࡦࡲࠧࣀ"): 1, l11l1_opy_ (u"ࡶࠩࡨࡲࡩ࠭ࣁ"): 1}}
    l1l11l_opy_  = file(l1l11l1_opy_, l11l1_opy_ (u"ࠩࡺࠫࣂ"))
    l1l11l_opy_.write(l11l1_opy_ (u"ࠪ࡟ࠬࣃ"))
    l1l11l_opy_.write(addon)
    l1l11l_opy_.write(l11l1_opy_ (u"ࠫࡢ࠭ࣄ"))
    l1l11l_opy_.write(l11l1_opy_ (u"ࠬࡢ࡮ࠨࣅ"))
    l1ll11l_opy_ = []
    for channel in l1l_opy_:
        l1l11_opy_ = channel[l11l1_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬࣆ")]
        l1l11_opy_ = l11l1l_opy_(l1l11_opy_)
        l1111l_opy_ = dixie.mapChannelName(l1l11_opy_)
        stream   = channel[l11l1_opy_ (u"ࠧࡧ࡫࡯ࡩࠬࣇ")]
        l1lllll_opy_ = l1111l_opy_ + l11l1_opy_ (u"ࠨ࠿ࠪࣈ") + stream
        l1ll11l_opy_.append(l1lllll_opy_)
        l1ll11l_opy_.sort()
    for item in l1ll11l_opy_:
        l1l11l_opy_.write(l11l1_opy_ (u"ࠤࠨࡷࡡࡴࠢࣉ") % item)
    l1l11l_opy_.close()
def l11l1l_opy_(name):
    import re
    name  = re.sub(l11l1_opy_ (u"ࠪࡠ࠭ࡡ࠰࠮࠻ࠬࡡ࠯ࡢࠩࠨ࣊"), l11l1_opy_ (u"ࠫࠬ࣋"), name)
    items = name.split(l11l1_opy_ (u"ࠬࡣࠧ࣌"))
    name  = l11l1_opy_ (u"࠭ࠧ࣍")
    for item in items:
        if len(item) == 0:
            continue
        item += l11l1_opy_ (u"ࠧ࡞ࠩ࣎")
        item  = re.sub(l11l1_opy_ (u"ࠨ࡞࡞࡟ࡣ࠯࡝ࠫ࡞ࡠ࣏ࠫ"), l11l1_opy_ (u"࣐ࠩࠪ"), item)
        if len(item) > 0:
            name += item
    name  = name.replace(l11l1_opy_ (u"ࠪ࡟࣑ࠬ"), l11l1_opy_ (u"࣒ࠫࠬ"))
    name  = name.replace(l11l1_opy_ (u"ࠬࡣ࣓ࠧ"), l11l1_opy_ (u"࠭ࠧࣔ"))
    name  = name.strip()
    while True:
        length = len(name)
        name = name.replace(l11l1_opy_ (u"ࠧࠡࠢࠪࣕ"), l11l1_opy_ (u"ࠨࠢࠪࣖ"))
        if length == len(name):
            break
    return name.strip()
def l111ll_opy_(addon):
    return l1ll1lll_opy_(addon)
def l1ll1lll_opy_(addon):
    if addon == l1ll1l11_opy_:
        l1ll1111_opy_ = [l11l1_opy_ (u"ࠩ࠴࠸࠶࠭ࣗ"), l11l1_opy_ (u"ࠪ࠵࠹࠸ࠧࣘ"), l11l1_opy_ (u"ࠫ࠶࠺࠵ࠨࣙ"), l11l1_opy_ (u"ࠬ࠷࠴࠸ࠩࣚ"), l11l1_opy_ (u"࠭࠲࠶࠹ࠪࣛ"), l11l1_opy_ (u"ࠧ࠳࠷࠻ࠫࣜ"), l11l1_opy_ (u"ࠨ࠴࠸࠽ࠬࣝ"), l11l1_opy_ (u"ࠩ࠵࠺࠵࠭ࣞ"), l11l1_opy_ (u"ࠪ࠶࠻࠺ࠧࣟ")]
    if addon == l1ll11l1_opy_:
        l1ll1111_opy_ = [l11l1_opy_ (u"ࠫ࠷࠻ࠧ࣠"), l11l1_opy_ (u"ࠬ࠸࠶ࠨ࣡"), l11l1_opy_ (u"࠭࠲࠸ࠩ࣢"), l11l1_opy_ (u"ࠧ࠳࠻ࣣࠪ"), l11l1_opy_ (u"ࠨ࠵࠳ࠫࣤ"), l11l1_opy_ (u"ࠩ࠶࠵ࠬࣥ"), l11l1_opy_ (u"ࠪ࠷࠷ࣦ࠭"), l11l1_opy_ (u"ࠫ࠸࠻ࠧࣧ"), l11l1_opy_ (u"ࠬ࠹࠶ࠨࣨ"), l11l1_opy_ (u"࠭࠳࠸ࣩࠩ"), l11l1_opy_ (u"ࠧ࠴࠺ࠪ࣪"), l11l1_opy_ (u"ࠨ࠵࠼ࠫ࣫"), l11l1_opy_ (u"ࠩ࠷࠴ࠬ࣬"), l11l1_opy_ (u"ࠪ࠸࠶࣭࠭"), l11l1_opy_ (u"ࠫ࠹࠾࣮ࠧ"), l11l1_opy_ (u"ࠬ࠺࠹ࠨ࣯"), l11l1_opy_ (u"࠭࠵࠱ࣰࠩ"), l11l1_opy_ (u"ࠧ࠶࠴ࣱࠪ"), l11l1_opy_ (u"ࠨ࠷࠷ࣲࠫ"), l11l1_opy_ (u"ࠩ࠸࠺ࠬࣳ"), l11l1_opy_ (u"ࠪ࠹࠼࠭ࣴ"), l11l1_opy_ (u"ࠫ࠺࠾ࠧࣵ"), l11l1_opy_ (u"ࠬ࠻࠹ࠨࣶ"), l11l1_opy_ (u"࠭࠶࠱ࠩࣷ"), l11l1_opy_ (u"ࠧ࠷࠳ࠪࣸ"), l11l1_opy_ (u"ࠨ࠸࠵ࣹࠫ"), l11l1_opy_ (u"ࠩ࠹࠷ࣺࠬ"), l11l1_opy_ (u"ࠪ࠺࠺࠭ࣻ"), l11l1_opy_ (u"ࠫ࠻࠼ࠧࣼ"), l11l1_opy_ (u"ࠬ࠼࠷ࠨࣽ"), l11l1_opy_ (u"࠭࠶࠺ࠩࣾ"), l11l1_opy_ (u"ࠧ࠸࠲ࠪࣿ"), l11l1_opy_ (u"ࠨ࠹࠷ࠫऀ"), l11l1_opy_ (u"ࠩ࠺࠻ࠬँ"), l11l1_opy_ (u"ࠪ࠻࠽࠭ं"), l11l1_opy_ (u"ࠫ࠽࠶ࠧः"), l11l1_opy_ (u"ࠬ࠾࠱ࠨऄ")]
    if (addon == l1ll111l_opy_) or (addon == l1l1llll_opy_):
        l1ll1111_opy_ = [l11l1_opy_ (u"࠭࠲࠶ࠩअ"), l11l1_opy_ (u"ࠧ࠳࠸ࠪआ"), l11l1_opy_ (u"ࠨ࠴࠺ࠫइ"), l11l1_opy_ (u"ࠩ࠵࠽ࠬई"), l11l1_opy_ (u"ࠪ࠷࠵࠭उ"), l11l1_opy_ (u"ࠫ࠸࠷ࠧऊ"), l11l1_opy_ (u"ࠬ࠹࠲ࠨऋ"), l11l1_opy_ (u"࠭࠳࠶ࠩऌ"), l11l1_opy_ (u"ࠧ࠴࠸ࠪऍ"), l11l1_opy_ (u"ࠨ࠵࠺ࠫऎ"), l11l1_opy_ (u"ࠩ࠶࠼ࠬए"), l11l1_opy_ (u"ࠪ࠷࠾࠭ऐ"), l11l1_opy_ (u"ࠫ࠹࠶ࠧऑ"), l11l1_opy_ (u"ࠬ࠺࠱ࠨऒ"), l11l1_opy_ (u"࠭࠴࠹ࠩओ"), l11l1_opy_ (u"ࠧ࠵࠻ࠪऔ"), l11l1_opy_ (u"ࠨ࠷࠳ࠫक"), l11l1_opy_ (u"ࠩ࠸࠶ࠬख"), l11l1_opy_ (u"ࠪ࠹࠹࠭ग"), l11l1_opy_ (u"ࠫ࠺࠼ࠧघ"), l11l1_opy_ (u"ࠬ࠻࠷ࠨङ"), l11l1_opy_ (u"࠭࠵࠹ࠩच"), l11l1_opy_ (u"ࠧ࠷࠲ࠪछ"), l11l1_opy_ (u"ࠨ࠸࠵ࠫज"), l11l1_opy_ (u"ࠩ࠹࠷ࠬझ"), l11l1_opy_ (u"ࠪ࠺࠺࠭ञ"), l11l1_opy_ (u"ࠫ࠻࠽ࠧट"), l11l1_opy_ (u"ࠬ࠼࠹ࠨठ"), l11l1_opy_ (u"࠭࠷࠱ࠩड"), l11l1_opy_ (u"ࠧ࠸࠶ࠪढ"), l11l1_opy_ (u"ࠨ࠹࠹ࠫण"), l11l1_opy_ (u"ࠩ࠺࠻ࠬत"), l11l1_opy_ (u"ࠪ࠻࠽࠭थ"), l11l1_opy_ (u"ࠫ࠽࠷ࠧद")]
    login = l11l1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠦࡵ࠲ࠫध") % addon
    sendJSON(login, addon)
    l1111ll_opy_ = []
    for l1ll1l1l_opy_ in l1ll1111_opy_:
        if addon == l1ll1l11_opy_:
            query = l11l1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶ࠳ࡄࡳ࡯ࡥࡧࡢ࡭ࡩࡃࡣࡩࡣࡱࡲࡪࡲࡳࠧ࡯ࡲࡨࡪࡃࡣࡩࡣࡱࡲࡪࡲࡳࠧࡵࡨࡧࡹ࡯࡯࡯ࡡ࡬ࡨࡂࠫࡳࠨन") % (addon, l1ll1l1l_opy_)
        if (addon == l1ll11l1_opy_) or (addon == l1ll111l_opy_) or (addon == l1l1llll_opy_):
            query = l11l1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷ࠴ࡅࡵࡳ࡮ࡀࠩࡸࠬ࡭ࡰࡦࡨࡁ࠹ࠬ࡮ࡢ࡯ࡨࡁࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡳࡰࡦࡿ࠽ࠧࡦࡤࡸࡪࡃࠦࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࡂࠬࡰࡢࡩࡨࡁࠬऩ") % (addon, l1ll1l1l_opy_)
        response = sendJSON(query, addon)
        l1111ll_opy_.extend(response)
    return l1111ll_opy_
def sendJSON(query, addon):
    try:
        l1ll11ll_opy_     = l11l1_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫप") % query
        l1ll1ll1_opy_  = xbmc.executeJSONRPC(l1ll11ll_opy_)
        response = json.loads(l1ll1ll1_opy_)
        result   = response[l11l1_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩफ")]
        if xbmcgui.Window(10000).getProperty(l11l1_opy_ (u"ࠪࡔࡑ࡛ࡇࡊࡐࡢࡋࡊࡔࡒࡆࠩब")) == l11l1_opy_ (u"࡙ࠫࡸࡵࡦࠩभ"):
            xbmcaddon.Addon(addon).setSetting(l11l1_opy_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫम"), l11l1_opy_ (u"࠭ࡴࡳࡷࡨࠫय"))
        if xbmcgui.Window(10000).getProperty(l11l1_opy_ (u"ࠧࡑࡎࡘࡋࡎࡔ࡟ࡕࡘࡊ࡙ࡎࡊࡅࠨर")) == l11l1_opy_ (u"ࠨࡖࡵࡹࡪ࠭ऱ"):
            xbmcaddon.Addon(addon).setSetting(l11l1_opy_ (u"ࠩࡷࡺ࡬ࡻࡩࡥࡧࠪल"), l11l1_opy_ (u"ࠪࡸࡷࡻࡥࠨळ"))
        return result[l11l1_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪऴ")]
    except:
        {l11l1_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࡷࠬव"): [{l11l1_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩश"): l11l1_opy_ (u"ࡵࠨࡨ࡬ࡰࡪ࠭ष"), l11l1_opy_ (u"ࡶࠩࡷࡽࡵ࡫ࠧस"): l11l1_opy_ (u"ࡷࠪࡹࡳࡱ࡮ࡰࡹࡱࠫह"), l11l1_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࠩऺ"): l11l1_opy_ (u"ࡹࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸࡹࡺࠪऻ"), l11l1_opy_ (u"ࡺ࠭࡬ࡢࡤࡨࡰ़ࠬ"): l11l1_opy_ (u"ࡻࠧࡏࡑࠣࡇࡍࡇࡎࡏࡇࡏࡗࠬऽ")}], l11l1_opy_ (u"ࡵࠨ࡮࡬ࡱ࡮ࡺࡳࠨा"):{l11l1_opy_ (u"ࡶࠩࡶࡸࡦࡸࡴࠨि"): 0, l11l1_opy_ (u"ࡷࠪࡸࡴࡺࡡ࡭ࠩी"): 1, l11l1_opy_ (u"ࡸࠫࡪࡴࡤࠨु"): 1}}
def l111l1l_opy_():
    modules = map(__import__, [l1lll111_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11l1ll_opy_)):
        return l11l1_opy_ (u"࡙ࠫࡸࡵࡦࠩू")
    if len(modules[-1].Window(10**4).getProperty(l11l1l1_opy_)):
        return l11l1_opy_ (u"࡚ࠬࡲࡶࡧࠪृ")
    return l11l1_opy_ (u"࠭ࡆࡢ࡮ࡶࡩࠬॄ")
def l1llllll_opy_(e, addon):
    l111ll1_opy_ = l11l1_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠲ࠠࡢࡰࠣࡩࡷࡸ࡯ࡳࠢࡲࡧࡨࡻࡲࡦࡦ࠽ࠤࡏ࡙ࡏࡏࠢࡈࡶࡷࡵࡲ࠻ࠢࠨࡷ࠱ࠦࠥࡴࠩॅ")  % (e, addon)
    l11ll11_opy_ = l11l1_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡥࡲࡲࡹࡧࡣࡵࠢࡸࡷࠥࡵ࡮ࠡࡶ࡫ࡩࠥ࡬࡯ࡳࡷࡰ࠲ࠬॆ")
    l11l111_opy_ = l11l1_opy_ (u"ࠩࡘࡴࡱࡵࡡࡥࠢࡤࠤࡱࡵࡧࠡࡸ࡬ࡥࠥࡺࡨࡦࠢࡤࡨࡩࡵ࡮ࠡࡵࡨࡸࡹ࡯࡮ࡨࡵࠣࡥࡳࡪࠠࡱࡱࡶࡸࠥࡺࡨࡦࠢ࡯࡭ࡳࡱ࠮ࠨे")
    dixie.log(addon)
    dixie.log(e)
if __name__ == l11l1_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬै"):
    checkAddons()