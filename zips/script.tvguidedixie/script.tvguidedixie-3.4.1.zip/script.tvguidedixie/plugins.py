# coding: UTF-8

import sys

l1llll11 = sys.version_info [0] == 2
l1ll111 = 2048
l1lll1 = 7

def l1111l (ll):
	global l111
	
	l1111l1 = ord (ll [-1])
	l1lllll1 = ll [:-1]
	
	l1ll1 = l1111l1 % len (l1lllll1)
	l11l11l = l1lllll1 [:l1ll1] + l1lllll1 [l1ll1:]
		
	if l1llll11:
		l1l1l1l = unicode () .join ([unichr (ord (char) - l1ll111 - (l11l1l + l1111l1) % l1lll1) for l11l1l, char in enumerate (l11l11l)])
	else:
		l1l1l1l = str () .join ([chr (ord (char) - l1ll111 - (l11l1l + l1111l1) % l1lll1) for l11l1l, char in enumerate (l11l11l)])
		
	return eval (l1l1l1l)


import xbmc
import xbmcaddon
import json
import os
import shutil
import dixie

l1l111l1l     = l1111l (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡴࡴࡷࠩࣆ")
l1l1l1111     = l1111l (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡵ࡬ࡶࡸࡶࡰ࠭ࣇ")


l11llll11 = [l1l111l1l, l1l1l1111]

HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1111l (u"ࠨ࡫ࡱ࡭ࠬࣈ"))


def checkAddons():
    for l11l1l1 in l11llll11:
        if l11llll1l(l11l1l1):
            try: l1l11l11l(l11l1l1)
            except: pass


def l11llll1l(l11l1l1):
    if xbmc.getCondVisibility(l1111l (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡋࡥࡸࡇࡤࡥࡱࡱࠬࠪࡹࠩࠨࣉ") % l11l1l1) == 1:
        return True
    return False


def l1l11l11l(l11l1l1):
    l1l1l11ll = l1l11l1l1(l11l1l1) + l1111l (u"ࠪ࠲࡮ࡴࡩࠨ࣊")
    l1l11l111  = os.path.join(PATH, l1l1l11ll)

    l1lll11l = l1l1l1lll(l11l1l1)

    l1l1l1l1l  = file(l1l11l111, l1111l (u"ࠫࡼ࠭࣋"))

    l1l1l1l1l.write(l1111l (u"ࠬࡡࠧ࣌"))
    l1l1l1l1l.write(l11l1l1)
    l1l1l1l1l.write(l1111l (u"࠭࡝ࠨ࣍"))
    l1l1l1l1l.write(l1111l (u"ࠧ࡝ࡰࠪ࣎"))

    for l1llll1 in l1lll11l:
        l1l11ll11   = l1llll1[l1111l (u"ࠨ࡮ࡤࡦࡪࡲ࣏ࠧ")]


        l1l11ll11 = l1l11ll11.replace(l1111l (u"ࠩࠣ࡟࣐ࠬ"), l1111l (u"ࠪ࡟࣑ࠬ")).replace(l1111l (u"ࠫࡢ࣒ࠦࠧ"), l1111l (u"ࠬࡣ࣓ࠧ")).replace(l1111l (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡡࡲࡷࡤࡡࠬࣔ"), l1111l (u"ࠧࠨࣕ")).replace(l1111l (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬ࡱࡪ࡭ࡲࡦࡧࡱࡡࠬࣖ"), l1111l (u"ࠩࠪࣗ")).replace(l1111l (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡽࡪࡲ࡬ࡰࡹࡠࠫࣘ"), l1111l (u"ࠫࠬࣙ")).replace(l1111l (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡨ࡬ࡶࡧࡠࠫࣚ"), l1111l (u"࠭ࠧࣛ")).replace(l1111l (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡰࡴࡤࡲ࡬࡫࡝ࠨࣜ"), l1111l (u"ࠨࠩࣝ")).replace(l1111l (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡵࡩࡩࡣࠧࣞ"), l1111l (u"ࠪࠫࣟ")).replace(l1111l (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡼ࡮ࡩࡵࡧࡠࠫ࣠"), l1111l (u"ࠬ࠭࣡")).replace(l1111l (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ࣢"), l1111l (u"ࠧࠨࣣ"))

        stream  = l1llll1[l1111l (u"ࠨࡨ࡬ࡰࡪ࠭ࣤ")]

        l1l1l1l1l.write(l1111l (u"ࠩࠨࡷࠬࣥ") % l1l11ll11)
        l1l1l1l1l.write(l1111l (u"ࠪࡁࣦࠬ"))
        l1l1l1l1l.write(l1111l (u"ࠫࠪࡹࠧࣧ") % stream)
        l1l1l1l1l.write(l1111l (u"ࠬࡢ࡮ࠨࣨ"))

    l1l1l1l1l.write(l1111l (u"࠭࡜࡯ࣩࠩ"))
    l1l1l1l1l.close()


def l1l11l1l1(l11l1l1):
    if l11l1l1 == l1l111l1l:
        return l1111l (u"ࠧ࡯ࡶࡹࠫ࣪")

    if l11l1l1 == l1l1l1111:
        return l1111l (u"ࠨࡷ࡮ࡸࠬ࣫")


def l1l1l1lll(l11l1l1):
    if l11l1l1 == l1l1l1111:
        return l1l111l11(l11l1l1)


    if l11l1l1 == l1l111l1l:
        xbmcaddon.Addon(l1l111l1l).setSetting(l1111l (u"ࠩࡪࡩࡳࡸࡥࠨ࣬"), l1111l (u"ࠪࡪࡦࡲࡳࡦ࣭ࠩ"))
        xbmcaddon.Addon(l1l111l1l).setSetting(l1111l (u"ࠫࡹࡼࡧࡶ࡫ࡧࡩ࣮ࠬ"), l1111l (u"ࠬ࡬ࡡ࡭ࡵࡨ࣯ࠫ"))

    l1l11111l  = l1111l (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࣰࠩ") + l11l1l1
    l1l11l1ll =  l1l1l1ll1(l11l1l1)
    query   =  l1l11111l + l1l11l1ll

    return sendJSON(query, l11l1l1)


def getPluginInfo(l1l1111l1):
    if l1l1111l1.isdigit():
        l11lllll1   = l1111l (u"ࠧࡌࡱࡧ࡭ࠥࡖࡖࡓࠢࡆ࡬ࡦࡴ࡮ࡦ࡮ࣱࠪ")
        l11llllll = os.path.join(dixie.RESOURCES, l1111l (u"ࠨ࡭ࡲࡨ࡮࠳ࡰࡷࡴ࠱ࡴࡳ࡭ࣲࠧ"))
        return l11lllll1, l11llllll

    if l1l1111l1.startswith(l1111l (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬࣳ")):
        name = l1l1111l1.split(l1111l (u"ࠪ࠳࠴࠭ࣴ"), 1)[-1].rsplit(l1111l (u"ࠫ࠴࠭ࣵ"), 1)[0]

    if l1l1111l1.startswith(l1111l (u"ࠬࡎࡄࡕࡘࣶࠪ")):
        name = l1111l (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡮ࡤࡵࡸࠪࣷ")

    if l1l1111l1.startswith(l1111l (u"ࠧࡊࡒࡏࡅ࡞ࡀࠧࣸ")):
        name = l1111l (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡣࡤࡦ࡭ࡵࡲࡡࡺࡧࡵࣹࠫ")

    if l1l1111l1.startswith(l1111l (u"ࠩࡌࡔࡑࡇ࡙࠳࠼ࣺࠪ")):
        name = l1111l (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠭ࣻ")

    if l1l1111l1.startswith(l1111l (u"ࠫࡎࡖࡌࡂ࡛ࡌࡘ࡛ࡀࠧࣼ")):
        name = l1111l (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡺࡶࠨࣽ")

    if l1l1111l1.startswith(l1111l (u"࠭ࡌࡊࡘࡈࡘ࡛ࡀࠧࣾ")):
        name = l1111l (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡬ࡪࡸࡨࡱ࡮ࡾࠧࣿ")

    if l1l1111l1.startswith(l1111l (u"ࠨࡷࡳࡲࡵࡀࠧऀ")):
        name = l1111l (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰࡫ࡨ࡭ࡵ࡭ࡦࡴࡸࡲ࠳ࡼࡩࡦࡹࠪँ")

    l11lllll1   = xbmcaddon.Addon(name).getAddonInfo(l1111l (u"ࠪࡲࡦࡳࡥࠨं"))
    l11llllll = xbmcaddon.Addon(name).getAddonInfo(l1111l (u"ࠫ࡮ࡩ࡯࡯ࠩः"))
    l1l1111l1  = l1111l (u"ࠧࡵࡳ࠯ࡴࡨࡱࡴࡼࡥࠩࡱࡶ࠲ࡵࡧࡴࡩ࠰࡭ࡳ࡮ࡴࠨࡹࡤࡰࡧ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࡑࡣࡷ࡬࠭࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡳࡶࡴ࡬ࡩ࡭ࡧ࠲ࠫ࠮࠲ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤ࠳ࡸࡩࡲࡪࡲࡷ࠲ࡹࡼࡰࡰࡴࡷࡥࡱ࠵ࡰࡳࡱࡪࡶࡦࡳ࠮ࡥࡤࠪ࠭࠮ࠨऄ")
    try: eval(l1l1111l1)
    except: pass

    return l11lllll1, l11llllll


def l1l111l11(l11l1l1):
    l1l11111l = l1111l (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩअ") + l11l1l1

    l11lll1l1 = l1111l (u"ࠧ࠰ࡁࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡲࡵࡤࡦ࠿࠴ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡻ࡫ࠥ࠳࠲ࡗ࡚ࠫࡻࡲ࡭࠿࡫ࡸࡹࡶࠥ࠴ࡣࠨ࠶࡫ࠫ࠲ࡧ࡯ࡨࡸࡦࡲ࡫ࡦࡶࡷࡰࡪ࠴ࡣࡰࠧ࠵ࡪ࡚ࡑࡔࡶࡴ࡮࠵࠽࠶࠲࠳࠲࠴࠺ࠪ࠸ࡦࡍ࡫ࡹࡩࠪ࠸࠵࠳࠲ࡗ࡚࠶࠷࠮ࡵࡺࡷࠫआ")
    l11lll1ll = l1111l (u"ࠨ࠱ࡂࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡳ࡯ࡥࡧࡀ࠵ࠫࡴࡡ࡮ࡧࡀࡗࡵࡵࡲࡵࡵࠩࡹࡷࡲ࠽ࡩࡶࡷࡴࠪ࠹ࡡࠦ࠴ࡩࠩ࠷࡬࡭ࡦࡶࡤࡰࡰ࡫ࡴࡵ࡮ࡨ࠲ࡨࡵࠥ࠳ࡨࡘࡏ࡙ࡻࡲ࡬࠳࠻࠴࠷࠸࠰࠲࠸ࠨ࠶࡫࡙ࡰࡰࡴࡷࡷࡑ࡯ࡳࡵ࠳࠴࠲ࡹࡾࡴࠨइ")

    l1l111lll  = []
    l1l111lll += sendJSON(l1l11111l + l11lll1l1, l11l1l1)
    l1l111lll += sendJSON(l1l11111l + l11lll1ll, l11l1l1)

    return l1l111lll


def l1l1l1ll1(l11l1l1):
    if l11l1l1 == l1l111l1l:
        return l1111l (u"ࠩ࠲ࡃࡨࡧࡴ࠾࠯࠵ࠪࡲࡵࡤࡦ࠿࠵ࠪࡳࡧ࡭ࡦ࠿ࡐࡽࠪ࠸࠰ࡄࡪࡤࡲࡳ࡫࡬ࡴࠨࡸࡶࡱࡃࡵࡳ࡮ࠪई")


def sendJSON(query, l11l1l1):
    try:
        l11lll     = l1111l (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭उ") % query
        l1l1lll  = xbmc.executeJSONRPC(l11lll)
        response = json.loads(l1l1lll)
        result   = response[l1111l (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫऊ")]

        return result[l1111l (u"ࠬ࡬ࡩ࡭ࡧࡶࠫऋ")]

    except Exception as e:
        l1l1111ll(e, l11l1l1)
        return {l1111l (u"࠭ࡅࡳࡴࡲࡶࠬऌ") : l1111l (u"ࠧࡑ࡮ࡸ࡫࡮ࡴࠠࡆࡴࡵࡳࡷ࠭ऍ")}


def l1l1111ll(e, l11l1l1):
    l1l11ll1l = l1111l (u"ࠨࡕࡲࡶࡷࡿࠬࠡࡣࡱࠤࡪࡸࡲࡰࡴࠣࡳࡨࡩࡵࡳࡧࡧ࠾ࠥࡐࡓࡐࡐࠣࡉࡷࡸ࡯ࡳ࠼ࠣࠩࡸ࠲ࠠࠦࡵࠪऎ")  % (e, l11l1l1) 
    l1l11lll1 = l1111l (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡹࡸࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡦࡰࡴࡸࡱ࠳࠭ए")
    l1l11llll = l1111l (u"࡙ࠪࡵࡲ࡯ࡢࡦࠣࡥࠥࡲ࡯ࡨࠢࡹ࡭ࡦࠦࡴࡩࡧࠣࡥࡩࡪ࡯࡯ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠤࡦࡴࡤࠡࡲࡲࡷࡹࠦࡴࡩࡧࠣࡰ࡮ࡴ࡫࠯ࠩऐ")

    dixie.log(l11l1l1)
    dixie.log(e)


def getPlaylist():
    import requests

    l1l111ll1 = [l1111l (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡬ࡵ࠲࡭࠰࡬ࡲࡰ࠵࡫ࡰࡦ࡬ࠫऑ"), l1111l (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲ࡨࡧࡩࡨ࠱࠳ࠪऒ"), l1111l (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬࠲ࡨࡩ࡬ࡥ࠰࡬ࡳࠬओ"), l1111l (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡢ࡫ࡲ࠲ࡨࡩ࡬ࡰࡷࡧࡸࡻ࠴࡯ࡳࡩ࠲࡯ࡴࡪࡩࠨऔ")]
    l1l111111 =  l1111l (u"ࠨࠥࡈ࡜࡙ࡓ࠳ࡖࠩक")

    for url in l1l111ll1:
        dixie.log(url)
        try:
            request  = requests.get(url)
            l1l1l11l1 = request.text
        except: pass

        if l1l111111 in l1l1l11l1:
            path = os.path.join(dixie.PROFILE, l1111l (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡲ࠹ࡵࠨख"))
            with open(path, l1111l (u"ࠪࡻࠬग")) as f:
                f.write(l1l1l11l1)
                break

    import urllib

    l1l1l111l = os.path.join(PATH, l1111l (u"ࠫࡹ࡫࡭ࡱ࡫ࡱ࡭ࠬघ"))
    l1l11l111  = os.path.join(PATH, l1111l (u"ࠬ࡯࡮ࡪ࠴࠱࡭ࡳ࡯ࠧङ"))
    l1l111ll1  = l1111l (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳࡣࡺ࠲࡬࡯ࡴࡩࡷࡥࡹࡸ࡫ࡲࡤࡱࡱࡸࡪࡴࡴ࠯ࡥࡲࡱ࠴ࡘࡥ࡯ࡧࡪࡥࡩ࡫ࡳࡕࡘ࠲ࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡳࡧࡱࡩ࡬ࡧࡤࡦࡵࡷࡺ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡧࡤࡥࡱࡱࡷ࠷࠴ࡩ࡯࡫ࠪच")

    urllib.urlretrieve(l1l111ll1, l1l1l111l)

    temp = open(l1l1l111l)
    l1l1l1l11  = open(l1l11l111, l1111l (u"ࠧࡸࡶࠪछ"))

    for line in temp:
        l1l1l1l11.write(line.replace(
                               l1111l (u"ࠨ࡝ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡦࡨࡼࡢ࠭ज"), l1111l (u"ࠩ࡞ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡼࡽࡣࠧझ"))
                               .replace(l1111l (u"ࠪ࡟ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡊ࠳࡚࠮ࡗ࡟ࠪञ"), l1111l (u"ࠫࡠࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡾࡸ࡞ࠩट"))
                               .replace(l1111l (u"ࠬࡡࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰ࡭ࡣࡼࡩࡷࡽࡷࡸ࡟ࠪठ"), l1111l (u"࡛࠭ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸࡹࡺࡠࠫड"))
                               .replace(l1111l (u"ࠧ࡜ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡶࡹࡡࠬढ"), l1111l (u"ࠨ࡝ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡺࡻࡼࡢ࠭ण"))
                               .replace(l1111l (u"ࠩ࡞ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡥࡦࡨ࡯ࡰ࡭ࡣࡼࡩࡷࡣࠧत"), l1111l (u"ࠪ࡟ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡽࡾ࡝ࠨथ"))
                               .replace(l1111l (u"ࠫࡠࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡨࡧࡳࡵࡣࡺࡥࡾࡣࠧद"), l1111l (u"ࠬࡡࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾࡸࡹ࡟ࠪध"))
                               )

    temp.close()
    l1l1l1l11.close()

    os.remove(l1l1l111l)
