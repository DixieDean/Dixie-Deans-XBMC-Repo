# coding: UTF-8

import sys

l1llll11 = sys.version_info [0] == 2
l1ll111 = 2048
l1lll1 = 7

def l1111l (ll):
	global l111
	
	l1111l1 = ord (ll [-1])
	l1lllll1 = ll [:-1]
	
	l1ll1 = l1111l1 % len (l1lllll1)
	l11l11l = l1lllll1 [:l1ll1] + l1lllll1 [l1ll1:]
		
	if l1llll11:
		l1l1l1l = unicode () .join ([unichr (ord (char) - l1ll111 - (l11l1l + l1111l1) % l1lll1) for l11l1l, char in enumerate (l11l11l)])
	else:
		l1l1l1l = str () .join ([chr (ord (char) - l1ll111 - (l11l1l + l1111l1) % l1lll1) for l11l1l, char in enumerate (l11l11l)])
		
	return eval (l1l1l1l)


import xbmc
import xbmcgui
import xbmcaddon

import dixie

import urllib2
import re
import json
import os
import datetime
from hashlib import md5

from threading import Timer


global l11ll1l, l1ll11, l11l11, l1lll1ll
l11ll1l  = None
l1ll11  = False
l11l11 = 0
l1lll1ll = 0


ADDON = dixie.ADDON
HOME  = ADDON.getAddonInfo(l1111l (u"ࠫࡵࡧࡴࡩࠩࠀ"))
ICON  = os.path.join(HOME, l1111l (u"ࠬ࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧࠁ"))
ICON  = xbmc.translatePath(ICON)
TITLE = dixie.TITLE

SETTING = l1111l (u"࠭ࡌࡐࡉࡌࡒࡤࡎࡄࡕࡘࠪࠂ")

l1l111l           = l1111l (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲࡫࡯࡬࡮ࡱࡱ࠲ࡨࡵ࡭࠰ࠩࠃ")
l111l       =  l1l111l + l1111l (u"ࠨࡣࡳ࡭࠴࡯࡮ࡪࡶ࠲ࠫࠄ")
l11      =  l1l111l + l1111l (u"ࠩࡤࡴ࡮࠵࡬ࡰࡩ࡬ࡲࡄࡹࡥࡴࡵ࡬ࡳࡳࡥ࡫ࡦࡻࡀࠩࡸࠬ࡬ࡰࡩ࡬ࡲࡂࠫࡳࠧࡲࡤࡷࡸࡽ࡯ࡳࡦࡀࠩࡸ࠭ࠅ")
l1lll     =  l1l111l + l1111l (u"ࠪࡥࡵ࡯࠯࡭ࡱࡪࡳࡺࡺ࠿ࡴࡧࡶࡷ࡮ࡵ࡮ࡠ࡭ࡨࡽࡂࠫࡳࠨࠆ")
l11ll1     =  l1l111l + l1111l (u"ࠫࡦࡶࡩ࠰ࡦࡹࡶ࠲ࡧࡤࡥࡁࡶࡩࡸࡹࡩࡰࡰࡢ࡯ࡪࡿ࠽ࠦࡵࠩࡧ࡭ࡧ࡮࡯ࡧ࡯ࡣ࡮ࡪ࠽ࠦࡵࠩࡴࡷࡵࡧࡳࡣࡰࡱࡪࡥࡩࡥ࠿ࠨࡷࠫࡹࡴࡢࡴࡷࡣࡹ࡯࡭ࡦ࠿ࠨࡷࠬࠇ")
l111lll =  l1l111l + l1111l (u"ࠬࡧࡰࡪ࠱ࡧࡺࡷ࠳࡬ࡪࡵࡷࡃࡸ࡫ࡳࡴ࡫ࡲࡲࡤࡱࡥࡺ࠿ࠨࡷࠬࠈ")
l1l11ll     =  l1l111l + l1111l (u"࠭ࡡࡱ࡫࠲ࡨࡻࡸ࠭ࡳࡧࡰࡳࡻ࡫࠿ࡴࡧࡶࡷ࡮ࡵ࡮ࡠ࡭ࡨࡽࡂࠫࡳࠧࡴࡨࡧࡴࡸࡤࡪࡰࡪࡣ࡮ࡪ࠽ࠦࡵࠪࠉ")
l11l111      =  l1l111l + l1111l (u"ࠧࡵࡸ࠲ࡥࡵ࡯࠯ࡵࡸࡪࡹ࡮ࡪࡥ࠰ࠧࡶࡃࡸ࡫ࡳࡴ࡫ࡲࡲࡤࡱࡥࡺ࠿ࠨࡷࠬࠊ")

l1l11l = 275 

l1lll11  = l1111l (u"ࠨࠩࠋ")
l11ll11  = l1111l (u"ࠩࠪࠌ")
l1ll1l = False
if not l1ll1l:
    try:
        l11l1l1    = xbmcaddon.Addon(l1111l (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡉ࠲࡙࠴ࡖࠨࠍ"))
        l1lll11 = l11l1l1.getSetting(l1111l (u"ࠫ࡫࡯࡬࡮ࡱࡱࡣࡺࡹࡥࡳࠩࠎ"))
        l11ll11 = l11l1l1.getSetting(l1111l (u"ࠬ࡬ࡩ࡭࡯ࡲࡲࡤࡶࡡࡴࡵࠪࠏ"))
        l11ll11 = md5(l11ll11).hexdigest()

        l1ll1l = len(l1lll11) > 0 and len(l11ll11) > 0
    except:
        l1ll1l = False

if not l1ll1l:
    try:
        l11l1l1    = xbmcaddon.Addon(l1111l (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡩࡳࡦࡺࡳࡥࡹࡺࡶࠨࠐ"))
        l1lll11 = l11l1l1.getSetting(l1111l (u"ࠧࡶࡵࡨࡶࠬࠑ"))
        l11ll11 = l11l1l1.getSetting(l1111l (u"ࠨࡲࡤࡷࡸ࠭ࠒ"))
        l11ll11 = md5(l11ll11).hexdigest()

        l1ll1l = len(l1lll11) > 0 and len(l11ll11) > 0
    except:
        l1ll1l = False


def notify(message, length=5000):
    cmd = l1111l (u"࡛ࠩࡆࡒࡉ࠮࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠮ࠥࡴ࠮ࠨࡷ࠱ࠫࡤ࠭ࠧࡶ࠭ࠬࠓ") % (TITLE, message, length, ICON)
    xbmc.l1llllll(cmd)

def l1l1l():
    return l1111l (u"ࠪࠤࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶ࠿࡛ࠥ࠻࡙ࠡ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠻࠮࠲࠽ࠣࡩࡳ࠳ࡇࡃ࠽ࠣࡶࡻࡀ࠱࠯࠻࠱࠴࠳࠹ࠩࠡࡉࡨࡧࡰࡵ࠯࠳࠲࠳࠼࠵࠿࠲࠵࠳࠺ࠤࡋ࡯ࡲࡦࡨࡲࡼ࠴࠹࠮࠱࠰࠶ࠫࠔ")


def isValid(stream):
    if stream.startswith(l1111l (u"ࠫࡍࡊࡔࡗࠩࠕ")):
        return True

    if not l1ll1l:
        return False

    if stream.startswith(l1111l (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡆ࠯ࡖ࠱࡚ࠬࠖ")):
        return True

    if stream.startswith(l1111l (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡤࡵࡨࡼࡵࡧࡴࡵࡸࠪࠗ")):
        return True

    return False


def l1ll11l(url):
    global l1lll1ll

    try:
        req  = urllib2.Request(url)
        req.add_header(l1111l (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ࠘"), l1l1l())
        resp = urllib2.urlopen(req, timeout=10)
  
        headers = resp.headers
        l1lll1l     = headers[l1111l (u"ࠨࡆࡤࡸࡪ࠭࠙")].split(l1111l (u"ࠩ࠯ࠤࠬࠚ"))[-1]
        l1lll1l     = datetime.datetime.strptime(l1lll1l, l1111l (u"ࠪࠩࡩࠦࠥࡣࠢࠨ࡝ࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠠࡈࡏࡗࠫࠛ"))

        l1lll1ll = l1lll1l - datetime.datetime.today()
        l1lll1ll = ((l1lll1ll.days * 86400) + (l1lll1ll.seconds + 1800)) / 3600        
        l1lll1ll *= -3600

        l111l11 = resp.read()
        resp.close()
        return l111l11
    except Exception, e:
        dixie.log(l1111l (u"ࠫࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡇࡦࡶࡋࡘࡒࡒࠬࠡࡷࡵࡰࠥࡃࠠࠦࡵࠪࠜ") % url)
        dixie.log(str(e))
        return str(e)


def l111ll():
    if (not l1lll11) or (not l11ll11):
        return

    l111111()
        
    try:
        global l11l11
        l11l11 = 0
        response  = l1ll11l(l111l)
        l11l11 = re.compile(l1111l (u"ࠬࠨࡳࡦࡵࡶ࡭ࡴࡴ࡟࡬ࡧࡼࠦ࠿ࠨࠨ࠯࠭ࡂ࠭ࠧ࠭ࠝ")).search(response).group(1)
    except:
        pass


def l1llll1l():
    dixie.log(l1111l (u"࠭ࡅ࡯ࡶࡨࡶ࡮ࡴࡧࠡ࡮ࡲ࡫࡮ࡴࠧࠞ"))
    global l11ll1l, l1ll11, l11l11

    l1ll11 = False

    if l11l11 == 0:
        l111ll()

    url   = l11 % (l11l11, l1lll11, l11ll11)
    l1llll1l = l1ll11l(url)

    l1ll11 = l1111l (u"ࠧࡆࡔࡕࡓࡗ࠭ࠟ") not in l1llll1l.upper()

    if l1ll11:
        message = l1111l (u"ࠨࡎࡲ࡫࡬࡫ࡤࠡ࡫ࡱࡸࡴࠦࡆࡪ࡮ࡰࡳࡳ࠭ࠠ")
    else:
        message = l1111l (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡒ࡯ࡨࠢ࡬ࡲࡹࡵࠠࡇ࡫࡯ࡱࡴࡴࠧࠡ")

    dixie.log(message)
    notify(message)

    if l1ll11:
        l11ll1l = Timer(l1l11l, l1l1111)
        l11ll1l.start()


def l111111():
    global l11ll1l
    if l11ll1l:
        l11ll1l.cancel()
        del l11ll1l
        l11ll1l = None


def l1l1111():
    l111111()

    global l1ll11, l11l11
    if not l1ll11:
        return

    id = l11l11

    l1ll11  = False
    l11l11 = 0

    try:
        url    = l1lll % id
        l1l1111 = l1ll11l(url)

        l1l1ll1  = json.loads(l1l1111)
        if l1111l (u"ࠪࡷࡺࡩࡣࡦࡵࡶࠫࠢ") in l1l1ll1:
            l1ll11 = not l1l1ll1[l1111l (u"ࠫࡸࡻࡣࡤࡧࡶࡷࠬࠣ")]

        if l1ll11:
            dixie.log(l1111l (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡎࡲ࡫ࡴࡻࡴࠡࡱࡩࠤࡋ࡯࡬࡮ࡱࡱࠫࠤ"))
        else:
            dixie.log(l1111l (u"࠭ࡌࡰࡩࡪࡩࡩࠦ࡯ࡶࡶࠣࡳ࡫ࠦࡆࡪ࡮ࡰࡳࡳ࠭ࠥ"))
            
    except:
        pass


def l1ll(l1l111):
    global l1lll1ll
    start   = datetime.datetime(1970, 1, 1)
    l11lll1   = l1l111 - start
    seconds = (l11lll1.days * 86400) + l11lll1.seconds
    return seconds - l1lll1ll


def l1lllll(l1llll1):
    global l11l11
    try:

        if l11l11 == 0:
            return None

        l1lll1l1 = l1ll11l(l11l111 % (l1llll1, l11l11))
        return l1lll1l1

    except Exception, e:
        dixie.log(l1111l (u"ࠧࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡧࡦࡶࡊࡹ࡮ࡪࡥࠡࠧࡶࠫࠦ") % str(e))
        return None


def l1l1l11(l1l1l1):
    try:    
        return int(re.compile(l1111l (u"ࠨࡷࡵࡰࡂ࠮࠮ࠬࡁࠬࠪࠬࠧ")).search(l1l1l1).group(1))
    except:
        pass

    try:
        l11l1ll = l1l1l1.rsplit(l1111l (u"ࠩࡦ࡬ࡤ࡬ࡡ࡯ࡣࡵࡸࡂ࠭ࠨ"), 1)[-1]
        l11l1ll = int(l11l1ll.split(l1111l (u"ࠪࡀࡃ࠭ࠩ"), 1)[0])
        return l11l1ll
    except:
        return None


def getProgram(l1llll1, start):
    dixie.log(l1111l (u"ࠫࡊࡴࡴࡦࡴ࡬ࡲ࡬ࠦࡧࡦࡶࡓࡶࡴ࡭ࡲࡢ࡯ࠪࠪ"))
    dixie.log(l1111l (u"ࠬࡉࡨࡢࡰࡱࡩࡱࠦ࠽ࠡࠧࡶࠫࠫ") % str(l1llll1))
    dixie.log(l1111l (u"࠭ࡓࡵࡣࡵࡸࠥࠦࠠ࠾ࠢࠨࡷࠬࠬ") % str(start))
    try:
        l11l = l1ll(start)
        dixie.log(l1111l (u"ࠧࡔࡶࡤࡶࡹ࡚ࡓࠡ࠿ࠣࠩࡸ࠭࠭") % str(l11l))
        dixie.log(l1111l (u"ࠨࡶࡼࡴࡪ࠮ࡓࡵࡣࡵࡸ࡙࡙ࠩࠡ࠿ࠣࠩࡸ࠭࠮") % type(l11l))

        l1lll1l1 = l1lllll(l1llll1)
        if not l1lll1l1:
            return None

        l1lll1l1 = json.loads(l1lll1l1)

        
        

        for l1ll1ll in l1lll1l1:
            dixie.log(l1111l (u"ࠩࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࠬ࠯"))
            dixie.log(l1111l (u"ࠪࡘࡾࡶࡥࠡ࠿ࠣࠩࡸ࠭࠰") % type(l1ll1ll))
            dixie.log(l1111l (u"࡙ࠫࡿࡰࡦࠢࡲࡪࠥࡶࡲࡰࡩࡵࡥࡲࡡࡳࡵࡣࡵࡸࡩࡧࡴࡦࡶ࡬ࡱࡪࡣࠠ࠾ࠢࠨࡷࠬ࠱") % type(l1ll1ll[l1111l (u"ࠬࡹࡴࡢࡴࡷࡨࡦࡺࡥࡵ࡫ࡰࡩࠬ࠲")]))
            dixie.log(l1ll1ll)
            dixie.log(l1111l (u"࠭࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࠩ࠳"))
            dixie.log(l1111l (u"ࠧ࠲ࠢࠣࠤࠬ࠴"))
            dixie.log(l1111l (u"ࠨ࠴ࠣࠤࠥ࠭࠵"))
            dixie.log(l1111l (u"ࠩ࠶ࠤࠥࠦࠧ࠶"))
            if l1111l (u"ࠪࡷࡹࡧࡲࡵࡦࡤࡸࡪࡺࡩ࡮ࡧࠪ࠷") in l1ll1ll and l1111l (u"ࠫࡵࡸ࡯ࡨࡴࡤࡱࡲ࡫ࠧ࠸") in l1ll1ll:                
                if int(l1ll1ll[l1111l (u"ࠬࡹࡴࡢࡴࡷࡨࡦࡺࡥࡵ࡫ࡰࡩࠬ࠹")]) == l11l:
                    return l1ll1ll[l1111l (u"࠭ࡰࡳࡱࡪࡶࡦࡳ࡭ࡦࠩ࠺")]                
            
    except Exception, e:
        dixie.log(l1111l (u"ࠧࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡧࡦࡶࡓࡶࡴ࡭ࡲࡢ࡯ࠣࠩࡸ࠭࠻") % str(e))

    dixie.log(l1111l (u"ࠨࡔࡨࡸࡺࡸ࡮ࡪࡰࡪࠤࡓࡵ࡮ࡦࠢࡩࡶࡴࡳࠠࡨࡧࡷࡔࡷࡵࡧࡳࡣࡰࠫ࠼"))
    return None


def verifyLogin():
    dixie.log(l1111l (u"ࠩࡈࡲࡹ࡫ࡲࡪࡰࡪࠤ࡛࡫ࡲࡪࡨࡼࡐࡴ࡭ࡩ࡯ࠩ࠽"))
    try:
        global l1ll11

        if not l1ll11:
            dixie.log(l1111l (u"ࠪࡅࡹࡺࡥ࡮ࡲࡷ࡭ࡳ࡭ࠠࡵࡱࠣࡐࡴ࡭ࡩ࡯ࠩ࠾"))
            l1llll1l()

        if not l1ll11:
            dixie.log(l1111l (u"ࠫࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡍࡱࡪ࡭ࡳ࠭࠿"))
            dixie.DialogOK(l1111l (u"ࠬࡔ࡯ࡵࠢ࡯ࡳ࡬࡭ࡥࡥࠢ࡬ࡲࡹࡵࠠࡇ࡫࡯ࡱࡴࡴ࠮ࠨࡀ"), l1111l (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡣࡩࡧࡦ࡯ࠥࡪࡥࡵࡣ࡬ࡰࡸࠦࡡ࡯ࡦࠣࡸࡷࡿࠠࡢࡩࡤ࡭ࡳ࠴ࠧࡁ"))
            return False

        return True
    except Exception, e:
        dixie.log(l1111l (u"ࠧࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡖࡦࡴ࡬ࡪࡾࡒ࡯ࡨ࡫ࡱࠤࠪࡹࠧࡂ") % str(e))

    return False


def isRecorded(name, start):
    if not verifyLogin():
        return False, None

    l11111l = getRecording(name, start)

    if l11111l == None:
        dixie.log(l1111l (u"ࠨࠧࡶࠤ࡮ࡹࠠࡏࡑࡗࠤࡗࡋࡃࡐࡔࡇࡉࡉ࠭ࡃ") % name)
        return False, None

    dixie.log(l1111l (u"ࠩࠨࡷࠥ࡯ࡳࠡࡔࡈࡇࡔࡘࡄࡆࡆࠪࡄ") % name)
    return True, l11111l


    
def record(name, start, end, l1l1l1, l1l1=True):
    output = l1111l (u"ࠪࡅࡹࡺࡥ࡮ࡲࡷ࡭ࡳ࡭ࠠࡵࡱࠣࡷࡪࡺࠠࡳࡧࡦࡳࡷࡪࡩ࡯ࡩࠣࡪࡴࡸࠠࠦࡵࠣࡷࡹࡧࡲࡵ࠼ࠨࡷࠥ࡫࡮ࡥ࠼ࠨࡷࠥࡹࡴࡳࡧࡤࡱ࠿ࠫࡳࠨࡅ") % (name, start, end, l1l1l1)
    dixie.log(output)
    if not verifyLogin():
        dixie.log(l1111l (u"ࠫࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡷࡧࡵ࡭࡫ࡿࠠ࡭ࡱࡪ࡭ࡳ࠭ࡆ"))
        return False

    global l11l11

    l1llll1 = l1l1l11(l1l1l1)
    if not l1llll1:
        dixie.log(l1111l (u"ࠬࡴ࡯ࡵࠢࡦ࡬ࡦࡴ࡮ࡦ࡮ࠪࡇ"))
        dixie.DialogOK(l1111l (u"࠭ࡎࡰࠢࡹࡥࡱ࡯ࡤࠡࡥ࡫ࡥࡳࡴࡥ࡭ࠢࡩࡳࡺࡴࡤࠡ࡫ࡱࠤࡸࡺࡲࡦࡣࡰ࠲ࠬࡈ"), l1111l (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡦࡦ࡬ࡸࠥࡹࡴࡳࡧࡤࡱࠥࡧ࡮ࡥࠢࡷࡶࡾࠦࡡࡨࡣ࡬ࡲ࠳࠭ࡉ"))
        return False

    l1ll1ll = getProgram(l1llll1, start)
    if not l1ll1ll:
        dixie.log(l1111l (u"ࠨࡰࡲࡸࠥࡶࡲࡰࡩࡵࡥࡲ࠭ࡊ"))
        dixie.DialogOK(l1111l (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠦࡩ࡯ࠢࡉ࡭ࡱࡳ࡯࡯ࠢࡪࡹ࡮ࡪࡥ࠯ࠩࡋ"))
        return False

    url     = l11ll1 % (l11l11, l1llll1, l1ll1ll, l1ll(start))
    record  = l1ll11l(url)
    l111ll1 = False

    dixie.log(l1111l (u"ࠪࡶࡪࡩ࡯ࡳࡦࠣࡸࡦࡹ࡫ࠡࡷࡵࡰࠥࡀࠠࠦࡵࠪࡌ") % url)
    dixie.log(l1111l (u"ࠫࡷ࡫ࡳࡱࡱࡱࡷࡪࠦࠥࡴࠩࡍ") % record)

    try:
        l1l1ll1 = json.loads(record)

        dixie.log(l1111l (u"ࠬࡇࡳࠡࡌࡖࡓࡓ࠭ࡎ"))
        dixie.log(l1l1ll1)

        if l1111l (u"࠭ࡳࡶࡥࡦࡩࡸࡹࠧࡏ") in l1l1ll1:
           l111ll1 = l1l1ll1[l1111l (u"ࠧࡴࡷࡦࡧࡪࡹࡳࠨࡐ")]
    except Exception, e:
        error = record.split(l1111l (u"ࠨ࠼ࠪࡑ"))[-1].strip()
        dixie.log(l1111l (u"ࠩࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡴࡨࡧࡴࡸࡤࠡࠧࡶࠫࡒ") % str(e))
        dixie.log(error)
        if not l1l1:
            return False

        dixie.DialogOK(name, l1111l (u"ࠪࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡳࡤࡪࡨࡨࡺࡲࡥࠡࡴࡨࡧࡴࡸࡤࡪࡰࡪ࠲ࠬࡓ"), error)

        return False

    if not l1l1:
        return l1ll1ll

    
    if l111ll1:
        if end < datetime.datetime.today():
            dixie.DialogOK(name, l1111l (u"ࠫࡍࡧࡳࠡࡤࡨࡩࡳࠦࡲࡦࡥࡲࡶࡩ࡫ࡤ࠯ࠩࡔ"))
        else:
            dixie.DialogOK(name, l1111l (u"ࠬࡎࡡࡴࠢࡥࡩࡪࡴࠠࡴࡥ࡫ࡩࡩࡻ࡬ࡦࡦࠣࡸࡴࠦࡢࡦࠢࡵࡩࡨࡵࡲࡥࡧࡧ࠲ࠬࡕ"))
    else:
        dixie.DialogOK(l1111l (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡶࡧ࡭࡫ࡤࡶ࡮ࡨࠤࡷ࡫ࡣࡰࡴࡧ࡭ࡳ࡭࠮ࠨࡖ"))

    return l1ll1ll


def getRecording(name, start):
    if not verifyLogin():
        return False

    global l11l11

    url        = l111lll % l11l11
    l1l11l1 = l1ll11l(url)
    l1l11l1 = json.loads(l1l11l1)
    l1l11l1 = l1l11l1[l1111l (u"ࠧࡳࡧࡦࡳࡷࡪࡩ࡯ࡩࡶࠫࡗ")]

    l11l = l1ll(start)
    name    = name.lower()

    for l11111l in l1l11l1:
        try:
            title = l11111l[l1111l (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࡘ")].lower()
            start = int(l11111l[l1111l (u"ࠩࡷ࡭ࡲ࡫࡟ࡴࡶࡤࡶࡹ࡙࠭")])

            if (start == l11l): 
                dixie.log(l1111l (u"ࠪࡈࡴࡽ࡮࡭ࡱࡤࡨ࡛ࠥࡒࡍࠢࡀࠤࠪࡹ࡚ࠧ") % l11111l[l1111l (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥࡵࡳ࡮࡛ࠪ")])
                return l11111l[l1111l (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡶࡴ࡯ࠫ࡜")]

        except Exception, e:
            dixie.log(l1111l (u"࠭ࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡷ࡬ࡷࡵࡷ࡯ࠢ࡬ࡲࠥ࡭ࡥࡵࡔࡨࡧࡴࡸࡤࡪࡰࡪࠤࠪࡹࠧ࡝") % str(e))

    return None


def getHDTVRecording(name, start, stream):
    dixie.log(l1111l (u"ࠧࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࠦࡃࡂࡖࡆࡌ࡛ࠥࡐࠡࡊࡇࡘ࡛ࠦ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤ࠭࡞"))
    dixie.log(name)
    dixie.log(start)
    dixie.log(stream)

    import urllib
    
    l11l1 =  str(start)
    l1  =  l11l1.split(l1111l (u"ࠨࠢࠪ࡟"))[0]
    l1ll1l1  =  getRecordURL(name)

    if l1ll1l1 is None:
        dixie.DialogOK(l1111l (u"ࠩࡖࡳࡷࡸࡹ࠯ࠩࡠ"), l1111l (u"࡛ࠪࡪࠦࡣࡰࡷ࡯ࡨࠥࡴ࡯ࡵࠢࡩ࡭ࡳࡪࠠࡢࠢࡦࡥࡹࡩࡨࡶࡲࠣࡷࡪࡸࡶࡪࡥࡨࠤ࡫ࡵࡲࠡࡶ࡫࡭ࡸࠦࡣࡩࡣࡱࡲࡪࡲ࠮ࠨࡡ"), l1111l (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡹࡸࡹࠡࡣࡱࡳࡹ࡮ࡥࡳࠢࡦ࡬ࡦࡴ࡮ࡦ࡮࠱ࠫࡢ"))
        return None

    l11llll  =  l11l1.split(l1111l (u"ࠬ࠳ࠧࡣ"), 1)[-1].rsplit(l1111l (u"࠭࠺ࠨࡤ"), 1)[0]
    l1l11    =  urllib.quote_plus(l11llll)
    l111l1l  = l1111l (u"ࠧࡱ࡮ࡲࡸࡂ࠭ࡥ") + l1l11

    l11111    =  l1111(stream)
    dixie.log(l11111)

    l111l1  = l1111l (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ࡦ") % l11111
    l11ll  = l1111l (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠪࡹ࠯ࡀࡣࡦࡸ࡮ࡵ࡮࠾࡮࡬ࡺࡪࡺࡶࡠࡥࡤࡸࡨ࡮ࡵࡱࡡࡥࡽࡤࡩࡨࡢࡰࡱࡩࡱࡥࡡ࡯ࡦࡢࡨࡦࡺࡥࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠬࡴࡪࡶ࡯ࡩࡂࠫࡳࠧࡷࡵࡰࡂࠫࡳࠨࡧ") % (l11111, l1, l1ll1l1)
    l11lll       = l1111l (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ࡨ") % l11ll

    if not dixie.validTime(SETTING, 60 * 60 * 8):
        xbmc.executeJSONRPC(l111l1)
        l1llll(SETTING)

    l1l1lll    =  xbmc.executeJSONRPC(l11lll)
    response   =  json.loads(l1l1lll)
    result     =  response[l1111l (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫࡩ")]
    l1l11l1 =  result[l1111l (u"ࠬ࡬ࡩ࡭ࡧࡶࠫࡪ")]

    for l11111l in l1l11l1:
        try:
            l1ll1ll = l11111l[l1111l (u"࠭ࡦࡪ࡮ࡨࠫ࡫")]

            if l111l1l in l1ll1ll:
                dixie.log(l1111l (u"ࠧࡱࡴࡲ࡫ࡷࡧ࡭ࡊࡆࠣࡁࠥࠫࡳࠨ࡬") % l1ll1ll)
                return l1ll1ll

        except Exception, e:
            dixie.log(l1111l (u"ࠨࡇࡕࡖࡔࡘ࠺ࠡࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤࡹ࡮ࡲࡰࡹࡱࠤ࡮ࡴࠠࡨࡧࡷࡌࡉ࡚ࡖࡓࡧࡦࡳࡷࡪࡩ࡯ࡩࠣࠩࡸ࠭࡭") % str(e))
            dixie.DialogOK(l1111l (u"ࠩࡖࡳࡷࡸࡹ࠯ࠩ࡮"), l1111l (u"࡛ࠪࡪࠦࡣࡰࡷ࡯ࡨࠥࡴ࡯ࡵࠢࡩ࡭ࡳࡪࠠࡢࠢࡦࡥࡹࡩࡨࡶࡲࠣࡷࡹࡸࡥࡢ࡯ࠣࡪࡴࡸࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲ࠴ࠧ࡯"), l1111l (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡹࡸࡹࠡࡣࡪࡥ࡮ࡴࠠ࡭ࡣࡷࡩࡷ࠴ࠧࡰ"))
            return None

    return None


def l1111(stream):
    if stream.startswith(l1111l (u"ࠬࡎࡄࡕࡘ࠽ࠫࡱ")):
        return l1111l (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡮ࡤࡵࡸࠪࡲ")

    if stream.startswith(l1111l (u"ࠧࡉࡆࡗ࡚࠷ࡀࠧࡳ")):
        return l1111l (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥ࡮ࡶࡴࡷࠩࡴ")

    if stream.startswith(l1111l (u"ࠩࡋࡈ࡙࡜࠳࠻ࠩࡵ")):
        return l1111l (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧࡴࡷࠩࡶ")


def getRecordURL(name):
    l1l1ll   = dixie.PROFILE
    l1l = os.path.join(l1l1ll, l1111l (u"ࠫ࡮ࡴࡩࠨࡷ"), l1111l (u"ࠬࡩࡡࡵࡥ࡫ࡹࡵ࠴ࡴࡹࡶࠪࡸ"))
    l1lll11l   = json.load(open(l1l))

    for l1llll1 in l1lll11l:
        if name.upper() == l1llll1[l1111l (u"࠭ࡏࡕࡖ࡙ࠫࡹ")].upper():
            return l1llll1[l1111l (u"ࠧࡖࡔࡏࠫࡺ")]


def l1111ll(url):
    if not verifyLogin():
        return False

    try:
        l111l1l = url.rsplit(l1111l (u"ࠨ࠱ࠪࡻ"), 1)[-1].split(l1111l (u"ࠩ࠱ࠫࡼ"), 1)[0]

        global l11l11
 
        url        = l1l11ll % (l11l11, l111l1l)
        response   = l1ll11l(url)
        response   = json.loads(response)
    except:
        pass