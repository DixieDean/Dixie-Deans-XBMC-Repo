# -*- coding: utf-8 -*-
import sys
l1l11l1_opy_ = sys.version_info [0] == 2
l1l111l_opy_ = 2048
l1l1l1_opy_ = 7
def l1ll1ll_opy_ (ll_opy_):
	global l1ll1l_opy_
	l1lll111_opy_ = ord (ll_opy_ [-1])
	l1l1l1l_opy_ = ll_opy_ [:-1]
	l1111ll_opy_ = l1lll111_opy_ % len (l1l1l1l_opy_)
	l1lllll1_opy_ = l1l1l1l_opy_ [:l1111ll_opy_] + l1l1l1l_opy_ [l1111ll_opy_:]
	if l1l11l1_opy_:
		l11l1ll_opy_ = unicode () .join ([unichr (ord (char) - l1l111l_opy_ - (l1llll1_opy_ + l1lll111_opy_) % l1l1l1_opy_) for l1llll1_opy_, char in enumerate (l1lllll1_opy_)])
	else:
		l11l1ll_opy_ = str () .join ([chr (ord (char) - l1l111l_opy_ - (l1llll1_opy_ + l1lll111_opy_) % l1l1l1_opy_) for l1llll1_opy_, char in enumerate (l1lllll1_opy_)])
	return eval (l11l1ll_opy_)
import os
import json
import requests
import dixie
l1111l_opy_ = dixie.PROFILE
PATH = os.path.join(l1111l_opy_, l1ll1ll_opy_ (u"࠭ࡰ࡭࡫ࡶࡸࡸ࠭ࣾ"))
def loadPlaylists():
    dixie.log(l1ll1ll_opy_ (u"ࠧ࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃࠠࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠣࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠩࣿ"))
    if os.path.exists(PATH):
        return json.load(open(PATH))
    try:
        l11ll111l_opy_()
        return json.load(open(PATH))
    except:
        dixie.log(l1ll1ll_opy_ (u"ࠨ࠿ࡀࡁࡂࠦࡐ࡭ࡣࡼࡰ࡮ࡹࡴࠡ࡮ࡲࡥࡩࠦࡥࡳࡴࡲࡶࠥࡃ࠽࠾࠿ࠪऀ"))
        return []
def l11ll111l_opy_():
    source = dixie.GetSetting(l1ll1ll_opy_ (u"ࠩ࡬ࡴࡹࡼ࠮ࡴࡱࡸࡶࡨ࡫ࠧँ"))
    if not source == l1ll1ll_opy_ (u"ࠪ࠵ࠬं"):
        return l11ll1l1l_opy_()
    return l11l111ll_opy_()
def l11ll1l1l_opy_():
    l1l1111ll_opy_ = []
    if dixie.GetSetting(l1ll1ll_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠳ࠫः")) == l1ll1ll_opy_ (u"ࠬࡺࡲࡶࡧࠪऄ"):
        l1l111111_opy_  = dixie.GetSetting(l1ll1ll_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠵ࡥࡕࡓࡎࠪअ"))
        l11l11l11_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠶࡟ࡑࡑࡕࡘࠬआ"))
        l11ll11ll_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠰ࡠࡖ࡜ࡔࡊ࠭इ"))
        l11llll1l_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠱ࡡࡘࡗࡊࡘࠧई"))
        l1l11111l_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠲ࡢࡔࡆ࡙ࡓࠨउ"))
        if len(l1l111111_opy_) > 0:
            l11lll1ll_opy_ = l11llll11_opy_(l1l111111_opy_, l11l11l11_opy_, l11ll11ll_opy_, l11llll1l_opy_, l1l11111l_opy_)
            l1l1111ll_opy_.append((l11lll1ll_opy_, l1ll1ll_opy_ (u"ࠫࡎࡖࡔࡗ࠳࠽ࠤࠬऊ")))
    if dixie.GetSetting(l1ll1ll_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠵ࠬऋ")) == l1ll1ll_opy_ (u"࠭ࡴࡳࡷࡨࠫऌ"):
        l1l111111_opy_  = dixie.GetSetting(l1ll1ll_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠷࡟ࡖࡔࡏࠫऍ"))
        l11l11l11_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠱ࡠࡒࡒࡖ࡙࠭ऎ"))
        l11ll11ll_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠲ࡡࡗ࡝ࡕࡋࠧए"))
        l11llll1l_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠳ࡢ࡙ࡘࡋࡒࠨऐ"))
        l1l11111l_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠴ࡣࡕࡇࡓࡔࠩऑ"))
        if len(l1l111111_opy_) > 0:
            l11lll1l1_opy_ = l11llll11_opy_(l1l111111_opy_, l11l11l11_opy_, l11ll11ll_opy_, l11llll1l_opy_, l1l11111l_opy_)
            l1l1111ll_opy_.append((l11lll1l1_opy_, l1ll1ll_opy_ (u"ࠬࡏࡐࡕࡘ࠵࠾ࠥ࠭ऒ")))
    if dixie.GetSetting(l1ll1ll_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠷࠭ओ")) == l1ll1ll_opy_ (u"ࠧࡵࡴࡸࡩࠬऔ"):
        l1l111111_opy_  = dixie.GetSetting(l1ll1ll_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠲ࡠࡗࡕࡐࠬक"))
        l11l11l11_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠳ࡡࡓࡓࡗ࡚ࠧख"))
        l11ll11ll_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠴ࡢࡘ࡞ࡖࡅࠨग"))
        l11llll1l_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠵ࡣ࡚࡙ࡅࡓࠩघ"))
        l1l11111l_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠶ࡤࡖࡁࡔࡕࠪङ"))
        if len(l1l111111_opy_) > 0:
            l11lll11l_opy_ = l11llll11_opy_(l1l111111_opy_, l11l11l11_opy_, l11ll11ll_opy_, l11llll1l_opy_, l1l11111l_opy_)
            l1l1111ll_opy_.append((l11lll11l_opy_, l1ll1ll_opy_ (u"࠭ࡉࡑࡖ࡙࠷࠿ࠦࠧच")))
    return l11l1l1l1_opy_(l1ll1ll_opy_ (u"ࠧࡖࡔࡏࡗࠬछ"),  l1l1111ll_opy_)
def l11l111ll_opy_():
    l1l1111ll_opy_ = []
    if dixie.GetSetting(l1ll1ll_opy_ (u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡸࡾࡶࡥࠨज")) == l1ll1ll_opy_ (u"ࠩ࠳ࠫझ"):
        if dixie.GetSetting(l1ll1ll_opy_ (u"࡙ࠪࡗࡒ࡟ࡐࠩञ")) == l1ll1ll_opy_ (u"ࠫࡹࡸࡵࡦࠩट"):
            l11l1111l_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡶࡴ࡯ࠫठ"))
            if len(l11l1111l_opy_) > 0:
                l1l1111ll_opy_.append((l11l1111l_opy_, l1ll1ll_opy_ (u"࠭ࡕࡓࡎ࠴࠾ࠥ࠭ड")))
        if dixie.GetSetting(l1ll1ll_opy_ (u"ࠧࡖࡔࡏࡣ࠶࠭ढ")) == l1ll1ll_opy_ (u"ࠨࡶࡵࡹࡪ࠭ण"):
            l11l1ll11_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡺࡸ࡬࠲ࠩत"))
            if len(l11l1ll11_opy_) > 0:
                l1l1111ll_opy_.append((l11l1ll11_opy_, l1ll1ll_opy_ (u"࡙ࠪࡗࡒ࠲࠻ࠢࠪथ")))
        if dixie.GetSetting(l1ll1ll_opy_ (u"࡚ࠫࡘࡌࡠ࠴ࠪद")) == l1ll1ll_opy_ (u"ࠬࡺࡲࡶࡧࠪध"):
            l11lll111_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡷࡵࡰ࠷࠭न"))
            if len(l11lll111_opy_) > 0:
                l1l1111ll_opy_.append((l11lll111_opy_, l1ll1ll_opy_ (u"ࠧࡖࡔࡏ࠷࠿ࠦࠧऩ")))
        dixie.log(l1l1111ll_opy_)
        return l11l1l1l1_opy_(l1ll1ll_opy_ (u"ࠨࡗࡕࡐࡘ࠭प"),  l1l1111ll_opy_)
    if dixie.GetSetting(l1ll1ll_opy_ (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡹࡿࡰࡦࠩफ")) == l1ll1ll_opy_ (u"ࠪ࠵ࠬब"):
        if dixie.GetSetting(l1ll1ll_opy_ (u"ࠫࡋࡏࡌࡆࡡ࠳ࠫभ")) == l1ll1ll_opy_ (u"ࠬࡺࡲࡶࡧࠪम"):
            l11l111l1_opy_ = os.path.join(dixie.GetSetting(l1ll1ll_opy_ (u"࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡨ࡬ࡰࡪ࠭य")))
            if l11l111l1_opy_:
                l1l1111ll_opy_.append((l11l111l1_opy_, l1ll1ll_opy_ (u"ࠧࡇࡋࡏࡉ࠶ࡀࠠࠨर")))
        if dixie.GetSetting(l1ll1ll_opy_ (u"ࠨࡈࡌࡐࡊࡥ࠰ࠨऱ")) == l1ll1ll_opy_ (u"ࠩࡷࡶࡺ࡫ࠧल"):
            l11lllll1_opy_ = os.path.join(dixie.GetSetting(l1ll1ll_opy_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳࡬ࡩ࡭ࡧ࠴ࠫळ")))
            if l11lllll1_opy_:
                l1l1111ll_opy_.append((l11lllll1_opy_, l1ll1ll_opy_ (u"ࠫࡋࡏࡌࡆ࠴࠽ࠤࠬऴ")))
        if dixie.GetSetting(l1ll1ll_opy_ (u"ࠬࡌࡉࡍࡇࡢ࠴ࠬव")) == l1ll1ll_opy_ (u"࠭ࡴࡳࡷࡨࠫश"):
            l1l1111l1_opy_ = os.path.join(dixie.GetSetting(l1ll1ll_opy_ (u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡩ࡭ࡱ࡫࠲ࠨष")))
            if l1l1111l1_opy_:
                l1l1111ll_opy_.append((l1l1111l1_opy_, l1ll1ll_opy_ (u"ࠨࡈࡌࡐࡊ࠹࠺ࠡࠩस")))
        dixie.log(l1l1111ll_opy_)
        return l11l1l1l1_opy_(l1ll1ll_opy_ (u"ࠩࡉࡍࡑࡋࡓࠨह"), l1l1111ll_opy_)
def l11l11ll1_opy_():
    l11l11lll_opy_ = [l1ll1ll_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡼ࠳ࡩ࡯࠰ࡊࡈ࡞࠺ࡠࡹࡪࡌࡨ࡛ࠬऺ")]
    for url in l11l11lll_opy_:
        request = requests.get(url)
        content = request.content
        if l1ll1ll_opy_ (u"ࠫࠨࡋࡘࡕࡏ࠶࡙ࠬऻ") in content:
            return l11l1l1l1_opy_(l1ll1ll_opy_ (u"ࠬࡉࡌࡐࡗࡇ़ࠫ"), [(url, l1ll1ll_opy_ (u"࠭ࠧऽ"))])
            break
def l11l1l1l1_opy_(l11l1l11l_opy_, plist):
    dixie.log(l11l1l11l_opy_)
    dixie.log(plist)
    playlists = []
    for item in plist:
        url = item[0]
        l11l1l111_opy_ = item[1]
        l11ll1ll1_opy_ = l11llllll_opy_(l11l1l11l_opy_, url, l11l1l111_opy_)
        playlists.extend(l11ll1ll1_opy_)
    json.dump(playlists, open(PATH,l1ll1ll_opy_ (u"ࠧࡸࠩा")))
def l11llllll_opy_(l11l1l11l_opy_, url, l11l1l111_opy_):
    content  = l11l11l1l_opy_(l11l1l11l_opy_, url)
    pairs    = []
    for i in range(1,len(content), 2):
        if l11ll1lll_opy_(content[i]) == True:
            l1lllll_opy_ = content[i]
            l11llll_opy_   = content[i+1]
            pairs.append([l1lllll_opy_, l11llll_opy_])
    l11l1ll1l_opy_ = list()
    l1lllll_opy_   = l1ll1ll_opy_ (u"ࠨࠩि")
    value   = l1ll1ll_opy_ (u"ࠩࠪी")
    for item in pairs:
        l11ll11l1_opy_ = item[0]
        l11ll1l11_opy_ = item[1]
        l11ll1111_opy_   = l11ll11l1_opy_.split(l1ll1ll_opy_ (u"ࠪ࠰ࠬु"))[-1].strip()
        l11l1llll_opy_   = dixie.cleanLabel(l11ll1111_opy_)
        l1ll1l1l_opy_ = dixie.cleanPrefix(l11l1llll_opy_)
        l1l1l_opy_ = dixie.mapChannelName(l1ll1l1l_opy_)
        value = l11ll1l11_opy_.replace(l1ll1ll_opy_ (u"ࠫࡷࡺ࡭ࡱ࠼࠲࠳ࠩࡕࡐࡕ࠼ࡵࡸࡲࡶ࠭ࡳࡣࡺࡁࠬू"), l1ll1ll_opy_ (u"ࠬ࠭ृ")).replace(l1ll1ll_opy_ (u"࠭࡜࡯ࠩॄ"), l1ll1ll_opy_ (u"ࠧࠨॅ"))
        l11l1ll1l_opy_.append((l11l1l111_opy_, l1l1l_opy_, value))
    return l11l1ll1l_opy_
def l11ll1lll_opy_(l1lllll_opy_):
    if l1lllll_opy_ == l1ll1ll_opy_ (u"ࠨࠥࡈ࡜࡙࠳ࡘ࠮ࡇࡑࡈࡑࡏࡓࡕࠩॆ"):
        return False
    l1lllll_opy_ = l1lllll_opy_.lower()
    filters = dixie.getFilters()
    for item in filters:
        item = item.lower()
        if item in l1lllll_opy_:
            return False
    return True
def l11l11l1l_opy_(l11l1l11l_opy_, url):
    import urllib
    if (l11l1l11l_opy_ == l1ll1ll_opy_ (u"ࠩࡘࡖࡑ࡙ࠧे")) or (l11l1l11l_opy_ == l1ll1ll_opy_ (u"ࠪࡇࡑࡕࡕࡅࠩै")):
        response = urllib.urlopen(url)
        content  = response.readlines()
        return content
    if l11l1l11l_opy_ == l1ll1ll_opy_ (u"ࠫࡋࡏࡌࡆࡕࠪॉ"):
        with open(url) as content:
            return content.readlines()
def l11llll11_opy_(l1l111111_opy_, l11l11l11_opy_, l11ll11ll_opy_, l11llll1l_opy_, l1l11111l_opy_):
    if l1l111111_opy_.startswith(l1ll1ll_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭ॊ")):
        url = l1l111111_opy_
    else:
        url = l1ll1ll_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧो") + l1l111111_opy_
    url +=  l11l1l1ll_opy_(l11l11l11_opy_)
    url += l1ll1ll_opy_ (u"ࠧ࠰ࡩࡨࡸ࠳ࡶࡨࡱࡁࡸࡷࡪࡸ࡮ࡢ࡯ࡨࡁࠬौ")
    url +=  l11llll1l_opy_
    url += l1ll1ll_opy_ (u"ࠨࠨࡳࡥࡸࡹࡷࡰࡴࡧࡁ्ࠬ")
    url +=  l1l11111l_opy_
    url += l1ll1ll_opy_ (u"ࠩࠩࡸࡾࡶࡥ࠾࡯࠶ࡹࡤࡶ࡬ࡶࡵࠩࡳࡺࡺࡰࡶࡶࡀࠫॎ")
    url +=  l11l1lll1_opy_(l11ll11ll_opy_)
    return url
def l11l1l1ll_opy_(l11l11l11_opy_):
    if not l11l11l11_opy_ == l1ll1ll_opy_ (u"ࠪࠫॏ"):
        return l1ll1ll_opy_ (u"ࠫ࠿࠭ॐ") + l11l11l11_opy_
    return l1ll1ll_opy_ (u"ࠬ࠭॑")
def l11l1lll1_opy_(l11ll11ll_opy_):
    if l11ll11ll_opy_ == l1ll1ll_opy_ (u"࠭࠰ࠨ॒"):
        return l1ll1ll_opy_ (u"ࠧ࡮࠵ࡸ࠼ࠬ॓")
    if l11ll11ll_opy_ == l1ll1ll_opy_ (u"ࠨ࠳ࠪ॔"):
        return l1ll1ll_opy_ (u"ࠩࡰࡴࡪ࡭ࡴࡴࠩॕ")
if __name__ == l1ll1ll_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬॖ"):
    l11ll111l_opy_()