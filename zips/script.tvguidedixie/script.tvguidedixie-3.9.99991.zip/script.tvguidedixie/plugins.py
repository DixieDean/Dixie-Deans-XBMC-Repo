# coding: UTF-8
import sys
l1l1l11l_opy_ = sys.version_info [0] == 2
l111l1l_opy_ = 2048
l1l1l1ll_opy_ = 7
def l1l1l_opy_ (l1l111_opy_):
	global l111lll_opy_
	l1llllll_opy_ = ord (l1l111_opy_ [-1])
	l1l1ll11_opy_ = l1l111_opy_ [:-1]
	l1l1111_opy_ = l1llllll_opy_ % len (l1l1ll11_opy_)
	l11l11_opy_ = l1l1ll11_opy_ [:l1l1111_opy_] + l1l1ll11_opy_ [l1l1111_opy_:]
	if l1l1l11l_opy_:
		l1111_opy_ = unicode () .join ([unichr (ord (char) - l111l1l_opy_ - (l1lll_opy_ + l1llllll_opy_) % l1l1l1ll_opy_) for l1lll_opy_, char in enumerate (l11l11_opy_)])
	else:
		l1111_opy_ = str () .join ([chr (ord (char) - l111l1l_opy_ - (l1lll_opy_ + l1llllll_opy_) % l1l1l1ll_opy_) for l1lll_opy_, char in enumerate (l11l11_opy_)])
	return eval (l1111_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l11l1111l_opy_     = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡴࡴࡷࠩॠ")
l111lll11_opy_  = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡷ࡭࡫ࡳࡸࡻ࠭ॡ")
l11l1ll11_opy_     = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡶ࡭ࡷࡹࡷࡱࠧॢ")
locked  = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮ࡲࡧࡰ࡫ࡤࡵࡸࠪॣ")
l111l1lll_opy_      = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸࡰࡹ࡯࡭ࡢࡶࡨࡱࡦࡴࡩࡢࠩ।")
l111ll1l1_opy_    = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰ࡮ࡻࡸ࠯ࡶࡹࠫ॥")
l111llll1_opy_     = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡉࡉࡓࡱࡱࡵࡸࡸ࠭०")
l11l1l1ll_opy_  = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡥࡣࡱࡲࡸࠬ१")
l111lllll_opy_     = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡣ࡭ࡷ࡬ࡴࡹࡼࠧ२")
l11l1l1l1_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡶ࡭ࡷࡺ࠹࡫ࡸࡱࡣࡷࡷ࠳ࡩ࡯࡮ࠩ३")
l1llll11_opy_ = [l11l1111l_opy_, locked, l111ll1l1_opy_, l111lll11_opy_, l11l1l1l1_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1l1l_opy_ (u"ࠩ࡬ࡲ࡮࠭४"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1l1ll1_opy_ = l1l1l_opy_ (u"ࠪࠫ५")
def l1l11l_opy_(i, t1, l1l1l1_opy_=[]):
 t = l1l1ll1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l1l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11_opy_ = l1l11l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11lll_opy_ = l1l11l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1llll11_opy_:
        if l1l1l1l1_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1l1l1l1_opy_(addon):
    if xbmc.getCondVisibility(l1l1l_opy_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡍࡧࡳࡂࡦࡧࡳࡳ࠮ࠥࡴࠫࠪ६") % addon) == 1:
        return True
    return False
def createINI(addon):
    l11lll1l_opy_ = str(addon).split(l1l1l_opy_ (u"ࠬ࠴ࠧ७"))[2] + l1l1l_opy_ (u"࠭࠮ࡪࡰ࡬ࠫ८")
    l1l11l1_opy_  = os.path.join(PATH, l11lll1l_opy_)
    try:
        l11llll_opy_ = l1lll1ll_opy_(addon)
    except KeyError:
        dixie.log(l1l1l_opy_ (u"ࠧ࠮࠯࠰࠱࠲ࠦࡋࡦࡻࡈࡶࡷࡵࡲࠡ࡫ࡱࠤ࡬࡫ࡴࡇ࡫࡯ࡩࡸࠦ࠭࠮࠯࠰࠱ࠥ࠭९") + addon)
        result = {l1l1l_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࡳࠨ॰"): [{l1l1l_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬॱ"): l1l1l_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࠩॲ"), l1l1l_opy_ (u"ࡹࠬࡺࡹࡱࡧࠪॳ"): l1l1l_opy_ (u"ࡺ࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧॴ"), l1l1l_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࠬॵ"): l1l1l_opy_ (u"ࡵࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡼࡽ࠭ॶ"), l1l1l_opy_ (u"ࡶࠩ࡯ࡥࡧ࡫࡬ࠨॷ"): l1l1l_opy_ (u"ࡷࠪࡒࡔࠦࡃࡉࡃࡑࡒࡊࡒࡓࠨॸ")}], l1l1l_opy_ (u"ࡸࠫࡱ࡯࡭ࡪࡶࡶࠫॹ"):{l1l1l_opy_ (u"ࡹࠬࡹࡴࡢࡴࡷࠫॺ"): 0, l1l1l_opy_ (u"ࡺ࠭ࡴࡰࡶࡤࡰࠬॻ"): 1, l1l1l_opy_ (u"ࡻࠧࡦࡰࡧࠫॼ"): 1}}
    l1l1ll_opy_  = l1l1l_opy_ (u"ࠧ࡜ࠩॽ") + addon + l1l1l_opy_ (u"ࠨ࡟࡟ࡲࠬॾ")
    l1ll1lll_opy_  =  file(l1l11l1_opy_, l1l1l_opy_ (u"ࠩࡺࠫॿ"))
    l1ll1lll_opy_.write(l1l1ll_opy_)
    l1l11lll_opy_ = []
    for channel in l11llll_opy_:
        l1l1_opy_ = dixie.cleanLabel(channel[l1l1l_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩঀ")])
        l1l11ll_opy_   = dixie.cleanPrefix(l1l1_opy_)
        l11l1l_opy_ = dixie.mapChannelName(l1l11ll_opy_)
        stream   = channel[l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࠩঁ")]
        l111l1_opy_ = l11l1l_opy_ + l1l1l_opy_ (u"ࠬࡃࠧং") + stream
        l1l11lll_opy_.append(l111l1_opy_)
        l1l11lll_opy_.sort()
    for item in l1l11lll_opy_:
        l1ll1lll_opy_.write(l1l1l_opy_ (u"ࠨࠥࡴ࡞ࡱࠦঃ") % item)
    l1ll1lll_opy_.close()
def l1lll1ll_opy_(addon):
    if (addon == l11l1111l_opy_) or (addon == l111lll11_opy_):
        if xbmcaddon.Addon(addon).getSetting(l1l1l_opy_ (u"ࠧࡨࡧࡱࡶࡪ࠭঄")) == l1l1l_opy_ (u"ࠨࡶࡵࡹࡪ࠭অ"):
            xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"ࠩࡪࡩࡳࡸࡥࠨআ"), l1l1l_opy_ (u"ࠪࡪࡦࡲࡳࡦࠩই"))
            xbmcgui.Window(10000).setProperty(l1l1l_opy_ (u"ࠫࡕࡒࡕࡈࡋࡑࡣࡌࡋࡎࡓࡇࠪঈ"), l1l1l_opy_ (u"࡚ࠬࡲࡶࡧࠪউ"))
        if xbmcaddon.Addon(addon).getSetting(l1l1l_opy_ (u"࠭ࡴࡷࡩࡸ࡭ࡩ࡫ࠧঊ")) == l1l1l_opy_ (u"ࠧࡵࡴࡸࡩࠬঋ"):
            xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"ࠨࡶࡹ࡫ࡺ࡯ࡤࡦࠩঌ"), l1l1l_opy_ (u"ࠩࡩࡥࡱࡹࡥࠨ঍"))
            xbmcgui.Window(10000).setProperty(l1l1l_opy_ (u"ࠪࡔࡑ࡛ࡇࡊࡐࡢࡘ࡛ࡍࡕࡊࡆࡈࠫ঎"), l1l1l_opy_ (u"࡙ࠫࡸࡵࡦࠩএ"))
        l111ll1ll_opy_  = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨঐ") + addon
        l11l1l111_opy_ =  l11l1lll1_opy_(addon)
        query   =  l111ll1ll_opy_ + l11l1l111_opy_
        return sendJSON(query, addon)
    return l11l11l11_opy_(addon)
def l11l11l11_opy_(addon):
    if addon == l11l1l1l1_opy_:
        l11l11l1l_opy_ = [l1l1l_opy_ (u"࠭࠱࠷࠳ࠪ঑"), l1l1l_opy_ (u"ࠧ࠲࠸࠳ࠫ঒"), l1l1l_opy_ (u"ࠨ࠴࠶࠺ࠬও"), l1l1l_opy_ (u"ࠩ࠵࠸࠷࠭ঔ"), l1l1l_opy_ (u"ࠪ࠵࠺࠾ࠧক"), l1l1l_opy_ (u"ࠫ࠶࠻࠹ࠨখ")]
    if addon == l111ll1l1_opy_:
        l11l11l1l_opy_ = [l1l1l_opy_ (u"ࠬ࠻ࠧগ"), l1l1l_opy_ (u"࠭࠱࠱࠸ࠪঘ"), l1l1l_opy_ (u"ࠧ࠵ࠩঙ"), l1l1l_opy_ (u"ࠨ࠴࠹࠷ࠬচ"), l1l1l_opy_ (u"ࠩ࠴࠷࠷࠭ছ")]
    if addon == locked:
        l11l11l1l_opy_ = [l1l1l_opy_ (u"ࠪ࠷࠵࠭জ"), l1l1l_opy_ (u"ࠫ࠸࠷ࠧঝ"), l1l1l_opy_ (u"ࠬ࠹࠲ࠨঞ"), l1l1l_opy_ (u"࠭࠳࠴ࠩট"), l1l1l_opy_ (u"ࠧ࠴࠶ࠪঠ"), l1l1l_opy_ (u"ࠨ࠵࠸ࠫড"), l1l1l_opy_ (u"ࠩ࠶࠼ࠬঢ"), l1l1l_opy_ (u"ࠪ࠸࠵࠭ণ"), l1l1l_opy_ (u"ࠫ࠹࠷ࠧত"), l1l1l_opy_ (u"ࠬ࠺࠵ࠨথ"), l1l1l_opy_ (u"࠭࠴࠸ࠩদ"), l1l1l_opy_ (u"ࠧ࠵࠻ࠪধ"), l1l1l_opy_ (u"ࠨ࠷࠵ࠫন")]
    if addon == l111l1lll_opy_:
        l11l11l1l_opy_ = [l1l1l_opy_ (u"ࠩ࠵࠹ࠬ঩"), l1l1l_opy_ (u"ࠪ࠶࠻࠭প"), l1l1l_opy_ (u"ࠫ࠷࠽ࠧফ"), l1l1l_opy_ (u"ࠬ࠸࠹ࠨব"), l1l1l_opy_ (u"࠭࠳࠱ࠩভ"), l1l1l_opy_ (u"ࠧ࠴࠳ࠪম"), l1l1l_opy_ (u"ࠨ࠵࠵ࠫয"), l1l1l_opy_ (u"ࠩ࠶࠹ࠬর"), l1l1l_opy_ (u"ࠪ࠷࠻࠭঱"), l1l1l_opy_ (u"ࠫ࠸࠽ࠧল"), l1l1l_opy_ (u"ࠬ࠹࠸ࠨ঳"), l1l1l_opy_ (u"࠭࠳࠺ࠩ঴"), l1l1l_opy_ (u"ࠧ࠵࠲ࠪ঵"), l1l1l_opy_ (u"ࠨ࠶࠴ࠫশ"), l1l1l_opy_ (u"ࠩ࠷࠼ࠬষ"), l1l1l_opy_ (u"ࠪ࠸࠾࠭স"), l1l1l_opy_ (u"ࠫ࠺࠶ࠧহ"), l1l1l_opy_ (u"ࠬ࠻࠲ࠨ঺"), l1l1l_opy_ (u"࠭࠵࠵ࠩ঻"), l1l1l_opy_ (u"ࠧ࠶࠸়ࠪ"), l1l1l_opy_ (u"ࠨ࠷࠺ࠫঽ"), l1l1l_opy_ (u"ࠩ࠸࠼ࠬা"), l1l1l_opy_ (u"ࠪ࠹࠾࠭ি"), l1l1l_opy_ (u"ࠫ࠻࠶ࠧী"), l1l1l_opy_ (u"ࠬ࠼࠱ࠨু"), l1l1l_opy_ (u"࠭࠶࠳ࠩূ"), l1l1l_opy_ (u"ࠧ࠷࠵ࠪৃ"), l1l1l_opy_ (u"ࠨ࠸࠸ࠫৄ"), l1l1l_opy_ (u"ࠩ࠹࠺ࠬ৅"), l1l1l_opy_ (u"ࠪ࠺࠼࠭৆"), l1l1l_opy_ (u"ࠫ࠻࠿ࠧে"), l1l1l_opy_ (u"ࠬ࠽࠰ࠨৈ"), l1l1l_opy_ (u"࠭࠷࠵ࠩ৉"), l1l1l_opy_ (u"ࠧ࠸࠹ࠪ৊"), l1l1l_opy_ (u"ࠨ࠹࠻ࠫো"), l1l1l_opy_ (u"ࠩ࠻࠴ࠬৌ"), l1l1l_opy_ (u"ࠪ࠼࠶্࠭")]
    login = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴ࠱ࠪৎ") % addon
    sendJSON(login, addon)
    l11l111_opy_ = []
    for l11l1ll1l_opy_ in l11l11l1l_opy_:
        if (addon == l11l1l1l1_opy_) or (addon == l111ll1l1_opy_):
            query = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠦࡵ࠲ࡃࡲࡵࡤࡦࡡ࡬ࡨࡂࡩࡨࡢࡰࡱࡩࡱࡹࠦ࡮ࡱࡧࡩࡂࡩࡨࡢࡰࡱࡩࡱࡹࠦࡴࡧࡦࡸ࡮ࡵ࡮ࡠ࡫ࡧࡁࠪࡹࠧ৏") % (addon, l11l1ll1l_opy_)
        if (addon == locked) or (addon == l111l1lll_opy_):
            query = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶ࠳ࡄࡻࡲ࡭࠿ࠨࡷࠫࡳ࡯ࡥࡧࡀ࠸ࠫࡴࡡ࡮ࡧࡀࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧࡲ࡯ࡥࡾࡃࠦࡥࡣࡷࡩࡂࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࡁࠫࡶࡡࡨࡧࡀࠫ৐") % (addon, l11l1ll1l_opy_)
        response = sendJSON(query, addon)
        l11l111_opy_.extend(response)
    return l11l111_opy_
def sendJSON(query, addon):
    l11l1l11l_opy_     = l1l1l_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ৑") % query
    l11l111l1_opy_  = xbmc.executeJSONRPC(l11l1l11l_opy_)
    response = json.loads(l11l111l1_opy_)
    result   = response[l1l1l_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨ৒")]
    if xbmcgui.Window(10000).getProperty(l1l1l_opy_ (u"ࠩࡓࡐ࡚ࡍࡉࡏࡡࡊࡉࡓࡘࡅࠨ৓")) == l1l1l_opy_ (u"ࠪࡘࡷࡻࡥࠨ৔"):
        xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ৕"), l1l1l_opy_ (u"ࠬࡺࡲࡶࡧࠪ৖"))
    if xbmcgui.Window(10000).getProperty(l1l1l_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡔࡗࡉࡘࡍࡉࡋࠧৗ")) == l1l1l_opy_ (u"ࠧࡕࡴࡸࡩࠬ৘"):
        xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"ࠨࡶࡹ࡫ࡺ࡯ࡤࡦࠩ৙"), l1l1l_opy_ (u"ࠩࡷࡶࡺ࡫ࠧ৚"))
    return result[l1l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩ৛")]
def l11l1lll1_opy_(addon):
    if (addon == l11l1111l_opy_) or (addon == l111lll11_opy_):
        return l1l1l_opy_ (u"ࠫ࠴ࡅࡣࡢࡶࡀ࠱࠷ࠬࡤࡢࡶࡨࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠨࡨࡲࡩࡊࡡࡵࡧࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦ࡮ࡱࡧࡩࡂ࠸ࠦ࡯ࡣࡰࡩࡂࡓࡹࠦ࠴࠳ࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡸࡥࡤࡱࡵࡨࡳࡧ࡭ࡦࠨࡶࡸࡦࡸࡴࡅࡣࡷࡩࠫࡻࡲ࡭࠿ࡸࡶࡱ࠭ড়")
    return l1l1l_opy_ (u"ࠬ࠭ঢ়")
def l1l1lll1_opy_():
    modules = map(__import__, [l1l11l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l1l1l_opy_ (u"࠭ࡔࡳࡷࡨࠫ৞")
    if len(modules[-1].Window(10**4).getProperty(l11lll_opy_)):
        return l1l1l_opy_ (u"ࠧࡕࡴࡸࡩࠬয়")
    return l1l1l_opy_ (u"ࠨࡈࡤࡰࡸ࡫ࠧৠ")
def l1l11111_opy_(e, addon):
    l1l1llll_opy_ = l1l1l_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠭ࠢࡤࡲࠥ࡫ࡲࡳࡱࡵࠤࡴࡩࡣࡶࡴࡨࡨ࠿ࠦࡊࡔࡑࡑࠤࡊࡸࡲࡰࡴ࠽ࠤࠪࡹࠬࠡࠧࡶࠫৡ")  % (e, addon)
    l11ll1l_opy_ = l1l1l_opy_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡧࡴࡴࡴࡢࡥࡷࠤࡺࡹࠠࡰࡰࠣࡸ࡭࡫ࠠࡧࡱࡵࡹࡲ࠴ࠧৢ")
    l1ll111l_opy_ = l1l1l_opy_ (u"࡚ࠫࡶ࡬ࡰࡣࡧࠤࡦࠦ࡬ࡰࡩࠣࡺ࡮ࡧࠠࡵࡪࡨࠤࡦࡪࡤࡰࡰࠣࡷࡪࡺࡴࡪࡰࡪࡷࠥࡧ࡮ࡥࠢࡳࡳࡸࡺࠠࡵࡪࡨࠤࡱ࡯࡮࡬࠰ࠪৣ")
    dixie.log(addon)
    dixie.log(e)
def getPluginInfo(streamurl, kodiID=False):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l111l1ll1_opy_   = l1l1l_opy_ (u"ࠬࡑ࡯ࡥ࡫ࠣࡔ࡛ࡘࠧ৤")
            l111ll11l_opy_ = os.path.join(dixie.RESOURCES, l1l1l_opy_ (u"࠭࡫ࡰࡦ࡬࠱ࡵࡼࡲ࠯ࡲࡱ࡫ࠬ৥"))
            return l111l1ll1_opy_, l111ll11l_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l1l1l_opy_ (u"ࠧࡳࡶࡰࡴࠬ০")) or url.startswith(l1l1l_opy_ (u"ࠨࡴࡷࡱࡵ࡫ࠧ১")) or url.startswith(l1l1l_opy_ (u"ࠩࡵࡸࡸࡶࠧ২")) or url.startswith(l1l1l_opy_ (u"ࠪ࡬ࡹࡺࡰࠨ৩")):
            l111l1ll1_opy_   = l1l1l_opy_ (u"ࠫࡲ࠹ࡵࠡࡒ࡯ࡥࡾࡲࡩࡴࡶࠪ৪")
            l111ll11l_opy_ = os.path.join(dixie.RESOURCES, l1l1l_opy_ (u"ࠬ࡯ࡰࡵࡸ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡶ࡮ࡨࠩ৫"))
            return l111l1ll1_opy_, l111ll11l_opy_
    except:
        pass
    if streamurl.startswith(l1l1l_opy_ (u"࠭ࡰࡷࡴ࠽࠳࠴࠭৬")):
        l111l1ll1_opy_   = l1l1l_opy_ (u"ࠧࡌࡱࡧ࡭ࠥࡖࡖࡓࠩ৭")
        l111ll11l_opy_ = os.path.join(dixie.RESOURCES, l1l1l_opy_ (u"ࠨ࡭ࡲࡨ࡮࠳ࡰࡷࡴ࠱ࡴࡳ࡭ࠧ৮"))
        return l111l1ll1_opy_, l111ll11l_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        l11l11111_opy_ = streamurl.split(l1l1l_opy_ (u"ࠩࡠࡓ࡙࡚࡟ࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ৯"), 1)[-1].split(l1l1l_opy_ (u"ࠪ࠳ࠬৰ"), 1)[0]
    if l1l1l_opy_ (u"ࠫࡢࡕࡔࡕࡡࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬৱ") in streamurl:
        l11l11111_opy_ = streamurl.split(l1l1l_opy_ (u"ࠬࡣࡏࡕࡖࡢࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭৲"), 1)[-1].split(l1l1l_opy_ (u"࠭࠯ࠨ৳"), 1)[0]
    if streamurl.startswith(l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ৴")):
        l11l11111_opy_ = streamurl.split(l1l1l_opy_ (u"ࠨ࠱࠲ࠫ৵"), 1)[-1].split(l1l1l_opy_ (u"ࠩ࠲ࠫ৶"), 1)[0]
    if l1l1l_opy_ (u"ࠪࡋࡘࡖࡒࡕࡕ࠽ࠫ৷") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡫࡮ࢀ࡭ࡰࡵࡳࡳࡷࡺࡳࠨ৸")
    if l1l1l_opy_ (u"ࠬࡥ࡟ࡔࡈࡢࡣࠬ৹") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡰࡳࡱࡪࡶࡦࡳ࠮ࡴࡷࡳࡩࡷ࠴ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵࠪ৺")
    if l1l1l_opy_ (u"ࠧࡗࡋࡓࡗࡘࡀࠧ৻") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡗࡋࡓࡗࡺࡶࡥࡳࡕࡷࡶࡪࡧ࡭ࡴࡖ࡙ࠫৼ")
    if l1l1l_opy_ (u"ࠩࡏࡍࡒ࠸࠺ࠨ৽") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡏ࡭ࡲ࡯ࡴ࡭ࡧࡶࡷ࡛࠸ࠧ৾")
    if l1l1l_opy_ (u"ࠫࡓࡇࡔࡉ࠼ࠪ৿") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡓࡧࡴࡩࡱ࠱ࡍࡕ࡚ࡖࠨ਀")
    if l1l1l_opy_ (u"࠭ࡎࡊࡅࡈ࠾ࠬਁ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡮ࡢࡶ࡫ࡳࡸࡻࡢࡴ࡫ࡦࡩࠬਂ")
    if l1l1l_opy_ (u"ࠨࡒࡕࡉࡒࡀࠧਃ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡲࡵࡩࡲ࡯ࡵ࡮࡫ࡳࡸࡻ࠭਄")
    if l1l1l_opy_ (u"ࠪࡋࡎࡠ࠺ࠨਅ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡫࡮ࢀ࡭ࡰࡶࡹࠫਆ")
    if l1l1l_opy_ (u"ࠬࡍࡅࡉ࠼ࠪਇ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡭ࡥࡩࡱࡶࡸ࡮ࡴࡧࠨਈ")
    if l1l1l_opy_ (u"ࠧࡎࡖ࡛ࡍࡊࡀࠧਉ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡮ࡣࡷࡶ࡮ࡾࡩࡳࡧ࡯ࡥࡳࡪࠧਊ")
    if l1l1l_opy_ (u"ࠩࡗ࡚ࡐࡀࠧ਋") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡷࡺࡰ࡯࡮ࡨࡵࠪ਌")
    if l1l1l_opy_ (u"ࠫ࡝࡚ࡃ࠻ࠩ਍") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡺࡲࡦࡣࡰ࠱ࡨࡵࡤࡦࡵࠪ਎")
    if l1l1l_opy_ (u"࠭ࡓࡄࡖ࡙࠾ࠬਏ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡤࡶࡹࠫਐ")
    if l1l1l_opy_ (u"ࠨࡕࡘࡔ࠿࠭਑") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡷࡶࡪࡧ࡭ࡴࡷࡳࡶࡪࡳࡥ࠳ࠩ਒")
    if l1l1l_opy_ (u"࡙ࠪࡐ࡚࠺ࠨਓ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡹࡰࡺࡵࡳ࡭ࠪਔ")
    if l1l1l_opy_ (u"ࠬࡒࡉࡎࡋࡗ࠾ࠬਕ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡒࡩ࡮࡫ࡷࡰࡪࡹࡳࡊࡒࡗ࡚ࠬਖ")
    if l1l1l_opy_ (u"ࠧࡇࡃࡅ࠾ࠬਗ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡧࡣࡥ࡬ࡴࡹࡴࡪࡰࡪࠫਘ")
    if l1l1l_opy_ (u"ࠩࡄࡇࡊࡀࠧਙ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡧࡪࡺࡶࠨਚ")
    if l1l1l_opy_ (u"ࠫࡍࡕࡒࡊ࡜࠽ࠫਛ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡭ࡵࡲࡪࡼࡲࡲ࡮ࡶࡴࡷࠩਜ")
    if l1l1l_opy_ (u"࠭ࡒࡐࡑࡗ࠶࠿࠭ਝ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡰࡱࡷࡍࡕ࡚ࡖࠨਞ")
    if l1l1l_opy_ (u"ࠨࡏࡈࡋࡆࡀࠧਟ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡯ࡨ࡫ࡦ࡯ࡰࡵࡸࠪਠ")
    if l1l1l_opy_ (u"࡚ࠪࡉࡘࡔࡗ࠼ࠪਡ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡚ࡆࡊࡅࡓࠩਢ")
    if l1l1l_opy_ (u"ࠬࡎࡄࡕࡘ࠽ࠫਣ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹ࡭ࡢࡴࡷ࡬ࡺࡨࠧਤ")
    if l1l1l_opy_ (u"ࠧࡉࡆࡗ࡚࠷ࡀࠧਥ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥ࠷࠭ਦ")
    if l1l1l_opy_ (u"ࠩࡋࡈ࡙࡜࠳࠻ࠩਧ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧ࠲ࠨਨ")
    if l1l1l_opy_ (u"ࠫࡍࡊࡔࡗ࠶࠽ࠫ਩") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡲࠧਪ")
    if l1l1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝࠿࠭ਫ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡢࡣࡥ࡬ࡴࡱࡧࡹࡦࡴࠪਬ")
    if l1l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠲࠻ࠩਭ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡰࡦࡿࡥࡳࡹࡺࡻࠬਮ")
    if l1l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡔ࠽ࠫਯ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽࠧਰ")
    if l1l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡍ࡙࡜࠺ࠨ਱") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡴࡷࠩਲ")
    if l1l1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡊ࠺ࠨਲ਼") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡥࡧࡻࠫ਴")
    if l1l1l_opy_ (u"ࠩࡍࡍࡓ࡞࠲࠻ࠩਵ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡭࡭ࡳࡾࡴࡷ࠴ࠪਸ਼")
    if l1l1l_opy_ (u"ࠫࡒࡇࡔࡔ࠼ࠪ਷") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡒࡧࡴࡴࡄࡸ࡭ࡱࡪࡳࡊࡒࡗ࡚ࠬਸ")
    if l1l1l_opy_ (u"࠭ࡒࡐࡑࡗ࠾ࠬਹ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡰࡱࡷ࡭ࡵࡺࡶࠨ਺")
    if l1l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡒࡃ࠼ࠪ਻") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡨࡦࡴࡵࡴࠨ਼")
    if l1l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡅࡏ࡙࠿࠭਽") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡧࡱࡻࡩࡱࡶࡹࠫਾ")
    if l1l1l_opy_ (u"ࠬࡏࡐࡕࡕࠪਿ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰࡵࡸࡶࡹࡧࡹࠧੀ")
    if l1l1l_opy_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠺ࠨੁ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡭࡫ࡹࡩࡲ࡯ࡸࠨੂ")
    if l1l1l_opy_ (u"ࠩࡈࡒࡉࡀࠧ੃") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡈࡲࡩࡲࡥࡴࡵࠪ੄")
    if l1l1l_opy_ (u"ࠫࡋࡒࡁ࠻ࠩ੅") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡋࡲࡡࡸ࡮ࡨࡷࡸ࡚ࡶࠨ੆")
    if l1l1l_opy_ (u"࠭ࡍࡂ࡚ࡌ࠾ࠬੇ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡭ࡢࡺ࡬ࡻࡪࡨࡴࡷࠩੈ")
    if l1l1l_opy_ (u"ࠨࡈࡏࡅࡘࡀࠧ੉") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡈ࡯ࡥࡼࡲࡥࡴࡵࡗࡺࠬ੊")
    if l1l1l_opy_ (u"ࠪࡗࡕࡘࡍ࠻ࠩੋ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡗࡺࡶࡲࡦ࡯ࡤࡧࡾ࡚ࡖࠨੌ")
    if l1l1l_opy_ (u"ࠬࡓࡃࡌࡖ࡙࠾੍ࠬ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡳࡣ࡬ࡶࡹ࠱ࡵࡲࡵࡴࠩ੎")
    if l1l1l_opy_ (u"ࠧࡕ࡙ࡌࡗ࡙ࡀࠧ੏") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡵࡹ࡬ࡷࡹ࡫ࡤࡵࡸࠪ੐")
    if l1l1l_opy_ (u"ࠩࡓࡖࡊ࡙ࡔ࠻ࠩੑ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡳࡷࡦࡪࡤࡰࡰࠪ੒")
    if l1l1l_opy_ (u"ࠫࡇࡒࡋࡊ࠼ࠪ੓") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡇࡲࡡࡤ࡭ࡌࡧࡪ࡚ࡖࠨ੔")
    if l1l1l_opy_ (u"࠭ࡆࡓࡇࡈ࠾ࠬ੕") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡦࡳࡧࡨࡺ࡮࡫ࡷࠨ੖")
    if l1l1l_opy_ (u"ࠨࡷࡳࡲࡵࡀࠧ੗") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰࡫ࡨ࡭ࡵ࡭ࡦࡴࡸࡲ࠳ࡼࡩࡦࡹࠪ੘")
    return l11l11lll_opy_(l11l11111_opy_, kodiID)
def l11l11lll_opy_(l11l11111_opy_, kodiID):
    l111l1ll1_opy_     = l1l1l_opy_ (u"ࠪࠫਖ਼")
    l111ll11l_opy_   = l1l1l_opy_ (u"ࠫࠬਗ਼")
    try:
        l11l1llll_opy_ = xbmcaddon.Addon(l11l11111_opy_).getAddonInfo(l1l1l_opy_ (u"ࠬࡴࡡ࡮ࡧࠪਜ਼"))
        l111l1ll1_opy_    = dixie.cleanLabel(l11l1llll_opy_)
        l111ll11l_opy_  = xbmcaddon.Addon(l11l11111_opy_).getAddonInfo(l1l1l_opy_ (u"࠭ࡩࡤࡱࡱࠫੜ"))
        if kodiID:
            l111ll111_opy_ = xbmcaddon.Addon(l11l11111_opy_).getAddonInfo(l1l1l_opy_ (u"ࠧࡪࡦࠪ੝"))
            return l111l1ll1_opy_, l111ll111_opy_
        return l111l1ll1_opy_, l111ll11l_opy_
    except:
        l111l1ll1_opy_   = l1l1l_opy_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡖࡳࡺࡸࡣࡦࠩਫ਼")
        l111ll11l_opy_ =  dixie.ICON
        return l111l1ll1_opy_, l111ll11l_opy_
    return l111l1ll1_opy_, l111ll11l_opy_
def selectStream(url, channel):
    l111l1l1l_opy_ = url.split(l1l1l_opy_ (u"ࠩࡿࠫ੟"))
    if len(l111l1l1l_opy_) == 0:
        return None
    options, l1l1l111_opy_ = getOptions(l111l1l1l_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l111l1l1l_opy_) == 1:
            return l1l1l111_opy_[0]
    import selectDialog
    l11l111ll_opy_ = selectDialog.select(l1l1l_opy_ (u"ࠪࡗࡪࡲࡥࡤࡶࠣࡥࠥࡹࡴࡳࡧࡤࡱࠬ੠"), options)
    if l11l111ll_opy_ < 0:
        raise Exception(l1l1l_opy_ (u"ࠫࡘ࡫࡬ࡦࡥࡷ࡭ࡴࡴࠠࡄࡣࡱࡧࡪࡲࠧ੡"))
    return l1l1l111_opy_[l11l111ll_opy_]
def getOptions(l111l1l1l_opy_, channel, addmore=True):
    options = []
    l1l1l111_opy_    = []
    for index, stream in enumerate(l111l1l1l_opy_):
        l111l1ll1_opy_ = getPluginInfo(stream)
        l1llll1_opy_ = l1l1l_opy_ (u"ࠬ࠭੢")
        l111lll1l_opy_  = l111l1ll1_opy_[1]
        if stream.startswith(OPEN_OTT):
            l11l11ll1_opy_ = stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l1l1l_opy_ (u"࠭ࠧ੣"))
            l1llll1_opy_  = l1llll1_opy_ + l11l11ll1_opy_
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l1l1l_opy_ (u"ࠧࠨ੤"))
        else:
            l1llll1_opy_  = l1llll1_opy_ + channel
        options.append([l1llll1_opy_, index, l111lll1l_opy_])
        l1l1l111_opy_.append(stream)
    if addmore:
        options.append([l1l1l_opy_ (u"ࠨࡃࡧࡨࠥࡳ࡯ࡳࡧ࠱࠲࠳࠭੥"), index + 1, dixie.ICON])
        l1l1l111_opy_.append(l1l1l_opy_ (u"ࠩࡤࡨࡩࡓ࡯ࡳࡧࠪ੦"))
    return options, l1l1l111_opy_
if __name__ == l1l1l_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬ੧"):
    checkAddons()