# coding: UTF-8
import sys
l11ll111_opy_ = sys.version_info [0] == 2
l1lll1l1_opy_ = 2048
l11lllll_opy_ = 7
def l1l11_opy_ (l11ll1_opy_):
	global l1llll11_opy_
	l1ll1111_opy_ = ord (l11ll1_opy_ [-1])
	l11ll11l_opy_ = l11ll1_opy_ [:-1]
	l11l11l_opy_ = l1ll1111_opy_ % len (l11ll11l_opy_)
	l111l1_opy_ = l11ll11l_opy_ [:l11l11l_opy_] + l11ll11l_opy_ [l11l11l_opy_:]
	if l11ll111_opy_:
		l1lll1_opy_ = unicode () .join ([unichr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	else:
		l1lll1_opy_ = str () .join ([chr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	return eval (l1lll1_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l1lll11ll_opy_    = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡯ࡶࡹࠫ࡟")
l1111111_opy_    = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡷ࡮ࡸࡺࡸ࡫ࠨࡠ")
locked = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡯ࡳࡨࡱࡥࡥࡶࡹࠫࡡ")
l1111ll1_opy_   = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡹࡸࡥࡢ࡯ࡷࡺࡧࡵࡸࠨࡢ")
l1ll11ll1_opy_     = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡶ࡯ࡳࡶࡶࡱࡦࡴࡩࡢࠩࡣ")
l1111l1l_opy_     = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹࡰࡰࡴࡷࡷࡳࡧࡴࡪࡱࡱ࡬ࡩࡺࡶࠨࡤ")
l1ll1l1l1_opy_     = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡵ࡭ࡶ࡬ࡱࡦࡺࡥ࡮ࡣࡱ࡭ࡦ࠭ࡥ")
l1ll111ll_opy_   = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡭࡫ࡸࡼ࠳ࡺࡶࠨࡦ")
l1lll1111_opy_    = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡆࡆࡗࡵࡵࡲࡵࡵࠪࡧ")
l1ll11l1l_opy_ = [l1111111_opy_, l1lll1111_opy_, l1lll11ll_opy_, locked, l1111ll1_opy_, l1ll111ll_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1l11_opy_ (u"ࠪ࡭ࡳ࡯ࠧࡨ"))
def checkAddons():
    for addon in l1ll11l1l_opy_:
        if l1llll111_opy_(addon):
            try: l1llll11l_opy_(addon)
            except: pass
def l1llll111_opy_(addon):
    if xbmc.getCondVisibility(l1l11_opy_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡍࡧࡳࡂࡦࡧࡳࡳ࠮ࠥࡴࠫࠪࡩ") % addon) == 1:
        return True
    return False
def l1llll11l_opy_(addon):
    l11111ll_opy_ = str(addon).split(l1l11_opy_ (u"ࠬ࠴ࠧࡪ"))[2] + l1l11_opy_ (u"࠭࠮ࡪࡰ࡬ࠫ࡫")
    l1ll11lll_opy_  = os.path.join(PATH, l11111ll_opy_)
    l1111l11_opy_ = l111l111_opy_(addon)
    l1ll1lll1_opy_  = file(l1ll11lll_opy_, l1l11_opy_ (u"ࠧࡸࠩ࡬"))
    l1ll1lll1_opy_.write(l1l11_opy_ (u"ࠨ࡝ࠪ࡭"))
    l1ll1lll1_opy_.write(addon)
    l1ll1lll1_opy_.write(l1l11_opy_ (u"ࠩࡠࠫ࡮"))
    l1ll1lll1_opy_.write(l1l11_opy_ (u"ࠪࡠࡳ࠭࡯"))
    for channel in l1111l11_opy_:
        l1lllll11_opy_  = channel[l1l11_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪࡰ")]
        l1lllll11_opy_  = l1lllll11_opy_.replace(l1l11_opy_ (u"ࠬ࠴࠮࠯࠰࠱ࠫࡱ"), l1l11_opy_ (u"࠭ࠧࡲ")).replace(l1l11_opy_ (u"ࠧ࠻ࠩࡳ"), l1l11_opy_ (u"ࠨࠩࡴ")).replace(l1l11_opy_ (u"ࠩࠣ࡟ࠬࡵ"), l1l11_opy_ (u"ࠪ࡟ࠬࡶ")).replace(l1l11_opy_ (u"ࠫࡢࠦࠧࡷ"), l1l11_opy_ (u"ࠬࡣࠧࡸ")).replace(l1l11_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡡࡲࡷࡤࡡࠬࡹ"), l1l11_opy_ (u"ࠧࠨࡺ")).replace(l1l11_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬ࡱࡪ࡭ࡲࡦࡧࡱࡡࠬࡻ"), l1l11_opy_ (u"ࠩࠪࡼ")).replace(l1l11_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡷ࡫ࡥ࡯࡟ࠪࡽ"), l1l11_opy_ (u"ࠫࠬࡾ")).replace(l1l11_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡿࡥ࡭࡮ࡲࡻࡢ࠭ࡿ"), l1l11_opy_ (u"࠭ࠧࢀ")).replace(l1l11_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢ࠭ࢁ"), l1l11_opy_ (u"ࠨࠩࢂ")).replace(l1l11_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡲࡶࡦࡴࡧࡦ࡟ࠪࢃ"), l1l11_opy_ (u"ࠪࠫࢄ")).replace(l1l11_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞ࠩࢅ"), l1l11_opy_ (u"ࠬ࠭ࢆ")).replace(l1l11_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡷࡩ࡫ࡷࡩࡢ࠭ࢇ"), l1l11_opy_ (u"ࠧࠨ࢈")).replace(l1l11_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢉ"), l1l11_opy_ (u"ࠩࠪࢊ")).replace(l1l11_opy_ (u"ࠪ࡟ࡎࡣࠧࢋ"), l1l11_opy_ (u"ࠫࠬࢌ")).replace(l1l11_opy_ (u"ࠬࡡ࠯ࡊ࡟ࠪࢍ"), l1l11_opy_ (u"࠭ࠧࢎ")).replace(l1l11_opy_ (u"ࠧ࡜ࡄࡠࠫ࢏"), l1l11_opy_ (u"ࠨࠩ࢐")).replace(l1l11_opy_ (u"ࠩ࡞࠳ࡇࡣࠧ࢑"), l1l11_opy_ (u"ࠪࠫ࢒"))
        stream = channel[l1l11_opy_ (u"ࠫ࡫࡯࡬ࡦࠩ࢓")]
        l1ll1lll1_opy_.write(l1l11_opy_ (u"ࠬࠫࡳࠨ࢔") % l1lllll11_opy_)
        l1ll1lll1_opy_.write(l1l11_opy_ (u"࠭࠽ࠨ࢕"))
        l1ll1lll1_opy_.write(l1l11_opy_ (u"ࠧࠦࡵࠪ࢖") % stream)
        l1ll1lll1_opy_.write(l1l11_opy_ (u"ࠨ࡞ࡱࠫࢗ"))
    l1ll1lll1_opy_.write(l1l11_opy_ (u"ࠩ࡟ࡲࠬ࢘"))
    l1ll1lll1_opy_.close()
def l111l111_opy_(addon):
    if addon == l1111111_opy_:
        return l1lll11l1_opy_(addon)
    if addon == l1lll1111_opy_:
        return l11111l1_opy_(addon)
    if addon in [l1ll11ll1_opy_, l1111l1l_opy_, l1ll1l1l1_opy_]:
        return
    try:
        if xbmcaddon.Addon(addon).getSetting(l1l11_opy_ (u"ࠪ࡫ࡪࡴࡲࡦ࢙ࠩ")) == l1l11_opy_ (u"ࠫࡹࡸࡵࡦ࢚ࠩ"):
            xbmcaddon.Addon(addon).setSetting(l1l11_opy_ (u"ࠬ࡭ࡥ࡯ࡴࡨ࢛ࠫ"), l1l11_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬ࢜"))
            xbmcgui.Window(10000).setProperty(l1l11_opy_ (u"ࠧࡑࡎࡘࡋࡎࡔ࡟ࡈࡇࡑࡖࡊ࠭࢝"), l1l11_opy_ (u"ࠨࡖࡵࡹࡪ࠭࢞"))
        if xbmcaddon.Addon(addon).getSetting(l1l11_opy_ (u"ࠩࡷࡺ࡬ࡻࡩࡥࡧࠪ࢟")) == l1l11_opy_ (u"ࠪࡸࡷࡻࡥࠨࢠ"):
            xbmcaddon.Addon(addon).setSetting(l1l11_opy_ (u"ࠫࡹࡼࡧࡶ࡫ࡧࡩࠬࢡ"), l1l11_opy_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫࢢ"))
            xbmcgui.Window(10000).setProperty(l1l11_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡔࡗࡉࡘࡍࡉࡋࠧࢣ"), l1l11_opy_ (u"ࠧࡕࡴࡸࡩࠬࢤ"))
    except: pass
    l1ll1ll1l_opy_  = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫࢥ") + addon
    l1llll1l1_opy_ =  l1111lll_opy_(addon)
    query   =  l1ll1ll1l_opy_ + l1llll1l1_opy_
    return sendJSON(query, addon)
def l1ll1l11l_opy_(addon):
    l1lll1l11_opy_   =  []
    query    = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬࢦ") + addon
    response =  sendJSON(query, addon)
    for item in response:
        if not l1l11_opy_ (u"ࠪ࠲ࠬࢧ") in item[l1l11_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪࢨ")]:
            l1lll1l11_opy_.append(item[l1l11_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪࢩ")])
    l1lll1lll_opy_ = []
    for l1lll111l_opy_ in l1lll1l11_opy_:
        response = sendJSON(l1lll111l_opy_, addon)
        l1lll1lll_opy_.extend(response)
    return l1lll1lll_opy_
def l1lll11l1_opy_(addon):
    l1ll1ll1l_opy_ = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩࢪ") + addon
    l1ll111l1_opy_ = l1l11_opy_ (u"ࠧ࠰ࡁࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡲࡵࡤࡦ࠿࠴ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡻ࡫ࠥ࠳࠲ࡗ࡚ࠫࡻࡲ࡭࠿࡫ࡸࡹࡶࠥ࠴ࡣࠨ࠶࡫ࠫ࠲ࡧ࡯ࡨࡸࡦࡲ࡫ࡦࡶࡷࡰࡪ࠴ࡣࡰࠧ࠵ࡪ࡚ࡑࡔࡶࡴ࡮࠵࠽࠶࠲࠳࠲࠴࠺ࠪ࠸ࡦࡍ࡫ࡹࡩࠪ࠸࠵࠳࠲ࡗ࡚࠳ࡺࡸࡵࠩࢫ")
    l1ll11l11_opy_ = l1l11_opy_ (u"ࠨ࠱ࡂࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡳ࡯ࡥࡧࡀ࠵ࠫࡴࡡ࡮ࡧࡀࡗࡵࡵࡲࡵࡵࠩࡹࡷࡲ࠽ࡩࡶࡷࡴࠪ࠹ࡡࠦ࠴ࡩࠩ࠷࡬࡭ࡦࡶࡤࡰࡰ࡫ࡴࡵ࡮ࡨ࠲ࡨࡵࠥ࠳ࡨࡘࡏ࡙ࡻࡲ࡬࠳࠻࠴࠷࠸࠰࠲࠸ࠨ࠶࡫࡙ࡰࡰࡴࡷࡷࡑ࡯ࡳࡵ࠰ࡷࡼࡹ࠭ࢬ")
    l1lll1lll_opy_  = []
    l1lll1lll_opy_ += sendJSON(l1ll1ll1l_opy_ + l1ll111l1_opy_, addon)
    l1lll1lll_opy_ += sendJSON(l1ll1ll1l_opy_ + l1ll11l11_opy_, addon)
    return l1lll1lll_opy_
def l11111l1_opy_(addon):
    l1ll1ll1l_opy_ = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬࢭ") + addon
    l1ll111l1_opy_ = l1l11_opy_ (u"ࠪ࠳ࡄ࡬ࡡ࡯ࡣࡵࡸࡂ࡮ࡴࡵࡲࠨ࠷ࡦࠫ࠲ࡧࠧ࠵ࡪ࡬ࡵ࡯࠯ࡩ࡯ࠩ࠷࡬ࡘࡥࡈ࠵࠼࡙ࠬ࡭ࡰࡦࡨࡁ࠶ࠬ࡮ࡢ࡯ࡨࡁࡑ࡯ࡶࡦࠧ࠵࠴࡚ࡑࠥ࠳࠲ࡖࡴࡴࡸࡴࡴࠨࡸࡶࡱࡃࡨࡵࡶࡳࡷࠪ࠹ࡡࠦ࠴ࡩࠩ࠷࡬ࡧࡰࡱ࠱࡫ࡱࠫ࠲ࡧ࠷ࡴࡕ࡬ࡋ࠴ࠨࢮ")
    l1ll11l11_opy_ = l1l11_opy_ (u"ࠫ࠴ࡅࡦࡢࡰࡤࡶࡹࡃࡨࡵࡶࡳࡷࠪ࠹ࡡࠦ࠴ࡩࠩ࠷࡬ࡧࡰࡱ࠱࡫ࡱࠫ࠲ࡧࡈࡪ࡛ࡒࡱ࡚ࠧ࡯ࡲࡨࡪࡃ࠱ࠧࡰࡤࡱࡪࡃࡌࡪࡸࡨࠩ࠷࠶ࡕࡔࠧ࠵ࡪࡈࡇࡎࠦ࠴࠳ࡗࡵࡵࡲࡵࡵࠩࡹࡷࡲ࠽ࡩࡶࡷࡴࡸࠫ࠳ࡢࠧ࠵ࡪࠪ࠸ࡦࡨࡱࡲ࠲࡬ࡲࠥ࠳ࡨࡩ࠽࡯࡭࠸ࡏࠩࢯ")
    l1lll1lll_opy_  = []
    l1lll1lll_opy_ += sendJSON(l1ll1ll1l_opy_ + l1ll111l1_opy_, addon)
    l1lll1lll_opy_ += sendJSON(l1ll1ll1l_opy_ + l1ll11l11_opy_, addon)
    return l1lll1lll_opy_
def l1111lll_opy_(addon):
    if addon == l1lll11ll_opy_:
        return l1l11_opy_ (u"ࠬ࠵࠿ࡤࡣࡷࡁ࠲࠸ࠦ࡮ࡱࡧࡩࡂ࠸ࠦ࡯ࡣࡰࡩࡂࡓࡹࠦ࠴࠳ࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡻࡲ࡭࠿ࡸࡶࡱ࠭ࢰ")
    return l1l11_opy_ (u"࠭ࠧࢱ")
def sendJSON(query, addon):
    try:
        l1llll1ll_opy_     = l1l11_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࢲ") % query
        l1lll1l1l_opy_  = xbmc.executeJSONRPC(l1llll1ll_opy_)
        response = json.loads(l1lll1l1l_opy_)
        if xbmcgui.Window(10000).getProperty(l1l11_opy_ (u"ࠨࡒࡏ࡙ࡌࡏࡎࡠࡉࡈࡒࡗࡋࠧࢳ")) == l1l11_opy_ (u"ࠩࡗࡶࡺ࡫ࠧࢴ"):
            xbmcaddon.Addon(addon).setSetting(l1l11_opy_ (u"ࠪ࡫ࡪࡴࡲࡦࠩࢵ"), l1l11_opy_ (u"ࠫࡹࡸࡵࡦࠩࢶ"))
            xbmcgui.Window(10000).clearProperty(l1l11_opy_ (u"ࠬࡖࡌࡖࡉࡌࡒࡤࡍࡅࡏࡔࡈࠫࢷ"))
        if xbmcgui.Window(10000).getProperty(l1l11_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡔࡗࡉࡘࡍࡉࡋࠧࢸ")) == l1l11_opy_ (u"ࠧࡕࡴࡸࡩࠬࢹ"):
            xbmcaddon.Addon(addon).setSetting(l1l11_opy_ (u"ࠨࡶࡹ࡫ࡺ࡯ࡤࡦࠩࢺ"), l1l11_opy_ (u"ࠩࡷࡶࡺ࡫ࠧࢻ"))
            xbmcgui.Window(10000).clearProperty(l1l11_opy_ (u"ࠪࡔࡑ࡛ࡇࡊࡐࡢࡘ࡛ࡍࡕࡊࡆࡈࠫࢼ"))
        return response[l1l11_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫࢽ")][l1l11_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫࢾ")]
    except Exception as e:
        l1ll1llll_opy_(e, addon)
        return {l1l11_opy_ (u"࠭ࡅࡳࡴࡲࡶࠬࢿ") : l1l11_opy_ (u"ࠧࡑ࡮ࡸ࡫࡮ࡴࠠࡆࡴࡵࡳࡷ࠭ࣀ")}
def l1ll1llll_opy_(e, addon):
    l1lllll1l_opy_ = l1l11_opy_ (u"ࠨࡕࡲࡶࡷࡿࠬࠡࡣࡱࠤࡪࡸࡲࡰࡴࠣࡳࡨࡩࡵࡳࡧࡧ࠾ࠥࡐࡓࡐࡐࠣࡉࡷࡸ࡯ࡳ࠼ࠣࠩࡸ࠲ࠠࠦࡵࠪࣁ")  % (e, addon)
    l1llllll1_opy_ = l1l11_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡹࡸࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡦࡰࡴࡸࡱ࠳࠭ࣂ")
    l1lllllll_opy_ = l1l11_opy_ (u"࡙ࠪࡵࡲ࡯ࡢࡦࠣࡥࠥࡲ࡯ࡨࠢࡹ࡭ࡦࠦࡴࡩࡧࠣࡥࡩࡪ࡯࡯ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠤࡦࡴࡤࠡࡲࡲࡷࡹࠦࡴࡩࡧࠣࡰ࡮ࡴ࡫࠯ࠩࣃ")
    dixie.log(addon)
    dixie.log(e)
def getPlaylist():
    import requests
    l1lll1ll1_opy_ = [l1l11_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡬ࡵ࠲࡭࠰࡬ࡲࡰ࠵࡫ࡰࡦ࡬ࠫࣄ"), l1l11_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲ࡨࡧࡩࡨ࠱࠳ࠪࣅ"), l1l11_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬࠲ࡨࡩ࡬ࡥ࠰࡬ࡳࠬࣆ"), l1l11_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡢ࡫ࡲ࠲ࡨࡩ࡬ࡰࡷࡧࡸࡻ࠴࡯ࡳࡩ࠲࡯ࡴࡪࡩࠨࣇ")]
    l1ll1ll11_opy_ =  l1l11_opy_ (u"ࠨࠥࡈ࡜࡙ࡓ࠳ࡖࠩࣈ")
    for url in l1lll1ll1_opy_:
        dixie.log(url)
        try:
            request  = requests.get(url)
            l111111l_opy_ = request.text
        except: pass
        if l1ll1ll11_opy_ in l111111l_opy_:
            path = os.path.join(dixie.PROFILE, l1l11_opy_ (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡲ࠹ࡵࠨࣉ"))
            with open(path, l1l11_opy_ (u"ࠪࡻࠬ࣊")) as f:
                f.write(l111111l_opy_)
                break
def getPluginInfo(streamurl):
    if streamurl.isdigit():
        l1ll1l111_opy_   = l1l11_opy_ (u"ࠫࡐࡵࡤࡪࠢࡓ࡚ࡗࠦࡃࡩࡣࡱࡲࡪࡲࠧ࣋")
        l1ll1l1ll_opy_ = os.path.join(dixie.RESOURCES, l1l11_opy_ (u"ࠬࡱ࡯ࡥ࡫࠰ࡴࡻࡸ࠮ࡱࡰࡪࠫ࣌"))
        return l1ll1l111_opy_, l1ll1l1ll_opy_
    if streamurl.startswith(l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ࣍")):
        name = streamurl.split(l1l11_opy_ (u"ࠧ࠰࠱ࠪ࣎"), 1)[-1].split(l1l11_opy_ (u"ࠨ࠱࣏ࠪ"), 1)[0]
    if streamurl.startswith(l1l11_opy_ (u"ࠩࡢࡣࡘࡌ࡟ࡠ࣐ࠩ")):
        name = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡴࡷࡵࡧࡳࡣࡰ࠲ࡸࡻࡰࡦࡴ࠱ࡪࡦࡼ࡯ࡶࡴ࡬ࡸࡪࡹ࣑ࠧ")
    if streamurl.startswith(l1l11_opy_ (u"ࠫࡍࡊࡔࡗ࠼࣒ࠪ")):
        name = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡭ࡪࡴࡷ࣓ࠩ")
    if streamurl.startswith(l1l11_opy_ (u"࠭ࡈࡅࡖ࡙࠶࠿࠭ࣔ")):
        name = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࡭ࡵࡺࡶࠨࣕ")
    if streamurl.startswith(l1l11_opy_ (u"ࠨࡊࡇࡘ࡛࠹࠺ࠨࣖ")):
        name = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦࡺࡶࠨࣗ")
    if streamurl.startswith(l1l11_opy_ (u"ࠪࡌࡉ࡚ࡖ࠵࠼ࠪࣘ")):
        name = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡱ࠭ࣙ")
    if streamurl.startswith(l1l11_opy_ (u"ࠬࡏࡐࡍࡃ࡜࠾ࠬࣚ")):
        name = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡨࡢࡤ࡫ࡳࡰࡦࡿࡥࡳࠩࣛ")
    if streamurl.startswith(l1l11_opy_ (u"ࠧࡊࡒࡏࡅ࡞࠸࠺ࠨࣜ")):
        name = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺࠫࣝ")
    if streamurl.startswith(l1l11_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡓ࠼ࠪࣞ")):
        name = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠭ࣟ")
    if streamurl.startswith(l1l11_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡌࡘ࡛ࡀࠧ࣠")):
        name = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡺࡶࠨ࣡")
    if streamurl.startswith(l1l11_opy_ (u"࠭ࡌࡊࡘࡈࡘ࡛ࡀࠧ࣢")):
        name = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡬ࡪࡸࡨࡱ࡮ࡾࣣࠧ")
    if streamurl.startswith(l1l11_opy_ (u"ࠨࡷࡳࡲࡵࡀࠧࣤ")):
        name = l1l11_opy_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰࡫ࡨ࡭ࡵ࡭ࡦࡴࡸࡲ࠳ࡼࡩࡦࡹࠪࣥ")
    try:
        l1ll1l111_opy_   = xbmcaddon.Addon(name).getAddonInfo(l1l11_opy_ (u"ࠪࡲࡦࡳࡥࠨࣦ"))
        l1ll1l1ll_opy_ = xbmcaddon.Addon(name).getAddonInfo(l1l11_opy_ (u"ࠫ࡮ࡩ࡯࡯ࠩࣧ"))
    except:
        l1ll1l111_opy_   = l1l11_opy_ (u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡳࡵࡴࡨࡥࡲࠦ࡯ࡳࠢࡤࡨࡩ࠳࡯࡯ࠩࣨ")
        l1ll1l1ll_opy_ =  dixie.ICON
    return l1ll1l111_opy_, l1ll1l1ll_opy_