# coding: UTF-8
import sys
l11llll_opy_ = sys.version_info [0] == 2
l1llll1_opy_ = 2048
l1llll_opy_ = 7
def l11l11_opy_ (ll_opy_):
	global l1lllll_opy_
	l1l1111_opy_ = ord (ll_opy_ [-1])
	l1111l_opy_ = ll_opy_ [:-1]
	l1ll111_opy_ = l1l1111_opy_ % len (l1111l_opy_)
	l1l1l_opy_ = l1111l_opy_ [:l1ll111_opy_] + l1111l_opy_ [l1ll111_opy_:]
	if l11llll_opy_:
		l1ll1ll_opy_ = unicode () .join ([unichr (ord (char) - l1llll1_opy_ - (l11ll1_opy_ + l1l1111_opy_) % l1llll_opy_) for l11ll1_opy_, char in enumerate (l1l1l_opy_)])
	else:
		l1ll1ll_opy_ = str () .join ([chr (ord (char) - l1llll1_opy_ - (l11ll1_opy_ + l1l1111_opy_) % l1llll_opy_) for l11ll1_opy_, char in enumerate (l1l1l_opy_)])
	return eval (l1ll1ll_opy_)
import xbmc
import xbmcaddon
import json
import urllib
import os
import dixie
l111l1ll1_opy_   = l11l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡶ࡭ࡷࡺ࡫ࡸࡡ࡯ࡥࡨࠫી")
l111l11ll_opy_ = l11l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࡯ࡰࡵࡸࠪુ")
l1111llll_opy_    = l11l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡴࡹ࡮ࡩ࡫ࡪࡲࡷࡺࠬૂ")
l111ll111_opy_   = l11l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡪࡺࡺࡵࡳࡧࡶࡸࡷ࡫ࡡ࡮ࡵࠪૃ")
l111l1111_opy_    = l11l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡶࡩ࡯ࡼࠪૄ")
l111l1l1l_opy_  = l11l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹࡴࡦࡣ࡯ࡸ࡭ࡻ࡮ࡥࡧࡵ࡫ࡷࡵࡵ࡯ࡦࠪૅ")
l1111lll1_opy_     = l11l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡯ࡵࡶࡤࡰࡵ࡮ࡡࠨ૆")
l11l11l_opy_   =  [l111l1ll1_opy_, l1111llll_opy_, l111ll111_opy_, l111l1111_opy_, l111l1l1l_opy_, l1111lll1_opy_]
def checkAddons():
    for addon in l11l11l_opy_:
        if l11l1ll_opy_(addon):
            createINI(addon)
def l11l1ll_opy_(addon):
    if xbmc.getCondVisibility(l11l11_opy_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫࠩࡸ࠯ࠧે") % addon) == 1:
        return True
    else:
        return False
def createINI(addon):
    HOME = dixie.PROFILE
    PATH = os.path.join(HOME, l11l11_opy_ (u"ࠩ࡬ࡲ࡮࠭ૈ"))
    l11_opy_ = str(addon).split(l11l11_opy_ (u"ࠪ࠲ࠬૉ"))[2] + l11l11_opy_ (u"ࠫ࠳࡯࡮ࡪࠩ૊")
    l1l_opy_  = os.path.join(PATH, l11_opy_)
    response = l1_opy_(addon)
    try:
        result = response[l11l11_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬો")]
    except KeyError:
        dixie.log(l11l11_opy_ (u"࠭࠭࠮࠯࠰࠱ࠥࡑࡥࡺࡇࡵࡶࡴࡸࠠࡪࡰࠣ࡫ࡪࡺࡆࡪ࡮ࡨࡷࠥ࠳࠭࠮࠯࠰ࠤࠬૌ") + addon)
        result = {l11l11_opy_ (u"ࡵࠨࡨ࡬ࡰࡪࡹ્ࠧ"): [{l11l11_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ૎"): l11l11_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࠨ૏"), l11l11_opy_ (u"ࡸࠫࡹࡿࡰࡦࠩૐ"): l11l11_opy_ (u"ࡹࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭૑"), l11l11_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࠫ૒"): l11l11_opy_ (u"ࡻࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡺࡻࡼࠬ૓"), l11l11_opy_ (u"ࡵࠨ࡮ࡤࡦࡪࡲࠧ૔"): l11l11_opy_ (u"ࡶࠩࡑࡓࠥࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ૕")}], l11l11_opy_ (u"ࡷࠪࡰ࡮ࡳࡩࡵࡵࠪ૖"): {l11l11_opy_ (u"ࡸࠫࡸࡺࡡࡳࡶࠪ૗"): 0, l11l11_opy_ (u"ࡹࠬࡺ࡯ࡵࡣ࡯ࠫ૘"): 1, l11l11_opy_ (u"ࡺ࠭ࡥ࡯ࡦࠪ૙"): 1}}
    l1l1l1l_opy_ = result[l11l11_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬ૚")]
    l1l1l11_opy_  = file(l1l_opy_, l11l11_opy_ (u"ࠧࡸࠩ૛"))
    l1l1l11_opy_.write(l11l11_opy_ (u"ࠨ࡝ࠪ૜"))
    l1l1l11_opy_.write(addon)
    l1l1l11_opy_.write(l11l11_opy_ (u"ࠩࡠࠫ૝"))
    l1l1l11_opy_.write(l11l11_opy_ (u"ࠪࡠࡳ࠭૞"))
    l1ll11_opy_ = []
    for channel in l1l1l1l_opy_:
        l11lll_opy_ = dixie.cleanLabel(channel[l11l11_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪ૟")])
        l1ll1_opy_ = dixie.mapChannelName(l11lll_opy_)
        stream   = channel[l11l11_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪૠ")]
        l11l1_opy_ = l1ll1_opy_ + l11l11_opy_ (u"࠭࠽ࠨૡ") + stream
        l1ll11_opy_.append(l11l1_opy_)
        l1ll11_opy_.sort()
    for item in l1ll11_opy_:
      l1l1l11_opy_.write(l11l11_opy_ (u"ࠢࠦࡵ࡟ࡲࠧૢ") % item)
    l1l1l11_opy_.close()
def l1_opy_(addon):
    l111l1l11_opy_ = (l11l11_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫૣ") % addon)
    if addon == l111l1l1l_opy_:
        login = l11l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡹ࡫ࡡ࡭ࡶ࡫ࡹࡳࡪࡥࡳࡩࡵࡳࡺࡴࡤ࠰ࡁࡰࡳࡩ࡫࠽ࡨࡧࡱࡶࡪࡹࠦࡱࡱࡵࡸࡦࡲ࠽ࠦ࠹ࡥࠩ࠷࠸࡮ࡢ࡯ࡨࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࠫ࠲࠳ࠧ࠸ࡦࡎࠫ࠵ࡥࠧ࠸ࡦࡈࡕࡌࡐࡔࠨ࠶࠵ࡽࡨࡪࡶࡨࠩ࠺ࡪࡃ࡭࡫ࡦ࡯ࠪ࠸࠰ࡕࡱࠨ࠶࠵࡜ࡩࡦࡹࠨ࠶࠵࡚ࡨࡦࠧ࠵࠴ࡑ࡯ࡳࡵࠧ࠵࠴ࡔ࡬ࠥ࠳࠲ࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠩ࠺ࡨࠥ࠳ࡨࡆࡓࡑࡕࡒࠦ࠷ࡧࠩ࠺ࡨࠥ࠳ࡨࡌࠩ࠺ࡪࠥ࠳࠴ࠨ࠶ࡨࠫ࠲࠱ࠧ࠵࠶ࡵࡧࡲࡦࡰࡷࡥࡱࠫ࠲࠳ࠧ࠶ࡥࠪ࠸࠰ࠦ࠴࠵ࡪࡦࡲࡳࡦࠧ࠵࠶ࠪ࠸ࡣࠦ࠴࠳ࠩ࠷࠸ࡵࡳ࡮ࠨ࠶࠷ࠫ࠳ࡢࠧ࠵࠴ࠪ࠸࠲ࡩࡶࡷࡴࠪ࠹ࡡࠦ࠴ࡩࠩ࠷࡬࡭ࡸ࠳࠱࡭ࡵࡺࡶ࠷࠸࠱ࡸࡻࠫ࠲࠳ࠧ࠵ࡧࠪ࠸࠰ࠦ࠴࠵ࡴࡵࡧࡳࡴࡹࡲࡶࡩࠫ࠲࠳ࠧ࠶ࡥࠪ࠸࠰ࠦ࠴࠵࠴࠵࠶࠰ࠦ࠴࠵ࠩ࠷ࡩࠥ࠳࠲ࠨ࠶࠷ࡳࡡࡤࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࠩ࠷࠸࠰࠱ࠧ࠶ࡥ࠶ࡇࠥ࠴ࡣ࠺࠼ࠪ࠹ࡡ࠵࠵ࠨ࠷ࡦ࠷࠲ࠦ࠵ࡤ࠻࠹ࠫ࠲࠳ࠧ࠵ࡧࠪ࠸࠰ࠦ࠴࠵ࡷࡪࡸࡩࡢ࡮ࠨ࠶࠷ࠫ࠳ࡢࠧ࠵࠴ࠪ࠽ࡢࠦ࠴࠵ࡷࡪࡴࡤࡠࡵࡨࡶ࡮ࡧ࡬ࠦ࠴࠵ࠩ࠸ࡧࠥ࠳࠲ࡷࡶࡺ࡫ࠥ࠳ࡥࠨ࠶࠵ࠫ࠲࠳ࡥࡸࡷࡹࡵ࡭ࠦ࠴࠵ࠩ࠸ࡧࠥ࠳࠲ࡷࡶࡺ࡫ࠥ࠳ࡥࠨ࠶࠵ࠫ࠲࠳ࡵࡱࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࠫ࠲࠳ࠧ࠵࠶ࠪ࠸ࡣࠦ࠴࠳ࠩ࠷࠸ࡳࡪࡩࡱࡥࡹࡻࡲࡦࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࠩ࠷࠸ࠥ࠳࠴ࠨ࠶ࡨࠫ࠲࠱ࠧ࠵࠶ࡩ࡫ࡶࡪࡥࡨࡣ࡮ࡪ࠲ࠦ࠴࠵ࠩ࠸ࡧࠥ࠳࠲ࠨ࠶࠷ࠫ࠲࠳ࠧ࠵ࡧࠪ࠸࠰ࠦ࠴࠵ࡨࡪࡼࡩࡤࡧࡢ࡭ࡩࠫ࠲࠳ࠧ࠶ࡥࠪ࠸࠰ࠦ࠴࠵ࠩ࠷࠸ࠥ࠸ࡦࠨ࠶ࡨࠫ࠲࠱ࠧ࠵࠶ࡵࡧࡳࡴࡹࡲࡶࡩࠫ࠲࠳ࠧ࠶ࡥࠪ࠸࠰࡯ࡷ࡯ࡰࠪ࠸ࡣࠦ࠴࠳ࠩ࠷࠸࡬ࡰࡩ࡬ࡲࠪ࠸࠲ࠦ࠵ࡤࠩ࠷࠶࡮ࡶ࡮࡯ࠩ࠼ࡪࠧ૤")
    else:
        login = l11l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭૥") + addon + l11l11_opy_ (u"ࠫ࠴ࡅࡡࡤࡶ࡬ࡳࡳࡃࡳࡦࡥࡸࡶ࡮ࡺࡹࡠࡥ࡫ࡩࡨࡱࠦࡦࡺࡷࡶࡦࠬࡰࡢࡩࡨࠪࡵࡲ࡯ࡵࠨࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠫࡺࡩࡵ࡮ࡨࡁࡑ࡯ࡶࡦࠧ࠵࠴࡙࡜ࠦࡶࡴ࡯ࠫ૦")
    try:
        query = l111ll1l1_opy_(addon)
    except: pass
    l111l111l_opy_ = (l11l11_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࠦࡵࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ૧") % login)
    l111l11l1_opy_ = (l11l11_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࠧࡶࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ૨") % query)
    try:
        xbmc.executeJSONRPC(l111l1l11_opy_)
        if addon != l111l11ll_opy_:
            xbmc.executeJSONRPC(l111l111l_opy_)
        response = xbmc.executeJSONRPC(l111l11l1_opy_)
        content  = json.loads(response.decode(l11l11_opy_ (u"ࠧࡶࡶࡩ࠱࠽࠭૩"), l11l11_opy_ (u"ࠨ࡫ࡪࡲࡴࡸࡥࠨ૪")))
        return content
    except:
        dixie.log(l11l11_opy_ (u"ࠩ࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰ࠤࡕࡲࡵࡨ࡫ࡱࠤࡊࡸࡲࡰࡴࠣ࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱ࠬ૫"))
        return {l11l11_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠩ૬") : l11l11_opy_ (u"ࠫࡕࡲࡵࡨ࡫ࡱࠤࡊࡸࡲࡰࡴࠪ૭")}
def l111ll1l1_opy_(addon):
    if addon == l111l11ll_opy_:
        return l11l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࡭ࡵࡺࡶ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿࡯࡭ࡻ࡫ࡴࡷࡡࡤࡰࡱࠬࡥࡹࡶࡵࡥࠫࡶࡡࡨࡧࠩࡴࡱࡵࡴࠧࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡁࠪ࠸ࡦࡖࡵࡨࡶࡸࠫ࠲ࡧࡴ࡬ࡧ࡭ࡧࡲࡥࠧ࠵ࡪࡑ࡯ࡢࡳࡣࡵࡽࠪ࠸ࡦࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠪ࠸࠰ࡔࡷࡳࡴࡴࡸࡴࠦ࠴ࡩࡏࡴࡪࡩࠦ࠴ࡩࡥࡩࡪ࡯࡯ࡵࠨ࠶࡫ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶࡴࡷࡵࡸࡦࡸ࠸࠮࠵ࠧ࠵ࡪࡷ࡫ࡳࡰࡷࡵࡧࡪࡹࠥ࠳ࡨ࡬ࡱ࡬ࠫ࠲ࡧࡪࡲࡸ࠳ࡶ࡮ࡨࠨࡷ࡭ࡹࡲࡥ࠾ࡃ࡯ࡰࠪ࠸࠰ࡤࡪࡤࡲࡳ࡫࡬ࡴࠨࡸࡶࡱ࠭૮")
    if addon == l1111llll_opy_:
        return l11l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡲࡷ࡬ࡧࡰ࡯ࡰࡵࡸ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡸࡺࡲࡦࡣࡰࡣࡻ࡯ࡤࡦࡱࠩࡩࡽࡺࡲࡢࠨࡳࡥ࡬࡫ࠦࡱ࡮ࡲࡸࠫࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠾ࠨࡷ࡭ࡹࡲࡥ࠾ࡃ࡯ࡰࠫࡻࡲ࡭࠿࠳ࠫ૯")
    if addon == l111ll111_opy_:
        return l11l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡨࡸࡸࡺࡸࡥࡴࡶࡵࡩࡦࡳࡳ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿ࡶࡸࡷ࡫ࡡ࡮ࡡࡹ࡭ࡩ࡫࡯ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠦࡵ࡫ࡷࡰࡪࡃࡁ࡭࡮ࠩࡹࡷࡲ࠽࠱ࠩ૰")
    if addon == l111l1l1l_opy_:
        return l11l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡸࡪࡧ࡬ࡵࡪࡸࡲࡩ࡫ࡲࡨࡴࡲࡹࡳࡪ࠯ࡀࡩࡨࡲࡷ࡫࡟࡯ࡣࡰࡩࡂࡇ࡬࡭ࠨࡳࡳࡷࡺࡡ࡭࠿ࠨ࠻ࡇࠫ࠲࠳ࡰࡤࡱࡪࠫ࠲࠳ࠧ࠶ࡅ࠰ࠫ࠲࠳ࠧ࠸ࡆࡎࠫ࠵ࡅࠧ࠸ࡆࡈࡕࡌࡐࡔ࠮ࡻ࡭࡯ࡴࡦࠧ࠸ࡈࡈࡲࡩࡤ࡭࠮ࡘࡴ࠱ࡖࡪࡧࡺ࠯࡙࡮ࡥࠬࡎ࡬ࡷࡹ࠱ࡏࡧ࠭ࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠩ࠺ࡈࠥ࠳ࡈࡆࡓࡑࡕࡒࠦ࠷ࡇࠩ࠺ࡈࠥ࠳ࡈࡌࠩ࠺ࡊࠥ࠳࠴ࠨ࠶ࡈ࠱ࠥ࠳࠴ࡳࡥࡷ࡫࡮ࡵࡣ࡯ࠩ࠷࠸ࠥ࠴ࡃ࠮ࠩ࠷࠸ࡦࡢ࡮ࡶࡩࠪ࠸࠲ࠦ࠴ࡆ࠯ࠪ࠸࠲ࡶࡴ࡯ࠩ࠷࠸ࠥ࠴ࡃ࠮ࠩ࠷࠸ࡨࡵࡶࡳࠩ࠸ࡇࠥ࠳ࡈࠨ࠶ࡋࡳࡷ࠲࠰࡬ࡴࡹࡼ࠶࠷࠰ࡷࡺࠪ࠸࠲ࠦ࠴ࡆ࠯ࠪ࠸࠲ࡱࡲࡤࡷࡸࡽ࡯ࡳࡦࠨ࠶࠷ࠫ࠳ࡂ࠭ࠨ࠶࠷࠶࠰࠱࠲ࠨ࠶࠷ࠫ࠲ࡄ࠭ࠨ࠶࠷ࡳࡡࡤࠧ࠵࠶ࠪ࠹ࡁࠬࠧ࠵࠶࠵࠶ࠥ࠴ࡃ࠴ࡅࠪ࠹ࡁ࠸࠺ࠨ࠷ࡆ࠺࠳ࠦ࠵ࡄ࠵࠷ࠫ࠳ࡂ࠹࠷ࠩ࠷࠸ࠥ࠳ࡅ࠮ࠩ࠷࠸ࡳࡦࡴ࡬ࡥࡱࠫ࠲࠳ࠧ࠶ࡅ࠰ࠫ࠷ࡃࠧ࠵࠶ࡸ࡫࡮ࡥࡡࡶࡩࡷ࡯ࡡ࡭ࠧ࠵࠶ࠪ࠹ࡁࠬࡶࡵࡹࡪࠫ࠲ࡄ࠭ࠨ࠶࠷ࡩࡵࡴࡶࡲࡱࠪ࠸࠲ࠦ࠵ࡄ࠯ࡹࡸࡵࡦࠧ࠵ࡇ࠰ࠫ࠲࠳ࡵࡱࠩ࠷࠸ࠥ࠴ࡃ࠮ࠩ࠷࠸ࠥ࠳࠴ࠨ࠶ࡈ࠱ࠥ࠳࠴ࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࠪ࠸࠲ࠦ࠵ࡄ࠯ࠪ࠸࠲ࠦ࠴࠵ࠩ࠷ࡉࠫࠦ࠴࠵ࡨࡪࡼࡩࡤࡧࡢ࡭ࡩ࠸ࠥ࠳࠴ࠨ࠷ࡆ࠱ࠥ࠳࠴ࠨ࠶࠷ࠫ࠲ࡄ࠭ࠨ࠶࠷ࡪࡥࡷ࡫ࡦࡩࡤ࡯ࡤࠦ࠴࠵ࠩ࠸ࡇࠫࠦ࠴࠵ࠩ࠷࠸ࠥ࠸ࡆࠨ࠶ࡈ࠱ࠥ࠳࠴ࡳࡥࡸࡹࡷࡰࡴࡧࠩ࠷࠸ࠥ࠴ࡃ࠮ࡲࡺࡲ࡬ࠦ࠴ࡆ࠯ࠪ࠸࠲࡭ࡱࡪ࡭ࡳࠫ࠲࠳ࠧ࠶ࡅ࠰ࡴࡵ࡭࡮ࠨ࠻ࡉࠬ࡭ࡰࡦࡨࡁࡨ࡮ࡡ࡯ࡰࡨࡰࡸࠬࡧࡦࡰࡵࡩࡤ࡯ࡤ࠾ࠧ࠵ࡅࠬ૱")
    else:
        Addon = xbmcaddon.Addon(addon)
        if addon == l1111lll1_opy_:
            username =  Addon.getSetting(l11l11_opy_ (u"ࠩࡘࡷࡪࡸ࡮ࡢ࡯ࡨࠫ૲"))
            password =  Addon.getSetting(l11l11_opy_ (u"ࠪࡔࡦࡹࡳࡸࡱࡵࡨࠬ૳"))
        else:
            username =  Addon.getSetting(l11l11_opy_ (u"ࠫࡰࡧࡳࡶࡶࡤ࡮ࡦࡴࡩ࡮࡫ࠪ૴"))
            password =  Addon.getSetting(l11l11_opy_ (u"ࠬࡹࡡ࡭ࡣࡶࡳࡳࡧࠧ૵"))
        l1111ll1l_opy_     = l11l11_opy_ (u"࠭࠯ࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡵࡷࡶࡪࡧ࡭ࡠࡸ࡬ࡨࡪࡵࠦࡦࡺࡷࡶࡦࠬࡰࡢࡩࡨࠪࡵࡲ࡯ࡵࠨࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡂࠬࡴࡪࡶ࡯ࡩࡂࡇ࡬࡭ࠨࡸࡶࡱࡃࠧ૶")
        l11l1ll1l_opy_  =  l11ll111l_opy_(addon)
        l1l11llll_opy_   = l11l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ૷") + addon
        l111l1lll_opy_  =  l1l11llll_opy_ + l1111ll1l_opy_ + l11l1ll1l_opy_
        l111ll11l_opy_ = l11l11_opy_ (u"ࠨࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠫ૸") + username + l11l11_opy_ (u"ࠩࠩࡴࡦࡹࡳࡸࡱࡵࡨࡂ࠭ૹ") + password + l11l11_opy_ (u"ࠪࠪࡹࡿࡰࡦ࠿ࡪࡩࡹࡥ࡬ࡪࡸࡨࡣࡸࡺࡲࡦࡣࡰࡷࠫࡩࡡࡵࡡ࡬ࡨࡂ࠶ࠧૺ")
        return l111l1lll_opy_ + urllib.quote_plus(l111ll11l_opy_)
def l11ll111l_opy_(addon):
    if (addon == l111l1ll1_opy_):
        return l11l11_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠸࠽࠮࠲࠺࠺࠲࠶࠹࠹࠯࠳࠸࠹࠿࠾࠰࠱࠲࠲ࡩࡳ࡯ࡧ࡮ࡣ࠵࠲ࡵ࡮ࡰࡀࠩૻ")
    if addon == l111l1111_opy_:
        return l11l11_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡰࡪࡰࡽࡸࡻࡶࡲࡰ࠰ࡷ࡯࠿࠾࠰࠱࠲࠲ࡩࡳ࡯ࡧ࡮ࡣ࠵࠲ࡵ࡮ࡰࡀࠩૼ")
    if addon == l1111lll1_opy_:
        return l11l11_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡯ࡵࡶࡷࡺ࠳࡭ࡡ࠻࠴࠳࠽࠺࠵ࡥ࡯࡫ࡪࡱࡦ࠸࠮ࡱࡪࡳࡃࠬ૽")
def l1l1ll1_opy_(e):
    l1l111_opy_ = l11l11_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠲ࠠࡢࡰࠣࡩࡷࡸ࡯ࡳࠢࡲࡧࡨࡻࡲࡦࡦ࠽ࠤࡏ࡙ࡏࡏࠢࡈࡶࡷࡵࡲ࠻ࠢࠨࡷࠬ૾")  %e
    l111l_opy_ = l11l11_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡥࡲࡲࡹࡧࡣࡵࠢࡸࡷࠥࡵ࡮ࠡࡶ࡫ࡩࠥ࡬࡯ࡳࡷࡰ࠲ࠬ૿")
    l1l1l1_opy_ = l11l11_opy_ (u"ࠩࡘࡴࡱࡵࡡࡥࠢࡤࠤࡱࡵࡧࠡࡸ࡬ࡥࠥࡺࡨࡦࠢࡤࡨࡩࡵ࡮ࠡࡵࡨࡸࡹ࡯࡮ࡨࡵࠣࡥࡳࡪࠠࡱࡱࡶࡸࠥࡺࡨࡦࠢ࡯࡭ࡳࡱ࠮ࠨ଀")
    dixie.log(e)
    dixie.DialogOK(l1l111_opy_, l111l_opy_, l1l1l1_opy_)
    dixie.SetSetting(SETTING, l11l11_opy_ (u"ࠪࠫଁ"))
if __name__ == l11l11_opy_ (u"ࠫࡤࡥ࡭ࡢ࡫ࡱࡣࡤ࠭ଂ"):
    checkAddons()