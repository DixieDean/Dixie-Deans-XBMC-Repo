# coding: UTF-8
import sys
l11llll_opy_ = sys.version_info [0] == 2
l1llll1_opy_ = 2048
l1llll_opy_ = 7
def l11l11_opy_ (ll_opy_):
	global l1lllll_opy_
	l1l1111_opy_ = ord (ll_opy_ [-1])
	l1111l_opy_ = ll_opy_ [:-1]
	l1ll111_opy_ = l1l1111_opy_ % len (l1111l_opy_)
	l1l1l_opy_ = l1111l_opy_ [:l1ll111_opy_] + l1111l_opy_ [l1ll111_opy_:]
	if l11llll_opy_:
		l1ll1ll_opy_ = unicode () .join ([unichr (ord (char) - l1llll1_opy_ - (l11ll1_opy_ + l1l1111_opy_) % l1llll_opy_) for l11ll1_opy_, char in enumerate (l1l1l_opy_)])
	else:
		l1ll1ll_opy_ = str () .join ([chr (ord (char) - l1llll1_opy_ - (l11ll1_opy_ + l1l1111_opy_) % l1llll_opy_) for l11ll1_opy_, char in enumerate (l1l1l_opy_)])
	return eval (l1ll1ll_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
ADDON    = dixie.ADDON
l1l11l_opy_ = dixie.PROFILE
l1l1lll_opy_  = os.path.join(l1l11l_opy_, l11l11_opy_ (u"ࠫ࡮ࡴࡩࠨࠀ"))
l1l11l1_opy_ = l11l11_opy_ (u"ࠬ࠭ࠁ")
def l11l111_opy_(i, t1, l1l111l_opy_=[]):
 t = l1l11l1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l111l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1l11_opy_ = l11l111_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11ll_opy_ = l11l111_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1ll1l1_opy_ = l11l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡌ࡬ࡢࡹ࡯ࡩࡸࡹࡔࡷࠩࠂ")
dexter   = l11l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡤࡦࡺࠪࠃ")
l11l11l_opy_   = [l1ll1l1_opy_, dexter]
l1lll11_opy_ = os.path.join(dixie.PROFILE, l11l11_opy_ (u"ࠨࡦࡷࡩࡲࡶࠧࠄ"))
if os.path.exists(l1lll11_opy_):
    os.remove(l1lll11_opy_)
l11l1l_opy_ = os.path.join(dixie.PROFILE, l11l11_opy_ (u"ࠩࡩࡸࡪࡳࡰࠨࠅ"))
if os.path.exists(l11l1l_opy_):
    os.remove(l11l1l_opy_)
l1ll_opy_ = os.path.join(l1l1lll_opy_, l11l11_opy_ (u"ࠪࡨࡪࡾࡴࡦࡴ࠱࡭ࡳ࡯ࠧࠆ"))
if os.path.exists(l1ll_opy_):
    os.remove(l1ll_opy_)
def checkAddons():
    for addon in l11l11l_opy_:
        if l11l1ll_opy_(addon):
            createINI(addon)
def l11l1ll_opy_(addon):
    if xbmc.getCondVisibility(l11l11_opy_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡍࡧࡳࡂࡦࡧࡳࡳ࠮ࠥࡴࠫࠪࠇ") % addon) == 1:
        return True
    else:
        return False
def createINI(addon):
    HOME  = dixie.PROFILE
    l1l1ll_opy_ = os.path.join(HOME, l11l11_opy_ (u"ࠬ࡯࡮ࡪࠩࠈ"))
    l11_opy_  = str(addon).split(l11l11_opy_ (u"࠭࠮ࠨࠉ"))[2] + l11l11_opy_ (u"ࠧ࠯࡫ࡱ࡭ࠬࠊ")
    l1l_opy_   = os.path.join(l1l1ll_opy_, l11_opy_)
    response = l1_opy_(addon)
    l1l1l1l_opy_ = response[l11l11_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨࠋ")][l11l11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨࠌ")]
    l111l1_opy_  = l11l11_opy_ (u"ࠪ࡟ࠬࠍ") + addon + l11l11_opy_ (u"ࠫࡢࡢ࡮ࠨࠎ")
    l1l1l11_opy_  =  file(l1l_opy_, l11l11_opy_ (u"ࠬࡽࠧࠏ"))
    l1l1l11_opy_.write(l111l1_opy_)
    l1ll11_opy_ = []
    for channel in l1l1l1l_opy_:
        l11ll1l_opy_ = channel[l11l11_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬࠐ")].split(l11l11_opy_ (u"ࠧࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࠑ"))[0]
        l11ll1l_opy_ = dixie.cleanLabel(l11ll1l_opy_)
        l1ll11l_opy_ = l11ll1l_opy_
        l1ll1l_opy_ = l11lll1_opy_(addon)
        l1ll1_opy_  = dixie.mapChannelName(l11ll1l_opy_)
        stream    = l1ll1l_opy_ + l1ll11l_opy_
        l11l1_opy_   = l1ll1_opy_ + l11l11_opy_ (u"ࠨ࠿ࠪࠒ") + stream
        if l11l1_opy_ not in l1ll11_opy_:
            l1ll11_opy_.append(l11l1_opy_)
    l1ll11_opy_.sort()
    for item in l1ll11_opy_:
        l1l1l11_opy_.write(l11l11_opy_ (u"ࠤࠨࡷࡡࡴࠢࠓ") % item)
    l1l1l11_opy_.close()
def l11lll1_opy_(addon):
    if addon == l1ll1l1_opy_:
        return l11l11_opy_ (u"ࠪࡊࡑࡇ࠺ࠨࠔ")
    if addon == dexter:
        return l11l11_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡇ࠾ࠬࠕ")
def getURL(url):
    if url.startswith(l11l11_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡇࡑ࡛࠺ࠨࠖ")):
        url = url.replace(l11l11_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡈࡒࡕ࠻ࠩࠗ"), l11l11_opy_ (u"ࠧࠨ࠘")).replace(l11l11_opy_ (u"ࠨ࠯࠰ࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧ࠙"), l11l11_opy_ (u"ࠩࡿࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧࠚ"))
        return url
    if url.startswith(l11l11_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡆࠪࠛ")):
        return l1l1_opy_(url, dexter)
    if url.startswith(l11l11_opy_ (u"ࠫࡋࡒࡁࠨࠜ")):
        return l1l1_opy_(url, l1ll1l1_opy_)
    response = l11l_opy_(url)
    stream   = url.split(l11l11_opy_ (u"ࠬࡀࠧࠝ"), 1)[-1]
    try:
        result = response[l11l11_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࠞ")]
        l11111_opy_  = result[l11l11_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࠟ")]
    except Exception as e:
        l1l1ll1_opy_(e)
        return None
    for file in l11111_opy_:
        l11lll_opy_ = file[l11l11_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࠠ")]
        if stream in l11lll_opy_:
            return file[l11l11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧࠡ")]
    return None
def l1l1_opy_(url, addon):
    PATH = l1lll_opy_(addon)
    if os.path.exists(PATH):
        response = json.load(open(PATH))
    else:
        response = l1_opy_(addon)
    l1lll1l_opy_ = url.split(l11l11_opy_ (u"ࠪ࠾ࠬࠢ"))[0]
    l11l1l1_opy_    = url.split(l11l11_opy_ (u"ࠫ࠿࠭ࠣ"), 1)[-1]
    l11ll11_opy_ = l11l1l1_opy_.split(l11l11_opy_ (u"࡛ࠬࠦࠨࠤ"), 1)
    stream  = l11ll11_opy_[0]
    l11111_opy_  = response[l11l11_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࠥ")][l11l11_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࠦ")]
    for file in l11111_opy_:
        l11lll_opy_ = file[l11l11_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࠧ")]
        l11lll_opy_ = dixie.cleanLabel(l11lll_opy_)
        if stream in l11lll_opy_:
            l111_opy_ = file[l11l11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧࠨ")]
            dixie.log(file[l11l11_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࠩ")])
            if l1lll1l_opy_ == l11l11_opy_ (u"ࠫࡋࡒࡁࡔࠩࠪ"):
                return l111_opy_
            l111_opy_ = l111_opy_.replace(l11l11_opy_ (u"ࠬ࠴ࡴࡴࠩࠫ"), l11l11_opy_ (u"࠭࠮࡮࠵ࡸ࠼ࠬࠬ"))
            return l111_opy_
def l1_opy_(addon):
    if addon == l1ll1l1_opy_:
        query = l11l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡈ࡯ࡥࡼࡲࡥࡴࡵࡗࡺ࠴ࡅࡡࡤࡶ࡬ࡳࡳࡃࡳࡵࡴࡨࡥࡲࡥࡶࡪࡦࡨࡳࠫ࡫ࡸࡵࡴࡤࠪࡵࡧࡧࡦࠨࡳࡰࡴࡺࠦࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡀࠪࡹ࡯ࡴ࡭ࡧࡀࡅࡱࡲࠦࡶࡴ࡯ࡁ࠵࠭࠭")
        content = doJSON(query)
        return l111ll_opy_(addon, content)
    if addon == dexter:
        query   = l1lll1_opy_(dexter)
        content = doJSON(query)
        return l111ll_opy_(dexter, content)
def l111ll_opy_(addon, content):
    PATH  = l1lll_opy_(addon)
    json.dump(content, open(PATH,l11l11_opy_ (u"ࠨࡹࠪ࠮")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    l1l11ll_opy_  = (l11l11_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬ࠯") % query)
    response = xbmc.executeJSONRPC(l1l11ll_opy_)
    content  = json.loads(response)
    return content
def l1lll_opy_(addon):
    if addon == l1ll1l1_opy_:
        return os.path.join(dixie.PROFILE, l11l11_opy_ (u"ࠪࡪࡹ࡫࡭ࡱࠩ࠰"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l11l11_opy_ (u"ࠫࡩࡺࡥ࡮ࡲࠪ࠱"))
def l1lll1_opy_(addon):
    if addon == dexter:
        query = l11l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡤࡦࡺࠪ࠲")
        response = doJSON(query)
        l11111_opy_    = response[l11l11_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭࠳")][l11l11_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭࠴")]
        for file in l11111_opy_:
            l11lll_opy_ = file[l11l11_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧ࠵")]
            if l11lll_opy_ == l11l11_opy_ (u"ࠩࡄࡰࡱ࠭࠶"):
                login = file[l11l11_opy_ (u"ࠪࡪ࡮ࡲࡥࠨ࠷")]
                return login
def l11l_opy_(url):
    if url.startswith(l11l11_opy_ (u"ࠫࡎࡖࡌࡂ࡛࠽ࠫ࠸")):
        l1l11ll_opy_ = (l11l11_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡤࡥࡧ࡮ࡶ࡬ࡢࡻࡨࡶ࠴ࡅࡵࡳ࡮ࡀࡹࡷࡲࠦ࡮ࡱࡧࡩࡂ࠸ࠦ࡯ࡣࡰࡩࡂࡒࡩࡷࡧࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࡂࠬࡉࡑࡋࡇࡁࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ࠹"))
    if url.startswith(l11l11_opy_ (u"࠭ࡉࡑࡎࡄ࡝࠷ࡀࠧ࠺")):
        l1l11ll_opy_ = (l11l11_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽ࠯ࡀࡷࡵࡰࡂࡻࡲ࡭ࠨࡰࡳࡩ࡫࠽࠲࠲࠴ࠪࡳࡧ࡭ࡦ࠿࡚ࡥࡹࡩࡨࠬࡎ࡬ࡺࡪࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࠩࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮࠾ࠨࡶࡹࡧࡺࡩࡵ࡮ࡨࡷࡤࡻࡲ࡭࠿ࠩࡰࡴ࡭ࡧࡦࡦࡢ࡭ࡳࡃࡆࡢ࡮ࡶࡩࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ࠻"))
    if url.startswith(l11l11_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡒ࠻ࠩ࠼")):
        l1l11ll_opy_ = (l11l11_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰ࡭ࡣࡼࡩࡷࡽࡷࡸ࠱ࡂࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠧ࡮ࡲ࡫࡬࡫ࡤࡠ࡫ࡱࡁࡋࡧ࡬ࡴࡧࠩࡱࡴࡪࡥ࠾࠳࠴࠷ࠫࡴࡡ࡮ࡧࡀࡐ࡮ࡹࡴࡦࡰࠨ࠶࠵ࡒࡩࡷࡧࠩࡷࡺࡨࡴࡪࡶ࡯ࡩࡸࡥࡵࡳ࡮ࠩࡹࡷࡲ࠽ࡶࡴ࡯ࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ࠽"))
    if url.startswith(l11l11_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡋࡗ࡚࠿࠭࠾")):
        l1l11ll_opy_ = (l11l11_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡶࡹࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ࠿"))
    if url.startswith(l11l11_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡈ࠿࠭ࡀ")):
        l1l11ll_opy_ = (l11l11_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡧࡩࡽ࠵࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࡢ࡮࡯ࠪࡪࡾࡴࡳࡣࠩࡴࡦ࡭ࡥࠧࡲ࡯ࡳࡹࠬࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠿ࠩࡸ࡮ࡺ࡬ࡦ࠿ࠨ࠹ࡧࡉࡏࡍࡑࡕࠩ࠷࠶ࡷࡩ࡫ࡷࡩࠪ࠻ࡤࡂ࡮࡯ࠩ࠷࠶ࡃࡩࡣࡱࡲࡪࡲࡳࠦ࠷ࡥࠩ࠷࡬ࡃࡐࡎࡒࡖࠪ࠻ࡤࠧࡷࡵࡰࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࡁ"))
    if url.startswith(l11l11_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡘࡂ࠻ࠩࡂ")):
        l1l11ll_opy_ = (l11l11_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷ࡫ࡢࡰࡱࡷ࠳ࡄࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠩࡪࡦࡴࡡࡳࡶࡀࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧ࡯ࡲࡨࡪࡃ࠷ࠧࡲ࡬ࡰࡱࡵࡷ࠾ࡎ࡬ࡺࡪࠫ࠲࠱ࡕࡷࡶࡪࡧ࡭ࡴࠨࡸࡶࡱࡃࡲࡢࡰࡧࡳࡲࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࡃ"))
    if url.startswith(l11l11_opy_ (u"ࠩࡌࡔ࡙࡙࠺ࠨࡄ")):
        l1l11ll_opy_ = (l11l11_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࡭ࡵࡺࡶ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿࡯࡭ࡻ࡫ࡴࡷࡡࡤࡰࡱࠬࡥࡹࡶࡵࡥࠫࡶࡡࡨࡧࠩࡴࡱࡵࡴࠧࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡁࠫࡺࡩࡵ࡮ࡨࡁࡆࡲ࡬ࠦ࠴࠳ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡻࡲ࡭ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࡅ"))
    try:
        dixie.ShowBusy()
        addon =  l1l11ll_opy_.split(l11l11_opy_ (u"ࠫ࠴࠵ࠧࡆ"), 1)[-1].split(l11l11_opy_ (u"ࠬ࠵ࠧࡇ"), 1)[0]
        login = l11l11_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࡈ") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1l11ll_opy_)
        dixie.log(response)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1l1ll1_opy_(e)
        return {l11l11_opy_ (u"ࠧࡆࡴࡵࡳࡷ࠭ࡉ") : l11l11_opy_ (u"ࠨࡒ࡯ࡹ࡬࡯࡮ࠡࡇࡵࡶࡴࡸࠧࡊ")}
def l1111_opy_():
    modules = map(__import__, [l11l111_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1l11_opy_)):
        return l11l11_opy_ (u"ࠩࡗࡶࡺ࡫ࠧࡋ")
    if len(modules[-1].Window(10**4).getProperty(l11ll_opy_)):
        return l11l11_opy_ (u"ࠪࡘࡷࡻࡥࠨࡌ")
    return l11l11_opy_ (u"ࠫࡋࡧ࡬ࡴࡧࠪࡍ")
def l1l1ll1_opy_(e):
    l1l111_opy_ = l11l11_opy_ (u"࡙ࠬ࡯ࡳࡴࡼ࠰ࠥࡧ࡮ࠡࡧࡵࡶࡴࡸࠠࡰࡥࡦࡹࡷ࡫ࡤ࠻ࠢࡍࡗࡔࡔࠠࡆࡴࡵࡳࡷࡀࠠࠦࡵࠪࡎ")  %e
    l111l_opy_ = l11l11_opy_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡲࡦ࠯࡯࡭ࡳࡱࠠࡵࡪ࡬ࡷࠥࡩࡨࡢࡰࡱࡩࡱࠦࡡ࡯ࡦࠣࡸࡷࡿࠠࡢࡩࡤ࡭ࡳ࠴ࠧࡏ")
    l1l1l1_opy_ = l11l11_opy_ (u"ࠧࡖࡵࡨ࠾ࠥࡉ࡯࡯ࡶࡨࡼࡹࠦࡍࡦࡰࡸࠤࡂࡄࠠࡓࡧࡰࡳࡻ࡫ࠠࡔࡶࡵࡩࡦࡳࠧࡐ")
    dixie.log(e)
    dixie.DialogOK(l1l111_opy_, l111l_opy_, l1l1l1_opy_)
if __name__ == l11l11_opy_ (u"ࠨࡡࡢࡱࡦ࡯࡮ࡠࡡࠪࡑ"):
    checkAddons()