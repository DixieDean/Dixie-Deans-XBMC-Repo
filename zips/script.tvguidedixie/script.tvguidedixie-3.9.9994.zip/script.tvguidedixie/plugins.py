# coding: UTF-8
import sys
l1l1l1ll_opy_ = sys.version_info [0] == 2
l111ll1_opy_ = 2048
l1l1ll1l_opy_ = 7
def l1l1l_opy_ (l1l111_opy_):
	global l11l111_opy_
	l111111_opy_ = ord (l1l111_opy_ [-1])
	l1l1lll1_opy_ = l1l111_opy_ [:-1]
	l1l1111_opy_ = l111111_opy_ % len (l1l1lll1_opy_)
	l11l11_opy_ = l1l1lll1_opy_ [:l1l1111_opy_] + l1l1lll1_opy_ [l1l1111_opy_:]
	if l1l1l1ll_opy_:
		l1111_opy_ = unicode () .join ([unichr (ord (char) - l111ll1_opy_ - (l1lll_opy_ + l111111_opy_) % l1l1ll1l_opy_) for l1lll_opy_, char in enumerate (l11l11_opy_)])
	else:
		l1111_opy_ = str () .join ([chr (ord (char) - l111ll1_opy_ - (l1lll_opy_ + l111111_opy_) % l1l1ll1l_opy_) for l1lll_opy_, char in enumerate (l11l11_opy_)])
	return eval (l1111_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l11l11l11_opy_     = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡱࡸࡻ࠭ॖ")
l111lllll_opy_  = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡻࡱ࡯ࡰࡵࡸࠪॗ")
l11l1llll_opy_     = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡶࡴ࡮ࠫक़")
locked  = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲ࡯ࡤ࡭ࡨࡨࡹࡼࠧख़")
l111ll1l1_opy_      = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡵ࡭ࡶ࡬ࡱࡦࡺࡥ࡮ࡣࡱ࡭ࡦ࠭ग़")
l111lll1l_opy_    = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡭࡫ࡸࡼ࠳ࡺࡶࠨज़")
l11l1111l_opy_     = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡆࡆࡗࡵࡵࡲࡵࡵࠪड़")
l11l1lll1_opy_  = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡩࡧࡵ࡯ࡵࠩढ़")
l11l111l1_opy_     = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡧࡱࡻࡩࡱࡶࡹࠫफ़")
l11l1ll1l_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡷ࠶ࡨࡼࡵࡧࡴࡴ࠰ࡦࡳࡲ࠭य़")
l1lllll1_opy_ = [l11l11l11_opy_, locked, l111lll1l_opy_, l111lllll_opy_, l11l1ll1l_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1l1l_opy_ (u"࠭ࡩ࡯࡫ࠪॠ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1l1ll1_opy_ = l1l1l_opy_ (u"ࠧࠨॡ")
def l1l11l_opy_(i, t1, l1l1l1_opy_=[]):
 t = l1l1ll1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l1l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11_opy_ = l1l11l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11lll_opy_ = l1l11l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1lllll1_opy_:
        if l1l11l1_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1l11l1_opy_(addon):
    if xbmc.getCondVisibility(l1l1l_opy_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫࠩࡸ࠯ࠧॢ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l11lllll_opy_ = str(addon).split(l1l1l_opy_ (u"ࠩ࠱ࠫॣ"))[2] + l1l1l_opy_ (u"ࠪ࠲࡮ࡴࡩࠨ।")
    l1l1ll11_opy_  = os.path.join(PATH, l11lllll_opy_)
    try:
        l11llll_opy_ = l1llll1l_opy_(addon)
    except KeyError:
        dixie.log(l1l1l_opy_ (u"ࠫ࠲࠳࠭࠮࠯ࠣࡏࡪࡿࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡩࡨࡸࡋ࡯࡬ࡦࡵࠣ࠱࠲࠳࠭࠮ࠢࠪ॥") + addon)
        result = {l1l1l_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࡷࠬ०"): [{l1l1l_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ१"): l1l1l_opy_ (u"ࡵࠨࡨ࡬ࡰࡪ࠭२"), l1l1l_opy_ (u"ࡶࠩࡷࡽࡵ࡫ࠧ३"): l1l1l_opy_ (u"ࡷࠪࡹࡳࡱ࡮ࡰࡹࡱࠫ४"), l1l1l_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࠩ५"): l1l1l_opy_ (u"ࡹࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸࡹࡺࠪ६"), l1l1l_opy_ (u"ࡺ࠭࡬ࡢࡤࡨࡰࠬ७"): l1l1l_opy_ (u"ࡻࠧࡏࡑࠣࡇࡍࡇࡎࡏࡇࡏࡗࠬ८")}], l1l1l_opy_ (u"ࡵࠨ࡮࡬ࡱ࡮ࡺࡳࠨ९"):{l1l1l_opy_ (u"ࡶࠩࡶࡸࡦࡸࡴࠨ॰"): 0, l1l1l_opy_ (u"ࡷࠪࡸࡴࡺࡡ࡭ࠩॱ"): 1, l1l1l_opy_ (u"ࡸࠫࡪࡴࡤࠨॲ"): 1}}
    l1l1ll_opy_  = l1l1l_opy_ (u"ࠫࡠ࠭ॳ") + addon + l1l1l_opy_ (u"ࠬࡣ࡜࡯ࠩॴ")
    l1lll11l_opy_  =  file(l1l1ll11_opy_, l1l1l_opy_ (u"࠭ࡷࠨॵ"))
    l1lll11l_opy_.write(l1l1ll_opy_)
    l1l1l11l_opy_ = []
    for channel in l11llll_opy_:
        l1l1_opy_ = dixie.cleanLabel(channel[l1l1l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ॶ")])
        l1l11ll_opy_   = dixie.cleanPrefix(l1l1_opy_)
        l11l1l_opy_ = dixie.mapChannelName(l1l11ll_opy_)
        stream   = channel[l1l1l_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ॷ")]
        l111l1_opy_ = l11l1l_opy_ + l1l1l_opy_ (u"ࠩࡀࠫॸ") + stream
        l1l1l11l_opy_.append(l111l1_opy_)
        l1l1l11l_opy_.sort()
    for item in l1l1l11l_opy_:
        l1lll11l_opy_.write(l1l1l_opy_ (u"ࠥࠩࡸࡢ࡮ࠣॹ") % item)
    l1lll11l_opy_.close()
def l1llll1l_opy_(addon):
    if (addon == l11l11l11_opy_) or (addon == l111lllll_opy_):
        if xbmcaddon.Addon(addon).getSetting(l1l1l_opy_ (u"ࠫ࡬࡫࡮ࡳࡧࠪॺ")) == l1l1l_opy_ (u"ࠬࡺࡲࡶࡧࠪॻ"):
            xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"࠭ࡧࡦࡰࡵࡩࠬॼ"), l1l1l_opy_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭ॽ"))
            xbmcgui.Window(10000).setProperty(l1l1l_opy_ (u"ࠨࡒࡏ࡙ࡌࡏࡎࡠࡉࡈࡒࡗࡋࠧॾ"), l1l1l_opy_ (u"ࠩࡗࡶࡺ࡫ࠧॿ"))
        if xbmcaddon.Addon(addon).getSetting(l1l1l_opy_ (u"ࠪࡸࡻ࡭ࡵࡪࡦࡨࠫঀ")) == l1l1l_opy_ (u"ࠫࡹࡸࡵࡦࠩঁ"):
            xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"ࠬࡺࡶࡨࡷ࡬ࡨࡪ࠭ং"), l1l1l_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬঃ"))
            xbmcgui.Window(10000).setProperty(l1l1l_opy_ (u"ࠧࡑࡎࡘࡋࡎࡔ࡟ࡕࡘࡊ࡙ࡎࡊࡅࠨ঄"), l1l1l_opy_ (u"ࠨࡖࡵࡹࡪ࠭অ"))
        l111llll1_opy_  = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬআ") + addon
        l11l1l1ll_opy_ =  l11ll111l_opy_(addon)
        query   =  l111llll1_opy_ + l11l1l1ll_opy_
        return sendJSON(query, addon)
    return l11l11lll_opy_(addon)
def l11l11lll_opy_(addon):
    if addon == l11l1ll1l_opy_:
        l11l1l111_opy_ = [l1l1l_opy_ (u"ࠪ࠵࠻࠷ࠧই"), l1l1l_opy_ (u"ࠫ࠶࠼࠰ࠨঈ"), l1l1l_opy_ (u"ࠬ࠸࠳࠷ࠩউ"), l1l1l_opy_ (u"࠭࠲࠵࠴ࠪঊ"), l1l1l_opy_ (u"ࠧ࠲࠷࠻ࠫঋ"), l1l1l_opy_ (u"ࠨ࠳࠸࠽ࠬঌ")]
    if addon == l111lll1l_opy_:
        l11l1l111_opy_ = [l1l1l_opy_ (u"ࠩ࠸ࠫ঍"), l1l1l_opy_ (u"ࠪ࠵࠵࠼ࠧ঎"), l1l1l_opy_ (u"ࠫ࠹࠭এ"), l1l1l_opy_ (u"ࠬ࠸࠶࠴ࠩঐ"), l1l1l_opy_ (u"࠭࠱࠴࠴ࠪ঑")]
    if addon == locked:
        l11l1l111_opy_ = [l1l1l_opy_ (u"ࠧ࠴࠲ࠪ঒"), l1l1l_opy_ (u"ࠨ࠵࠴ࠫও"), l1l1l_opy_ (u"ࠩ࠶࠶ࠬঔ"), l1l1l_opy_ (u"ࠪ࠷࠸࠭ক"), l1l1l_opy_ (u"ࠫ࠸࠺ࠧখ"), l1l1l_opy_ (u"ࠬ࠹࠵ࠨগ"), l1l1l_opy_ (u"࠭࠳࠹ࠩঘ"), l1l1l_opy_ (u"ࠧ࠵࠲ࠪঙ"), l1l1l_opy_ (u"ࠨ࠶࠴ࠫচ"), l1l1l_opy_ (u"ࠩ࠷࠹ࠬছ"), l1l1l_opy_ (u"ࠪ࠸࠼࠭জ"), l1l1l_opy_ (u"ࠫ࠹࠿ࠧঝ"), l1l1l_opy_ (u"ࠬ࠻࠲ࠨঞ")]
    if addon == l111ll1l1_opy_:
        l11l1l111_opy_ = [l1l1l_opy_ (u"࠭࠲࠶ࠩট"), l1l1l_opy_ (u"ࠧ࠳࠸ࠪঠ"), l1l1l_opy_ (u"ࠨ࠴࠺ࠫড"), l1l1l_opy_ (u"ࠩ࠵࠽ࠬঢ"), l1l1l_opy_ (u"ࠪ࠷࠵࠭ণ"), l1l1l_opy_ (u"ࠫ࠸࠷ࠧত"), l1l1l_opy_ (u"ࠬ࠹࠲ࠨথ"), l1l1l_opy_ (u"࠭࠳࠶ࠩদ"), l1l1l_opy_ (u"ࠧ࠴࠸ࠪধ"), l1l1l_opy_ (u"ࠨ࠵࠺ࠫন"), l1l1l_opy_ (u"ࠩ࠶࠼ࠬ঩"), l1l1l_opy_ (u"ࠪ࠷࠾࠭প"), l1l1l_opy_ (u"ࠫ࠹࠶ࠧফ"), l1l1l_opy_ (u"ࠬ࠺࠱ࠨব"), l1l1l_opy_ (u"࠭࠴࠹ࠩভ"), l1l1l_opy_ (u"ࠧ࠵࠻ࠪম"), l1l1l_opy_ (u"ࠨ࠷࠳ࠫয"), l1l1l_opy_ (u"ࠩ࠸࠶ࠬর"), l1l1l_opy_ (u"ࠪ࠹࠹࠭঱"), l1l1l_opy_ (u"ࠫ࠺࠼ࠧল"), l1l1l_opy_ (u"ࠬ࠻࠷ࠨ঳"), l1l1l_opy_ (u"࠭࠵࠹ࠩ঴"), l1l1l_opy_ (u"ࠧ࠶࠻ࠪ঵"), l1l1l_opy_ (u"ࠨ࠸࠳ࠫশ"), l1l1l_opy_ (u"ࠩ࠹࠵ࠬষ"), l1l1l_opy_ (u"ࠪ࠺࠷࠭স"), l1l1l_opy_ (u"ࠫ࠻࠹ࠧহ"), l1l1l_opy_ (u"ࠬ࠼࠵ࠨ঺"), l1l1l_opy_ (u"࠭࠶࠷ࠩ঻"), l1l1l_opy_ (u"ࠧ࠷࠹়ࠪ"), l1l1l_opy_ (u"ࠨ࠸࠼ࠫঽ"), l1l1l_opy_ (u"ࠩ࠺࠴ࠬা"), l1l1l_opy_ (u"ࠪ࠻࠹࠭ি"), l1l1l_opy_ (u"ࠫ࠼࠽ࠧী"), l1l1l_opy_ (u"ࠬ࠽࠸ࠨু"), l1l1l_opy_ (u"࠭࠸࠱ࠩূ"), l1l1l_opy_ (u"ࠧ࠹࠳ࠪৃ")]
    login = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸ࠵ࠧৄ") % addon
    sendJSON(login, addon)
    l11l11l_opy_ = []
    for l11ll1111_opy_ in l11l1l111_opy_:
        if (addon == l11l1ll1l_opy_) or (addon == l111lll1l_opy_):
            query = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠪࡹ࠯ࡀ࡯ࡲࡨࡪࡥࡩࡥ࠿ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪࡲࡵࡤࡦ࠿ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪࡸ࡫ࡣࡵ࡫ࡲࡲࡤ࡯ࡤ࠾ࠧࡶࠫ৅") % (addon, l11ll1111_opy_)
        if (addon == locked) or (addon == l111ll1l1_opy_):
            query = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳ࠰ࡁࡸࡶࡱࡃࠥࡴࠨࡰࡳࡩ࡫࠽࠵ࠨࡱࡥࡲ࡫࠽ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡶ࡬ࡢࡻࡀࠪࡩࡧࡴࡦ࠿ࠩࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮࠾ࠨࡳࡥ࡬࡫࠽ࠨ৆") % (addon, l11ll1111_opy_)
        response = sendJSON(query, addon)
        l11l11l_opy_.extend(response)
    return l11l11l_opy_
def sendJSON(query, addon):
    l11l1ll11_opy_     = l1l1l_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࠥࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧে") % query
    l11l11l1l_opy_  = xbmc.executeJSONRPC(l11l1ll11_opy_)
    response = json.loads(l11l11l1l_opy_)
    result   = response[l1l1l_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬৈ")]
    if xbmcgui.Window(10000).getProperty(l1l1l_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡇࡆࡐࡕࡉࠬ৉")) == l1l1l_opy_ (u"ࠧࡕࡴࡸࡩࠬ৊"):
        xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"ࠨࡩࡨࡲࡷ࡫ࠧো"), l1l1l_opy_ (u"ࠩࡷࡶࡺ࡫ࠧৌ"))
    if xbmcgui.Window(10000).getProperty(l1l1l_opy_ (u"ࠪࡔࡑ࡛ࡇࡊࡐࡢࡘ࡛ࡍࡕࡊࡆࡈ্ࠫ")) == l1l1l_opy_ (u"࡙ࠫࡸࡵࡦࠩৎ"):
        xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"ࠬࡺࡶࡨࡷ࡬ࡨࡪ࠭৏"), l1l1l_opy_ (u"࠭ࡴࡳࡷࡨࠫ৐"))
    return result[l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭৑")]
def l11ll111l_opy_(addon):
    if (addon == l11l11l11_opy_) or (addon == l111lllll_opy_):
        return l1l1l_opy_ (u"ࠨ࠱ࡂࡧࡦࡺ࠽࠮࠴ࠩࡨࡦࡺࡥࠧࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠬࡥ࡯ࡦࡇࡥࡹ࡫ࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡲࡵࡤࡦ࠿࠵ࠪࡳࡧ࡭ࡦ࠿ࡐࡽࠪ࠸࠰ࡄࡪࡤࡲࡳ࡫࡬ࡴࠨࡵࡩࡨࡵࡲࡥࡰࡤࡱࡪࠬࡳࡵࡣࡵࡸࡉࡧࡴࡦࠨࡸࡶࡱࡃࡵࡳ࡮ࠪ৒")
    return l1l1l_opy_ (u"ࠩࠪ৓")
def l1ll1111_opy_():
    modules = map(__import__, [l1l11l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l1l1l_opy_ (u"ࠪࡘࡷࡻࡥࠨ৔")
    if len(modules[-1].Window(10**4).getProperty(l11lll_opy_)):
        return l1l1l_opy_ (u"࡙ࠫࡸࡵࡦࠩ৕")
    return l1l1l_opy_ (u"ࠬࡌࡡ࡭ࡵࡨࠫ৖")
def l1l111l1_opy_(e, addon):
    l1ll111l_opy_ = l1l1l_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠱ࠦࡡ࡯ࠢࡨࡶࡷࡵࡲࠡࡱࡦࡧࡺࡸࡥࡥ࠼ࠣࡎࡘࡕࡎࠡࡇࡵࡶࡴࡸ࠺ࠡࠧࡶ࠰ࠥࠫࡳࠨৗ")  % (e, addon)
    l1_opy_ = l1l1l_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡤࡱࡱࡸࡦࡩࡴࠡࡷࡶࠤࡴࡴࠠࡵࡪࡨࠤ࡫ࡵࡲࡶ࡯࠱ࠫ৘")
    l1ll11ll_opy_ = l1l1l_opy_ (u"ࠨࡗࡳࡰࡴࡧࡤࠡࡣࠣࡰࡴ࡭ࠠࡷ࡫ࡤࠤࡹ࡮ࡥࠡࡣࡧࡨࡴࡴࠠࡴࡧࡷࡸ࡮ࡴࡧࡴࠢࡤࡲࡩࠦࡰࡰࡵࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰ࠴ࠧ৙")
    dixie.log(addon)
    dixie.log(e)
def getPluginInfo(streamurl, kodiID=False):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l111ll11l_opy_   = l1l1l_opy_ (u"ࠩࡎࡳࡩ࡯ࠠࡑࡘࡕࠫ৚")
            l111lll11_opy_ = os.path.join(dixie.RESOURCES, l1l1l_opy_ (u"ࠪ࡯ࡴࡪࡩ࠮ࡲࡹࡶ࠳ࡶ࡮ࡨࠩ৛"))
            return l111ll11l_opy_, l111lll11_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l1l1l_opy_ (u"ࠫࡷࡺ࡭ࡱࠩড়")) or url.startswith(l1l1l_opy_ (u"ࠬࡸࡴ࡮ࡲࡨࠫঢ়")) or url.startswith(l1l1l_opy_ (u"࠭ࡲࡵࡵࡳࠫ৞")) or url.startswith(l1l1l_opy_ (u"ࠧࡩࡶࡷࡴࠬয়")):
            l111ll11l_opy_   = l1l1l_opy_ (u"ࠨ࡯࠶ࡹࠥࡖ࡬ࡢࡻ࡯࡭ࡸࡺࠧৠ")
            l111lll11_opy_ = os.path.join(dixie.RESOURCES, l1l1l_opy_ (u"ࠩ࡬ࡴࡹࡼ࠭ࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡳࡲ࡬࠭ৡ"))
            return l111ll11l_opy_, l111lll11_opy_
    except:
        pass
    if streamurl.startswith(l1l1l_opy_ (u"ࠪࡴࡻࡸ࠺࠰࠱ࠪৢ")):
        l111ll11l_opy_   = l1l1l_opy_ (u"ࠫࡐࡵࡤࡪࠢࡓ࡚ࡗ࠭ৣ")
        l111lll11_opy_ = os.path.join(dixie.RESOURCES, l1l1l_opy_ (u"ࠬࡱ࡯ࡥ࡫࠰ࡴࡻࡸ࠮ࡱࡰࡪࠫ৤"))
        return l111ll11l_opy_, l111lll11_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        l11l111ll_opy_ = streamurl.split(l1l1l_opy_ (u"࠭࡝ࡐࡖࡗࡣࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ৥"), 1)[-1].split(l1l1l_opy_ (u"ࠧ࠰ࠩ০"), 1)[0]
    if l1l1l_opy_ (u"ࠨ࡟ࡒࡘ࡙ࡥࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ১") in streamurl:
        l11l111ll_opy_ = streamurl.split(l1l1l_opy_ (u"ࠩࡠࡓ࡙࡚࡟ࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ২"), 1)[-1].split(l1l1l_opy_ (u"ࠪ࠳ࠬ৩"), 1)[0]
    if streamurl.startswith(l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ৪")):
        l11l111ll_opy_ = streamurl.split(l1l1l_opy_ (u"ࠬ࠵࠯ࠨ৫"), 1)[-1].split(l1l1l_opy_ (u"࠭࠯ࠨ৬"), 1)[0]
    if l1l1l_opy_ (u"ࠧࡈࡕࡓࡖ࡙࡙࠺ࠨ৭") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡨ࡫ࡽࡱࡴࡹࡰࡰࡴࡷࡷࠬ৮")
    if l1l1l_opy_ (u"ࠩࡢࡣࡘࡌ࡟ࡠࠩ৯") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡴࡷࡵࡧࡳࡣࡰ࠲ࡸࡻࡰࡦࡴ࠱ࡪࡦࡼ࡯ࡶࡴ࡬ࡸࡪࡹࠧৰ")
    if l1l1l_opy_ (u"ࠫࡓࡏࡃࡆ࠼ࠪৱ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡳࡧࡴࡩࡱࡶࡹࡧࡹࡩࡤࡧࠪ৲")
    if l1l1l_opy_ (u"࠭ࡐࡓࡇࡐ࠾ࠬ৳") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡰࡳࡧࡰ࡭ࡺࡳࡩࡱࡶࡹࠫ৴")
    if l1l1l_opy_ (u"ࠨࡉࡌ࡞࠿࠭৵") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡩ࡬ࡾࡲࡵࡴࡷࠩ৶")
    if l1l1l_opy_ (u"ࠪࡋࡊࡎ࠺ࠨ৷") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡫ࡪ࡮࡯ࡴࡶ࡬ࡲ࡬࠭৸")
    if l1l1l_opy_ (u"ࠬࡓࡔ࡙ࡋࡈ࠾ࠬ৹") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡳࡡࡵࡴ࡬ࡼ࡮ࡸࡥ࡭ࡣࡱࡨࠬ৺")
    if l1l1l_opy_ (u"ࠧࡕࡘࡎ࠾ࠬ৻") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡵࡸ࡮࡭ࡳ࡭ࡳࠨৼ")
    if l1l1l_opy_ (u"࡛ࠩࡘࡈࡀࠧ৽") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡸࡷ࡫ࡡ࡮࠯ࡦࡳࡩ࡫ࡳࠨ৾")
    if l1l1l_opy_ (u"ࠫࡘࡉࡔࡗ࠼ࠪ৿") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡩࡴࡷࠩ਀")
    if l1l1l_opy_ (u"࠭ࡓࡖࡒ࠽ࠫਁ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡵࡴࡨࡥࡲࡹࡵࡱࡴࡨࡱࡪ࠸ࠧਂ")
    if l1l1l_opy_ (u"ࠨࡗࡎࡘ࠿࠭ਃ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡷ࡮ࡸࡺࡸ࡫ࠨ਄")
    if l1l1l_opy_ (u"ࠪࡐࡎࡓࡉࡕ࠼ࠪਅ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡐ࡮ࡳࡩࡵ࡮ࡨࡷࡸࡏࡐࡕࡘࠪਆ")
    if l1l1l_opy_ (u"ࠬࡌࡁࡃ࠼ࠪਇ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡬ࡡࡣࡪࡲࡷࡹ࡯࡮ࡨࠩਈ")
    if l1l1l_opy_ (u"ࠧࡂࡅࡈ࠾ࠬਉ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡥࡨࡸࡻ࠭ਊ")
    if l1l1l_opy_ (u"ࠩࡋࡓࡗࡏ࡚࠻ࠩ਋") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡫ࡳࡷ࡯ࡺࡰࡰ࡬ࡴࡹࡼࠧ਌")
    if l1l1l_opy_ (u"ࠫࡗࡕࡏࡕ࠴࠽ࠫ਍") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡵ࡯ࡵࡋࡓࡘ࡛࠭਎")
    if l1l1l_opy_ (u"࠭ࡍࡆࡉࡄ࠾ࠬਏ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡭ࡦࡩࡤ࡭ࡵࡺࡶࠨਐ")
    if l1l1l_opy_ (u"ࠨࡘࡇࡖ࡙࡜࠺ࠨ਑") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡘࡄࡈࡊࡘࠧ਒")
    if l1l1l_opy_ (u"ࠪࡌࡉ࡚ࡖ࠻ࠩਓ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡲࡧࡲࡵࡪࡸࡦࠬਔ")
    if l1l1l_opy_ (u"ࠬࡎࡄࡕࡘ࠵࠾ࠬਕ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡵࡺࡣ࠵ࠫਖ")
    if l1l1l_opy_ (u"ࠧࡉࡆࡗ࡚࠸ࡀࠧਗ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥ࠷࠭ਘ")
    if l1l1l_opy_ (u"ࠩࡋࡈ࡙࡜࠴࠻ࠩਙ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡰࠬਚ")
    if l1l1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛࠽ࠫਛ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡧࡨࡣࡪࡲ࡯ࡥࡾ࡫ࡲࠨਜ")
    if l1l1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝࠷ࡀࠧਝ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱ࡮ࡤࡽࡪࡸࡷࡸࡹࠪਞ")
    if l1l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡒ࠻ࠩਟ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡰࡦࡿࡥࡳࡹࡺࡻࠬਠ")
    if l1l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡋࡗ࡚࠿࠭ਡ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡹࡼࠧਢ")
    if l1l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡈ࠿࠭ਣ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡪࡥࡹࠩਤ")
    if l1l1l_opy_ (u"ࠧࡋࡋࡑ࡜࠷ࡀࠧਥ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡫࡫ࡱࡼࡹࡼ࠲ࠨਦ")
    if l1l1l_opy_ (u"ࠩࡐࡅ࡙࡙࠺ࠨਧ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡐࡥࡹࡹࡂࡶ࡫࡯ࡨࡸࡏࡐࡕࡘࠪਨ")
    if l1l1l_opy_ (u"ࠫࡗࡕࡏࡕ࠼ࠪ਩") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡵ࡯ࡵ࡫ࡳࡸࡻ࠭ਪ")
    if l1l1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡗࡈ࠺ࠨਫ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡦࡤࡲࡳࡹ࠭ਬ")
    if l1l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡃࡍࡗ࠽ࠫਭ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡥ࡯ࡹ࡮ࡶࡴࡷࠩਮ")
    if l1l1l_opy_ (u"ࠪࡍࡕ࡚ࡓࠨਯ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡺࡶࡴࡷࡥࡷࠬਰ")
    if l1l1l_opy_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠿࠭਱") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲࡩࡷࡧࡰ࡭ࡽ࠭ਲ")
    if l1l1l_opy_ (u"ࠧࡆࡐࡇ࠾ࠬਲ਼") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡆࡰࡧࡰࡪࡹࡳࠨ਴")
    if l1l1l_opy_ (u"ࠩࡉࡐࡆࡀࠧਵ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡉࡰࡦࡽ࡬ࡦࡵࡶࡘࡻ࠭ਸ਼")
    if l1l1l_opy_ (u"ࠫࡒࡇࡘࡊ࠼ࠪ਷") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡲࡧࡸࡪࡹࡨࡦࡹࡼࠧਸ")
    if l1l1l_opy_ (u"࠭ࡆࡍࡃࡖ࠾ࠬਹ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡆ࡭ࡣࡺࡰࡪࡹࡳࡕࡸࠪ਺")
    if l1l1l_opy_ (u"ࠨࡕࡓࡖࡒࡀࠧ਻") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡕࡸࡴࡷ࡫࡭ࡢࡥࡼࡘ਼࡛࠭")
    if l1l1l_opy_ (u"ࠪࡑࡈࡑࡔࡗ࠼ࠪ਽") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡱࡨࡱࡴࡷ࠯ࡳࡰࡺࡹࠧਾ")
    if l1l1l_opy_ (u"࡚ࠬࡗࡊࡕࡗ࠾ࠬਿ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡺࡷࡪࡵࡷࡩࡩ࠭ੀ")
    if l1l1l_opy_ (u"ࠧࡑࡔࡈࡗ࡙ࡀࠧੁ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡱࡵࡤࡨࡩࡵ࡮ࠨੂ")
    if l1l1l_opy_ (u"ࠩࡅࡐࡐࡏ࠺ࠨ੃") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡅࡰࡦࡩ࡫ࡊࡥࡨࡘ࡛࠭੄")
    if l1l1l_opy_ (u"ࠫࡋࡘࡅࡆ࠼ࠪ੅") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡫ࡸࡥࡦࡸ࡬ࡩࡼ࠭੆")
    if l1l1l_opy_ (u"࠭ࡵࡱࡰࡳ࠾ࠬੇ") in streamurl:
        l11l111ll_opy_ = l1l1l_opy_ (u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮ࡩࡦ࡫ࡳࡲ࡫ࡲࡶࡰ࠱ࡺ࡮࡫ࡷࠨੈ")
    return l11l1l1l1_opy_(l11l111ll_opy_, kodiID)
def l11l1l1l1_opy_(l11l111ll_opy_, kodiID):
    l111ll11l_opy_     = l1l1l_opy_ (u"ࠨࠩ੉")
    l111lll11_opy_   = l1l1l_opy_ (u"ࠩࠪ੊")
    try:
        l11ll11l1_opy_ = xbmcaddon.Addon(l11l111ll_opy_).getAddonInfo(l1l1l_opy_ (u"ࠪࡲࡦࡳࡥࠨੋ"))
        l111ll11l_opy_    = dixie.cleanLabel(l11ll11l1_opy_)
        l111lll11_opy_  = xbmcaddon.Addon(l11l111ll_opy_).getAddonInfo(l1l1l_opy_ (u"ࠫ࡮ࡩ࡯࡯ࠩੌ"))
        if kodiID:
            l111ll1ll_opy_ = xbmcaddon.Addon(l11l111ll_opy_).getAddonInfo(l1l1l_opy_ (u"ࠬ࡯ࡤࠨ੍"))
            return l111ll11l_opy_, l111ll1ll_opy_
        return l111ll11l_opy_, l111lll11_opy_
    except:
        l111ll11l_opy_   = l1l1l_opy_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡔࡱࡸࡶࡨ࡫ࠧ੎")
        l111lll11_opy_ =  dixie.ICON
        return l111ll11l_opy_, l111lll11_opy_
    return l111ll11l_opy_, l111lll11_opy_
def selectStream(url, channel):
    l111ll111_opy_ = url.split(l1l1l_opy_ (u"ࠧࡽࠩ੏"))
    if len(l111ll111_opy_) == 0:
        return None
    options, l1l1l1l1_opy_ = getOptions(l111ll111_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l111ll111_opy_) == 1:
            return l1l1l1l1_opy_[0]
    import selectDialog
    l11l11ll1_opy_ = selectDialog.select(l1l1l_opy_ (u"ࠨࡕࡨࡰࡪࡩࡴࠡࡣࠣࡷࡹࡸࡥࡢ࡯ࠪ੐"), options)
    if l11l11ll1_opy_ < 0:
        raise Exception(l1l1l_opy_ (u"ࠩࡖࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡉࡡ࡯ࡥࡨࡰࠬੑ"))
    return l1l1l1l1_opy_[l11l11ll1_opy_]
def getOptions(l111ll111_opy_, channel, addmore=True):
    options = []
    l1l1l1l1_opy_    = []
    for index, stream in enumerate(l111ll111_opy_):
        l111ll11l_opy_ = getPluginInfo(stream)
        l1llll1_opy_ = l1l1l_opy_ (u"ࠪࠫ੒")
        l11l11111_opy_  = l111ll11l_opy_[1]
        if stream.startswith(OPEN_OTT):
            l11l1l11l_opy_ = stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l1l1l_opy_ (u"ࠫࠬ੓"))
            l1llll1_opy_  = l1llll1_opy_ + l11l1l11l_opy_
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l1l1l_opy_ (u"ࠬ࠭੔"))
        else:
            l1llll1_opy_  = l1llll1_opy_ + channel
        options.append([l1llll1_opy_, index, l11l11111_opy_])
        l1l1l1l1_opy_.append(stream)
    if addmore:
        options.append([l1l1l_opy_ (u"࠭ࡁࡥࡦࠣࡱࡴࡸࡥ࠯࠰࠱ࠫ੕"), index + 1, dixie.ICON])
        l1l1l1l1_opy_.append(l1l1l_opy_ (u"ࠧࡢࡦࡧࡑࡴࡸࡥࠨ੖"))
    return options, l1l1l1l1_opy_
if __name__ == l1l1l_opy_ (u"ࠨࡡࡢࡱࡦ࡯࡮ࡠࡡࠪ੗"):
    checkAddons()