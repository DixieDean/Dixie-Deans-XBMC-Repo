# coding: UTF-8
import sys
l1l11l1l_opy_ = sys.version_info [0] == 2
l1llll11_opy_ = 2048
l1l1ll11_opy_ = 7
def l11ll_opy_ (l1l11l_opy_):
	global l1llllll_opy_
	l1ll1ll1_opy_ = ord (l1l11l_opy_ [-1])
	l1l1l1l1_opy_ = l1l11l_opy_ [:-1]
	l11l11l_opy_ = l1ll1ll1_opy_ % len (l1l1l1l1_opy_)
	l11ll1_opy_ = l1l1l1l1_opy_ [:l11l11l_opy_] + l1l1l1l1_opy_ [l11l11l_opy_:]
	if l1l11l1l_opy_:
		l1llll_opy_ = unicode () .join ([unichr (ord (char) - l1llll11_opy_ - (l111l11_opy_ + l1ll1ll1_opy_) % l1l1ll11_opy_) for l111l11_opy_, char in enumerate (l11ll1_opy_)])
	else:
		l1llll_opy_ = str () .join ([chr (ord (char) - l1llll11_opy_ - (l111l11_opy_ + l1ll1ll1_opy_) % l1l1ll11_opy_) for l111l11_opy_, char in enumerate (l11ll1_opy_)])
	return eval (l1llll_opy_)
import xbmc
import xbmcgui
import xbmcaddon
import json
import time
import datetime
import os
import dixie
import mapping
l1l111l_opy_  = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡊࡱࡧࡷ࡭ࡧࡶࡷ࡙ࡼࠧࠀ")
l11lll1_opy_   = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡭ࡵࡲࡪࡼࡲࡲ࡮ࡶࡴࡷࠩࠁ")
l1_opy_   = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡬ࡡࡣࡪࡲࡷࡹ࡯࡮ࡨࠩࠂ")
l11lllll_opy_     = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡤࡧࡷࡺࠬࠃ")
l1lll1_opy_     = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡱࡲࡸࡎࡖࡔࡗࠩࠄ")
l1l111l1_opy_ = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡎ࡬ࡱ࡮ࡺ࡬ࡦࡵࡶࡍࡕ࡚ࡖࠨࠅ")
l1ll_opy_     = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡙ࡅࡉࡋࡒࠨࠆ")
l1ll111l_opy_   = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡹࡸࡥࡢ࡯ࡶࡹࡵࡸࡥ࡮ࡧ࠵ࠫࠇ")
l1lll1l_opy_      = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡩࡴࡷࠩࠈ")
l111l1l_opy_   = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡺࡶ࡬࡫ࡱ࡫ࡸ࠭ࠉ")
l11llll1_opy_      = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡬ࡪࡷࡻ࠲ࡹࡼࠧࠊ")
l1ll1ll_opy_    = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡶࡵࡩࡦࡳࡳࡦࡣࡶࡽ࠳ࡺࡶࠨࠋ")
l1ll1l_opy_  = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡰࡥࡷࡺࡨࡶࡤࠪࠌ")
l11l11_opy_  = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧ࠲ࠨࠍ")
l1ll11ll_opy_   = [l111l1l_opy_, l1ll111l_opy_, l1lll1l_opy_, l1ll_opy_, l1l111l1_opy_, l1l111l_opy_, l11lll1_opy_, l1_opy_, l11lllll_opy_, l1lll1_opy_]
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
def isValid(stream):
    if l11ll_opy_ (u"ࠫࡍࡕࡒࡊ࡜࠽ࠫࠎ") in stream:
        dixie.log(l11ll_opy_ (u"ࠬ࠳࠭࠮ࠢࡋࡓࡗࡏ࡚ࡐࡐࠣࡘࡗ࡛ࡅࠡ࠯࠰࠱ࠬࠏ"))
        return True
    if l11ll_opy_ (u"࠭ࡆࡍࡃ࠽ࠫࠐ") in stream:
        dixie.log(l11ll_opy_ (u"ࠧ࠮࠯࠰ࠤࡋࡒࡁࡘࡎࡈࡗࡘࠦࡔࡓࡗࡈࠤ࠲࠳࠭ࠨࠑ"))
        return True
    if l11ll_opy_ (u"ࠨࡈࡄࡆ࠿࠭ࠒ") in stream:
        dixie.log(l11ll_opy_ (u"ࠩ࠰࠱࠲ࠦࡆࡂࡄࡌࡔ࡙࡜ࠠࡕࡔࡘࡉࠥ࠳࠭࠮ࠩࠓ"))
        return True
    if l11ll_opy_ (u"ࠪࡅࡈࡋ࠺ࠨࠔ") in stream:
        dixie.log(l11ll_opy_ (u"ࠫ࠲࠳࠭ࠡࡃࡆࡉ࡙࡜ࠠࡕࡔࡘࡉࠥ࠳࠭࠮ࠩࠕ"))
        return True
    if l11ll_opy_ (u"ࠬࡘࡏࡐࡖ࠵࠾ࠬࠖ") in stream:
        dixie.log(l11ll_opy_ (u"࠭࠭࠮࠯ࠣࡖࡔࡕࡔ࠳ࠢࡗࡖ࡚ࡋࠠ࠮࠯࠰ࠫࠗ"))
        return True
    if l11ll_opy_ (u"ࠧࡍࡋࡐࡍ࡙ࡀࠧ࠘") in stream:
        dixie.log(l11ll_opy_ (u"ࠨ࠯࠰࠱ࠥࡒࡉࡎࡋࡗࡐࡊ࡙ࡓࠡࡖࡕ࡙ࡊࠦ࠭࠮࠯ࠪ࠙"))
        return True
    if l11ll_opy_ (u"࡙ࠩࡈࡗ࡚ࡖ࠻ࠩࠚ") in stream:
        dixie.log(l11ll_opy_ (u"ࠪ࠱࠲࠳ࠠࡗࡃࡇࡉࡗࠦࡔࡓࡗࡈࠤ࠲࠳࠭ࠨࠛ"))
        return True
    if l11ll_opy_ (u"ࠫࡘ࡛ࡐ࠻ࠩࠜ") in stream:
        dixie.log(l11ll_opy_ (u"ࠬ࠳࠭࠮ࠢࡖ࡙ࡕࡘࡅࡎࡇࠣࡘࡗ࡛ࡅࠡ࠯࠰࠱ࠬࠝ"))
        return True
    if l11ll_opy_ (u"࠭ࡓࡄࡖ࡙࠾ࠬࠞ") in stream:
        dixie.log(l11ll_opy_ (u"ࠧ࠮࠯࠰ࠤࡘࡉࡔࡗࠢࡗࡖ࡚ࡋࠠ࠮࠯࠰ࠫࠟ"))
        return True
    if l11ll_opy_ (u"ࠨࡖ࡙ࡏ࠿࠭ࠠ") in stream:
        dixie.log(l11ll_opy_ (u"ࠩ࠰࠱࠲ࠦࡔࡗࡍࡌࡒࡌ࡙ࠠࡕࡔࡘࡉࠥ࠳࠭࠮ࠩࠡ"))
        return True
    dixie.log(l11ll_opy_ (u"ࠪ࠱࠲࠳ࠠࡗࡃࡏࡍࡉࠦࡆࡂࡎࡖࡉࠥ࠳࠭࠮ࠩࠢ"))
    return False
def getRecording(name, title, start, stream):
    dixie.log(l11ll_opy_ (u"ࠫࡂࡃ࠽࠾࠿ࡀࠤ࡬࡫ࡴࡓࡧࡦࡳࡷࡪࡩ࡯ࡩࠣࡁࡂࡃ࠽࠾࠿ࠪࠣ"))
    l11llll_opy_   =  stream.split(l11ll_opy_ (u"ࠬࢂࠧࠤ"))
    l11ll1l_opy_    =  getAddonInfo(l11llll_opy_)
    catchup   = l11ll_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡯ࡳࡣࡱ࡫ࡪࡣࠠ࡜ࡅࡤࡸࡨ࡮࠭ࡶࡲࠣࡅࡻࡧࡩ࡭ࡣࡥࡰࡪࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨࠥ")
    l11lll1l_opy_ = l11ll_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࠥࡡࡎࡰࠢࡆࡥࡹࡩࡨ࠮ࡷࡳࠤࡆࡼࡡࡪ࡮ࡤࡦࡱ࡫࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࠦ")
    options = []
    l1l_opy_ = []
    for item in l11ll1l_opy_:
        l1lllll_opy_ =  item[0]
        l1lllll_opy_ = l11ll_opy_ (u"ࠨ࡝ࡅࡡࠬࠧ") + l1lllll_opy_ + l11ll_opy_ (u"ࠩ࡞࠳ࡇࡣࠧࠨ")
        addon =  item[1]
        l1l1l_opy_ = l1l1111l_opy_(addon)
        l1lll1ll_opy_ = l1l1l11l_opy_(addon, name)
        dixie.log(l1l1l_opy_)
        dixie.log(l1lll1ll_opy_)
        if not l1l1l_opy_:
            l111l1_opy_ = l1lllll_opy_ + l11lll1l_opy_
            options.append(l111l1_opy_)
            l1l_opy_.append(addon)
        if l1l1l_opy_ and not l1lll1ll_opy_:
            l111l1_opy_ = l1lllll_opy_ + l11lll1l_opy_
            options.append(l111l1_opy_)
            l1l_opy_.append(addon)
        if l1l1l_opy_ and l1lll1ll_opy_:
            l1lll_opy_ = l1lllll_opy_ + catchup
            options.append(l1lll_opy_)
            l1l_opy_.append(addon)
    l1llll1l_opy_ = xbmcgui.Dialog().select(l11ll_opy_ (u"ࠪࡗࡊࡒࡅࡄࡖࠣࡇࡆ࡚ࡃࡉ࠯ࡘࡔࠥࡇࡄࡅ࠯ࡒࡒࠬࠩ"), options)
    addon  = l1l_opy_[l1llll1l_opy_]
    if l1llll1l_opy_ > -1:
        return getIPTVRecording(addon, name, title, start, stream)
    dixie.DialogOK(l11ll_opy_ (u"ࠫࡓࡵࠠࡄࡣࡷࡧ࡭࠳ࡵࡱࠢࡄࡨࡩ࠳࡯࡯ࠢࡖࡩࡱ࡫ࡣࡵࡧࡧ࠲ࠬࠪ"), l11ll_opy_ (u"ࠬࡘࡥࡷࡧࡵࡸ࡮ࡴࡧࠡࡤࡤࡧࡰࠦࡴࡰࠢࡏ࡭ࡻ࡫ࠠࡕࡘ࠱ࠫࠫ"))
    return
def getAddonInfo(l11llll_opy_):
    import plugins
    l11ll1l_opy_ = []
    for stream in l11llll_opy_:
        info    = plugins.getPluginInfo(stream, kodiID=True)
        l1lllll_opy_   = info[0]
        addon   = info[1]
        result  = [l1lllll_opy_, addon]
        if result not in l11ll1l_opy_:
            l11ll1l_opy_.append(result)
    dixie.log(l11ll1l_opy_)
    return l11ll1l_opy_
def l1l1111l_opy_(addon):
    for item in l1ll11ll_opy_:
        if addon == item:
            return True
    return False
def l1l1l11l_opy_(addon, name):
    l11l111_opy_ = l1l1l1l_opy_(addon)
    dixie.log(l11l111_opy_)
    for item in l11l111_opy_:
        l1ll11l1_opy_  = name.upper()
        channel = item[0].upper()
        if l1ll11l1_opy_ == channel:
            return True
    return False
def l1l1l1l_opy_(addon):
    HOME  = dixie.PROFILE
    iPATH = os.path.join(HOME, l11ll_opy_ (u"࠭ࡩ࡯࡫ࠪࠬ"))
    if addon == l1_opy_:
        l11111_opy_ = os.path.join(iPATH, l11ll_opy_ (u"ࠧࡤࡣࡷࡧ࡭ࡻࡰࡇࡃࡅ࠲࡯ࡹ࡯࡯ࠩ࠭"))
        return json.load(open(l11111_opy_))
    if (addon == l1l111l_opy_) or (addon == l11lll1_opy_):
        l11111_opy_ = os.path.join(iPATH, l11ll_opy_ (u"ࠨࡥࡤࡸࡨ࡮ࡵࡱࡈࡏࡅ࠳ࡰࡳࡰࡰࠪ࠮"))
        return json.load(open(l11111_opy_))
    if addon == l11lllll_opy_:
        l11111_opy_ = os.path.join(iPATH, l11ll_opy_ (u"ࠩࡦࡥࡹࡩࡨࡶࡲࡄࡇࡊ࠴ࡪࡴࡱࡱࠫ࠯"))
        return json.load(open(l11111_opy_))
    if (addon == l1lll1_opy_) or (addon == l1l111l1_opy_) or (addon == l111l1l_opy_):
        l11111_opy_ = os.path.join(iPATH, l11ll_opy_ (u"ࠪࡧࡦࡺࡣࡩࡷࡳࡖࡔࡕࡔ࠯࡬ࡶࡳࡳ࠭࠰"))
        return json.load(open(l11111_opy_))
    if (addon == l1ll_opy_) or (addon == l1ll111l_opy_) or (addon == l1lll1l_opy_):
        l11111_opy_ = os.path.join(iPATH, l11ll_opy_ (u"ࠫࡨࡧࡴࡤࡪࡸࡴ࡛ࡇࡄࡆࡔ࠱࡮ࡸࡵ࡮ࠨ࠱"))
        return json.load(open(l11111_opy_))
    return [[l11ll_opy_ (u"ࠧࡔ࡯࡯ࡧࠥ࠲"), l11ll_opy_ (u"ࠨࡎࡰࡰࡨࠦ࠳")]]
def getIPTVRecording(addon, name, title, start, stream):
    dixie.log(l11ll_opy_ (u"ࠧࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࠣࡇࡆ࡚ࡃࡉࠢࡘࡔࠥࡏࡐࡕࡘࠣࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥࠧ࠴"))
    dixie.log(addon)
    dixie.log(name)
    dixie.log(title)
    dixie.log(start)
    dixie.log(stream)
    l1ll111_opy_ = l1lll111_opy_(addon)
    l1l1l1_opy_  = start - datetime.timedelta(seconds=l1ll111_opy_)
    dixie.log(l11ll_opy_ (u"ࠨࡇࡓࡋ࡙ࠥࡴࡢࡴࡷࠤ࡙࡯࡭ࡦ࠰࠱࠲࠿ࠦࠥࡴࠩ࠵") % start)
    dixie.log(l11ll_opy_ (u"ࠩࡈࡔࡌࠦࡓࡵࡣࡵࡸ࡚ࠥࡩ࡮ࡧࠣࡓࡋࡌࡓࡆࡖ࠽ࠤࠪࡹࠧ࠶") % l1l1l1_opy_)
    l11l_opy_ = str(l1l1l1_opy_)
    dixie.log(l11ll_opy_ (u"ࠪࡸ࡮ࡳࡥࡴࡶࡵ࡭ࡳ࡭࠺ࠡࠧࡶࠫ࠷") % l11l_opy_)
    l11_opy_   = l11l_opy_.split(l11ll_opy_ (u"ࠫࠥ࠭࠸"))[0]
    l1l1lll1_opy_  = l11l_opy_.split(l11ll_opy_ (u"ࠬࠦࠧ࠹"))[1]
    l1ll1l1_opy_   = time.strptime(l11_opy_, l11ll_opy_ (u"࡚࠭ࠥ࠯ࠨࡱ࠲ࠫࡤࠨ࠺"))
    theDate    = l1l11ll1_opy_(addon, l1ll1l1_opy_)
    dixie.log(l11ll_opy_ (u"ࠧࡵࡪࡨࡈࡦࡺࡥ࠻ࠢࠨࡷࠬ࠻") % theDate)
    l1ll1111_opy_  = time.strptime(l1l1lll1_opy_,  l11ll_opy_ (u"ࠨࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠪ࠼"))
    theTime    = time.strftime(l11ll_opy_ (u"ࠩࠨࡌ࠿ࠫࡍࠨ࠽"),  l1ll1111_opy_)
    dixie.log(l11ll_opy_ (u"ࠪࡸ࡭࡫ࡔࡪ࡯ࡨ࠾ࠥࠫࡳࠨ࠾") % theTime)
    return getCatchupLink(addon, name, title, theDate, theTime)
def l1lll111_opy_(addon):
    l111ll1_opy_ = l1l1ll1l_opy_()
    if (addon == l1ll_opy_) or (addon == l1ll111l_opy_) or (addon == l1lll1l_opy_):
        l1ll111_opy_ = -l111ll1_opy_ - 7200
        dixie.log(l11ll_opy_ (u"࡛ࠫࡇࡄࡆࡔࠣࡘࡎࡓࡅ࡛ࡑࡑࡉ࠿ࠦࠥࡴࠩ࠿") % l111ll1_opy_)
        dixie.log(l11ll_opy_ (u"ࠬ࡜ࡁࡅࡇࡕࠤࡔࡌࡆࡔࡇࡗ࠾ࠥࠫࡳࠨࡀ") % l1ll111_opy_)
        return l1ll111_opy_
    l1ll111_opy_ = -l111ll1_opy_
    dixie.log(l11ll_opy_ (u"࠭ࡔࡊࡏࡈ࡞ࡔࡔࡅ࠻ࠢࠨࡷࠬࡁ") % l111ll1_opy_)
    dixie.log(l11ll_opy_ (u"ࠧࡐࡈࡉࡗࡊ࡚࠺ࠡࠧࡶࠫࡂ") % l1ll111_opy_)
    return l1ll111_opy_
def l1l1ll1l_opy_():
    dixie.log(l11ll_opy_ (u"ࠨࡆࡄ࡝ࡑࡏࡇࡉࡖ࠽ࠤࠪࡹࠧࡃ") % time.daylight)
    dixie.log(l11ll_opy_ (u"ࠩࡗࡍࡒࡋ࡚ࡐࡐࡈ࠾ࠥࠫࡳࠨࡄ") % time.timezone)
    return time.timezone
def l1l11ll1_opy_(addon, l1ll1l1_opy_):
    if (addon == l11lllll_opy_) or (addon == l1ll_opy_) or (addon == l1ll111l_opy_) or (addon == l1lll1l_opy_):
        return time.strftime(l11ll_opy_ (u"ࠪࠩࡩ࠴ࠥ࡮ࠩࡅ"), l1ll1l1_opy_)
    if (addon == l1lll1_opy_) or (addon == l1l111l1_opy_) or (addon == l111l1l_opy_):
        return time.strftime(l11ll_opy_ (u"ࠫࠪ࡟࠯ࠦ࡯࠲ࠩࡩ࠭ࡆ"), l1ll1l1_opy_)
    return time.strftime(l11ll_opy_ (u"࡙ࠬࠫ࠮ࠧࡰ࠱ࠪࡪࠧࡇ"), l1ll1l1_opy_)
def getCatchupLink(addon, channel, theShow, theDate, theTime):
    dixie.log(l11ll_opy_ (u"࠭࠽࠾࠿ࡀࡁࡂࠦࡧࡦࡶࡆࡥࡹࡩࡨࡶࡲࡏ࡭ࡳࡱࠠ࠾࠿ࡀࡁࡂࡃࠧࡈ"))
    LABELFILE = l1ll1l11_opy_(addon)
    dixie.log(l11ll_opy_ (u"ࠧ࠾࠿ࡀࡁࡂࡃࠠࡍࡃࡅࡉࡑࡌࡉࡍࡇ࠯ࠤࡱࡧࡢࡦ࡮ࡰࡥࡵࡹࠠ࠾࠿ࡀࡁࡂࡃࠧࡉ"))
    labelmaps = json.load(open(LABELFILE))
    dixie.log(LABELFILE)
    dixie.log(labelmaps)
    l1l11ll_opy_  = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫࡊ") + addon
    l1111l_opy_ =  l111_opy_(addon)
    try:
        l11111l_opy_  = findCatchup(l11ll_opy_ (u"ࠩࡦࡥࡹࡩࡨࡶࡲ࡯࡭ࡳࡱࠧࡋ"), addon, l1l11ll_opy_, l1111l_opy_)
        l11l1l_opy_  = mapping.mapLabel(labelmaps, channel)
        l11l1l_opy_  = l11l1l_opy_.upper()
        dixie.log(l11ll_opy_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࠣࡧࡦࡺࡣࡩࡷࡳࡰ࡮ࡴ࡫ࠡ࠿ࡀࡁࡂࡃ࠽ࠨࡌ"))
        print addon, l11111l_opy_, l11l1l_opy_
        if (addon == l1ll_opy_) or (addon == l1ll111l_opy_) or (addon == l1lll1l_opy_):
            l1l1llll_opy_ = l1l11l11_opy_(l11ll_opy_ (u"࡛ࠫࡇࡄࡆࡔࠣࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬࡍ"), addon, l11l1l_opy_)
        else:
            l1l1llll_opy_ = findCatchup(l11ll_opy_ (u"ࠬࡺࡨࡦࡅ࡫ࡥࡳࡴࡥ࡭ࠩࡎ"), addon, l11111l_opy_, l11l1l_opy_)
        dixie.log(l11ll_opy_ (u"࠭࠽࠾࠿ࡀࡁࡂࠦࡴࡩࡧࡆ࡬ࡦࡴ࡮ࡦ࡮ࠣࡪ࡮ࡴࡤࡄࡣࡷࡧ࡭ࡻࡰࠡ࠿ࡀࡁࡂࡃ࠽ࠨࡏ"))
        print addon, l11111l_opy_, l11l1l_opy_, l1l1llll_opy_
        l1l11lll_opy_ = l1l1ll_opy_(addon, theDate, theTime)
        l1lll11_opy_      = findCatchup(l11ll_opy_ (u"ࠧࡵࡪࡨࡐ࡮ࡴ࡫ࠨࡐ"), addon, l1l1llll_opy_, l1l11lll_opy_, splitlabel=True)
        dixie.CloseBusy()
        return l1lll11_opy_
    except:
        dixie.CloseBusy()
        dixie.DialogOK(l11ll_opy_ (u"ࠨࡕࡲࡶࡷࡿ࠮ࠨࡑ"), l11ll_opy_ (u"࡚ࠩࡩࠥࡩ࡯ࡶ࡮ࡧࠤࡳࡵࡴࠡࡨ࡬ࡲࡩࠦࡡࠡࡥࡤࡸࡨ࡮ࡵࡱࠢࡶࡸࡷ࡫ࡡ࡮ࠢࡩࡳࡷࠦࡴࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱ࠳࠭ࡒ"), l11ll_opy_ (u"ࠪࡖࡪࡼࡥࡳࡶ࡬ࡲ࡬ࠦࡢࡢࡥ࡮ࠤࡹࡵࠠࡍ࡫ࡹࡩ࡚ࠥࡖ࠯ࠩࡓ"))
        return l11ll_opy_ (u"ࠫࠬࡔ")
def l1l11l11_opy_(string, addon, item):
    dixie.log(l11ll_opy_ (u"ࠬࡃ࠽࠾࠿ࡀࡁࠥ࡭ࡥࡵࡕࡨࡧࡹ࡯࡯࡯ࡵࠣࡁࡂࡃ࠽࠾࠿ࠪࡕ"))
    l1111l1_opy_ = [l11ll_opy_ (u"࠭࠳ࠨࡖ"), l11ll_opy_ (u"ࠧ࠹ࠩࡗ"), l11ll_opy_ (u"ࠨ࠻ࠪࡘ"),l11ll_opy_ (u"ࠩ࠴࠴࡙ࠬ"), l11ll_opy_ (u"ࠪ࠶࠽࡚࠭")]
    l111111_opy_ = []
    for l1111l_opy_ in l1111l1_opy_:
        query = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴ࠱ࡦࡥࡹࡩࡨࡶࡲ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴ࠫࡳࠨ࡛") % (addon, l1111l_opy_)
        dixie.log(l11ll_opy_ (u"ࠬࡃ࠽࠾࠿ࡀࡁࠥࡷࡵࡦࡴࡼࠤࡂࡃ࠽࠾࠿ࡀࠫ࡜"))
        dixie.log(query)
        response = sendJSON(query, addon)
        dixie.log(l11ll_opy_ (u"࠭࠽࠾࠿ࡀࡁࡂࠦࡱࡶࡧࡵࡽࠥࡘࡅࡔࡗࡏࡘࠥࡃ࠽࠾࠿ࡀࡁࠬ࡝"))
        dixie.log(response)
        l111111_opy_.extend(response)
    for file in l111111_opy_:
        l1l1lll_opy_ = file[l11ll_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭࡞")]
        dixie.log(l11ll_opy_ (u"ࠨ࠿ࡀࡁࡂࡃ࠽ࠡࡘࡄࡈࡊࡘࠠࡓࡃ࡚ࠤࡑࡇࡂࡆࡎࠣࡁࡂࡃ࠽࠾࠿ࠪ࡟"))
        dixie.log(l1l1lll_opy_)
        l111l_opy_ = mapping.cleanLabel(l1l1lll_opy_)
        l1lllll_opy_  = cleanPrefix(l111l_opy_)
        l1lllll_opy_  = l1lllll_opy_.upper()
        if l1lllll_opy_ == item.upper():
            dixie.log(l11ll_opy_ (u"ࠩࡀࡁࡂࡃ࠽࠾࡙ࠢࡅࡉࡋࡒࠡࡏࡄࡘࡈࡎࠠࡇࡑࡘࡒࡉࠦ࠽࠾࠿ࡀࡁࡂ࠭ࡠ"))
            dixie.log(item)
            dixie.log(l1lllll_opy_)
            return file[l11ll_opy_ (u"ࠪࡪ࡮ࡲࡥࠨࡡ")]
def sendJSON(query, addon):
    l1111ll_opy_     = l11ll_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࠥࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࡢ") % query
    l1111_opy_  = xbmc.executeJSONRPC(l1111ll_opy_)
    response = json.loads(l1111_opy_)
    result   = response[l11ll_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬࡣ")]
    return result[l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬࡤ")]
def l1ll1l11_opy_(addon):
    HOME  = dixie.PROFILE
    iPATH = os.path.join(HOME, l11ll_opy_ (u"ࠧࡪࡰ࡬ࠫࡥ"))
    if addon == l1_opy_:
         return os.path.join(iPATH, l11ll_opy_ (u"ࠨࡥࡤࡸࡨ࡮ࡵࡱࡈࡄࡆ࠳ࡰࡳࡰࡰࠪࡦ"))
    if (addon == l1l111l_opy_) or (addon == l11lll1_opy_):
         return os.path.join(iPATH, l11ll_opy_ (u"ࠩࡦࡥࡹࡩࡨࡶࡲࡉࡐࡆ࠴ࡪࡴࡱࡱࠫࡧ"))
    if addon == l11lllll_opy_:
        return os.path.join(iPATH, l11ll_opy_ (u"ࠪࡧࡦࡺࡣࡩࡷࡳࡅࡈࡋ࠮࡫ࡵࡲࡲࠬࡨ"))
    if (addon == l1lll1_opy_) or (addon == l1l111l1_opy_) or (addon == l111l1l_opy_):
        return os.path.join(iPATH, l11ll_opy_ (u"ࠫࡨࡧࡴࡤࡪࡸࡴࡗࡕࡏࡕ࠰࡭ࡷࡴࡴࠧࡩ"))
    if (addon == l1ll_opy_) or (addon == l1ll111l_opy_) or (addon == l1lll1l_opy_):
        return os.path.join(iPATH, l11ll_opy_ (u"ࠬࡩࡡࡵࡥ࡫ࡹࡵ࡜ࡁࡅࡇࡕ࠲࡯ࡹ࡯࡯ࠩࡪ"))
def l111_opy_(addon):
    dixie.log(l11ll_opy_ (u"࠭࠽࠾࠿ࡀࡁࡂࠦࡧࡦࡶࡆࡥࡹࡩࡨࡶࡲࡖࡩࡨࡺࡩࡰࡰࠣࡁࡂࡃ࠽࠾࠿ࠪ࡫"))
    dixie.log(addon)
    l1111l1_opy_ = [[l1_opy_, l11ll_opy_ (u"ࠧࡇࡃࡅࠤࡈࡇࡔࡄࡊࡘࡔࠬ࡬")], [l1l111l_opy_, l11ll_opy_ (u"ࠨࡈࡏࡅ࡜ࡒࡅࡔࡕࠣࡇࡆ࡚ࡃࡉࡗࡓࠫ࡭")], [l11lll1_opy_, l11ll_opy_ (u"ࠩࡋࡓࡗࡏ࡚ࡐࡐࠣࡇࡆ࡚ࡃࡉࡗࡓࠫ࡮")], [l11lllll_opy_, l11ll_opy_ (u"ࠪࡘ࡛ࠦࡃࡂࡖࡆࡌ࡛ࠥࡐࠨ࡯")], [l1lll1_opy_, l11ll_opy_ (u"ࠫࡈࡇࡔࡄࡊࡘࡔ࡚ࠥࡖࠨࡰ")], [l1l111l1_opy_, l11ll_opy_ (u"ࠬࡉࡁࡕࡅࡋ࡙ࡕࠦࡔࡗࠩࡱ")], [l1ll_opy_, l11ll_opy_ (u"࠭ࡔࡗࠢࡆࡅ࡙ࡉࡈࡖࡒࠪࡲ")], [l1ll111l_opy_, l11ll_opy_ (u"ࠧࡕࡘࠣࡇࡆ࡚ࡃࡉࡗࡓࠫࡳ")], [l1lll1l_opy_, l11ll_opy_ (u"ࠨࡖ࡙ࠤࡈࡇࡔࡄࡊࡘࡔࠬࡴ")], [l111l1l_opy_, l11ll_opy_ (u"ࠩࡆࡅ࡙ࡉࡈࡖࡒࠣࡘ࡛࠭ࡵ")]]
    for l1111l_opy_ in l1111l1_opy_:
        if addon == l1111l_opy_[0]:
            dixie.log(l11ll_opy_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࠣࡷࡪࡩࡴࡪࡱࡱࠤ࡫ࡵࡵ࡯ࡦࠣࡁࡂࡃ࠽࠾࠿ࠪࡶ"))
            dixie.log(l1111l_opy_[1])
            return l1111l_opy_[1]
def findCatchup(string, addon, query, item, splitlabel=False):
    dixie.log(l11ll_opy_ (u"ࠫࡂࡃ࠽࠾࠿ࡀࠤࡋࡏࡎࡅࠢࡆࡅ࡙ࡉࡈࡖࡒࠣࡍ࡙ࡋࡍࠡ࠿ࡀࡁࡂࡃ࠽ࠨࡷ"))
    dixie.log(string)
    response = doJSON(query)
    l111111_opy_    = response[l11ll_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬࡸ")][l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬࡹ")]
    dixie.log(l111111_opy_)
    for file in l111111_opy_:
        l1l1lll_opy_ = file[l11ll_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ࡺ")]
        dixie.log(l11ll_opy_ (u"ࠨ࠿ࡀࡁࡂࡃ࠽ࠡࡔࡄ࡛ࠥࡒࡁࡃࡇࡏࠤࡂࡃ࠽࠾࠿ࡀࠫࡻ"))
        dixie.log(l1l1lll_opy_)
        l111l_opy_   = mapping.cleanLabel(l1l1lll_opy_)
        l1lllll_opy_    = cleanPrefix(l111l_opy_)
        if splitlabel:
            l1lllll_opy_ = l1l1l111_opy_(addon, l1lllll_opy_)
        else:
            l1lllll_opy_ = l1lllll_opy_.upper()
        dixie.log(l11ll_opy_ (u"ࠩࡀࡁࡂࡃ࠽࠾ࠢࡉࡍࡓࡊࠠࡄࡃࡗࡇࡍ࡛ࡐࠡ࠿ࡀࡁࡂࡃ࠽ࠨࡼ"))
        dixie.log(item)
        dixie.log(l1lllll_opy_)
        if l1lllll_opy_ == item.upper():
            dixie.log(l11ll_opy_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࠣࡑࡆ࡚ࡃࡉࠢࡉࡓ࡚ࡔࡄࠡ࠿ࡀࡁࡂࡃ࠽ࠨࡽ"))
            dixie.log(item)
            dixie.log(l1lllll_opy_)
            return file[l11ll_opy_ (u"ࠫ࡫࡯࡬ࡦࠩࡾ")]
def l1l1l111_opy_(addon, l1lllll_opy_):
    l1lllll_opy_ = l1lllll_opy_.upper()
    if addon == l11lllll_opy_:
        return l1lllll_opy_.rsplit(l11ll_opy_ (u"ࠬࠏࠧࡿ"), 1)[0]
    return l1lllll_opy_.rsplit(l11ll_opy_ (u"࠭ࠠ࠮ࠢࠪࢀ"), 1)[0]
def l1l1ll_opy_(addon, theDate, theTime):
    if addon == l11lllll_opy_:
        return theDate + l11ll_opy_ (u"ࠧࠊࠩࢁ") + theTime
    return theDate + l11ll_opy_ (u"ࠨࠢ࠰ࠤࠬࢂ") + theTime
def doJSON(query):
    l1l1l11_opy_  = (l11ll_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬࢃ") % query)
    response = xbmc.executeJSONRPC(l1l1l11_opy_)
    content  = json.loads(response)
    return content
def cleanPrefix(text):
    l1l1111_opy_ = text.strip()
    l1ll1_opy_  = [l11ll_opy_ (u"࡙ࠪࡐࡀࠧࢄ"), l11ll_opy_ (u"ࠫࡎࡔࡔ࠻ࠢࠪࢅ"), l11ll_opy_ (u"ࠬࡒࡉࡗࡇࠣࠫࢆ"), l11ll_opy_ (u"࠭ࡕࡌࠢ࡯ࠤࠬࢇ"),l11ll_opy_ (u"ࠧࡊࡐ࠽ࠤࠬ࢈"), l11ll_opy_ (u"ࠨࡋࡑࠤࡱࠦࠧࢉ"), l11ll_opy_ (u"ࠩࡌࡒࠥࢂࠠࠨࢊ"), l11ll_opy_ (u"ࠪࡈࡊࠦ࡬ࠡࠩࢋ"), l11ll_opy_ (u"ࠫࡗࡇࡄࠡ࡮ࠣࠫࢌ"), l11ll_opy_ (u"ࠬ࡜ࡉࡑࠢ࡯ࠤࠬࢍ"), l11ll_opy_ (u"࠭ࠠࡍࡱࡦࡥࡱ࠭ࢎ"), l11ll_opy_ (u"ࠧࡖࡕࡄ࠳ࡈࡇࠠ࠻ࠢࠪ࢏"), l11ll_opy_ (u"ࠨࡗࡖࡅ࠴ࡉࡁ࠻ࠢࠪ࢐"), l11ll_opy_ (u"ࠩࡆࡅ࠿ࠦࠧ࢑"),l11ll_opy_ (u"ࠪࡇࡆࠦ࠺ࠡࠩ࢒"),l11ll_opy_ (u"ࠫࡈࡇࠠࠨ࢓"),l11ll_opy_ (u"࡛ࠬࡋࠡࡘࡌࡔࠥࡀࠠࠨ࢔"), l11ll_opy_ (u"࠭ࡕࡌࠢ࠽ࠤࠬ࢕"), l11ll_opy_ (u"ࠧࡖࡍ࠽ࠤࠬ࢖"), l11ll_opy_ (u"ࠨࡗࡎࠤࢁࠦࠧࢗ"), l11ll_opy_ (u"ࠩࡘࡗࡆࠦ࠺ࠡࡎࡌ࡚ࡊࠦࠧ࢘"), l11ll_opy_ (u"࡙ࠪࡘࡇࠠࡽࠢࡏࡍ࡛ࡋࠠࠨ࢙"), l11ll_opy_ (u"࡚࡙ࠫࡁࠡ࠼࢚ࠣࠫ"), l11ll_opy_ (u"࡛ࠬࡓࡂࠢ࠽࢛ࠫ"), l11ll_opy_ (u"࠭ࡕࡔࡃ࠽ࠤࠬ࢜"), l11ll_opy_ (u"ࠧࡖࡕࡄࠤࢁࠦࠧ࢝"), l11ll_opy_ (u"ࠨࡗࡖࡅࠥ࠭࢞"), l11ll_opy_ (u"ࠩࡘࡗࠥࢂࠠࠨ࢟"),l11ll_opy_ (u"࡙ࠪࡘࡀࠠࠨࢠ"), l11ll_opy_ (u"ࠫࡓࡕࡒࡅࡋࡆࠤࠬࢡ")]
    for prefix in l1ll1_opy_:
        if prefix in l1l1111_opy_:
            l1l1111_opy_ = l1l1111_opy_.replace(prefix, l11ll_opy_ (u"ࠬ࠭ࢢ"))
    return l1l1111_opy_.strip()
def l11lll_opy_(addon, name, title, start, stream):
    import time
    dixie.log(l11ll_opy_ (u"࠭࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࠢࡆࡅ࡙ࡉࡈࠡࡗࡓࠤࡑ࡞ࡔࡗࠢࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤ࠭ࢣ"))
    l1l111ll_opy_ = stream.split(l11ll_opy_ (u"ࠧࡽࠩࢤ"))
    for url in l1l111ll_opy_:
        if (l1ll1ll_opy_ in url) or (l11llll1_opy_ in url):
            dixie.log(l11ll_opy_ (u"ࠨࡎ࡛ࡘ࡛ࠦࡕࡓࡎ࠱࠲࠳ࡀࠠࠦࡵࠪࢥ") % url)
            l1llll1_opy_ = url.split(CLOSE_OTT)[0].replace(OPEN_OTT, l11ll_opy_ (u"ࠩࠪࢦ"))
            break
    import urllib
    l1ll111_opy_ = l1lllll1_opy_()
    dixie.log(l11ll_opy_ (u"ࠪࡉࡕࡍࠠࡔࡶࡤࡶࡹࠦࡔࡪ࡯ࡨ࠲࠳࠴࠺ࠡࠧࡶࠫࢧ") % start)
    dixie.log(l11ll_opy_ (u"ࠫࡔ࡬ࡦࡴࡧࡷࠤ࡮ࡴࠠࡴࡧࡦࡳࡳࡪࡳ࠻ࠢࠨࡷࠬࢨ") % l1ll111_opy_)
    l1l1l1_opy_  =  start - datetime.timedelta(seconds=l1ll111_opy_)
    dixie.log(l11ll_opy_ (u"࡙ࠬࡴࡢࡴࡷࠤ࡙࡯࡭ࡦࠢࡲࡪ࡫ࡹࡥࡵ࠼ࠣࠩࡸ࠭ࢩ") % l1l1l1_opy_)
    l11l1l1_opy_     = l111ll_opy_(l1llll1_opy_)
    l11l_opy_ = str(l1l1l1_opy_)
    l1l11l1_opy_   = l11l_opy_.split(l11ll_opy_ (u"࠭ࠠࠨࢪ"))[0]
    l1l1lll1_opy_  = l11l_opy_.split(l11ll_opy_ (u"ࠧࠡࠩࢫ"))[1]
    l11l1_opy_  = time.strptime(l1l1lll1_opy_,  l11ll_opy_ (u"ࠨࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠪࢬ"))
    l11l1_opy_  = time.strftime(l11ll_opy_ (u"ࠩࠨࡍ࠿ࠫࡍࠡࠧࡳࠫࢭ"),  l11l1_opy_)
    l1ll1lll_opy_ = time.strptime(l1l11l1_opy_,   l11ll_opy_ (u"ࠪࠩ࡞࠳ࠥ࡮࠯ࠨࡨࠬࢮ"))
    l1ll1lll_opy_ = time.strftime(l11ll_opy_ (u"ࠫࠪࡇࠬࠡࠧࡅࠤࠪࡪࠧࢯ"), l1ll1lll_opy_)
    query = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠦࡵ࠲ࡃࡨ࡮ࡡ࡯ࡰࡨࡰࡤ࡯ࡤ࠾ࠧࡶࠪࡩࡧࡴࡦ࠿ࠨࡷࠫࡪࡡࡵࡧࡢࡸ࡮ࡺ࡬ࡦ࠿ࠨࡷࠫ࡯࡭ࡨ࠿ࠩࡱࡴࡪࡥ࠾ࡴࡨࡧࡴࡸࡤࡪࡰࡪࡷࠫࡺࡩࡵ࡮ࡨࡁࠪࡹࠧࢰ") % (addon, l11l1l1_opy_, l1l11l1_opy_, l1ll1lll_opy_, l1llll1_opy_)
    l1111ll_opy_  = l11ll_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࠧࡶࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩࢱ") % query
    if not l11l1l1_opy_:
        dixie.DialogOK(l11ll_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠴ࠧࢲ"), l11ll_opy_ (u"ࠨ࡙ࡨࠤࡨࡵࡵ࡭ࡦࠣࡲࡴࡺࠠࡧ࡫ࡱࡨࠥࡧࠠࡤࡣࡷࡧ࡭ࡻࡰࠡࡵࡨࡶࡻ࡯ࡣࡦࠢࡩࡳࡷࠦࡴࡩ࡫ࡶࠤࡨ࡮ࡡ࡯ࡰࡨࡰ࠳࠭ࢳ"), l11ll_opy_ (u"ࠩࡕࡩࡻ࡫ࡲࡵ࡫ࡱ࡫ࠥࡨࡡࡤ࡭ࠣࡸࡴࠦࡌࡪࡸࡨࠤ࡙࡜࠮ࠨࢴ"))
        return None
    l1111_opy_    = xbmc.executeJSONRPC(l1111ll_opy_)
    response   = json.loads(l1111_opy_)
    result     = response[l11ll_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪࢵ")]
    l1ll11l_opy_ = result[l11ll_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪࢶ")]
    for l1ll1l1l_opy_ in l1ll11l_opy_:
        try:
            l1l11_opy_ = l1ll1l1l_opy_[l11ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪࢷ")]
            l1lllll_opy_   = l1ll1l1l_opy_[l11ll_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬࢸ")]
            if l11l1_opy_ in l1lllll_opy_:
                dixie.DialogOK(l11ll_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡰࡴࡤࡲ࡬࡫࡝ࡄࡣࡷࡧ࡭࠳ࡵࡱࠢࡶࡸࡷ࡫ࡡ࡮ࠢࡩࡳࡺࡴࡤ࠯࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢹ"), l11ll_opy_ (u"ࠨࡑࡱ࠱࡙ࡧࡰࡱ࠰ࡗ࡚ࠥࡽࡩ࡭࡮ࠣࡲࡴࡽࠠࡱ࡮ࡤࡽ࠿࡛ࠦࡄࡑࡏࡓࡗࠦ࡯ࡳࡣࡱ࡫ࡪࡣ࡛ࡃ࡟ࠨࡷࡠ࠵ࡂ࡞࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢺ") % (title))
                return l1l11_opy_
        except Exception, e:
            dixie.log(l11ll_opy_ (u"ࠩࡈࡖࡗࡕࡒ࠻ࠢࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥࡺࡨࡳࡱࡺࡲࠥ࡯࡮ࠡࡩࡨࡸࡑ࡞ࡔࡗࡔࡨࡧࡴࡸࡤࡪࡰࡪࠤࠪࡹࠧࢻ") % str(e))
            dixie.DialogOK(l11ll_opy_ (u"ࠪࡗࡴࡸࡲࡺ࠰ࠪࢼ"), l11ll_opy_ (u"ࠫ࡜࡫ࠠࡤࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡪ࡮ࡴࡤࠡࡣࠣࡧࡦࡺࡣࡩࡷࡳࠤࡸࡺࡲࡦࡣࡰࠤ࡫ࡵࡲࠡࡶ࡫࡭ࡸࠦࡰࡳࡱࡪࡶࡦࡳ࠮ࠨࢽ"), l11ll_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡺࡲࡺࠢࡤ࡫ࡦ࡯࡮ࠡ࡮ࡤࡸࡪࡸ࠮ࠨࢾ"))
            return None
def l111ll_opy_(l1llll1_opy_):
    l1llll1_opy_ = l1llll1_opy_.upper()
    if l1llll1_opy_ == l11ll_opy_ (u"࠭࠳ࡆࠩࢿ") : return 188
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡂࡄࡆࠤࡊࡇࡓࡕࠩࣀ") : return 363
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡃࡅࡇࠬࣁ") : return 346
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡄࡑࡈ࠭ࣂ") : return 375
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡅࡑࡏࡂࡊࠢࡌࡖࡊࡒࡁࡏࡆࠪࣃ") : return 280
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡆࡔࡉࡎࡃࡏࠤࡕࡒࡁࡏࡇࡗࠤ࡚࡙ࡁࠨࣄ") : return 386
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡇࡎࡊࡏࡄࡐࠥࡖࡌࡂࡐࡈࡘࠬࣅ") : return 19
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡁࡓࡇࡑࡅ࡙ࠥࡐࡐࡔࡗࡗࠥ࠷ࠠࡉࡆࠣࡇࡗࡕࡁࡕࡋࡄࠫࣆ") : return 403
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡂࡔࡈࡒࡆࠦࡓࡑࡑࡕࡘࡘࠦ࠲ࠡࡊࡇࠤࡈࡘࡏࡂࡖࡌࡅࠬࣇ") : return 404
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡃࡕࡉࡓࡇࠠࡔࡒࡒࡖ࡙࡙ࠠ࠴ࠢࡋࡈࠥࡉࡒࡐࡃࡗࡍࡆ࠭ࣈ") : return 405
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡄࡖࡊࡔࡁࠡࡕࡓࡓࡗ࡚ࡓࠡ࠶ࠣࡌࡉࠦࡃࡓࡑࡄࡘࡎࡇࠧࣉ") : return 406
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡅࡗࡋࡎࡂࠢࡖࡔࡔࡘࡔࡔࠢ࠸ࠤࡘࡘࡂࠨ࣊") : return 407
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡆ࡚ࠠࡕࡊࡈࠤࡗࡇࡃࡆࡕࠪ࣋") : return 273
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡈࡂࡄࠢࡒࡒࡊࡡࡈࡅ࡟ࠪ࣌") : return 210
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡂࡃࡅࠣࡘ࡜ࡕ࡛ࡉࡆࡠࠫ࣍") : return 211
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡃࡇࡌࡒ࡙ࠥࡐࡐࡔࡗࠤ࠶࠶ࠠࡉࡆࠫࡘࡊ࡙ࡔࠪࠩ࣎") : return 300
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡄࡈࡍࡓࠦࡓࡑࡑࡕࡘࠥ࠷࠱ࠡࡊࡇ࡙ࠬࡋࡓࡕ࣏ࠫࠪ") : return 389
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡅࡉࡎࡔࠠࡔࡒࡒࡖ࡙ࠦ࠱ࡉࡆࠫࡘࡊ࡙ࡔ࣐ࠪࠩ") : return 285
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡆࡊࡏࡎࠡࡕࡓࡓࡗ࡚ࠠ࠳ࠢࡋࡈ࡚࠭ࡅࡔࡖ࣑ࠬࠫ") : return 286
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡇࡋࡉࡏࠢࡖࡔࡔࡘࡔࠡ࠵ࠣࡌࡉ࠮ࡔࡆࡕࡗ࣒࠭ࠬ") : return 287
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡈࡅࡊࡐࠣࡗࡕࡕࡒࡕࠢ࠷ࠤࡍࡊࠨࡕࡇࡖࡘ࠮࣓࠭") : return 288
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡂࡆࡋࡑࠤࡘࡖࡏࡓࡖࠣ࠹ࠥࡎࡄࠩࡖࡈࡗ࡙࠯ࠧࣔ") : return 289
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡃࡇࡌࡒ࡙ࠥࡐࡐࡔࡗࠤ࠻ࠦࡈࡅࠪࡗࡉࡘ࡚ࠩࠨࣕ") : return 290
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡄࡈࡍࡓࠦࡓࡑࡑࡕࡘࠥ࠽ࠠࡉࡆࠫࡘࡊ࡙ࡔࠪࠩࣖ") : return 291
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡅࡉࡎࡔࠠࡔࡒࡒࡖ࡙ࠦ࠸ࠡࡊࡇ࡙ࠬࡋࡓࡕࠫࠪࣗ") : return 292
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡆࡊࡏࡎࠡࡕࡓࡓࡗ࡚ࠠ࠺ࠢࡋࡈ࡚࠭ࡅࡔࡖࠬࠫࣘ") : return 293
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡇ࡚ࠠࡔࡒࡒࡖ࡙ࠦ࠱ࠡࡊࡇࠤ࡚࠭ࡅࡔࡖࠬࠫࣙ") : return 306
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡈࡔࠡࡕࡓࡓࡗ࡚ࠠ࠲ࠩࣚ") : return 17
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡂࡕࠢࡖࡔࡔࡘࡔࠡ࠴ࠣࡌࡉࠦࠨࡕࡇࡖࡘ࠮࠭ࣛ") : return 307
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡃࡖࠣࡗࡕࡕࡒࡕࠢ࠵ࠫࣜ") : return 18
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡄࡗࠤࡘࡖࡏࡓࡖࠣࡉࡘࡖࡎࠨࣝ") : return 24
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡅࡘ࡙ࠥࡐࡐࡔࡗࠤࡊ࡛ࡒࡐࡒࡈࠫࣞ") : return 216
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡆࡆࡈ࡙ࠡࡖ࡙ࠫࣟ") : return 299
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡇࡒࡕࡆࠢࡋ࡙ࡘ࡚ࡌࡆࡔࠣࡉ࡚ࡘࡏࡑࡇࠪ࣠") : return 241
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡈࡏࡐࡏࡈࡖࡆࡔࡇࠨ࣡") : return 192
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡂࡐ࡚ࠣࡒࡆ࡚ࡉࡐࡐࠪ࣢") : return 185
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡃࡔࡌࡘࡎ࡙ࡈࠡࡇࡘࡖࡔ࡙ࡐࡐࡔࡗ࠶ࣣࠬ") : return 173
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡄࡕࡍ࡙ࡏࡓࡉࠢࡈ࡙ࡗࡕࡓࡑࡑࡕࡘࠬࣤ") : return 182
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡆࡆࡘࠦࡒࡆࡃࡏࡍ࡙࡟ࠧࣥ") : return 190
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡇࡓࡈࡃࠨࣦ") : return 366
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡈࡔࡎࠨࣧ") : return 365
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡉࡁࡓࡖࡒࡓࡓࠦࡎࡆࡖ࡚ࡓࡗࡑࠠࡖࡍࠪࣨ") : return 186
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡃࡂࡔࡗࡓࡔࡔࡉࡕࡑࣩࠪ") : return 250
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡄࡊࡈࡐࡘࡋࡁࠡࡖ࡙ࠫ࣪") : return 179
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡅࡒࡑࡊࡊ࡙ࠡࡅࡈࡒ࡙ࡘࡁࡍࠢࡘࡗࡆ࠭࣫") : return 374
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡆࡓࡒࡋࡄ࡚ࠢࡆࡉࡓ࡚ࡒࡂࡎࠪ࣬") : return 251
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡇࡔࡓࡅࡅ࡛ࠣ࡜࡙ࡘࡁࠨ࣭") : return 176
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡈࡘࡉࡎࡇࠣࡍࡓ࡜ࡅࡔࡖࡌࡋࡆ࡚ࡉࡐࡐ࣮ࠪ") : return 249
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡊࡁࡗࡇ࣯ࠪ") : return 230
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡄࡊࡕࡆࡓ࡛ࡋࡒ࡚ࠢࡋࡍࡘ࡚ࡏࡓࣰ࡛ࠪ") : return 20
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡅࡋࡖࡇࡔ࡜ࡅࡓ࡛ࠣࡗࡈࡏࡅࡏࡅࡈࣱࠫ") : return 103
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡆࡌࡗࡈࡕࡖࡆࡔ࡜ࠤ࡙࡛ࡒࡃࡑࣲࠪ") : return 102
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡇࡍࡘࡉࡏࡗࡇࡕ࡝࠶࠭ࣳ") : return 98
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡈࡎ࡙ࡃࡐࡘࡈࡖ࡞࠭ࣴ") : return 370
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡉࡏࡓࡏࡇ࡜ࡇࡍࡔࡌࠨࣵ") : return 117
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡊࡉࡔࡐࡈ࡝ࡏ࡛ࡎࡊࡑࡕࣶࠫ") : return 118
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡅࡔࡒࡑࠤ࠷࠭ࣷ") : return 349
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡆࡕࡓࡒࠬࣸ") : return 348
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡇࡇࡉࡓࠦࠫ࠲ࣹࠩ") : return 278
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡈࡍࡗࠦࡓࡑࡑࡕࡘࡘࣺ࠭") : return 30
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡉ࡚ࡘࡏࡏࡇ࡚ࡗࠬࣻ") : return 398
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡋࡕࡘࠡࡕࡓࡓࡗ࡚ࡓࠡ࠳ࠪࣼ") : return 352
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡌࡏ࡙ࠢࡑࡉ࡜࡙ࠧࣽ") : return 274
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡇࡐࡎࡇࠤ࡚ࡑࠧࣾ") : return 277
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡉ࠴࡙ࠣࡐ࠭ࣿ") : return 271
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡊࡅࡓࠥࡋࡁࡔࡖࠪऀ") : return 376
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡋࡆࡔࠦࡆࡂࡏࡌࡐ࡞࠭ँ") : return 377
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡌࡇࡕࠠࡔࡋࡊࡒࡆ࡚ࡕࡓࡇࠪं") : return 378
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡍࡈࡏࠡ࡜ࡒࡒࡊ࠭ः") : return 379
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡎࡇࡕࡘࠪऄ") : return 384
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡈࡊࡕࡗࡓࡗ࡟ࠠࡖࡍࠪअ") : return 268
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡉࡋࡖࡘࡔࡘ࡙ࠡࡗࡖࡅࠬआ") : return 369
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡊࡒࡑࡊࠦࠫ࠲ࠩइ") : return 279
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡋࡓࡗࡘࡏࡓࠢࡆࡌࡆࡔࡎࡆࡎ࡙ࠣࡐ࠭ई") : return 183
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡍࡉࠦࡕࡌࠩउ") : return 229
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡎ࡚ࡖࠡ࠴ࠪऊ") : return 208
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡏࡔࡗࠢ࠶ࠫऋ") : return 207
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡉࡕࡘࠣ࠸ࠬऌ") : return 209
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡊࡖ࡙ࠫऍ") : return 206
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡎࡉࡇ࡚ࠥࡖࠨऎ") : return 180
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡐࡍࡔࠦࡓࡕࡃࡇࡍ࡚ࡓࠠ࠲࠲࠵ࠤࡍࡊࠧए") : return 334
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡑࡎࡕࠠࡔࡖࡄࡈࡎ࡛ࡍࠡ࠳࠳࠷ࠥࡎࡄࠨऐ") : return 335
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡒࡏࡏࠡࡕࡗࡅࡉࡏࡕࡎࠢ࠴࠴࠹ࠦࡈࡅࠩऑ") : return 336
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡓࡉࡐࠢࡖࡘࡆࡊࡉࡖࡏࠣ࠵࠵࠻ࠠࡉࡆࠪऒ") : return 337
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡍࡊࡑࠣࡗ࡙ࡇࡄࡊࡗࡐࠤ࠶࠶࠶ࠡࡊࡇࠫओ") : return 338
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡎࡋࡒࠤࡘ࡚ࡁࡅࡋࡘࡑࠥ࠷࠰࠸ࠢࡋࡈࠬऔ") : return 333
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡏࡗ࡚ࠥࡈࡁࡔࡇࠪक") : return 132
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡐࡘ࡛ࠦࡄࡂࡐࡆࡉࠬख") : return 131
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡑ࡙࡜ࠠࡉࡋࡗࡗࠦ࠭ग") : return 135
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡒ࡚ࡖࠡࡏࡘࡗࡎࡉࠧघ") : return 217
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡓࡔࡗࠢࡕࡓࡈࡑࡓࠨङ") : return 133
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡍࡖࡖ࡙ࠫच") : return 106
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡎࡑࡗࡓࡗ࡙ࠠࡖࡍࠪछ") : return 215
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡐࡅࡅࠬज") : return 283
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡑࡆࡈࠦࡅࡂࡕࡗࠫझ") : return 361
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡒࡎࡉࡋࠡࡖࡒࡓࡓ࡙ࠧञ") : return 296
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡓࡇࡔࠡࡉࡈࡓࠥ࡝ࡉࡍࡆ࡙ࠣࡐ࠭ट") : return 269
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡔࡁࡕࡋࡒࡒࡆࡒࠠࡈࡇࡒࡋࡗࡇࡐࡉࡋࡆࠤ࡚ࡑࠧठ") : return 270
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡎࡂࡖࡌࡓࡓࡇࡌࠡࡉࡈࡓࡌࡘࡁࡑࡊࡌࡇ࡛ࠥࡓࡂࠩड") : return 371
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡏࡋࡆࡏࠥࡐࡕࡏࡋࡒࡖࠬढ") : return 297
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡐࡌࡇࡐࠦࡕࡌࠩण") : return 295
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡓࡖࡊࡓࡉࡆࡔࡖࡔࡔࡘࡔࡔࠩत") : return 29
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡖ࡙ࡋࠠࡐࡐࡈࠫथ") : return 69
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡗ࡚ࡅࠡࡖ࡚ࡓࡠࡎࡄ࡞ࠩद") : return 70
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡘࡔࡆࡌࡕࠫध") : return 89
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡒࡂࡅࡌࡒࡌࠦࡕࡌࠩन") : return 26
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡓࡇࡄࡐࠥࡒࡉࡗࡇࡖࠫऩ") : return 275
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡕࡎ࡝ࠥࡈࡕࡏࡆࡈࡗࡑࡏࡇࡂࠢ࠴ࠤࡍࡊ࡛ࡅࡇࡠࠫप") : return 408
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡖࡏ࡞ࠦࡎࡆ࡙ࡖࠫफ") : return 263
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡗࡐ࡟ࠠ࠲ࠩब") : return 177
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡘࡑ࡙ࠡ࠴ࠪभ") : return 178
    if l1llll1_opy_ == l11ll_opy_ (u"࡙ࠬࡋ࡚ࠢࡄࡇ࡙ࡏࡏࡏࠢࡐࡓ࡛ࡏࡅࡔࠩम") : return 16
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡓࡌ࡛ࠣࡅ࡙ࡒࡁࡏࡖࡌࡇࠬय") : return 174
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡔࡍ࡜ࠤࡈࡕࡍࡆࡆ࡜ࠤࡒࡕࡖࡊࡇࡖࠫर") : return 34
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡕࡎ࡝ࠥࡊࡒࡂࡏࡄࡖࡔࡓࠠࡎࡑ࡙ࡍࡊ࡙ࠧऱ") : return 97
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡖࡏ࡞ࠦࡆࡂࡏࡌࡐ࡞ࠦࡍࡐࡘࡌࡉࡘ࠭ल") : return 36
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡗࡐ࡟ࠠࡈࡔࡈࡅ࡙࡙ࠠࡎࡑ࡙ࡍࡊ࡙ࠧळ") : return 37
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡘࡑ࡙ࠡࡏࡒ࡚ࡎࡋࡓࠡࡆࡌࡗࡓࡋ࡙ࠨऴ") : return 220
    if l1llll1_opy_ == l11ll_opy_ (u"࡙ࠬࡋ࡚ࠢࡓࡖࡊࡓࡉࡆࡔࡈࠤࡒࡕࡖࡊࡇࡖࠫव") : return 40
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡓࡌ࡛ࠣࡗࡈࡌࡉࡉࡑࡕࡖࡔࡘࠠࡎࡑ࡙ࡍࡊ࡙ࠧश") : return 41
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡔࡍ࡜ࠤࡘࡋࡌࡆࡅࡗࠤࡒࡕࡖࡊࡇࡖࠫष") : return 42
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡕࡎ࡝࡙ࠥࡐࠡࡐࡈ࡛ࡘࠦࡈࡒࠩस") : return 175
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡖࡏ࡞ࠦࡓࡑࡑࡕࡘࠥ࠷ࠠࡉࡆ࡙ࠣࠬࡋࡓࡕࠫࠪह") : return 301
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡗࡐ࡟ࠠࡔࡒࡒࡖ࡙ࠦ࠲ࠡࡊࡇࠤ࡚࠭ࡅࡔࡖࠬࠫऺ") : return 302
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡘࡑ࡙ࠡࡕࡓࡓࡗ࡚ࠠ࠴ࠢࡋࡈࠥ࠮ࡔࡆࡕࡗ࠭ࠬऻ") : return 303
    if l1llll1_opy_ == l11ll_opy_ (u"࡙ࠬࡋ࡚ࠢࡖࡔࡔࡘࡔࠡ࠶ࠣࡌࡉࠦࠨࡕࡇࡖࡘ࠮़࠭") : return 304
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡓࡌ࡛ࠣࡗࡕࡕࡒࡕࠢ࠸ࠤࡍࡊࠠࠩࡖࡈࡗ࡙࠯ࠧऽ") : return 305
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡔࡍ࡜ࠤࡘࡖࡏࡓࡖࡖࠤ࠶࠭ा") : return 95
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡕࡎ࡝࡙ࠥࡐࡐࡔࡗࡗࠥ࠸ࠧि") : return 136
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡖࡏ࡞ࠦࡓࡑࡑࡕࡘࡘࠦ࠳ࠨी") : return 43
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡗࡐ࡟ࠠࡔࡒࡒࡖ࡙࡙ࠠ࠵ࠩु") : return 119
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡘࡑ࡙ࠡࡕࡓࡓࡗ࡚ࡓࠡ࠷ࠪू") : return 120
    if l1llll1_opy_ == l11ll_opy_ (u"࡙ࠬࡋ࡚ࠢࡗࡌࡗࡏࡌࡍࡇࡕࠤࡒࡕࡖࡊࡇࡖࠫृ") : return 96
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡓࡌ࡛ࠣࡐࡎ࡜ࡉࡏࡉࠪॄ") : return 298
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡔࡒࡒࡖ࡙࡙ࠠࡇ࠳ࠪॅ") : return 45
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡕ࡜ࡊ࡞ࠦࡕࡔࡃࠪॆ") : return 383
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡗࡇࡒࠦࠫ࠲ࠢࡘࡏࠬे") : return 189
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡘࡌ࠺ࠧै") : return 88
    if l1llll1_opy_ == l11ll_opy_ (u"࡙࡙ࠫࡎࠡ࠳ࠪॉ") : return 339
    if l1llll1_opy_ == l11ll_opy_ (u"࡚ࠬࡓࡏࠢ࠵ࠫॊ") : return 340
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡔࡔࡐࠣ࠷ࠬो") : return 341
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡕࡕࡑࠤ࠹࠭ौ") : return 342
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡖࡖࡒࠥ࠻्ࠧ") : return 343
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡗ࡚࠸ࠦࡉࡆࠩॎ") : return 87
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡘࡗࡇࡖࡆࡎࠣࡇࡍࡇࡎࡏࡇࡏ࠯࠶ࠦࡕࡌࠩॏ") : return 184
    if l1llll1_opy_ == l11ll_opy_ (u"࡚࡙ࠫࡁࠡࡈࡒ࡜࡙ࠥࡐࡐࡔࡗࡗࠬॐ") : return 347
    if l1llll1_opy_ == l11ll_opy_ (u"࡛ࠬࡓࡂࠢࡑࡉ࡙࡝ࡏࡓࡍࠪ॑") : return 344
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡕࡕࡘࠣࡍࡊ॒࠭") : return 272
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡗࡋ࡙ࡅ࡚ࠥࡈࡆࠢࡋࡍ࡙࡙ࠡࠨ॓") : return 130
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡘࡌࡅࡘࡇࡔࠡࡉࡒࡐࡋ࠭॔") : return 125
    if l1llll1_opy_ == l11ll_opy_ (u"࡚ࠩࡅ࡙ࡉࡈࠡࡋࡕࡉࡑࡇࡎࡅࠩॕ") : return 281
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪ࡜࡝࡞࠱ࠨॖ") : return 314
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫ࡝࡞ࡘ࠳ࠩॗ") : return 315
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬ࡞ࡘ࡙࠵ࠪक़") : return 316
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡘ࡙࡚࠷ࠫख़") : return 317
    if l1llll1_opy_ == l11ll_opy_ (u"࡙࡚࡛ࠧ࠹ࠬग़") : return 318
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨ࡛ࡈࡗ࡙ࡋࡒࡅࡃ࡜ࠤ࠰࠷ࠧज़") : return 282
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡐࡓ࡛࠺ࡍࡆࡐ࠴ࠫड़") : return 33
def getHDTVRecording(name, title, start, stream):
    l1l111ll_opy_ = stream.split(l11ll_opy_ (u"ࠪࢀࠬढ़"))
    for url in l1l111ll_opy_:
        url   = url.split(CLOSE_OTT)[1].rsplit(l11ll_opy_ (u"ࠫ࠿࠭फ़"))
        l1l111_opy_ = url[0]
        if l1l111_opy_ == l11ll_opy_ (u"ࠬࡎࡄࡕࡘࠪय़"):
            addon = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹ࡭ࡢࡴࡷ࡬ࡺࡨࠧॠ")
        else:
            addon = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࠶ࠬॡ")
    dixie.log(l11ll_opy_ (u"ࠨࡃࡧࡨࡴࡴࠠࡊࡆ࠱࠲࠳ࡀࠠࠦࡵࠪॢ") % addon)
    Addon  = xbmcaddon.Addon(id=addon)
    path   = Addon.getAddonInfo(l11ll_opy_ (u"ࠩࡳࡥࡹ࡮ࠧॣ"))
    import sys
    sys.path.insert(0, path)
    import api
    l1l1_opy_ = Addon.getSetting(l11ll_opy_ (u"ࠪࡷࡪࡹࡳࡪࡱࡱࠫ।"))
    l1ll11_opy_  = Addon.getSetting(l11ll_opy_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࠫ॥"))
    l1l1ll1_opy_    = l11ll_opy_ (u"ࠬࠬࡤ࠾࡭ࡲࡨ࡮ࠬࡳ࠾ࠩ०") + l1l1_opy_ + l11ll_opy_ (u"࠭ࠦࡰ࠿ࠪ१") + l1ll11_opy_
    import urllib
    l1ll111_opy_ = l1lllll1_opy_()
    dixie.log(l11ll_opy_ (u"ࠧࡆࡒࡊࠤࡘࡺࡡࡳࡶࠣࡘ࡮ࡳࡥ࠯࠰࠱࠾ࠥࠫࡳࠨ२") % start)
    dixie.log(l11ll_opy_ (u"ࠨࡑࡩࡪࡸ࡫ࡴࠡ࡫ࡱࠤࡸ࡫ࡣࡰࡰࡧࡷ࠿ࠦࠥࡴࠩ३") % l1ll111_opy_)
    l1l1l1_opy_  =  start - datetime.timedelta(seconds=l1ll111_opy_)
    dixie.log(l11ll_opy_ (u"ࠩࡖࡸࡦࡸࡴࠡࡖ࡬ࡱࡪࠦ࡯ࡧࡨࡶࡩࡹࡀࠠࠦࡵࠪ४") % l1l1l1_opy_)
    l11l_opy_ = str(l1l1l1_opy_)
    l11l1ll_opy_  = l11l_opy_.split(l11ll_opy_ (u"ࠪࠤࠬ५"))[0]
    l1lll11l_opy_     = l1lll1l1_opy_(name)
    if not l1lll11l_opy_:
        dixie.DialogOK(l11ll_opy_ (u"ࠫࡘࡵࡲࡳࡻ࠱ࠫ६"), l11ll_opy_ (u"ࠬ࡝ࡥࠡࡥࡲࡹࡱࡪࠠ࡯ࡱࡷࠤ࡫࡯࡮ࡥࠢࡤࠤࡨࡧࡴࡤࡪࡸࡴࠥࡹࡥࡳࡸ࡬ࡧࡪࠦࡦࡰࡴࠣࡸ࡭࡯ࡳࠡࡥ࡫ࡥࡳࡴࡥ࡭࠰ࠪ७"), l11ll_opy_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡴࡳࡻࠣࡥࡳࡵࡴࡩࡧࡵࠤࡨ࡮ࡡ࡯ࡰࡨࡰ࠳࠭८"))
        return None
    l1l11111_opy_  = l11l_opy_.split(l11ll_opy_ (u"ࠧ࠮ࠩ९"), 1)[-1].rsplit(l11ll_opy_ (u"ࠨ࠼ࠪ॰"), 1)[0]
    theTime    = urllib.quote_plus(l1l11111_opy_)
    response   = api.remote_call( l11ll_opy_ (u"ࠤࡷࡺࡦࡸࡣࡩ࡫ࡹࡩ࠴࡭ࡥࡵࡡࡥࡽࡤࡩࡨࡢࡰࡱࡩࡱࡥࡡ࡯ࡦࡢࡨࡦࡺࡥ࠯ࡲ࡫ࡴࠧॱ") , {l11ll_opy_ (u"ࠥࡨࡦࡺࡥࠣॲ"): l11l1ll_opy_, l11ll_opy_ (u"ࠦ࡮ࡪࠢॳ"): l1lll11l_opy_ } )
    l1ll11l_opy_ = response[l11ll_opy_ (u"ࠧࡨ࡯ࡥࡻࠥॴ")]
    if not l1ll11l_opy_:
        dixie.DialogOK(l11ll_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠳࠭ॵ"), l11ll_opy_ (u"ࠧࡘࡧࠣࡧࡴࡻ࡬ࡥࠢࡱࡳࡹࠦࡦࡪࡰࡧࠤࡦࠦࡣࡢࡶࡦ࡬ࡺࡶࠠࡴࡶࡵࡩࡦࡳࠠࡧࡱࡵࠤࡹ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯࠱ࠫॶ"), l11ll_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡶࡵࡽࠥࡧࡧࡢ࡫ࡱࠤࡱࡧࡴࡦࡴ࠱ࠫॷ"))
        return None
    for l1ll1l1l_opy_ in l1ll11l_opy_:
        l1l11_opy_ = l1ll1l1l_opy_[l11ll_opy_ (u"ࠤࡳࡰࡴࡺࠢॸ")]
        if l1l11111_opy_ in l1l11_opy_:
            dixie.DialogOK(l11ll_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡳࡷࡧ࡮ࡨࡧࡠࡇࡦࡺࡣࡩ࠯ࡸࡴࠥࡹࡴࡳࡧࡤࡱࠥ࡬࡯ࡶࡰࡧ࠲ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ॹ"), l11ll_opy_ (u"ࠫࡔࡴ࠭ࡕࡣࡳࡴ࠳࡚ࡖࠡࡹ࡬ࡰࡱࠦ࡮ࡰࡹࠣࡴࡱࡧࡹ࠻ࠢ࡞ࡇࡔࡒࡏࡓࠢࡲࡶࡦࡴࡧࡦ࡟࡞ࡆࡢࠫࡳ࡜࠱ࡅࡡࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ॺ") % (title))
            return l1ll1l1l_opy_[l11ll_opy_ (u"ࠧࡻࡲ࡭ࠤॻ")] + l1l1ll1_opy_
def l1lll1l1_opy_(name):
    l1l1l1ll_opy_   = dixie.PROFILE
    ll_opy_ = os.path.join(l1l1l1ll_opy_, l11ll_opy_ (u"࠭ࡩ࡯࡫ࠪॼ"), l11ll_opy_ (u"ࠧࡤࡣࡷࡧ࡭ࡻࡰ࠯ࡶࡻࡸࠬॽ"))
    l11l111_opy_   = json.load(open(ll_opy_))
    for channel in l11l111_opy_:
        if name.upper() == channel[l11ll_opy_ (u"ࠨࡑࡗࡘ࡛࠭ॾ")].upper():
            return channel[l11ll_opy_ (u"ࠩࡘࡖࡑ࠭ॿ")]
def l1lllll1_opy_():
    import time
    gmt = time.gmtime()
    loc = time.localtime()
    GMT = datetime.datetime(*gmt[:6]).isoformat(l11ll_opy_ (u"ࠪࠤࠬঀ"))
    LOC = datetime.datetime(*loc[:6]).isoformat(l11ll_opy_ (u"ࠫࠥ࠭ঁ"))
    dixie.log(gmt)
    dixie.log(loc)
    l11ll11_opy_ = dixie.parseTime(GMT)
    l111lll_opy_ = dixie.parseTime(LOC)
    dixie.log(l11ll11_opy_)
    dixie.log(l111lll_opy_)
    dixie.log(l11ll_opy_ (u"ࠬࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࠢࡒࡊࡋ࡙ࡅࡕࠢࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥࠧং"))
    l1ll111_opy_ = l11ll11_opy_ - l111lll_opy_
    dixie.log(l1ll111_opy_)
    l1ll111_opy_ = ((l1ll111_opy_.days * 86400) + (l1ll111_opy_.seconds + 1800)) / 3600
    dixie.log(l1ll111_opy_)
    l1ll111_opy_ *= -3600
    dixie.log(l1ll111_opy_)
    dixie.log(l11ll_opy_ (u"࠭࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࠨঃ"))
    return l1ll111_opy_