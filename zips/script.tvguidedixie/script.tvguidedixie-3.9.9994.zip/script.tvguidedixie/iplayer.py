# coding: UTF-8
import sys
l1l1l1ll_opy_ = sys.version_info [0] == 2
l111ll1_opy_ = 2048
l1l1ll1l_opy_ = 7
def l1l1l_opy_ (l1l111_opy_):
	global l11l111_opy_
	l111111_opy_ = ord (l1l111_opy_ [-1])
	l1l1lll1_opy_ = l1l111_opy_ [:-1]
	l1l1111_opy_ = l111111_opy_ % len (l1l1lll1_opy_)
	l11l11_opy_ = l1l1lll1_opy_ [:l1l1111_opy_] + l1l1lll1_opy_ [l1l1111_opy_:]
	if l1l1l1ll_opy_:
		l1111_opy_ = unicode () .join ([unichr (ord (char) - l111ll1_opy_ - (l1lll_opy_ + l111111_opy_) % l1l1ll1l_opy_) for l1lll_opy_, char in enumerate (l11l11_opy_)])
	else:
		l1111_opy_ = str () .join ([chr (ord (char) - l111ll1_opy_ - (l1lll_opy_ + l111111_opy_) % l1l1ll1l_opy_) for l1lll_opy_, char in enumerate (l11l11_opy_)])
	return eval (l1111_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
import mapping
ADDON    = dixie.ADDON
l1ll11l1_opy_ = dixie.PROFILE
l1111ll_opy_  = os.path.join(l1ll11l1_opy_, l1l1l_opy_ (u"ࠫ࡮ࡴࡩࠨࠀ"))
l1lllll_opy_    = os.path.join(l1111ll_opy_, l1l1l_opy_ (u"ࠬࡳࡡࡱࡲ࡬ࡲ࡬ࡹ࠮࡫ࡵࡲࡲࠬࠁ"))
l111ll_opy_   = os.path.join(l1111ll_opy_, l1l1l_opy_ (u"࠭࡭ࡢࡲࡶ࠲࡯ࡹ࡯࡯ࠩࠂ"))
LABELFILE  = os.path.join(l1111ll_opy_, l1l1l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱࡹ࠮࡫ࡵࡲࡲࠬࠃ"))
l1l11111_opy_ = os.path.join(l1111ll_opy_, l1l1l_opy_ (u"ࠨࡲࡵࡩ࡫࡯ࡸࡦࡵ࠱࡮ࡸࡵ࡮ࠨࠄ"))
l1ll1l1l_opy_  = json.load(open(l1lllll_opy_))
l1l1llll_opy_      = json.load(open(l111ll_opy_))
labelmaps = json.load(open(LABELFILE))
l111_opy_  = json.load(open(l1l11111_opy_))
l1l1ll1_opy_ = l1l1l_opy_ (u"ࠩࠪࠅ")
def l1l11l_opy_(i, t1, l1l1l1_opy_=[]):
 t = l1l1ll1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l1l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11_opy_ = l1l11l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11lll_opy_ = l1l11l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1l1lll_opy_       = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡧࡪࡺࡶࠨࠆ")
l1l1l111_opy_  = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡆࡱࡧࡣ࡬ࡋࡦࡩ࡙࡜ࠧࠇ")
dexter    = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸࠨࠈ")
l1ll1l_opy_   = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡋ࡮ࡥ࡮ࡨࡷࡸ࠭ࠉ")
l1lll1_opy_       = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡦࡢࡤ࡫ࡳࡸࡺࡩ࡯ࡩࠪࠊ")
l1ll1l11_opy_  = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡇ࡮ࡤࡻࡱ࡫ࡳࡴࡖࡹࠫࠋ")
l1l11l1l_opy_  = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡨࡵࡩࡪࡼࡩࡦࡹࠪࠌ")
l1ll11_opy_    = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡪࡩ࡭ࡵࡳࡵ࡫ࡱ࡫ࠬࠍ")
l1l111l_opy_   = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡬ࡴࡸࡩࡻࡱࡱ࡭ࡵࡺࡶࠨࠎ")
l1ll1_opy_  = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶࡴࡷࡵࡸࡦࡸ࠭ࠏ")
l11l1l1_opy_      = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡰࡩ࡯ࡺࡷࡺ࠷࠭ࠐ")
l1l11lll_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡌࡪ࡯࡬ࡸࡱ࡫ࡳࡴࡋࡓࡘ࡛࠭ࠑ")
l11l_opy_  = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡮ࡣࡷࡶ࡮ࡾࡩࡳࡧ࡯ࡥࡳࡪࠧࠒ")
l1lll1ll_opy_  = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡏࡤࡸࡸࡈࡵࡪ࡮ࡧࡷࡎࡖࡔࡗࠩࠓ")
l1l111ll_opy_   = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡰࡥࡽ࡯ࡷࡦࡤࡷࡺࠬࠔ")
l11l1ll_opy_     = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡱࡨࡱࡴࡷ࠯ࡳࡰࡺࡹࠧࠕ")
l11111l_opy_      = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡲ࡫ࡧࡢ࡫ࡳࡸࡻ࠭ࠖ")
nice      = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡴࡡࡵࡪࡲࡷࡺࡨࡳࡪࡥࡨࠫࠗ")
l11ll_opy_   = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡰࡳࡧࡰ࡭ࡺࡳࡩࡱࡶࡹࠫ࠘")
l1l11l11_opy_  = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡱࡵࡤࡨࡩࡵ࡮ࠨ࠙")
root      = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡲࡳࡹࡏࡐࡕࡘࠪࠚ")
l1ll1lll_opy_     = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡪ࡭ࡿࡳ࡯ࡵࡸࠪࠛ")
l1l1l1l_opy_    = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡫࡮ࢀ࡭ࡰࡵࡳࡳࡷࡺࡳࠨࠜ")
l1lll1l_opy_      = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡩࡴࡷࠩࠝ")
l1111l1_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡙ࡵࡱࡴࡨࡱࡦࡩࡹࡕࡘࠪࠞ")
l1llll11_opy_   = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡵࡴࡨࡥࡲࡹࡵࡱࡴࡨࡱࡪ࠸ࠧࠟ")
l11ll11_opy_   = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡵࡹ࡬ࡷࡹ࡫ࡤࠨࠠ")
l11ll1l_opy_   = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡶࡹ࡯࡮ࡴࡧࡴࠩࠡ")
l11lll1_opy_    = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸ࡯ࡹࡻࡲ࡬ࠩࠢ")
l1l_opy_     = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡚ࡆࡊࡅࡓࠩࠣ")
l1lll111_opy_   = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡺࡲࡦࡣࡰ࠱ࡨࡵࡤࡦࡵࠪࠤ")
l1lllll1_opy_    = [nice, l11ll_opy_, l1ll1lll_opy_, l1l1l1l_opy_, l1ll11_opy_, l11ll1l_opy_, l11l_opy_, l1lll111_opy_, l1lll1l_opy_, l1llll11_opy_, l11lll1_opy_, l1l11lll_opy_, l1lll1_opy_, l1l1lll_opy_, l1l111l_opy_, root, l11111l_opy_, l1l11l1l_opy_, l1ll1_opy_, l11l1l1_opy_, l1ll1l_opy_, l1ll1l11_opy_, l1l111ll_opy_, dexter, l1l_opy_, l1111l1_opy_, l11l1ll_opy_, l11ll11_opy_, l1l11l11_opy_, l1l1l111_opy_]
def checkAddons():
    for addon in l1lllll1_opy_:
        if l1l11l1_opy_(addon):
            try: createINI(addon)
            except: continue
def l1l11l1_opy_(addon):
    if xbmc.getCondVisibility(l1l1l_opy_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡈࡢࡵࡄࡨࡩࡵ࡮ࠩࠧࡶ࠭ࠬࠥ") % addon) == 1:
        dixie.log(l1l1l_opy_ (u"ࠧ࠾࠿ࡀࡁࠥࡧࡤࡥࡱࡱࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠ࠾࠿ࡀࡁࠬࠦ"))
        dixie.log(addon)
        return True
    return False
def createINI(addon):
    l11lllll_opy_  = str(addon).split(l1l1l_opy_ (u"ࠨ࠰ࠪࠧ"))[2] + l1l1l_opy_ (u"ࠩ࠱࡭ࡳ࡯ࠧࠨ")
    l1l1ll11_opy_   = os.path.join(l1111ll_opy_, l11lllll_opy_)
    response = l1llll1l_opy_(addon)
    l11llll_opy_ = response[l1l1l_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪࠩ")][l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪࠪ")]
    l1l1ll_opy_  = l1l1l_opy_ (u"ࠬࡡࠧࠫ") + addon + l1l1l_opy_ (u"࠭࡝࡝ࡰࠪࠬ")
    l1lll11l_opy_  =  file(l1l1ll11_opy_, l1l1l_opy_ (u"ࠧࡸࠩ࠭"))
    l1lll11l_opy_.write(l1l1ll_opy_)
    l1l1l11l_opy_ = []
    for channel in l11llll_opy_:
        l11111_opy_ = l1l1l11_opy_(addon)
        l11ll1_opy_  = channel[l1l1l_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧ࠮")].split(l1l1l_opy_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࠯"), 1)[0]
        if addon == dexter:
            l11ll1_opy_ = l11ll1_opy_.split(l1l1l_opy_ (u"ࠪࠤ࠰ࠦࠧ࠰"), 1)[0]
        if (addon == nice) or (addon == l1ll1lll_opy_) or (addon == l1l1l1l_opy_) or (addon == root) or (addon == l1l11lll_opy_) or (addon == l11ll1l_opy_) or (addon == l1ll11_opy_):
            l11ll1_opy_ = l11ll1_opy_.split(l1l1l_opy_ (u"ࠫࠥ࠳ࠠࠨ࠱"), 1)[0]
        l1llll_opy_ = l111l_opy_(addon, l11ll1_opy_)
        l11l1l_opy_ = l1llllll_opy_(addon, l111_opy_, labelmaps, l1ll1l1l_opy_, l1l1llll_opy_, l11ll1_opy_)
        stream  = l11111_opy_ + l1llll_opy_
        l111l1_opy_ = l11l1l_opy_  + l1l1l_opy_ (u"ࠬࡃࠧ࠲") + stream
        if l111l1_opy_ not in l1l1l11l_opy_:
            l1l1l11l_opy_.append(l111l1_opy_)
    l1l1l11l_opy_.sort()
    for item in l1l1l11l_opy_:
        l1lll11l_opy_.write(l1l1l_opy_ (u"ࠨࠥࡴ࡞ࡱࠦ࠳") % item)
    l1lll11l_opy_.close()
def l111l_opy_(addon, l11ll1_opy_):
    if (addon == nice) or (addon == l11ll_opy_) or (addon == l1ll1lll_opy_) or (addon == l1l1l1l_opy_) or (addon == root) or (addon == l1l11lll_opy_) or (addon == l1lll1_opy_) or (addon == l1lll111_opy_) or (addon == l11l_opy_) or (addon == l11ll1l_opy_) or (addon == l1ll11_opy_):
        l1l11ll_opy_ = mapping.cleanLabel(l11ll1_opy_)
        l1llll_opy_ = mapping.editPrefix(l111_opy_, l1l11ll_opy_)
        return l1llll_opy_
    l1l11ll_opy_ = mapping.cleanLabel(l11ll1_opy_)
    l1llll_opy_ = mapping.cleanStreamLabel(l1l11ll_opy_)
    return l1llll_opy_
def l1llllll_opy_(addon, l111_opy_, labelmaps, l1ll1l1l_opy_, l1l1llll_opy_, l11ll1_opy_):
    if (addon == nice) or (addon == l11ll_opy_) or (addon == l1ll1lll_opy_) or (addon == l1l1l1l_opy_) or (addon == root) or (addon == l1l11lll_opy_) or (addon == l1lll1_opy_) or (addon == l1lll111_opy_) or (addon == l11l_opy_) or (addon == l11ll1l_opy_) or (addon == l1ll11_opy_):
        return l1l11ll1_opy_(l111_opy_, l1l1llll_opy_, l11ll1_opy_)
    l1llll1_opy_    = mapping.cleanLabel(l11ll1_opy_)
    l1l11ll_opy_ = mapping.mapLabel(labelmaps, l1llll1_opy_)
    l11l1l_opy_ = mapping.cleanPrefix(l1l11ll_opy_)
    return mapping.mapChannelName(l1ll1l1l_opy_, l11l1l_opy_)
def l1l11ll1_opy_(l111_opy_, l1l1llll_opy_, l11ll1_opy_):
    l1l1_opy_ = mapping.cleanLabel(l11ll1_opy_)
    l1l11ll_opy_   = mapping.editPrefix(l111_opy_, l1l1_opy_)
    l111lll_opy_   = mapping.mapEPGLabel(l111_opy_, l1l1llll_opy_, l1l11ll_opy_)
    return l111lll_opy_
def l1ll_opy_(addon, file):
    l1llll1_opy_ = file[l1l1l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭࠴")].split(l1l1l_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ࠵"), 1)[0]
    l1llll1_opy_ = l1llll1_opy_.split(l1l1l_opy_ (u"ࠩ࠮ࠫ࠶"), 1)[0]
    l1llll1_opy_ = mapping.cleanLabel(l1llll1_opy_)
    return l1llll1_opy_
def l1l1l11_opy_(addon):
    if addon == nice:
        return l1l1l_opy_ (u"ࠪࡒࡎࡉࡅ࠻ࠩ࠷")
    if addon == l11ll_opy_:
        return l1l1l_opy_ (u"ࠫࡕࡘࡅࡎ࠼ࠪ࠸")
    if addon == l1ll1lll_opy_:
        return l1l1l_opy_ (u"ࠬࡍࡉ࡛࠼ࠪ࠹")
    if addon == l1l1l1l_opy_:
        return l1l1l_opy_ (u"࠭ࡇࡔࡒࡕࡘࡘࡀࠧ࠺")
    if addon == l1ll11_opy_:
        return l1l1l_opy_ (u"ࠧࡈࡇࡋ࠾ࠬ࠻")
    if addon == l11ll1l_opy_:
        return l1l1l_opy_ (u"ࠨࡖ࡙ࡏ࠿࠭࠼")
    if addon == l11l_opy_:
        return l1l1l_opy_ (u"ࠩࡐࡘ࡝ࡏࡅ࠻ࠩ࠽")
    if addon == l1lll111_opy_:
        return l1l1l_opy_ (u"ࠪ࡜࡙ࡉ࠺ࠨ࠾")
    if addon == l1lll1l_opy_:
        return l1l1l_opy_ (u"ࠫࡘࡉࡔࡗ࠼ࠪ࠿")
    if addon == l1llll11_opy_:
        return l1l1l_opy_ (u"࡙ࠬࡕࡑ࠼ࠪࡀ")
    if addon == l11lll1_opy_:
        return l1l1l_opy_ (u"࠭ࡕࡌࡖ࠽ࠫࡁ")
    if addon == l1l11lll_opy_:
        return l1l1l_opy_ (u"ࠧࡍࡋࡐࡍ࡙ࡀࠧࡂ")
    if addon == l1lll1_opy_:
        return l1l1l_opy_ (u"ࠨࡈࡄࡆ࠿࠭ࡃ")
    if addon == l1l1lll_opy_:
        return l1l1l_opy_ (u"ࠩࡄࡇࡊࡀࠧࡄ")
    if addon == l1l111l_opy_:
        return l1l1l_opy_ (u"ࠪࡌࡔࡘࡉ࡛࠼ࠪࡅ")
    if addon == root:
        return l1l1l_opy_ (u"ࠫࡗࡕࡏࡕ࠴࠽ࠫࡆ")
    if addon == l11111l_opy_:
        return l1l1l_opy_ (u"ࠬࡓࡅࡈࡃ࠽ࠫࡇ")
    if addon == l1l11l1l_opy_:
        return l1l1l_opy_ (u"࠭ࡆࡓࡇࡈ࠾ࠬࡈ")
    if addon == l1lll1ll_opy_:
        return l1l1l_opy_ (u"ࠧࡎࡃࡗࡗ࠿࠭ࡉ")
    if addon == l1ll1_opy_:
        return l1l1l_opy_ (u"ࠨࡋࡓࡘࡘࡀࠧࡊ")
    if addon == l11l1l1_opy_:
        return l1l1l_opy_ (u"ࠩࡍࡍࡓ࡞࠲࠻ࠩࡋ")
    if addon == l1ll1l_opy_:
        return l1l1l_opy_ (u"ࠪࡉࡓࡊ࠺ࠨࡌ")
    if addon == l1ll1l11_opy_:
        return l1l1l_opy_ (u"ࠫࡋࡒࡁ࠻ࠩࡍ")
    if addon == l1l111ll_opy_:
        return l1l1l_opy_ (u"ࠬࡓࡁ࡙ࡋ࠽ࠫࡎ")
    if addon == dexter:
        return l1l1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡉࡀࠧࡏ")
    if addon == l1l_opy_:
        return l1l1l_opy_ (u"ࠧࡗࡆࡕࡘ࡛ࡀࠧࡐ")
    if addon == l1111l1_opy_:
        return l1l1l_opy_ (u"ࠨࡕࡓࡖࡒࡀࠧࡑ")
    if addon == l11l1ll_opy_:
        return l1l1l_opy_ (u"ࠩࡐࡇࡐ࡚ࡖ࠻ࠩࡒ")
    if addon == l11ll11_opy_:
        return l1l1l_opy_ (u"ࠪࡘ࡜ࡏࡓࡕ࠼ࠪࡓ")
    if addon == l1l11l11_opy_:
        return l1l1l_opy_ (u"ࠫࡕࡘࡅࡔࡖ࠽ࠫࡔ")
    if addon == l1l1l111_opy_:
        return l1l1l_opy_ (u"ࠬࡈࡌࡌࡋ࠽ࠫࡕ")
def getURL(url):
    if url.startswith(l1l1l_opy_ (u"࠭ࡎࡊࡅࡈࠫࡖ")):
        return ll_opy_(url, nice)
    if url.startswith(l1l1l_opy_ (u"ࠧࡑࡔࡈࡑࠬࡗ")):
        return ll_opy_(url, l11ll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡉࡌ࡞ࠬࡘ")):
        return ll_opy_(url, l1ll1lll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡊࡗࡕࡘࡔࡔ࡙ࠩ")):
        return ll_opy_(url, l1l1l1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡋࡊࡎ࡚ࠧ")):
        return ll_opy_(url, l1ll11_opy_)
    if url.startswith(l1l1l_opy_ (u"࡙ࠫ࡜ࡋࠨ࡛")):
        return ll_opy_(url, l11ll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡓࡔ࡙ࡋࡈࠫ࡜")):
        return ll_opy_(url, l11l_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡘࡕࡅࠪ࡝")):
        return ll_opy_(url, l1lll111_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡔࡅࡗ࡚ࠬ࡞")):
        return ll_opy_(url, l1lll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡕࡘࡔࠬ࡟")):
        return ll_opy_(url, l1llll11_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡘࡏ࡙࠭ࡠ")):
        return ll_opy_(url, l11lll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡐࡎࡓࡉࡕࠩࡡ")):
        return ll_opy_(url, l1l11lll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡋࡇࡂࠨࡢ")):
        return ll_opy_(url, l1lll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡇࡃࡆࠩࡣ")):
        return ll_opy_(url, l1l1lll_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡈࡐࡔࡌ࡞ࠬࡤ")):
        return ll_opy_(url, l1l111l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡓࡑࡒࡘ࠷࠭ࡥ")):
        return ll_opy_(url, root)
    if url.startswith(l1l1l_opy_ (u"ࠨࡏࡈࡋࡆ࠭ࡦ")):
        return ll_opy_(url, l11111l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡉࡖࡊࡋࠧࡧ")):
        return ll_opy_(url, l1l11l1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡅࡏ࡙࠿࠭ࡨ")):
        url = url.replace(l1l1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡆࡐ࡚ࡀࠧࡩ"), l1l1l_opy_ (u"ࠬ࠭ࡪ")).replace(l1l1l_opy_ (u"࠭࠭࠮ࡷࡶࡩࡷ࠳ࡡࡨࡧࡱࡸࠬ࡫"), l1l1l_opy_ (u"ࠧࡽࡷࡶࡩࡷ࠳ࡡࡨࡧࡱࡸࠬ࡬"))
        return url
    if url.startswith(l1l1l_opy_ (u"ࠨࡏࡄࡘࡘ࠭࡭")):
        return ll_opy_(url, l1lll1ll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡌࡔ࡙࡙ࠧ࡮")):
        return ll_opy_(url, l1ll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡎࡎࡔࡘ࠳ࠩ࡯")):
        return ll_opy_(url, l11l1l1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡇࠫࡰ")):
        return ll_opy_(url, dexter)
    if url.startswith(l1l1l_opy_ (u"ࠬࡌࡌࡂࠩࡱ")):
        return ll_opy_(url, l1ll1l11_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡍࡂ࡚ࡌࠫࡲ")):
        return ll_opy_(url, l1l111ll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡆࡐࡇࠫࡳ")):
        return ll_opy_(url, l1ll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡘࡇࡖ࡙࡜ࠧࡴ")):
        return ll_opy_(url, l1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡖࡔࡗࡓࠧࡵ")):
        return ll_opy_(url, l1111l1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡑࡈࡑࡔࡗࠩࡶ")):
        return ll_opy_(url, l11l1ll_opy_)
    if url.startswith(l1l1l_opy_ (u"࡙ࠫ࡝ࡉࡔࡖࠪࡷ")):
        return ll_opy_(url, l11ll11_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡖࡒࡆࡕࡗࠫࡸ")):
        return ll_opy_(url, l1l11l11_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡂࡍࡍࡌࠫࡹ")):
        return ll_opy_(url, l1l1l111_opy_)
    response  = l11llll1_opy_(url)
    l1ll1ll_opy_ = url.split(l1l1l_opy_ (u"ࠧ࠻ࠩࡺ"), 1)[-1]
    l1ll1ll_opy_ = l1ll1ll_opy_.upper().replace(l1l1l_opy_ (u"ࠨࠢࠪࡻ"), l1l1l_opy_ (u"ࠩࠪࡼ"))
    try:
        result = response[l1l1l_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪࡽ")]
        l11l11l_opy_  = result[l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪࡾ")]
    except Exception as e:
        l1l111l1_opy_(e)
        return None
    for file in l11l11l_opy_:
        l11ll1_opy_  = file[l1l1l_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫࡿ")].split(l1l1l_opy_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࢀ"), 1)[0]
        l1ll1l1_opy_  = l11ll1_opy_.split(l1l1l_opy_ (u"ࠧࠬࠩࢁ"), 1)[0]
        l1ll11l_opy_ = mapping.cleanLabel(l1ll1l1_opy_)
        l1ll11l_opy_ = l1ll11l_opy_.upper().replace(l1l1l_opy_ (u"ࠨࠢࠪࢂ"), l1l1l_opy_ (u"ࠩࠪࢃ"))
        try:
            if l1ll1ll_opy_ == l1ll11l_opy_:
                return file[l1l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࠨࢄ")]
        except:
            if (l1ll1ll_opy_ in l1ll11l_opy_) or (l1ll11l_opy_ in l1ll1ll_opy_):
                return file[l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࠩࢅ")]
    return None
def ll_opy_(url, addon):
    PATH = l1lll1l1_opy_(addon)
    try:
        response = json.load(open(PATH))
    except:
        response = l1llll1l_opy_(addon)
    l1l1l1l1_opy_      = url.split(l1l1l_opy_ (u"ࠬࡀࠧࢆ"), 1)[-1]
    stream    = l1l1l1l1_opy_.split(l1l1l_opy_ (u"࠭ࠠ࡜ࠩࢇ"), 1)[0]
    l1ll1ll_opy_ = mapping.cleanLabel(stream)
    l1ll1ll_opy_ = l1ll1ll_opy_.upper().replace(l1l1l_opy_ (u"ࠧࠡࠩ࢈"), l1l1l_opy_ (u"ࠨࠩࢉ"))
    l11l11l_opy_  = response[l1l1l_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩࢊ")][l1l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩࢋ")]
    for file in l11l11l_opy_:
        l11ll1_opy_  = file[l1l1l_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪࢌ")].split(l1l1l_opy_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࢍ"), 1)[0]
        if addon == dexter:
            l11ll1_opy_ = l11ll1_opy_.split(l1l1l_opy_ (u"࠭ࠠࠬࠢࠪࢎ"), 1)[0]
        if (addon == nice) or (addon == l1ll1lll_opy_) or (addon == l1l1l1l_opy_) or (addon == root) or (addon == l1l11lll_opy_) or (addon == l11ll1l_opy_) or (addon == l1ll11_opy_):
            l11ll1_opy_ = l11ll1_opy_.split(l1l1l_opy_ (u"ࠧࠡ࠯ࠣࠫ࢏"), 1)[0]
        l1ll11l_opy_ = l111l_opy_(addon, l11ll1_opy_)
        l1ll11l_opy_ = l1ll11l_opy_.upper().replace(l1l1l_opy_ (u"ࠨࠢࠪ࢐"), l1l1l_opy_ (u"ࠩࠪ࢑"))
        try:
            if l1ll1ll_opy_ == l1ll11l_opy_:
                return file[l1l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࠨ࢒")]
        except:
            if (l1ll1ll_opy_ in l1ll11l_opy_) or (l1ll11l_opy_ in l1ll1ll_opy_):
                return file[l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࠩ࢓")]
    return None
def l1llll1l_opy_(addon):
    PATH  = l1lll1l1_opy_(addon)
    if addon == l1l_opy_:
        query = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡖࡂࡆࡈࡖ࠴ࡲࡩࡷࡧࡷࡺ࠴ࡧ࡬࡭࠱ࠪ࢔")
    elif addon == l1llll11_opy_:
        query = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡶࡵࡩࡦࡳࡳࡶࡲࡵࡩࡲ࡫࠲࠰࡮࡬ࡺࡪࡺࡶ࠰ࡣ࡯ࡰ࠴࠭࢕")
    elif addon == l1lll1l_opy_:
        query = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡦࡸࡻ࠵࡬ࡪࡸࡨࡸࡻ࠵ࡡ࡭࡮࠲ࠫ࢖")
    elif addon == l1llll11_opy_:
        query = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡸࡷ࡫ࡡ࡮ࡵࡸࡴࡷ࡫࡭ࡦ࠴࠲ࡰ࡮ࡼࡥࡵࡸ࠲ࡥࡱࡲ࠯ࠨࢗ")
    elif addon == l1l11l1l_opy_:
        query = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡪࡷ࡫ࡥࡷ࡫ࡨࡻ࠴ࡅࡵࡳ࡮ࡀࡹࡷࡲࠦ࡮ࡱࡧࡩࡂ࠻ࠦ࡯ࡣࡰࡩࡂࡒࡩࡷࡧ࠮ࡘ࡛࠭࢘")
    elif addon == l11lll1_opy_:
        query = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡶࡴ࡮࠳ࡄࡻࡲ࡭࠿࡫ࡸࡹࡶࠥ࠴ࡃࠨ࠶ࡋࠫ࠲ࡇࡣࡧࡨࡴࡴࡣ࡭ࡱࡸࡨ࠳ࡵࡲࡨࠧ࠵ࡊࡺࡱࡴࡶࡴ࡮ࠩ࠷ࡌࡕࡌࡖࡸࡶࡰࠫ࠲ࡇࡎ࡬ࡺࡪࠫ࠲࠶࠴࠳ࡘ࡛࠴ࡴࡹࡶࠩࡱࡴࡪࡥ࠾࠳ࠩࡲࡦࡳࡥ࠾ࡎ࡬ࡺࡪ࠱ࡔࡗࠨࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴ࠽ࠧࡨࡤࡲࡦࡸࡴ࠾ࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂ࢙࠭")
    else:
        query = l1ll1ll1_opy_(addon)
    try:
        return json.load(open(PATH))
    except:
        content = doJSON(query)
        return l1l11_opy_(PATH, addon, content)
def l1l11_opy_(PATH, addon, content):
    json.dump(content, open(PATH,l1l1l_opy_ (u"ࠫࡼ࢚࠭")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    l1ll111_opy_  = (l1l1l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࠦࡵࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ࢛") % query)
    response = xbmc.executeJSONRPC(l1ll111_opy_)
    content  = json.loads(response)
    return content
def l1lll1l1_opy_(addon):
    if addon == nice:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭࡮ࡪࡥࡨࡸࡪࡳࡰࠨ࢜"))
    if addon == l11ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡱࡴࡨࡱࡹ࡫࡭ࡱࠩ࢝"))
    if addon == l1ll1lll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡩ࡬ࡾࡹ࡫࡭ࡱࠩ࢞"))
    if addon == l1l1l1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡪࡷࡵࡸࡴࡴࡶࡨࡱࡵ࠭࢟"))
    if addon == l1ll11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪ࡫ࡪࡺࡥ࡮ࡲࠪࢠ"))
    if addon == l11l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡲࡺࡸࡵࡧࡰࡴࠬࢡ"))
    if addon == l11ll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡺࡶ࡬ࡶࡨࡱࡵ࠭ࢢ"))
    if addon == l1lll111_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡸࡵࡧࡰࡴࠬࢣ"))
    if addon == l1lll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡴࡥࡷࡩࡲࡶࠧࢤ"))
    if addon == l1llll11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡵࡸࡴࡹ࡫࡭ࡱࠩࢥ"))
    if addon == l11lll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡸ࡯ࡹࡺࡥ࡮ࡲࠪࢦ"))
    if addon == l1l11lll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡰ࡮ࡳࡩࡵࡧࡰࡴࠬࢧ"))
    if addon == l1lll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫ࡫ࡧࡢࡵࡧࡰࡴࠬࢨ"))
    if addon == l1l1lll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡧࡣࡦࡶࡨࡱࡵ࠭ࢩ"))
    if addon == l1l111l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡨࡰࡴࡷࡩࡲࡶࠧࢪ"))
    if addon == root:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡳࡱ࠵ࡸࡪࡳࡰࠨࢫ"))
    if addon == l11111l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨ࡯ࡨ࡫ࡦࡺ࡭ࡱࠩࢬ"))
    if addon == l1lll1ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡰࡥࡹࡹࡴ࡮ࡲࠪࢭ"))
    if addon == l1l11l1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡪࡷ࡫ࡥࡵ࡯ࡳࠫࢮ"))
    if addon == l1ll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫ࡮ࡶࡴࡴࡶࡰࡴࠬࢯ"))
    if addon == l11l1l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡰ࠲ࡵࡧࡰࡴࠬࢰ"))
    if addon == l1ll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡥࡵࡧࡰࡴࠬࢱ"))
    if addon == l1ll1l11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡧࡶࡨࡱࡵ࠭ࢲ"))
    if addon == l1l111ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨ࡯ࡤࡼࡹ࡫࡭ࡱࠩࢳ"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡧࡸࡪࡳࡰࠨࢴ"))
    if addon == l1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡺࡩࡺࡥ࡮ࡲࠪࢵ"))
    if addon == l1111l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡸࡶࡲࡵࡧࡰࡴࠬࢶ"))
    if addon == l11l1ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡳࡣ࡬ࡶࡨࡱࡵ࠭ࢷ"))
    if addon == l11ll11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡴࡸ࡫ࡷࡩࡲࡶࠧࢸ"))
    if addon == l1l11l11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡱࡴࡨࡷࡹ࡫࡭ࡱࠩࢹ"))
    if addon == l1l1l111_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡤ࡯࡯࡮ࡺࡥ࡮ࡲࠪࢺ"))
def l1ll1ll1_opy_(addon):
    query = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬࢻ") + addon
    response = doJSON(query)
    l11l11l_opy_    = response[l1l1l_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪࢼ")][l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪࢽ")]
    for file in l11l11l_opy_:
        l111l1l_opy_ = file[l1l1l_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫࢾ")]
        l1llll1_opy_ = mapping.cleanLabel(l111l1l_opy_)
        l1llll1_opy_ = l1llll1_opy_.upper()
        if (l1llll1_opy_ == l1l1l_opy_ (u"࠭ࡌࡊࡘࡈࠤࡎࡖࡔࡗࠩࢿ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠧࡍࡋ࡙ࡉ࡚ࠥࡖࠨࣀ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠨࡎࡌ࡚ࡊࠦࡃࡉࡃࡑࡒࡊࡒࡓࠨࣁ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠩࡏࡍ࡛ࡋࠧࣂ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠪࡉࡓࡊࡌࡆࡕࡖࠤࡒࡋࡄࡊࡃࠪࣃ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠫࡋࡒࡁࡘࡎࡈࡗࡘ࡚ࡖࠨࣄ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠬࡓࡁ࡙ࡋ࡚ࡉࡇࠦࡔࡗࠩࣅ")) or (l1llll1_opy_ == l1l1l_opy_ (u"࠭ࡂࡍࡃࡆࡏࡎࡉࡅࠡࡖ࡙ࠫࣆ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠧࡉࡑࡕࡍ࡟ࡕࡎࠡࡋࡓࡘ࡛࠭ࣇ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠨࡈࡄࡆࠥࡏࡐࡕࡘࠪࣈ")):
            livetv = file[l1l1l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧࣉ")]
            return l1111l_opy_(livetv)
def l1111l_opy_(livetv):
    response = doJSON(livetv)
    l11l11l_opy_    = response[l1l1l_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪ࣊")][l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪ࣋")]
    for file in l11l11l_opy_:
        l111l1l_opy_ = file[l1l1l_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫ࣌")]
        l1llll1_opy_ = mapping.cleanLabel(l111l1l_opy_)
        l1llll1_opy_ = l1llll1_opy_.upper()
        if l1llll1_opy_ == l1l1l_opy_ (u"࠭ࡁࡍࡎࠪ࣍"):
            return file[l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࠬ࣎")]
def l1lll11_opy_(l11l1_opy_):
    items = []
    _111l11_opy_(l11l1_opy_, items)
    return items
def _111l11_opy_(l11l1_opy_, items):
    response = doJSON(l11l1_opy_)
    if response[l1l1l_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨ࣏")].has_key(l1l1l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨ࣐")):
        result = response[l1l1l_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶ࣑ࠪ")][l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࡵ࣒ࠪ")]
        for item in result:
            if item[l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫࣓ࠧ")] == l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࠫࣔ"):
                l1llll1_opy_ = mapping.cleanLabel(item[l1l1l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ࣕ")])
                items.append(item)
            elif item[l1l1l_opy_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪࣖ")] == l1l1l_opy_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠬࣗ"):
                l1llll1_opy_ = mapping.cleanLabel(item[l1l1l_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࣘ")])
                l1l1111l_opy_  = item[l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࠩࣙ")]
                dixie.log(item)
                dixie.log(l1l1111l_opy_)
                _111l11_opy_(l1l1111l_opy_, items)
def l11llll1_opy_(url):
    if url.startswith(l1l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜࠾ࠬࣚ")):
        l1ll111_opy_ = (l1l1l_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡥࡦࡨ࡯ࡰ࡭ࡣࡼࡩࡷ࠵࠿ࡶࡴ࡯ࡁࡺࡸ࡬ࠧ࡯ࡲࡨࡪࡃ࠲ࠧࡰࡤࡱࡪࡃࡌࡪࡸࡨࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࡃࠦࡊࡒࡌࡈࡂࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࣛ"))
    if url.startswith(l1l1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞࠸࠺ࠨࣜ")):
        l1ll111_opy_ = (l1l1l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶ࡬ࡢࡻࡨࡶࡼࡽࡷ࠰ࡁࡸࡶࡱࡃࡵࡳ࡮ࠩࡱࡴࡪࡥ࠾࠳࠳࠵ࠫࡴࡡ࡮ࡧࡀ࡛ࡦࡺࡣࡩ࠭ࡏ࡭ࡻ࡫ࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠩࡷࡺࡨࡴࡪࡶ࡯ࡩࡸࡥࡵࡳ࡮ࡀࠪࡱࡵࡧࡨࡧࡧࡣ࡮ࡴ࠽ࡇࡣ࡯ࡷࡪࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࣝ"))
    if url.startswith(l1l1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡓ࠼ࠪࣞ")):
        l1ll111_opy_ = (l1l1l_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱ࡮ࡤࡽࡪࡸࡷࡸࡹ࠲ࡃࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࡊࡥࡧࡣࡸࡰࡹࡌ࡯࡭ࡦࡨࡶ࠳ࡶ࡮ࡨࠨ࡯ࡳ࡬࡭ࡥࡥࡡ࡬ࡲࡂࡌࡡ࡭ࡵࡨࠪࡲࡵࡤࡦ࠿࠴࠵࠸ࠬ࡮ࡢ࡯ࡨࡁࡑ࡯ࡳࡵࡧࡱࠩ࠷࠶ࡌࡪࡸࡨࠪࡸࡻࡢࡵ࡫ࡷࡰࡪࡹ࡟ࡶࡴ࡯ࠪࡺࡸ࡬࠾ࡷࡵࡰࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࣟ"))
    if url.startswith(l1l1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡌࡘ࡛ࡀࠧ࣠")):
        l1ll111_opy_ = (l1l1l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡷࡺࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ࣡"))
    if url.startswith(l1l1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡉࡀࠧ࣢")):
        l1ll111_opy_ = (l1l1l_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡨࡪࡾ࠯ࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡣ࡯ࡰࠫ࡫ࡸࡵࡴࡤࠪࡵࡧࡧࡦࠨࡳࡰࡴࡺࠦࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡀࠪࡹ࡯ࡴ࡭ࡧࡀࠩ࠺ࡨࡃࡐࡎࡒࡖࠪ࠸࠰ࡸࡪ࡬ࡸࡪࠫ࠵ࡥࡃ࡯ࡰࠪ࠸࠰ࡄࡪࡤࡲࡳ࡫࡬ࡴࠧ࠸ࡦࠪ࠸ࡦࡄࡑࡏࡓࡗࠫ࠵ࡥࠨࡸࡶࡱࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࣣࠫ"))
    if url.startswith(l1l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡒࡃ࠼ࠪࣤ")):
        l1ll111_opy_ = (l1l1l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡥࡣࡱࡲࡸ࠴ࡅࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠪ࡫ࡧ࡮ࡢࡴࡷࡁࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡰࡳࡩ࡫࠽࠸ࠨࡳ࡭ࡱࡲ࡯ࡸ࠿ࡏ࡭ࡻ࡫ࠥ࠳࠲ࡖࡸࡷ࡫ࡡ࡮ࡵࠩࡹࡷࡲ࠽ࡳࡣࡱࡨࡴࡳࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬࣥ"))
    try:
        dixie.ShowBusy()
        addon =  l1ll111_opy_.split(l1l1l_opy_ (u"ࠪ࠳࠴ࣦ࠭"), 1)[-1].split(l1l1l_opy_ (u"ࠫ࠴࠭ࣧ"), 1)[0]
        login = l1l1l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࣨ") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1ll111_opy_)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1l111l1_opy_(e)
        return {l1l1l_opy_ (u"࠭ࡅࡳࡴࡲࡶࣩࠬ") : l1l1l_opy_ (u"ࠧࡑ࡮ࡸ࡫࡮ࡴࠠࡆࡴࡵࡳࡷ࠭࣪")}
def l1ll1111_opy_():
    modules = map(__import__, [l1l11l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l1l1l_opy_ (u"ࠨࡖࡵࡹࡪ࠭࣫")
    if len(modules[-1].Window(10**4).getProperty(l11lll_opy_)):
        return l1l1l_opy_ (u"ࠩࡗࡶࡺ࡫ࠧ࣬")
    return l1l1l_opy_ (u"ࠪࡊࡦࡲࡳࡦ࣭ࠩ")
def l1l111l1_opy_(e):
    l1ll111l_opy_ = l1l1l_opy_ (u"ࠫࡘࡵࡲࡳࡻ࠯ࠤࡦࡴࠠࡦࡴࡵࡳࡷࠦ࡯ࡤࡥࡸࡶࡪࡪ࠺ࠡࡌࡖࡓࡓࠦࡅࡳࡴࡲࡶ࠿ࠦࠥࡴ࣮ࠩ")  %e
    l1_opy_ = l1l1l_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡸࡥ࠮࡮࡬ࡲࡰࠦࡴࡩ࡫ࡶࠤࡨ࡮ࡡ࡯ࡰࡨࡰࠥࡧ࡮ࡥࠢࡷࡶࡾࠦࡡࡨࡣ࡬ࡲ࠳࣯࠭")
    l1ll11ll_opy_ = l1l1l_opy_ (u"࠭ࡕࡴࡧ࠽ࠤࡈࡵ࡮ࡵࡧࡻࡸࠥࡓࡥ࡯ࡷࠣࡁࡃࠦࡒࡦ࡯ࡲࡺࡪࠦࡓࡵࡴࡨࡥࡲࣰ࠭")
    dixie.log(e)
    dixie.DialogOK(l1ll111l_opy_, l1_opy_, l1ll11ll_opy_)
if __name__ == l1l1l_opy_ (u"ࠧࡠࡡࡰࡥ࡮ࡴ࡟ࡠࣱࠩ"):
    checkAddons()