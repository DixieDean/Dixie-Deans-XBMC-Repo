# coding: UTF-8
import sys
l1l1l1l_opy_ = sys.version_info [0] == 2
l111l1_opy_ = 2048
l1111_opy_ = 7
def l11l1l_opy_ (ll_opy_):
	global l111ll_opy_
	l1l1ll1_opy_ = ord (ll_opy_ [-1])
	l11lll_opy_ = ll_opy_ [:-1]
	l1lll_opy_ = l1l1ll1_opy_ % len (l11lll_opy_)
	l1ll1_opy_ = l11lll_opy_ [:l1lll_opy_] + l11lll_opy_ [l1lll_opy_:]
	if l1l1l1l_opy_:
		l1lllll_opy_ = unicode () .join ([unichr (ord (char) - l111l1_opy_ - (l1l111_opy_ + l1l1ll1_opy_) % l1111_opy_) for l1l111_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1lllll_opy_ = str () .join ([chr (ord (char) - l111l1_opy_ - (l1l111_opy_ + l1l1ll1_opy_) % l1111_opy_) for l1l111_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1lllll_opy_)
import time
import random
import base64
import requests
import re
import os
import json
import hashlib
import xbmc
import dixie
addon = l11l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡱ࡯ࡶࡦ࡯࡬ࡼࠬࡣ")
def checkAddons():
    if l1l11l1_opy_(addon):
        createINI()
def l1l11l1_opy_(addon):
    if xbmc.getCondVisibility(l11l1l_opy_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡈࡢࡵࡄࡨࡩࡵ࡮ࠩࠧࡶ࠭ࠬࡤ") % addon) == 1:
        return True
    return False
def getLIVETV(url):
    if url.startswith(l11l1l_opy_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜ࡆ࠻ࠩࡥ")):
        return url.replace(l11l1l_opy_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖࡇ࠼ࠪࡦ"), l11l1l_opy_ (u"ࠩࠪࡧ")).replace(l11l1l_opy_ (u"ࠪ࠲ࡹࡹࠧࡨ"), l11l1l_opy_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪࡩ"))
    l1ll1ll_opy_ = getChannels()
    stream   = url.split(l11l1l_opy_ (u"ࠬࡀࠧࡪ"), 1)[-1].lower()
    for channel in l1ll1ll_opy_:
        l1l11l_opy_ = channel[l11l1l_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬ࡫")]
        url   = channel[l11l1l_opy_ (u"ࠧࡶࡴ࡯ࠫ࡬")]
        if stream == l1l11l_opy_.lower():
            return url
    return None
def createINI():
    HOME = dixie.PROFILE
    PATH = os.path.join(HOME, l11l1l_opy_ (u"ࠨ࡫ࡱ࡭ࠬ࡭"))
    l1111l_opy_ = l11l1l_opy_ (u"ࠩ࡯࡭ࡻ࡫ࡴࡷ࠰࡬ࡲ࡮࠭࡮")
    l1l_opy_  = os.path.join(PATH, l1111l_opy_)
    l1ll1ll_opy_ = getChannels()
    l1ll1l1_opy_  = file(l1l_opy_, l11l1l_opy_ (u"ࠪࡻࠬ࡯"))
    l1ll1l1_opy_.write(l11l1l_opy_ (u"ࠫࡠ࠭ࡰ"))
    l1ll1l1_opy_.write(addon)
    l1ll1l1_opy_.write(l11l1l_opy_ (u"ࠬࡣࠧࡱ"))
    l1ll1l1_opy_.write(l11l1l_opy_ (u"࠭࡜࡯ࠩࡲ"))
    for channel in l1ll1ll_opy_:
        l1l11l_opy_   = channel[l11l1l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ࡳ")]
        stream  = channel[l11l1l_opy_ (u"ࠨࡷࡵࡰࠬࡴ")]
        l1ll1l1_opy_.write(l11l1l_opy_ (u"ࠩࠨࡷࠬࡵ") % l1l11l_opy_)
        l1ll1l1_opy_.write(l11l1l_opy_ (u"ࠪࡁࠬࡶ"))
        l1ll1l1_opy_.write(l11l1l_opy_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠾ࠬࡷ"))
        l1ll1l1_opy_.write(l11l1l_opy_ (u"ࠬࠫࡳࠨࡸ") % l1l11l_opy_)
        l1ll1l1_opy_.write(l11l1l_opy_ (u"࠭࡜࡯ࠩࡹ"))
    l1ll1l1_opy_.write(l11l1l_opy_ (u"ࠧ࡝ࡰࠪࡺ"))
    l1ll1l1_opy_.close()
def getChannels():
    token   =  l11ll11_opy_(l11l1l_opy_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡴࡵ࠴ࡵ࡬ࡶࡹࡲࡴࡽ࠮࡯ࡧࡷ࠳ࡻ࠷࠯ࡨࡧࡷࡣࡦࡲ࡬ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪࡻ"),l11l1l_opy_ (u"ࠩࡪࡳࡦࡺࠧࡼ"))
    headers =  {l11l1l_opy_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧࡽ"):l11l1l_opy_ (u"࡚࡙ࠫࡅࡓ࠯ࡄࡋࡊࡔࡔ࠮ࡗࡎࡘ࡛ࡔࡏࡘ࠯ࡄࡔࡕ࠳ࡖ࠲ࠩࡾ"),
                l11l1l_opy_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫࡿ"):l11l1l_opy_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭ࢀ"),
                l11l1l_opy_ (u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩࢁ") : l11l1l_opy_ (u"ࠨࡩࡽ࡭ࡵ࠭ࢂ"),
                l11l1l_opy_ (u"ࠩࡤࡴࡵ࠳ࡴࡰ࡭ࡨࡲࠬࢃ"):token,
                l11l1l_opy_ (u"ࠪࡇࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࠧࢄ"):l11l1l_opy_ (u"ࠫࡐ࡫ࡥࡱ࠯ࡄࡰ࡮ࡼࡥࠨࢅ"),
                l11l1l_opy_ (u"ࠬࡎ࡯ࡴࡶࠪࢆ"):l11l1l_opy_ (u"࠭ࡡࡱࡲ࠱ࡹࡰࡺࡶ࡯ࡱࡺ࠲ࡳ࡫ࡴࠨࢇ")}
    l11l1ll_opy_ = {l11l1l_opy_ (u"ࠧࡶࡵࡨࡶࡳࡧ࡭ࡦࠩ࢈"):l11l1l_opy_ (u"ࠨࡩࡲࡥࡹ࠭ࢉ")}
    request = requests.post(l11l1l_opy_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡵࡶ࠮ࡶ࡭ࡷࡺࡳࡵࡷ࠯ࡰࡨࡸ࠴ࡼ࠱࠰ࡩࡨࡸࡤࡧ࡬࡭ࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫࢊ"), data=l11l1ll_opy_, headers=headers)
    l11lll1_opy_ =  request.content
    l11lll1_opy_ =  l11lll1_opy_.replace(l11l1l_opy_ (u"ࠪࡠ࠴࠭ࢋ"),l11l1l_opy_ (u"ࠫ࠴࠭ࢌ"))
    l11llll_opy_ = l11l1l_opy_ (u"ࠬࠨࡣࡩࡣࡱࡲࡪࡲ࡟࡯ࡣࡰࡩࠧࡀࠢࠩ࠰࠮ࡃ࠮ࠨࠬࠣ࡫ࡰ࡫ࠧࡀࠢࠩ࠰࠮ࡃ࠮ࠨࠬࠣࡪࡷࡸࡵࡥࡳࡵࡴࡨࡥࡲࠨ࠺ࠣࠪ࠱࠯ࡄ࠯ࠢ࠭ࠤࡵࡸࡲࡶ࡟ࡴࡶࡵࡩࡦࡳࠢ࠻ࠤࠫ࠲࠰ࡅࠩࠣ࠮ࠥࡧࡦࡺ࡟ࡪࡦࠥ࠾ࠧ࠮࠮ࠬࡁࠬࠦࠬࢍ")
    items    = re.compile(l11llll_opy_).findall(l11lll1_opy_)
    l1ll1ll_opy_ = []
    for item in items:
        link = {l11l1l_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬࢎ"): item[0], l11l1l_opy_ (u"ࠧࡶࡴ࡯ࠫ࢏"): item[2]}
        l1ll1ll_opy_.append(link)
    return l1ll1ll_opy_
def l11ll11_opy_(url, username):
    l11ll1l_opy_   =  l11l1l1_opy_()
    st   = l11l1l_opy_ (u"ࠣࡷ࡮ࡸࡻࡴ࡯ࡸ࠯ࡷࡳࡰ࡫࡮࠮ࠤ࢐")+ l11ll1l_opy_ + l11l1l_opy_ (u"ࠤ࠰ࠦ࢑")+ l11l1l_opy_ (u"ࠥࡣࢁࡥ࠭ࠣ࢒") + url + l11l1l_opy_ (u"ࠦ࠲ࠨ࢓") + username +l11l1l_opy_ (u"ࠧ࠳ࠢ࢔") + l11l1l_opy_ (u"ࠨ࡟ࡽࡡࠥ࢕")+ l11l1l_opy_ (u"ࠢ࠮ࠤ࢖")+ base64.b64decode(l11l1l_opy_ (u"ࠣࡏࡗࡍࡿࡔࡄࡖ࠴ࡌ࡙ࡆࡰࡊࡄࡘࡨࡨ࡜ࡺ࠰ࡥ࡯࠸ࡺࡩ࠷࠴࡭ࡌࡆࡒࡆࡏࡔ࡚࠳ࡑࡈࡒࡿࡍࡒ࠿ࡀࠦࢗ"))
    return hashlib.md5(st).hexdigest()
def l11l1l1_opy_():
    from datetime import datetime, timedelta
    local = datetime.now() + timedelta(hours=5)
    return local.strftime(l11l1l_opy_ (u"ࠩࠨࡆ࠲ࠫࡤ࠮ࠧ࡜ࠫ࢘"))