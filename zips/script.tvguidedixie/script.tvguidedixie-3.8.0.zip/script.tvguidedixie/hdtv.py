# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l11lll_opy_ = 2048
l1l1l_opy_ = 7
def l1ll11_opy_ (ll_opy_):
	global l1l111_opy_
	l1lll1l_opy_ = ord (ll_opy_ [-1])
	l1l1l1_opy_ = ll_opy_ [:-1]
	l11_opy_ = l1lll1l_opy_ % len (l1l1l1_opy_)
	l111_opy_ = l1l1l1_opy_ [:l11_opy_] + l1l1l1_opy_ [l11_opy_:]
	if l1_opy_:
		l111ll_opy_ = unicode () .join ([unichr (ord (char) - l11lll_opy_ - (l1lll1_opy_ + l1lll1l_opy_) % l1l1l_opy_) for l1lll1_opy_, char in enumerate (l111_opy_)])
	else:
		l111ll_opy_ = str () .join ([chr (ord (char) - l11lll_opy_ - (l1lll1_opy_ + l1lll1l_opy_) % l1l1l_opy_) for l1lll1_opy_, char in enumerate (l111_opy_)])
	return eval (l111ll_opy_)
import xbmc
import xbmcgui
import time
import datetime
import os
import sys
from threading import Timer
if sys.version_info >=  (2, 7):
    import json
else:
    import simplejson as json
import dixie
PATH     =  os.path.join(dixie.PROFILE, l1ll11_opy_ (u"ࠫࡹ࡫࡭ࡱࠩࠀ"))
SETTING  = l1ll11_opy_ (u"ࠬࡒࡏࡈࡋࡑࡣࡍࡊࡔࡗࠩࠁ")
l11ll_opy_ =  50
def getURL(url):
    if dixie.validTime(SETTING, 60 * 60 * 8):
        response = json.load(open(PATH))
    else:
        response = l1lll11_opy_(url)
        l1ll1_opy_(SETTING)
    stream = url.split(l1ll11_opy_ (u"࠭࠺ࠨࠂ"), 1)[-1].lower()
    try:
        result = response[l1ll11_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧࠃ")]
        l1l11l_opy_  = result[l1ll11_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧࠄ")]
    except Exception as e:
        l1111l_opy_(e)
        return None
    for file in l1l11l_opy_:
        l1llll_opy_   = file[l1ll11_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨࠅ")]
        l1llll_opy_   = l1llll_opy_.replace(l1ll11_opy_ (u"ࠪࠤࠥ࠭ࠆ"), l1ll11_opy_ (u"ࠫࠥ࠭ࠇ")).replace(l1ll11_opy_ (u"࡛ࠬࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨࠈ"), l1ll11_opy_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࠉ"))
        channel = l1llll_opy_.rsplit(l1ll11_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࠊ"), 1)[0].split(l1ll11_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡹ࡫࡭ࡹ࡫࡝ࠨࠋ"), 1)[-1]
        if stream == channel.lower():
            return file[l1ll11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧࠌ")]
    return None
def l1lll11_opy_(url):
    try:
        message = l1ll11_opy_ (u"ࠪࡖࡪࡺࡲࡪࡧࡹ࡭ࡳ࡭ࠠࡶࡲࡧࡥࡹ࡫ࡤࠡࡥ࡫ࡥࡳࡴࡥ࡭ࠢ࡯࡭ࡳࡱࡳ࠯ࠢࡓࡰࡪࡧࡳࡦࠢࡥࡩࠥࡶࡡࡵ࡫ࡨࡲࡹ࠴ࠧࠍ")
        dixie.notify(message, 7000)
        dixie.ShowBusy()
        response = l11l11_opy_(url)
        dixie.CloseBusy()
        return response
    except Exception as e:
        l1111l_opy_(e)
        return {l1ll11_opy_ (u"ࠫࡊࡸࡲࡰࡴࠪࠎ") : l1ll11_opy_ (u"ࠬࡖ࡬ࡶࡩ࡬ࡲࠥࡋࡲࡳࡱࡵࠫࠏ")}
def l11l11_opy_(url):
    doJSON(url)
    return json.load(open(PATH))
def doJSON(url):
    login = l1lllll_opy_(url)
    xbmc.executeJSONRPC(login)
    l1llll1_opy_  = l111l_opy_(url)
    response = xbmc.executeJSONRPC(l1llll1_opy_)
    content = json.loads(response.decode(l1ll11_opy_ (u"࠭࡬ࡢࡶ࡬ࡲ࠲࠷ࠧࠐ"), l1ll11_opy_ (u"ࠧࡪࡩࡱࡳࡷ࡫ࠧࠑ")))
    json.dump(content, open(PATH,l1ll11_opy_ (u"ࠨࡹࠪࠒ")), indent=0)
    l11ll1_opy_(url)
def l1lllll_opy_(url):
    l1l1ll_opy_ = l1lll_opy_(url)
    login   = (l1ll11_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴ࠱ࡂࡥࡨࡺࡩࡰࡰࡀࡱࡦ࡯࡮ࡠ࡮࡬ࡷࡹࠬࡴࡪࡶ࡯ࡩࡂࠬࡵࡳ࡮ࡀࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩࠓ") % l1l1ll_opy_)
    return login
def l111l_opy_(url):
    l1l1ll_opy_ = l1lll_opy_(url)
    l1llll1_opy_ = (l1ll11_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠦࡵ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡱ࡯ࡶࡦࡶࡹࡣࡦࡲ࡬ࠧࡶ࡬ࡸࡱ࡫࠽ࡂ࡮࡯࠯ࡨ࡮ࡡ࡯ࡰࡨࡰࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࠔ") % l1l1ll_opy_)
    return l1llll1_opy_
def l1lll_opy_(url):
    if url.startswith(l1ll11_opy_ (u"ࠫࡍࡊࡔࡗ࠴࠽ࠫࠕ")):
        return l1ll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢ࡫ࡳࡸࡻ࠭ࠖ")
    if url.startswith(l1ll11_opy_ (u"࠭ࡈࡅࡖ࡙࠷࠿࠭ࠗ")):
        return l1ll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤࡸࡻ࠭࠘")
def createINI(url):
    HOME = dixie.PROFILE
    l1l1_opy_ = l1ll11_opy_ (u"ࠨࡪࡧࡸࡻࡳࡡࡴࡶࡨࡶ࠳࡯࡮ࡪࠩ࠙")
    l1l_opy_  = os.path.join(HOME, l1l1_opy_)
    addon = l1lll_opy_(url)
    response = json.load(open(PATH))
    result   = response[l1ll11_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩࠚ")]
    l11111_opy_ = result[l1ll11_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩࠛ")]
    l1ll_opy_  = file(l1l_opy_, l1ll11_opy_ (u"ࠫࡼ࠭ࠜ"))
    l1ll_opy_.write(l1ll11_opy_ (u"ࠬࡡࠧࠝ"))
    l1ll_opy_.write(addon)
    l1ll_opy_.write(l1ll11_opy_ (u"࠭࡝ࠨࠞ"))
    l1ll_opy_.write(l1ll11_opy_ (u"ࠧ࡝ࡰࠪࠟ"))
    for channel in l11111_opy_:
        l1llll_opy_    = channel[l1ll11_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࠠ")].replace(l1ll11_opy_ (u"ࠩࠣࠤࠬࠡ"), l1ll11_opy_ (u"ࠪࠤࠬࠢ")).replace(l1ll11_opy_ (u"ࠫࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࠣ"), l1ll11_opy_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࠤ"))
        l111l1_opy_  = l1llll_opy_.rsplit(l1ll11_opy_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࠥ"), 1)[0].split(l1ll11_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡸࡪ࡬ࡸࡪࡣࠧࠦ"), 1)[-1]
        l11l1l_opy_ = channel[l1ll11_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ࠧ")]
        if l1ll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡪࡧࡸࡻ࠭ࠨ") in channel[l1ll11_opy_ (u"ࠪࡪ࡮ࡲࡥࠨࠩ")]:
            l11l1l_opy_ = l1ll11_opy_ (u"ࠫࡍࡊࡔࡗ࠼ࠪࠪ") + l111l1_opy_
        if l1ll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢ࡫ࡳࡸࡻ࠭ࠫ") in channel[l1ll11_opy_ (u"࠭ࡦࡪ࡮ࡨࠫࠬ")]:
            l11l1l_opy_ = l1ll11_opy_ (u"ࠧࡉࡆࡗ࡚࠷ࡀࠧ࠭") + l111l1_opy_
        if l1ll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥࡹࡼࠧ࠮") in channel[l1ll11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧ࠯")]:
            l11l1l_opy_ = l1ll11_opy_ (u"ࠪࡌࡉ࡚ࡖ࠳࠼ࠪ࠰") + l111l1_opy_
        l1ll_opy_.write(l1ll11_opy_ (u"ࠫࠪࡹࠧ࠱") % l111l1_opy_)
        l1ll_opy_.write(l1ll11_opy_ (u"ࠬࡃࠧ࠲"))
        l1ll_opy_.write(l1ll11_opy_ (u"࠭ࠥࡴࠩ࠳") % l11l1l_opy_)
        l1ll_opy_.write(l1ll11_opy_ (u"ࠧ࡝ࡰࠪ࠴"))
    l1ll_opy_.write(l1ll11_opy_ (u"ࠨ࡞ࡱࠫ࠵"))
    l1ll_opy_.close()
def l11ll1_opy_(url):
    name   = dixie.TITLE + l1ll11_opy_ (u"ࠩࠣࡌࡉ࡚ࡖࠡࡗࡳࡨࡦࡺࡥࠨ࠶")
    l1l11_opy_ = os.path.join(dixie.HOME, l1ll11_opy_ (u"ࠪ࡬ࡩࡺࡶ࠯ࡲࡼࠫ࠷"))
    args   = url
    cmd    = l1ll11_opy_ (u"ࠫࡆࡲࡡࡳ࡯ࡆࡰࡴࡩ࡫ࠩࠧࡶ࠰ࠥࡘࡵ࡯ࡕࡦࡶ࡮ࡶࡴࠩࠧࡶ࠰ࠥࠫࡳࠪ࠮ࠣࠩࡩ࠲ࠠࡕࡴࡸࡩ࠮࠭࠸") % (name, l1l11_opy_, args, l11ll_opy_)
    xbmc.executebuiltin(l1ll11_opy_ (u"ࠬࡉࡡ࡯ࡥࡨࡰࡆࡲࡡࡳ࡯ࠫࠩࡸ࠲ࡔࡳࡷࡨ࠭ࠬ࠹") % name)
    xbmc.executebuiltin(cmd)
def l1ll1_opy_(l1ll1l_opy_):
    now = datetime.datetime.today()
    dixie.SetSetting(l1ll1l_opy_, str(now))
def l1111l_opy_(e):
    l1111_opy_ = l1ll11_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠱ࠦࡡ࡯ࠢࡨࡶࡷࡵࡲࠡࡱࡦࡧࡺࡸࡥࡥ࠼ࠣࡎࡘࡕࡎࠡࡇࡵࡶࡴࡸ࠺ࠡࠧࡶࠫ࠺")  %e
    l11l_opy_ = l1ll11_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡳࡧ࠰ࡰ࡮ࡴ࡫ࠡࡶ࡫࡭ࡸࠦࡣࡩࡣࡱࡲࡪࡲࠠࡢࡰࡧࠤࡹࡸࡹࠡࡣࡪࡥ࡮ࡴ࠮ࠨ࠻")
    l11l1_opy_ = l1ll11_opy_ (u"ࠨࡗࡶࡩ࠿ࠦࡃࡰࡰࡷࡩࡽࡺࠠࡎࡧࡱࡹࠥࡃ࠾ࠡࡔࡨࡱࡴࡼࡥࠡࡕࡷࡶࡪࡧ࡭ࠨ࠼")
    dixie.log(e)
    dixie.DialogOK(l1111_opy_, l11l_opy_, l11l1_opy_)
    dixie.SetSetting(SETTING, l1ll11_opy_ (u"ࠩࠪ࠽"))
if __name__ == l1ll11_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬ࠾"):
    url = sys.argv[1]
    doJSON(url)