# coding: UTF-8
import sys
l1l1l1l_opy_ = sys.version_info [0] == 2
l111l1_opy_ = 2048
l1111_opy_ = 7
def l11l1l_opy_ (ll_opy_):
	global l111ll_opy_
	l1l1ll1_opy_ = ord (ll_opy_ [-1])
	l11lll_opy_ = ll_opy_ [:-1]
	l1lll_opy_ = l1l1ll1_opy_ % len (l11lll_opy_)
	l1ll1_opy_ = l11lll_opy_ [:l1lll_opy_] + l11lll_opy_ [l1lll_opy_:]
	if l1l1l1l_opy_:
		l1lllll_opy_ = unicode () .join ([unichr (ord (char) - l111l1_opy_ - (l1l111_opy_ + l1l1ll1_opy_) % l1111_opy_) for l1l111_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1lllll_opy_ = str () .join ([chr (ord (char) - l111l1_opy_ - (l1l111_opy_ + l1l1ll1_opy_) % l1111_opy_) for l1l111_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1lllll_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l1l11ll11_opy_    = l11l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡮ࡵࡸࠪࣸ")
l1l1ll111_opy_    = l11l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡶ࡭ࡷࡹࡷࡱࣹࠧ")
locked = l11l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮ࡲࡧࡰ࡫ࡤࡵࡸࣺࠪ")
l1l11111l_opy_   = l11l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡸࡷ࡫ࡡ࡮ࡶࡹࡦࡴࡾࠧࣻ")
l1l1ll1l1_opy_     = l11l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡵࡵࡲࡵࡵࡰࡥࡳ࡯ࡡࠨࣼ")
l1l1l11l1_opy_     = l11l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡶ࡯ࡳࡶࡶࡲࡦࡺࡩࡰࡰ࡫ࡨࡹࡼࠧࣽ")
l1l111l11_opy_     = l11l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡻ࡬ࡵ࡫ࡰࡥࡹ࡫࡭ࡢࡰ࡬ࡥࠬࣾ")
l11lllll1_opy_   = l11l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡬ࡪࡷࡻ࠲ࡹࡼࠧࣿ")
l1l11l11l_opy_    = l11l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡅࡅࡖࡴࡴࡸࡴࡴࠩऀ")
l1l1l1lll_opy_ = l11l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡨࡦࡴࡵࡴࠨँ")
l1l11l1l1_opy_    = l11l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡦࡰࡺ࡯ࡰࡵࡸࠪं")
l1l11ll1l_opy_ = l11l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡹࡸࡥࡢ࡯ࡶࡩࡦࡹࡹ࠯ࡶࡹࠫः")
l1l1l1l11_opy_ = l11l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢ࡫ࡳࡸࡻ࠭ऄ")
l1l111l_opy_ = [l1l11ll11_opy_, locked, l11lllll1_opy_, l1l11ll1l_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l11l1l_opy_ (u"࠭ࡩ࡯࡫ࠪअ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1ll111_opy_ = l11l1l_opy_ (u"ࠧࠨआ")
def l1l1111_opy_(i, t1, l1l1lll_opy_=[]):
 t = l1ll111_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l1lll_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1l1l_opy_ = l1l1111_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11_opy_ = l1l1111_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1l111l_opy_:
        if l1l11l1_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1l11l1_opy_(addon):
    if xbmc.getCondVisibility(l11l1l_opy_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫࠩࡸ࠯ࠧइ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l1111l_opy_ = str(addon).split(l11l1l_opy_ (u"ࠩ࠱ࠫई"))[2] + l11l1l_opy_ (u"ࠪ࠲࡮ࡴࡩࠨउ")
    l1l_opy_  = os.path.join(PATH, l1111l_opy_)
    try:
        l1ll1ll_opy_ = l1l1llll1_opy_(addon)
    except KeyError:
        dixie.log(l11l1l_opy_ (u"ࠫ࠲࠳࠭࠮࠯ࠣࡏࡪࡿࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡩࡨࡸࡋ࡯࡬ࡦࡵࠣ࠱࠲࠳࠭࠮ࠢࠪऊ") + addon)
        result = {l11l1l_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࡷࠬऋ"): [{l11l1l_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩऌ"): l11l1l_opy_ (u"ࡵࠨࡨ࡬ࡰࡪ࠭ऍ"), l11l1l_opy_ (u"ࡶࠩࡷࡽࡵ࡫ࠧऎ"): l11l1l_opy_ (u"ࡷࠪࡹࡳࡱ࡮ࡰࡹࡱࠫए"), l11l1l_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࠩऐ"): l11l1l_opy_ (u"ࡹࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸࡹࡺࠪऑ"), l11l1l_opy_ (u"ࡺ࠭࡬ࡢࡤࡨࡰࠬऒ"): l11l1l_opy_ (u"ࡻࠧࡏࡑࠣࡇࡍࡇࡎࡏࡇࡏࡗࠬओ")}], l11l1l_opy_ (u"ࡵࠨ࡮࡬ࡱ࡮ࡺࡳࠨऔ"):{l11l1l_opy_ (u"ࡶࠩࡶࡸࡦࡸࡴࠨक"): 0, l11l1l_opy_ (u"ࡷࠪࡸࡴࡺࡡ࡭ࠩख"): 1, l11l1l_opy_ (u"ࡸࠫࡪࡴࡤࠨग"): 1}}
    l1ll1l1_opy_  = file(l1l_opy_, l11l1l_opy_ (u"ࠫࡼ࠭घ"))
    l1ll1l1_opy_.write(l11l1l_opy_ (u"ࠬࡡࠧङ"))
    l1ll1l1_opy_.write(addon)
    l1ll1l1_opy_.write(l11l1l_opy_ (u"࠭࡝ࠨच"))
    l1ll1l1_opy_.write(l11l1l_opy_ (u"ࠧ࡝ࡰࠪछ"))
    l1lll1_opy_ = []
    for channel in l1ll1ll_opy_:
        l1l11l_opy_    = channel[l11l1l_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧज")].replace(l11l1l_opy_ (u"ࠩ࡞ࡆࡢࡡࡃࡐࡎࡒࡖࠥࡽࡨࡪࡶࡨࡡࠬझ"), l11l1l_opy_ (u"ࠪࠫञ")).replace(l11l1l_opy_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࡡ࠯ࡃ࡟ࠪट"), l11l1l_opy_ (u"ࠬ࠭ठ")).replace(l11l1l_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡧࡳࡧࡨࡲࡢࡎࡄ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩड"), l11l1l_opy_ (u"ࠧࡉࡆࡇࠫढ"))
        l1l11l_opy_    = l1l11l_opy_.replace(l11l1l_opy_ (u"ࠨࡾࠪण"), l11l1l_opy_ (u"ࠩࠪत")).replace(l11l1l_opy_ (u"ࠪ࠳ࠬथ"), l11l1l_opy_ (u"ࠫࠬद")).replace(l11l1l_opy_ (u"ࠬࠦࠠࠡࠢࠣࠫध"), l11l1l_opy_ (u"࠭ࠠࠨन")).replace(l11l1l_opy_ (u"ࠧ࠯࠰࠱࠲࠳࠭ऩ"), l11l1l_opy_ (u"ࠨࠩप")).replace(l11l1l_opy_ (u"ࠩ࠽ࠫफ"), l11l1l_opy_ (u"ࠪࠫब"))
        l1l11l_opy_    = l1l11l_opy_.replace(l11l1l_opy_ (u"ࠫࡢࠦࠧभ"), l11l1l_opy_ (u"ࠬࡣࠧम")).replace(l11l1l_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡡࡲࡷࡤࡡࠬय"), l11l1l_opy_ (u"ࠧࠨर")).replace(l11l1l_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡹ࡫࡭ࡹ࡫࡝ࠨऱ"), l11l1l_opy_ (u"ࠩࠪल")).replace(l11l1l_opy_ (u"ࠪࠤࡠ࠭ळ"), l11l1l_opy_ (u"ࠫࡠ࠭ऴ"))
        l1l11l_opy_    = l1l11l_opy_.replace(l11l1l_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡲࡩ࡮ࡧࡪࡶࡪ࡫࡮࡞ࠩव"), l11l1l_opy_ (u"࠭ࠧश")).replace(l11l1l_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡺࡧ࡯ࡰࡴࡽ࡝ࠨष"), l11l1l_opy_ (u"ࠨࠩस"))
        l1l11l_opy_    = l1l11l_opy_.replace(l11l1l_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࠨह"), l11l1l_opy_ (u"ࠪࠫऺ")).replace(l11l1l_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡴࡸࡡ࡯ࡩࡨࡡࠬऻ"), l11l1l_opy_ (u"़ࠬ࠭")).replace(l11l1l_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠࠫऽ"), l11l1l_opy_ (u"ࠧࠨा"))
        l1l11l_opy_    = l1l11l_opy_.replace(l11l1l_opy_ (u"ࠨ࡝ࡌࡡࠬि"), l11l1l_opy_ (u"ࠩࠪी")).replace(l11l1l_opy_ (u"ࠪ࡟࠴ࡏ࡝ࠨु"), l11l1l_opy_ (u"ࠫࠬू")).replace(l11l1l_opy_ (u"ࠬࡡࡂ࡞ࠩृ"), l11l1l_opy_ (u"࠭ࠧॄ")).replace(l11l1l_opy_ (u"ࠧ࡜࠱ࡅࡡࠬॅ"), l11l1l_opy_ (u"ࠨࠩॆ"))
        l1lll1l_opy_ = dixie.mapChannelName(l1l11l_opy_)
        stream   = channel[l11l1l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧे")]
        l11ll_opy_ = l1lll1l_opy_ + l11l1l_opy_ (u"ࠪࡁࠬै") + stream
        l1lll1_opy_.append(l11ll_opy_)
        l1lll1_opy_.sort()
    for item in l1lll1_opy_:
        l1ll1l1_opy_.write(l11l1l_opy_ (u"ࠦࠪࡹ࡜࡯ࠤॉ") % item)
    l1ll1l1_opy_.close()
def l1l1llll1_opy_(addon):
    if (addon == l11lllll1_opy_) or (addon == locked):
        return l1l1l111l_opy_(addon)
    l1l111lll_opy_  = l11l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨॊ") + addon
    l1l1l1l1l_opy_ =  l1l1lll1l_opy_(addon)
    query   =  l1l111lll_opy_ + l1l1l1l1l_opy_
    return sendJSON(query, addon)
def l1l1l111l_opy_(addon):
    if addon == l11lllll1_opy_:
        l1l1l11ll_opy_ = [l11l1l_opy_ (u"࠭࠵ࠨो"), l11l1l_opy_ (u"ࠧ࠲࠲࠹ࠫौ"), l11l1l_opy_ (u"ࠨ࠶्ࠪ"), l11l1l_opy_ (u"ࠩ࠵࠺࠸࠭ॎ"), l11l1l_opy_ (u"ࠪ࠵࠸࠸ࠧॏ")]
    if addon == locked:
        l1l1l11ll_opy_ = [l11l1l_opy_ (u"ࠫ࠸࠶ࠧॐ"), l11l1l_opy_ (u"ࠬ࠹࠱ࠨ॑"), l11l1l_opy_ (u"࠭࠳࠳॒ࠩ"), l11l1l_opy_ (u"ࠧ࠴࠵ࠪ॓"), l11l1l_opy_ (u"ࠨ࠵࠷ࠫ॔"), l11l1l_opy_ (u"ࠩ࠶࠹ࠬॕ"), l11l1l_opy_ (u"ࠪ࠷࠽࠭ॖ"), l11l1l_opy_ (u"ࠫ࠹࠶ࠧॗ"), l11l1l_opy_ (u"ࠬ࠺࠱ࠨक़"), l11l1l_opy_ (u"࠭࠴࠶ࠩख़"), l11l1l_opy_ (u"ࠧ࠵࠹ࠪग़"), l11l1l_opy_ (u"ࠨ࠶࠼ࠫज़"), l11l1l_opy_ (u"ࠩ࠸࠶ࠬड़")]
    login = l11l1l_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠦࡵ࠲ࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩढ़") % addon
    xbmc.executeJSONRPC(login)
    l1_opy_ = []
    for l1l1ll11l_opy_ in l1l1l11ll_opy_:
        if addon == l11lllll1_opy_:
            l1l1l1ll1_opy_ = l11l1l_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡭࡫ࡸࡼ࠳ࡺࡶ࠰ࡁࡰࡳࡩ࡫࡟ࡪࡦࡀࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡳ࡯ࡥࡧࡀࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡹࡥࡤࡶ࡬ࡳࡳࡥࡩࡥ࠿ࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪफ़") % l1l1ll11l_opy_
        if addon == locked:
            l1l1l1ll1_opy_ = l11l1l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮ࡲࡧࡰ࡫ࡤࡵࡸ࠲ࡃࡺࡸ࡬࠾ࠧࡶࠪࡲࡵࡤࡦ࠿࠷ࠪࡳࡧ࡭ࡦ࠿ࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦࡱ࡮ࡤࡽࡂࠬࡤࡢࡶࡨࡁࠫࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࡀࠪࡵࡧࡧࡦ࠿ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨय़") % l1l1ll11l_opy_
        l1l11lll1_opy_  = xbmc.executeJSONRPC(l1l1l1ll1_opy_)
        response = json.loads(l1l11lll1_opy_)
        l1_opy_.extend(response[l11l1l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ॠ")][l11l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ॡ")])
    return l1_opy_
def sendJSON(query, addon):
    l1l1l1ll1_opy_     = l11l1l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫॢ") % query
    l1l11lll1_opy_  = xbmc.executeJSONRPC(l1l1l1ll1_opy_)
    response = json.loads(l1l11lll1_opy_)
    result   = response[l11l1l_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩॣ")]
    return result[l11l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩ।")]
def l1l11l1ll_opy_(addon):
    l1l111lll_opy_ = l11l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ॥") + addon
    l11llll1l_opy_  = l11l1l_opy_ (u"ࠬࡅࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࡩࡶࡷࡴࠪ࠹ࡡࠦ࠴ࡩࠩ࠷࡬࡭ࡦࡶࡤࡰࡰ࡫ࡴࡵ࡮ࡨ࠲ࡨࡵࠥ࠳ࡨࡘࡏ࡙ࡻࡲ࡬࠳࠻࠴࠷࠸࠰࠲࠸ࠨ࠶࡫ࡺࡨࡶ࡯ࡥࡷࠪ࠸ࡦ࡯ࡧࡺࠩ࠷࡬ࡕ࡬ࠧ࠵࠹࠷࠶ࡴࡶࡴ࡮ࠩ࠷࠻࠲࠱ࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠪ࠸࠵࠳࠲࡯࡭ࡻ࡫ࠥ࠳࠷࠵࠴ࡹࡼ࠮࡫ࡲࡪࠪࡲࡵࡤࡦ࠿࠴ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡻ࡫ࠥ࠳࠲ࡗ࡚ࠫࡻࡲ࡭࠿࡫ࡸࡹࡶࠥ࠴ࡣࠨ࠶࡫ࠫ࠲ࡧ࡯ࡨࡸࡦࡲ࡫ࡦࡶࡷࡰࡪ࠴ࡣࡰࠧ࠵ࡪ࡚ࡑࡔࡶࡴ࡮࠵࠽࠶࠲࠳࠲࠴࠺ࠪ࠸ࡦࡍ࡫ࡹࡩࠪ࠸࠵࠳࠲ࡗ࡚࠳ࡺࡸࡵࠩ०")
    l1_opy_  = []
    l1_opy_ += sendJSON(l1l111lll_opy_ + l11llll1l_opy_, addon)
    l1_opy_.sort()
    return l1_opy_
def l1l1lll11_opy_(addon):
    l1l111lll_opy_ = l11l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ१") + addon
    l11llll1l_opy_ = l11l1l_opy_ (u"ࠧ࠰ࡁࡩࡥࡳࡧࡲࡵ࠿࡫ࡸࡹࡶࠥ࠴ࡣࠨ࠶࡫ࠫ࠲ࡧࡩࡲࡳ࠳࡭࡬ࠦ࠴ࡩ࡜ࡩࡌ࠲࠹ࡖࠩࡱࡴࡪࡥ࠾࠳ࠩࡲࡦࡳࡥ࠾ࡎ࡬ࡺࡪࠫ࠲࠱ࡗࡎࠩ࠷࠶ࡓࡱࡱࡵࡸࡸࠬࡵࡳ࡮ࡀ࡬ࡹࡺࡰࡴࠧ࠶ࡥࠪ࠸ࡦࠦ࠴ࡩ࡫ࡴࡵ࠮ࡨ࡮ࠨ࠶࡫࠻ࡱࡒࡩࡈ࠸ࠬ२")
    l11llllll_opy_ = l11l1l_opy_ (u"ࠨ࠱ࡂࡪࡦࡴࡡࡳࡶࡀ࡬ࡹࡺࡰࡴࠧ࠶ࡥࠪ࠸ࡦࠦ࠴ࡩ࡫ࡴࡵ࠮ࡨ࡮ࠨ࠶࡫ࡌࡧࡘࡏ࡮࡞ࠫࡳ࡯ࡥࡧࡀ࠵ࠫࡴࡡ࡮ࡧࡀࡐ࡮ࡼࡥࠦ࠴࠳࡙ࡘࠫ࠲ࡧࡅࡄࡒࠪ࠸࠰ࡔࡲࡲࡶࡹࡹࠦࡶࡴ࡯ࡁ࡭ࡺࡴࡱࡵࠨ࠷ࡦࠫ࠲ࡧࠧ࠵ࡪ࡬ࡵ࡯࠯ࡩ࡯ࠩ࠷࡬ࡦ࠺࡬ࡪ࠼ࡓ࠭३")
    l1_opy_  = []
    l1_opy_ += sendJSON(l1l111lll_opy_ + l11llll1l_opy_, addon)
    l1_opy_ += sendJSON(l1l111lll_opy_ + l11llllll_opy_, addon)
    return l1_opy_
def l1l1lll1l_opy_(addon):
    if addon == l1l11ll11_opy_:
        return l11l1l_opy_ (u"ࠩ࠲ࡃࡨࡧࡴ࠾࠯࠵ࠪࡩࡧࡴࡦࠨࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠦࡦࡰࡧࡈࡦࡺࡥࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡳ࡯ࡥࡧࡀ࠶ࠫࡴࡡ࡮ࡧࡀࡑࡾࠫ࠲࠱ࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠩࡶࡪࡩ࡯ࡳࡦࡱࡥࡲ࡫ࠦࡴࡶࡤࡶࡹࡊࡡࡵࡧࠩࡹࡷࡲ࠽ࡶࡴ࡯ࠫ४")
    if addon == l1l1l1l11_opy_:
        return l11l1l_opy_ (u"ࠪ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡲࡩࡷࡧࡷࡺࡤࡧ࡬࡭ࠨࡨࡼࡹࡸࡡࠧࡲࡤ࡫ࡪࠬࡰ࡭ࡱࡷࠪࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠽ࠧࡶ࡬ࡸࡱ࡫࠽ࡂ࡮࡯ࠩ࠷࠶ࡣࡩࡣࡱࡲࡪࡲࡳࠧࡷࡵࡰࠬ५")
    return l11l1l_opy_ (u"ࠫࠬ६")
def l11l1_opy_():
    modules = map(__import__, [l1l1111_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1l1l_opy_)):
        return l11l1l_opy_ (u"࡚ࠬࡲࡶࡧࠪ७")
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l11l1l_opy_ (u"࠭ࡔࡳࡷࡨࠫ८")
    return l11l1l_opy_ (u"ࠧࡇࡣ࡯ࡷࡪ࠭९")
def l1lll11_opy_(e, addon):
    l1l1l1_opy_ = l11l1l_opy_ (u"ࠨࡕࡲࡶࡷࡿࠬࠡࡣࡱࠤࡪࡸࡲࡰࡴࠣࡳࡨࡩࡵࡳࡧࡧ࠾ࠥࡐࡓࡐࡐࠣࡉࡷࡸ࡯ࡳ࠼ࠣࠩࡸ࠲ࠠࠦࡵࠪ॰")  % (e, addon)
    l1l1ll_opy_ = l11l1l_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡹࡸࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡦࡰࡴࡸࡱ࠳࠭ॱ")
    l1ll11_opy_ = l11l1l_opy_ (u"࡙ࠪࡵࡲ࡯ࡢࡦࠣࡥࠥࡲ࡯ࡨࠢࡹ࡭ࡦࠦࡴࡩࡧࠣࡥࡩࡪ࡯࡯ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠤࡦࡴࡤࠡࡲࡲࡷࡹࠦࡴࡩࡧࠣࡰ࡮ࡴ࡫࠯ࠩॲ")
    dixie.log(addon)
    dixie.log(e)
def getPlaylist():
    import requests
    l1l11llll_opy_ = [l11l1l_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱ࡋࡉ࡟࠻࡚ࡺ࡫ࡍࡩ࡜࠭ॳ"), l11l1l_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲ࡼ࡫࠻ࡉ࠴ࡊࡒࡨ࡞ࡔࠧॴ"), l11l1l_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳࡚ࡒࡣ࠱࠳ࡐࡓࡑ࡭ࡃࠨॵ"), l11l1l_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡹ࠰ࡦࡳ࠴ࡰࡵࡏࡏࡑ࡫ࡼࡰࡐ࠱ࠩॶ"), l11l1l_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡺ࠱ࡧࡴ࠵ࡤ࡫ࡄࡤ࠵ࡳࡼ࠹ࡈࡼࠪॷ"), l11l1l_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡻ࠲ࡨࡵ࠯࡯ࡘࡶࡵࡨ࡭ࡣࡤ࠻ࡼࠫॸ"), l11l1l_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡼ࠳ࡩ࡯࠰ࡺࡏࡇ࠾࠺ࡅࡗࡓࡹ࡝ࠬॹ"), l11l1l_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱ࡷࡷࡊ࠹ࡊࡑࡶࡩࡑࡷ࠭ॺ"), l11l1l_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲ࡩ࡛࡜ࡁࡸࡍࡌࡷࡘ࡮ࠧॻ"), l11l1l_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳ࡽࡗࡰࡇࡌ࡚࡫࡮࡭ࡪࠨॼ")]
    l1l111ll1_opy_ =  l11l1l_opy_ (u"ࠧࠤࡇ࡛ࡘࡒ࠹ࡕࠨॽ")
    for url in l1l11llll_opy_:
        try:
            request  = requests.get(url)
            l1l1ll1ll_opy_ = request.text
        except: pass
        if l1l111ll1_opy_ in l1l1ll1ll_opy_:
            path = os.path.join(dixie.PROFILE, l11l1l_opy_ (u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡱ࠸ࡻࠧॾ"))
            with open(path, l11l1l_opy_ (u"ࠩࡺࠫॿ")) as f:
                f.write(l1l1ll1ll_opy_)
                break
def getPluginInfo(streamurl):
    if not l11l1_opy_() == l11l1l_opy_ (u"ࠪࡘࡷࡻࡥࠨঀ"):
        return
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l1l1111ll_opy_   = l11l1l_opy_ (u"ࠫࡐࡵࡤࡪࠢࡓ࡚ࡗ࠭ঁ")
            l1l111l1l_opy_ = os.path.join(dixie.RESOURCES, l11l1l_opy_ (u"ࠬࡱ࡯ࡥ࡫࠰ࡴࡻࡸ࠮ࡱࡰࡪࠫং"))
            return l1l1111ll_opy_, l1l111l1l_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l11l1l_opy_ (u"࠭ࡲࡵ࡯ࡳࠫঃ")) or url.startswith(l11l1l_opy_ (u"ࠧࡳࡶࡰࡴࡪ࠭঄")) or url.startswith(l11l1l_opy_ (u"ࠨࡴࡷࡷࡵ࠭অ")) or url.startswith(l11l1l_opy_ (u"ࠩ࡫ࡸࡹࡶࠧআ")):
            l1l1111ll_opy_   = l11l1l_opy_ (u"ࠪࡱ࠸ࡻࠠࡑ࡮ࡤࡽࡱ࡯ࡳࡵࠩই")
            l1l111l1l_opy_ = os.path.join(dixie.RESOURCES, l11l1l_opy_ (u"ࠫ࡮ࡶࡴࡷ࠯ࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡵࡴࡧࠨঈ"))
            return l1l1111ll_opy_, l1l111l1l_opy_
    except:
        pass
    if streamurl.startswith(dixie.OPEN_OTT):
        name = streamurl.split(l11l1l_opy_ (u"ࠬࡣࡏࡕࡖࡢࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭উ"), 1)[-1].split(l11l1l_opy_ (u"࠭࠯ࠨঊ"), 1)[0]
    if l11l1l_opy_ (u"ࠧ࡞ࡑࡗࡘࡤࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨঋ") in streamurl:
        name = streamurl.split(l11l1l_opy_ (u"ࠨ࡟ࡒࡘ࡙ࡥࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩঌ"), 1)[-1].split(l11l1l_opy_ (u"ࠩ࠲ࠫ঍"), 1)[0]
    if streamurl.startswith(l11l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭঎")):
        name = streamurl.split(l11l1l_opy_ (u"ࠫ࠴࠵ࠧএ"), 1)[-1].split(l11l1l_opy_ (u"ࠬ࠵ࠧঐ"), 1)[0]
    if l11l1l_opy_ (u"࠭࡟ࡠࡕࡉࡣࡤ࠭঑") in streamurl:
        name = l11l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡱࡴࡲ࡫ࡷࡧ࡭࠯ࡵࡸࡴࡪࡸ࠮ࡧࡣࡹࡳࡺࡸࡩࡵࡧࡶࠫ঒")
    if l11l1l_opy_ (u"ࠨࡊࡇࡘ࡛ࡀࠧও") in streamurl:
        name = l11l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡰࡥࡷࡺࡨࡶࡤࠪঔ")
    if l11l1l_opy_ (u"ࠪࡌࡉ࡚ࡖ࠳࠼ࠪক") in streamurl:
        name = l11l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡺࡿࡡࡪࡲࡷࡺࠬখ")
    if l11l1l_opy_ (u"ࠬࡎࡄࡕࡘ࠶࠾ࠬগ") in streamurl:
        name = l11l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡵࡺࡣࡷࡺࠬঘ")
    if l11l1l_opy_ (u"ࠧࡉࡆࡗ࡚࠹ࡀࠧঙ") in streamurl:
        name = l11l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡹ࡮ࠪচ")
    if l11l1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙࠻ࠩছ") in streamurl:
        name = l11l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡥࡦࡨ࡯ࡰ࡭ࡣࡼࡩࡷ࠭জ")
    if l11l1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛࠵࠾ࠬঝ") in streamurl:
        name = l11l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶ࡬ࡢࡻࡨࡶࡼࡽࡷࠨঞ")
    if l11l1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡗࡀࠧট") in streamurl:
        name = l11l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱ࡮ࡤࡽࡪࡸࡷࡸࡹࠪঠ")
    if l11l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡉࡕࡘ࠽ࠫড") in streamurl:
        name = l11l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡷࡺࠬঢ")
    if l11l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡆ࠽ࠫণ") in streamurl:
        name = l11l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡨࡪࡾࠧত")
    if l11l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖࡇࡀࠧথ") in streamurl:
        name = l11l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡥࡣࡱࡲࡸࠬদ")
    if l11l1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡉࡌࡖ࠼ࠪধ") in streamurl:
        name = l11l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡤ࡮ࡸ࡭ࡵࡺࡶࠨন")
    if l11l1l_opy_ (u"ࠩࡌࡔ࡙࡙ࠧ঩") in streamurl:
        name = l11l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧࡩࡱࡶࡹࠫপ")
    if l11l1l_opy_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠾ࠬফ") in streamurl:
        name = l11l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡱ࡯ࡶࡦ࡯࡬ࡼࠬব")
    if (l11l1l_opy_ (u"࠭ࡆࡍࡃ࠽ࠫভ")) or (l11l1l_opy_ (u"ࠧࡇࡎࡄࡗ࠿࠭ম")) in streamurl:
        name = l11l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡇ࡮ࡤࡻࡱ࡫ࡳࡴࡖࡹࠫয")
    if l11l1l_opy_ (u"ࠩࡸࡴࡳࡶ࠺ࠨর") in streamurl:
        name = l11l1l_opy_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱࡬ࡩ࡮࡯࡮ࡧࡵࡹࡳ࠴ࡶࡪࡧࡺࠫ঱")
    try:
        l1l1111ll_opy_   = xbmcaddon.Addon(name).getAddonInfo(l11l1l_opy_ (u"ࠫࡳࡧ࡭ࡦࠩল"))
        l1l111l1l_opy_ = xbmcaddon.Addon(name).getAddonInfo(l11l1l_opy_ (u"ࠬ࡯ࡣࡰࡰࠪ঳"))
    except:
        l1l1111ll_opy_   = l11l1l_opy_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡔࡱࡸࡶࡨ࡫ࠧ঴")
        l1l111l1l_opy_ =  dixie.ICON
    return l1l1111ll_opy_, l1l111l1l_opy_
def selectStream(url, channel):
    url = url.replace(l11l1l_opy_ (u"ࠧࡽࡷࡶࡩࡷ࠳ࡡࡨࡧࡱࡸࠬ঵"), l11l1l_opy_ (u"ࠨ࠯࠰ࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧশ"))
    l1l1111l1_opy_ = url.split(l11l1l_opy_ (u"ࠩࡿࠫষ"))
    if len(l1l1111l1_opy_) == 0:
        return None
    options, l1l111111_opy_ = getOptions(l1l1111l1_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l1l1111l1_opy_) == 1:
            return l1l111111_opy_[0]
    import selectDialog
    l1l1l1111_opy_ = selectDialog.select(l11l1l_opy_ (u"ࠪࡗࡪࡲࡥࡤࡶࠣࡥࠥࡹࡴࡳࡧࡤࡱࠬস"), options)
    if l1l1l1111_opy_ < 0:
        raise Exception(l11l1l_opy_ (u"ࠫࡘ࡫࡬ࡦࡥࡷ࡭ࡴࡴࠠࡄࡣࡱࡧࡪࡲࠧহ"))
    return l1l111111_opy_[l1l1l1111_opy_]
def getOptions(l1l1111l1_opy_, channel, addmore=True):
    if not l11l1_opy_() == l11l1l_opy_ (u"࡚ࠬࡲࡶࡧࠪ঺"):
        return
    options = []
    l1l111111_opy_    = []
    for index, stream in enumerate(l1l1111l1_opy_):
        l1l1111ll_opy_ = getPluginInfo(stream)
        l1l11l_opy_ = l1l1111ll_opy_[0]
        l1l11l111_opy_  = l1l1111ll_opy_[1]
        l1l11l_opy_  = l11l1l_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡯ࡳࡣࡱ࡫ࡪࡣ࡛ࠨ঻") + l1l11l_opy_ + l11l1l_opy_ (u"ࠧ࡞࡝࠲ࡇࡔࡒࡏࡓ࡟়ࠣࠫ")
        if stream.startswith(OPEN_OTT):
            l1l11l_opy_  = l1l11l_opy_ + stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l11l1l_opy_ (u"ࠨࠩঽ"))
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l11l1l_opy_ (u"ࠩࠪা"))
        else:
            l1l11l_opy_  = l1l11l_opy_ + channel
        options.append([l1l11l_opy_, index, l1l11l111_opy_])
        l1l111111_opy_.append(stream)
    if addmore:
        options.append([l11l1l_opy_ (u"ࠪࡅࡩࡪࠠ࡮ࡱࡵࡩ࠳࠴࠮ࠨি"), index + 1, dixie.ICON])
        l1l111111_opy_.append(l11l1l_opy_ (u"ࠫࡦࡪࡤࡎࡱࡵࡩࠬী"))
    return options, l1l111111_opy_