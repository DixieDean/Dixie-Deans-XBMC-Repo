# coding: UTF-8
import sys
l1l1l1l_opy_ = sys.version_info [0] == 2
l111l1_opy_ = 2048
l1111_opy_ = 7
def l11l1l_opy_ (ll_opy_):
	global l111ll_opy_
	l1l1ll1_opy_ = ord (ll_opy_ [-1])
	l11lll_opy_ = ll_opy_ [:-1]
	l1lll_opy_ = l1l1ll1_opy_ % len (l11lll_opy_)
	l1ll1_opy_ = l11lll_opy_ [:l1lll_opy_] + l11lll_opy_ [l1lll_opy_:]
	if l1l1l1l_opy_:
		l1lllll_opy_ = unicode () .join ([unichr (ord (char) - l111l1_opy_ - (l1l111_opy_ + l1l1ll1_opy_) % l1111_opy_) for l1l111_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1lllll_opy_ = str () .join ([chr (ord (char) - l111l1_opy_ - (l1l111_opy_ + l1l1ll1_opy_) % l1111_opy_) for l1l111_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1lllll_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
l1ll111_opy_ = l11l1l_opy_ (u"ࠫࠬࠀ")
def l1l1111_opy_(i, t1, l1l1lll_opy_=[]):
 t = l1ll111_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l1lll_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1l1l_opy_ = l1l1111_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11_opy_ = l1l1111_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1llll1_opy_ = l11l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡋࡲࡡࡸ࡮ࡨࡷࡸ࡚ࡶࠨࠁ")
dexter   = l11l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡪࡥࡹࠩࠂ")
l1l111l_opy_   = [l1llll1_opy_, dexter]
def checkAddons():
    for addon in l1l111l_opy_:
        if l1l11l1_opy_(addon):
            createINI(addon)
def l1l11l1_opy_(addon):
    if xbmc.getCondVisibility(l11l1l_opy_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡉࡣࡶࡅࡩࡪ࡯࡯ࠪࠨࡷ࠮࠭ࠃ") % addon) == 1:
        return True
    else:
        return False
def createINI(addon):
    HOME  = dixie.PROFILE
    l111l_opy_ = os.path.join(HOME, l11l1l_opy_ (u"ࠨ࡫ࡱ࡭ࠬࠄ"))
    l1111l_opy_  = str(addon).split(l11l1l_opy_ (u"ࠩ࠱ࠫࠅ"))[2] + l11l1l_opy_ (u"ࠪ࠲࡮ࡴࡩࠨࠆ")
    l1l_opy_   = os.path.join(l111l_opy_, l1111l_opy_)
    response = doJSON(addon)
    l1ll1ll_opy_ = response[l11l1l_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫࠇ")][l11l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫࠈ")]
    l11ll1_opy_  = l11l1l_opy_ (u"࡛࠭ࠨࠉ") + addon + l11l1l_opy_ (u"ࠧ࡞࡞ࡱࠫࠊ")
    l1ll1l1_opy_  =  file(l1l_opy_, l11l1l_opy_ (u"ࠨࡹࠪࠋ"))
    l1ll1l1_opy_.write(l11ll1_opy_)
    l1lll1_opy_ = []
    for channel in l1ll1ll_opy_:
        l1l1l11_opy_  = channel[l11l1l_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨࠌ")]
        l1l1l11_opy_  = l1l1l11_opy_.split(l11l1l_opy_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࠍ"), 1)[0]
        l1l1l11_opy_  = l1l1l11_opy_.replace(l11l1l_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡼ࡮ࡩࡵࡧࡠࠫࠎ"), l11l1l_opy_ (u"ࠬ࠭ࠏ"))
        l1l11ll_opy_  = l1l11_opy_(l1l1l11_opy_, addon)
        l1llll_opy_ = l1ll1l_opy_(addon)
        l1lll1l_opy_  = dixie.mapChannelName(l1l11ll_opy_)
        stream    = l1llll_opy_ + l1l1l11_opy_
        l11ll_opy_   = l1lll1l_opy_ + l11l1l_opy_ (u"࠭࠽ࠨࠐ") + stream
        if l11ll_opy_ not in l1lll1_opy_:
            l1lll1_opy_.append(l11ll_opy_)
    l1lll1_opy_.sort()
    for item in l1lll1_opy_:
        l1ll1l1_opy_.write(l11l1l_opy_ (u"ࠢࠦࡵ࡟ࡲࠧࠑ") % item)
    l1ll1l1_opy_.close()
def l1ll1l_opy_(addon):
    if addon == l1llll1_opy_:
        return l11l1l_opy_ (u"ࠨࡈࡏࡅ࠿࠭ࠒ")
    if addon == dexter:
        return l11l1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪࠓ")
def l1l11_opy_(l1l11l_opy_, addon):
    if addon == l1llll1_opy_:
        l1l11l_opy_ = l1l11l_opy_.replace(l11l1l_opy_ (u"ࠪࠤࠥ࠭ࠔ"), l11l1l_opy_ (u"ࠫࠬࠕ"))
        l1l11l_opy_ = l1l11l_opy_.replace(l11l1l_opy_ (u"࡛ࠬࡋ࠻ࠢࠪࠖ"), l11l1l_opy_ (u"࠭ࠧࠗ"))
        l1l11l_opy_ = l1l11l_opy_.replace(l11l1l_opy_ (u"ࠧࡖࡕࡄ࠾ࠥ࠭࠘"), l11l1l_opy_ (u"ࠨࠩ࠙"))
        l1l11l_opy_ = l1l11l_opy_.replace(l11l1l_opy_ (u"ࠩࡆࡅ࠿ࠦࠧࠚ"), l11l1l_opy_ (u"ࠪࠫࠛ"))
        l1l11l_opy_ = l1l11l_opy_.replace(l11l1l_opy_ (u"ࠫࡎࡔࡔ࠻ࠢࠪࠜ"), l11l1l_opy_ (u"ࠬ࠭ࠝ"))
        return l1l11l_opy_
    if addon == dexter:
        l1l11l_opy_ = l1l11l_opy_.replace(l11l1l_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡳ࡬ࡻࡥࡰࡺ࡫࡝࡜ࡄࡠ࡙ࡘࡇࠠ࡜ࡅࡒࡐࡔࡘࠠࡰ࡮ࡧࡰࡦࡩࡥ࡞ࠩࠞ"), l11l1l_opy_ (u"ࠧࠨࠟ"))
        l1l11l_opy_ = l1l11l_opy_.replace(l11l1l_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡲࡤࡰࡪ࡭ࡲࡦࡧࡱࡡࡠࡈ࡝࠳࠶࠺ࠤࡠࡉࡏࡍࡑࡕࠤࡴࡲࡤ࡭ࡣࡦࡩࡢ࠭ࠠ"), l11l1l_opy_ (u"ࠩࠪࠡ"))
        l1l11l_opy_ = l1l11l_opy_.replace(l11l1l_opy_ (u"ࠪ࡟࠴ࡈ࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࠪࠢ"), l11l1l_opy_ (u"ࠫࠬࠣ"))
        l1l11l_opy_ = l1l11l_opy_.replace(l11l1l_opy_ (u"ࠬࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫࠤ"), l11l1l_opy_ (u"࠭ࠧࠥ"))
        l1l11l_opy_ = l1l11l_opy_.replace(l11l1l_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡺࡧ࡯ࡰࡴࡽ࡝ࠨࠦ"), l11l1l_opy_ (u"ࠨࠩࠧ"))
        l1l11l_opy_ = l1l11l_opy_.replace(l11l1l_opy_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࡠࡉࡏࡍࡑࡕࠤࡼ࡮ࡩࡵࡧࡠ࡟ࡇࡣࠧࠨ"), l11l1l_opy_ (u"ࠪࠫࠩ"))
        l1l11l_opy_ = l1l11l_opy_.replace(l11l1l_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤ࡬ࡸࡡࡺ࡟࡞ࡍࡢ࠭ࠪ"), l11l1l_opy_ (u"ࠬ࠭ࠫ"))
        l1l11l_opy_ = l1l11l_opy_.replace(l11l1l_opy_ (u"࡛࠭࠰ࡋࡠ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࠬ"), l11l1l_opy_ (u"ࠧࠨ࠭"))
        return l1l11l_opy_
def getURL(url):
    if not l11l1_opy_() == l11l1l_opy_ (u"ࠨࡖࡵࡹࡪ࠭࠮"):
        return
    if url.startswith(l11l1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡄࡎࡘ࠾ࠬ࠯")):
        url = url.replace(l11l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡅࡏ࡙࠿࠭࠰"), l11l1l_opy_ (u"ࠫࠬ࠱")).replace(l11l1l_opy_ (u"ࠬ࠳࠭ࡶࡵࡨࡶ࠲ࡧࡧࡦࡰࡷࠫ࠲"), l11l1l_opy_ (u"࠭ࡼࡶࡵࡨࡶ࠲ࡧࡧࡦࡰࡷࠫ࠳"))
        return url
    if url.startswith(l11l1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡊ࠺ࠨ࠴")):
        return l1ll_opy_(url, dexter)
    if url.startswith(l11l1l_opy_ (u"ࠨࡈࡏࡅࠬ࠵")):
        return l1ll_opy_(url, l1llll1_opy_)
    response = l1l1_opy_(url)
    stream   = url.split(l11l1l_opy_ (u"ࠩ࠽ࠫ࠶"), 1)[-1]
    try:
        result = response[l11l1l_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪ࠷")]
        l1_opy_  = result[l11l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪ࠸")]
    except Exception as e:
        l1lll11_opy_(e)
        return None
    for file in l1_opy_:
        l1l11l_opy_ = file[l11l1l_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫ࠹")]
        if stream in l1l11l_opy_:
            return file[l11l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࠫ࠺")]
    return None
def l1ll_opy_(url, addon):
    PATH = l111_opy_(addon)
    if os.path.exists(PATH):
        response = json.load(open(PATH))
    else:
        response = doJSON(addon)
    l11111_opy_ = url.split(l11l1l_opy_ (u"ࠧ࠻ࠩ࠻"))[0]
    stream   = url.split(l11l1l_opy_ (u"ࠨ࠼ࠪ࠼"), 1)[-1]
    l1_opy_  = response[l11l1l_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩ࠽")][l11l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩ࠾")]
    for file in l1_opy_:
        l1l11l_opy_ = file[l11l1l_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪ࠿")]
        if stream in l1l11l_opy_:
            l11l_opy_ = file[l11l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪࡀ")]
            if l11111_opy_ == l11l1l_opy_ (u"࠭ࡆࡍࡃࡖࠫࡁ"):
                return l11l_opy_
            l11l_opy_ = l11l_opy_.replace(l11l1l_opy_ (u"ࠧ࠯ࡶࡶࠫࡂ"), l11l1l_opy_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧࡃ"))
            return l11l_opy_
def doJSON(addon):
    PATH  = l111_opy_(addon)
    query = l11l11_opy_(addon)
    l1ll11l_opy_  = (l11l1l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬࡄ") % query)
    response = xbmc.executeJSONRPC(l1ll11l_opy_)
    content  = json.loads(response)
    json.dump(content, open(PATH,l11l1l_opy_ (u"ࠪࡻࠬࡅ")), indent=3)
    return json.load(open(PATH))
def l111_opy_(addon):
    if addon == l1llll1_opy_:
        return os.path.join(dixie.PROFILE, l11l1l_opy_ (u"ࠫ࡫ࡺࡥ࡮ࡲࠪࡆ"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l11l1l_opy_ (u"ࠬࡪࡴࡦ࡯ࡳࠫࡇ"))
def l11l11_opy_(addon):
    if addon == l1llll1_opy_:
        return l11l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡇ࡮ࡤࡻࡱ࡫ࡳࡴࡖࡹ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡹࡴࡳࡧࡤࡱࡤࡼࡩࡥࡧࡲࠪࡪࡾࡴࡳࡣࠩࡴࡦ࡭ࡥࠧࡲ࡯ࡳࡹࠬࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠿ࠩࡸ࡮ࡺ࡬ࡦ࠿ࡄࡰࡱࠬࡵࡳ࡮ࡀ࠴ࠬࡈ")
    if addon == dexter:
        return l11l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡦࡨࡼ࠴ࡅࡡࡤࡶ࡬ࡳࡳࡃࡡ࡭࡮ࠩࡩࡽࡺࡲࡢࠨࡳࡥ࡬࡫ࠦࡱ࡮ࡲࡸࠫࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠾ࠨࡷ࡭ࡹࡲࡥ࠾ࠧ࠸ࡦࡈࡕࡌࡐࡔࠨ࠶࠵ࡽࡨࡪࡶࡨࠩ࠺ࡪࡁ࡭࡮ࠨ࠶࠵ࡉࡨࡢࡰࡱࡩࡱࡹࠥ࠶ࡤࠨ࠶࡫ࡉࡏࡍࡑࡕࠩ࠺ࡪࠦࡶࡴ࡯ࠫࡉ")
def l1l1_opy_(url):
    if url.startswith(l11l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠺ࠨࡊ")):
        l1ll11l_opy_ = (l11l1l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡨࡢࡤ࡫ࡳࡰࡦࡿࡥࡳ࠱ࡂࡹࡷࡲ࠽ࡶࡴ࡯ࠪࡲࡵࡤࡦ࠿࠵ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡻ࡫ࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠩࡍࡕࡏࡄ࠾ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࡋ"))
    if url.startswith(l11l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠴࠽ࠫࡌ")):
        l1ll11l_opy_ = (l11l1l_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺ࠳ࡄࡻࡲ࡭࠿ࡸࡶࡱࠬ࡭ࡰࡦࡨࡁ࠶࠶࠱ࠧࡰࡤࡱࡪࡃࡗࡢࡶࡦ࡬࠰ࡒࡩࡷࡧࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࡂࠬࡳࡶࡤࡷ࡭ࡹࡲࡥࡴࡡࡸࡶࡱࡃࠦ࡭ࡱࡪ࡫ࡪࡪ࡟ࡪࡰࡀࡊࡦࡲࡳࡦࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࡍ"))
    if url.startswith(l11l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖ࠿࠭ࡎ")):
        l1ll11l_opy_ = (l11l1l_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠵࠿ࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠫࡲ࡯ࡨࡩࡨࡨࡤ࡯࡮࠾ࡈࡤࡰࡸ࡫ࠦ࡮ࡱࡧࡩࡂ࠷࠱࠴ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡶࡸࡪࡴࠥ࠳࠲ࡏ࡭ࡻ࡫ࠦࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡵࡢࡹࡷࡲࠦࡶࡴ࡯ࡁࡺࡸ࡬ࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ࡏ"))
    if url.startswith(l11l1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡏࡔࡗ࠼ࠪࡐ")):
        l1ll11l_opy_ = (l11l1l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡺࡶࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ࡑ"))
    if url.startswith(l11l1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪࡒ")):
        l1ll11l_opy_ = (l11l1l_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡤࡦࡺ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡦࡲ࡬ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠦࡵ࡫ࡷࡰࡪࡃࠥ࠶ࡤࡆࡓࡑࡕࡒࠦ࠴࠳ࡻ࡭࡯ࡴࡦࠧ࠸ࡨࡆࡲ࡬ࠦ࠴࠳ࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠪ࠻ࡢࠦ࠴ࡩࡇࡔࡒࡏࡓࠧ࠸ࡨࠫࡻࡲ࡭ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࡓ"))
    if url.startswith(l11l1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡕࡆ࠿࠭ࡔ")):
        l1ll11l_opy_ = (l11l1l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡨࡦࡴࡵࡴ࠰ࡁࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠦࡧࡣࡱࡥࡷࡺ࠽ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡳ࡯ࡥࡧࡀ࠻ࠫࡶࡩ࡭࡮ࡲࡻࡂࡒࡩࡷࡧࠨ࠶࠵࡙ࡴࡳࡧࡤࡱࡸࠬࡵࡳ࡮ࡀࡶࡦࡴࡤࡰ࡯ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨࡕ"))
    if url.startswith(l11l1l_opy_ (u"࠭ࡉࡑࡖࡖ࠾ࠬࡖ")):
        l1ll11l_opy_ = (l11l1l_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡺࡿࡡࡪࡲࡷࡺ࠴ࡅࡡࡤࡶ࡬ࡳࡳࡃ࡬ࡪࡸࡨࡸࡻࡥࡡ࡭࡮ࠩࡩࡽࡺࡲࡢࠨࡳࡥ࡬࡫ࠦࡱ࡮ࡲࡸࠫࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠾ࠨࡷ࡭ࡹࡲࡥ࠾ࡃ࡯ࡰࠪ࠸࠰ࡤࡪࡤࡲࡳ࡫࡬ࡴࠨࡸࡶࡱࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࡗ"))
    try:
        dixie.ShowBusy()
        addon =  l1ll11l_opy_.split(l11l1l_opy_ (u"ࠨ࠱࠲ࠫࡘ"), 1)[-1].split(l11l1l_opy_ (u"ࠩ࠲࡙ࠫ"), 1)[0]
        login = l11l1l_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠦࡵࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ࡚") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1ll11l_opy_)
        dixie.log(response)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1lll11_opy_(e)
        return {l11l1l_opy_ (u"ࠫࡊࡸࡲࡰࡴ࡛ࠪ") : l11l1l_opy_ (u"ࠬࡖ࡬ࡶࡩ࡬ࡲࠥࡋࡲࡳࡱࡵࠫ࡜")}
def l11l1_opy_():
    modules = map(__import__, [l1l1111_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1l1l_opy_)):
        return l11l1l_opy_ (u"࠭ࡔࡳࡷࡨࠫ࡝")
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l11l1l_opy_ (u"ࠧࡕࡴࡸࡩࠬ࡞")
    return l11l1l_opy_ (u"ࠨࡈࡤࡰࡸ࡫ࠧ࡟")
def l1lll11_opy_(e):
    l1l1l1_opy_ = l11l1l_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠭ࠢࡤࡲࠥ࡫ࡲࡳࡱࡵࠤࡴࡩࡣࡶࡴࡨࡨ࠿ࠦࡊࡔࡑࡑࠤࡊࡸࡲࡰࡴ࠽ࠤࠪࡹࠧࡠ")  %e
    l1l1ll_opy_ = l11l1l_opy_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡶࡪ࠳࡬ࡪࡰ࡮ࠤࡹ࡮ࡩࡴࠢࡦ࡬ࡦࡴ࡮ࡦ࡮ࠣࡥࡳࡪࠠࡵࡴࡼࠤࡦ࡭ࡡࡪࡰ࠱ࠫࡡ")
    l1ll11_opy_ = l11l1l_opy_ (u"࡚ࠫࡹࡥ࠻ࠢࡆࡳࡳࡺࡥࡹࡶࠣࡑࡪࡴࡵࠡ࠿ࡁࠤࡗ࡫࡭ࡰࡸࡨࠤࡘࡺࡲࡦࡣࡰࠫࡢ")
    dixie.log(e)
    dixie.DialogOK(l1l1l1_opy_, l1l1ll_opy_, l1ll11_opy_)