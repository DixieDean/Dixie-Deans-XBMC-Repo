# coding: UTF-8
import sys
l111l_opy_ = sys.version_info [0] == 2
l1l11ll_opy_ = 2048
l1ll1l_opy_ = 7
def l1lllll_opy_ (ll_opy_):
	global l1llll_opy_
	l1111_opy_ = ord (ll_opy_ [-1])
	l1ll11l1_opy_ = ll_opy_ [:-1]
	l111lll_opy_ = l1111_opy_ % len (l1ll11l1_opy_)
	l1ll1_opy_ = l1ll11l1_opy_ [:l111lll_opy_] + l1ll11l1_opy_ [l111lll_opy_:]
	if l111l_opy_:
		l11ll1l_opy_ = unicode () .join ([unichr (ord (char) - l1l11ll_opy_ - (l111ll_opy_ + l1111_opy_) % l1ll1l_opy_) for l111ll_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l11ll1l_opy_ = str () .join ([chr (ord (char) - l1l11ll_opy_ - (l111ll_opy_ + l1111_opy_) % l1ll1l_opy_) for l111ll_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l11ll1l_opy_)
import xbmc
import xbmcgui
import xbmcaddon
import json
import datetime
import os
import dixie
import mapping
l1ll1lll_opy_ = l1lllll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡊࡱࡧࡷ࡭ࡧࡶࡷ࡙ࡼࠧࠀ")
l1l1l11_opy_  = l1lllll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡭ࡵࡲࡪࡼࡲࡲ࡮ࡶࡴࡷࠩࠁ")
l11_opy_  = l1lllll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡬ࡡࡣࡪࡲࡷࡹ࡯࡮ࡨࠩࠂ")
l11ll11_opy_     = l1lllll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡬ࡪࡷࡻ࠲ࡹࡼࠧࠃ")
l1l1ll_opy_   = l1lllll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡶࡵࡩࡦࡳࡳࡦࡣࡶࡽ࠳ࡺࡶࠨࠄ")
l11lll1_opy_ = l1lllll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡰࡥࡷࡺࡨࡶࡤࠪࠅ")
l11ll_opy_ = l1lllll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧ࠲ࠨࠆ")
l1l1lll1_opy_   = [l1ll1lll_opy_, l1l1l11_opy_, l11_opy_]
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
def isValid(stream):
    if l1lllll_opy_ (u"ࠫࡍࡕࡒࡊ࡜࠽ࠫࠇ") in stream:
        dixie.log(l1lllll_opy_ (u"ࠬ࠳࠭࠮ࠢࡋࡓࡗࡏ࡚ࡐࡐࠣࡘࡗ࡛ࡅࠡ࠯࠰࠱ࠬࠈ"))
        return True
    if l1lllll_opy_ (u"࠭ࡆࡍࡃ࠽ࠫࠉ") in stream:
        dixie.log(l1lllll_opy_ (u"ࠧ࠮࠯࠰ࠤࡋࡒࡁࡘࡎࡈࡗࡘࠦࡔࡓࡗࡈࠤ࠲࠳࠭ࠨࠊ"))
        return True
    if l1lllll_opy_ (u"ࠨࡈࡄࡆ࠿࠭ࠋ") in stream:
        dixie.log(l1lllll_opy_ (u"ࠩ࠰࠱࠲ࠦࡆࡂࡄࡌࡔ࡙࡜ࠠࡕࡔࡘࡉࠥ࠳࠭࠮ࠩࠌ"))
        return True
    dixie.log(l1lllll_opy_ (u"ࠪ࠱࠲࠳ࠠࡗࡃࡏࡍࡉࠦࡆࡂࡎࡖࡉࠥ࠳࠭࠮ࠩࠍ"))
    return False
def getRecording(name, title, start, stream):
    dixie.log(l1lllll_opy_ (u"ࠫࡂࡃ࠽࠾࠿ࡀࠤ࡬࡫ࡴࡓࡧࡦࡳࡷࡪࡩ࡯ࡩࠣࡁࡂࡃ࠽࠾࠿ࠪࠎ"))
    l1ll1l1l_opy_   =  stream.split(l1lllll_opy_ (u"ࠬࢂࠧࠏ"))
    l1ll1111_opy_    =  getAddonInfo(l1ll1l1l_opy_)
    catchup   = l1lllll_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡯ࡳࡣࡱ࡫ࡪࡣࠠ࡜ࡅࡤࡸࡨ࡮࠭ࡶࡲࠣࡅࡻࡧࡩ࡭ࡣࡥࡰࡪࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨࠐ")
    l11111_opy_ = l1lllll_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࠥࡡࡎࡰࠢࡆࡥࡹࡩࡨ࠮ࡷࡳࠤࡆࡼࡡࡪ࡮ࡤࡦࡱ࡫࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࠑ")
    options = []
    l111_opy_ = []
    for item in l1ll1111_opy_:
        l11l1l_opy_ =  item[0]
        l11l1l_opy_ = l1lllll_opy_ (u"ࠨ࡝ࡅࡡࠬࠒ") + l11l1l_opy_ + l1lllll_opy_ (u"ࠩ࡞࠳ࡇࡣࠧࠓ")
        addon =  item[1]
        l1l11l_opy_ = l11llll_opy_(addon)
        l111l11_opy_ = l1lll1_opy_(addon, name)
        dixie.log(l1l11l_opy_)
        dixie.log(l111l11_opy_)
        if not l1l11l_opy_:
            l1llllll_opy_ = l11l1l_opy_ + l11111_opy_
            options.append(l1llllll_opy_)
            l111_opy_.append(addon)
        if l1l11l_opy_ and not l111l11_opy_:
            l1llllll_opy_ = l11l1l_opy_ + l11111_opy_
            options.append(l1llllll_opy_)
            l111_opy_.append(addon)
        if l1l11l_opy_ and l111l11_opy_:
            l11lll_opy_ = l11l1l_opy_ + catchup
            options.append(l11lll_opy_)
            l111_opy_.append(addon)
    l1llll1_opy_ = xbmcgui.Dialog().select(l1lllll_opy_ (u"ࠪࡗࡊࡒࡅࡄࡖࠣࡇࡆ࡚ࡃࡉ࠯ࡘࡔࠥࡇࡄࡅ࠯ࡒࡒࠬࠔ"), options)
    addon  = l111_opy_[l1llll1_opy_]
    return getIPTVRecording(addon, name, title, start, stream)
def getAddonInfo(l1ll1l1l_opy_):
    import plugins
    l1ll1111_opy_ = []
    for stream in l1ll1l1l_opy_:
        info    = plugins.getPluginInfo(stream, kodiID=True)
        l11l1l_opy_   = info[0]
        addon   = info[1]
        result  = [l11l1l_opy_, addon]
        if result not in l1ll1111_opy_:
            l1ll1111_opy_.append(result)
    dixie.log(l1ll1111_opy_)
    return l1ll1111_opy_
def l11llll_opy_(addon):
    for item in l1l1lll1_opy_:
        if addon == item:
            return True
    return False
def l1lll1_opy_(addon, name):
    l1111ll_opy_ = l11111l_opy_(addon)
    dixie.log(l1111ll_opy_)
    for item in l1111ll_opy_:
        l1l1ll1l_opy_  = name.upper()
        channel = item[0].upper()
        if l1l1ll1l_opy_ == channel:
            return True
    return False
def l11111l_opy_(addon):
    HOME  = dixie.PROFILE
    iPATH = os.path.join(HOME, l1lllll_opy_ (u"ࠫ࡮ࡴࡩࠨࠕ"))
    if addon == l11_opy_:
        l11ll1_opy_ = os.path.join(iPATH, l1lllll_opy_ (u"ࠬࡩࡡࡵࡥ࡫ࡹࡵࡌࡁࡃ࠰࡭ࡷࡴࡴࠧࠖ"))
        return json.load(open(l11ll1_opy_))
    if (addon == l1ll1lll_opy_) or (addon == l1l1l11_opy_):
        l11ll1_opy_ = os.path.join(iPATH, l1lllll_opy_ (u"࠭ࡣࡢࡶࡦ࡬ࡺࡶࡆࡍࡃ࠱࡮ࡸࡵ࡮ࠨࠗ"))
        return json.load(open(l11ll1_opy_))
    return [[l1lllll_opy_ (u"ࠢࡏࡱࡱࡩࠧ࠘"), l1lllll_opy_ (u"ࠣࡐࡲࡲࡪࠨ࠙")]]
def getIPTVRecording(addon, name, title, start, stream):
    import time
    dixie.log(l1lllll_opy_ (u"ࠩࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࠥࡉࡁࡕࡅࡋࠤ࡚ࡖࠠࡊࡒࡗ࡚ࠥࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࠩࠚ"))
    dixie.log(addon)
    dixie.log(name)
    dixie.log(title)
    dixie.log(start)
    dixie.log(stream)
    l11l111_opy_ = -time.timezone
    dixie.log(l1lllll_opy_ (u"ࠪࡓࡋࡌࡓࡆࡖ࠽ࠤࠪࡹࠧࠛ") % l11l111_opy_)
    l1ll1l11_opy_  = start - datetime.timedelta(seconds=l11l111_opy_)
    dixie.log(l1lllll_opy_ (u"ࠫࡊࡖࡇࠡࡕࡷࡥࡷࡺࠠࡕ࡫ࡰࡩ࠳࠴࠮࠻ࠢࠨࡷࠬࠜ") % start)
    dixie.log(l1lllll_opy_ (u"ࠬࡋࡐࡈࠢࡖࡸࡦࡸࡴࠡࡖ࡬ࡱࡪࠦࡏࡇࡈࡖࡉ࡙ࡀࠠࠦࡵࠪࠝ") % l1ll1l11_opy_)
    l11l1_opy_ = str(l1ll1l11_opy_)
    dixie.log(l1lllll_opy_ (u"࠭ࡴࡪ࡯ࡨࡷࡹࡸࡩ࡯ࡩ࠽ࠤࠪࡹࠧࠞ") % l11l1_opy_)
    l1l1l1_opy_   = l11l1_opy_.split(l1lllll_opy_ (u"ࠧࠡࠩࠟ"))[0]
    l1111l1_opy_  = l11l1_opy_.split(l1lllll_opy_ (u"ࠨࠢࠪࠠ"))[1]
    l1l1_opy_  = time.strptime(l1111l1_opy_,  l1lllll_opy_ (u"ࠩࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠫࠡ"))
    theTime    = time.strftime(l1lllll_opy_ (u"ࠪࠩࡍࡀࠥࡎࠩࠢ"),  l1l1_opy_)
    dixie.log(l1lllll_opy_ (u"ࠫࡎࡖࡔࡗࡵࡷࡥࡷࡺ࠺ࠡࠧࡶࠫࠣ") % theTime)
    l1lll_opy_ = time.strptime(l1l1l1_opy_,   l1lllll_opy_ (u"࡙ࠬࠫ࠮ࠧࡰ࠱ࠪࡪࠧࠤ"))
    theDate    = time.strftime(l1lllll_opy_ (u"࡚࠭ࠥ࠯ࠨࡱ࠲ࠫࡤࠨࠥ"), l1lll_opy_)
    dixie.log(l1lllll_opy_ (u"ࠧࡊࡒࡗ࡚ࡩࡺࡩࡵ࡮ࡨ࠾ࠥࠫࡳࠨࠦ") % theDate)
    return getCatchupLink(addon, name, title, theDate, theTime)
def getCatchupLink(addon, channel, theShow, theDate, theTime):
    LABELFILE = l1ll11ll_opy_(addon)
    labelmaps = json.load(open(LABELFILE))
    l1llll1l_opy_ = l1lllll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫࠧ") + addon
    item   = l1ll1l1_opy_(addon)
    try:
        l1l1111_opy_  = findCatchup(l1llll1l_opy_, item)
        l1l1l_opy_  = mapping.mapLabel(labelmaps, channel)
        l1l1l_opy_  = l1l1l_opy_.upper()
        l11l_opy_   = findCatchup(l1l1111_opy_, l1l1l_opy_)
        l1ll11l_opy_ = theDate + l1lllll_opy_ (u"ࠩࠣ࠱ࠥ࠭ࠨ") + theTime
        l1ll11l_opy_ = l1ll11l_opy_.upper()
        l1l1ll1_opy_      = findCatchup(l11l_opy_, l1ll11l_opy_, splitlabel=True)
        dixie.DialogOK(l1lllll_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡳࡷࡧ࡮ࡨࡧࡠ࡟ࡇࡣࡃࡢࡶࡦ࡬࠲ࡻࡰࠡࡵࡷࡶࡪࡧ࡭ࠡࡨࡲࡹࡳࡪ࠮࡜࠱ࡅࡡࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠩ"), l1lllll_opy_ (u"ࠫࡔࡴ࠭ࡕࡣࡳࡴ࠳࡚ࡖࠡࡹ࡬ࡰࡱࠦ࡮ࡰࡹࠣࡴࡱࡧࡹ࠻ࠢ࡞ࡇࡔࡒࡏࡓࠢࡲࡶࡦࡴࡧࡦ࡟࡞ࡆࡢࠫࡳ࡜࠱ࡅࡡࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠪ") % (theShow))
        return l1l1ll1_opy_
    except:
        dixie.DialogOK(l1lllll_opy_ (u"࡙ࠬ࡯ࡳࡴࡼ࠲ࠬࠫ"), l1lllll_opy_ (u"࠭ࡗࡦࠢࡦࡳࡺࡲࡤࠡࡰࡲࡸࠥ࡬ࡩ࡯ࡦࠣࡥࠥࡩࡡࡵࡥ࡫ࡹࡵࠦࡳࡵࡴࡨࡥࡲࠦࡦࡰࡴࠣࡸ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮࠰ࠪࠬ"), l1lllll_opy_ (u"ࠧࡓࡧࡹࡩࡷࡺࡩ࡯ࡩࠣࡦࡦࡩ࡫ࠡࡶࡲࠤࡑ࡯ࡶࡦࠢࡗ࡚࠳࠭࠭"))
        return l1lllll_opy_ (u"ࠨࠩ࠮")
def l1ll11ll_opy_(addon):
    HOME  = dixie.PROFILE
    iPATH = os.path.join(HOME, l1lllll_opy_ (u"ࠩ࡬ࡲ࡮࠭࠯"))
    if addon == l11_opy_:
         return os.path.join(iPATH, l1lllll_opy_ (u"ࠪࡧࡦࡺࡣࡩࡷࡳࡊࡆࡈ࠮࡫ࡵࡲࡲࠬ࠰"))
    if (addon == l1ll1lll_opy_) or (addon == l1l1l11_opy_):
         return os.path.join(iPATH, l1lllll_opy_ (u"ࠫࡨࡧࡴࡤࡪࡸࡴࡋࡒࡁ࠯࡬ࡶࡳࡳ࠭࠱"))
def l1ll1l1_opy_(addon):
    if addon == l11_opy_:
        return l1lllll_opy_ (u"ࠬࡌࡁࡃࠢࡌࡔ࡙࡜ࠠࡄࡃࡗࡇࡍ࡛ࡐࠨ࠲")
    if addon == l1ll1lll_opy_:
        return l1lllll_opy_ (u"࠭ࡆࡍࡃ࡚ࡐࡊ࡙ࡓࠡࡅࡄࡘࡈࡎࡕࡑࠩ࠳")
    if addon == l1l1l11_opy_:
        return l1lllll_opy_ (u"ࠧࡉࡑࡕࡍ࡟ࡕࡎࠡࡅࡄࡘࡈࡎࡕࡑࠩ࠴")
def findCatchup(query, item, splitlabel=False):
    response = doJSON(query)
    l1l1lll_opy_    = response[l1lllll_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨ࠵")][l1lllll_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨ࠶")]
    for file in l1l1lll_opy_:
        l111ll1_opy_ = file[l1lllll_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩ࠷")]
        l1lll11_opy_   = mapping.cleanLabel(l111ll1_opy_)
        l11l1l_opy_    = cleanPrefix(l1lll11_opy_)
        if splitlabel:
            l11l1l_opy_ = l11l1l_opy_.upper()
            l11l1l_opy_ = l11l1l_opy_.rsplit(l1lllll_opy_ (u"ࠫࠥ࠳ࠠࠨ࠸"), 1)[0]
        else:
            l11l1l_opy_ = l11l1l_opy_.upper()
        if l11l1l_opy_ == item.upper():
            return file[l1lllll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪ࠹")]
def doJSON(query):
    l111111_opy_  = (l1lllll_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࠧࡶࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ࠺") % query)
    response = xbmc.executeJSONRPC(l111111_opy_)
    content  = json.loads(response)
    return content
def cleanPrefix(text):
    l1ll1ll1_opy_ = text.strip()
    l11l11_opy_  = [l1lllll_opy_ (u"ࠧࡖࡍ࠽ࠫ࠻"), l1lllll_opy_ (u"ࠨࡋࡑࡘ࠿ࠦࠧ࠼"), l1lllll_opy_ (u"ࠩࡏࡍ࡛ࡋࠠࠨ࠽"), l1lllll_opy_ (u"࡙ࠪࡐࠦ࡬ࠡࠩ࠾"), l1lllll_opy_ (u"ࠫࡎࡔࠠ࡭ࠢࠪ࠿"), l1lllll_opy_ (u"ࠬࡏࡎࠡࡾࠣࠫࡀ"), l1lllll_opy_ (u"࠭ࡄࡆࠢ࡯ࠤࠬࡁ"), l1lllll_opy_ (u"ࠧࡓࡃࡇࠤࡱࠦࠧࡂ"), l1lllll_opy_ (u"ࠨࡘࡌࡔࠥࡲࠠࠨࡃ"), l1lllll_opy_ (u"ࠩࠣࡐࡴࡩࡡ࡭ࠩࡄ"), l1lllll_opy_ (u"࡙ࠪࡘࡇ࠯ࡄࡃࠣ࠾ࠥ࠭ࡅ"), l1lllll_opy_ (u"࡚࡙ࠫࡁ࠰ࡅࡄ࠾ࠥ࠭ࡆ"), l1lllll_opy_ (u"ࠬࡉࡁ࠻ࠢࠪࡇ"),l1lllll_opy_ (u"࠭ࡃࡂࠢ࠽ࠤࠬࡈ"),l1lllll_opy_ (u"ࠧࡄࡃࠣࠫࡉ"),l1lllll_opy_ (u"ࠨࡗࡎࠤ࡛ࡏࡐࠡ࠼ࠣࠫࡊ"), l1lllll_opy_ (u"ࠩࡘࡏࠥࡀࠠࠨࡋ"), l1lllll_opy_ (u"࡙ࠪࡐࡀࠠࠨࡌ"), l1lllll_opy_ (u"࡚ࠫࡑࠠࡽࠢࠪࡍ"), l1lllll_opy_ (u"࡛ࠬࡓࡂࠢ࠽ࠤࡑࡏࡖࡆࠢࠪࡎ"), l1lllll_opy_ (u"࠭ࡕࡔࡃࠣࢀࠥࡒࡉࡗࡇࠣࠫࡏ"), l1lllll_opy_ (u"ࠧࡖࡕࡄࠤ࠿ࠦࠧࡐ"), l1lllll_opy_ (u"ࠨࡗࡖࡅࠥࡀࠧࡑ"), l1lllll_opy_ (u"ࠩࡘࡗࡆࡀࠠࠨࡒ"), l1lllll_opy_ (u"࡙ࠪࡘࡇࠠࡽࠢࠪࡓ"), l1lllll_opy_ (u"࡚࡙ࠫࡁࠡࠩࡔ"), l1lllll_opy_ (u"࡛ࠬࡓࠡࡾࠣࠫࡕ"),l1lllll_opy_ (u"࠭ࡕࡔ࠼ࠣࠫࡖ"), l1lllll_opy_ (u"ࠧࡏࡑࡕࡈࡎࡉࠠࠨࡗ")]
    for prefix in l11l11_opy_:
        if prefix in l1ll1ll1_opy_:
            l1ll1ll1_opy_ = l1ll1ll1_opy_.replace(prefix, l1lllll_opy_ (u"ࠨࠩࡘ"))
    return l1ll1ll1_opy_.strip()
def l1ll_opy_(addon, name, title, start, stream):
    import time
    dixie.log(l1lllll_opy_ (u"ࠩࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࠥࡉࡁࡕࡅࡋࠤ࡚ࡖࠠࡍ࡚ࡗ࡚ࠥࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠ࡙ࠩ"))
    l1llll11_opy_ = stream.split(l1lllll_opy_ (u"ࠪࢀ࡚ࠬ"))
    for url in l1llll11_opy_:
        if (l1l1ll_opy_ in url) or (l11ll11_opy_ in url):
            dixie.log(l1lllll_opy_ (u"ࠫࡑ࡞ࡔࡗࠢࡘࡖࡑ࠴࠮࠯࠼ࠣࠩࡸ࡛࠭") % url)
            l1ll111_opy_ = url.split(CLOSE_OTT)[0].replace(OPEN_OTT, l1lllll_opy_ (u"ࠬ࠭࡜"))
            break
    import urllib
    l11l111_opy_ = l1l1l1l_opy_()
    dixie.log(l1lllll_opy_ (u"࠭ࡅࡑࡉࠣࡗࡹࡧࡲࡵࠢࡗ࡭ࡲ࡫࠮࠯࠰࠽ࠤࠪࡹࠧ࡝") % start)
    dixie.log(l1lllll_opy_ (u"ࠧࡐࡨࡩࡷࡪࡺࠠࡪࡰࠣࡷࡪࡩ࡯࡯ࡦࡶ࠾ࠥࠫࡳࠨ࡞") % l11l111_opy_)
    l1ll1l11_opy_  =  start - datetime.timedelta(seconds=l11l111_opy_)
    dixie.log(l1lllll_opy_ (u"ࠨࡕࡷࡥࡷࡺࠠࡕ࡫ࡰࡩࠥࡵࡦࡧࡵࡨࡸ࠿ࠦࠥࡴࠩ࡟") % l1ll1l11_opy_)
    l1l11l1_opy_     = l1ll11_opy_(l1ll111_opy_)
    l11l1_opy_ = str(l1ll1l11_opy_)
    l1lll1ll_opy_   = l11l1_opy_.split(l1lllll_opy_ (u"ࠩࠣࠫࡠ"))[0]
    l1111l1_opy_  = l11l1_opy_.split(l1lllll_opy_ (u"ࠪࠤࠬࡡ"))[1]
    l1lll1l_opy_  = time.strptime(l1111l1_opy_,  l1lllll_opy_ (u"ࠫࠪࡎ࠺ࠦࡏ࠽ࠩࡘ࠭ࡢ"))
    l1lll1l_opy_  = time.strftime(l1lllll_opy_ (u"ࠬࠫࡉ࠻ࠧࡐࠤࠪࡶࠧࡣ"),  l1lll1l_opy_)
    l1lllll1_opy_ = time.strptime(l1lll1ll_opy_,   l1lllll_opy_ (u"࡚࠭ࠥ࠯ࠨࡱ࠲ࠫࡤࠨࡤ"))
    l1lllll1_opy_ = time.strftime(l1lllll_opy_ (u"ࠧࠦࡃ࠯ࠤࠪࡈࠠࠦࡦࠪࡥ"), l1lllll1_opy_)
    query = l1lllll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸ࠵࠿ࡤࡪࡤࡲࡳ࡫࡬ࡠ࡫ࡧࡁࠪࡹࠦࡥࡣࡷࡩࡂࠫࡳࠧࡦࡤࡸࡪࡥࡴࡪࡶ࡯ࡩࡂࠫࡳࠧ࡫ࡰ࡫ࡂࠬ࡭ࡰࡦࡨࡁࡷ࡫ࡣࡰࡴࡧ࡭ࡳ࡭ࡳࠧࡶ࡬ࡸࡱ࡫࠽ࠦࡵࠪࡦ") % (addon, l1l11l1_opy_, l1lll1ll_opy_, l1lllll1_opy_, l1ll111_opy_)
    l111l1_opy_  = l1lllll_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬࡧ") % query
    if not l1l11l1_opy_:
        dixie.DialogOK(l1lllll_opy_ (u"ࠪࡗࡴࡸࡲࡺ࠰ࠪࡨ"), l1lllll_opy_ (u"ࠫ࡜࡫ࠠࡤࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡪ࡮ࡴࡤࠡࡣࠣࡧࡦࡺࡣࡩࡷࡳࠤࡸ࡫ࡲࡷ࡫ࡦࡩࠥ࡬࡯ࡳࠢࡷ࡬࡮ࡹࠠࡤࡪࡤࡲࡳ࡫࡬࠯ࠩࡩ"), l1lllll_opy_ (u"ࠬࡘࡥࡷࡧࡵࡸ࡮ࡴࡧࠡࡤࡤࡧࡰࠦࡴࡰࠢࡏ࡭ࡻ࡫ࠠࡕࡘ࠱ࠫࡪ"))
        return None
    l1l111l_opy_    = xbmc.executeJSONRPC(l111l1_opy_)
    response   = json.loads(l1l111l_opy_)
    result     = response[l1lllll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭࡫")]
    l11l1ll_opy_ = result[l1lllll_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭࡬")]
    for l1lll111_opy_ in l11l1ll_opy_:
        try:
            l1111l_opy_ = l1lll111_opy_[l1lllll_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭࡭")]
            l11l1l_opy_   = l1lll111_opy_[l1lllll_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨ࡮")]
            if l1lll1l_opy_ in l11l1l_opy_:
                dixie.DialogOK(l1lllll_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡳࡷࡧ࡮ࡨࡧࡠࡇࡦࡺࡣࡩ࠯ࡸࡴࠥࡹࡴࡳࡧࡤࡱࠥ࡬࡯ࡶࡰࡧ࠲ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࡯"), l1lllll_opy_ (u"ࠫࡔࡴ࠭ࡕࡣࡳࡴ࠳࡚ࡖࠡࡹ࡬ࡰࡱࠦ࡮ࡰࡹࠣࡴࡱࡧࡹ࠻ࠢ࡞ࡇࡔࡒࡏࡓࠢࡲࡶࡦࡴࡧࡦ࡟࡞ࡆࡢࠫࡳ࡜࠱ࡅࡡࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࡰ") % (title))
                return l1111l_opy_
        except Exception, e:
            dixie.log(l1lllll_opy_ (u"ࠬࡋࡒࡓࡑࡕ࠾ࠥࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡࡶ࡫ࡶࡴࡽ࡮ࠡ࡫ࡱࠤ࡬࡫ࡴࡍ࡚ࡗ࡚ࡗ࡫ࡣࡰࡴࡧ࡭ࡳ࡭ࠠࠦࡵࠪࡱ") % str(e))
            dixie.DialogOK(l1lllll_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠳࠭ࡲ"), l1lllll_opy_ (u"ࠧࡘࡧࠣࡧࡴࡻ࡬ࡥࠢࡱࡳࡹࠦࡦࡪࡰࡧࠤࡦࠦࡣࡢࡶࡦ࡬ࡺࡶࠠࡴࡶࡵࡩࡦࡳࠠࡧࡱࡵࠤࡹ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯࠱ࠫࡳ"), l1lllll_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡶࡵࡽࠥࡧࡧࡢ࡫ࡱࠤࡱࡧࡴࡦࡴ࠱ࠫࡴ"))
            return None
def l1ll11_opy_(l1ll111_opy_):
    l1ll111_opy_ = l1ll111_opy_.upper()
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩ࠶ࡉࠬࡵ") : return 188
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡅࡇࡉࠠࡆࡃࡖࡘࠬࡶ") : return 363
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫࡆࡈࡃࠨࡷ") : return 346
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠬࡇࡍࡄࠩࡸ") : return 375
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡁࡍࡋࡅࡍࠥࡏࡒࡆࡎࡄࡒࡉ࠭ࡹ") : return 280
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡂࡐࡌࡑࡆࡒࠠࡑࡎࡄࡒࡊ࡚ࠠࡖࡕࡄࠫࡺ") : return 386
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡃࡑࡍࡒࡇࡌࠡࡒࡏࡅࡓࡋࡔࠨࡻ") : return 19
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡄࡖࡊࡔࡁࠡࡕࡓࡓࡗ࡚ࡓࠡ࠳ࠣࡌࡉࠦࡃࡓࡑࡄࡘࡎࡇࠧࡼ") : return 403
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡅࡗࡋࡎࡂࠢࡖࡔࡔࡘࡔࡔࠢ࠵ࠤࡍࡊࠠࡄࡔࡒࡅ࡙ࡏࡁࠨࡽ") : return 404
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫࡆࡘࡅࡏࡃࠣࡗࡕࡕࡒࡕࡕࠣ࠷ࠥࡎࡄࠡࡅࡕࡓࡆ࡚ࡉࡂࠩࡾ") : return 405
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠬࡇࡒࡆࡐࡄࠤࡘࡖࡏࡓࡖࡖࠤ࠹ࠦࡈࡅࠢࡆࡖࡔࡇࡔࡊࡃࠪࡿ") : return 406
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡁࡓࡇࡑࡅ࡙ࠥࡐࡐࡔࡗࡗࠥ࠻ࠠࡔࡔࡅࠫࢀ") : return 407
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡂࡖࠣࡘࡍࡋࠠࡓࡃࡆࡉࡘ࠭ࢁ") : return 273
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡄࡅࡇࠥࡕࡎࡆ࡝ࡋࡈࡢ࠭ࢂ") : return 210
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡅࡆࡈࠦࡔࡘࡑ࡞ࡌࡉࡣࠧࢃ") : return 211
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡆࡊࡏࡎࠡࡕࡓࡓࡗ࡚ࠠ࠲࠲ࠣࡌࡉ࠮ࡔࡆࡕࡗ࠭ࠬࢄ") : return 300
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫࡇࡋࡉࡏࠢࡖࡔࡔࡘࡔࠡ࠳࠴ࠤࡍࡊࠨࡕࡇࡖࡘ࠮࠭ࢅ") : return 389
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠬࡈࡅࡊࡐࠣࡗࡕࡕࡒࡕࠢ࠴ࡌࡉ࠮ࡔࡆࡕࡗ࠭ࠬࢆ") : return 285
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡂࡆࡋࡑࠤࡘࡖࡏࡓࡖࠣ࠶ࠥࡎࡄࠩࡖࡈࡗ࡙࠯ࠧࢇ") : return 286
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡃࡇࡌࡒ࡙ࠥࡐࡐࡔࡗࠤ࠸ࠦࡈࡅࠪࡗࡉࡘ࡚ࠩࠨ࢈") : return 287
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡄࡈࡍࡓࠦࡓࡑࡑࡕࡘࠥ࠺ࠠࡉࡆࠫࡘࡊ࡙ࡔࠪࠩࢉ") : return 288
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡅࡉࡎࡔࠠࡔࡒࡒࡖ࡙ࠦ࠵ࠡࡊࡇ࡙ࠬࡋࡓࡕࠫࠪࢊ") : return 289
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡆࡊࡏࡎࠡࡕࡓࡓࡗ࡚ࠠ࠷ࠢࡋࡈ࡚࠭ࡅࡔࡖࠬࠫࢋ") : return 290
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫࡇࡋࡉࡏࠢࡖࡔࡔࡘࡔࠡ࠹ࠣࡌࡉ࠮ࡔࡆࡕࡗ࠭ࠬࢌ") : return 291
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠬࡈࡅࡊࡐࠣࡗࡕࡕࡒࡕࠢ࠻ࠤࡍࡊࠨࡕࡇࡖࡘ࠮࠭ࢍ") : return 292
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡂࡆࡋࡑࠤࡘࡖࡏࡓࡖࠣ࠽ࠥࡎࡄࠩࡖࡈࡗ࡙࠯ࠧࢎ") : return 293
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡃࡖࠣࡗࡕࡕࡒࡕࠢ࠴ࠤࡍࡊࠠࠩࡖࡈࡗ࡙࠯ࠧ࢏") : return 306
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡄࡗࠤࡘࡖࡏࡓࡖࠣ࠵ࠬ࢐") : return 17
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡅࡘ࡙ࠥࡐࡐࡔࡗࠤ࠷ࠦࡈࡅࠢࠫࡘࡊ࡙ࡔࠪࠩ࢑") : return 307
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡆ࡙ࠦࡓࡑࡑࡕࡘࠥ࠸ࠧ࢒") : return 18
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫࡇ࡚ࠠࡔࡒࡒࡖ࡙ࠦࡅࡔࡒࡑࠫ࢓") : return 24
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠬࡈࡔࠡࡕࡓࡓࡗ࡚ࠠࡆࡗࡕࡓࡕࡋࠧ࢔") : return 216
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡂࡂࡄ࡜ࠤ࡙࡜ࠧ࢕") : return 299
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡃࡎࡘࡉࠥࡎࡕࡔࡖࡏࡉࡗࠦࡅࡖࡔࡒࡔࡊ࠭࢖") : return 241
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡄࡒࡓࡒࡋࡒࡂࡐࡊࠫࢗ") : return 192
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡅࡓ࡝ࠦࡎࡂࡖࡌࡓࡓ࠭࢘") : return 185
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡆࡗࡏࡔࡊࡕࡋࠤࡊ࡛ࡒࡐࡕࡓࡓࡗ࡚࠲ࠨ࢙") : return 173
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫࡇࡘࡉࡕࡋࡖࡌࠥࡋࡕࡓࡑࡖࡔࡔࡘࡔࠨ࢚") : return 182
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠬࡉࡂࡔࠢࡕࡉࡆࡒࡉࡕ࡛࢛ࠪ") : return 190
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡃࡏࡄࡆࠫ࢜") : return 366
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡄࡐࡑࠫ࢝") : return 365
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡅࡄࡖ࡙ࡕࡏࡏࠢࡑࡉ࡙࡝ࡏࡓࡍ࡙ࠣࡐ࠭࢞") : return 186
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡆࡅࡗ࡚ࡏࡐࡐࡌࡘࡔ࠭࢟") : return 250
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡇࡍࡋࡌࡔࡇࡄࠤ࡙࡜ࠧࢠ") : return 179
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫࡈࡕࡍࡆࡆ࡜ࠤࡈࡋࡎࡕࡔࡄࡐ࡛ࠥࡓࡂࠩࢡ") : return 374
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠬࡉࡏࡎࡇࡇ࡝ࠥࡉࡅࡏࡖࡕࡅࡑ࠭ࢢ") : return 251
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡃࡐࡏࡈࡈ࡞ࠦࡘࡕࡔࡄࠫࢣ") : return 176
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡄࡔࡌࡑࡊࠦࡉࡏࡘࡈࡗ࡙ࡏࡇࡂࡖࡌࡓࡓ࠭ࢤ") : return 249
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡆࡄ࡚ࡊ࠭ࢥ") : return 230
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡇࡍࡘࡉࡏࡗࡇࡕ࡝ࠥࡎࡉࡔࡖࡒࡖ࡞࠭ࢦ") : return 20
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡈࡎ࡙ࡃࡐࡘࡈࡖ࡞ࠦࡓࡄࡋࡈࡒࡈࡋࠧࢧ") : return 103
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫࡉࡏࡓࡄࡑ࡙ࡉࡗ࡟ࠠࡕࡗࡕࡆࡔ࠭ࢨ") : return 102
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠬࡊࡉࡔࡅࡒ࡚ࡊࡘ࡙࠲ࠩࢩ") : return 98
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡄࡊࡕࡆࡓ࡛ࡋࡒ࡚ࠩࢪ") : return 370
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡅࡋࡖࡒࡊ࡟ࡃࡉࡐࡏࠫࢫ") : return 117
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡆࡌࡗࡓࡋ࡙ࡋࡗࡑࡍࡔࡘࠧࢬ") : return 118
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡈࡗࡕࡔࠠ࠳ࠩࢭ") : return 349
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡉࡘࡖࡎࠨࢮ") : return 348
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫࡊࡊࡅࡏࠢ࠮࠵ࠬࢯ") : return 278
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠬࡋࡉࡓࠢࡖࡔࡔࡘࡔࡔࠩࢰ") : return 30
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡅࡖࡔࡒࡒࡊ࡝ࡓࠨࢱ") : return 398
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡇࡑ࡛ࠤࡘࡖࡏࡓࡖࡖࠤ࠶࠭ࢲ") : return 352
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡈࡒ࡜ࠥࡔࡅࡘࡕࠪࢳ") : return 274
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡊࡓࡑࡊࠠࡖࡍࠪࢴ") : return 277
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡌ࠷ࠦࡕࡌࠩࢵ") : return 271
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫࡍࡈࡏࠡࡇࡄࡗ࡙࠭ࢶ") : return 376
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠬࡎࡂࡐࠢࡉࡅࡒࡏࡌ࡚ࠩࢷ") : return 377
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡈࡃࡑࠣࡗࡎࡍࡎࡂࡖࡘࡖࡊ࠭ࢸ") : return 378
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡉࡄࡒࠤ࡟ࡕࡎࡆࠩࢹ") : return 379
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡊࡊࡘ࡛࠭ࢺ") : return 384
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡋࡍࡘ࡚ࡏࡓ࡛࡙ࠣࡐ࠭ࢻ") : return 268
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡌࡎ࡙ࡔࡐࡔ࡜ࠤ࡚࡙ࡁࠨࢼ") : return 369
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫࡍࡕࡍࡆࠢ࠮࠵ࠬࢽ") : return 279
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠬࡎࡏࡓࡔࡒࡖࠥࡉࡈࡂࡐࡑࡉࡑࠦࡕࡌࠩࢾ") : return 183
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡉࡅࠢࡘࡏࠬࢿ") : return 229
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡊࡖ࡙ࠤ࠷࠭ࣀ") : return 208
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡋࡗ࡚ࠥ࠹ࠧࣁ") : return 207
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡌࡘ࡛ࠦ࠴ࠨࣂ") : return 209
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡍ࡙࡜ࠧࣃ") : return 206
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫࡑࡌࡃࠡࡖ࡙ࠫࣄ") : return 180
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠬࡓࡉࡐࠢࡖࡘࡆࡊࡉࡖࡏࠣ࠵࠵࠸ࠠࡉࡆࠪࣅ") : return 334
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡍࡊࡑࠣࡗ࡙ࡇࡄࡊࡗࡐࠤ࠶࠶࠳ࠡࡊࡇࠫࣆ") : return 335
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡎࡋࡒࠤࡘ࡚ࡁࡅࡋࡘࡑࠥ࠷࠰࠵ࠢࡋࡈࠬࣇ") : return 336
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡏࡌࡓ࡙ࠥࡔࡂࡆࡌ࡙ࡒࠦ࠱࠱࠷ࠣࡌࡉ࠭ࣈ") : return 337
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡐࡍࡔࠦࡓࡕࡃࡇࡍ࡚ࡓࠠ࠲࠲࠹ࠤࡍࡊࠧࣉ") : return 338
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡑࡎࡕࠠࡔࡖࡄࡈࡎ࡛ࡍࠡ࠳࠳࠻ࠥࡎࡄࠨ࣊") : return 333
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫࡒ࡚ࡖࠡࡄࡄࡗࡊ࠭࣋") : return 132
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠬࡓࡔࡗࠢࡇࡅࡓࡉࡅࠨ࣌") : return 131
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡍࡕࡘࠣࡌࡎ࡚ࡓࠢࠩ࣍") : return 135
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡎࡖ࡙ࠤࡒ࡛ࡓࡊࡅࠪ࣎") : return 217
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡏࡗ࡚ࠥࡘࡏࡄࡍࡖ࣏ࠫ") : return 133
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡐ࡙࡙࡜࣐ࠧ") : return 106
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡑࡔ࡚ࡏࡓࡕ࡙ࠣࡐ࣑࠭") : return 215
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫࡓࡈࡁࠨ࣒") : return 283
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠬࡔࡂࡄࠢࡈࡅࡘ࡚࣓ࠧ") : return 361
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡎࡊࡅࡎࠤ࡙ࡕࡏࡏࡕࠪࣔ") : return 296
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡏࡃࡗࠤࡌࡋࡏ࡙ࠡࡌࡐࡉࠦࡕࡌࠩࣕ") : return 269
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡐࡄࡘࡎࡕࡎࡂࡎࠣࡋࡊࡕࡇࡓࡃࡓࡌࡎࡉࠠࡖࡍࠪࣖ") : return 270
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡑࡅ࡙ࡏࡏࡏࡃࡏࠤࡌࡋࡏࡈࡔࡄࡔࡍࡏࡃࠡࡗࡖࡅࠬࣗ") : return 371
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡒࡎࡉࡋࠡࡌࡘࡒࡎࡕࡒࠨࣘ") : return 297
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫࡓࡏࡃࡌࠢࡘࡏࠬࣙ") : return 295
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠬࡖࡒࡆࡏࡌࡉࡗ࡙ࡐࡐࡔࡗࡗࠬࣚ") : return 29
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡒࡕࡇࠣࡓࡓࡋࠧࣛ") : return 69
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡓࡖࡈࠤ࡙࡝ࡏ࡜ࡊࡇࡡࠬࣜ") : return 70
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡔࡗࡉࡏࡘࠧࣝ") : return 89
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡕࡅࡈࡏࡎࡈࠢࡘࡏࠬࣞ") : return 26
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡖࡊࡇࡌࠡࡎࡌ࡚ࡊ࡙ࠧࣟ") : return 275
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫࡘࡑ࡙ࠡࡄࡘࡒࡉࡋࡓࡍࡋࡊࡅࠥ࠷ࠠࡉࡆ࡞ࡈࡊࡣࠧ࣠") : return 408
    if l1ll111_opy_ == l1lllll_opy_ (u"࡙ࠬࡋ࡚ࠢࡑࡉ࡜࡙ࠧ࣡") : return 263
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡓࡌ࡛ࠣ࠵ࠬ࣢") : return 177
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡔࡍ࡜ࠤ࠷ࣣ࠭") : return 178
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡕࡎ࡝ࠥࡇࡃࡕࡋࡒࡒࠥࡓࡏࡗࡋࡈࡗࠬࣤ") : return 16
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡖࡏ࡞ࠦࡁࡕࡎࡄࡒ࡙ࡏࡃࠨࣥ") : return 174
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡗࡐ࡟ࠠࡄࡑࡐࡉࡉ࡟ࠠࡎࡑ࡙ࡍࡊ࡙ࣦࠧ") : return 34
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫࡘࡑ࡙ࠡࡆࡕࡅࡒࡇࡒࡐࡏࠣࡑࡔ࡜ࡉࡆࡕࠪࣧ") : return 97
    if l1ll111_opy_ == l1lllll_opy_ (u"࡙ࠬࡋ࡚ࠢࡉࡅࡒࡏࡌ࡚ࠢࡐࡓ࡛ࡏࡅࡔࠩࣨ") : return 36
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡓࡌ࡛ࠣࡋࡗࡋࡁࡕࡕࠣࡑࡔ࡜ࡉࡆࡕࣩࠪ") : return 37
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡔࡍ࡜ࠤࡒࡕࡖࡊࡇࡖࠤࡉࡏࡓࡏࡇ࡜ࠫ࣪") : return 220
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡕࡎ࡝ࠥࡖࡒࡆࡏࡌࡉࡗࡋࠠࡎࡑ࡙ࡍࡊ࡙ࠧ࣫") : return 40
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡖࡏ࡞ࠦࡓࡄࡈࡌࡌࡔࡘࡒࡐࡔࠣࡑࡔ࡜ࡉࡆࡕࠪ࣬") : return 41
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡗࡐ࡟ࠠࡔࡇࡏࡉࡈ࡚ࠠࡎࡑ࡙ࡍࡊ࡙࣭ࠧ") : return 42
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫࡘࡑ࡙ࠡࡕࡓࠤࡓࡋࡗࡔࠢࡋࡕ࣮ࠬ") : return 175
    if l1ll111_opy_ == l1lllll_opy_ (u"࡙ࠬࡋ࡚ࠢࡖࡔࡔࡘࡔࠡ࠳ࠣࡌࡉࠦࠨࡕࡇࡖࡘ࠮࣯࠭") : return 301
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡓࡌ࡛ࠣࡗࡕࡕࡒࡕࠢ࠵ࠤࡍࡊࠠࠩࡖࡈࡗ࡙࠯ࣰࠧ") : return 302
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡔࡍ࡜ࠤࡘࡖࡏࡓࡖࠣ࠷ࠥࡎࡄࠡࠪࡗࡉࡘ࡚ࠩࠨࣱ") : return 303
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡕࡎ࡝࡙ࠥࡐࡐࡔࡗࠤ࠹ࠦࡈࡅࠢࠫࡘࡊ࡙ࡔࣲࠪࠩ") : return 304
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡖࡏ࡞ࠦࡓࡑࡑࡕࡘࠥ࠻ࠠࡉࡆ࡙ࠣࠬࡋࡓࡕࠫࠪࣳ") : return 305
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡗࡐ࡟ࠠࡔࡒࡒࡖ࡙࡙ࠠ࠲ࠩࣴ") : return 95
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫࡘࡑ࡙ࠡࡕࡓࡓࡗ࡚ࡓࠡ࠴ࠪࣵ") : return 136
    if l1ll111_opy_ == l1lllll_opy_ (u"࡙ࠬࡋ࡚ࠢࡖࡔࡔࡘࡔࡔࠢ࠶ࣶࠫ") : return 43
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡓࡌ࡛ࠣࡗࡕࡕࡒࡕࡕࠣ࠸ࠬࣷ") : return 119
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡔࡍ࡜ࠤࡘࡖࡏࡓࡖࡖࠤ࠺࠭ࣸ") : return 120
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡕࡎ࡝࡚ࠥࡈࡓࡋࡏࡐࡊࡘࠠࡎࡑ࡙ࡍࡊ࡙ࣹࠧ") : return 96
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡖࡏ࡞ࠦࡌࡊࡘࡌࡒࡌࣺ࠭") : return 298
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡗࡕࡕࡒࡕࡕࠣࡊ࠶࠭ࣻ") : return 45
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫࡘ࡟ࡆ࡚ࠢࡘࡗࡆ࠭ࣼ") : return 383
    if l1ll111_opy_ == l1lllll_opy_ (u"࡚ࠬࡃࡎࠢ࠮࠵࡛ࠥࡋࠨࣽ") : return 189
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡔࡈ࠶ࠪࣾ") : return 88
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡕࡕࡑࠤ࠶࠭ࣿ") : return 339
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡖࡖࡒࠥ࠸ࠧऀ") : return 340
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡗࡗࡓࠦ࠳ࠨँ") : return 341
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪࡘࡘࡔࠠ࠵ࠩं") : return 342
    if l1ll111_opy_ == l1lllll_opy_ (u"࡙࡙ࠫࡎࠡ࠷ࠪः") : return 343
    if l1ll111_opy_ == l1lllll_opy_ (u"࡚ࠬࡖ࠴ࠢࡌࡉࠬऄ") : return 87
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡔࡓࡃ࡙ࡉࡑࠦࡃࡉࡃࡑࡒࡊࡒࠫ࠲ࠢࡘࡏࠬअ") : return 184
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠧࡖࡕࡄࠤࡋࡕࡘࠡࡕࡓࡓࡗ࡚ࡓࠨआ") : return 347
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨࡗࡖࡅࠥࡔࡅࡕ࡙ࡒࡖࡐ࠭इ") : return 344
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠩࡘࡘ࡛ࠦࡉࡆࠩई") : return 272
    if l1ll111_opy_ == l1lllll_opy_ (u"࡚ࠪࡎ࡜ࡁࠡࡖࡋࡉࠥࡎࡉࡕࡕࠤࠫउ") : return 130
    if l1ll111_opy_ == l1lllll_opy_ (u"࡛ࠫࡏࡁࡔࡃࡗࠤࡌࡕࡌࡇࠩऊ") : return 125
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠬ࡝ࡁࡕࡅࡋࠤࡎࡘࡅࡍࡃࡑࡈࠬऋ") : return 281
    if l1ll111_opy_ == l1lllll_opy_ (u"࠭ࡘ࡙࡚࠴ࠫऌ") : return 314
    if l1ll111_opy_ == l1lllll_opy_ (u"࡙࡚࡛ࠧ࠶ࠬऍ") : return 315
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠨ࡚࡛࡜࠸࠭ऎ") : return 316
    if l1ll111_opy_ == l1lllll_opy_ (u"࡛ࠩ࡜࡝࠺ࠧए") : return 317
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠪ࡜࡝࡞࠵ࠨऐ") : return 318
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠫ࡞ࡋࡓࡕࡇࡕࡈࡆ࡟ࠠࠬ࠳ࠪऑ") : return 282
    if l1ll111_opy_ == l1lllll_opy_ (u"ࠬࡓࡏࡗ࠶ࡐࡉࡓ࠷ࠧऒ") : return 33
def getHDTVRecording(name, title, start, stream):
    l1llll11_opy_ = stream.split(l1lllll_opy_ (u"࠭ࡼࠨओ"))
    for url in l1llll11_opy_:
        url   = url.split(CLOSE_OTT)[1].rsplit(l1lllll_opy_ (u"ࠧ࠻ࠩऔ"))
        l1ll1ll_opy_ = url[0]
        if l1ll1ll_opy_ == l1lllll_opy_ (u"ࠨࡊࡇࡘ࡛࠭क"):
            addon = l1lllll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡰࡥࡷࡺࡨࡶࡤࠪख")
        else:
            addon = l1lllll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧ࠲ࠨग")
    dixie.log(l1lllll_opy_ (u"ࠫࡆࡪࡤࡰࡰࠣࡍࡉ࠴࠮࠯࠼ࠣࠩࡸ࠭घ") % addon)
    Addon  = xbmcaddon.Addon(id=addon)
    path   = Addon.getAddonInfo(l1lllll_opy_ (u"ࠬࡶࡡࡵࡪࠪङ"))
    import sys
    sys.path.insert(0, path)
    import api
    l1l11_opy_ = Addon.getSetting(l1lllll_opy_ (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧच"))
    l1lll11l_opy_  = Addon.getSetting(l1lllll_opy_ (u"ࠧࡴࡧࡵࡺࡪࡸࠧछ"))
    l111l1l_opy_    = l1lllll_opy_ (u"ࠨࠨࡧࡁࡰࡵࡤࡪࠨࡶࡁࠬज") + l1l11_opy_ + l1lllll_opy_ (u"ࠩࠩࡳࡂ࠭झ") + l1lll11l_opy_
    import urllib
    l11l111_opy_ = l1l1l1l_opy_()
    dixie.log(l1lllll_opy_ (u"ࠪࡉࡕࡍࠠࡔࡶࡤࡶࡹࠦࡔࡪ࡯ࡨ࠲࠳࠴࠺ࠡࠧࡶࠫञ") % start)
    dixie.log(l1lllll_opy_ (u"ࠫࡔ࡬ࡦࡴࡧࡷࠤ࡮ࡴࠠࡴࡧࡦࡳࡳࡪࡳ࠻ࠢࠨࡷࠬट") % l11l111_opy_)
    l1ll1l11_opy_  =  start - datetime.timedelta(seconds=l11l111_opy_)
    dixie.log(l1lllll_opy_ (u"࡙ࠬࡴࡢࡴࡷࠤ࡙࡯࡭ࡦࠢࡲࡪ࡫ࡹࡥࡵ࠼ࠣࠩࡸ࠭ठ") % l1ll1l11_opy_)
    l11l1_opy_ = str(l1ll1l11_opy_)
    l1l1llll_opy_  = l11l1_opy_.split(l1lllll_opy_ (u"࠭ࠠࠨड"))[0]
    l11l1l1_opy_     = l1ll111l_opy_(name)
    if not l11l1l1_opy_:
        dixie.DialogOK(l1lllll_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠴ࠧढ"), l1lllll_opy_ (u"ࠨ࡙ࡨࠤࡨࡵࡵ࡭ࡦࠣࡲࡴࡺࠠࡧ࡫ࡱࡨࠥࡧࠠࡤࡣࡷࡧ࡭ࡻࡰࠡࡵࡨࡶࡻ࡯ࡣࡦࠢࡩࡳࡷࠦࡴࡩ࡫ࡶࠤࡨ࡮ࡡ࡯ࡰࡨࡰ࠳࠭ण"), l1lllll_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡷࡶࡾࠦࡡ࡯ࡱࡷ࡬ࡪࡸࠠࡤࡪࡤࡲࡳ࡫࡬࠯ࠩत"))
        return None
    l11l11l_opy_  = l11l1_opy_.split(l1lllll_opy_ (u"ࠪ࠱ࠬथ"), 1)[-1].rsplit(l1lllll_opy_ (u"ࠫ࠿࠭द"), 1)[0]
    theTime    = urllib.quote_plus(l11l11l_opy_)
    response   = api.remote_call( l1lllll_opy_ (u"ࠧࡺࡶࡢࡴࡦ࡬࡮ࡼࡥ࠰ࡩࡨࡸࡤࡨࡹࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡡࡤࡲࡩࡥࡤࡢࡶࡨ࠲ࡵ࡮ࡰࠣध") , {l1lllll_opy_ (u"ࠨࡤࡢࡶࡨࠦन"): l1l1llll_opy_, l1lllll_opy_ (u"ࠢࡪࡦࠥऩ"): l11l1l1_opy_ } )
    l11l1ll_opy_ = response[l1lllll_opy_ (u"ࠣࡤࡲࡨࡾࠨप")]
    if not l11l1ll_opy_:
        dixie.DialogOK(l1lllll_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠯ࠩफ"), l1lllll_opy_ (u"࡛ࠪࡪࠦࡣࡰࡷ࡯ࡨࠥࡴ࡯ࡵࠢࡩ࡭ࡳࡪࠠࡢࠢࡦࡥࡹࡩࡨࡶࡲࠣࡷࡹࡸࡥࡢ࡯ࠣࡪࡴࡸࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲ࠴ࠧब"), l1lllll_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡹࡸࡹࠡࡣࡪࡥ࡮ࡴࠠ࡭ࡣࡷࡩࡷ࠴ࠧभ"))
        return None
    for l1lll111_opy_ in l11l1ll_opy_:
        l1111l_opy_ = l1lll111_opy_[l1lllll_opy_ (u"ࠧࡶ࡬ࡰࡶࠥम")]
        if l11l11l_opy_ in l1111l_opy_:
            dixie.DialogOK(l1lllll_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡯ࡳࡣࡱ࡫ࡪࡣࡃࡢࡶࡦ࡬࠲ࡻࡰࠡࡵࡷࡶࡪࡧ࡭ࠡࡨࡲࡹࡳࡪ࠮࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩय"), l1lllll_opy_ (u"ࠧࡐࡰ࠰ࡘࡦࡶࡰ࠯ࡖ࡙ࠤࡼ࡯࡬࡭ࠢࡱࡳࡼࠦࡰ࡭ࡣࡼ࠾ࠥࡡࡃࡐࡎࡒࡖࠥࡵࡲࡢࡰࡪࡩࡢࡡࡂ࡞ࠧࡶ࡟࠴ࡈ࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩर") % (title))
            return l1lll111_opy_[l1lllll_opy_ (u"ࠣࡷࡵࡰࠧऱ")] + l111l1l_opy_
def l1ll111l_opy_(name):
    l1l111_opy_   = dixie.PROFILE
    l1l_opy_ = os.path.join(l1l111_opy_, l1lllll_opy_ (u"ࠩ࡬ࡲ࡮࠭ल"), l1lllll_opy_ (u"ࠪࡧࡦࡺࡣࡩࡷࡳ࠲ࡹࡾࡴࠨळ"))
    l1111ll_opy_   = json.load(open(l1l_opy_))
    for channel in l1111ll_opy_:
        if name.upper() == channel[l1lllll_opy_ (u"ࠫࡔ࡚ࡔࡗࠩऴ")].upper():
            return channel[l1lllll_opy_ (u"࡛ࠬࡒࡍࠩव")]
def l1l1l1l_opy_():
    import time
    gmt = time.gmtime()
    loc = time.localtime()
    GMT = datetime.datetime(*gmt[:6]).isoformat(l1lllll_opy_ (u"࠭ࠠࠨश"))
    LOC = datetime.datetime(*loc[:6]).isoformat(l1lllll_opy_ (u"ࠧࠡࠩष"))
    dixie.log(gmt)
    dixie.log(loc)
    l1_opy_ = dixie.parseTime(GMT)
    l1lll1l1_opy_ = dixie.parseTime(LOC)
    dixie.log(l1_opy_)
    dixie.log(l1lll1l1_opy_)
    dixie.log(l1lllll_opy_ (u"ࠨࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࠥࡕࡆࡇࡕࡈࡘࠥࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࠪस"))
    l11l111_opy_ = l1_opy_ - l1lll1l1_opy_
    dixie.log(l11l111_opy_)
    l11l111_opy_ = ((l11l111_opy_.days * 86400) + (l11l111_opy_.seconds + 1800)) / 3600
    dixie.log(l11l111_opy_)
    l11l111_opy_ *= -3600
    dixie.log(l11l111_opy_)
    dixie.log(l1lllll_opy_ (u"ࠩࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࠫह"))
    return l11l111_opy_