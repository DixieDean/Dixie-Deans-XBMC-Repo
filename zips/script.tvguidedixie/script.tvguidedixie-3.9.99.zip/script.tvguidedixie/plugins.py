# coding: UTF-8
import sys
l1l11l1l_opy_ = sys.version_info [0] == 2
l1llll11_opy_ = 2048
l1l1ll11_opy_ = 7
def l11ll_opy_ (l1l11l_opy_):
	global l1llllll_opy_
	l1ll1ll1_opy_ = ord (l1l11l_opy_ [-1])
	l1l1l1l1_opy_ = l1l11l_opy_ [:-1]
	l11l11l_opy_ = l1ll1ll1_opy_ % len (l1l1l1l1_opy_)
	l11ll1_opy_ = l1l1l1l1_opy_ [:l11l11l_opy_] + l1l1l1l1_opy_ [l11l11l_opy_:]
	if l1l11l1l_opy_:
		l1llll_opy_ = unicode () .join ([unichr (ord (char) - l1llll11_opy_ - (l111l11_opy_ + l1ll1ll1_opy_) % l1l1ll11_opy_) for l111l11_opy_, char in enumerate (l11ll1_opy_)])
	else:
		l1llll_opy_ = str () .join ([chr (ord (char) - l1llll11_opy_ - (l111l11_opy_ + l1ll1ll1_opy_) % l1l1ll11_opy_) for l111l11_opy_, char in enumerate (l11ll1_opy_)])
	return eval (l1llll_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l1lll111l1_opy_     = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡰࡷࡺࠬ઺")
l1lll111ll_opy_  = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡺࡰ࡮ࡶࡴࡷࠩ઻")
l1lll1lll1_opy_     = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡹࡰࡺࡵࡳ࡭઼ࠪ")
locked  = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡱࡵࡣ࡬ࡧࡧࡸࡻ࠭ઽ")
l1lll1l1l1_opy_      = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡻ࡬ࡵ࡫ࡰࡥࡹ࡫࡭ࡢࡰ࡬ࡥࠬા")
l11llll1_opy_    = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡬ࡪࡷࡻ࠲ࡹࡼࠧિ")
l1lll11l1l_opy_     = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡅࡅࡖࡴࡴࡸࡴࡴࠩી")
l1lll1l1ll_opy_  = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡨࡦࡴࡵࡴࠨુ")
l1lll11l11_opy_     = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡦࡰࡺ࡯ࡰࡵࡸࠪૂ")
l1lll1111l_opy_ = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡹࡰࡺࡶ࠵ࡧࡻࡴࡦࡺࡳ࠯ࡥࡲࡱࠬૃ")
l1ll11ll_opy_ = [l1lll111l1_opy_, locked, l11llll1_opy_, l1lll111ll_opy_, l1lll1111l_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l11ll_opy_ (u"ࠬ࡯࡮ࡪࠩૄ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1ll11l1l_opy_ = l11ll_opy_ (u"࠭ࠧૅ")
def l1l1lll1l_opy_(i, t1, l1ll11l11_opy_=[]):
 t = l1ll11l1l_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1ll11l11_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11l111l_opy_ = l1l1lll1l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11l1111_opy_ = l1l1lll1l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1ll11ll_opy_:
        if l1l1lllll_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1l1lllll_opy_(addon):
    if xbmc.getCondVisibility(l11ll_opy_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡉࡣࡶࡅࡩࡪ࡯࡯ࠪࠨࡷ࠮࠭૆") % addon) == 1:
        return True
    return False
def createINI(addon):
    l1lll1l11_opy_ = str(addon).split(l11ll_opy_ (u"ࠨ࠰ࠪે"))[2] + l11ll_opy_ (u"ࠩ࠱࡭ࡳ࡯ࠧૈ")
    l1lllll11_opy_  = os.path.join(PATH, l1lll1l11_opy_)
    try:
        l11l111_opy_ = l11lll11_opy_(addon)
    except KeyError:
        dixie.log(l11ll_opy_ (u"ࠪ࠱࠲࠳࠭࠮ࠢࡎࡩࡾࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡨࡧࡷࡊ࡮ࡲࡥࡴࠢ࠰࠱࠲࠳࠭ࠡࠩૉ") + addon)
        result = {l11ll_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࡶࠫ૊"): [{l11ll_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨો"): l11ll_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࠬૌ"), l11ll_opy_ (u"ࡵࠨࡶࡼࡴࡪ્࠭"): l11ll_opy_ (u"ࡶࠩࡸࡲࡰࡴ࡯ࡸࡰࠪ૎"), l11ll_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࠨ૏"): l11ll_opy_ (u"ࡸࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾࡸࡹࠩૐ"), l11ll_opy_ (u"ࡹࠬࡲࡡࡣࡧ࡯ࠫ૑"): l11ll_opy_ (u"ࡺ࠭ࡎࡐࠢࡆࡌࡆࡔࡎࡆࡎࡖࠫ૒")}], l11ll_opy_ (u"ࡻࠧ࡭࡫ࡰ࡭ࡹࡹࠧ૓"):{l11ll_opy_ (u"ࡵࠨࡵࡷࡥࡷࡺࠧ૔"): 0, l11ll_opy_ (u"ࡶࠩࡷࡳࡹࡧ࡬ࠨ૕"): 1, l11ll_opy_ (u"ࡷࠪࡩࡳࡪࠧ૖"): 1}}
    l1llllll1_opy_  = l11ll_opy_ (u"ࠪ࡟ࠬ૗") + addon + l11ll_opy_ (u"ࠫࡢࡢ࡮ࠨ૘")
    l11l1l11_opy_  =  file(l1lllll11_opy_, l11ll_opy_ (u"ࠬࡽࠧ૙"))
    l11l1l11_opy_.write(l1llllll1_opy_)
    l1llll111_opy_ = []
    for channel in l11l111_opy_:
        l111ll11_opy_ = dixie.cleanLabel(channel[l11ll_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬ૚")])
        l1l1111_opy_   = dixie.cleanPrefix(l111ll11_opy_)
        l11l1l1l_opy_ = dixie.mapChannelName(l1l1111_opy_)
        stream   = channel[l11ll_opy_ (u"ࠧࡧ࡫࡯ࡩࠬ૛")]
        l111llll_opy_ = l11l1l1l_opy_ + l11ll_opy_ (u"ࠨ࠿ࠪ૜") + stream
        l1llll111_opy_.append(l111llll_opy_)
        l1llll111_opy_.sort()
    for item in l1llll111_opy_:
        l11l1l11_opy_.write(l11ll_opy_ (u"ࠤࠨࡷࡡࡴࠢ૝") % item)
    l11l1l11_opy_.close()
def l11lll11_opy_(addon):
    if (addon == l1lll111l1_opy_) or (addon == l1lll111ll_opy_):
        if xbmcaddon.Addon(addon).getSetting(l11ll_opy_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ૞")) == l11ll_opy_ (u"ࠫࡹࡸࡵࡦࠩ૟"):
            xbmcaddon.Addon(addon).setSetting(l11ll_opy_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫૠ"), l11ll_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬૡ"))
            xbmcgui.Window(10000).setProperty(l11ll_opy_ (u"ࠧࡑࡎࡘࡋࡎࡔ࡟ࡈࡇࡑࡖࡊ࠭ૢ"), l11ll_opy_ (u"ࠨࡖࡵࡹࡪ࠭ૣ"))
        if xbmcaddon.Addon(addon).getSetting(l11ll_opy_ (u"ࠩࡷࡺ࡬ࡻࡩࡥࡧࠪ૤")) == l11ll_opy_ (u"ࠪࡸࡷࡻࡥࠨ૥"):
            xbmcaddon.Addon(addon).setSetting(l11ll_opy_ (u"ࠫࡹࡼࡧࡶ࡫ࡧࡩࠬ૦"), l11ll_opy_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫ૧"))
            xbmcgui.Window(10000).setProperty(l11ll_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡔࡗࡉࡘࡍࡉࡋࠧ૨"), l11ll_opy_ (u"ࠧࡕࡴࡸࡩࠬ૩"))
        l1l11ll_opy_  = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫ૪") + addon
        l1lll11lll_opy_ =  l1lll1llll_opy_(addon)
        query   =  l1l11ll_opy_ + l1lll11lll_opy_
        return sendJSON(query, addon)
    return l1l11l11_opy_(addon)
def l1l11l11_opy_(addon):
    if addon == l1lll1111l_opy_:
        l1111l1_opy_ = [l11ll_opy_ (u"ࠩ࠴࠺࠶࠭૫"), l11ll_opy_ (u"ࠪ࠵࠻࠶ࠧ૬"), l11ll_opy_ (u"ࠫ࠷࠹࠶ࠨ૭"), l11ll_opy_ (u"ࠬ࠸࠴࠳ࠩ૮"), l11ll_opy_ (u"࠭࠱࠶࠺ࠪ૯"), l11ll_opy_ (u"ࠧ࠲࠷࠼ࠫ૰")]
    if addon == l11llll1_opy_:
        l1111l1_opy_ = [l11ll_opy_ (u"ࠨ࠷ࠪ૱"), l11ll_opy_ (u"ࠩ࠴࠴࠻࠭૲"), l11ll_opy_ (u"ࠪ࠸ࠬ૳"), l11ll_opy_ (u"ࠫ࠷࠼࠳ࠨ૴"), l11ll_opy_ (u"ࠬ࠷࠳࠳ࠩ૵")]
    if addon == locked:
        l1111l1_opy_ = [l11ll_opy_ (u"࠭࠳࠱ࠩ૶"), l11ll_opy_ (u"ࠧ࠴࠳ࠪ૷"), l11ll_opy_ (u"ࠨ࠵࠵ࠫ૸"), l11ll_opy_ (u"ࠩ࠶࠷ࠬૹ"), l11ll_opy_ (u"ࠪ࠷࠹࠭ૺ"), l11ll_opy_ (u"ࠫ࠸࠻ࠧૻ"), l11ll_opy_ (u"ࠬ࠹࠸ࠨૼ"), l11ll_opy_ (u"࠭࠴࠱ࠩ૽"), l11ll_opy_ (u"ࠧ࠵࠳ࠪ૾"), l11ll_opy_ (u"ࠨ࠶࠸ࠫ૿"), l11ll_opy_ (u"ࠩ࠷࠻ࠬ଀"), l11ll_opy_ (u"ࠪ࠸࠾࠭ଁ"), l11ll_opy_ (u"ࠫ࠺࠸ࠧଂ")]
    if addon == l1lll1l1l1_opy_:
        l1111l1_opy_ = [l11ll_opy_ (u"ࠬ࠸࠵ࠨଃ"), l11ll_opy_ (u"࠭࠲࠷ࠩ଄"), l11ll_opy_ (u"ࠧ࠳࠹ࠪଅ"), l11ll_opy_ (u"ࠨ࠴࠼ࠫଆ"), l11ll_opy_ (u"ࠩ࠶࠴ࠬଇ"), l11ll_opy_ (u"ࠪ࠷࠶࠭ଈ"), l11ll_opy_ (u"ࠫ࠸࠸ࠧଉ"), l11ll_opy_ (u"ࠬ࠹࠵ࠨଊ"), l11ll_opy_ (u"࠭࠳࠷ࠩଋ"), l11ll_opy_ (u"ࠧ࠴࠹ࠪଌ"), l11ll_opy_ (u"ࠨ࠵࠻ࠫ଍"), l11ll_opy_ (u"ࠩ࠶࠽ࠬ଎"), l11ll_opy_ (u"ࠪ࠸࠵࠭ଏ"), l11ll_opy_ (u"ࠫ࠹࠷ࠧଐ"), l11ll_opy_ (u"ࠬ࠺࠸ࠨ଑"), l11ll_opy_ (u"࠭࠴࠺ࠩ଒"), l11ll_opy_ (u"ࠧ࠶࠲ࠪଓ"), l11ll_opy_ (u"ࠨ࠷࠵ࠫଔ"), l11ll_opy_ (u"ࠩ࠸࠸ࠬକ"), l11ll_opy_ (u"ࠪ࠹࠻࠭ଖ"), l11ll_opy_ (u"ࠫ࠺࠽ࠧଗ"), l11ll_opy_ (u"ࠬ࠻࠸ࠨଘ"), l11ll_opy_ (u"࠭࠵࠺ࠩଙ"), l11ll_opy_ (u"ࠧ࠷࠲ࠪଚ"), l11ll_opy_ (u"ࠨ࠸࠴ࠫଛ"), l11ll_opy_ (u"ࠩ࠹࠶ࠬଜ"), l11ll_opy_ (u"ࠪ࠺࠸࠭ଝ"), l11ll_opy_ (u"ࠫ࠻࠻ࠧଞ"), l11ll_opy_ (u"ࠬ࠼࠶ࠨଟ"), l11ll_opy_ (u"࠭࠶࠸ࠩଠ"), l11ll_opy_ (u"ࠧ࠷࠻ࠪଡ"), l11ll_opy_ (u"ࠨ࠹࠳ࠫଢ"), l11ll_opy_ (u"ࠩ࠺࠸ࠬଣ"), l11ll_opy_ (u"ࠪ࠻࠼࠭ତ"), l11ll_opy_ (u"ࠫ࠼࠾ࠧଥ"), l11ll_opy_ (u"ࠬ࠾࠰ࠨଦ"), l11ll_opy_ (u"࠭࠸࠲ࠩଧ")]
    login = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷ࠴࠭ନ") % addon
    sendJSON(login, addon)
    l111111_opy_ = []
    for l1111l_opy_ in l1111l1_opy_:
        if (addon == l1lll1111l_opy_) or (addon == l11llll1_opy_):
            query = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸ࠵࠿࡮ࡱࡧࡩࡤ࡯ࡤ࠾ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠩࡱࡴࡪࡥ࠾ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠩࡷࡪࡩࡴࡪࡱࡱࡣ࡮ࡪ࠽ࠦࡵࠪ଩") % (addon, l1111l_opy_)
        if (addon == locked) or (addon == l1lll1l1l1_opy_):
            query = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠪࡹ࠯ࡀࡷࡵࡰࡂࠫࡳࠧ࡯ࡲࡨࡪࡃ࠴ࠧࡰࡤࡱࡪࡃࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡵࡲࡡࡺ࠿ࠩࡨࡦࡺࡥ࠾ࠨࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴ࠽ࠧࡲࡤ࡫ࡪࡃࠧପ") % (addon, l1111l_opy_)
        response = sendJSON(query, addon)
        l111111_opy_.extend(response)
    return l111111_opy_
def sendJSON(query, addon):
    l1111ll_opy_     = l11ll_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ଫ") % query
    l1111_opy_  = xbmc.executeJSONRPC(l1111ll_opy_)
    response = json.loads(l1111_opy_)
    result   = response[l11ll_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫବ")]
    if xbmcgui.Window(10000).getProperty(l11ll_opy_ (u"ࠬࡖࡌࡖࡉࡌࡒࡤࡍࡅࡏࡔࡈࠫଭ")) == l11ll_opy_ (u"࠭ࡔࡳࡷࡨࠫମ"):
        xbmcaddon.Addon(addon).setSetting(l11ll_opy_ (u"ࠧࡨࡧࡱࡶࡪ࠭ଯ"), l11ll_opy_ (u"ࠨࡶࡵࡹࡪ࠭ର"))
    if xbmcgui.Window(10000).getProperty(l11ll_opy_ (u"ࠩࡓࡐ࡚ࡍࡉࡏࡡࡗ࡚ࡌ࡛ࡉࡅࡇࠪ଱")) == l11ll_opy_ (u"ࠪࡘࡷࡻࡥࠨଲ"):
        xbmcaddon.Addon(addon).setSetting(l11ll_opy_ (u"ࠫࡹࡼࡧࡶ࡫ࡧࡩࠬଳ"), l11ll_opy_ (u"ࠬࡺࡲࡶࡧࠪ଴"))
    return result[l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬଵ")]
def l1lll1llll_opy_(addon):
    if (addon == l1lll111l1_opy_) or (addon == l1lll111ll_opy_):
        return l11ll_opy_ (u"ࠧ࠰ࡁࡦࡥࡹࡃ࠭࠳ࠨࡧࡥࡹ࡫ࠦࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠫ࡫࡮ࡥࡆࡤࡸࡪࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࠩࡱࡴࡪࡥ࠾࠴ࠩࡲࡦࡳࡥ࠾ࡏࡼࠩ࠷࠶ࡃࡩࡣࡱࡲࡪࡲࡳࠧࡴࡨࡧࡴࡸࡤ࡯ࡣࡰࡩࠫࡹࡴࡢࡴࡷࡈࡦࡺࡥࠧࡷࡵࡰࡂࡻࡲ࡭ࠩଶ")
    return l11ll_opy_ (u"ࠨࠩଷ")
def l11111ll_opy_():
    modules = map(__import__, [l1l1lll1l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11l111l_opy_)):
        return l11ll_opy_ (u"ࠩࡗࡶࡺ࡫ࠧସ")
    if len(modules[-1].Window(10**4).getProperty(l11l1111_opy_)):
        return l11ll_opy_ (u"ࠪࡘࡷࡻࡥࠨହ")
    return l11ll_opy_ (u"ࠫࡋࡧ࡬ࡴࡧࠪ଺")
def l1ll1ll11_opy_(e, addon):
    l1111l11_opy_ = l11ll_opy_ (u"࡙ࠬ࡯ࡳࡴࡼ࠰ࠥࡧ࡮ࠡࡧࡵࡶࡴࡸࠠࡰࡥࡦࡹࡷ࡫ࡤ࠻ࠢࡍࡗࡔࡔࠠࡆࡴࡵࡳࡷࡀࠠࠦࡵ࠯ࠤࠪࡹࠧ଻")  % (e, addon)
    l111lll1_opy_ = l11ll_opy_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡣࡰࡰࡷࡥࡨࡺࠠࡶࡵࠣࡳࡳࠦࡴࡩࡧࠣࡪࡴࡸࡵ࡮࠰଼ࠪ")
    l1111ll1_opy_ = l11ll_opy_ (u"ࠧࡖࡲ࡯ࡳࡦࡪࠠࡢࠢ࡯ࡳ࡬ࠦࡶࡪࡣࠣࡸ࡭࡫ࠠࡢࡦࡧࡳࡳࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠡࡣࡱࡨࠥࡶ࡯ࡴࡶࠣࡸ࡭࡫ࠠ࡭࡫ࡱ࡯࠳࠭ଽ")
    dixie.log(addon)
    dixie.log(e)
def getPluginInfo(streamurl, kodiID=False):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l1lll1l111_opy_   = l11ll_opy_ (u"ࠨࡍࡲࡨ࡮ࠦࡐࡗࡔࠪା")
            l1lll1ll1l_opy_ = os.path.join(dixie.RESOURCES, l11ll_opy_ (u"ࠩ࡮ࡳࡩ࡯࠭ࡱࡸࡵ࠲ࡵࡴࡧࠨି"))
            return l1lll1l111_opy_, l1lll1ll1l_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l11ll_opy_ (u"ࠪࡶࡹࡳࡰࠨୀ")) or url.startswith(l11ll_opy_ (u"ࠫࡷࡺ࡭ࡱࡧࠪୁ")) or url.startswith(l11ll_opy_ (u"ࠬࡸࡴࡴࡲࠪୂ")) or url.startswith(l11ll_opy_ (u"࠭ࡨࡵࡶࡳࠫୃ")):
            l1lll1l111_opy_   = l11ll_opy_ (u"ࠧ࡮࠵ࡸࠤࡕࡲࡡࡺ࡮࡬ࡷࡹ࠭ୄ")
            l1lll1ll1l_opy_ = os.path.join(dixie.RESOURCES, l11ll_opy_ (u"ࠨ࡫ࡳࡸࡻ࠳ࡰ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡲࡱ࡫ࠬ୅"))
            return l1lll1l111_opy_, l1lll1ll1l_opy_
    except:
        pass
    if streamurl.startswith(l11ll_opy_ (u"ࠩࡳࡺࡷࡀ࠯࠰ࠩ୆")):
        l1lll1l111_opy_   = l11ll_opy_ (u"ࠪࡏࡴࡪࡩࠡࡒ࡙ࡖࠬେ")
        l1lll1ll1l_opy_ = os.path.join(dixie.RESOURCES, l11ll_opy_ (u"ࠫࡰࡵࡤࡪ࠯ࡳࡺࡷ࠴ࡰ࡯ࡩࠪୈ"))
        return l1lll1l111_opy_, l1lll1ll1l_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        l1lll1ll11_opy_ = streamurl.split(l11ll_opy_ (u"ࠬࡣࡏࡕࡖࡢࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭୉"), 1)[-1].split(l11ll_opy_ (u"࠭࠯ࠨ୊"), 1)[0]
    if l11ll_opy_ (u"ࠧ࡞ࡑࡗࡘࡤࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨୋ") in streamurl:
        l1lll1ll11_opy_ = streamurl.split(l11ll_opy_ (u"ࠨ࡟ࡒࡘ࡙ࡥࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩୌ"), 1)[-1].split(l11ll_opy_ (u"ࠩ࠲୍ࠫ"), 1)[0]
    if streamurl.startswith(l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭୎")):
        l1lll1ll11_opy_ = streamurl.split(l11ll_opy_ (u"ࠫ࠴࠵ࠧ୏"), 1)[-1].split(l11ll_opy_ (u"ࠬ࠵ࠧ୐"), 1)[0]
    if l11ll_opy_ (u"࠭࡟ࡠࡕࡉࡣࡤ࠭୑") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡱࡴࡲ࡫ࡷࡧ࡭࠯ࡵࡸࡴࡪࡸ࠮ࡧࡣࡹࡳࡺࡸࡩࡵࡧࡶࠫ୒")
    if l11ll_opy_ (u"ࠨࡏࡗ࡜ࡎࡋ࠺ࠨ୓") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡯ࡤࡸࡷ࡯ࡸࡪࡴࡨࡰࡦࡴࡤࠨ୔")
    if l11ll_opy_ (u"ࠪࡘ࡛ࡑ࠺ࠨ୕") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡸࡻࡱࡩ࡯ࡩࡶࠫୖ")
    if l11ll_opy_ (u"ࠬ࡞ࡔࡄ࠼ࠪୗ") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾࡴࡳࡧࡤࡱ࠲ࡩ࡯ࡥࡧࡶࠫ୘")
    if l11ll_opy_ (u"ࠧࡔࡅࡗ࡚࠿࠭୙") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡥࡷࡺࠬ୚")
    if l11ll_opy_ (u"ࠩࡖ࡙ࡕࡀࠧ୛") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡸࡷ࡫ࡡ࡮ࡵࡸࡴࡷ࡫࡭ࡦ࠴ࠪଡ଼")
    if l11ll_opy_ (u"࡚ࠫࡑࡔ࠻ࠩଢ଼") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡶࡴ࡮ࠫ୞")
    if l11ll_opy_ (u"࠭ࡌࡊࡏࡌࡘ࠿࠭ୟ") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡌࡪ࡯࡬ࡸࡱ࡫ࡳࡴࡋࡓࡘ࡛࠭ୠ")
    if l11ll_opy_ (u"ࠨࡈࡄࡆ࠿࠭ୡ") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡨࡤࡦ࡭ࡵࡳࡵ࡫ࡱ࡫ࠬୢ")
    if l11ll_opy_ (u"ࠪࡅࡈࡋ࠺ࠨୣ") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡨ࡫ࡴࡷࠩ୤")
    if l11ll_opy_ (u"ࠬࡎࡏࡓࡋ࡝࠾ࠬ୥") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡮࡯ࡳ࡫ࡽࡳࡳ࡯ࡰࡵࡸࠪ୦")
    if l11ll_opy_ (u"ࠧࡓࡑࡒࡘ࠷ࡀࠧ୧") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡱࡲࡸࡎࡖࡔࡗࠩ୨")
    if l11ll_opy_ (u"ࠩࡐࡉࡌࡇ࠺ࠨ୩") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡰࡩ࡬ࡧࡩࡱࡶࡹࠫ୪")
    if l11ll_opy_ (u"࡛ࠫࡊࡒࡕࡘ࠽ࠫ୫") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡛ࡇࡄࡆࡔࠪ୬")
    if l11ll_opy_ (u"࠭ࡈࡅࡖ࡙࠾ࠬ୭") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳ࡮ࡣࡵࡸ࡭ࡻࡢࠨ୮")
    if l11ll_opy_ (u"ࠨࡊࡇࡘ࡛࠸࠺ࠨ୯") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࠸ࠧ୰")
    if l11ll_opy_ (u"ࠪࡌࡉ࡚ࡖ࠴࠼ࠪୱ") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡺࡿࡡ࠳ࠩ୲")
    if l11ll_opy_ (u"ࠬࡎࡄࡕࡘ࠷࠾ࠬ୳") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾ࡬ࠨ୴")
    if l11ll_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡀࠧ୵") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡣࡤࡦ࡭ࡵࡲࡡࡺࡧࡵࠫ୶")
    if l11ll_opy_ (u"ࠩࡌࡔࡑࡇ࡙࠳࠼ࠪ୷") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠭୸")
    if l11ll_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡕ࠾ࠬ୹") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶ࡬ࡢࡻࡨࡶࡼࡽࡷࠨ୺")
    if l11ll_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡎ࡚ࡖ࠻ࠩ୻") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡵࡸࠪ୼")
    if l11ll_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡄ࠻ࠩ୽") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡦࡨࡼࠬ୾")
    if l11ll_opy_ (u"ࠪࡎࡎࡔࡘ࠳࠼ࠪ୿") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡮࡮ࡴࡸࡵࡸ࠵ࠫ஀")
    if l11ll_opy_ (u"ࠬࡓࡁࡕࡕ࠽ࠫ஁") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡓࡡࡵࡵࡅࡹ࡮ࡲࡤࡴࡋࡓࡘ࡛࠭ஂ")
    if l11ll_opy_ (u"ࠧࡓࡑࡒࡘ࠿࠭ஃ") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡱࡲࡸ࡮ࡶࡴࡷࠩ஄")
    if l11ll_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡓࡄ࠽ࠫஅ") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡩࡧࡵ࡯ࡵࠩஆ")
    if l11ll_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡆࡐ࡚ࡀࠧஇ") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡨࡲࡵࡪࡲࡷࡺࠬஈ")
    if l11ll_opy_ (u"࠭ࡉࡑࡖࡖࠫஉ") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱࡶࡹࡷࡺࡨࡳࠨஊ")
    if l11ll_opy_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠻ࠩ஋") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮࡬ࡺࡪࡳࡩࡹࠩ஌")
    if l11ll_opy_ (u"ࠪࡉࡓࡊ࠺ࠨ஍") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡉࡳࡪ࡬ࡦࡵࡶࠫஎ")
    if l11ll_opy_ (u"ࠬࡌࡌࡂ࠼ࠪஏ") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡌ࡬ࡢࡹ࡯ࡩࡸࡹࡔࡷࠩஐ")
    if l11ll_opy_ (u"ࠧࡎࡃ࡛ࡍ࠿࠭஑") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡮ࡣࡻ࡭ࡼ࡫ࡢࡵࡸࠪஒ")
    if l11ll_opy_ (u"ࠩࡉࡐࡆ࡙࠺ࠨஓ") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡉࡰࡦࡽ࡬ࡦࡵࡶࡘࡻ࠭ஔ")
    if l11ll_opy_ (u"ࠫࡘࡖࡒࡎ࠼ࠪக") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡘࡻࡰࡳࡧࡰࡥࡨࡿࡔࡗࠩ஖")
    if l11ll_opy_ (u"࠭ࡍࡄࡍࡗ࡚࠿࠭஗") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡭ࡤ࡭ࡷࡺ࠲ࡶ࡬ࡶࡵࠪ஘")
    if l11ll_opy_ (u"ࠨࡖ࡚ࡍࡘ࡚࠺ࠨங") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡶࡺ࡭ࡸࡺࡥࡥࠩச")
    if l11ll_opy_ (u"ࠪࡔࡗࡋࡓࡕ࠼ࠪ஛") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡴࡸࡧࡤࡥࡱࡱࠫஜ")
    if l11ll_opy_ (u"ࠬࡈࡌࡌࡋ࠽ࠫ஝") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡈ࡬ࡢࡥ࡮ࡍࡨ࡫ࡔࡗࠩஞ")
    if l11ll_opy_ (u"ࠧࡇࡔࡈࡉ࠿࠭ட") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡧࡴࡨࡩࡻ࡯ࡥࡸࠩ஠")
    if l11ll_opy_ (u"ࠩࡸࡴࡳࡶ࠺ࠨ஡") in streamurl:
        l1lll1ll11_opy_ = l11ll_opy_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱࡬ࡩ࡮࡯࡮ࡧࡵࡹࡳ࠴ࡶࡪࡧࡺࠫ஢")
    return l1lll11ll1_opy_(l1lll1ll11_opy_, kodiID)
def l1lll11ll1_opy_(l1lll1ll11_opy_, kodiID):
    l1lll1l111_opy_     = l11ll_opy_ (u"ࠫࠬண")
    l1lll1ll1l_opy_   = l11ll_opy_ (u"ࠬ࠭த")
    try:
        l1llll1111_opy_ = xbmcaddon.Addon(l1lll1ll11_opy_).getAddonInfo(l11ll_opy_ (u"࠭࡮ࡢ࡯ࡨࠫ஥"))
        l1lll1l111_opy_    = dixie.cleanLabel(l1llll1111_opy_)
        l1lll1ll1l_opy_  = xbmcaddon.Addon(l1lll1ll11_opy_).getAddonInfo(l11ll_opy_ (u"ࠧࡪࡥࡲࡲࠬ஦"))
        if kodiID:
            l1lll1l11l_opy_ = xbmcaddon.Addon(l1lll1ll11_opy_).getAddonInfo(l11ll_opy_ (u"ࠨ࡫ࡧࠫ஧"))
            return l1lll1l111_opy_, l1lll1l11l_opy_
        return l1lll1l111_opy_, l1lll1ll1l_opy_
    except:
        l1lll1l111_opy_   = l11ll_opy_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠣࡗࡴࡻࡲࡤࡧࠪந")
        l1lll1ll1l_opy_ =  dixie.ICON
        return l1lll1l111_opy_, l1lll1ll1l_opy_
    return l1lll1l111_opy_, l1lll1ll1l_opy_
def selectStream(url, channel):
    l11llll_opy_ = url.split(l11ll_opy_ (u"ࠪࢀࠬன"))
    if len(l11llll_opy_) == 0:
        return None
    options, l1l111ll_opy_ = getOptions(l11llll_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l11llll_opy_) == 1:
            return l1l111ll_opy_[0]
    import selectDialog
    l1llll1l_opy_ = selectDialog.select(l11ll_opy_ (u"ࠫࡘ࡫࡬ࡦࡥࡷࠤࡦࠦࡳࡵࡴࡨࡥࡲ࠭ப"), options)
    if l1llll1l_opy_ < 0:
        raise Exception(l11ll_opy_ (u"࡙ࠬࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡࡅࡤࡲࡨ࡫࡬ࠨ஫"))
    return l1l111ll_opy_[l1llll1l_opy_]
def getOptions(l11llll_opy_, channel, addmore=True):
    options = []
    l1l111ll_opy_    = []
    for index, stream in enumerate(l11llll_opy_):
        l1lll1l111_opy_ = getPluginInfo(stream)
        l1lllll_opy_ = l1lll1l111_opy_[0]
        l1lll11111_opy_  = l1lll1l111_opy_[1]
        l1lllll_opy_ = l11ll_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡯ࡳࡣࡱ࡫ࡪࡣ࡛ࠨ஬") + l1lllll_opy_ + l11ll_opy_ (u"ࠧ࡞࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࠫ஭")
        if stream.startswith(OPEN_OTT):
            l111l_opy_ = stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l11ll_opy_ (u"ࠨࠩம"))
            l1lllll_opy_  = l1lllll_opy_ + l111l_opy_
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l11ll_opy_ (u"ࠩࠪய"))
        else:
            l1lllll_opy_  = l1lllll_opy_ + channel
        options.append([l1lllll_opy_, index, l1lll11111_opy_])
        l1l111ll_opy_.append(stream)
    if addmore:
        options.append([l11ll_opy_ (u"ࠪࡅࡩࡪࠠ࡮ࡱࡵࡩ࠳࠴࠮ࠨர"), index + 1, dixie.ICON])
        l1l111ll_opy_.append(l11ll_opy_ (u"ࠫࡦࡪࡤࡎࡱࡵࡩࠬற"))
    return options, l1l111ll_opy_
if __name__ == l11ll_opy_ (u"ࠬࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠧல"):
    checkAddons()