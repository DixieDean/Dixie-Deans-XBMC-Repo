# coding: UTF-8
import sys
l1l11l1l_opy_ = sys.version_info [0] == 2
l1llll11_opy_ = 2048
l1l1ll11_opy_ = 7
def l11ll_opy_ (l1l11l_opy_):
	global l1llllll_opy_
	l1ll1ll1_opy_ = ord (l1l11l_opy_ [-1])
	l1l1l1l1_opy_ = l1l11l_opy_ [:-1]
	l11l11l_opy_ = l1ll1ll1_opy_ % len (l1l1l1l1_opy_)
	l11ll1_opy_ = l1l1l1l1_opy_ [:l11l11l_opy_] + l1l1l1l1_opy_ [l11l11l_opy_:]
	if l1l11l1l_opy_:
		l1llll_opy_ = unicode () .join ([unichr (ord (char) - l1llll11_opy_ - (l111l11_opy_ + l1ll1ll1_opy_) % l1l1ll11_opy_) for l111l11_opy_, char in enumerate (l11ll1_opy_)])
	else:
		l1llll_opy_ = str () .join ([chr (ord (char) - l1llll11_opy_ - (l111l11_opy_ + l1ll1ll1_opy_) % l1l1ll11_opy_) for l111l11_opy_, char in enumerate (l11ll1_opy_)])
	return eval (l1llll_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
import mapping
ADDON    = dixie.ADDON
l1l1l1ll_opy_ = dixie.PROFILE
l1ll1lll1_opy_  = os.path.join(l1l1l1ll_opy_, l11ll_opy_ (u"ࠧࡪࡰ࡬ࠫ঄"))
l111l111_opy_    = os.path.join(l1ll1lll1_opy_, l11ll_opy_ (u"ࠨ࡯ࡤࡴࡵ࡯࡮ࡨࡵ࠱࡮ࡸࡵ࡮ࠨঅ"))
l11l11l1_opy_   = os.path.join(l1ll1lll1_opy_, l11ll_opy_ (u"ࠩࡰࡥࡵࡹ࠮࡫ࡵࡲࡲࠬআ"))
LABELFILE  = os.path.join(l1ll1lll1_opy_, l11ll_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࡵ࠱࡮ࡸࡵ࡮ࠨই"))
l1ll1l111_opy_ = os.path.join(l1ll1lll1_opy_, l11ll_opy_ (u"ࠫࡵࡸࡥࡧ࡫ࡻࡩࡸ࠴ࡪࡴࡱࡱࠫঈ"))
l111l11l_opy_  = json.load(open(l111l111_opy_))
l11111l1_opy_      = json.load(open(l11l11l1_opy_))
labelmaps = json.load(open(LABELFILE))
l1ll1_opy_  = json.load(open(l1ll1l111_opy_))
l1ll11l1l_opy_ = l11ll_opy_ (u"ࠬ࠭উ")
def l1l1lll1l_opy_(i, t1, l1ll11l11_opy_=[]):
 t = l1ll11l1l_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1ll11l11_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11l111l_opy_ = l1l1lll1l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11l1111_opy_ = l1l1lll1l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1ll1111l_opy_       = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡣࡦࡶࡹࠫঊ")
l111ll1l_opy_  = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡂ࡭ࡣࡦ࡯ࡎࡩࡥࡕࡘࠪঋ")
dexter    = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡥࡧࡻࠫঌ")
l1ll1l1ll_opy_   = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡇࡱࡨࡱ࡫ࡳࡴࠩ঍")
l1lll1111_opy_       = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡩࡥࡧ࡮࡯ࡴࡶ࡬ࡲ࡬࠭঎")
l1l111l_opy_  = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡊࡱࡧࡷ࡭ࡧࡶࡷ࡙ࡼࠧএ")
l1ll111ll_opy_  = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡫ࡸࡥࡦࡸ࡬ࡩࡼ࠭ঐ")
l11lll1_opy_   = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡮࡯ࡳ࡫ࡽࡳࡳ࡯ࡰࡵࡸࠪ঑")
l11lll1_opy_   = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡨࡰࡴ࡬ࡾࡴࡴࡩࡱࡶࡹࠫ঒")
l1111111_opy_  = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲࡷࡺࡸࡻࡢࡴࠩও")
l1lllll1l_opy_      = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡬࡬ࡲࡽࡺࡶ࠳ࠩঔ")
l1l111l1_opy_ = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡏ࡭ࡲ࡯ࡴ࡭ࡧࡶࡷࡎࡖࡔࡗࠩক")
l1111l1l_opy_  = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡱࡦࡺࡲࡪࡺ࡬ࡶࡪࡲࡡ࡯ࡦࠪখ")
l11ll1ll_opy_  = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡒࡧࡴࡴࡄࡸ࡭ࡱࡪࡳࡊࡒࡗ࡚ࠬগ")
l1111lll_opy_   = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡳࡡࡹ࡫ࡺࡩࡧࡺࡶࠨঘ")
l1ll1l1l1_opy_     = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡭ࡤ࡭ࡷࡺ࠲ࡶ࡬ࡶࡵࠪঙ")
l1ll11ll1_opy_      = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡮ࡧࡪࡥ࡮ࡶࡴࡷࠩচ")
l1ll1llll_opy_  = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡲࡶࡥࡩࡪ࡯࡯ࠩছ")
root      = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡳࡴࡺࡉࡑࡖ࡙ࠫজ")
l1lll1l_opy_      = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡨࡺࡶࠨঝ")
l111111l_opy_ = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡘࡻࡰࡳࡧࡰࡥࡨࡿࡔࡗࠩঞ")
l1ll111l_opy_   = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹࡴࡳࡧࡤࡱࡸࡻࡰࡳࡧࡰࡩ࠷࠭ট")
l1ll11lll_opy_   = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡴࡸ࡫ࡶࡸࡪࡪࠧঠ")
l111l1l_opy_   = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡵࡸ࡮࡭ࡳ࡭ࡳࠨড")
l11l11ll_opy_    = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡷ࡮ࡸࡺࡸ࡫ࠨঢ")
l1ll_opy_     = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡙ࡅࡉࡋࡒࠨণ")
l1l1lll11_opy_   = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡹࡸࡥࡢ࡯࠰ࡧࡴࡪࡥࡴࠩত")
l1ll11ll_opy_    = [l111l1l_opy_, l1111l1l_opy_, l1l1lll11_opy_, l1lll1l_opy_, l1ll111l_opy_, l11l11ll_opy_, l1l111l1_opy_, l1lll1111_opy_,l1ll1111l_opy_, l11lll1_opy_, root, l1ll11ll1_opy_, l1ll111ll_opy_, l1111111_opy_, l1lllll1l_opy_, l1ll1l1ll_opy_, l1l111l_opy_, l1111lll_opy_, dexter, l1ll_opy_, l111111l_opy_, l1ll1l1l1_opy_, l1ll11lll_opy_, l1ll1llll_opy_, l111ll1l_opy_]
def checkAddons():
    for addon in l1ll11ll_opy_:
        if l1l1lllll_opy_(addon):
            try: createINI(addon)
            except: continue
def l1l1lllll_opy_(addon):
    if xbmc.getCondVisibility(l11ll_opy_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠦࡵࠬࠫথ") % addon) == 1:
        dixie.log(l11ll_opy_ (u"࠭࠽࠾࠿ࡀࠤࡦࡪࡤࡰࡰࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦ࠽࠾࠿ࡀࠫদ"))
        dixie.log(addon)
        return True
    return False
def createINI(addon):
    l1lll1l11_opy_  = str(addon).split(l11ll_opy_ (u"ࠧ࠯ࠩধ"))[2] + l11ll_opy_ (u"ࠨ࠰࡬ࡲ࡮࠭ন")
    l1lllll11_opy_   = os.path.join(l1ll1lll1_opy_, l1lll1l11_opy_)
    response = l11lll11_opy_(addon)
    l11l111_opy_ = response[l11ll_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩ঩")][l11ll_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩপ")]
    l1llllll1_opy_  = l11ll_opy_ (u"ࠫࡠ࠭ফ") + addon + l11ll_opy_ (u"ࠬࡣ࡜࡯ࠩব")
    l11l1l11_opy_  =  file(l1lllll11_opy_, l11ll_opy_ (u"࠭ࡷࠨভ"))
    l11l1l11_opy_.write(l1llllll1_opy_)
    l1llll111_opy_ = []
    for channel in l11l111_opy_:
        l111l1l1_opy_ = l1l1llll1_opy_(addon)
        l11l1lll_opy_  = channel[l11ll_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ম")].split(l11ll_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪয"), 1)[0]
        if addon == dexter:
            l11l1lll_opy_ = l11l1lll_opy_.split(l11ll_opy_ (u"ࠩࠣ࠯ࠥ࠭র"), 1)[0]
        if (addon == root) or (addon == l1l111l1_opy_) or (addon == l111l1l_opy_):
            l11l1lll_opy_ = l11l1lll_opy_.split(l11ll_opy_ (u"ࠪࠤ࠲ࠦࠧ঱"), 1)[0]
        l1lll11l1_opy_ = l1lll1ll1_opy_(addon, l11l1lll_opy_)
        l11l1l1l_opy_ = l1ll111l1_opy_(addon, l1ll1_opy_, labelmaps, l111l11l_opy_, l11111l1_opy_, l11l1lll_opy_)
        stream  = l111l1l1_opy_ + l1lll11l1_opy_
        l111llll_opy_ = l11l1l1l_opy_  + l11ll_opy_ (u"ࠫࡂ࠭ল") + stream
        if l111llll_opy_ not in l1llll111_opy_:
            l1llll111_opy_.append(l111llll_opy_)
    l1llll111_opy_.sort()
    for item in l1llll111_opy_:
        l11l1l11_opy_.write(l11ll_opy_ (u"ࠧࠫࡳ࡝ࡰࠥ঳") % item)
    l11l1l11_opy_.close()
def l1lll1ll1_opy_(addon, l11l1lll_opy_):
    if (addon == root) or (addon == l1l111l1_opy_) or (addon == l1lll1111_opy_) or (addon == l1l1lll11_opy_)or (addon == l1111l1l_opy_)or (addon == l111l1l_opy_):
        l1l1111_opy_ = mapping.cleanLabel(l11l1lll_opy_)
        l1lll11l1_opy_ = mapping.editPrefix(l1ll1_opy_, l1l1111_opy_)
        return l1lll11l1_opy_
    l1l1111_opy_ = mapping.cleanLabel(l11l1lll_opy_)
    l1lll11l1_opy_ = mapping.cleanStreamLabel(l1l1111_opy_)
    return l1lll11l1_opy_
def l1ll111l1_opy_(addon, l1ll1_opy_, labelmaps, l111l11l_opy_, l11111l1_opy_, l11l1lll_opy_):
    if (addon == root) or (addon == l1l111l1_opy_) or (addon == l1lll1111_opy_) or (addon == l1l1lll11_opy_)or (addon == l1111l1l_opy_)or (addon == l111l1l_opy_):
        return l1ll11111_opy_(l1ll1_opy_, l11111l1_opy_, l11l1lll_opy_)
    l1lllll_opy_    = mapping.cleanLabel(l11l1lll_opy_)
    l1l1111_opy_ = mapping.mapLabel(labelmaps, l1lllll_opy_)
    l11l1l1l_opy_ = mapping.cleanPrefix(l1l1111_opy_)
    return mapping.mapChannelName(l111l11l_opy_, l11l1l1l_opy_)
def l1ll11111_opy_(l1ll1_opy_, l11111l1_opy_, l11l1lll_opy_):
    l111ll11_opy_ = mapping.cleanLabel(l11l1lll_opy_)
    l1l1111_opy_   = mapping.editPrefix(l1ll1_opy_, l111ll11_opy_)
    l1llll11l_opy_   = mapping.mapEPGLabel(l1ll1_opy_, l11111l1_opy_, l1l1111_opy_)
    return l1llll11l_opy_
def l11ll1l1_opy_(addon, file):
    l1lllll_opy_ = file[l11ll_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬ঴")].split(l11ll_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ঵"), 1)[0]
    l1lllll_opy_ = l1lllll_opy_.split(l11ll_opy_ (u"ࠨ࠭ࠪশ"), 1)[0]
    l1lllll_opy_ = mapping.cleanLabel(l1lllll_opy_)
    return l1lllll_opy_
def l1l1llll1_opy_(addon):
    if addon == l111l1l_opy_:
        return l11ll_opy_ (u"ࠩࡗ࡚ࡐࡀࠧষ")
    if addon == l1111l1l_opy_:
        return l11ll_opy_ (u"ࠪࡑ࡙࡞ࡉࡆ࠼ࠪস")
    if addon == l1l1lll11_opy_:
        return l11ll_opy_ (u"ࠫ࡝࡚ࡃ࠻ࠩহ")
    if addon == l1lll1l_opy_:
        return l11ll_opy_ (u"࡙ࠬࡃࡕࡘ࠽ࠫ঺")
    if addon == l1ll111l_opy_:
        return l11ll_opy_ (u"࠭ࡓࡖࡒ࠽ࠫ঻")
    if addon == l11l11ll_opy_:
        return l11ll_opy_ (u"ࠧࡖࡍࡗ࠾়ࠬ")
    if addon == l1l111l1_opy_:
        return l11ll_opy_ (u"ࠨࡎࡌࡑࡎ࡚࠺ࠨঽ")
    if addon == l1lll1111_opy_:
        return l11ll_opy_ (u"ࠩࡉࡅࡇࡀࠧা")
    if addon == l1ll1111l_opy_:
        return l11ll_opy_ (u"ࠪࡅࡈࡋ࠺ࠨি")
    if addon == l11lll1_opy_:
        return l11ll_opy_ (u"ࠫࡍࡕࡒࡊ࡜࠽ࠫী")
    if addon == root:
        return l11ll_opy_ (u"ࠬࡘࡏࡐࡖ࠵࠾ࠬু")
    if addon == l1ll11ll1_opy_:
        return l11ll_opy_ (u"࠭ࡍࡆࡉࡄ࠾ࠬূ")
    if addon == l1ll111ll_opy_:
        return l11ll_opy_ (u"ࠧࡇࡔࡈࡉ࠿࠭ৃ")
    if addon == l11ll1ll_opy_:
        return l11ll_opy_ (u"ࠨࡏࡄࡘࡘࡀࠧৄ")
    if addon == l1111111_opy_:
        return l11ll_opy_ (u"ࠩࡌࡔ࡙࡙࠺ࠨ৅")
    if addon == l1lllll1l_opy_:
        return l11ll_opy_ (u"ࠪࡎࡎࡔࡘ࠳࠼ࠪ৆")
    if addon == l1ll1l1ll_opy_:
        return l11ll_opy_ (u"ࠫࡊࡔࡄ࠻ࠩে")
    if addon == l1l111l_opy_:
        return l11ll_opy_ (u"ࠬࡌࡌࡂ࠼ࠪৈ")
    if addon == l1111lll_opy_:
        return l11ll_opy_ (u"࠭ࡍࡂ࡚ࡌ࠾ࠬ৉")
    if addon == dexter:
        return l11ll_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡊ࠺ࠨ৊")
    if addon == l1ll_opy_:
        return l11ll_opy_ (u"ࠨࡘࡇࡖ࡙࡜࠺ࠨো")
    if addon == l111111l_opy_:
        return l11ll_opy_ (u"ࠩࡖࡔࡗࡓ࠺ࠨৌ")
    if addon == l1ll1l1l1_opy_:
        return l11ll_opy_ (u"ࠪࡑࡈࡑࡔࡗ࠼্ࠪ")
    if addon == l1ll11lll_opy_:
        return l11ll_opy_ (u"࡙ࠫ࡝ࡉࡔࡖ࠽ࠫৎ")
    if addon == l1ll1llll_opy_:
        return l11ll_opy_ (u"ࠬࡖࡒࡆࡕࡗ࠾ࠬ৏")
    if addon == l111ll1l_opy_:
        return l11ll_opy_ (u"࠭ࡂࡍࡍࡌ࠾ࠬ৐")
def getURL(url):
    if url.startswith(l11ll_opy_ (u"ࠧࡕࡘࡎࠫ৑")):
        return l11ll11l_opy_(url, l111l1l_opy_)
    if url.startswith(l11ll_opy_ (u"ࠨࡏࡗ࡜ࡎࡋࠧ৒")):
        return l11ll11l_opy_(url, l1111l1l_opy_)
    if url.startswith(l11ll_opy_ (u"࡛ࠩࡘࡈ࠭৓")):
        return l11ll11l_opy_(url, l1l1lll11_opy_)
    if url.startswith(l11ll_opy_ (u"ࠪࡗࡈ࡚ࡖࠨ৔")):
        return l11ll11l_opy_(url, l1lll1l_opy_)
    if url.startswith(l11ll_opy_ (u"ࠫࡘ࡛ࡐࠨ৕")):
        return l11ll11l_opy_(url, l1ll111l_opy_)
    if url.startswith(l11ll_opy_ (u"࡛ࠬࡋࡕࠩ৖")):
        return l11ll11l_opy_(url, l11l11ll_opy_)
    if url.startswith(l11ll_opy_ (u"࠭ࡌࡊࡏࡌࡘࠬৗ")):
        return l11ll11l_opy_(url, l1l111l1_opy_)
    if url.startswith(l11ll_opy_ (u"ࠧࡇࡃࡅࠫ৘")):
        return l11ll11l_opy_(url, l1lll1111_opy_)
    if url.startswith(l11ll_opy_ (u"ࠨࡃࡆࡉࠬ৙")):
        return l11ll11l_opy_(url, l1ll1111l_opy_)
    if url.startswith(l11ll_opy_ (u"ࠩࡋࡓࡗࡏ࡚ࠨ৚")):
        return l11ll11l_opy_(url, l11lll1_opy_)
    if url.startswith(l11ll_opy_ (u"ࠪࡖࡔࡕࡔ࠳ࠩ৛")):
        return l11ll11l_opy_(url, root)
    if url.startswith(l11ll_opy_ (u"ࠫࡒࡋࡇࡂࠩড়")):
        return l11ll11l_opy_(url, l1ll11ll1_opy_)
    if url.startswith(l11ll_opy_ (u"ࠬࡌࡒࡆࡇࠪঢ়")):
        return l11ll11l_opy_(url, l1ll111ll_opy_)
    if url.startswith(l11ll_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡈࡒࡕ࠻ࠩ৞")):
        url = url.replace(l11ll_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡉࡌࡖ࠼ࠪয়"), l11ll_opy_ (u"ࠨࠩৠ")).replace(l11ll_opy_ (u"ࠩ࠰࠱ࡺࡹࡥࡳ࠯ࡤ࡫ࡪࡴࡴࠨৡ"), l11ll_opy_ (u"ࠪࢀࡺࡹࡥࡳ࠯ࡤ࡫ࡪࡴࡴࠨৢ"))
        return url
    if url.startswith(l11ll_opy_ (u"ࠫࡒࡇࡔࡔࠩৣ")):
        return l11ll11l_opy_(url, l11ll1ll_opy_)
    if url.startswith(l11ll_opy_ (u"ࠬࡏࡐࡕࡕࠪ৤")):
        return l11ll11l_opy_(url, l1111111_opy_)
    if url.startswith(l11ll_opy_ (u"࠭ࡊࡊࡐ࡛࠶ࠬ৥")):
        return l11ll11l_opy_(url, l1lllll1l_opy_)
    if url.startswith(l11ll_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡊࠧ০")):
        return l11ll11l_opy_(url, dexter)
    if url.startswith(l11ll_opy_ (u"ࠨࡈࡏࡅࠬ১")):
        return l11ll11l_opy_(url, l1l111l_opy_)
    if url.startswith(l11ll_opy_ (u"ࠩࡐࡅ࡝ࡏࠧ২")):
        return l11ll11l_opy_(url, l1111lll_opy_)
    if url.startswith(l11ll_opy_ (u"ࠪࡉࡓࡊࠧ৩")):
        return l11ll11l_opy_(url, l1ll1l1ll_opy_)
    if url.startswith(l11ll_opy_ (u"࡛ࠫࡊࡒࡕࡘࠪ৪")):
        return l11ll11l_opy_(url, l1ll_opy_)
    if url.startswith(l11ll_opy_ (u"࡙ࠬࡐࡓࡏࠪ৫")):
        return l11ll11l_opy_(url, l111111l_opy_)
    if url.startswith(l11ll_opy_ (u"࠭ࡍࡄࡍࡗ࡚ࠬ৬")):
        return l11ll11l_opy_(url, l1ll1l1l1_opy_)
    if url.startswith(l11ll_opy_ (u"ࠧࡕ࡙ࡌࡗ࡙࠭৭")):
        return l11ll11l_opy_(url, l1ll11lll_opy_)
    if url.startswith(l11ll_opy_ (u"ࠨࡒࡕࡉࡘ࡚ࠧ৮")):
        return l11ll11l_opy_(url, l1ll1llll_opy_)
    if url.startswith(l11ll_opy_ (u"ࠩࡅࡐࡐࡏࠧ৯")):
        return l11ll11l_opy_(url, l111ll1l_opy_)
    response  = l11ll111_opy_(url)
    l1llll1l1_opy_ = url.split(l11ll_opy_ (u"ࠪ࠾ࠬৰ"), 1)[-1]
    try:
        result = response[l11ll_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫৱ")]
        l111111_opy_  = result[l11ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫ৲")]
    except Exception as e:
        l1ll1ll11_opy_(e)
        return None
    for file in l111111_opy_:
        l11l1lll_opy_  = file[l11ll_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬ৳")].split(l11ll_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ৴"), 1)[0]
        l1l1lll_opy_  = l11l1lll_opy_.split(l11ll_opy_ (u"ࠨ࠭ࠪ৵"), 1)[0]
        l1ll1ll1l_opy_ = mapping.cleanLabel(l1l1lll_opy_)
        try:
            if l1llll1l1_opy_ == l1ll1ll1l_opy_:
                return file[l11ll_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧ৶")]
        except:
            if (l1llll1l1_opy_ in l1ll1ll1l_opy_) or (l1ll1ll1l_opy_ in l1llll1l1_opy_):
                return file[l11ll_opy_ (u"ࠪࡪ࡮ࡲࡥࠨ৷")]
    return None
def l11ll11l_opy_(url, addon):
    PATH = l11l1ll1_opy_(addon)
    try:
        response = json.load(open(PATH))
    except:
        response = l11lll11_opy_(addon)
    l1l111ll_opy_      = url.split(l11ll_opy_ (u"ࠫ࠿࠭৸"), 1)[-1]
    stream    = l1l111ll_opy_.split(l11ll_opy_ (u"࡛ࠬࠦࠨ৹"), 1)[0]
    l1llll1l1_opy_ = mapping.cleanLabel(stream)
    l111111_opy_  = response[l11ll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭৺")][l11ll_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭৻")]
    for file in l111111_opy_:
        l11l1lll_opy_  = file[l11ll_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧৼ")].split(l11ll_opy_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ৽"), 1)[0]
        if addon == dexter:
            l11l1lll_opy_ = l11l1lll_opy_.split(l11ll_opy_ (u"ࠪࠤ࠰ࠦࠧ৾"), 1)[0]
        if (addon == root) or (addon == l1l111l1_opy_) or (addon == l111l1l_opy_):
            l11l1lll_opy_ = l11l1lll_opy_.split(l11ll_opy_ (u"ࠫࠥ࠳ࠠࠨ৿"), 1)[0]
        l1ll1ll1l_opy_ = l1lll1ll1_opy_(addon, l11l1lll_opy_)
        try:
            if l1llll1l1_opy_ == l1ll1ll1l_opy_:
                return file[l11ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪ਀")]
        except:
            if (l1llll1l1_opy_ in l1ll1ll1l_opy_) or (l1ll1ll1l_opy_ in l1llll1l1_opy_):
                return file[l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࠫਁ")]
    return None
def l11lll11_opy_(addon):
    PATH  = l11l1ll1_opy_(addon)
    if addon == l1ll_opy_:
        query = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡘࡄࡈࡊࡘ࠯࡭࡫ࡹࡩࡹࡼ࠯ࡢ࡮࡯࠳ࠬਂ")
    elif addon == l1ll111l_opy_:
        query = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡸࡷ࡫ࡡ࡮ࡵࡸࡴࡷ࡫࡭ࡦ࠴࠲ࡰ࡮ࡼࡥࡵࡸ࠲ࡥࡱࡲ࠯ࠨਃ")
    elif addon == l1lll1l_opy_:
        query = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡨࡺࡶ࠰࡮࡬ࡺࡪࡺࡶ࠰ࡣ࡯ࡰ࠴࠭਄")
    elif addon == l1ll111l_opy_:
        query = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡺࡲࡦࡣࡰࡷࡺࡶࡲࡦ࡯ࡨ࠶࠴ࡲࡩࡷࡧࡷࡺ࠴ࡧ࡬࡭࠱ࠪਅ")
    elif addon == l1ll111ll_opy_:
        query = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡬ࡲࡦࡧࡹ࡭ࡪࡽ࠯ࡀࡷࡵࡰࡂࡻࡲ࡭ࠨࡰࡳࡩ࡫࠽࠶ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡹࡩ࠰࡚ࡖࠨਆ")
    elif addon == l11l11ll_opy_:
        query = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡵ࡬ࡶࡸࡶࡰ࠵࠿ࡶࡴ࡯ࡁ࡭ࡺࡴࡱࠧ࠶ࡅࠪ࠸ࡆࠦ࠴ࡉࡥࡩࡪ࡯࡯ࡥ࡯ࡳࡺࡪ࠮ࡰࡴࡪࠩ࠷ࡌࡵ࡬ࡶࡸࡶࡰࠫ࠲ࡇࡗࡎࡘࡺࡸ࡫ࠦ࠴ࡉࡐ࡮ࡼࡥࠦ࠴࠸࠶࠵࡚ࡖ࠯ࡶࡻࡸࠫࡳ࡯ࡥࡧࡀ࠵ࠫࡴࡡ࡮ࡧࡀࡐ࡮ࡼࡥࠬࡖ࡙ࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠩࡪࡦࡴࡡࡳࡶࡀࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠨਇ")
    else:
        query = l1lll11ll_opy_(addon)
    try:
        return json.load(open(PATH))
    except:
        content = doJSON(query)
        return l1lllllll_opy_(PATH, addon, content)
def l1lllllll_opy_(PATH, addon, content):
    json.dump(content, open(PATH,l11ll_opy_ (u"࠭ࡷࠨਈ")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    l1l1l11_opy_  = (l11ll_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪਉ") % query)
    response = xbmc.executeJSONRPC(l1l1l11_opy_)
    content  = json.loads(response)
    return content
def l11l1ll1_opy_(addon):
    if addon == l1111l1l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠨ࡯ࡷࡼࡹ࡫࡭ࡱࠩਊ"))
    if addon == l111l1l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠩࡷࡺࡰࡺࡥ࡮ࡲࠪ਋"))
    if addon == l1l1lll11_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠪࡼࡹ࡫࡭ࡱࠩ਌"))
    if addon == l1lll1l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠫࡸࡩࡴࡦ࡯ࡳࠫ਍"))
    if addon == l1ll111l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠬࡹࡵࡱࡶࡨࡱࡵ࠭਎"))
    if addon == l11l11ll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"࠭ࡵ࡬ࡶࡷࡩࡲࡶࠧਏ"))
    if addon == l1l111l1_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠧ࡭࡫ࡰ࡭ࡹ࡫࡭ࡱࠩਐ"))
    if addon == l1lll1111_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠨࡨࡤࡦࡹ࡫࡭ࡱࠩ਑"))
    if addon == l1ll1111l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠩࡤࡧࡪࡺࡥ࡮ࡲࠪ਒"))
    if addon == l11lll1_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠪ࡬ࡴࡸࡴࡦ࡯ࡳࠫਓ"))
    if addon == root:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠫࡷࡵ࠲ࡵࡧࡰࡴࠬਔ"))
    if addon == l1ll11ll1_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠬࡳࡥࡨࡣࡷࡱࡵ࠭ਕ"))
    if addon == l11ll1ll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"࠭࡭ࡢࡶࡶࡸࡲࡶࠧਖ"))
    if addon == l1ll111ll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠧࡧࡴࡨࡩࡹࡳࡰࠨਗ"))
    if addon == l1111111_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠨ࡫ࡳࡸࡸࡺ࡭ࡱࠩਘ"))
    if addon == l1lllll1l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠩ࡭࠶ࡹ࡫࡭ࡱࠩਙ"))
    if addon == l1ll1l1ll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠪࡩࡹ࡫࡭ࡱࠩਚ"))
    if addon == l1l111l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠫ࡫ࡺࡥ࡮ࡲࠪਛ"))
    if addon == l1111lll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠬࡳࡡࡹࡶࡨࡱࡵ࠭ਜ"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"࠭ࡤࡵࡧࡰࡴࠬਝ"))
    if addon == l1ll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠧࡷࡦࡷࡩࡲࡶࠧਞ"))
    if addon == l111111l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠨࡵࡳࡶࡹ࡫࡭ࡱࠩਟ"))
    if addon == l1ll1l1l1_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠩࡰࡧࡰࡺࡥ࡮ࡲࠪਠ"))
    if addon == l1ll11lll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠪࡸࡼ࡯ࡴࡦ࡯ࡳࠫਡ"))
    if addon == l1ll1llll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠫࡵࡸࡥࡴࡶࡨࡱࡵ࠭ਢ"))
    if addon == l111ll1l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠬࡨ࡬࡬࡫ࡷࡩࡲࡶࠧਣ"))
def l1lll11ll_opy_(addon):
    query = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩਤ") + addon
    response = doJSON(query)
    l111111_opy_    = response[l11ll_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧਥ")][l11ll_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧਦ")]
    for file in l111111_opy_:
        l1lll1l1l_opy_ = file[l11ll_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨਧ")]
        l1lllll_opy_ = mapping.cleanLabel(l1lll1l1l_opy_)
        l1lllll_opy_ = l1lllll_opy_.upper()
        if (l1lllll_opy_ == l11ll_opy_ (u"ࠪࡐࡎ࡜ࡅࠡࡋࡓࡘ࡛࠭ਨ")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠫࡑࡏࡖࡆࠢࡗ࡚ࠬ਩")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠬࡒࡉࡗࡇࠣࡇࡍࡇࡎࡏࡇࡏࡗࠬਪ")) or (l1lllll_opy_ == l11ll_opy_ (u"࠭ࡌࡊࡘࡈࠫਫ")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠧࡆࡐࡇࡐࡊ࡙ࡓࠡࡏࡈࡈࡎࡇࠧਬ")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠨࡈࡏࡅ࡜ࡒࡅࡔࡕࡗ࡚ࠬਭ")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠩࡐࡅ࡝ࡏࡗࡆࡄࠣࡘ࡛࠭ਮ")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠪࡆࡑࡇࡃࡌࡋࡆࡉ࡚ࠥࡖࠨਯ")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠫࡍࡕࡒࡊ࡜ࡒࡒࠥࡏࡐࡕࡘࠪਰ")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠬࡌࡁࡃࠢࡌࡔ࡙࡜ࠧ਱")):
            livetv = file[l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࠫਲ")]
            return l111l1ll_opy_(livetv)
def l111l1ll_opy_(livetv):
    response = doJSON(livetv)
    l111111_opy_    = response[l11ll_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧਲ਼")][l11ll_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧ਴")]
    for file in l111111_opy_:
        l1lll1l1l_opy_ = file[l11ll_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨਵ")]
        l1lllll_opy_ = mapping.cleanLabel(l1lll1l1l_opy_)
        l1lllll_opy_ = l1lllll_opy_.upper()
        if l1lllll_opy_ == l11ll_opy_ (u"ࠪࡅࡑࡒࠧਸ਼"):
            return file[l11ll_opy_ (u"ࠫ࡫࡯࡬ࡦࠩ਷")]
def l1llll1ll_opy_(l1lll1lll_opy_):
    items = []
    _1lll111l_opy_(l1lll1lll_opy_, items)
    return items
def _1lll111l_opy_(l1lll1lll_opy_, items):
    response = doJSON(l1lll1lll_opy_)
    if response[l11ll_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬਸ")].has_key(l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬਹ")):
        result = response[l11ll_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧ਺")][l11ll_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧ਻")]
        for item in result:
            if item[l11ll_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨ਼ࠫ")] == l11ll_opy_ (u"ࠪࡪ࡮ࡲࡥࠨ਽"):
                l1lllll_opy_ = mapping.cleanLabel(item[l11ll_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪਾ")])
                items.append(item)
            elif item[l11ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧਿ")] == l11ll_opy_ (u"࠭ࡤࡪࡴࡨࡧࡹࡵࡲࡺࠩੀ"):
                l1lllll_opy_ = mapping.cleanLabel(item[l11ll_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ੁ")])
                l1ll1l11l_opy_  = item[l11ll_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ੂ")]
                dixie.log(item)
                dixie.log(l1ll1l11l_opy_)
                _1lll111l_opy_(l1ll1l11l_opy_, items)
def l11ll111_opy_(url):
    if url.startswith(l11ll_opy_ (u"ࠩࡌࡔࡑࡇ࡙࠻ࠩ੃")):
        l1l1l11_opy_ = (l11ll_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡢࡣࡥ࡬ࡴࡱࡧࡹࡦࡴ࠲ࡃࡺࡸ࡬࠾ࡷࡵࡰࠫࡳ࡯ࡥࡧࡀ࠶ࠫࡴࡡ࡮ࡧࡀࡐ࡮ࡼࡥࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࡀࠪࡎࡖࡉࡅ࠿ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ੄"))
    if url.startswith(l11ll_opy_ (u"ࠫࡎࡖࡌࡂ࡛࠵࠾ࠬ੅")):
        l1l1l11_opy_ = (l11ll_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡰࡦࡿࡥࡳࡹࡺࡻ࠴ࡅࡵࡳ࡮ࡀࡹࡷࡲࠦ࡮ࡱࡧࡩࡂ࠷࠰࠲ࠨࡱࡥࡲ࡫࠽ࡘࡣࡷࡧ࡭࠱ࡌࡪࡸࡨࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࡃࠦࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡵࡢࡹࡷࡲ࠽ࠧ࡮ࡲ࡫࡬࡫ࡤࡠ࡫ࡱࡁࡋࡧ࡬ࡴࡧࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ੆"))
    if url.startswith(l11ll_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡗࡀࠧੇ")):
        l1l1l11_opy_ = (l11ll_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽ࠯ࡀࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬ࠬ࡬ࡰࡩࡪࡩࡩࡥࡩ࡯࠿ࡉࡥࡱࡹࡥࠧ࡯ࡲࡨࡪࡃ࠱࠲࠵ࠩࡲࡦࡳࡥ࠾ࡎ࡬ࡷࡹ࡫࡮ࠦ࠴࠳ࡐ࡮ࡼࡥࠧࡵࡸࡦࡹ࡯ࡴ࡭ࡧࡶࡣࡺࡸ࡬ࠧࡷࡵࡰࡂࡻࡲ࡭ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧੈ"))
    if url.startswith(l11ll_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡉࡕࡘ࠽ࠫ੉")):
        l1l1l11_opy_ = (l11ll_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡴࡷࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧ੊"))
    if url.startswith(l11ll_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡆ࠽ࠫੋ")):
        l1l1l11_opy_ = (l11ll_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡥࡧࡻ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡧ࡬࡭ࠨࡨࡼࡹࡸࡡࠧࡲࡤ࡫ࡪࠬࡰ࡭ࡱࡷࠪࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠽ࠧࡶ࡬ࡸࡱ࡫࠽ࠦ࠷ࡥࡇࡔࡒࡏࡓࠧ࠵࠴ࡼ࡮ࡩࡵࡧࠨ࠹ࡩࡇ࡬࡭ࠧ࠵࠴ࡈ࡮ࡡ࡯ࡰࡨࡰࡸࠫ࠵ࡣࠧ࠵ࡪࡈࡕࡌࡐࡔࠨ࠹ࡩࠬࡵࡳ࡮ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨੌ"))
    if url.startswith(l11ll_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖࡇࡀ੍ࠧ")):
        l1l1l11_opy_ = (l11ll_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡩࡧࡵ࡯ࡵ࠱ࡂࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠧࡨࡤࡲࡦࡸࡴ࠾ࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࠬ࡭ࡰࡦࡨࡁ࠼ࠬࡰࡪ࡮࡯ࡳࡼࡃࡌࡪࡸࡨࠩ࠷࠶ࡓࡵࡴࡨࡥࡲࡹࠦࡶࡴ࡯ࡁࡷࡧ࡮ࡥࡱࡰࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ੎"))
    try:
        dixie.ShowBusy()
        addon =  l1l1l11_opy_.split(l11ll_opy_ (u"ࠧ࠰࠱ࠪ੏"), 1)[-1].split(l11ll_opy_ (u"ࠨ࠱ࠪ੐"), 1)[0]
        login = l11ll_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧੑ") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1l1l11_opy_)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1ll1ll11_opy_(e)
        return {l11ll_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠩ੒") : l11ll_opy_ (u"ࠫࡕࡲࡵࡨ࡫ࡱࠤࡊࡸࡲࡰࡴࠪ੓")}
def l11111ll_opy_():
    modules = map(__import__, [l1l1lll1l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11l111l_opy_)):
        return l11ll_opy_ (u"࡚ࠬࡲࡶࡧࠪ੔")
    if len(modules[-1].Window(10**4).getProperty(l11l1111_opy_)):
        return l11ll_opy_ (u"࠭ࡔࡳࡷࡨࠫ੕")
    return l11ll_opy_ (u"ࠧࡇࡣ࡯ࡷࡪ࠭੖")
def l1ll1ll11_opy_(e):
    l1111l11_opy_ = l11ll_opy_ (u"ࠨࡕࡲࡶࡷࡿࠬࠡࡣࡱࠤࡪࡸࡲࡰࡴࠣࡳࡨࡩࡵࡳࡧࡧ࠾ࠥࡐࡓࡐࡐࠣࡉࡷࡸ࡯ࡳ࠼ࠣࠩࡸ࠭੗")  %e
    l111lll1_opy_ = l11ll_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡵࡩ࠲ࡲࡩ࡯࡭ࠣࡸ࡭࡯ࡳࠡࡥ࡫ࡥࡳࡴࡥ࡭ࠢࡤࡲࡩࠦࡴࡳࡻࠣࡥ࡬ࡧࡩ࡯࠰ࠪ੘")
    l1111ll1_opy_ = l11ll_opy_ (u"࡙ࠪࡸ࡫࠺ࠡࡅࡲࡲࡹ࡫ࡸࡵࠢࡐࡩࡳࡻࠠ࠾ࡀࠣࡖࡪࡳ࡯ࡷࡧࠣࡗࡹࡸࡥࡢ࡯ࠪਖ਼")
    dixie.log(e)
    dixie.DialogOK(l1111l11_opy_, l111lll1_opy_, l1111ll1_opy_)
if __name__ == l11ll_opy_ (u"ࠫࡤࡥ࡭ࡢ࡫ࡱࡣࡤ࠭ਗ਼"):
    checkAddons()