#! /usr/bin/python
# coding: UTF-8
import sys
l1l1l1_opy_ = sys.version_info [0] == 2
l11ll1_opy_ = 2048
l1l11_opy_ = 7
def l1ll1l_opy_ (ll_opy_):
	global l1l11l_opy_
	l1l1l_opy_ = ord (ll_opy_ [-1])
	l1l1l11_opy_ = ll_opy_ [:-1]
	l1ll_opy_ = l1l1l_opy_ % len (l1l1l11_opy_)
	l1l1_opy_ = l1l1l11_opy_ [:l1ll_opy_] + l1l1l11_opy_ [l1ll_opy_:]
	if l1l1l1_opy_:
		l1111l_opy_ = unicode () .join ([unichr (ord (char) - l11ll1_opy_ - (l1111_opy_ + l1l1l_opy_) % l1l11_opy_) for l1111_opy_, char in enumerate (l1l1_opy_)])
	else:
		l1111l_opy_ = str () .join ([chr (ord (char) - l11ll1_opy_ - (l1111_opy_ + l1l1l_opy_) % l1l11_opy_) for l1111_opy_, char in enumerate (l1l1_opy_)])
	return eval (l1111l_opy_)
license = (
'''Copyright 2014, 2015, 2016 Jacques de Hooge, GEATEC engineering, www.geatec.com
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
    http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.'''
)
import re
import os
import sys
import errno
import keyword
import importlib
import random
import codecs
import shutil
l11l111l_opy_ = l1ll1l_opy_ (u"ࠧࡰࡲࡼࠫ჊")
l1111l1l_opy_ = l1ll1l_opy_ (u"ࠨ࠳࠱࠵࠳࠷࠹ࠨ჋")
if __name__ == l1ll1l_opy_ (u"ࠩࡢࡣࡲࡧࡩ࡯ࡡࡢࠫ჌"):
	print (l1ll1l_opy_ (u"ࠪࡿࢂࠦࠨࡕࡏࠬࠤࡈࡵ࡮ࡧ࡫ࡪࡹࡷࡧࡢ࡭ࡧࠣࡑࡺࡲࡴࡪࠢࡐࡳࡩࡻ࡬ࡦࠢࡓࡽࡹ࡮࡯࡯ࠢࡒࡦ࡫ࡻࡳࡤࡣࡷࡳࡷࠦࡖࡦࡴࡶ࡭ࡴࡴࠠࡼࡿࠪჍ").format (l11l111l_opy_.capitalize (), l1111l1l_opy_))
	print (l1ll1l_opy_ (u"ࠫࡈࡵࡰࡺࡴ࡬࡫࡭ࡺࠠࠩࡅࠬࠤࡌ࡫ࡡࡵࡧࡦࠤࡊࡴࡧࡪࡰࡨࡩࡷ࡯࡮ࡨ࠰ࠣࡐ࡮ࡩࡥ࡯ࡵࡨ࠾ࠥࡇࡰࡢࡥ࡫ࡩࠥ࠸࠮࠱ࠢࡤࡸࠥࠦࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡥࡵࡧࡣࡩࡧ࠱ࡳࡷ࡭࠯࡭࡫ࡦࡩࡳࡹࡥࡴ࠱ࡏࡍࡈࡋࡎࡔࡇ࠰࠶࠳࠶࡜࡯ࠩ჎"))
	random.seed ()
	l1ll1l1ll_opy_ = sys.version_info [0] == 2
	l11l1l1l_opy_ = 2048
	l1l1l_opy_ = l11l1l1l_opy_
	l1l1lll1l_opy_ = 7
	def l111llll_opy_ (l1l1l11l_opy_, open = False):
		try:
			os.makedirs (l1l1l11l_opy_.rsplit (l1ll1l_opy_ (u"ࠬ࠵ࠧ჏"), 1) [0])
		except OSError as l1lll11ll_opy_:
			if l1lll11ll_opy_.errno != errno.EEXIST:
				raise
		if open:
			return codecs.open (l1l1l11l_opy_, encoding = l1ll1l_opy_ (u"࠭ࡵࡵࡨ࠰࠼ࠬა"), mode = l1ll1l_opy_ (u"ࠧࡸࠩბ"))
	def l11ll111_opy_ (l1l1ll111_opy_, l1llll1l1_opy_):
		return l1ll1l_opy_ (u"ࠨࡽ࠳ࢁࢀ࠷ࡽࡼ࠴ࢀࠫგ").format (l1ll1l_opy_ (u"ࠩࡢࠫდ") if l1llll1l1_opy_ else l1ll1l_opy_ (u"ࠪࡰࠬე"), bin (l1l1ll111_opy_) [2:] .replace (l1ll1l_opy_ (u"ࠫ࠵࠭ვ"), l1ll1l_opy_ (u"ࠬࡲࠧზ")), l1ll111ll_opy_)
	def l1ll1l11l_opy_ (l1111l_opy_):
		global l1l1l_opy_
		if l1ll1l1ll_opy_:
			l1l1_opy_ = unicode () .join ([unichr (l11l1l1l_opy_ + ord (char) + (l1111_opy_ + l1l1l_opy_) % l1l1lll1l_opy_) for l1111_opy_, char in enumerate (l1111l_opy_)])
			l1l1l1l1l_opy_ = unichr (l1l1l_opy_)
		else:
			l1l1_opy_ = str () .join ([chr (l11l1l1l_opy_ + ord (char) + (l1111_opy_ + l1l1l_opy_) % l1l1lll1l_opy_) for l1111_opy_, char in enumerate (l1111l_opy_)])
			l1l1l1l1l_opy_ = chr (l1l1l_opy_)
		l1ll_opy_ = l1l1l_opy_ % len (l1111l_opy_)
		l1l1l11_opy_ = l1l1_opy_ [:-l1ll_opy_] + l1l1_opy_ [-l1ll_opy_:]
		ll_opy_ = l1l1l11_opy_ + l1l1l1l1l_opy_
		l1l1l_opy_ += 1
		return l1ll1l_opy_ (u"࠭ࡵࠣࠩთ") + ll_opy_ + l1ll1l_opy_ (u"ࠧࠣࠩი")
	def l1ll1ll1_opy_ (l11ll1l1_opy_):
		return l1ll1l_opy_ (u"ࠨࠩࠪࠑࠏ࡯࡭ࡱࡱࡵࡸࠥࡹࡹࡴࠏࠍࠑࠏ࡯ࡳࡑࡻࡷ࡬ࡴࡴ࠲ࡼ࠲ࢀࠤࡂࠦࡳࡺࡵ࠱ࡺࡪࡸࡳࡪࡱࡱࡣ࡮ࡴࡦࡰࠢ࡞࠴ࡢࠦ࠽࠾ࠢ࠵ࠑࠏࡩࡨࡢࡴࡅࡥࡸ࡫ࡻ࠱ࡿࠣࡁࠥࢁ࠱ࡾࠏࠍࡧ࡭ࡧࡲࡎࡱࡧࡹࡱࡻࡳࡼ࠲ࢀࠤࡂࠦࡻ࠳ࡿࠐࠎࠒࠐࡤࡦࡨࠣࡹࡳ࡙ࡣࡳࡣࡰࡦࡱ࡫ࡻ࠱ࡿࠣࠬࡰ࡫ࡹࡦࡦࡖࡸࡷ࡯࡮ࡨࡎ࡬ࡸࡪࡸࡡ࡭ࠫ࠽ࠑࠏࠏࡧ࡭ࡱࡥࡥࡱࠦࡳࡵࡴ࡬ࡲ࡬ࡔࡲࡼ࠲ࢀࠑࠏࠏࠍࠋࠋࡶࡸࡷ࡯࡮ࡨࡐࡵࠤࡂࠦ࡯ࡳࡦࠣࠬࡰ࡫ࡹࡦࡦࡖࡸࡷ࡯࡮ࡨࡎ࡬ࡸࡪࡸࡡ࡭ࠢ࡞࠱࠶ࡣࠩࠎࠌࠌࡶࡴࡺࡡࡵࡧࡧࡗࡹࡸࡩ࡯ࡩࡏ࡭ࡹ࡫ࡲࡢ࡮ࠣࡁࠥࡱࡥࡺࡧࡧࡗࡹࡸࡩ࡯ࡩࡏ࡭ࡹ࡫ࡲࡢ࡮ࠣ࡟࠿࠳࠱࡞ࠏࠍࠍࠒࠐࠉࡳࡱࡷࡥࡹ࡯࡯࡯ࡆ࡬ࡷࡹࡧ࡮ࡤࡧࠣࡁࠥࡹࡴࡳ࡫ࡱ࡫ࡓࡸࠠࠦࠢ࡯ࡩࡳࠦࠨࡳࡱࡷࡥࡹ࡫ࡤࡔࡶࡵ࡭ࡳ࡭ࡌࡪࡶࡨࡶࡦࡲࠩࠎࠌࠌࡶࡪࡩ࡯ࡥࡧࡧࡗࡹࡸࡩ࡯ࡩࡏ࡭ࡹ࡫ࡲࡢ࡮ࠣࡁࠥࡸ࡯ࡵࡣࡷࡩࡩ࡙ࡴࡳ࡫ࡱ࡫ࡑ࡯ࡴࡦࡴࡤࡰࠥࡡ࠺ࡳࡱࡷࡥࡹ࡯࡯࡯ࡆ࡬ࡷࡹࡧ࡮ࡤࡧࡠࠤ࠰ࠦࡲࡰࡶࡤࡸࡪࡪࡓࡵࡴ࡬ࡲ࡬ࡒࡩࡵࡧࡵࡥࡱ࡛ࠦࡳࡱࡷࡥࡹ࡯࡯࡯ࡆ࡬ࡷࡹࡧ࡮ࡤࡧ࠽ࡡࠒࠐࠉࠊࠏࠍࠍ࡮࡬ࠠࡪࡵࡓࡽࡹ࡮࡯࡯࠴ࡾ࠴ࢂࡀࠍࠋࠋࠌࡷࡹࡸࡩ࡯ࡩࡏ࡭ࡹ࡫ࡲࡢ࡮ࠣࡁࠥࡻ࡮ࡪࡥࡲࡨࡪࠦࠨࠪࠢ࠱࡮ࡴ࡯࡮ࠡࠪ࡞ࡹࡳ࡯ࡣࡩࡴࠣࠬࡴࡸࡤࠡࠪࡦ࡬ࡦࡸࠩࠡ࠯ࠣࡧ࡭ࡧࡲࡃࡣࡶࡩࢀ࠶ࡽࠡ࠯ࠣࠬࡨ࡮ࡡࡳࡋࡱࡨࡪࡾࠠࠬࠢࡶࡸࡷ࡯࡮ࡨࡐࡵ࠭ࠥࠫࠠࡤࡪࡤࡶࡒࡵࡤࡶ࡮ࡸࡷࢀ࠶ࡽࠪࠢࡩࡳࡷࠦࡣࡩࡣࡵࡍࡳࡪࡥࡹ࠮ࠣࡧ࡭ࡧࡲࠡ࡫ࡱࠤࡪࡴࡵ࡮ࡧࡵࡥࡹ࡫ࠠࠩࡴࡨࡧࡴࡪࡥࡥࡕࡷࡶ࡮ࡴࡧࡍ࡫ࡷࡩࡷࡧ࡬ࠪ࡟ࠬࠑࠏࠏࡥ࡭ࡵࡨ࠾ࠒࠐࠉࠊࡵࡷࡶ࡮ࡴࡧࡍ࡫ࡷࡩࡷࡧ࡬ࠡ࠿ࠣࡷࡹࡸࠠࠩࠫࠣ࠲࡯ࡵࡩ࡯ࠢࠫ࡟ࡨ࡮ࡲࠡࠪࡲࡶࡩࠦࠨࡤࡪࡤࡶ࠮ࠦ࠭ࠡࡥ࡫ࡥࡷࡈࡡࡴࡧࡾ࠴ࢂࠦ࠭ࠡࠪࡦ࡬ࡦࡸࡉ࡯ࡦࡨࡼࠥ࠱ࠠࡴࡶࡵ࡭ࡳ࡭ࡎࡳࠫࠣࠩࠥࡩࡨࡢࡴࡐࡳࡩࡻ࡬ࡶࡵࡾ࠴ࢂ࠯ࠠࡧࡱࡵࠤࡨ࡮ࡡࡳࡋࡱࡨࡪࡾࠬࠡࡥ࡫ࡥࡷࠦࡩ࡯ࠢࡨࡲࡺࡳࡥࡳࡣࡷࡩࠥ࠮ࡲࡦࡥࡲࡨࡪࡪࡓࡵࡴ࡬ࡲ࡬ࡒࡩࡵࡧࡵࡥࡱ࠯࡝ࠪࠏࠍࠍࠎࠓࠊࠊࡴࡨࡸࡺࡸ࡮ࠡࡧࡹࡥࡱࠦࠨࡴࡶࡵ࡭ࡳ࡭ࡌࡪࡶࡨࡶࡦࡲࠩࠎࠌࠌࠫࠬ࠭კ").format (l1l1111l_opy_, l11l1l1l_opy_, l1l1lll1l_opy_)
	def l1ll1llll_opy_ (l1lll1111_opy_):
		print (l1ll1l_opy_ (u"ࡴࠪࠫࠬࠓࠊࠎࠌ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮ࠒࠐࡻ࠱ࡿࠣࡻ࡮ࡲ࡬ࠡࡱࡥࡪࡺࡹࡣࡢࡶࡨࠤࡾࡵࡵࡳࠢࡨࡼࡹ࡫࡮ࡴ࡫ࡹࡩ࠱ࠦࡲࡦࡣ࡯ࠤࡼࡵࡲ࡭ࡦ࠯ࠤࡲࡻ࡬ࡵ࡫ࠣࡱࡴࡪࡵ࡭ࡧࠣࡔࡾࡺࡨࡰࡰࠣࡷࡴࡻࡲࡤࡧࠣࡧࡴࡪࡥࠡࡨࡲࡶࠥ࡬ࡲࡦࡧࠤࠑࠏࡇ࡮ࡥࠢ࡜ࡓ࡚ࠦࡣࡩࡱࡲࡷࡪࠦࡰࡦࡴࠣࡴࡷࡵࡪࡦࡥࡷࠤࡼ࡮ࡡࡵࠢࡷࡳࠥࡵࡢࡧࡷࡶࡧࡦࡺࡥࠡࡣࡱࡨࠥࡽࡨࡢࡶࠣࡲࡴࡺࠬࠡࡤࡼࠤࡪࡪࡩࡵࡶ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡧࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥ࠯ࠏࠍࠑࠏࡈࡁࡄࡍࡘࡔࠥ࡟ࡏࡖࡔࠣࡇࡔࡊࡅࠡࡃࡑࡈࠥ࡜ࡁࡍࡗࡄࡆࡑࡋࠠࡅࡃࡗࡅ࡚ࠥࡏࠡࡃࡑࠤࡔࡌࡆ࠮ࡎࡌࡒࡊࠦࡍࡆࡆࡌ࡙ࡒࠦࡆࡊࡔࡖࡘ࡚ࠥࡏࠡࡒࡕࡉ࡛ࡋࡎࡕࠢࡄࡇࡈࡏࡄࡆࡐࡗࡅࡑࠦࡌࡐࡕࡖࠤࡔࡌࠠࡘࡑࡕࡏࠦࠧࠡࠎࠌࠐࠎ࡙࡮ࡥ࡯ࠢࡦࡳࡵࡿࠠࡵࡪࡨࠤࡩ࡫ࡦࡢࡷ࡯ࡸࠥࡩ࡯࡯ࡨ࡬࡫ࠥ࡬ࡩ࡭ࡧࠣࡸࡴࠦࡴࡩࡧࠣࡷࡴࡻࡲࡤࡧࠣࡸࡴࡶࠠࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠣࡀࡹࡵࡰࡥ࡫ࡵࡂࠥࡧ࡮ࡥࠢࡵࡹࡳࠦࡻ࠱ࡿࠣࡪࡷࡵ࡭ࠡࡶ࡫ࡩࡷ࡫࠮ࠎࠌࡌࡸࠥࡽࡩ࡭࡮ࠣ࡫ࡪࡴࡥࡳࡣࡷࡩࠥࡧ࡮ࠡࡱࡥࡪࡺࡹࡣࡢࡶ࡬ࡳࡳࠦࡤࡪࡴࡨࡧࡹࡵࡲࡺࠢ࠿ࡸࡴࡶࡤࡪࡴࡁ࠳࠳࠴࠯࠽ࡶࡲࡴࡩ࡯ࡲ࠿ࡡࡾ࠵ࢂࠓࠊࠎࠌࡄࡸࠥ࡬ࡩࡳࡵࡷࠤࡸࡵ࡭ࡦࠢ࡬ࡨࡪࡴࡴࡪࡨ࡬ࡩࡷࡹࠠ࡮ࡣࡼࠤࡧ࡫ࠠࡰࡤࡩࡹࡸࡩࡡࡵࡧࡧࠤࡹ࡮ࡡࡵࠢࡶ࡬ࡴࡻ࡬ࡥࡰࠪࡸࠥࡨࡥ࠭ࠢࡨ࠲࡬࠴ࠠࡴࡱࡰࡩࠥࡵࡦࠡࡶ࡫ࡳࡸ࡫ࠠࡪ࡯ࡳࡳࡷࡺࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡷࡴࡡ࡭ࠢࡰࡳࡩࡻ࡬ࡦࡵ࠱ࠍࠒࠐࡁࡥࡣࡳࡸࠥࡿ࡯ࡶࡴࠣࡧࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡶࡲࠤࡦࡼ࡯ࡪࡦࠣࡸ࡭࡯ࡳ࠭ࠢࡨ࠲࡬࠴ࠠࡣࡻࠣࡥࡩࡪࡩ࡯ࡩࠣࡩࡽࡺࡥࡳࡰࡤࡰࠥࡳ࡯ࡥࡷ࡯ࡩࠥࡴࡡ࡮ࡧࡶࠤࡹ࡮ࡡࡵࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡶࡪࡩࡵࡳࡵ࡬ࡺࡪࡲࡹࠡࡵࡦࡥࡳࡴࡥࡥࠢࡩࡳࡷࠦࡩࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࡶ࠲ࠒࠐ࡙ࡰࡷࠣࡱࡦࡿࠠࡢ࡮ࡶࡳࠥ࡫ࡸࡤ࡮ࡸࡨࡪࠦࡣࡦࡴࡷࡥ࡮ࡴࠠࡸࡱࡵࡨࡸࠦ࡯ࡳࠢࡩ࡭ࡱ࡫ࡳࠡ࡫ࡱࠤࡾࡵࡵࡳࠢࡳࡶࡴࡰࡥࡤࡶࠣࡪࡷࡵ࡭ࠡࡱࡥࡪࡺࡹࡣࡢࡶ࡬ࡳࡳࠦࡥࡹࡲ࡯࡭ࡨ࡯ࡴ࡭ࡻ࠱ࠑࠏ࡙࡯ࡶࡴࡦࡩࠥࡪࡩࡳࡧࡦࡸࡴࡸࡹ࠭ࠢࡲࡦ࡫ࡻࡳࡤࡣࡷ࡭ࡴࡴࠠࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠣࡥࡳࡪࠠࡤࡱࡱࡪ࡮࡭ࠠࡧ࡫࡯ࡩࠥࡶࡡࡵࡪࠣࡧࡦࡴࠠࡢ࡮ࡶࡳࠥࡨࡥࠡࡵࡸࡴࡵࡲࡩࡦࡦࠣࡥࡸࠦࡣࡰ࡯ࡰࡥࡳࡪࠠ࡭࡫ࡱࡩࠥࡶࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࡬ࡲࠥࡺࡨࡢࡶࠣࡳࡷࡪࡥࡳ࠰ࠐࠎࡈࡵ࡭࡮ࡧࡱࡸࡸࠦࡡ࡯ࡦࠣࡷࡹࡸࡩ࡯ࡩࠣࡰ࡮ࡺࡥࡳࡣ࡯ࡷࠥࡩࡡ࡯ࠢࡥࡩࠥࡳࡡࡳ࡭ࡨࡨࠥࡧࡳࠡࡲ࡯ࡥ࡮ࡴࠬࠡࡤࡼࡴࡦࡹࡳࡪࡰࡪࠤࡴࡨࡦࡶࡵࡦࡥࡹ࡯࡯࡯ࠏࠍࠑࠏࡑ࡮ࡰࡹࡱࠤࡱ࡯࡭ࡪࡶࡤࡸ࡮ࡵ࡮ࡴ࠼ࠐࠎࡆࠦࡣࡰ࡯ࡰࡩࡳࡺࠠࡢࡨࡷࡩࡷࠦࡡࠡࡵࡷࡶ࡮ࡴࡧࠡ࡮࡬ࡸࡪࡸࡡ࡭ࠢࡶ࡬ࡴࡻ࡬ࡥࠢࡥࡩࠥࡶࡲࡦࡥࡨࡨࡪࡪࠠࡣࡻࠣࡻ࡭࡯ࡴࡦࡵࡳࡥࡨ࡫ࠍࠋࡃࠣࠫࠥࡵࡲࠡࠤࠣ࡭ࡳࡹࡩࡥࡧࠣࡥࠥࡹࡴࡳ࡫ࡱ࡫ࠥࡲࡩࡵࡧࡵࡥࡱࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡨࡷࡨࡧࡰࡦࡦࠣࡻ࡮ࡺࡨࠡ࡞ࠣࡶࡦࡺࡨࡦࡴࠣࡸ࡭࡫࡮ࠡࡦࡲࡹࡧࡲࡥࡥࠏࠍࡅࠥࢁ࠲ࡾࠢ࡬ࡲࠥࡧࠠࡴࡶࡵ࡭ࡳ࡭ࠠ࡭࡫ࡷࡩࡷࡧ࡬ࠡࡥࡤࡲࠥࡵ࡮࡭ࡻࠣࡦࡪࠦࡵࡴࡧࡧࠤࡦࡺࠠࡵࡪࡨࠤࡸࡺࡡࡳࡶ࠯ࠤࡸࡵࠠࡶࡵࡨࠤࠬࡶࠧࠨࡽ࠵ࢁࠬ࠭ࡲࠨࠢࡵࡥࡹ࡮ࡥࡳࠢࡷ࡬ࡦࡴࠠࠨࡲࡾ࠶ࢂࡸࠧࠎࠌࡒࡦ࡫ࡻࡳࡤࡣࡷ࡭ࡴࡴࠠࡰࡨࠣࡷࡹࡸࡩ࡯ࡩࠣࡰ࡮ࡺࡥࡳࡣ࡯ࡷࠥ࡯ࡳࠡࡷࡱࡷࡺ࡯ࡴࡢࡤ࡯ࡩࠥ࡬࡯ࡳࠢࡶࡩࡳࡹࡩࡵ࡫ࡹࡩࠥ࡯࡮ࡧࡱࡵࡱࡦࡺࡩࡰࡰࠣࡷ࡮ࡴࡣࡦࠢ࡬ࡸࠥࡩࡡ࡯ࠢࡥࡩࠥࡺࡲࡪࡸ࡬ࡥࡱࡲࡹࠡࡤࡵࡳࡰ࡫࡮ࠎࠌࠐࠎࡑ࡯ࡣࡦࡰࡦࡩ࠿ࠓࠊࡼ࠵ࢀࠑࠏ࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠎࠌࠌࠍࠬ࠭ࠧლ").format (l11l111l_opy_.capitalize (), l11l111l_opy_, l1ll1l_opy_ (u"ࡵࠫࠨ࠭მ"), license))
		exit (l1lll1111_opy_)
	if len (sys.argv) > 1:
		if l1ll1l_opy_ (u"ࠫࡄ࠭ნ") in sys.argv [1]:
			l1ll1llll_opy_ (0)
		l1ll1111_opy_ = sys.argv [1]
	else:
		l1ll1111_opy_ = os.getcwd () .replace (l1ll1l_opy_ (u"ࠬࡢ࡜ࠨო"), l1ll1l_opy_ (u"࠭࠯ࠨპ"))
	if len (sys.argv) > 2:
		l1l1l11l1_opy_ = sys.argv [2]
	else:
		l1l1l11l1_opy_ = l1ll1l_opy_ (u"ࠧࡼ࠲ࢀ࠳ࢀ࠷ࡽࡠࡽ࠵ࢁࠬჟ").format (* (l1ll1111_opy_.rsplit (l1ll1l_opy_ (u"ࠨ࠱ࠪრ"), 1) + [l11l111l_opy_]))
	if len (sys.argv) > 3:
		l1l1llll1_opy_ = sys.argv [3]
	else:
		l1l1llll1_opy_ = l1ll1l_opy_ (u"ࠩࡾ࠴ࢂ࠵ࡻ࠲ࡿࡢࡧࡴࡴࡦࡪࡩ࠱ࡸࡽࡺࠧს").format (l1ll1111_opy_, l11l111l_opy_)
	obfuscate_strings = False
	l1l11l11_opy_ = l1ll1l_opy_ (u"ࠪࡣࢀࢃ࡟ࠨტ").format (l11l111l_opy_)
	plain_marker = l1ll1l_opy_ (u"ࠫࡤࢁࡽࡠࠩუ").format (l11l111l_opy_)
	source_extensions = l1ll1l_opy_ (u"ࠬ࠭ფ")
	l11l1l11_opy_ = l1ll1l_opy_ (u"࠭ࠧქ")
	external_modules = l1ll1l_opy_ (u"ࠧࠨღ")
	plain_files = l1ll1l_opy_ (u"ࠨࠩყ")
	plain_names = l1ll1l_opy_ (u"ࠩࠪშ")
	try:
		l1lllll11_opy_ = open (l1l1llll1_opy_)
	except Exception as l1lll11ll_opy_:
		print (l1lll11ll_opy_)
		l1ll1llll_opy_ (1)
	exec (l1lllll11_opy_.read ())
	l1lllll11_opy_.close ()
	try:
		l1l1llll_opy_ = obfuscate_strings
	except:
		l1l1llll_opy_ = False
	try:
		l1lll1lll_opy_ = l1lll11l1_opy_
	except:
		l1lll1lll_opy_ = False
	try:
		l1ll111ll_opy_ = l1l11l11_opy_
	except:
		l1ll111ll_opy_ = l1ll1l_opy_ (u"ࠪࠫჩ")
	try:
		l1l1111l_opy_ = plain_marker
	except:
		l1l1111l_opy_ = l1ll1l_opy_ (u"ࠫࡤࢁ࠰ࡾࡡࠪც").format (l11l111l_opy_)
	l11l11l1_opy_ = source_extensions.split ()
	l1l1l1lll_opy_ = l11l1l11_opy_.split ()
	l1l11llll_opy_ = external_modules.split ()
	l1llllll1_opy_ = plain_files.split ()
	l1ll11lll_opy_ = plain_names.split ()
	l1l1ll11_opy_ = [
		l1ll1l_opy_ (u"ࠬࢁ࠰ࡾ࠱ࡾ࠵ࢂ࠭ძ").format (l1l11lll1_opy_.replace (l1ll1l_opy_ (u"࠭࡜࡝ࠩწ"), l1ll1l_opy_ (u"ࠧ࠰ࠩჭ")), l1l11lll_opy_)
		for l1l11lll1_opy_, l1l1l11ll_opy_, l1ll11111_opy_ in os.walk (l1ll1111_opy_)
		for l1l11lll_opy_ in l1ll11111_opy_
	]
	l1lllllll_opy_ = re.compile (l1ll1l_opy_ (u"ࡳࠩࡡࡿ࠵ࢃࠡࠨხ").format (l1ll1l_opy_ (u"ࡴࠪࠧࠬჯ")))
	l1lll1ll1_opy_ = re.compile (l1ll1l_opy_ (u"ࠪࡧࡴࡪࡩ࡯ࡩ࡞࠾ࡂࡣ࡜ࡴࠬࠫ࡟࠲ࡢࡷ࠯࡟࠮࠭ࠬჰ"))
	l1l1ll1l_opy_ = re.compile (l1ll1l_opy_ (u"ࠫ࠳࠰ࡻ࠱ࡿ࠱࠮ࠬჱ").format (l1l1111l_opy_), re.DOTALL)
	def l111l1l1_opy_ (l1l1ll1l1_opy_):
		l111l111_opy_ = l1l1ll1l1_opy_.group (0)
		if l1l1ll1l_opy_.search (l111l111_opy_):
			l11111ll_opy_.append (l111l111_opy_.replace (l1l1111l_opy_, l1ll1l_opy_ (u"ࠬ࠭ჲ")))
			return l1llll11l_opy_
		else:
			return l1ll1l_opy_ (u"࠭ࠧჳ")
	def l1l11ll1_opy_ (l1l1ll1l1_opy_):
		global l1l11111_opy_
		l1l11111_opy_ += 1
		return l11111ll_opy_ [l1l11111_opy_]
	l1l1l1ll1_opy_ = re.compile (l1ll1l_opy_ (u"ࡲࠨࡽ࠳ࢁࢀ࠷ࡽࡼ࠴ࢀ࠲࠯ࡅࠤࠨჴ").format (
		l1ll1l_opy_ (u"ࡳࠤࠫࡃࡁࠧࠧࠪࠤჵ"),
		l1ll1l_opy_ (u"ࡴࠪࠬࡄࡂࠡࠣࠫࠪჶ"),
		l1ll1l_opy_ (u"ࡵࠫࠨ࠭ჷ")
	), re.MULTILINE)
	l1llll11l_opy_ = l1ll1l_opy_ (u"ࠫࡤࢁ࠰ࡾࡡࡦࡣࠬჸ").format (l11l111l_opy_)
	l1ll1l111_opy_ = re.compile (l1ll1l_opy_ (u"ࡷ࠭ࡻ࠱ࡿࠪჹ").format (l1llll11l_opy_))
	l1l1lll1_opy_ = re.compile (l1ll1l_opy_ (u"ࡸࠧ࠯ࠬࡾ࠴ࢂ࠴ࠪࠨჺ").format (l1l1111l_opy_))
	def l1l1lll11_opy_ (l1l1ll1l1_opy_):
		string = l1l1ll1l1_opy_.group (0)
		if l1l1llll_opy_:
			if l1l1lll1_opy_.search (string):
				l11lllll_opy_.append (string.replace (l1l1111l_opy_, l1ll1l_opy_ (u"ࠧࠨ჻")))
				return l1ll1lll1_opy_
			else:
				l11lllll_opy_.append (l1ll1l11l_opy_ (string))
				return l1ll1l_opy_ (u"ࠨࡷࡱࡗࡨࡸࡡ࡮ࡤ࡯ࡩࢀ࠶ࡽࠡࠪࡾ࠵ࢂ࠯ࠧჼ").format (l1l1111l_opy_, l1ll1lll1_opy_)
		else:
			l11lllll_opy_.append (string)
			return l1ll1lll1_opy_
	def l1111111_opy_ (l1l1ll1l1_opy_):
		global l11l1lll_opy_
		l11l1lll_opy_ += 1
		return l11lllll_opy_ [l11l1lll_opy_]
	l1l1ll1ll_opy_ = re.compile (l1ll1l_opy_ (u"ࡴࠪࠬࡠࡸࡵ࡞ࡾࡵࡹࢁࡻࡲࠪࡁࠫࠬࢀ࠶ࡽࠪࡾࠫࡿ࠶ࢃࠩࡽࠪࡾ࠶ࢂ࠯ࡼࠩࡽ࠶ࢁ࠮࠯ࠧჽ").format (
		l1ll1l_opy_ (u"ࡵࠦࠬ࠭ࠧ࠯ࠬࡂࠬࡄࡂࠡ࡜ࡠ࡟ࡠࡢࡢ࡜ࠪࠪࡂࡀࠦࡡ࡞࡝࡞ࡠࡠࠬ࠯ࠧࠨࠩࠥჾ"),
		l1ll1l_opy_ (u"ࡶࠬࠨࠢࠣ࠰࠭ࡃ࠭ࡅ࠼ࠢ࡝ࡡࡠࡡࡣ࡜࡝ࠫࠫࡃࡁ࡛ࠧ࡟࡞࡟ࡡࡡࠨࠩࠣࠤࠥࠫჿ"),
		l1ll1l_opy_ (u"ࡷࠨࠧ࠯ࠬࡂࠬࡄࡂࠡ࡜ࡠ࡟ࡠࡢࡢ࡜ࠪࠩࠥᄀ"),
		l1ll1l_opy_ (u"ࡸࠧࠣ࠰࠭ࡃ࠭ࡅ࠼ࠢ࡝ࡡࡠࡡࡣ࡜࡝ࠫࠥࠫᄁ")
	), re.MULTILINE | re.DOTALL | re.VERBOSE)
	l1ll1lll1_opy_ = l1ll1l_opy_ (u"ࠧࡠࡽ࠳ࢁࡤࡹ࡟ࠨᄂ").format (l11l111l_opy_)
	l1111ll1_opy_ = re.compile (l1ll1l_opy_ (u"ࡳࠩࡾ࠴ࢂ࠭ᄃ").format (l1ll1lll1_opy_))
	def l1ll1l11_opy_ (l1l1ll1l1_opy_):
		l1ll1l1l1_opy_ = l1l1ll1l1_opy_.group (0)
		if l1ll1l1l1_opy_:
			global l11111l1_opy_
			l1lllll1l_opy_ [l11111l1_opy_:l11111l1_opy_] = [l1ll1l1l1_opy_]
			l11111l1_opy_ += 1
		return l1ll1l_opy_ (u"ࠩࠪᄄ")
	l1ll11ll1_opy_ = re.compile (l1ll1l_opy_ (u"ࠪࡪࡷࡵ࡭࡝ࡵ࠭ࡣࡤ࡬ࡵࡵࡷࡵࡩࡤࡥ࡜ࡴࠬ࡬ࡱࡵࡵࡲࡵ࡞ࡶ࠮ࡡࡽࠫ࠯ࠬࠧࠫᄅ"), re.MULTILINE)
	l11lll1l_opy_ = re.compile (l1ll1l_opy_ (u"ࡶࠬ࠭ࠧࠎࠌࠌࠍࡡࡨࠉࠊࠋࠍࠍࠎ࠮࠿ࠢࡡࡢ࠭ࠎࠏࠊࠊࠋࠫࡃࠦࢁ࠰ࡾࠫࠌࠍࠏࠏࠉࠩࡁࠤࡿ࠶ࢃࠩࠊࠋࠍࠍࠎࡡ࡞࡝ࡦ࡟࡛ࡢࠏࠉࠋࠋࠌࡠࡼ࠰ࠉࠊࠋࠍࠍࠎ࠮࠿࠽ࠣࡢࡣ࠮ࠏࠉࠋࠋࠌࠬࡄࡂࠡࡼ࠲ࢀ࠭ࠎࠐࠉࠊࠪࡂࡀࠦࢁ࠱ࡾࠫࠌࠎࠎࠏ࡜ࡣࠋࠌࠍࠏࠏࠧࠨࠩᄆ").format (l1llll11l_opy_, l1ll1lll1_opy_), re.VERBOSE)
	l1lll1l1l_opy_ = re.compile (l1ll1l_opy_ (u"ࡷ࠭࡜ࡣࡥ࡫ࡶࡡࡨࠧᄇ"))
	l1111lll_opy_ = set (keyword.kwlist + [l1ll1l_opy_ (u"࠭࡟ࡠ࡫ࡱ࡭ࡹࡥ࡟ࠨᄈ")] + l1ll11lll_opy_)
	l1ll1111l_opy_ = [l1ll1l_opy_ (u"ࠧࡼ࠲ࢀ࠳ࢀ࠷ࡽࠨᄉ").format (l1ll1111_opy_, l111ll1l_opy_) for l111ll1l_opy_ in l1llllll1_opy_]
	for l1l111ll_opy_ in l1ll1111l_opy_:
		l1ll111l1_opy_ = open (l1l111ll_opy_)
		content = l1ll111l1_opy_.read ()
		l1ll111l1_opy_.close ()
		content = l1l1l1ll1_opy_.sub (l1ll1l_opy_ (u"ࠨࠩᄊ"), content)
		content = l1l1ll1ll_opy_.sub (l1ll1l_opy_ (u"ࠩࠪᄋ"), content)
		l1111lll_opy_.update (re.findall (l11lll1l_opy_, content))
	class l1lll1l11_opy_:
		def __init__ (self):
			for l11l11ll_opy_ in l1l11llll_opy_:
				l1l1l111_opy_ = l11l11ll_opy_.replace (l1ll1l_opy_ (u"ࠪ࠲ࠬᄌ"), l1l1111l_opy_)
				try:
					exec (
						l1ll1l_opy_ (u"ࠫࠬ࠭ࠍࠋ࡫ࡰࡴࡴࡸࡴࠡࡽ࠳ࢁࠥࡧࡳࠡࡥࡸࡶࡷ࡫࡮ࡵࡏࡲࡨࡺࡲࡥࠎࠌࠌࠍࠎࠏࠉࠊࠩࠪࠫᄍ").format (l11l11ll_opy_),
						globals ()
					)
					setattr (self, l1l1l111_opy_, currentModule)
				except Exception as l1lll11ll_opy_:
					print (l1lll11ll_opy_)
					setattr (self, l1l1l111_opy_, None)
					print (l1ll1l_opy_ (u"ࠬ࡝ࡡࡳࡰ࡬ࡲ࡬ࡀࠠࡤࡱࡸࡰࡩࠦ࡮ࡰࡶࠣ࡭ࡳࡹࡰࡦࡥࡷࠤࡪࡾࡴࡦࡴࡱࡥࡱࠦ࡭ࡰࡦࡸࡰࡪࠦࡻ࠱ࡿࠪᄎ").format (l11l11ll_opy_))
	l1l1l1l1_opy_ = l1lll1l11_opy_ ()
	l11l1111_opy_ = set ()
	def l11l1ll1_opy_ (l111l11l_opy_):
		if l111l11l_opy_ in l11l1111_opy_:
			return
		else:
			l11l1111_opy_.update ([l111l11l_opy_])
		try:
			l1ll11l1_opy_ = list (l111l11l_opy_.__dict__)
		except:
			l1ll11l1_opy_ = []
		try:
			if l1ll1l1ll_opy_:
				l11llll1_opy_ = list (l111l11l_opy_.func_code.co_varnames)
			else:
				l11llll1_opy_ = list (l111l11l_opy_.__code__.co_varnames)
		except:
			l11llll1_opy_ = []
		l1llll111_opy_ = [getattr (l111l11l_opy_, l1l1l111_opy_) for l1l1l111_opy_ in l1ll11l1_opy_]
		l1l1lllll_opy_ = (l1l1111l_opy_.join (l1ll11l1_opy_)) .split (l1l1111l_opy_)
		l1l11ll11_opy_ = set ([l1l11ll1l_opy_ for l1l11ll1l_opy_ in (l11llll1_opy_ + l1l1lllll_opy_) if not (l1l11ll1l_opy_.startswith (l1ll1l_opy_ (u"࠭࡟ࡠࠩᄏ")) and l1l11ll1l_opy_.endswith (l1ll1l_opy_ (u"ࠧࡠࡡࠪᄐ")))])
		l1111lll_opy_.update (l1l11ll11_opy_)
		for l1ll11l11_opy_ in l1llll111_opy_:
			try:
				l11l1ll1_opy_ (l1ll11l11_opy_)
			except:
				pass
	l11l1ll1_opy_ (__builtins__)
	l11l1ll1_opy_ (l1l1l1l1_opy_)
	l1l11l1l_opy_ = list (l1111lll_opy_)
	l1l11l1l_opy_.sort (key = lambda s: s.lower ())
	l111111l_opy_ = []
	l1lll111l_opy_ = []
	for l1l1l1111_opy_ in l1l1ll11_opy_:
		if l1l1l1111_opy_ == l1l1llll1_opy_:
			continue
		l1l1l1ll_opy_, l1ll1ll1l_opy_ = l1l1l1111_opy_.rsplit (l1ll1l_opy_ (u"ࠨ࠱ࠪᄑ"), 1)
		l1l1l1l11_opy_, l1111l11_opy_ = (l1ll1ll1l_opy_.rsplit (l1ll1l_opy_ (u"ࠩ࠱ࠫᄒ"), 1) + [l1ll1l_opy_ (u"ࠪࠫᄓ")]) [ : 2]
		l111ll11_opy_ =  l1l1l1111_opy_ [len (l1ll1111_opy_) : ]
		if l1111l11_opy_ in l11l11l1_opy_ and not l1l1l1111_opy_ in l1ll1111l_opy_:
			l11ll1l1_opy_ = random.randrange (64)
			l1l111l1_opy_ = codecs.open (l1l1l1111_opy_, encoding = l1ll1l_opy_ (u"ࠫࡺࡺࡦ࠮࠺ࠪᄔ"))
			content = l1l111l1_opy_.read ()
			l1l111l1_opy_.close ()
			l11111ll_opy_ = []
			l1lllll1l_opy_ = content.split (l1ll1l_opy_ (u"ࠬࡢ࡮ࠨᄕ"), 2)
			l11111l1_opy_ = 0
			l1llll1ll_opy_ = True
			if len (l1lllll1l_opy_) > 0:
				if l1lllllll_opy_.search (l1lllll1l_opy_ [0]):
					l11111l1_opy_ += 1
					if len (l1lllll1l_opy_) > 1 and l1lll1ll1_opy_.search (l1lllll1l_opy_ [1]):
						l11111l1_opy_ += 1
						l1llll1ll_opy_ = False
				elif l1lll1ll1_opy_.search (l1lllll1l_opy_ [0]):
					l11111l1_opy_ += 1
					l1llll1ll_opy_ = False
			if l1l1llll_opy_ and l1llll1ll_opy_:
				l1lllll1l_opy_ [l11111l1_opy_:l11111l1_opy_] = [l1ll1l_opy_ (u"࠭ࠣࠡࡥࡲࡨ࡮ࡴࡧ࠻ࠢࡘࡘࡋ࠳࠸ࠨᄖ")]
				l11111l1_opy_ += 1
			if l1l1llll_opy_:
				l1ll1l1l_opy_ = l1ll1l_opy_ (u"ࠧ࡝ࡰࠪᄗ").join ([l1ll1ll1_opy_ (l11ll1l1_opy_)] + l1lllll1l_opy_ [l11111l1_opy_:])
			else:
				l1ll1l1l_opy_ = l1ll1l_opy_ (u"ࠨ࡞ࡱࠫᄘ").join (l1lllll1l_opy_ [l11111l1_opy_:])
			l1ll1l1l_opy_ = l1l1l1ll1_opy_.sub (l111l1l1_opy_, l1ll1l1l_opy_)
			l11lllll_opy_ = []
			l1ll1l1l_opy_ = l1l1ll1ll_opy_.sub (l1l1lll11_opy_, l1ll1l1l_opy_)
			l1ll1l1l_opy_ = l1ll11ll1_opy_.sub (l1ll1l11_opy_, l1ll1l1l_opy_)
			l1ll111l_opy_ = set (re.findall (l11lll1l_opy_, l1ll1l1l_opy_) + [l1l1l1l11_opy_])
			l11ll1ll_opy_ = l1ll111l_opy_.difference (l111111l_opy_).difference (l1111lll_opy_)
			l11ll11l_opy_ = list (l11ll1ll_opy_)
			l1l1l111l_opy_ = [re.compile (l1ll1l_opy_ (u"ࡴࠪࡠࡧࢁ࠰ࡾ࡞ࡥࠫᄙ").format (l11lll11_opy_)) for l11lll11_opy_ in l11ll11l_opy_]
			l111111l_opy_ += l11ll11l_opy_
			l1lll111l_opy_ += l1l1l111l_opy_
			for l1l1ll111_opy_, l1l1ll11l_opy_ in enumerate (l1lll111l_opy_):
				l1ll1l1l_opy_ = l1l1ll11l_opy_.sub (l11ll111_opy_ (l1l1ll111_opy_, l111111l_opy_ [l1l1ll111_opy_] .startswith (l1ll1l_opy_ (u"ࠪࡣࠬᄚ"))), l1ll1l1l_opy_)
			l11l1lll_opy_ = -1
			l1ll1l1l_opy_ = l1111ll1_opy_.sub (l1111111_opy_, l1ll1l1l_opy_)
			l1l11111_opy_ = -1
			l1ll1l1l_opy_ = l1ll1l111_opy_.sub (l1l11ll1_opy_, l1ll1l1l_opy_)
			content = l1ll1l_opy_ (u"ࠫࡡࡴࠧᄛ").join (l1lllll1l_opy_ [:l11111l1_opy_] + [l1ll1l1l_opy_])
			content = l1ll1l_opy_ (u"ࠬࡢ࡮ࠨᄜ").join ([line for line in [line.rstrip () for line in content.split (l1ll1l_opy_ (u"࠭࡜࡯ࠩᄝ"))] if line])
			try:
				l1ll1ll11_opy_ = l11ll111_opy_ (l111111l_opy_.index (l1l1l1l11_opy_), l1l1l1l11_opy_.startswith (l1ll1l_opy_ (u"ࠧࡠࠩᄞ")))
			except:
				l1ll1ll11_opy_ = l1l1l1l11_opy_
			l111lll1_opy_ = l111ll11_opy_.split (l1ll1l_opy_ (u"ࠨ࠱ࠪᄟ"))
			for index in range (len (l111lll1_opy_)):
				try:
					l111lll1_opy_ [index] = l11ll111_opy_ (l111111l_opy_.index (l111lll1_opy_ [index]), l111lll1_opy_ [index].startswith (l1ll1l_opy_ (u"ࠩࡢࠫᄠ")))
				except:
					pass
			l111ll11_opy_ = l1ll1l_opy_ (u"ࠪ࠳ࠬᄡ").join (l111lll1_opy_)
			l1ll11ll_opy_ = l1ll1l_opy_ (u"ࠫࢀ࠶ࡽࡼ࠳ࢀࠫᄢ").format (l1l1l11l1_opy_, l111ll11_opy_) .rsplit (l1ll1l_opy_ (u"ࠬ࠵ࠧᄣ"), 1) [0]
			l111l1ll_opy_ = l111llll_opy_ (l1ll1l_opy_ (u"࠭ࡻ࠱ࡿ࠲ࡿ࠶ࢃ࠮ࡼ࠴ࢀࠫᄤ").format (l1ll11ll_opy_, l1ll1ll11_opy_, l1111l11_opy_), open = True)
			l111l1ll_opy_.write (content)
			l111l1ll_opy_.close ()
		elif not l1111l11_opy_ in l1l1l1lll_opy_:
			l1ll11ll_opy_ = l1ll1l_opy_ (u"ࠧࡼ࠲ࢀࡿ࠶ࢃࠧᄥ").format (l1l1l11l1_opy_, l111ll11_opy_) .rsplit (l1ll1l_opy_ (u"ࠨ࠱ࠪᄦ"), 1) [0]
			l1ll11l1l_opy_ = l1ll1l_opy_ (u"ࠩࡾ࠴ࢂ࠵ࡻ࠲ࡿࠪᄧ").format (l1ll11ll_opy_, l1ll1ll1l_opy_)
			l111llll_opy_ (l1ll11l1l_opy_)
			shutil.copyfile (l1l1l1111_opy_, l1ll11l1l_opy_)
	print (l1ll1l_opy_ (u"ࠪࡓࡧ࡬ࡵࡴࡥࡤࡸࡪࡪࠠࡸࡱࡵࡨࡸࡀࠠࡼ࠲ࢀࠫᄨ").format (len (l111111l_opy_)))