# coding: UTF-8
import sys
l1lll1ll_opy_ = sys.version_info [0] == 2
l1ll111_opy_ = 2048
l1ll1l_opy_ = 7
def l1111l_opy_ (ll_opy_):
	global l111_opy_
	l11111l_opy_ = ord (ll_opy_ [-1])
	l1llll1l_opy_ = ll_opy_ [:-1]
	l1ll1_opy_ = l11111l_opy_ % len (l1llll1l_opy_)
	l11l111_opy_ = l1llll1l_opy_ [:l1ll1_opy_] + l1llll1l_opy_ [l1ll1_opy_:]
	if l1lll1ll_opy_:
		l1l1l1l_opy_ = unicode () .join ([unichr (ord (char) - l1ll111_opy_ - (l11l1l_opy_ + l11111l_opy_) % l1ll1l_opy_) for l11l1l_opy_, char in enumerate (l11l111_opy_)])
	else:
		l1l1l1l_opy_ = str () .join ([chr (ord (char) - l1ll111_opy_ - (l11l1l_opy_ + l11111l_opy_) % l1ll1l_opy_) for l11l1l_opy_, char in enumerate (l11l111_opy_)])
	return eval (l1l1l1l_opy_)
import xbmc
import xbmcaddon
import json
import os
import shutil
import dixie
l11ll1111_opy_     = l1111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡰࡷࡺࠬए")
l11ll1lll_opy_     = l1111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸ࡯ࡹࡻࡲ࡬ࠩऐ")
l11l1l11l_opy_ = [l11ll1111_opy_, l11ll1lll_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1111l_opy_ (u"ࠫ࡮ࡴࡩࠨऑ"))
def checkAddons():
    for l11l11l_opy_ in l11l1l11l_opy_:
        if l11l1l1l1_opy_(l11l11l_opy_):
            try: l11ll11ll_opy_(l11l11l_opy_)
            except: pass
def l11l1l1l1_opy_(l11l11l_opy_):
    if xbmc.getCondVisibility(l1111l_opy_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠦࡵࠬࠫऒ") % l11l11l_opy_) == 1:
        return True
    return False
def l11ll11ll_opy_(l11l11l_opy_):
    l11lll1l1_opy_ = l11ll1l1l_opy_(l11l11l_opy_) + l1111l_opy_ (u"࠭࠮ࡪࡰ࡬ࠫओ")
    l11ll11l1_opy_  = os.path.join(PATH, l11lll1l1_opy_)
    l1lll111_opy_ = l11lllll1_opy_(l11l11l_opy_)
    l11llll11_opy_  = file(l11ll11l1_opy_, l1111l_opy_ (u"ࠧࡸࠩऔ"))
    l11llll11_opy_.write(l1111l_opy_ (u"ࠨ࡝ࠪक"))
    l11llll11_opy_.write(l11l11l_opy_)
    l11llll11_opy_.write(l1111l_opy_ (u"ࠩࡠࠫख"))
    l11llll11_opy_.write(l1111l_opy_ (u"ࠪࡠࡳ࠭ग"))
    for l1llll1_opy_ in l1lll111_opy_:
        l1l1lll1_opy_   = l1llll1_opy_[l1111l_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪघ")]
        l1l1lll1_opy_ = l1l1lll1_opy_.replace(l1111l_opy_ (u"࡛ࠬࠦࠨङ"), l1111l_opy_ (u"࡛࠭ࠨच")).replace(l1111l_opy_ (u"ࠧ࡞ࠢࠪछ"), l1111l_opy_ (u"ࠨ࡟ࠪज")).replace(l1111l_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡤࡵࡺࡧ࡝ࠨझ"), l1111l_opy_ (u"ࠪࠫञ")).replace(l1111l_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡱ࡯࡭ࡦࡩࡵࡩࡪࡴ࡝ࠨट"), l1111l_opy_ (u"ࠬ࠭ठ")).replace(l1111l_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡹࡦ࡮࡯ࡳࡼࡣࠧड"), l1111l_opy_ (u"ࠧࠨढ")).replace(l1111l_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣࠧण"), l1111l_opy_ (u"ࠩࠪत")).replace(l1111l_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡳࡷࡧ࡮ࡨࡧࡠࠫथ"), l1111l_opy_ (u"ࠫࠬद")).replace(l1111l_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡸࡥࡥ࡟ࠪध"), l1111l_opy_ (u"࠭ࠧन")).replace(l1111l_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡸࡪ࡬ࡸࡪࡣࠧऩ"), l1111l_opy_ (u"ࠨࠩप")).replace(l1111l_opy_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫफ"), l1111l_opy_ (u"ࠪࠫब"))
        stream  = l1llll1_opy_[l1111l_opy_ (u"ࠫ࡫࡯࡬ࡦࠩभ")]
        l11llll11_opy_.write(l1111l_opy_ (u"ࠬࠫࡳࠨम") % l1l1lll1_opy_)
        l11llll11_opy_.write(l1111l_opy_ (u"࠭࠽ࠨय"))
        l11llll11_opy_.write(l1111l_opy_ (u"ࠧࠦࡵࠪर") % stream)
        l11llll11_opy_.write(l1111l_opy_ (u"ࠨ࡞ࡱࠫऱ"))
    l11llll11_opy_.write(l1111l_opy_ (u"ࠩ࡟ࡲࠬल"))
    l11llll11_opy_.close()
def l11ll1l1l_opy_(l11l11l_opy_):
    if l11l11l_opy_ == l11ll1111_opy_:
        return l1111l_opy_ (u"ࠪࡲࡹࡼࠧळ")
    if l11l11l_opy_ == l11ll1lll_opy_:
        return l1111l_opy_ (u"ࠫࡺࡱࡴࠨऴ")
def l11lllll1_opy_(l11l11l_opy_):
    if l11l11l_opy_ == l11ll1lll_opy_:
        return l11l1llll_opy_(l11l11l_opy_)
    if l11l11l_opy_ == l11ll1111_opy_:
        xbmcaddon.Addon(l11ll1111_opy_).setSetting(l1111l_opy_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫव"), l1111l_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬश"))
        xbmcaddon.Addon(l11ll1111_opy_).setSetting(l1111l_opy_ (u"ࠧࡵࡸࡪࡹ࡮ࡪࡥࠨष"), l1111l_opy_ (u"ࠨࡨࡤࡰࡸ࡫ࠧस"))
    l11l1lll1_opy_  = l1111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬह") + l11l11l_opy_
    l11ll1ll1_opy_ =  l11llll1l_opy_(l11l11l_opy_)
    query   =  l11l1lll1_opy_ + l11ll1ll1_opy_
    return sendJSON(query, l11l11l_opy_)
def getPluginInfo(streamurl):
    if streamurl.isdigit():
        l11l1l1ll_opy_   = l1111l_opy_ (u"ࠪࡏࡴࡪࡩࠡࡒ࡙ࡖࠥࡉࡨࡢࡰࡱࡩࡱ࠭ऺ")
        l11l1ll11_opy_ = os.path.join(dixie.RESOURCES, l1111l_opy_ (u"ࠫࡰࡵࡤࡪ࠯ࡳࡺࡷ࠴ࡰ࡯ࡩࠪऻ"))
        return l11l1l1ll_opy_, l11l1ll11_opy_
    if streamurl.startswith(l1111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ़")):
        name = streamurl.split(l1111l_opy_ (u"࠭࠯࠰ࠩऽ"), 1)[-1].rsplit(l1111l_opy_ (u"ࠧ࠰ࠩा"), 1)[0]
    if streamurl.startswith(l1111l_opy_ (u"ࠨࡊࡇࡘ࡛ࡀࠧि")):
        name = l1111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡪࡧࡸࡻ࠭ी")
    if streamurl.startswith(l1111l_opy_ (u"ࠪࡌࡉ࡚ࡖ࠳࠼ࠪु")):
        name = l1111l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡺࡿࡡࡪࡲࡷࡺࠬू")
    if streamurl.startswith(l1111l_opy_ (u"ࠬࡎࡄࡕࡘ࠶࠾ࠬृ")):
        name = l1111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡵࡺࡣࡷࡺࠬॄ")
    if streamurl.startswith(l1111l_opy_ (u"ࠧࡉࡆࡗ࡚࠹ࡀࠧॅ")):
        name = l1111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡹ࡮ࠪॆ")
    if streamurl.startswith(l1111l_opy_ (u"ࠩࡌࡔࡑࡇ࡙࠻ࠩे")):
        name = l1111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡥࡦࡨ࡯ࡰ࡭ࡣࡼࡩࡷ࠭ै")
    if streamurl.startswith(l1111l_opy_ (u"ࠫࡎࡖࡌࡂ࡛࠵࠾ࠬॉ")):
        name = l1111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶ࡬ࡢࡻࡨࡶࡼࡽࡷࠨॊ")
    if streamurl.startswith(l1111l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡎ࡚ࡖ࠻ࠩो")):
        name = l1111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡵࡸࠪौ")
    if streamurl.startswith(l1111l_opy_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠻्ࠩ")):
        name = l1111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮࡬ࡺࡪࡳࡩࡹࠩॎ")
    if streamurl.startswith(l1111l_opy_ (u"ࠪࡹࡵࡴࡰ࠻ࠩॏ")):
        name = l1111l_opy_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲࡭ࡪࡨࡰ࡯ࡨࡶࡺࡴ࠮ࡷ࡫ࡨࡻࠬॐ")
    try:
        l11l1l1ll_opy_   = xbmcaddon.Addon(name).getAddonInfo(l1111l_opy_ (u"ࠬࡴࡡ࡮ࡧࠪ॑"))
        l11l1ll11_opy_ = xbmcaddon.Addon(name).getAddonInfo(l1111l_opy_ (u"࠭ࡩࡤࡱࡱ॒ࠫ"))
        l11ll1l11_opy_  = l1111l_opy_ (u"ࠢࡰࡵ࠱ࡶࡪࡳ࡯ࡷࡧࠫࡳࡸ࠴ࡰࡢࡶ࡫࠲࡯ࡵࡩ࡯ࠪࡻࡦࡲࡩ࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࡓࡥࡹ࡮ࠨࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡵࡸ࡯ࡧ࡫࡯ࡩ࠴࠭ࠩ࠭ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠵ࡳࡤࡴ࡬ࡴࡹ࠴ࡴࡷࡲࡲࡶࡹࡧ࡬࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠰ࡧࡦࠬ࠯ࠩࠣ॓")
        eval(l11ll1l11_opy_)
    except: pass
    return l11l1l1ll_opy_, l11l1ll11_opy_
def l11l1llll_opy_(l11l11l_opy_):
    l11l1lll1_opy_ = l1111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫ॔") + l11l11l_opy_
    l11l11lll_opy_ = l1111l_opy_ (u"ࠩ࠲ࡃࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࠬ࡭ࡰࡦࡨࡁ࠶ࠬ࡮ࡢ࡯ࡨࡁࡑ࡯ࡶࡦࠧ࠵࠴࡙࡜ࠦࡶࡴ࡯ࡁ࡭ࡺࡴࡱࠧ࠶ࡥࠪ࠸ࡦࠦ࠴ࡩࡱࡪࡺࡡ࡭࡭ࡨࡸࡹࡲࡥ࠯ࡥࡲࠩ࠷࡬ࡕࡌࡖࡸࡶࡰ࠷࠸࠱࠴࠵࠴࠶࠼ࠥ࠳ࡨࡏ࡭ࡻ࡫ࠥ࠳࠷࠵࠴࡙࡜࠮ࡵࡺࡷࠫॕ")
    l11l1l111_opy_ = l1111l_opy_ (u"ࠪ࠳ࡄࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦ࡮ࡱࡧࡩࡂ࠷ࠦ࡯ࡣࡰࡩࡂ࡙ࡰࡰࡴࡷࡷࠫࡻࡲ࡭࠿࡫ࡸࡹࡶࠥ࠴ࡣࠨ࠶࡫ࠫ࠲ࡧ࡯ࡨࡸࡦࡲ࡫ࡦࡶࡷࡰࡪ࠴ࡣࡰࠧ࠵ࡪ࡚ࡑࡔࡶࡴ࡮࠵࠽࠶࠲࠳࠲࠴࠺ࠪ࠸ࡦࡔࡲࡲࡶࡹࡹࡌࡪࡵࡷ࠲ࡹࡾࡴࠨॖ")
    l1ll1lll_opy_  = []
    l1ll1lll_opy_ += sendJSON(l11l1lll1_opy_ + l11l11lll_opy_, l11l11l_opy_)
    l1ll1lll_opy_ += sendJSON(l11l1lll1_opy_ + l11l1l111_opy_, l11l11l_opy_)
    return l1ll1lll_opy_
def l11llll1l_opy_(l11l11l_opy_):
    if l11l11l_opy_ == l11ll1111_opy_:
        return l1111l_opy_ (u"ࠫ࠴ࡅࡣࡢࡶࡀ࠱࠷ࠬ࡭ࡰࡦࡨࡁ࠷ࠬ࡮ࡢ࡯ࡨࡁࡒࡿࠥ࠳࠲ࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪࡺࡸ࡬࠾ࡷࡵࡰࠬॗ")
def sendJSON(query, l11l11l_opy_):
    try:
        l11lll_opy_     = l1111l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࠦࡵࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨक़") % query
        l1l1lll_opy_  = xbmc.executeJSONRPC(l11lll_opy_)
        response = json.loads(l1l1lll_opy_)
        result   = response[l1111l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ख़")]
        return result[l1111l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ग़")]
    except Exception as e:
        l1l1l1l1_opy_(e, l11l11l_opy_)
        return {l1111l_opy_ (u"ࠨࡇࡵࡶࡴࡸࠧज़") : l1111l_opy_ (u"ࠩࡓࡰࡺ࡭ࡩ࡯ࠢࡈࡶࡷࡵࡲࠨड़")}
def l1l1l1l1_opy_(e, l11l11l_opy_):
    l1l1llll_opy_ = l1111l_opy_ (u"ࠪࡗࡴࡸࡲࡺ࠮ࠣࡥࡳࠦࡥࡳࡴࡲࡶࠥࡵࡣࡤࡷࡵࡩࡩࡀࠠࡋࡕࡒࡒࠥࡋࡲࡳࡱࡵ࠾ࠥࠫࡳ࠭ࠢࠨࡷࠬढ़")  % (e, l11l11l_opy_)
    l1l1l1ll_opy_ = l1111l_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡨࡵ࡮ࡵࡣࡦࡸࠥࡻࡳࠡࡱࡱࠤࡹ࡮ࡥࠡࡨࡲࡶࡺࡳ࠮ࠨफ़")
    l1ll111l_opy_ = l1111l_opy_ (u"࡛ࠬࡰ࡭ࡱࡤࡨࠥࡧࠠ࡭ࡱࡪࠤࡻ࡯ࡡࠡࡶ࡫ࡩࠥࡧࡤࡥࡱࡱࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸࠦࡡ࡯ࡦࠣࡴࡴࡹࡴࠡࡶ࡫ࡩࠥࡲࡩ࡯࡭࠱ࠫय़")
    dixie.log(l11l11l_opy_)
    dixie.log(e)
def getPlaylist():
    import requests
    l11ll111l_opy_ = [l1111l_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡧࡰ࠴࡯࠲࡮ࡴ࡫࠰࡭ࡲࡨ࡮࠭ॠ"), l1111l_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡹ࠰ࡦࡳ࠴ࡪࡢࡤࡪ࠳࠵ࠬॡ"), l1111l_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࠴ࡣࡤ࡮ࡧ࠲࡮ࡵࠧॢ"), l1111l_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤ࡭ࡴ࠴ࡣࡤ࡮ࡲࡹࡩࡺࡶ࠯ࡱࡵ࡫࠴ࡱ࡯ࡥ࡫ࠪॣ")]
    l11l1ll1l_opy_ =  l1111l_opy_ (u"ࠪࠧࡊ࡞ࡔࡎ࠵ࡘࠫ।")
    for url in l11ll111l_opy_:
        dixie.log(url)
        try:
            request  = requests.get(url)
            l11lll11l_opy_ = request.text
        except: pass
        if l11l1ll1l_opy_ in l11lll11l_opy_:
            path = os.path.join(dixie.PROFILE, l1111l_opy_ (u"ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠴࡭࠴ࡷࠪ॥"))
            with open(path, l1111l_opy_ (u"ࠬࡽࠧ०")) as f:
                f.write(l11lll11l_opy_)
                break
    import urllib
    l11lll111_opy_ = os.path.join(PATH, l1111l_opy_ (u"࠭ࡴࡦ࡯ࡳ࡭ࡳ࡯ࠧ१"))
    l11ll11l1_opy_  = os.path.join(PATH, l1111l_opy_ (u"ࠧࡪࡰ࡬࠶࠳࡯࡮ࡪࠩ२"))
    l11ll111l_opy_  = l1111l_opy_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡹࡧࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳ࠯ࡓࡧࡱࡩ࡬ࡧࡤࡦࡵࡗ࡚࠴ࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡵࡩࡳ࡫ࡧࡢࡦࡨࡷࡹࡼ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡢࡦࡧࡳࡳࡹ࠲࠯࡫ࡱ࡭ࠬ३")
    urllib.urlretrieve(l11ll111l_opy_, l11lll111_opy_)
    temp = open(l11lll111_opy_)
    l11lll1ll_opy_  = open(l11ll11l1_opy_, l1111l_opy_ (u"ࠩࡺࡸࠬ४"))
    for line in temp:
        l11lll1ll_opy_.write(line.replace(
                               l1111l_opy_ (u"ࠪ࡟ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡨࡪࡾ࡝ࠨ५"), l1111l_opy_ (u"ࠫࡠࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡾࡸ࡞ࠩ६"))
                               .replace(l1111l_opy_ (u"ࠬࡡࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡌ࠮ࡕ࠰࡙ࡡࠬ७"), l1111l_opy_ (u"࡛࠭ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸࡹࡺࡠࠫ८"))
                               .replace(l1111l_opy_ (u"ࠧ࡜ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺࡡࠬ९"), l1111l_opy_ (u"ࠨ࡝ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡺࡻࡼࡢ࠭॰"))
                               .replace(l1111l_opy_ (u"ࠩ࡞ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡸࡻࡣࠧॱ"), l1111l_opy_ (u"ࠪ࡟ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡽࡾ࡝ࠨॲ"))
                               .replace(l1111l_opy_ (u"ࠫࡠࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡧࡨࡣࡪࡲ࡯ࡥࡾ࡫ࡲ࡞ࠩॳ"), l1111l_opy_ (u"ࠬࡡࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾࡸࡹ࡟ࠪॴ"))
                               .replace(l1111l_opy_ (u"࡛࠭ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡣࡢࡵࡷࡥࡼࡧࡹ࡞ࠩॵ"), l1111l_opy_ (u"ࠧ࡜ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡹࡺࡻࡡࠬॶ"))
                               .replace(l1111l_opy_ (u"ࠨ࡝ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡺ࡯ࡡࠬॷ"), l1111l_opy_ (u"ࠩ࡞ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡼࡽࡣࠧॸ"))
                               )
    temp.close()
    l11lll1ll_opy_.close()
    os.remove(l11lll111_opy_)