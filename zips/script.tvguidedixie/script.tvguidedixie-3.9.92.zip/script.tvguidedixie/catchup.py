# coding: UTF-8
import sys
l1lllll1_opy_ = sys.version_info [0] == 2
l1ll11l_opy_ = 2048
l111l1_opy_ = 7
def l11l1l_opy_ (ll_opy_):
	global l111_opy_
	l111l_opy_ = ord (ll_opy_ [-1])
	l111111_opy_ = ll_opy_ [:-1]
	l1lll_opy_ = l111l_opy_ % len (l111111_opy_)
	l1ll1_opy_ = l111111_opy_ [:l1lll_opy_] + l111111_opy_ [l1lll_opy_:]
	if l1lllll1_opy_:
		l1l1ll1_opy_ = unicode () .join ([unichr (ord (char) - l1ll11l_opy_ - (l1l111_opy_ + l111l_opy_) % l111l1_opy_) for l1l111_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1l1ll1_opy_ = str () .join ([chr (ord (char) - l1ll11l_opy_ - (l1l111_opy_ + l111l_opy_) % l111l1_opy_) for l1l111_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1l1ll1_opy_)
import xbmc
import xbmcgui
import xbmcaddon
import json
import datetime
import os
import dixie
import mapping
l111l11_opy_ = l11l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡊࡱࡧࡷ࡭ࡧࡶࡷ࡙ࡼࠧࠀ")
l1ll1l1_opy_  = l11l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡭ࡵࡲࡪࡼࡲࡲ࡮ࡶࡴࡷࠩࠁ")
l11_opy_  = l11l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡬ࡡࡣࡪࡲࡷࡹ࡯࡮ࡨࠩࠂ")
l1llll11_opy_     = l11l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡬ࡪࡷࡻ࠲ࡹࡼࠧࠃ")
l1l1l1l_opy_   = l11l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡶࡵࡩࡦࡳࡳࡦࡣࡶࡽ࠳ࡺࡶࠨࠄ")
l11llll_opy_ = l11l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡰࡥࡷࡺࡨࡶࡤࠪࠅ")
l11ll_opy_ = l11l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧ࠲ࠨࠆ")
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
def isValid(stream):
    dixie.log(l11l1l_opy_ (u"ࠫ࠲࠳࠭ࠡࡅ࡫ࡩࡨࡱࠠࡊࡕ࡚ࠣࡆࡒࡉࡅࠢࡶࡸࡷ࡫ࡡ࡮ࠢ࠰࠱࠲࠭ࠇ"))
    dixie.log(stream)
    if (l11l1l_opy_ (u"ࠬࡎࡏࡓࡋ࡝࠾ࠬࠈ") in stream) or (l11l1l_opy_ (u"࠭ࡨࡰࡴ࡬ࡾࡴࡴ࠭ࡪࡲࡷࡺࠬࠉ") in stream):
        dixie.log(l11l1l_opy_ (u"ࠧ࠮࠯࠰ࠤࡍࡕࡒࡊ࡜ࡒࡒ࡚ࠥࡒࡖࡇࠣ࠱࠲࠳ࠧࠊ"))
        return True
    if (l11l1l_opy_ (u"ࠨࡈࡏࡅ࠿࠭ࠋ") in stream) or (l11l1l_opy_ (u"ࠩࡩࡰࡦࡽ࡬ࡦࡵࡶ࠱࡮ࡶࡴࡷࠩࠌ") in stream):
        dixie.log(l11l1l_opy_ (u"ࠪ࠱࠲࠳ࠠࡇࡎࡄ࡛ࡑࡋࡓࡔࠢࡗࡖ࡚ࡋࠠ࠮࠯࠰ࠫࠍ"))
        return True
    if (l11l1l_opy_ (u"ࠫࡋࡇࡂ࠻ࠩࠎ") in stream) or (l11l1l_opy_ (u"ࠬࡹࡴࡳࡧࡤࡱ࠳࡬ࡡࡣ࡫ࡳࡸࡻ࠭ࠏ") in stream):
        dixie.log(l11l1l_opy_ (u"࠭࠭࠮࠯ࠣࡊࡆࡈࡉࡑࡖ࡙ࠤ࡙ࡘࡕࡆࠢ࠰࠱࠲࠭ࠐ"))
        return True
    if l11l1l_opy_ (u"ࠧࡉࡆࡗ࡚ࠬࠑ") in stream:
        dixie.log(l11l1l_opy_ (u"ࠨ࠯࠰࠱ࠥࡎࡄࡕࡘࠣࡘࡗ࡛ࡅࠡ࠯࠰࠱ࠬࠒ"))
        return True
    if l1llll11_opy_ in stream:
        dixie.log(l11l1l_opy_ (u"ࠩ࠰࠱࠲ࠦࡌࡊࡗ࡛ࠤ࡙ࡘࡕࡆࠢ࠰࠱࠲࠭ࠓ"))
        return True
    if l1l1l1l_opy_ in stream:
        dixie.log(l11l1l_opy_ (u"ࠪ࠱࠲࠳ࠠࡔࡖࡈࡅࡘ࡟ࠠࡕࡔࡘࡉࠥ࠳࠭࠮ࠩࠔ"))
        return True
    dixie.log(l11l1l_opy_ (u"ࠫ࠲࠳࠭ࠡࡘࡄࡐࡎࡊࠠࡇࡃࡏࡗࡊࠦ࠭࠮࠯ࠪࠕ"))
    return False
def getRecording(name, title, start, stream):
    if l11l1l_opy_ (u"ࠬࡎࡏࡓࡋ࡝࠾ࠬࠖ") in stream:
        dixie.log(l11l1l_opy_ (u"࠭࠭࠮࠯ࠣࡌࡔࡘࡉ࡛࠼ࠣ࡭ࡳࠦࡳࡵࡴࡨࡥࡲࠦ࠭࠮࠯ࠪࠗ"))
        return getIPTVRecording(name, title, start, stream)
    if l11l1l_opy_ (u"ࠧࡇࡎࡄ࠾ࠬ࠘") in stream:
        dixie.log(l11l1l_opy_ (u"ࠨ࠯࠰࠱ࠥࡌࡌࡂ࠼ࠣ࡭ࡳࠦࡳࡵࡴࡨࡥࡲࠦ࠭࠮࠯ࠪ࠙"))
        return getIPTVRecording(name, title, start, stream)
    if l11l1l_opy_ (u"ࠩࡉࡅࡇࡀࠧࠚ") in stream:
        dixie.log(l11l1l_opy_ (u"ࠪ࠱࠲࠳ࠠࡇࡃࡅ࠾ࠥ࡯࡮ࠡࡵࡷࡶࡪࡧ࡭ࠡ࠯࠰࠱ࠬࠛ"))
        return getIPTVRecording(name, title, start, stream)
    if l11l1l_opy_ (u"ࠫࡍࡊࡔࡗࠩࠜ") in stream:
        dixie.log(l11l1l_opy_ (u"ࠬ࠳࠭࠮ࠢࡋࡈ࡙࡜࠺ࠡ࡫ࡱࠤࡸࡺࡲࡦࡣࡰࠤ࠲࠳࠭ࠨࠝ"))
        return getHDTVRecording(name, title, start, stream)
    if l1llll11_opy_ in stream:
        dixie.log(l11l1l_opy_ (u"࠭࠭࠮࠯ࠣࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡯࡭ࡺࡾ࠮ࡵࡸࠣ࡭ࡳࠦࡳࡵࡴࡨࡥࡲࠦ࠭࠮࠯ࠪࠞ"))
        addon = l1llll11_opy_
        return l1ll_opy_(addon, name, title, start, stream)
    if l1l1l1l_opy_ in stream:
        dixie.log(l11l1l_opy_ (u"ࠧ࠮࠯࠰ࠤࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡹࡸࡥࡢ࡯ࡶࡩࡦࡹࡹ࠯ࡶࡹࠤ࡮ࡴࠠࡴࡶࡵࡩࡦࡳࠠ࠮࠯࠰ࠫࠟ"))
        addon = l1l1l1l_opy_
        return l1ll_opy_(addon, name, title, start, stream)
def getIPTVRecording(name, title, start, stream):
    dixie.log(l11l1l_opy_ (u"ࠨࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࠤࡈࡇࡔࡄࡊ࡙ࠣࡕࠦࡉࡑࡖ࡙ࠤࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࠨࠠ"))
    dixie.log(name)
    dixie.log(title)
    dixie.log(start)
    dixie.log(stream)
    import time
    l11l11l_opy_ = stream.split(l11l1l_opy_ (u"ࠩࡿࠫࠡ"))
    dixie.log(l11l11l_opy_)
    for url in l11l11l_opy_:
        url   = url.split(CLOSE_OTT)[1].rsplit(l11l1l_opy_ (u"ࠪ࠾ࠬࠢ"))
        l11l1_opy_ = url[0]
        dixie.log(url)
        addon = l1111_opy_(l11l1_opy_)
    l1l11l1_opy_ = -time.timezone
    dixie.log(l11l1l_opy_ (u"ࠫࡔࡌࡆࡔࡇࡗ࠾ࠥࠫࡳࠨࠣ") % l1l11l1_opy_)
    l1111l1_opy_  = start - datetime.timedelta(seconds=l1l11l1_opy_)
    dixie.log(l11l1l_opy_ (u"ࠬࡋࡐࡈࠢࡖࡸࡦࡸࡴࠡࡖ࡬ࡱࡪ࠴࠮࠯࠼ࠣࠩࡸ࠭ࠤ") % start)
    dixie.log(l11l1l_opy_ (u"࠭ࡅࡑࡉࠣࡗࡹࡧࡲࡵࠢࡗ࡭ࡲ࡫ࠠࡐࡈࡉࡗࡊ࡚࠺ࠡࠧࡶࠫࠥ") % l1111l1_opy_)
    l1llllll_opy_ = str(l1111l1_opy_)
    dixie.log(l11l1l_opy_ (u"ࠧࡵ࡫ࡰࡩࡸࡺࡲࡪࡰࡪ࠾ࠥࠫࡳࠨࠦ") % l1llllll_opy_)
    l1ll1l_opy_   = l1llllll_opy_.split(l11l1l_opy_ (u"ࠨࠢࠪࠧ"))[0]
    l11lll1_opy_  = l1llllll_opy_.split(l11l1l_opy_ (u"ࠩࠣࠫࠨ"))[1]
    l1l1_opy_  = time.strptime(l11lll1_opy_,  l11l1l_opy_ (u"ࠪࠩࡍࡀࠥࡎ࠼ࠨࡗࠬࠩ"))
    theTime    = time.strftime(l11l1l_opy_ (u"ࠫࠪࡎ࠺ࠦࡏࠪࠪ"),  l1l1_opy_)
    dixie.log(l11l1l_opy_ (u"ࠬࡏࡐࡕࡘࡶࡸࡦࡸࡴ࠻ࠢࠨࡷࠬࠫ") % theTime)
    l1ll11_opy_ = time.strptime(l1ll1l_opy_,   l11l1l_opy_ (u"࡚࠭ࠥ࠯ࠨࡱ࠲ࠫࡤࠨࠬ"))
    theDate    = time.strftime(l11l1l_opy_ (u"࡛ࠧࠦ࠰ࠩࡲ࠳ࠥࡥࠩ࠭"), l1ll11_opy_)
    dixie.log(l11l1l_opy_ (u"ࠨࡋࡓࡘ࡛ࡪࡴࡪࡶ࡯ࡩ࠿ࠦࠥࡴࠩ࠮") % theDate)
    return getCatchupLink(addon, name, title, theDate, theTime)
def l1111_opy_(l11l1_opy_):
    if l11l1_opy_ == l11l1l_opy_ (u"ࠩࡉࡅࡇ࠭࠯"):
        return l11_opy_
    if l11l1_opy_ == l11l1l_opy_ (u"ࠪࡊࡑࡇࠧ࠰"):
        return l111l11_opy_
    if l11l1_opy_ == l11l1l_opy_ (u"ࠫࡍࡕࡒࡊ࡜ࠪ࠱"):
        return l1ll1l1_opy_
def getCatchupLink(addon, channel, theShow, theDate, theTime):
    LABELFILE = l11111l_opy_(addon)
    labelmaps = json.load(open(LABELFILE))
    dixie.log(l11l1l_opy_ (u"ࠬࡃ࠽࠾࠿ࡀࡁࠥࡩࡡࡵࡥ࡫ࡹࡵ࠴ࡪࡴࡱࡱࠤࡂࡃ࠽࠾࠿ࡀࠫ࠲"))
    dixie.log(labelmaps)
    l11l1l1_opy_ = l11l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ࠳") + addon
    item   = l1111l_opy_(addon)
    try:
        l1llll_opy_  = findCatchup(l11l1l1_opy_, item)
        l1l1l_opy_  = mapping.mapLabel(labelmaps, channel)
        l1l1l_opy_  = l1l1l_opy_.upper()
        l11l_opy_   = findCatchup(l1llll_opy_, l1l1l_opy_)
        l11111_opy_ = theDate + l11l1l_opy_ (u"ࠧࠡ࠯ࠣࠫ࠴") + theTime
        l11111_opy_ = l11111_opy_.upper()
        l1lll1l_opy_      = findCatchup(l11l_opy_, l11111_opy_, splitlabel=True)
        dixie.DialogOK(l11l1l_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡱࡵࡥࡳ࡭ࡥ࡞࡝ࡅࡡࡈࡧࡴࡤࡪ࠰ࡹࡵࠦࡳࡵࡴࡨࡥࡲࠦࡦࡰࡷࡱࡨ࠳ࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࠵"), l11l1l_opy_ (u"ࠩࡒࡲ࠲࡚ࡡࡱࡲ࠱ࡘ࡛ࠦࡷࡪ࡮࡯ࠤࡳࡵࡷࠡࡲ࡯ࡥࡾࡀࠠ࡜ࡅࡒࡐࡔࡘࠠࡰࡴࡤࡲ࡬࡫࡝࡜ࡄࡠࠩࡸࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࠶") % (theShow))
        return l1lll1l_opy_
    except:
        return l11l1l_opy_ (u"ࠪࠫ࠷")
def l11111l_opy_(addon):
    dixie.log(l11l1l_opy_ (u"ࠫࡂࡃ࠽࠾࠿ࡀࠤ࡬࡫ࡴࡍࡣࡥࡩࡱࡌࡩ࡭ࡧࠣࡁࡂࡃ࠽࠾࠿ࠪ࠸"))
    dixie.log(addon)
    HOME  = dixie.PROFILE
    iPATH = os.path.join(HOME, l11l1l_opy_ (u"ࠬ࡯࡮ࡪࠩ࠹"))
    if addon == l11_opy_:
         return os.path.join(iPATH, l11l1l_opy_ (u"࠭ࡣࡢࡶࡦ࡬ࡺࡶࡆࡂࡄ࠱࡮ࡸࡵ࡮ࠨ࠺"))
    if (addon == l111l11_opy_) or (addon == l1ll1l1_opy_):
         return os.path.join(iPATH, l11l1l_opy_ (u"ࠧࡤࡣࡷࡧ࡭ࡻࡰࡇࡎࡄ࠲࡯ࡹ࡯࡯ࠩ࠻"))
def l1111l_opy_(addon):
    if addon == l11_opy_:
        return l11l1l_opy_ (u"ࠨࡈࡄࡆࠥࡏࡐࡕࡘࠣࡇࡆ࡚ࡃࡉࡗࡓࠫ࠼")
    if addon == l111l11_opy_:
        return l11l1l_opy_ (u"ࠩࡉࡐࡆ࡝ࡌࡆࡕࡖࠤࡈࡇࡔࡄࡊࡘࡔࠬ࠽")
    if addon == l1ll1l1_opy_:
        return l11l1l_opy_ (u"ࠪࡌࡔࡘࡉ࡛ࡑࡑࠤࡈࡇࡔࡄࡊࡘࡔࠬ࠾")
def findCatchup(query, item, splitlabel=False):
    response = doJSON(query)
    l1llll1_opy_    = response[l11l1l_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫ࠿")][l11l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫࡀ")]
    for file in l1llll1_opy_:
        l1l111l_opy_ = file[l11l1l_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬࡁ")]
        l111ll_opy_   = mapping.cleanLabel(l1l111l_opy_)
        l1l1l1_opy_    = cleanPrefix(l111ll_opy_)
        if splitlabel:
            l1l1l1_opy_ = l1l1l1_opy_.upper()
            l1l1l1_opy_ = l1l1l1_opy_.rsplit(l11l1l_opy_ (u"ࠧࠡ࠯ࠣࠫࡂ"), 1)[0]
        else:
            l1l1l1_opy_ = l1l1l1_opy_.upper()
        if l1l1l1_opy_ == item.upper():
            return file[l11l1l_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ࡃ")]
def doJSON(query):
    l11ll11_opy_  = (l11l1l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬࡄ") % query)
    response = xbmc.executeJSONRPC(l11ll11_opy_)
    content  = json.loads(response)
    return content
def cleanPrefix(text):
    l1111ll_opy_ = text.strip()
    l1l11l_opy_  = [l11l1l_opy_ (u"࡙ࠪࡐࡀࠧࡅ"), l11l1l_opy_ (u"ࠫࡎࡔࡔ࠻ࠢࠪࡆ"), l11l1l_opy_ (u"ࠬࡒࡉࡗࡇࠣࠫࡇ"), l11l1l_opy_ (u"࠭ࡕࡌࠢ࡯ࠤࠬࡈ"), l11l1l_opy_ (u"ࠧࡊࡐࠣࡰࠥ࠭ࡉ"), l11l1l_opy_ (u"ࠨࡋࡑࠤࢁࠦࠧࡊ"), l11l1l_opy_ (u"ࠩࡇࡉࠥࡲࠠࠨࡋ"), l11l1l_opy_ (u"ࠪࡖࡆࡊࠠ࡭ࠢࠪࡌ"), l11l1l_opy_ (u"࡛ࠫࡏࡐࠡ࡮ࠣࠫࡍ"), l11l1l_opy_ (u"ࠬࠦࡌࡰࡥࡤࡰࠬࡎ"), l11l1l_opy_ (u"࠭ࡕࡔࡃ࠲ࡇࡆࠦ࠺ࠡࠩࡏ"), l11l1l_opy_ (u"ࠧࡖࡕࡄ࠳ࡈࡇ࠺ࠡࠩࡐ"), l11l1l_opy_ (u"ࠨࡅࡄ࠾ࠥ࠭ࡑ"),l11l1l_opy_ (u"ࠩࡆࡅࠥࡀࠠࠨࡒ"),l11l1l_opy_ (u"ࠪࡇࡆࠦࠧࡓ"),l11l1l_opy_ (u"࡚ࠫࡑࠠࡗࡋࡓࠤ࠿ࠦࠧࡔ"), l11l1l_opy_ (u"࡛ࠬࡋࠡ࠼ࠣࠫࡕ"), l11l1l_opy_ (u"࠭ࡕࡌ࠼ࠣࠫࡖ"), l11l1l_opy_ (u"ࠧࡖࡍࠣࢀࠥ࠭ࡗ"), l11l1l_opy_ (u"ࠨࡗࡖࡅࠥࡀࠠࡍࡋ࡙ࡉࠥ࠭ࡘ"), l11l1l_opy_ (u"ࠩࡘࡗࡆࠦࡼࠡࡎࡌ࡚ࡊ࡙ࠦࠧ"), l11l1l_opy_ (u"࡙ࠪࡘࡇࠠ࠻࡚ࠢࠪ"), l11l1l_opy_ (u"࡚࡙ࠫࡁࠡ࠼࡛ࠪ"), l11l1l_opy_ (u"࡛ࠬࡓࡂ࠼ࠣࠫ࡜"), l11l1l_opy_ (u"࠭ࡕࡔࡃࠣࢀࠥ࠭࡝"), l11l1l_opy_ (u"ࠧࡖࡕࡄࠤࠬ࡞"), l11l1l_opy_ (u"ࠨࡗࡖࠤࢁࠦࠧ࡟"),l11l1l_opy_ (u"ࠩࡘࡗ࠿ࠦࠧࡠ"), l11l1l_opy_ (u"ࠪࡒࡔࡘࡄࡊࡅࠣࠫࡡ")]
    for prefix in l1l11l_opy_:
        if prefix in l1111ll_opy_:
            l1111ll_opy_ = l1111ll_opy_.replace(prefix, l11l1l_opy_ (u"ࠫࠬࡢ"))
    return l1111ll_opy_.strip()
def l1ll_opy_(addon, name, title, start, stream):
    import time
    dixie.log(l11l1l_opy_ (u"ࠬࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࠡࡅࡄࡘࡈࡎࠠࡖࡒࠣࡐ࡝࡚ࡖࠡࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࠬࡣ"))
    l11l11l_opy_ = stream.split(l11l1l_opy_ (u"࠭ࡼࠨࡤ"))
    for url in l11l11l_opy_:
        if (l1l1l1l_opy_ in url) or (l1llll11_opy_ in url):
            dixie.log(l11l1l_opy_ (u"ࠧࡍ࡚ࡗ࡚࡛ࠥࡒࡍ࠰࠱࠲࠿ࠦࠥࡴࠩࡥ") % url)
            l1lllll_opy_ = url.split(CLOSE_OTT)[0].replace(OPEN_OTT, l11l1l_opy_ (u"ࠨࠩࡦ"))
            break
    import urllib
    l1l11l1_opy_ = l1ll1ll_opy_()
    dixie.log(l11l1l_opy_ (u"ࠩࡈࡔࡌࠦࡓࡵࡣࡵࡸ࡚ࠥࡩ࡮ࡧ࠱࠲࠳ࡀࠠࠦࡵࠪࡧ") % start)
    dixie.log(l11l1l_opy_ (u"ࠪࡓ࡫࡬ࡳࡦࡶࠣ࡭ࡳࠦࡳࡦࡥࡲࡲࡩࡹ࠺ࠡࠧࡶࠫࡨ") % l1l11l1_opy_)
    l1111l1_opy_  =  start - datetime.timedelta(seconds=l1l11l1_opy_)
    dixie.log(l11l1l_opy_ (u"ࠫࡘࡺࡡࡳࡶࠣࡘ࡮ࡳࡥࠡࡱࡩࡪࡸ࡫ࡴ࠻ࠢࠨࡷࠬࡩ") % l1111l1_opy_)
    l1ll111_opy_     = l1lll1_opy_(l1lllll_opy_)
    l1llllll_opy_ = str(l1111l1_opy_)
    l11l111_opy_   = l1llllll_opy_.split(l11l1l_opy_ (u"ࠬࠦࠧࡪ"))[0]
    l11lll1_opy_  = l1llllll_opy_.split(l11l1l_opy_ (u"࠭ࠠࠨ࡫"))[1]
    l11l11_opy_  = time.strptime(l11lll1_opy_,  l11l1l_opy_ (u"ࠧࠦࡊ࠽ࠩࡒࡀࠥࡔࠩ࡬"))
    l11l11_opy_  = time.strftime(l11l1l_opy_ (u"ࠨࠧࡌ࠾ࠪࡓࠠࠦࡲࠪ࡭"),  l11l11_opy_)
    l11l1ll_opy_ = time.strptime(l11l111_opy_,   l11l1l_opy_ (u"ࠩࠨ࡝࠲ࠫ࡭࠮ࠧࡧࠫ࡮"))
    l11l1ll_opy_ = time.strftime(l11l1l_opy_ (u"ࠪࠩࡆ࠲ࠠࠦࡄࠣࠩࡩ࠭࡯"), l11l1ll_opy_)
    query = l11l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴ࠱ࡂࡧ࡭ࡧ࡮࡯ࡧ࡯ࡣ࡮ࡪ࠽ࠦࡵࠩࡨࡦࡺࡥ࠾ࠧࡶࠪࡩࡧࡴࡦࡡࡷ࡭ࡹࡲࡥ࠾ࠧࡶࠪ࡮ࡳࡧ࠾ࠨࡰࡳࡩ࡫࠽ࡳࡧࡦࡳࡷࡪࡩ࡯ࡩࡶࠪࡹ࡯ࡴ࡭ࡧࡀࠩࡸ࠭ࡰ") % (addon, l1ll111_opy_, l11l111_opy_, l11l1ll_opy_, l1lllll_opy_)
    l11lll_opy_  = l11l1l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࠦࡵࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨࡱ") % query
    if not l1ll111_opy_:
        dixie.DialogOK(l11l1l_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠳࠭ࡲ"), l11l1l_opy_ (u"ࠧࡘࡧࠣࡧࡴࡻ࡬ࡥࠢࡱࡳࡹࠦࡦࡪࡰࡧࠤࡦࠦࡣࡢࡶࡦ࡬ࡺࡶࠠࡴࡧࡵࡺ࡮ࡩࡥࠡࡨࡲࡶࠥࡺࡨࡪࡵࠣࡧ࡭ࡧ࡮࡯ࡧ࡯࠲ࠬࡳ"), l11l1l_opy_ (u"ࠨࡔࡨࡺࡪࡸࡴࡪࡰࡪࠤࡧࡧࡣ࡬ࠢࡷࡳࠥࡒࡩࡷࡧࠣࡘ࡛࠴ࠧࡴ"))
        return None
    l1l1lll_opy_    = xbmc.executeJSONRPC(l11lll_opy_)
    response   = json.loads(l1l1lll_opy_)
    result     = response[l11l1l_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩࡵ")]
    l1l1l11_opy_ = result[l11l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩࡶ")]
    for l111l1l_opy_ in l1l1l11_opy_:
        try:
            l11ll1_opy_ = l111l1l_opy_[l11l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࠩࡷ")]
            l1l1l1_opy_   = l111l1l_opy_[l11l1l_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫࡸ")]
            if l11l11_opy_ in l1l1l1_opy_:
                dixie.DialogOK(l11l1l_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡯ࡳࡣࡱ࡫ࡪࡣࡃࡢࡶࡦ࡬࠲ࡻࡰࠡࡵࡷࡶࡪࡧ࡭ࠡࡨࡲࡹࡳࡪ࠮࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࡹ"), l11l1l_opy_ (u"ࠧࡐࡰ࠰ࡘࡦࡶࡰ࠯ࡖ࡙ࠤࡼ࡯࡬࡭ࠢࡱࡳࡼࠦࡰ࡭ࡣࡼ࠾ࠥࡡࡃࡐࡎࡒࡖࠥࡵࡲࡢࡰࡪࡩࡢࡡࡂ࡞ࠧࡶ࡟࠴ࡈ࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࡺ") % (title))
                return l11ll1_opy_
        except Exception, e:
            dixie.log(l11l1l_opy_ (u"ࠨࡇࡕࡖࡔࡘ࠺ࠡࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤࡹ࡮ࡲࡰࡹࡱࠤ࡮ࡴࠠࡨࡧࡷࡐ࡝࡚ࡖࡓࡧࡦࡳࡷࡪࡩ࡯ࡩࠣࠩࡸ࠭ࡻ") % str(e))
            dixie.DialogOK(l11l1l_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠯ࠩࡼ"), l11l1l_opy_ (u"࡛ࠪࡪࠦࡣࡰࡷ࡯ࡨࠥࡴ࡯ࡵࠢࡩ࡭ࡳࡪࠠࡢࠢࡦࡥࡹࡩࡨࡶࡲࠣࡷࡹࡸࡥࡢ࡯ࠣࡪࡴࡸࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲ࠴ࠧࡽ"), l11l1l_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡹࡸࡹࠡࡣࡪࡥ࡮ࡴࠠ࡭ࡣࡷࡩࡷ࠴ࠧࡾ"))
            return None
def l1lll1_opy_(l1lllll_opy_):
    l1lllll_opy_ = l1lllll_opy_.upper()
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠬ࠹ࡅࠨࡿ") : return 188
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡁࡃࡅࠣࡉࡆ࡙ࡔࠨࢀ") : return 363
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡂࡄࡆࠫࢁ") : return 346
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡃࡐࡇࠬࢂ") : return 375
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡄࡐࡎࡈࡉࠡࡋࡕࡉࡑࡇࡎࡅࠩࢃ") : return 280
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪࡅࡓࡏࡍࡂࡎࠣࡔࡑࡇࡎࡆࡖ࡙ࠣࡘࡇࠧࢄ") : return 386
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠫࡆࡔࡉࡎࡃࡏࠤࡕࡒࡁࡏࡇࡗࠫࢅ") : return 19
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠬࡇࡒࡆࡐࡄࠤࡘࡖࡏࡓࡖࡖࠤ࠶ࠦࡈࡅࠢࡆࡖࡔࡇࡔࡊࡃࠪࢆ") : return 403
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡁࡓࡇࡑࡅ࡙ࠥࡐࡐࡔࡗࡗࠥ࠸ࠠࡉࡆࠣࡇࡗࡕࡁࡕࡋࡄࠫࢇ") : return 404
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡂࡔࡈࡒࡆࠦࡓࡑࡑࡕࡘࡘࠦ࠳ࠡࡊࡇࠤࡈࡘࡏࡂࡖࡌࡅࠬ࢈") : return 405
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡃࡕࡉࡓࡇࠠࡔࡒࡒࡖ࡙࡙ࠠ࠵ࠢࡋࡈࠥࡉࡒࡐࡃࡗࡍࡆ࠭ࢉ") : return 406
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡄࡖࡊࡔࡁࠡࡕࡓࡓࡗ࡚ࡓࠡ࠷ࠣࡗࡗࡈࠧࢊ") : return 407
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪࡅ࡙ࠦࡔࡉࡇࠣࡖࡆࡉࡅࡔࠩࢋ") : return 273
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠫࡇࡈࡃࠡࡑࡑࡉࡠࡎࡄ࡞ࠩࢌ") : return 210
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠬࡈࡂࡄࠢࡗ࡛ࡔࡡࡈࡅ࡟ࠪࢍ") : return 211
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡂࡆࡋࡑࠤࡘࡖࡏࡓࡖࠣ࠵࠵ࠦࡈࡅࠪࡗࡉࡘ࡚ࠩࠨࢎ") : return 300
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡃࡇࡌࡒ࡙ࠥࡐࡐࡔࡗࠤ࠶࠷ࠠࡉࡆࠫࡘࡊ࡙ࡔࠪࠩ࢏") : return 389
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡄࡈࡍࡓࠦࡓࡑࡑࡕࡘࠥ࠷ࡈࡅࠪࡗࡉࡘ࡚ࠩࠨ࢐") : return 285
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡅࡉࡎࡔࠠࡔࡒࡒࡖ࡙ࠦ࠲ࠡࡊࡇ࡙ࠬࡋࡓࡕࠫࠪ࢑") : return 286
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪࡆࡊࡏࡎࠡࡕࡓࡓࡗ࡚ࠠ࠴ࠢࡋࡈ࡚࠭ࡅࡔࡖࠬࠫ࢒") : return 287
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠫࡇࡋࡉࡏࠢࡖࡔࡔࡘࡔࠡ࠶ࠣࡌࡉ࠮ࡔࡆࡕࡗ࠭ࠬ࢓") : return 288
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠬࡈࡅࡊࡐࠣࡗࡕࡕࡒࡕࠢ࠸ࠤࡍࡊࠨࡕࡇࡖࡘ࠮࠭࢔") : return 289
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡂࡆࡋࡑࠤࡘࡖࡏࡓࡖࠣ࠺ࠥࡎࡄࠩࡖࡈࡗ࡙࠯ࠧ࢕") : return 290
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡃࡇࡌࡒ࡙ࠥࡐࡐࡔࡗࠤ࠼ࠦࡈࡅࠪࡗࡉࡘ࡚ࠩࠨ࢖") : return 291
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡄࡈࡍࡓࠦࡓࡑࡑࡕࡘࠥ࠾ࠠࡉࡆࠫࡘࡊ࡙ࡔࠪࠩࢗ") : return 292
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡅࡉࡎࡔࠠࡔࡒࡒࡖ࡙ࠦ࠹ࠡࡊࡇ࡙ࠬࡋࡓࡕࠫࠪ࢘") : return 293
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪࡆ࡙ࠦࡓࡑࡑࡕࡘࠥ࠷ࠠࡉࡆ࡙ࠣࠬࡋࡓࡕ࢙ࠫࠪ") : return 306
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠫࡇ࡚ࠠࡔࡒࡒࡖ࡙ࠦ࠱ࠨ࢚") : return 17
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠬࡈࡔࠡࡕࡓࡓࡗ࡚ࠠ࠳ࠢࡋࡈࠥ࠮ࡔࡆࡕࡗ࢛࠭ࠬ") : return 307
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡂࡕࠢࡖࡔࡔࡘࡔࠡ࠴ࠪ࢜") : return 18
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡃࡖࠣࡗࡕࡕࡒࡕࠢࡈࡗࡕࡔࠧ࢝") : return 24
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡄࡗࠤࡘࡖࡏࡓࡖࠣࡉ࡚ࡘࡏࡑࡇࠪ࢞") : return 216
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡅࡅࡇ࡟ࠠࡕࡘࠪ࢟") : return 299
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪࡆࡑ࡛ࡅࠡࡊࡘࡗ࡙ࡒࡅࡓࠢࡈ࡙ࡗࡕࡐࡆࠩࢠ") : return 241
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠫࡇࡕࡏࡎࡇࡕࡅࡓࡍࠧࢡ") : return 192
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠬࡈࡏ࡙ࠢࡑࡅ࡙ࡏࡏࡏࠩࢢ") : return 185
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡂࡓࡋࡗࡍࡘࡎࠠࡆࡗࡕࡓࡘࡖࡏࡓࡖ࠵ࠫࢣ") : return 173
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡃࡔࡌࡘࡎ࡙ࡈࠡࡇࡘࡖࡔ࡙ࡐࡐࡔࡗࠫࢤ") : return 182
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡅࡅࡗࠥࡘࡅࡂࡎࡌࡘ࡞࠭ࢥ") : return 190
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡆࡒࡇࡉࠧࢦ") : return 366
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪࡇࡓࡔࠧࢧ") : return 365
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠫࡈࡇࡒࡕࡑࡒࡒࠥࡔࡅࡕ࡙ࡒࡖࡐࠦࡕࡌࠩࢨ") : return 186
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠬࡉࡁࡓࡖࡒࡓࡓࡏࡔࡐࠩࢩ") : return 250
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡃࡉࡇࡏࡗࡊࡇࠠࡕࡘࠪࢪ") : return 179
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡄࡑࡐࡉࡉ࡟ࠠࡄࡇࡑࡘࡗࡇࡌࠡࡗࡖࡅࠬࢫ") : return 374
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡅࡒࡑࡊࡊ࡙ࠡࡅࡈࡒ࡙ࡘࡁࡍࠩࢬ") : return 251
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡆࡓࡒࡋࡄ࡚࡛ࠢࡘࡗࡇࠧࢭ") : return 176
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪࡇࡗࡏࡍࡆࠢࡌࡒ࡛ࡋࡓࡕࡋࡊࡅ࡙ࡏࡏࡏࠩࢮ") : return 249
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠫࡉࡇࡖࡆࠩࢯ") : return 230
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠬࡊࡉࡔࡅࡒ࡚ࡊࡘ࡙ࠡࡊࡌࡗ࡙ࡕࡒ࡚ࠩࢰ") : return 20
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡄࡊࡕࡆࡓ࡛ࡋࡒ࡚ࠢࡖࡇࡎࡋࡎࡄࡇࠪࢱ") : return 103
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡅࡋࡖࡇࡔ࡜ࡅࡓ࡛ࠣࡘ࡚ࡘࡂࡐࠩࢲ") : return 102
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡆࡌࡗࡈࡕࡖࡆࡔ࡜࠵ࠬࢳ") : return 98
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡇࡍࡘࡉࡏࡗࡇࡕ࡝ࠬࢴ") : return 370
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪࡈࡎ࡙ࡎࡆ࡛ࡆࡌࡓࡒࠧࢵ") : return 117
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠫࡉࡏࡓࡏࡇ࡜ࡎ࡚ࡔࡉࡐࡔࠪࢶ") : return 118
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠬࡋࡓࡑࡐࠣ࠶ࠬࢷ") : return 349
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡅࡔࡒࡑࠫࢸ") : return 348
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡆࡆࡈࡒࠥ࠱࠱ࠨࢹ") : return 278
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡇࡌࡖ࡙ࠥࡐࡐࡔࡗࡗࠬࢺ") : return 30
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡈ࡙ࡗࡕࡎࡆ࡙ࡖࠫࢻ") : return 398
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪࡊࡔ࡞ࠠࡔࡒࡒࡖ࡙࡙ࠠ࠲ࠩࢼ") : return 352
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠫࡋࡕࡘࠡࡐࡈ࡛ࡘ࠭ࢽ") : return 274
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠬࡍࡏࡍࡆ࡙ࠣࡐ࠭ࢾ") : return 277
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡈ࠳ࠢࡘࡏࠬࢿ") : return 271
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡉࡄࡒࠤࡊࡇࡓࡕࠩࣀ") : return 376
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡊࡅࡓࠥࡌࡁࡎࡋࡏ࡝ࠬࣁ") : return 377
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡋࡆࡔࠦࡓࡊࡉࡑࡅ࡙࡛ࡒࡆࠩࣂ") : return 378
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪࡌࡇࡕ࡛ࠠࡑࡑࡉࠬࣃ") : return 379
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠫࡍࡍࡔࡗࠩࣄ") : return 384
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠬࡎࡉࡔࡖࡒࡖ࡞ࠦࡕࡌࠩࣅ") : return 268
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡈࡊࡕࡗࡓࡗ࡟ࠠࡖࡕࡄࠫࣆ") : return 369
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡉࡑࡐࡉࠥ࠱࠱ࠨࣇ") : return 279
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡊࡒࡖࡗࡕࡒࠡࡅࡋࡅࡓࡔࡅࡍࠢࡘࡏࠬࣈ") : return 183
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡌࡈ࡛ࠥࡋࠨࣉ") : return 229
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪࡍ࡙࡜ࠠ࠳ࠩ࣊") : return 208
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠫࡎ࡚ࡖࠡ࠵ࠪ࣋") : return 207
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠬࡏࡔࡗࠢ࠷ࠫ࣌") : return 209
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡉࡕࡘࠪ࣍") : return 206
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡍࡈࡆࠤ࡙࡜ࠧ࣎") : return 180
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡏࡌࡓ࡙ࠥࡔࡂࡆࡌ࡙ࡒࠦ࠱࠱࠴ࠣࡌࡉ࣏࠭") : return 334
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡐࡍࡔࠦࡓࡕࡃࡇࡍ࡚ࡓࠠ࠲࠲࠶ࠤࡍࡊ࣐ࠧ") : return 335
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪࡑࡎࡕࠠࡔࡖࡄࡈࡎ࡛ࡍࠡ࠳࠳࠸ࠥࡎࡄࠨ࣑") : return 336
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠫࡒࡏࡏࠡࡕࡗࡅࡉࡏࡕࡎࠢ࠴࠴࠺ࠦࡈࡅ࣒ࠩ") : return 337
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠬࡓࡉࡐࠢࡖࡘࡆࡊࡉࡖࡏࠣ࠵࠵࠼ࠠࡉࡆ࣓ࠪ") : return 338
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡍࡊࡑࠣࡗ࡙ࡇࡄࡊࡗࡐࠤ࠶࠶࠷ࠡࡊࡇࠫࣔ") : return 333
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡎࡖ࡙ࠤࡇࡇࡓࡆࠩࣕ") : return 132
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡏࡗ࡚ࠥࡊࡁࡏࡅࡈࠫࣖ") : return 131
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡐࡘ࡛ࠦࡈࡊࡖࡖࠥࠬࣗ") : return 135
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪࡑ࡙࡜ࠠࡎࡗࡖࡍࡈ࠭ࣘ") : return 217
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠫࡒ࡚ࡖࠡࡔࡒࡇࡐ࡙ࠧࣙ") : return 133
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠬࡓࡕࡕࡘࠪࣚ") : return 106
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡍࡐࡖࡒࡖࡘࠦࡕࡌࠩࣛ") : return 215
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡏࡄࡄࠫࣜ") : return 283
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡐࡅࡇࠥࡋࡁࡔࡖࠪࣝ") : return 361
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡑࡍࡈࡑࠠࡕࡑࡒࡒࡘ࠭ࣞ") : return 296
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪࡒࡆ࡚ࠠࡈࡇࡒࠤ࡜ࡏࡌࡅࠢࡘࡏࠬࣟ") : return 269
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠫࡓࡇࡔࡊࡑࡑࡅࡑࠦࡇࡆࡑࡊࡖࡆࡖࡈࡊࡅ࡙ࠣࡐ࠭࣠") : return 270
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠬࡔࡁࡕࡋࡒࡒࡆࡒࠠࡈࡇࡒࡋࡗࡇࡐࡉࡋࡆࠤ࡚࡙ࡁࠨ࣡") : return 371
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡎࡊࡅࡎࠤࡏ࡛ࡎࡊࡑࡕࠫ࣢") : return 297
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡏࡋࡆࡏ࡛ࠥࡋࠨࣣ") : return 295
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡒࡕࡉࡒࡏࡅࡓࡕࡓࡓࡗ࡚ࡓࠨࣤ") : return 29
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡕࡘࡊࠦࡏࡏࡇࠪࣥ") : return 69
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪࡖ࡙ࡋࠠࡕ࡙ࡒ࡟ࡍࡊ࡝ࠨࣦ") : return 70
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠫࡗ࡚ࡅࡋࡔࠪࣧ") : return 89
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠬࡘࡁࡄࡋࡑࡋ࡛ࠥࡋࠨࣨ") : return 26
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡒࡆࡃࡏࠤࡑࡏࡖࡆࡕࣩࠪ") : return 275
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡔࡍ࡜ࠤࡇ࡛ࡎࡅࡇࡖࡐࡎࡍࡁࠡ࠳ࠣࡌࡉࡡࡄࡆ࡟ࠪ࣪") : return 408
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡕࡎ࡝ࠥࡔࡅࡘࡕࠪ࣫") : return 263
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡖࡏ࡞ࠦ࠱ࠨ࣬") : return 177
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪࡗࡐ࡟ࠠ࠳࣭ࠩ") : return 178
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠫࡘࡑ࡙ࠡࡃࡆࡘࡎࡕࡎࠡࡏࡒ࡚ࡎࡋࡓࠨ࣮") : return 16
    if l1lllll_opy_ == l11l1l_opy_ (u"࡙ࠬࡋ࡚ࠢࡄࡘࡑࡇࡎࡕࡋࡆ࣯ࠫ") : return 174
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡓࡌ࡛ࠣࡇࡔࡓࡅࡅ࡛ࠣࡑࡔ࡜ࡉࡆࡕࣰࠪ") : return 34
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡔࡍ࡜ࠤࡉࡘࡁࡎࡃࡕࡓࡒࠦࡍࡐࡘࡌࡉࡘࣱ࠭") : return 97
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡕࡎ࡝ࠥࡌࡁࡎࡋࡏ࡝ࠥࡓࡏࡗࡋࡈࡗࣲࠬ") : return 36
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡖࡏ࡞ࠦࡇࡓࡇࡄࡘࡘࠦࡍࡐࡘࡌࡉࡘ࠭ࣳ") : return 37
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪࡗࡐ࡟ࠠࡎࡑ࡙ࡍࡊ࡙ࠠࡅࡋࡖࡒࡊ࡟ࠧࣴ") : return 220
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠫࡘࡑ࡙ࠡࡒࡕࡉࡒࡏࡅࡓࡇࠣࡑࡔ࡜ࡉࡆࡕࠪࣵ") : return 40
    if l1lllll_opy_ == l11l1l_opy_ (u"࡙ࠬࡋ࡚ࠢࡖࡇࡋࡏࡈࡐࡔࡕࡓࡗࠦࡍࡐࡘࡌࡉࡘࣶ࠭") : return 41
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡓࡌ࡛ࠣࡗࡊࡒࡅࡄࡖࠣࡑࡔ࡜ࡉࡆࡕࠪࣷ") : return 42
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡔࡍ࡜ࠤࡘࡖࠠࡏࡇ࡚ࡗࠥࡎࡑࠨࣸ") : return 175
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡕࡎ࡝࡙ࠥࡐࡐࡔࡗࠤ࠶ࠦࡈࡅࠢࠫࡘࡊ࡙ࡔࣹࠪࠩ") : return 301
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡖࡏ࡞ࠦࡓࡑࡑࡕࡘࠥ࠸ࠠࡉࡆ࡙ࠣࠬࡋࡓࡕࣺࠫࠪ") : return 302
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪࡗࡐ࡟ࠠࡔࡒࡒࡖ࡙ࠦ࠳ࠡࡊࡇࠤ࡚࠭ࡅࡔࡖࠬࠫࣻ") : return 303
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠫࡘࡑ࡙ࠡࡕࡓࡓࡗ࡚ࠠ࠵ࠢࡋࡈࠥ࠮ࡔࡆࡕࡗ࠭ࠬࣼ") : return 304
    if l1lllll_opy_ == l11l1l_opy_ (u"࡙ࠬࡋ࡚ࠢࡖࡔࡔࡘࡔࠡ࠷ࠣࡌࡉࠦࠨࡕࡇࡖࡘ࠮࠭ࣽ") : return 305
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡓࡌ࡛ࠣࡗࡕࡕࡒࡕࡕࠣ࠵ࠬࣾ") : return 95
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡔࡍ࡜ࠤࡘࡖࡏࡓࡖࡖࠤ࠷࠭ࣿ") : return 136
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡕࡎ࡝࡙ࠥࡐࡐࡔࡗࡗࠥ࠹ࠧऀ") : return 43
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡖࡏ࡞ࠦࡓࡑࡑࡕࡘࡘࠦ࠴ࠨँ") : return 119
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪࡗࡐ࡟ࠠࡔࡒࡒࡖ࡙࡙ࠠ࠶ࠩं") : return 120
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠫࡘࡑ࡙ࠡࡖࡋࡖࡎࡒࡌࡆࡔࠣࡑࡔ࡜ࡉࡆࡕࠪः") : return 96
    if l1lllll_opy_ == l11l1l_opy_ (u"࡙ࠬࡋ࡚ࠢࡏࡍ࡛ࡏࡎࡈࠩऄ") : return 298
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡓࡑࡑࡕࡘࡘࠦࡆ࠲ࠩअ") : return 45
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡔ࡛ࡉ࡝࡛ࠥࡓࡂࠩआ") : return 383
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡖࡆࡑࠥ࠱࠱ࠡࡗࡎࠫइ") : return 189
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡗࡋ࠹࠭ई") : return 88
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪࡘࡘࡔࠠ࠲ࠩउ") : return 339
    if l1lllll_opy_ == l11l1l_opy_ (u"࡙࡙ࠫࡎࠡ࠴ࠪऊ") : return 340
    if l1lllll_opy_ == l11l1l_opy_ (u"࡚ࠬࡓࡏࠢ࠶ࠫऋ") : return 341
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡔࡔࡐࠣ࠸ࠬऌ") : return 342
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡕࡕࡑࠤ࠺࠭ऍ") : return 343
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡖ࡙࠷ࠥࡏࡅࠨऎ") : return 87
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠩࡗࡖࡆ࡜ࡅࡍࠢࡆࡌࡆࡔࡎࡆࡎ࠮࠵࡛ࠥࡋࠨए") : return 184
    if l1lllll_opy_ == l11l1l_opy_ (u"࡙ࠪࡘࡇࠠࡇࡑ࡛ࠤࡘࡖࡏࡓࡖࡖࠫऐ") : return 347
    if l1lllll_opy_ == l11l1l_opy_ (u"࡚࡙ࠫࡁࠡࡐࡈࡘ࡜ࡕࡒࡌࠩऑ") : return 344
    if l1lllll_opy_ == l11l1l_opy_ (u"࡛ࠬࡔࡗࠢࡌࡉࠬऒ") : return 272
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡖࡊࡘࡄࠤ࡙ࡎࡅࠡࡊࡌࡘࡘࠧࠧओ") : return 130
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠧࡗࡋࡄࡗࡆ࡚ࠠࡈࡑࡏࡊࠬऔ") : return 125
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨ࡙ࡄࡘࡈࡎࠠࡊࡔࡈࡐࡆࡔࡄࠨक") : return 281
    if l1lllll_opy_ == l11l1l_opy_ (u"࡛ࠩ࡜࡝࠷ࠧख") : return 314
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠪ࡜࡝࡞࠲ࠨग") : return 315
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠫ࡝࡞ࡘ࠴ࠩघ") : return 316
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠬ࡞ࡘ࡙࠶ࠪङ") : return 317
    if l1lllll_opy_ == l11l1l_opy_ (u"࠭ࡘ࡙࡚࠸ࠫच") : return 318
    if l1lllll_opy_ == l11l1l_opy_ (u"࡚ࠧࡇࡖࡘࡊࡘࡄࡂ࡛ࠣ࠯࠶࠭छ") : return 282
    if l1lllll_opy_ == l11l1l_opy_ (u"ࠨࡏࡒ࡚࠹ࡓࡅࡏ࠳ࠪज") : return 33
def getHDTVRecording(name, title, start, stream):
    l11l11l_opy_ = stream.split(l11l1l_opy_ (u"ࠩࡿࠫझ"))
    for url in l11l11l_opy_:
        url   = url.split(CLOSE_OTT)[1].rsplit(l11l1l_opy_ (u"ࠪ࠾ࠬञ"))
        l11l1_opy_ = url[0]
        if l11l1_opy_ == l11l1l_opy_ (u"ࠫࡍࡊࡔࡗࠩट"):
            addon = l11l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡳࡡࡳࡶ࡫ࡹࡧ࠭ठ")
        else:
            addon = l11l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡵࡺࡣ࠵ࠫड")
    dixie.log(l11l1l_opy_ (u"ࠧࡂࡦࡧࡳࡳࠦࡉࡅ࠰࠱࠲࠿ࠦࠥࡴࠩढ") % addon)
    Addon  = xbmcaddon.Addon(id=addon)
    path   = Addon.getAddonInfo(l11l1l_opy_ (u"ࠨࡲࡤࡸ࡭࠭ण"))
    import sys
    sys.path.insert(0, path)
    import api
    l1l11_opy_ = Addon.getSetting(l11l1l_opy_ (u"ࠩࡶࡩࡸࡹࡩࡰࡰࠪत"))
    l111ll1_opy_  = Addon.getSetting(l11l1l_opy_ (u"ࠪࡷࡪࡸࡶࡦࡴࠪथ"))
    l1l1111_opy_    = l11l1l_opy_ (u"ࠫࠫࡪ࠽࡬ࡱࡧ࡭ࠫࡹ࠽ࠨद") + l1l11_opy_ + l11l1l_opy_ (u"ࠬࠬ࡯࠾ࠩध") + l111ll1_opy_
    import urllib
    l1l11l1_opy_ = l1ll1ll_opy_()
    dixie.log(l11l1l_opy_ (u"࠭ࡅࡑࡉࠣࡗࡹࡧࡲࡵࠢࡗ࡭ࡲ࡫࠮࠯࠰࠽ࠤࠪࡹࠧन") % start)
    dixie.log(l11l1l_opy_ (u"ࠧࡐࡨࡩࡷࡪࡺࠠࡪࡰࠣࡷࡪࡩ࡯࡯ࡦࡶ࠾ࠥࠫࡳࠨऩ") % l1l11l1_opy_)
    l1111l1_opy_  =  start - datetime.timedelta(seconds=l1l11l1_opy_)
    dixie.log(l11l1l_opy_ (u"ࠨࡕࡷࡥࡷࡺࠠࡕ࡫ࡰࡩࠥࡵࡦࡧࡵࡨࡸ࠿ࠦࠥࡴࠩप") % l1111l1_opy_)
    l1llllll_opy_ = str(l1111l1_opy_)
    l1llll1l_opy_  = l1llllll_opy_.split(l11l1l_opy_ (u"ࠩࠣࠫफ"))[0]
    l11ll1l_opy_     = l1lll11_opy_(name)
    if not l11ll1l_opy_:
        dixie.DialogOK(l11l1l_opy_ (u"ࠪࡗࡴࡸࡲࡺ࠰ࠪब"), l11l1l_opy_ (u"ࠫ࡜࡫ࠠࡤࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡪ࡮ࡴࡤࠡࡣࠣࡧࡦࡺࡣࡩࡷࡳࠤࡸ࡫ࡲࡷ࡫ࡦࡩࠥ࡬࡯ࡳࠢࡷ࡬࡮ࡹࠠࡤࡪࡤࡲࡳ࡫࡬࠯ࠩभ"), l11l1l_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡺࡲࡺࠢࡤࡲࡴࡺࡨࡦࡴࠣࡧ࡭ࡧ࡮࡯ࡧ࡯࠲ࠬम"))
        return None
    l1l11ll_opy_  = l1llllll_opy_.split(l11l1l_opy_ (u"࠭࠭ࠨय"), 1)[-1].rsplit(l11l1l_opy_ (u"ࠧ࠻ࠩर"), 1)[0]
    theTime    = urllib.quote_plus(l1l11ll_opy_)
    response   = api.remote_call( l11l1l_opy_ (u"ࠣࡶࡹࡥࡷࡩࡨࡪࡸࡨ࠳࡬࡫ࡴࡠࡤࡼࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡤࡧ࡮ࡥࡡࡧࡥࡹ࡫࠮ࡱࡪࡳࠦऱ") , {l11l1l_opy_ (u"ࠤࡧࡥࡹ࡫ࠢल"): l1llll1l_opy_, l11l1l_opy_ (u"ࠥ࡭ࡩࠨळ"): l11ll1l_opy_ } )
    l1l1l11_opy_ = response[l11l1l_opy_ (u"ࠦࡧࡵࡤࡺࠤऴ")]
    if not l1l1l11_opy_:
        dixie.DialogOK(l11l1l_opy_ (u"࡙ࠬ࡯ࡳࡴࡼ࠲ࠬव"), l11l1l_opy_ (u"࠭ࡗࡦࠢࡦࡳࡺࡲࡤࠡࡰࡲࡸࠥ࡬ࡩ࡯ࡦࠣࡥࠥࡩࡡࡵࡥ࡫ࡹࡵࠦࡳࡵࡴࡨࡥࡲࠦࡦࡰࡴࠣࡸ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮࠰ࠪश"), l11l1l_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡵࡴࡼࠤࡦ࡭ࡡࡪࡰࠣࡰࡦࡺࡥࡳ࠰ࠪष"))
        return None
    for l111l1l_opy_ in l1l1l11_opy_:
        l11ll1_opy_ = l111l1l_opy_[l11l1l_opy_ (u"ࠣࡲ࡯ࡳࡹࠨस")]
        if l1l11ll_opy_ in l11ll1_opy_:
            dixie.DialogOK(l11l1l_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡲࡶࡦࡴࡧࡦ࡟ࡆࡥࡹࡩࡨ࠮ࡷࡳࠤࡸࡺࡲࡦࡣࡰࠤ࡫ࡵࡵ࡯ࡦ࠱࡟࠴ࡉࡏࡍࡑࡕࡡࠬह"), l11l1l_opy_ (u"ࠪࡓࡳ࠳ࡔࡢࡲࡳ࠲࡙࡜ࠠࡸ࡫࡯ࡰࠥࡴ࡯ࡸࠢࡳࡰࡦࡿ࠺ࠡ࡝ࡆࡓࡑࡕࡒࠡࡱࡵࡥࡳ࡭ࡥ࡞࡝ࡅࡡࠪࡹ࡛࠰ࡄࡠ࡟࠴ࡉࡏࡍࡑࡕࡡࠬऺ") % (title))
            return l111l1l_opy_[l11l1l_opy_ (u"ࠦࡺࡸ࡬ࠣऻ")] + l1l1111_opy_
def l1lll11_opy_(name):
    l1l1ll_opy_   = dixie.PROFILE
    l1l_opy_ = os.path.join(l1l1ll_opy_, l11l1l_opy_ (u"ࠬ࡯࡮ࡪ़ࠩ"), l11l1l_opy_ (u"࠭ࡣࡢࡶࡦ࡬ࡺࡶ࠮ࡵࡺࡷࠫऽ"))
    l1lll1ll_opy_   = json.load(open(l1l_opy_))
    for channel in l1lll1ll_opy_:
        if name.upper() == channel[l11l1l_opy_ (u"ࠧࡐࡖࡗ࡚ࠬा")].upper():
            return channel[l11l1l_opy_ (u"ࠨࡗࡕࡐࠬि")]
def l1ll1ll_opy_():
    import time
    gmt = time.gmtime()
    loc = time.localtime()
    GMT = datetime.datetime(*gmt[:6]).isoformat(l11l1l_opy_ (u"ࠩࠣࠫी"))
    LOC = datetime.datetime(*loc[:6]).isoformat(l11l1l_opy_ (u"ࠪࠤࠬु"))
    dixie.log(gmt)
    dixie.log(loc)
    l1_opy_ = dixie.parseTime(GMT)
    l111lll_opy_ = dixie.parseTime(LOC)
    dixie.log(l1_opy_)
    dixie.log(l111lll_opy_)
    dixie.log(l11l1l_opy_ (u"ࠫࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࠡࡑࡉࡊࡘࡋࡔࠡࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤ࠭ू"))
    l1l11l1_opy_ = l1_opy_ - l111lll_opy_
    dixie.log(l1l11l1_opy_)
    l1l11l1_opy_ = ((l1l11l1_opy_.days * 86400) + (l1l11l1_opy_.seconds + 1800)) / 3600
    dixie.log(l1l11l1_opy_)
    l1l11l1_opy_ *= -3600
    dixie.log(l1l11l1_opy_)
    dixie.log(l11l1l_opy_ (u"ࠬࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥࠧृ"))
    return l1l11l1_opy_