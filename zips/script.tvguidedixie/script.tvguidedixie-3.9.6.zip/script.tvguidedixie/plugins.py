# coding: UTF-8
import sys
l11l111_opy_ = sys.version_info [0] == 2
l1ll1l1_opy_ = 2048
l1llll_opy_ = 7
def l111l1_opy_ (ll_opy_):
	global l11l_opy_
	l11l11l_opy_ = ord (ll_opy_ [-1])
	l1lll1l_opy_ = ll_opy_ [:-1]
	l1l11l1_opy_ = l11l11l_opy_ % len (l1lll1l_opy_)
	l1ll1_opy_ = l1lll1l_opy_ [:l1l11l1_opy_] + l1lll1l_opy_ [l1l11l1_opy_:]
	if l11l111_opy_:
		l1ll111_opy_ = unicode () .join ([unichr (ord (char) - l1ll1l1_opy_ - (l11l11_opy_ + l11l11l_opy_) % l1llll_opy_) for l11l11_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1ll111_opy_ = str () .join ([chr (ord (char) - l1ll1l1_opy_ - (l11l11_opy_ + l11l11l_opy_) % l1llll_opy_) for l11l11_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1ll111_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l111l1ll1_opy_    = l111l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡱࡸࡻ࠭঎")
l111l1lll_opy_ = l111l1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡻࡱ࡯ࡰࡵࡸࠪএ")
l11l111l1_opy_    = l111l1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡶࡴ࡮ࠫঐ")
locked = l111l1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲ࡯ࡤ࡭ࡨࡨࡹࡼࠧ঑")
l111llll1_opy_     = l111l1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡵ࡭ࡶ࡬ࡱࡦࡺࡥ࡮ࡣࡱ࡭ࡦ࠭঒")
l111lll1l_opy_   = l111l1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡭࡫ࡸࡼ࠳ࡺࡶࠨও")
l111l1l1l_opy_    = l111l1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡆࡆࡗࡵࡵࡲࡵࡵࠪঔ")
l111lllll_opy_ = l111l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡩࡧࡵ࡯ࡵࠩক")
l111ll111_opy_    = l111l1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡧࡱࡻࡩࡱࡶࡹࠫখ")
l1111ll_opy_ = [l111l1ll1_opy_, locked, l111lll1l_opy_, l111l1lll_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l111l1_opy_ (u"ࠬ࡯࡮ࡪࠩগ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l11l1ll_opy_ = l111l1_opy_ (u"࠭ࠧঘ")
def l1111l1_opy_(i, t1, l11l1l1_opy_=[]):
 t = l11l1ll_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l11l1l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1l1l_opy_ = l1111l1_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l1l11_opy_ = l1111l1_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1111ll_opy_:
        if l111l1l_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l111l1l_opy_(addon):
    if xbmc.getCondVisibility(l111l1_opy_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡉࡣࡶࡅࡩࡪ࡯࡯ࠪࠨࡷ࠮࠭ঙ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l1l11ll_opy_ = str(addon).split(l111l1_opy_ (u"ࠨ࠰ࠪচ"))[2] + l111l1_opy_ (u"ࠩ࠱࡭ࡳ࡯ࠧছ")
    l1l_opy_  = os.path.join(PATH, l1l11ll_opy_)
    try:
        l11lll1_opy_ = l1_opy_(addon)
    except KeyError:
        dixie.log(l111l1_opy_ (u"ࠪ࠱࠲࠳࠭࠮ࠢࡎࡩࡾࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡨࡧࡷࡊ࡮ࡲࡥࡴࠢ࠰࠱࠲࠳࠭ࠡࠩজ") + addon)
        result = {l111l1_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࡶࠫঝ"): [{l111l1_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨঞ"): l111l1_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࠬট"), l111l1_opy_ (u"ࡵࠨࡶࡼࡴࡪ࠭ঠ"): l111l1_opy_ (u"ࡶࠩࡸࡲࡰࡴ࡯ࡸࡰࠪড"), l111l1_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࠨঢ"): l111l1_opy_ (u"ࡸࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾࡸࡹࠩণ"), l111l1_opy_ (u"ࡹࠬࡲࡡࡣࡧ࡯ࠫত"): l111l1_opy_ (u"ࡺ࠭ࡎࡐࠢࡆࡌࡆࡔࡎࡆࡎࡖࠫথ")}], l111l1_opy_ (u"ࡻࠧ࡭࡫ࡰ࡭ࡹࡹࠧদ"):{l111l1_opy_ (u"ࡵࠨࡵࡷࡥࡷࡺࠧধ"): 0, l111l1_opy_ (u"ࡶࠩࡷࡳࡹࡧ࡬ࠨন"): 1, l111l1_opy_ (u"ࡷࠪࡩࡳࡪࠧ঩"): 1}}
    l1lllll_opy_  = l111l1_opy_ (u"ࠪ࡟ࠬপ") + addon + l111l1_opy_ (u"ࠫࡢࡢ࡮ࠨফ")
    l11ll1l_opy_  =  file(l1l_opy_, l111l1_opy_ (u"ࠬࡽࠧব"))
    l11ll1l_opy_.write(l1lllll_opy_)
    l1l1ll_opy_ = []
    for channel in l11lll1_opy_:
        l11l11lll_opy_ = cleanLabel(channel[l111l1_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬভ")])
        l111ll1_opy_   = dixie.l11l11l1l_opy_(l11l11lll_opy_)
        l1lll_opy_ = dixie.mapChannelName(l111ll1_opy_)
        stream   = channel[l111l1_opy_ (u"ࠧࡧ࡫࡯ࡩࠬম")]
        l11ll_opy_ = l1lll_opy_ + l111l1_opy_ (u"ࠨ࠿ࠪয") + stream
        l1l1ll_opy_.append(l11ll_opy_)
        l1l1ll_opy_.sort()
    for item in l1l1ll_opy_:
        l11ll1l_opy_.write(l111l1_opy_ (u"ࠤࠨࡷࡡࡴࠢর") % item)
    l11ll1l_opy_.close()
def l1_opy_(addon):
    if (addon == l111l1ll1_opy_) or (addon == l111l1lll_opy_):
        if xbmcaddon.Addon(addon).getSetting(l111l1_opy_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ঱")) == l111l1_opy_ (u"ࠫࡹࡸࡵࡦࠩল"):
            xbmcaddon.Addon(addon).setSetting(l111l1_opy_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ঳"), l111l1_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬ঴"))
            xbmcgui.Window(10000).setProperty(l111l1_opy_ (u"ࠧࡑࡎࡘࡋࡎࡔ࡟ࡈࡇࡑࡖࡊ࠭঵"), l111l1_opy_ (u"ࠨࡖࡵࡹࡪ࠭শ"))
        if xbmcaddon.Addon(addon).getSetting(l111l1_opy_ (u"ࠩࡷࡺ࡬ࡻࡩࡥࡧࠪষ")) == l111l1_opy_ (u"ࠪࡸࡷࡻࡥࠨস"):
            xbmcaddon.Addon(addon).setSetting(l111l1_opy_ (u"ࠫࡹࡼࡧࡶ࡫ࡧࡩࠬহ"), l111l1_opy_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫ঺"))
            xbmcgui.Window(10000).setProperty(l111l1_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡔࡗࡉࡘࡍࡉࡋࠧ঻"), l111l1_opy_ (u"ࠧࡕࡴࡸࡩ়ࠬ"))
        l1l1l11l1_opy_  = l111l1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫঽ") + addon
        l111ll1ll_opy_ =  l11l111ll_opy_(addon)
        query   =  l1l1l11l1_opy_ + l111ll1ll_opy_
        return sendJSON(query, addon)
    return l1l111l1l_opy_(addon)
def l1l111l1l_opy_(addon):
    if addon == l111lll1l_opy_:
        l1l111lll_opy_ = [l111l1_opy_ (u"ࠩ࠸ࠫা"), l111l1_opy_ (u"ࠪ࠵࠵࠼ࠧি"), l111l1_opy_ (u"ࠫ࠹࠭ী"), l111l1_opy_ (u"ࠬ࠸࠶࠴ࠩু"), l111l1_opy_ (u"࠭࠱࠴࠴ࠪূ")]
    if addon == locked:
        l1l111lll_opy_ = [l111l1_opy_ (u"ࠧ࠴࠲ࠪৃ"), l111l1_opy_ (u"ࠨ࠵࠴ࠫৄ"), l111l1_opy_ (u"ࠩ࠶࠶ࠬ৅"), l111l1_opy_ (u"ࠪ࠷࠸࠭৆"), l111l1_opy_ (u"ࠫ࠸࠺ࠧে"), l111l1_opy_ (u"ࠬ࠹࠵ࠨৈ"), l111l1_opy_ (u"࠭࠳࠹ࠩ৉"), l111l1_opy_ (u"ࠧ࠵࠲ࠪ৊"), l111l1_opy_ (u"ࠨ࠶࠴ࠫো"), l111l1_opy_ (u"ࠩ࠷࠹ࠬৌ"), l111l1_opy_ (u"ࠪ࠸࠼্࠭"), l111l1_opy_ (u"ࠫ࠹࠿ࠧৎ"), l111l1_opy_ (u"ࠬ࠻࠲ࠨ৏")]
    if addon == l111llll1_opy_:
        l1l111lll_opy_ = [l111l1_opy_ (u"࠭࠲࠶ࠩ৐"), l111l1_opy_ (u"ࠧ࠳࠸ࠪ৑"), l111l1_opy_ (u"ࠨ࠴࠺ࠫ৒"), l111l1_opy_ (u"ࠩ࠵࠽ࠬ৓"), l111l1_opy_ (u"ࠪ࠷࠵࠭৔"), l111l1_opy_ (u"ࠫ࠸࠷ࠧ৕"), l111l1_opy_ (u"ࠬ࠹࠲ࠨ৖"), l111l1_opy_ (u"࠭࠳࠶ࠩৗ"), l111l1_opy_ (u"ࠧ࠴࠸ࠪ৘"), l111l1_opy_ (u"ࠨ࠵࠺ࠫ৙"), l111l1_opy_ (u"ࠩ࠶࠼ࠬ৚"), l111l1_opy_ (u"ࠪ࠷࠾࠭৛"), l111l1_opy_ (u"ࠫ࠹࠶ࠧড়"), l111l1_opy_ (u"ࠬ࠺࠱ࠨঢ়"), l111l1_opy_ (u"࠭࠴࠹ࠩ৞"), l111l1_opy_ (u"ࠧ࠵࠻ࠪয়"), l111l1_opy_ (u"ࠨ࠷࠳ࠫৠ"), l111l1_opy_ (u"ࠩ࠸࠶ࠬৡ"), l111l1_opy_ (u"ࠪ࠹࠹࠭ৢ"), l111l1_opy_ (u"ࠫ࠺࠼ࠧৣ"), l111l1_opy_ (u"ࠬ࠻࠷ࠨ৤"), l111l1_opy_ (u"࠭࠵࠹ࠩ৥"), l111l1_opy_ (u"ࠧ࠶࠻ࠪ০"), l111l1_opy_ (u"ࠨ࠸࠳ࠫ১"), l111l1_opy_ (u"ࠩ࠹࠵ࠬ২"), l111l1_opy_ (u"ࠪ࠺࠷࠭৩"), l111l1_opy_ (u"ࠫ࠻࠹ࠧ৪"), l111l1_opy_ (u"ࠬ࠼࠵ࠨ৫"), l111l1_opy_ (u"࠭࠶࠷ࠩ৬"), l111l1_opy_ (u"ࠧ࠷࠹ࠪ৭"), l111l1_opy_ (u"ࠨ࠸࠼ࠫ৮"), l111l1_opy_ (u"ࠩ࠺࠴ࠬ৯"), l111l1_opy_ (u"ࠪ࠻࠹࠭ৰ"), l111l1_opy_ (u"ࠫ࠼࠽ࠧৱ"), l111l1_opy_ (u"ࠬ࠽࠸ࠨ৲"), l111l1_opy_ (u"࠭࠸࠱ࠩ৳"), l111l1_opy_ (u"ࠧ࠹࠳ࠪ৴")]
    login = l111l1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸ࠵ࠧ৵") % addon
    sendJSON(login, addon)
    l1111_opy_ = []
    for l1l11llll_opy_ in l1l111lll_opy_:
        if addon == l111lll1l_opy_:
            query = l111l1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠪࡹ࠯ࡀ࡯ࡲࡨࡪࡥࡩࡥ࠿ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪࡲࡵࡤࡦ࠿ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪࡸ࡫ࡣࡵ࡫ࡲࡲࡤ࡯ࡤ࠾ࠧࡶࠫ৶") % (addon, l1l11llll_opy_)
        if (addon == locked) or (addon == l111llll1_opy_):
            query = l111l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳ࠰ࡁࡸࡶࡱࡃࠥࡴࠨࡰࡳࡩ࡫࠽࠵ࠨࡱࡥࡲ࡫࠽ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡶ࡬ࡢࡻࡀࠪࡩࡧࡴࡦ࠿ࠩࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮࠾ࠨࡳࡥ࡬࡫࠽ࠨ৷") % (addon, l1l11llll_opy_)
        response = sendJSON(query, addon)
        l1111_opy_.extend(response)
    return l1111_opy_
def sendJSON(query, addon):
    l1l11l1ll_opy_     = l111l1_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࠥࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧ৸") % query
    l1l1l1111_opy_  = xbmc.executeJSONRPC(l1l11l1ll_opy_)
    response = json.loads(l1l1l1111_opy_)
    result   = response[l111l1_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬ৹")]
    if xbmcgui.Window(10000).getProperty(l111l1_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡇࡆࡐࡕࡉࠬ৺")) == l111l1_opy_ (u"ࠧࡕࡴࡸࡩࠬ৻"):
        xbmcaddon.Addon(addon).setSetting(l111l1_opy_ (u"ࠨࡩࡨࡲࡷ࡫ࠧৼ"), l111l1_opy_ (u"ࠩࡷࡶࡺ࡫ࠧ৽"))
    if xbmcgui.Window(10000).getProperty(l111l1_opy_ (u"ࠪࡔࡑ࡛ࡇࡊࡐࡢࡘ࡛ࡍࡕࡊࡆࡈࠫ৾")) == l111l1_opy_ (u"࡙ࠫࡸࡵࡦࠩ৿"):
        xbmcaddon.Addon(addon).setSetting(l111l1_opy_ (u"ࠬࡺࡶࡨࡷ࡬ࡨࡪ࠭਀"), l111l1_opy_ (u"࠭ࡴࡳࡷࡨࠫਁ"))
    return result[l111l1_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ਂ")]
def l11l111ll_opy_(addon):
    if (addon == l111l1ll1_opy_) or (addon == l111l1lll_opy_):
        return l111l1_opy_ (u"ࠨ࠱ࡂࡧࡦࡺ࠽࠮࠴ࠩࡨࡦࡺࡥࠧࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠬࡥ࡯ࡦࡇࡥࡹ࡫ࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡲࡵࡤࡦ࠿࠵ࠪࡳࡧ࡭ࡦ࠿ࡐࡽࠪ࠸࠰ࡄࡪࡤࡲࡳ࡫࡬ࡴࠨࡵࡩࡨࡵࡲࡥࡰࡤࡱࡪࠬࡳࡵࡣࡵࡸࡉࡧࡴࡦࠨࡸࡶࡱࡃࡵࡳ࡮ࠪਃ")
    return l111l1_opy_ (u"ࠩࠪ਄")
def l111l_opy_():
    modules = map(__import__, [l1111l1_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1l1l_opy_)):
        return l111l1_opy_ (u"ࠪࡘࡷࡻࡥࠨਅ")
    if len(modules[-1].Window(10**4).getProperty(l1l11_opy_)):
        return l111l1_opy_ (u"࡙ࠫࡸࡵࡦࠩਆ")
    return l111l1_opy_ (u"ࠬࡌࡡ࡭ࡵࡨࠫਇ")
def l1l1111_opy_(e, addon):
    l11ll1_opy_ = l111l1_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠱ࠦࡡ࡯ࠢࡨࡶࡷࡵࡲࠡࡱࡦࡧࡺࡸࡥࡥ࠼ࠣࡎࡘࡕࡎࠡࡇࡵࡶࡴࡸ࠺ࠡࠧࡶ࠰ࠥࠫࡳࠨਈ")  % (e, addon)
    l11l1_opy_ = l111l1_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡤࡱࡱࡸࡦࡩࡴࠡࡷࡶࠤࡴࡴࠠࡵࡪࡨࠤ࡫ࡵࡲࡶ࡯࠱ࠫਉ")
    l1l111_opy_ = l111l1_opy_ (u"ࠨࡗࡳࡰࡴࡧࡤࠡࡣࠣࡰࡴ࡭ࠠࡷ࡫ࡤࠤࡹ࡮ࡥࠡࡣࡧࡨࡴࡴࠠࡴࡧࡷࡸ࡮ࡴࡧࡴࠢࡤࡲࡩࠦࡰࡰࡵࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰ࠴ࠧਊ")
    dixie.log(addon)
    dixie.log(e)
def getPluginInfo(streamurl):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l111lll11_opy_   = l111l1_opy_ (u"ࠩࡎࡳࡩ࡯ࠠࡑࡘࡕࠫ਋")
            l11l1111l_opy_ = os.path.join(dixie.RESOURCES, l111l1_opy_ (u"ࠪ࡯ࡴࡪࡩ࠮ࡲࡹࡶ࠳ࡶ࡮ࡨࠩ਌"))
            return l111lll11_opy_, l11l1111l_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l111l1_opy_ (u"ࠫࡷࡺ࡭ࡱࠩ਍")) or url.startswith(l111l1_opy_ (u"ࠬࡸࡴ࡮ࡲࡨࠫ਎")) or url.startswith(l111l1_opy_ (u"࠭ࡲࡵࡵࡳࠫਏ")) or url.startswith(l111l1_opy_ (u"ࠧࡩࡶࡷࡴࠬਐ")):
            l111lll11_opy_   = l111l1_opy_ (u"ࠨ࡯࠶ࡹࠥࡖ࡬ࡢࡻ࡯࡭ࡸࡺࠧ਑")
            l11l1111l_opy_ = os.path.join(dixie.RESOURCES, l111l1_opy_ (u"ࠩ࡬ࡴࡹࡼ࠭ࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡳࡲ࡬࠭਒"))
            return l111lll11_opy_, l11l1111l_opy_
    except:
        pass
    if streamurl.startswith(l111l1_opy_ (u"ࠪࡴࡻࡸ࠺࠰࠱ࠪਓ")):
        l111lll11_opy_   = l111l1_opy_ (u"ࠫࡐࡵࡤࡪࠢࡓ࡚ࡗ࠭ਔ")
        l11l1111l_opy_ = os.path.join(dixie.RESOURCES, l111l1_opy_ (u"ࠬࡱ࡯ࡥ࡫࠰ࡴࡻࡸ࠮ࡱࡰࡪࠫਕ"))
        return l111lll11_opy_, l11l1111l_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        l11l11111_opy_ = streamurl.split(l111l1_opy_ (u"࠭࡝ࡐࡖࡗࡣࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧਖ"), 1)[-1].split(l111l1_opy_ (u"ࠧ࠰ࠩਗ"), 1)[0]
    if l111l1_opy_ (u"ࠨ࡟ࡒࡘ࡙ࡥࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩਘ") in streamurl:
        l11l11111_opy_ = streamurl.split(l111l1_opy_ (u"ࠩࡠࡓ࡙࡚࡟ࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪਙ"), 1)[-1].split(l111l1_opy_ (u"ࠪ࠳ࠬਚ"), 1)[0]
    if streamurl.startswith(l111l1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧਛ")):
        l11l11111_opy_ = streamurl.split(l111l1_opy_ (u"ࠬ࠵࠯ࠨਜ"), 1)[-1].split(l111l1_opy_ (u"࠭࠯ࠨਝ"), 1)[0]
    if l111l1_opy_ (u"ࠧࡠࡡࡖࡊࡤࡥࠧਞ") in streamurl:
        l11l11111_opy_ = l111l1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡲࡵࡳ࡬ࡸࡡ࡮࠰ࡶࡹࡵ࡫ࡲ࠯ࡨࡤࡺࡴࡻࡲࡪࡶࡨࡷࠬਟ")
    if l111l1_opy_ (u"ࠩࡋࡈ࡙࡜࠺ࠨਠ") in streamurl:
        l11l11111_opy_ = l111l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡱࡦࡸࡴࡩࡷࡥࠫਡ")
    if l111l1_opy_ (u"ࠫࡍࡊࡔࡗ࠴࠽ࠫਢ") in streamurl:
        l11l11111_opy_ = l111l1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢ࠴ࠪਣ")
    if l111l1_opy_ (u"࠭ࡈࡅࡖ࡙࠷࠿࠭ਤ") in streamurl:
        l11l11111_opy_ = l111l1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࠶ࠬਥ")
    if l111l1_opy_ (u"ࠨࡊࡇࡘ࡛࠺࠺ࠨਦ") in streamurl:
        l11l11111_opy_ = l111l1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡺ࡯ࠫਧ")
    if l111l1_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠼ࠪਨ") in streamurl:
        l11l11111_opy_ = l111l1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡦࡧࡩࡩࡱ࡮ࡤࡽࡪࡸࠧ਩")
    if l111l1_opy_ (u"ࠬࡏࡐࡍࡃ࡜࠶࠿࠭ਪ") in streamurl:
        l11l11111_opy_ = l111l1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰ࡭ࡣࡼࡩࡷࡽࡷࡸࠩਫ")
    if l111l1_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡘ࠺ࠨਬ") in streamurl:
        l11l11111_opy_ = l111l1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺࠫਭ")
    if l111l1_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡊࡖ࡙࠾ࠬਮ") in streamurl:
        l11l11111_opy_ = l111l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡸࡻ࠭ਯ")
    if l111l1_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡇ࠾ࠬਰ") in streamurl:
        l11l11111_opy_ = l111l1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸࠨ਱")
    if l111l1_opy_ (u"࠭ࡊࡊࡐ࡛࠶࠿࠭ਲ") in streamurl:
        l11l11111_opy_ = l111l1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡪࡪࡰࡻࡸࡻ࠸ࠧਲ਼")
    if l111l1_opy_ (u"ࠨࡔࡒࡓ࡙ࡀࠧ਴") in streamurl:
        l11l11111_opy_ = l111l1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡲࡳࡹ࡯ࡰࡵࡸࠪਵ")
    if l111l1_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡔࡅ࠾ࠬਸ਼") in streamurl:
        l11l11111_opy_ = l111l1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡪࡨ࡯ࡰࡶࠪ਷")
    if l111l1_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡇࡑ࡛࠺ࠨਸ") in streamurl:
        l11l11111_opy_ = l111l1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡩ࡬ࡶ࡫ࡳࡸࡻ࠭ਹ")
    if l111l1_opy_ (u"ࠧࡊࡒࡗࡗࠬ਺") in streamurl:
        l11l11111_opy_ = l111l1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲࡷࡺࡸࡻࡢࡴࠩ਻")
    if l111l1_opy_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠼਼ࠪ") in streamurl:
        l11l11111_opy_ = l111l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡯࡭ࡻ࡫࡭ࡪࡺࠪ਽")
    if l111l1_opy_ (u"ࠫࡊࡔࡄ࠻ࠩਾ") in streamurl:
        l11l11111_opy_ = l111l1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡊࡴࡤ࡭ࡧࡶࡷࠬਿ")
    if l111l1_opy_ (u"࠭ࡆࡍࡃ࠽ࠫੀ") in streamurl:
        l11l11111_opy_ = l111l1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡆ࡭ࡣࡺࡰࡪࡹࡳࡕࡸࠪੁ")
    if l111l1_opy_ (u"ࠨࡈࡏࡅࡘࡀࠧੂ") in streamurl:
        l11l11111_opy_ = l111l1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡈ࡯ࡥࡼࡲࡥࡴࡵࡗࡺࠬ੃")
    if l111l1_opy_ (u"ࠪࡹࡵࡴࡰ࠻ࠩ੄") in streamurl:
        l11l11111_opy_ = l111l1_opy_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲࡭ࡪࡨࡰ࡯ࡨࡶࡺࡴ࠮ࡷ࡫ࡨࡻࠬ੅")
    return l111ll11l_opy_(l11l11111_opy_)
def l111ll11l_opy_(l11l11111_opy_):
    l111lll11_opy_   = l111l1_opy_ (u"ࠬ࠭੆")
    l11l1111l_opy_ = l111l1_opy_ (u"࠭ࠧੇ")
    try:
        l11l11ll1_opy_ = xbmcaddon.Addon(l11l11111_opy_).getAddonInfo(l111l1_opy_ (u"ࠧ࡯ࡣࡰࡩࠬੈ"))
        l111lll11_opy_    = cleanLabel(l11l11ll1_opy_)
        l11l1111l_opy_  = xbmcaddon.Addon(l11l11111_opy_).getAddonInfo(l111l1_opy_ (u"ࠨ࡫ࡦࡳࡳ࠭੉"))
        return l111lll11_opy_, l11l1111l_opy_
    except:
        l111lll11_opy_   = l111l1_opy_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠣࡗࡴࡻࡲࡤࡧࠪ੊")
        l11l1111l_opy_ =  dixie.ICON
        return l111lll11_opy_, l11l1111l_opy_
    return l111lll11_opy_, l11l1111l_opy_
def selectStream(url, channel):
    l111ll1l1_opy_ = url.split(l111l1_opy_ (u"ࠪࢀࠬੋ"))
    if len(l111ll1l1_opy_) == 0:
        return None
    options, l111l11_opy_ = getOptions(l111ll1l1_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l111ll1l1_opy_) == 1:
            return l111l11_opy_[0]
    import selectDialog
    l11l11l11_opy_ = selectDialog.select(l111l1_opy_ (u"ࠫࡘ࡫࡬ࡦࡥࡷࠤࡦࠦࡳࡵࡴࡨࡥࡲ࠭ੌ"), options)
    if l11l11l11_opy_ < 0:
        raise Exception(l111l1_opy_ (u"࡙ࠬࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡࡅࡤࡲࡨ࡫࡬ࠨ੍"))
    return l111l11_opy_[l11l11l11_opy_]
def getOptions(l111ll1l1_opy_, channel, addmore=True):
    options = []
    l111l11_opy_    = []
    for index, stream in enumerate(l111ll1l1_opy_):
        l111lll11_opy_ = getPluginInfo(stream)
        l11l1l_opy_ = l111lll11_opy_[0]
        l111l1l11_opy_  = l111lll11_opy_[1]
        l11l1l_opy_ = l111l1_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡯ࡳࡣࡱ࡫ࡪࡣ࡛ࠨ੎") + l11l1l_opy_ + l111l1_opy_ (u"ࠧ࡞࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࠫ੏")
        if stream.startswith(OPEN_OTT):
            l11ll1l11_opy_ = stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l111l1_opy_ (u"ࠨࠩ੐"))
            l11l1l_opy_  = l11l1l_opy_ + l11ll1l11_opy_
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l111l1_opy_ (u"ࠩࠪੑ"))
        else:
            l11l1l_opy_  = l11l1l_opy_ + channel
        options.append([l11l1l_opy_, index, l111l1l11_opy_])
        l111l11_opy_.append(stream)
    if addmore:
        options.append([l111l1_opy_ (u"ࠪࡅࡩࡪࠠ࡮ࡱࡵࡩ࠳࠴࠮ࠨ੒"), index + 1, dixie.ICON])
        l111l11_opy_.append(l111l1_opy_ (u"ࠫࡦࡪࡤࡎࡱࡵࡩࠬ੓"))
    return options, l111l11_opy_
def cleanLabel(name):
    import re
    name  = re.sub(l111l1_opy_ (u"ࠬࡢࠨ࡜࠲࠰࠽࠮ࡣࠪ࡝ࠫࠪ੔"), l111l1_opy_ (u"࠭ࠧ੕"), name)
    items = name.split(l111l1_opy_ (u"ࠧ࡞ࠩ੖"))
    name  = l111l1_opy_ (u"ࠨࠩ੗")
    for item in items:
        if len(item) == 0:
            continue
        item += l111l1_opy_ (u"ࠩࡠࠫ੘")
        item  = re.sub(l111l1_opy_ (u"ࠪࡠࡠࡡ࡞ࠪ࡟࠭ࡠࡢ࠭ਖ਼"), l111l1_opy_ (u"ࠫࠬਗ਼"), item)
        if len(item) > 0:
            name += item
    name  = name.replace(l111l1_opy_ (u"ࠬࡡࠧਜ਼"), l111l1_opy_ (u"࠭ࠧੜ"))
    name  = name.replace(l111l1_opy_ (u"ࠧ࡞ࠩ੝"), l111l1_opy_ (u"ࠨࠩਫ਼"))
    name  = name.strip()
    while True:
        length = len(name)
        name = name.replace(l111l1_opy_ (u"ࠩࠣࠤࠬ੟"), l111l1_opy_ (u"ࠪࠤࠬ੠"))
        if length == len(name):
            break
    return name.strip()
if __name__ == l111l1_opy_ (u"ࠫࡤࡥ࡭ࡢ࡫ࡱࡣࡤ࠭੡"):
    checkAddons()