# -*- coding: utf-8 -*-
import sys
l11l111_opy_ = sys.version_info [0] == 2
l1ll1l1_opy_ = 2048
l1llll_opy_ = 7
def l111l1_opy_ (ll_opy_):
	global l11l_opy_
	l11l11l_opy_ = ord (ll_opy_ [-1])
	l1lll1l_opy_ = ll_opy_ [:-1]
	l1l11l1_opy_ = l11l11l_opy_ % len (l1lll1l_opy_)
	l1ll1_opy_ = l1lll1l_opy_ [:l1l11l1_opy_] + l1lll1l_opy_ [l1l11l1_opy_:]
	if l11l111_opy_:
		l1ll111_opy_ = unicode () .join ([unichr (ord (char) - l1ll1l1_opy_ - (l11l11_opy_ + l11l11l_opy_) % l1llll_opy_) for l11l11_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1ll111_opy_ = str () .join ([chr (ord (char) - l1ll1l1_opy_ - (l11l11_opy_ + l11l11l_opy_) % l1llll_opy_) for l11l11_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1ll111_opy_)
import os
import json
import requests
import dixie
l11lll_opy_ = dixie.PROFILE
PATH = os.path.join(l11lll_opy_, l111l1_opy_ (u"ࠬࡶ࡬ࡪࡵࡷࡷࠬव"))
def loadPlaylists():
    dixie.log(l111l1_opy_ (u"࠭࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࠦࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠢࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠨश"))
    if os.path.exists(PATH):
        return json.load(open(PATH))
    try:
        l11ll1111_opy_()
        return json.load(open(PATH))
    except:
        dixie.log(l111l1_opy_ (u"ࠧ࠾࠿ࡀࡁࠥࡖ࡬ࡢࡻ࡯࡭ࡸࡺࠠ࡭ࡱࡤࡨࠥ࡫ࡲࡳࡱࡵࠤࡂࡃ࠽࠾ࠩष"))
        return []
def l11ll1111_opy_():
    source = dixie.GetSetting(l111l1_opy_ (u"ࠨ࡫ࡳࡸࡻ࠴ࡳࡰࡷࡵࡧࡪ࠭स"))
    if not source == l111l1_opy_ (u"ࠩ࠴ࠫह"):
        return l11lll111_opy_()
    return l11l1l11l_opy_()
def l11lll111_opy_():
    l1l111l11_opy_ = []
    if dixie.GetSetting(l111l1_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠲ࠪऺ")) == l111l1_opy_ (u"ࠫࡹࡸࡵࡦࠩऻ"):
        l1l1l1l1l_opy_  = dixie.GetSetting(l111l1_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠴ࡤ࡛ࡒࡍ़ࠩ"))
        l1l11l11l_opy_ = dixie.GetSetting(l111l1_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠵ࡥࡐࡐࡔࡗࠫऽ"))
        l11ll1ll1_opy_ = dixie.GetSetting(l111l1_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠶࡟ࡕ࡛ࡓࡉࠬा"))
        l1l11ll11_opy_ = dixie.GetSetting(l111l1_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠰ࡠࡗࡖࡉࡗ࠭ि"))
        l1l1l1ll1_opy_ = dixie.GetSetting(l111l1_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠱ࡡࡓࡅࡘ࡙ࠧी"))
        if len(l1l1l1l1l_opy_) > 0:
            l11l1l1l1_opy_ = l1l11l1l1_opy_(l1l1l1l1l_opy_, l1l11l11l_opy_, l11ll1ll1_opy_, l1l11ll11_opy_, l1l1l1ll1_opy_)
            l1l111l11_opy_.append((l11l1l1l1_opy_, l111l1_opy_ (u"ࠪࡍࡕ࡚ࡖ࠲࠼ࠣࠫु")))
    if dixie.GetSetting(l111l1_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠴ࠫू")) == l111l1_opy_ (u"ࠬࡺࡲࡶࡧࠪृ"):
        l1l1l1l1l_opy_  = dixie.GetSetting(l111l1_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠶ࡥࡕࡓࡎࠪॄ"))
        l1l11l11l_opy_ = dixie.GetSetting(l111l1_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠷࡟ࡑࡑࡕࡘࠬॅ"))
        l11ll1ll1_opy_ = dixie.GetSetting(l111l1_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠱ࡠࡖ࡜ࡔࡊ࠭ॆ"))
        l1l11ll11_opy_ = dixie.GetSetting(l111l1_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠲ࡡࡘࡗࡊࡘࠧे"))
        l1l1l1ll1_opy_ = dixie.GetSetting(l111l1_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠳ࡢࡔࡆ࡙ࡓࠨै"))
        if len(l1l1l1l1l_opy_) > 0:
            l11llll1l_opy_ = l1l11l1l1_opy_(l1l1l1l1l_opy_, l1l11l11l_opy_, l11ll1ll1_opy_, l1l11ll11_opy_, l1l1l1ll1_opy_)
            l1l111l11_opy_.append((l11llll1l_opy_, l111l1_opy_ (u"ࠫࡎࡖࡔࡗ࠴࠽ࠤࠬॉ")))
    if dixie.GetSetting(l111l1_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠶ࠬॊ")) == l111l1_opy_ (u"࠭ࡴࡳࡷࡨࠫो"):
        l1l1l1l1l_opy_  = dixie.GetSetting(l111l1_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠸࡟ࡖࡔࡏࠫौ"))
        l1l11l11l_opy_ = dixie.GetSetting(l111l1_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠲ࡠࡒࡒࡖ्࡙࠭"))
        l11ll1ll1_opy_ = dixie.GetSetting(l111l1_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠳ࡡࡗ࡝ࡕࡋࠧॎ"))
        l1l11ll11_opy_ = dixie.GetSetting(l111l1_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠴ࡢ࡙ࡘࡋࡒࠨॏ"))
        l1l1l1ll1_opy_ = dixie.GetSetting(l111l1_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠵ࡣࡕࡇࡓࡔࠩॐ"))
        if len(l1l1l1l1l_opy_) > 0:
            l11llll11_opy_ = l1l11l1l1_opy_(l1l1l1l1l_opy_, l1l11l11l_opy_, l11ll1ll1_opy_, l1l11ll11_opy_, l1l1l1ll1_opy_)
            l1l111l11_opy_.append((l11llll11_opy_, l111l1_opy_ (u"ࠬࡏࡐࡕࡘ࠶࠾ࠥ࠭॑")))
    return l11l1llll_opy_(l111l1_opy_ (u"࠭ࡕࡓࡎࡖ॒ࠫ"),  l1l111l11_opy_)
def l11l1l11l_opy_():
    l1l111l11_opy_ = []
    if dixie.GetSetting(l111l1_opy_ (u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡷࡽࡵ࡫ࠧ॓")) == l111l1_opy_ (u"ࠨ࠲ࠪ॔"):
        if dixie.GetSetting(l111l1_opy_ (u"ࠩࡘࡖࡑࡥࡏࠨॕ")) == l111l1_opy_ (u"ࠪࡸࡷࡻࡥࠨॖ"):
            l11l1l111_opy_ = dixie.GetSetting(l111l1_opy_ (u"ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡵࡳ࡮ࠪॗ"))
            if len(l11l1l111_opy_) > 0:
                l1l111l11_opy_.append((l11l1l111_opy_, l111l1_opy_ (u"࡛ࠬࡒࡍ࠳࠽ࠤࠬक़")))
        if dixie.GetSetting(l111l1_opy_ (u"࠭ࡕࡓࡎࡢ࠵ࠬख़")) == l111l1_opy_ (u"ࠧࡵࡴࡸࡩࠬग़"):
            l11lllll1_opy_ = dixie.GetSetting(l111l1_opy_ (u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡹࡷࡲ࠱ࠨज़"))
            if len(l11lllll1_opy_) > 0:
                l1l111l11_opy_.append((l11lllll1_opy_, l111l1_opy_ (u"ࠩࡘࡖࡑ࠸࠺ࠡࠩड़")))
        if dixie.GetSetting(l111l1_opy_ (u"࡙ࠪࡗࡒ࡟࠳ࠩढ़")) == l111l1_opy_ (u"ࠫࡹࡸࡵࡦࠩफ़"):
            l11lll1ll_opy_ = dixie.GetSetting(l111l1_opy_ (u"ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡶࡴ࡯࠶ࠬय़"))
            if len(l11lll1ll_opy_) > 0:
                l1l111l11_opy_.append((l11lll1ll_opy_, l111l1_opy_ (u"࠭ࡕࡓࡎ࠶࠾ࠥ࠭ॠ")))
        dixie.log(l1l111l11_opy_)
        return l11l1llll_opy_(l111l1_opy_ (u"ࠧࡖࡔࡏࡗࠬॡ"),  l1l111l11_opy_)
    if dixie.GetSetting(l111l1_opy_ (u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡸࡾࡶࡥࠨॢ")) == l111l1_opy_ (u"ࠩ࠴ࠫॣ"):
        if dixie.GetSetting(l111l1_opy_ (u"ࠪࡊࡎࡒࡅࡠ࠲ࠪ।")) == l111l1_opy_ (u"ࠫࡹࡸࡵࡦࠩ॥"):
            l1l11111l_opy_ = os.path.join(dixie.GetSetting(l111l1_opy_ (u"ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡧ࡫࡯ࡩࠬ०")))
            if l1l11111l_opy_:
                l1l111l11_opy_.append((l1l11111l_opy_, l111l1_opy_ (u"࠭ࡆࡊࡎࡈ࠵࠿ࠦࠧ१")))
        if dixie.GetSetting(l111l1_opy_ (u"ࠧࡇࡋࡏࡉࡤ࠶ࠧ२")) == l111l1_opy_ (u"ࠨࡶࡵࡹࡪ࠭३"):
            l1l1111l1_opy_ = os.path.join(dixie.GetSetting(l111l1_opy_ (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲࡫࡯࡬ࡦ࠳ࠪ४")))
            if l1l1111l1_opy_:
                l1l111l11_opy_.append((l1l1111l1_opy_, l111l1_opy_ (u"ࠪࡊࡎࡒࡅ࠳࠼ࠣࠫ५")))
        if dixie.GetSetting(l111l1_opy_ (u"ࠫࡋࡏࡌࡆࡡ࠳ࠫ६")) == l111l1_opy_ (u"ࠬࡺࡲࡶࡧࠪ७"):
            l1l1111ll_opy_ = os.path.join(dixie.GetSetting(l111l1_opy_ (u"࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡨ࡬ࡰࡪ࠸ࠧ८")))
            if l1l1111ll_opy_:
                l1l111l11_opy_.append((l1l1111ll_opy_, l111l1_opy_ (u"ࠧࡇࡋࡏࡉ࠸ࡀࠠࠨ९")))
        dixie.log(l1l111l11_opy_)
        return l11l1llll_opy_(l111l1_opy_ (u"ࠨࡈࡌࡐࡊ࡙ࠧ॰"), l1l111l11_opy_)
def l11l1ll11_opy_():
    l11l1ll1l_opy_ = [l111l1_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡻ࠲ࡨࡵ࠯ࡉࡇ࡝࠹࡟ࡿࡩࡋࡧ࡚ࠫॱ")]
    for url in l11l1ll1l_opy_:
        request = requests.get(url)
        content = request.content
        if l111l1_opy_ (u"ࠪࠧࡊ࡞ࡔࡎ࠵ࡘࠫॲ") in content:
            return l11l1llll_opy_(l111l1_opy_ (u"ࠫࡈࡒࡏࡖࡆࠪॳ"), [(url, l111l1_opy_ (u"ࠬ࠭ॴ"))])
            break
def l11l1llll_opy_(l11l1lll1_opy_, plist):
    dixie.log(l11l1lll1_opy_)
    dixie.log(plist)
    playlists = []
    for item in plist:
        url = item[0]
        l11llllll_opy_ = item[1]
        l11lll11l_opy_ = l1l111111_opy_(l11l1lll1_opy_, url, l11llllll_opy_)
        playlists.extend(l11lll11l_opy_)
    json.dump(playlists, open(PATH,l111l1_opy_ (u"࠭ࡷࠨॵ")))
def l1l111111_opy_(l11l1lll1_opy_, url, l11llllll_opy_):
    content  = l11l1l1ll_opy_(l11l1lll1_opy_, url)
    pairs    = []
    for i in range(1,len(content), 2):
        if l11lll1l1_opy_(content[i]) == True:
            l11l1l_opy_ = content[i]
            l1ll11l_opy_   = content[i+1]
            pairs.append([l11l1l_opy_, l1ll11l_opy_])
    l11ll111l_opy_ = list()
    l11l1l_opy_   = l111l1_opy_ (u"ࠧࠨॶ")
    value   = l111l1_opy_ (u"ࠨࠩॷ")
    for item in pairs:
        l11ll1l1l_opy_ = item[0]
        l11ll1lll_opy_ = item[1]
        l11ll1l11_opy_   = l11ll1l1l_opy_.split(l111l1_opy_ (u"ࠩ࠯ࠫॸ"))[-1].strip()
        l111ll1_opy_ = dixie.cleanLabel(l11ll1l11_opy_)
        l1lll_opy_ = dixie.mapChannelName(l111ll1_opy_)
        value = l11ll1lll_opy_.replace(l111l1_opy_ (u"ࠪࡶࡹࡳࡰ࠻࠱࠲ࠨࡔࡖࡔ࠻ࡴࡷࡱࡵ࠳ࡲࡢࡹࡀࠫॹ"), l111l1_opy_ (u"ࠫࠬॺ")).replace(l111l1_opy_ (u"ࠬࡢ࡮ࠨॻ"), l111l1_opy_ (u"࠭ࠧॼ"))
        l11ll111l_opy_.append((l11llllll_opy_, l1lll_opy_, value))
    return l11ll111l_opy_
def l11lll1l1_opy_(l11l1l_opy_):
    l11l1l_opy_ = l11l1l_opy_.lower()
    filters = dixie.getFilters()
    for item in filters:
        item = item.lower()
        if item in l11l1l_opy_:
            return False
    return True
def l11l1l1ll_opy_(l11l1lll1_opy_, url):
    try:
        import urllib
        if (l11l1lll1_opy_ == l111l1_opy_ (u"ࠧࡖࡔࡏࡗࠬॽ")) or (l11l1lll1_opy_ == l111l1_opy_ (u"ࠨࡅࡏࡓ࡚ࡊࠧॾ")):
            response = urllib.urlopen(url)
            content  = response.readlines()
            return content
    except:
        dixie.log(l111l1_opy_ (u"ࠩࡈࡖࡗࡕࡒࠡࡴࡨࡥࡩ࡯࡮ࡨࠢࡳࡰࡦࡿ࡬ࡪࡵࡷࠤ࡚ࡘࡌࠡࡵࡨࡸࡹ࡯࡮ࡨࠩॿ"))
        return []
    try:
        if l11l1lll1_opy_ == l111l1_opy_ (u"ࠪࡊࡎࡒࡅࡔࠩঀ"):
            with open(url) as content:
                return content.readlines()
    except:
        dixie.log(l111l1_opy_ (u"ࠫࡊࡘࡒࡐࡔࠣࡶࡪࡧࡤࡪࡰࡪࠤࡵࡲࡡࡺ࡮࡬ࡷࡹࠦࡆࡊࡎࡈࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠬঁ"))
        return []
def l1l11l1l1_opy_(l1l1l1l1l_opy_, l1l11l11l_opy_, l11ll1ll1_opy_, l1l11ll11_opy_, l1l1l1ll1_opy_):
    url  = l111l1_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭ং")
    url +=  l1l1l1l1l_opy_
    url +=  l11ll11ll_opy_(l1l11l11l_opy_)
    url += l111l1_opy_ (u"࠭࠯ࡨࡧࡷ࠲ࡵ࡮ࡰࡀࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠫঃ")
    url +=  l1l11ll11_opy_
    url += l111l1_opy_ (u"ࠧࠧࡲࡤࡷࡸࡽ࡯ࡳࡦࡀࠫ঄")
    url +=  l1l1l1ll1_opy_
    url += l111l1_opy_ (u"ࠨࠨࡷࡽࡵ࡫࠽࡮࠵ࡸࡣࡵࡲࡵࡴࠨࡲࡹࡹࡶࡵࡵ࠿ࠪঅ")
    url +=  l11ll11l1_opy_(l11ll1ll1_opy_)
    return url
def l11ll11ll_opy_(l1l11l11l_opy_):
    if not l1l11l11l_opy_ == l111l1_opy_ (u"ࠩࠪআ"):
        return l111l1_opy_ (u"ࠪ࠾ࠬই") + l1l11l11l_opy_
    return l111l1_opy_ (u"ࠫࠬঈ")
def l11ll11l1_opy_(l11ll1ll1_opy_):
    if l11ll1ll1_opy_ == l111l1_opy_ (u"ࠬ࠶ࠧউ"):
        return l111l1_opy_ (u"࠭࡭࠴ࡷ࠻ࠫঊ")
    if l11ll1ll1_opy_ == l111l1_opy_ (u"ࠧ࠲ࠩঋ"):
        return l111l1_opy_ (u"ࠨ࡯ࡳࡩ࡬ࡺࡳࠨঌ")
if __name__ == l111l1_opy_ (u"ࠩࡢࡣࡲࡧࡩ࡯ࡡࡢࠫ঍"):
    l11ll1111_opy_()