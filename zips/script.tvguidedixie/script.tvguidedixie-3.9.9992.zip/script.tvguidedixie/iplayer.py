# coding: UTF-8
import sys
l1l1ll11_opy_ = sys.version_info [0] == 2
l111lll_opy_ = 2048
l1l1lll1_opy_ = 7
def l1l1l_opy_ (l1l111_opy_):
	global l11l11l_opy_
	l11111l_opy_ = ord (l1l111_opy_ [-1])
	l1l1llll_opy_ = l1l111_opy_ [:-1]
	l1l111l_opy_ = l11111l_opy_ % len (l1l1llll_opy_)
	l11l11_opy_ = l1l1llll_opy_ [:l1l111l_opy_] + l1l1llll_opy_ [l1l111l_opy_:]
	if l1l1ll11_opy_:
		l1111_opy_ = unicode () .join ([unichr (ord (char) - l111lll_opy_ - (l1lll_opy_ + l11111l_opy_) % l1l1lll1_opy_) for l1lll_opy_, char in enumerate (l11l11_opy_)])
	else:
		l1111_opy_ = str () .join ([chr (ord (char) - l111lll_opy_ - (l1lll_opy_ + l11111l_opy_) % l1l1lll1_opy_) for l1lll_opy_, char in enumerate (l11l11_opy_)])
	return eval (l1111_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
import mapping
ADDON    = dixie.ADDON
l1ll11ll_opy_ = dixie.PROFILE
l111l11_opy_  = os.path.join(l1ll11ll_opy_, l1l1l_opy_ (u"ࠫ࡮ࡴࡩࠨࠀ"))
l1lllll_opy_    = os.path.join(l111l11_opy_, l1l1l_opy_ (u"ࠬࡳࡡࡱࡲ࡬ࡲ࡬ࡹ࠮࡫ࡵࡲࡲࠬࠁ"))
l111ll_opy_   = os.path.join(l111l11_opy_, l1l1l_opy_ (u"࠭࡭ࡢࡲࡶ࠲࡯ࡹ࡯࡯ࠩࠂ"))
LABELFILE  = os.path.join(l111l11_opy_, l1l1l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱࡹ࠮࡫ࡵࡲࡲࠬࠃ"))
l1l1111l_opy_ = os.path.join(l111l11_opy_, l1l1l_opy_ (u"ࠨࡲࡵࡩ࡫࡯ࡸࡦࡵ࠱࡮ࡸࡵ࡮ࠨࠄ"))
l1ll1ll1_opy_  = json.load(open(l1lllll_opy_))
l1ll1111_opy_      = json.load(open(l111ll_opy_))
labelmaps = json.load(open(LABELFILE))
l111_opy_  = json.load(open(l1l1111l_opy_))
l1l1ll1_opy_ = l1l1l_opy_ (u"ࠩࠪࠅ")
def l1l11l_opy_(i, t1, l1l1l1_opy_=[]):
 t = l1l1ll1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l1l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11_opy_ = l1l11l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11lll_opy_ = l1l11l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1l1lll_opy_       = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡧࡪࡺࡶࠨࠆ")
l1l1l11l_opy_  = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡆࡱࡧࡣ࡬ࡋࡦࡩ࡙࡜ࠧࠇ")
dexter    = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸࠨࠈ")
l1ll1l_opy_   = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡋ࡮ࡥ࡮ࡨࡷࡸ࠭ࠉ")
l1lll1_opy_       = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡦࡢࡤ࡫ࡳࡸࡺࡩ࡯ࡩࠪࠊ")
l1ll1l1l_opy_  = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡇ࡮ࡤࡻࡱ࡫ࡳࡴࡖࡹࠫࠋ")
l1l11ll1_opy_  = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡨࡵࡩࡪࡼࡩࡦࡹࠪࠌ")
l1ll11_opy_    = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡪࡩ࡭ࡵࡳࡵ࡫ࡱ࡫ࠬࠍ")
l1l1l1ll_opy_   = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡬ࡴࡸࡩࡻࡱࡱ࡭ࡵࡺࡶࠨࠎ")
l1ll1_opy_  = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶࡴࡷࡵࡸࡦࡸ࠭ࠏ")
l11l1ll_opy_      = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡰࡩ࡯ࡺࡷࡺ࠷࠭ࠐ")
l1l1l111_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡌࡪ࡯࡬ࡸࡱ࡫ࡳࡴࡋࡓࡘ࡛࠭ࠑ")
l11l_opy_  = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡮ࡣࡷࡶ࡮ࡾࡩࡳࡧ࡯ࡥࡳࡪࠧࠒ")
l1llll11_opy_  = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡏࡤࡸࡸࡈࡵࡪ࡮ࡧࡷࡎࡖࡔࡗࠩࠓ")
l1l11l11_opy_   = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡰࡥࡽ࡯ࡷࡦࡤࡷࡺࠬࠔ")
l11ll11_opy_     = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡱࡨࡱࡴࡷ࠯ࡳࡰࡺࡹࠧࠕ")
l1111l1_opy_      = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡲ࡫ࡧࡢ࡫ࡳࡸࡻ࠭ࠖ")
nice      = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡴࡡࡵࡪࡲࡷࡺࡨࡳࡪࡥࡨࠫࠗ")
l11ll_opy_   = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡰࡳࡧࡰ࡭ࡺࡳࡩࡱࡶࡹࠫ࠘")
l1l11l1l_opy_  = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡱࡵࡤࡨࡩࡵ࡮ࠨ࠙")
root      = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡲࡳࡹࡏࡐࡕࡘࠪࠚ")
l1lll111_opy_     = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡪ࡭ࡿࡳ࡯ࡵࡸࠪࠛ")
l1lll1l_opy_      = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡨࡺࡶࠨࠜ")
l1111ll_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡘࡻࡰࡳࡧࡰࡥࡨࡿࡔࡗࠩࠝ")
l1llll1l_opy_   = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹࡴࡳࡧࡤࡱࡸࡻࡰࡳࡧࡰࡩ࠷࠭ࠞ")
l11ll1l_opy_   = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡴࡸ࡫ࡶࡸࡪࡪࠧࠟ")
l11lll1_opy_   = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡵࡸ࡮࡭ࡳ࡭ࡳࠨࠠ")
l11llll_opy_    = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡷ࡮ࡸࡺࡸ࡫ࠨࠡ")
l1l_opy_     = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡙ࡅࡉࡋࡒࠨࠢ")
l1lll11l_opy_   = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡹࡸࡥࡢ࡯࠰ࡧࡴࡪࡥࡴࠩࠣ")
l1llllll_opy_    = [nice, l11ll_opy_, l1lll111_opy_, l1ll11_opy_, l11lll1_opy_, l11l_opy_, l1lll11l_opy_, l1lll1l_opy_, l1llll1l_opy_, l11llll_opy_, l1l1l111_opy_, l1lll1_opy_, l1l1lll_opy_, l1l1l1ll_opy_, root, l1111l1_opy_, l1l11ll1_opy_, l1ll1_opy_, l11l1ll_opy_, l1ll1l_opy_, l1ll1l1l_opy_, l1l11l11_opy_, dexter, l1l_opy_, l1111ll_opy_, l11ll11_opy_, l11ll1l_opy_, l1l11l1l_opy_, l1l1l11l_opy_]
def checkAddons():
    for addon in l1llllll_opy_:
        if l1l11ll_opy_(addon):
            try: createINI(addon)
            except: continue
def l1l11ll_opy_(addon):
    if xbmc.getCondVisibility(l1l1l_opy_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠦࡵࠬࠫࠤ") % addon) == 1:
        dixie.log(l1l1l_opy_ (u"࠭࠽࠾࠿ࡀࠤࡦࡪࡤࡰࡰࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦ࠽࠾࠿ࡀࠫࠥ"))
        dixie.log(addon)
        return True
    return False
def createINI(addon):
    l1l11111_opy_  = str(addon).split(l1l1l_opy_ (u"ࠧ࠯ࠩࠦ"))[2] + l1l1l_opy_ (u"ࠨ࠰࡬ࡲ࡮࠭ࠧ")
    l1l1ll1l_opy_   = os.path.join(l111l11_opy_, l1l11111_opy_)
    response = l1lllll1_opy_(addon)
    l1l1111_opy_ = response[l1l1l_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩࠨ")][l1l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩࠩ")]
    l1l1ll_opy_  = l1l1l_opy_ (u"ࠫࡠ࠭ࠪ") + addon + l1l1l_opy_ (u"ࠬࡣ࡜࡯ࠩࠫ")
    l1lll1l1_opy_  =  file(l1l1ll1l_opy_, l1l1l_opy_ (u"࠭ࡷࠨࠬ"))
    l1lll1l1_opy_.write(l1l1ll_opy_)
    l1l1l1l1_opy_ = []
    for channel in l1l1111_opy_:
        l11111_opy_ = l1l1l1l_opy_(addon)
        l11ll1_opy_  = channel[l1l1l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭࠭")].split(l1l1l_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ࠮"), 1)[0]
        if addon == dexter:
            l11ll1_opy_ = l11ll1_opy_.split(l1l1l_opy_ (u"ࠩࠣ࠯ࠥ࠭࠯"), 1)[0]
        if (addon == nice) or (addon == l1lll111_opy_) or (addon == root) or (addon == l1l1l111_opy_) or (addon == l11lll1_opy_) or (addon == l1ll11_opy_):
            l11ll1_opy_ = l11ll1_opy_.split(l1l1l_opy_ (u"ࠪࠤ࠲ࠦࠧ࠰"), 1)[0]
        l1llll_opy_ = l111l_opy_(addon, l11ll1_opy_)
        l11l1l_opy_ = l111111_opy_(addon, l111_opy_, labelmaps, l1ll1ll1_opy_, l1ll1111_opy_, l11ll1_opy_)
        stream  = l11111_opy_ + l1llll_opy_
        l111l1_opy_ = l11l1l_opy_  + l1l1l_opy_ (u"ࠫࡂ࠭࠱") + stream
        if l111l1_opy_ not in l1l1l1l1_opy_:
            l1l1l1l1_opy_.append(l111l1_opy_)
    l1l1l1l1_opy_.sort()
    for item in l1l1l1l1_opy_:
        l1lll1l1_opy_.write(l1l1l_opy_ (u"ࠧࠫࡳ࡝ࡰࠥ࠲") % item)
    l1lll1l1_opy_.close()
def l111l_opy_(addon, l11ll1_opy_):
    if (addon == nice) or (addon == l11ll_opy_) or (addon == l1lll111_opy_) or (addon == root) or (addon == l1l1l111_opy_) or (addon == l1lll1_opy_) or (addon == l1lll11l_opy_) or (addon == l11l_opy_) or (addon == l11lll1_opy_) or (addon == l1ll11_opy_):
        l1l1l11_opy_ = mapping.cleanLabel(l11ll1_opy_)
        l1llll_opy_ = mapping.editPrefix(l111_opy_, l1l1l11_opy_)
        return l1llll_opy_
    l1l1l11_opy_ = mapping.cleanLabel(l11ll1_opy_)
    l1llll_opy_ = mapping.cleanStreamLabel(l1l1l11_opy_)
    return l1llll_opy_
def l111111_opy_(addon, l111_opy_, labelmaps, l1ll1ll1_opy_, l1ll1111_opy_, l11ll1_opy_):
    if (addon == nice) or (addon == l11ll_opy_) or (addon == l1lll111_opy_) or (addon == root) or (addon == l1l1l111_opy_) or (addon == l1lll1_opy_) or (addon == l1lll11l_opy_) or (addon == l11l_opy_) or (addon == l11lll1_opy_) or (addon == l1ll11_opy_):
        return l1l11lll_opy_(l111_opy_, l1ll1111_opy_, l11ll1_opy_)
    l1llll1_opy_    = mapping.cleanLabel(l11ll1_opy_)
    l1l1l11_opy_ = mapping.mapLabel(labelmaps, l1llll1_opy_)
    l11l1l_opy_ = mapping.cleanPrefix(l1l1l11_opy_)
    return mapping.mapChannelName(l1ll1ll1_opy_, l11l1l_opy_)
def l1l11lll_opy_(l111_opy_, l1ll1111_opy_, l11ll1_opy_):
    l1l1_opy_ = mapping.cleanLabel(l11ll1_opy_)
    l1l1l11_opy_   = mapping.editPrefix(l111_opy_, l1l1_opy_)
    l11l111_opy_   = mapping.mapEPGLabel(l111_opy_, l1ll1111_opy_, l1l1l11_opy_)
    return l11l111_opy_
def l1ll_opy_(addon, file):
    l1llll1_opy_ = file[l1l1l_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬ࠳")].split(l1l1l_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࠴"), 1)[0]
    l1llll1_opy_ = l1llll1_opy_.split(l1l1l_opy_ (u"ࠨ࠭ࠪ࠵"), 1)[0]
    l1llll1_opy_ = mapping.cleanLabel(l1llll1_opy_)
    return l1llll1_opy_
def l1l1l1l_opy_(addon):
    if addon == nice:
        return l1l1l_opy_ (u"ࠩࡑࡍࡈࡋ࠺ࠨ࠶")
    if addon == l11ll_opy_:
        return l1l1l_opy_ (u"ࠪࡔࡗࡋࡍ࠻ࠩ࠷")
    if addon == l1lll111_opy_:
        return l1l1l_opy_ (u"ࠫࡌࡏ࡚࠻ࠩ࠸")
    if addon == l1ll11_opy_:
        return l1l1l_opy_ (u"ࠬࡍࡅࡉ࠼ࠪ࠹")
    if addon == l11lll1_opy_:
        return l1l1l_opy_ (u"࠭ࡔࡗࡍ࠽ࠫ࠺")
    if addon == l11l_opy_:
        return l1l1l_opy_ (u"ࠧࡎࡖ࡛ࡍࡊࡀࠧ࠻")
    if addon == l1lll11l_opy_:
        return l1l1l_opy_ (u"ࠨ࡚ࡗࡇ࠿࠭࠼")
    if addon == l1lll1l_opy_:
        return l1l1l_opy_ (u"ࠩࡖࡇ࡙࡜࠺ࠨ࠽")
    if addon == l1llll1l_opy_:
        return l1l1l_opy_ (u"ࠪࡗ࡚ࡖ࠺ࠨ࠾")
    if addon == l11llll_opy_:
        return l1l1l_opy_ (u"࡚ࠫࡑࡔ࠻ࠩ࠿")
    if addon == l1l1l111_opy_:
        return l1l1l_opy_ (u"ࠬࡒࡉࡎࡋࡗ࠾ࠬࡀ")
    if addon == l1lll1_opy_:
        return l1l1l_opy_ (u"࠭ࡆࡂࡄ࠽ࠫࡁ")
    if addon == l1l1lll_opy_:
        return l1l1l_opy_ (u"ࠧࡂࡅࡈ࠾ࠬࡂ")
    if addon == l1l1l1ll_opy_:
        return l1l1l_opy_ (u"ࠨࡊࡒࡖࡎࡠ࠺ࠨࡃ")
    if addon == root:
        return l1l1l_opy_ (u"ࠩࡕࡓࡔ࡚࠲࠻ࠩࡄ")
    if addon == l1111l1_opy_:
        return l1l1l_opy_ (u"ࠪࡑࡊࡍࡁ࠻ࠩࡅ")
    if addon == l1l11ll1_opy_:
        return l1l1l_opy_ (u"ࠫࡋࡘࡅࡆ࠼ࠪࡆ")
    if addon == l1llll11_opy_:
        return l1l1l_opy_ (u"ࠬࡓࡁࡕࡕ࠽ࠫࡇ")
    if addon == l1ll1_opy_:
        return l1l1l_opy_ (u"࠭ࡉࡑࡖࡖ࠾ࠬࡈ")
    if addon == l11l1ll_opy_:
        return l1l1l_opy_ (u"ࠧࡋࡋࡑ࡜࠷ࡀࠧࡉ")
    if addon == l1ll1l_opy_:
        return l1l1l_opy_ (u"ࠨࡇࡑࡈ࠿࠭ࡊ")
    if addon == l1ll1l1l_opy_:
        return l1l1l_opy_ (u"ࠩࡉࡐࡆࡀࠧࡋ")
    if addon == l1l11l11_opy_:
        return l1l1l_opy_ (u"ࠪࡑࡆ࡞ࡉ࠻ࠩࡌ")
    if addon == dexter:
        return l1l1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡇ࠾ࠬࡍ")
    if addon == l1l_opy_:
        return l1l1l_opy_ (u"ࠬ࡜ࡄࡓࡖ࡙࠾ࠬࡎ")
    if addon == l1111ll_opy_:
        return l1l1l_opy_ (u"࠭ࡓࡑࡔࡐ࠾ࠬࡏ")
    if addon == l11ll11_opy_:
        return l1l1l_opy_ (u"ࠧࡎࡅࡎࡘ࡛ࡀࠧࡐ")
    if addon == l11ll1l_opy_:
        return l1l1l_opy_ (u"ࠨࡖ࡚ࡍࡘ࡚࠺ࠨࡑ")
    if addon == l1l11l1l_opy_:
        return l1l1l_opy_ (u"ࠩࡓࡖࡊ࡙ࡔ࠻ࠩࡒ")
    if addon == l1l1l11l_opy_:
        return l1l1l_opy_ (u"ࠪࡆࡑࡑࡉ࠻ࠩࡓ")
def getURL(url):
    if url.startswith(l1l1l_opy_ (u"ࠫࡓࡏࡃࡆࠩࡔ")):
        return ll_opy_(url, nice)
    if url.startswith(l1l1l_opy_ (u"ࠬࡖࡒࡆࡏࠪࡕ")):
        return ll_opy_(url, l11ll_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡇࡊ࡜ࠪࡖ")):
        return ll_opy_(url, l1lll111_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡈࡇࡋࠫࡗ")):
        return ll_opy_(url, l1ll11_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡖ࡙ࡏࠬࡘ")):
        return ll_opy_(url, l11lll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡐࡘ࡝ࡏࡅࠨ࡙")):
        return ll_opy_(url, l11l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪ࡜࡙ࡉ࡚ࠧ")):
        return ll_opy_(url, l1lll11l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡘࡉࡔࡗ࡛ࠩ")):
        return ll_opy_(url, l1lll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"࡙ࠬࡕࡑࠩ࡜")):
        return ll_opy_(url, l1llll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡕࡌࡖࠪ࡝")):
        return ll_opy_(url, l11llll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡍࡋࡐࡍ࡙࠭࡞")):
        return ll_opy_(url, l1l1l111_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡈࡄࡆࠬ࡟")):
        return ll_opy_(url, l1lll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡄࡇࡊ࠭ࡠ")):
        return ll_opy_(url, l1l1lll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡌࡔࡘࡉ࡛ࠩࡡ")):
        return ll_opy_(url, l1l1l1ll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡗࡕࡏࡕ࠴ࠪࡢ")):
        return ll_opy_(url, root)
    if url.startswith(l1l1l_opy_ (u"ࠬࡓࡅࡈࡃࠪࡣ")):
        return ll_opy_(url, l1111l1_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡆࡓࡇࡈࠫࡤ")):
        return ll_opy_(url, l1l11ll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡉࡌࡖ࠼ࠪࡥ")):
        url = url.replace(l1l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡃࡍࡗ࠽ࠫࡦ"), l1l1l_opy_ (u"ࠩࠪࡧ")).replace(l1l1l_opy_ (u"ࠪ࠱࠲ࡻࡳࡦࡴ࠰ࡥ࡬࡫࡮ࡵࠩࡨ"), l1l1l_opy_ (u"ࠫࢁࡻࡳࡦࡴ࠰ࡥ࡬࡫࡮ࡵࠩࡩ"))
        return url
    if url.startswith(l1l1l_opy_ (u"ࠬࡓࡁࡕࡕࠪࡪ")):
        return ll_opy_(url, l1llll11_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡉࡑࡖࡖࠫ࡫")):
        return ll_opy_(url, l1ll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡋࡋࡑ࡜࠷࠭࡬")):
        return ll_opy_(url, l11l1ll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡄࠨ࡭")):
        return ll_opy_(url, dexter)
    if url.startswith(l1l1l_opy_ (u"ࠩࡉࡐࡆ࠭࡮")):
        return ll_opy_(url, l1ll1l1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡑࡆ࡞ࡉࠨ࡯")):
        return ll_opy_(url, l1l11l11_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡊࡔࡄࠨࡰ")):
        return ll_opy_(url, l1ll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬ࡜ࡄࡓࡖ࡙ࠫࡱ")):
        return ll_opy_(url, l1l_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡓࡑࡔࡐࠫࡲ")):
        return ll_opy_(url, l1111ll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡎࡅࡎࡘ࡛࠭ࡳ")):
        return ll_opy_(url, l11ll11_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡖ࡚ࡍࡘ࡚ࠧࡴ")):
        return ll_opy_(url, l11ll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡓࡖࡊ࡙ࡔࠨࡵ")):
        return ll_opy_(url, l1l11l1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡆࡑࡑࡉࠨࡶ")):
        return ll_opy_(url, l1l1l11l_opy_)
    response  = l11lllll_opy_(url)
    l1ll1ll_opy_ = url.split(l1l1l_opy_ (u"ࠫ࠿࠭ࡷ"), 1)[-1]
    l1ll1ll_opy_ = l1ll1ll_opy_.upper().replace(l1l1l_opy_ (u"ࠬࠦࠧࡸ"), l1l1l_opy_ (u"࠭ࠧࡹ"))
    try:
        result = response[l1l1l_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧࡺ")]
        l11l1l1_opy_  = result[l1l1l_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧࡻ")]
    except Exception as e:
        l1l111ll_opy_(e)
        return None
    for file in l11l1l1_opy_:
        l11ll1_opy_  = file[l1l1l_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨࡼ")].split(l1l1l_opy_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࡽ"), 1)[0]
        l1ll1l1_opy_  = l11ll1_opy_.split(l1l1l_opy_ (u"ࠫ࠰࠭ࡾ"), 1)[0]
        l1ll11l_opy_ = mapping.cleanLabel(l1ll1l1_opy_)
        l1ll11l_opy_ = l1ll11l_opy_.upper().replace(l1l1l_opy_ (u"ࠬࠦࠧࡿ"), l1l1l_opy_ (u"࠭ࠧࢀ"))
        try:
            if l1ll1ll_opy_ == l1ll11l_opy_:
                return file[l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࠬࢁ")]
        except:
            if (l1ll1ll_opy_ in l1ll11l_opy_) or (l1ll11l_opy_ in l1ll1ll_opy_):
                return file[l1l1l_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ࢂ")]
    return None
def ll_opy_(url, addon):
    PATH = l1lll1ll_opy_(addon)
    try:
        response = json.load(open(PATH))
    except:
        response = l1lllll1_opy_(addon)
    l1l11l1_opy_      = url.split(l1l1l_opy_ (u"ࠩ࠽ࠫࢃ"), 1)[-1]
    stream    = l1l11l1_opy_.split(l1l1l_opy_ (u"ࠪࠤࡠ࠭ࢄ"), 1)[0]
    l1ll1ll_opy_ = mapping.cleanLabel(stream)
    l1ll1ll_opy_ = l1ll1ll_opy_.upper().replace(l1l1l_opy_ (u"ࠫࠥ࠭ࢅ"), l1l1l_opy_ (u"ࠬ࠭ࢆ"))
    l11l1l1_opy_  = response[l1l1l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࢇ")][l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭࢈")]
    for file in l11l1l1_opy_:
        l11ll1_opy_  = file[l1l1l_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࢉ")].split(l1l1l_opy_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࢊ"), 1)[0]
        if addon == dexter:
            l11ll1_opy_ = l11ll1_opy_.split(l1l1l_opy_ (u"ࠪࠤ࠰ࠦࠧࢋ"), 1)[0]
        if (addon == nice) or (addon == l1lll111_opy_) or (addon == root) or (addon == l1l1l111_opy_) or (addon == l11lll1_opy_) or (addon == l1ll11_opy_):
            l11ll1_opy_ = l11ll1_opy_.split(l1l1l_opy_ (u"ࠫࠥ࠳ࠠࠨࢌ"), 1)[0]
        l1ll11l_opy_ = l111l_opy_(addon, l11ll1_opy_)
        l1ll11l_opy_ = l1ll11l_opy_.upper().replace(l1l1l_opy_ (u"ࠬࠦࠧࢍ"), l1l1l_opy_ (u"࠭ࠧࢎ"))
        try:
            if l1ll1ll_opy_ == l1ll11l_opy_:
                return file[l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࠬ࢏")]
        except:
            if (l1ll1ll_opy_ in l1ll11l_opy_) or (l1ll11l_opy_ in l1ll1ll_opy_):
                return file[l1l1l_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭࢐")]
    return None
def l1lllll1_opy_(addon):
    PATH  = l1lll1ll_opy_(addon)
    if addon == l1l_opy_:
        query = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡚ࡆࡊࡅࡓ࠱࡯࡭ࡻ࡫ࡴࡷ࠱ࡤࡰࡱ࠵ࠧ࢑")
    elif addon == l1llll1l_opy_:
        query = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡺࡲࡦࡣࡰࡷࡺࡶࡲࡦ࡯ࡨ࠶࠴ࡲࡩࡷࡧࡷࡺ࠴ࡧ࡬࡭࠱ࠪ࢒")
    elif addon == l1lll1l_opy_:
        query = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹࡣࡵࡸ࠲ࡰ࡮ࡼࡥࡵࡸ࠲ࡥࡱࡲ࠯ࠨ࢓")
    elif addon == l1llll1l_opy_:
        query = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡵࡴࡨࡥࡲࡹࡵࡱࡴࡨࡱࡪ࠸࠯࡭࡫ࡹࡩࡹࡼ࠯ࡢ࡮࡯࠳ࠬ࢔")
    elif addon == l1l11ll1_opy_:
        query = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡧࡴࡨࡩࡻ࡯ࡥࡸ࠱ࡂࡹࡷࡲ࠽ࡶࡴ࡯ࠪࡲࡵࡤࡦ࠿࠸ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡻ࡫ࠫࡕࡘࠪ࢕")
    elif addon == l11llll_opy_:
        query = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡷ࡮ࡸࡺࡸ࡫࠰ࡁࡸࡶࡱࡃࡨࡵࡶࡳࠩ࠸ࡇࠥ࠳ࡈࠨ࠶ࡋࡧࡤࡥࡱࡱࡧࡱࡵࡵࡥ࠰ࡲࡶ࡬ࠫ࠲ࡇࡷ࡮ࡸࡺࡸ࡫ࠦ࠴ࡉ࡙ࡐ࡚ࡵࡳ࡭ࠨ࠶ࡋࡒࡩࡷࡧࠨ࠶࠺࠸࠰ࡕࡘ࠱ࡸࡽࡺࠦ࡮ࡱࡧࡩࡂ࠷ࠦ࡯ࡣࡰࡩࡂࡒࡩࡷࡧ࠮ࡘ࡛ࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࡁࠫ࡬ࡡ࡯ࡣࡵࡸࡂࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࠪ࢖")
    else:
        query = l1ll1lll_opy_(addon)
    try:
        return json.load(open(PATH))
    except:
        content = doJSON(query)
        return l1l11_opy_(PATH, addon, content)
def l1l11_opy_(PATH, addon, content):
    json.dump(content, open(PATH,l1l1l_opy_ (u"ࠨࡹࠪࢗ")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    l1ll111_opy_  = (l1l1l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬ࢘") % query)
    response = xbmc.executeJSONRPC(l1ll111_opy_)
    content  = json.loads(response)
    return content
def l1lll1ll_opy_(addon):
    if addon == nice:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡲ࡮ࡩࡥࡵࡧࡰࡴ࢙ࠬ"))
    if addon == l11ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡵࡸࡥ࡮ࡶࡨࡱࡵ࢚࠭"))
    if addon == l1lll111_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬ࡭ࡩࡻࡶࡨࡱࡵ࢛࠭"))
    if addon == l1ll11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡧࡦࡶࡨࡱࡵ࠭࢜"))
    if addon == l11l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧ࡮ࡶࡻࡸࡪࡳࡰࠨ࢝"))
    if addon == l11lll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡶࡹ࡯ࡹ࡫࡭ࡱࠩ࢞"))
    if addon == l1lll11l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡻࡸࡪࡳࡰࠨ࢟"))
    if addon == l1lll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡷࡨࡺࡥ࡮ࡲࠪࢠ"))
    if addon == l1llll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡸࡻࡰࡵࡧࡰࡴࠬࢡ"))
    if addon == l11llll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡻ࡫ࡵࡶࡨࡱࡵ࠭ࢢ"))
    if addon == l1l1l111_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭࡬ࡪ࡯࡬ࡸࡪࡳࡰࠨࢣ"))
    if addon == l1lll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡧࡣࡥࡸࡪࡳࡰࠨࢤ"))
    if addon == l1l1lll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡣࡦࡩࡹ࡫࡭ࡱࠩࢥ"))
    if addon == l1l1l1ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩ࡫ࡳࡷࡺࡥ࡮ࡲࠪࢦ"))
    if addon == root:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡶࡴ࠸ࡴࡦ࡯ࡳࠫࢧ"))
    if addon == l1111l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡲ࡫ࡧࡢࡶࡰࡴࠬࢨ"))
    if addon == l1llll11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡳࡡࡵࡵࡷࡱࡵ࠭ࢩ"))
    if addon == l1l11ll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡦࡳࡧࡨࡸࡲࡶࠧࢪ"))
    if addon == l1ll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡪࡲࡷࡷࡹࡳࡰࠨࢫ"))
    if addon == l11l1ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨ࡬࠵ࡸࡪࡳࡰࠨࢬ"))
    if addon == l1ll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡨࡸࡪࡳࡰࠨࢭ"))
    if addon == l1ll1l1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡪࡹ࡫࡭ࡱࠩࢮ"))
    if addon == l1l11l11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡲࡧࡸࡵࡧࡰࡴࠬࢯ"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡪࡴࡦ࡯ࡳࠫࢰ"))
    if addon == l1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡶࡥࡶࡨࡱࡵ࠭ࢱ"))
    if addon == l1111ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡴࡲࡵࡸࡪࡳࡰࠨࢲ"))
    if addon == l11ll11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨ࡯ࡦ࡯ࡹ࡫࡭ࡱࠩࢳ"))
    if addon == l11ll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡷࡻ࡮ࡺࡥ࡮ࡲࠪࢴ"))
    if addon == l1l11l1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡴࡷ࡫ࡳࡵࡧࡰࡴࠬࢵ"))
    if addon == l1l1l11l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡧࡲ࡫ࡪࡶࡨࡱࡵ࠭ࢶ"))
def l1ll1lll_opy_(addon):
    query = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨࢷ") + addon
    response = doJSON(query)
    l11l1l1_opy_    = response[l1l1l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࢸ")][l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࢹ")]
    for file in l11l1l1_opy_:
        l111ll1_opy_ = file[l1l1l_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࢺ")]
        l1llll1_opy_ = mapping.cleanLabel(l111ll1_opy_)
        l1llll1_opy_ = l1llll1_opy_.upper()
        if (l1llll1_opy_ == l1l1l_opy_ (u"ࠩࡏࡍ࡛ࡋࠠࡊࡒࡗ࡚ࠬࢻ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠪࡐࡎ࡜ࡅࠡࡖ࡙ࠫࢼ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠫࡑࡏࡖࡆࠢࡆࡌࡆࡔࡎࡆࡎࡖࠫࢽ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠬࡒࡉࡗࡇࠪࢾ")) or (l1llll1_opy_ == l1l1l_opy_ (u"࠭ࡅࡏࡆࡏࡉࡘ࡙ࠠࡎࡇࡇࡍࡆ࠭ࢿ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠧࡇࡎࡄ࡛ࡑࡋࡓࡔࡖ࡙ࠫࣀ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠨࡏࡄ࡜ࡎ࡝ࡅࡃࠢࡗ࡚ࠬࣁ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠩࡅࡐࡆࡉࡋࡊࡅࡈࠤ࡙࡜ࠧࣂ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠪࡌࡔࡘࡉ࡛ࡑࡑࠤࡎࡖࡔࡗࠩࣃ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠫࡋࡇࡂࠡࡋࡓࡘ࡛࠭ࣄ")):
            livetv = file[l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪࣅ")]
            return l1111l_opy_(livetv)
def l1111l_opy_(livetv):
    response = doJSON(livetv)
    l11l1l1_opy_    = response[l1l1l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࣆ")][l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࣇ")]
    for file in l11l1l1_opy_:
        l111ll1_opy_ = file[l1l1l_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࣈ")]
        l1llll1_opy_ = mapping.cleanLabel(l111ll1_opy_)
        l1llll1_opy_ = l1llll1_opy_.upper()
        if l1llll1_opy_ == l1l1l_opy_ (u"ࠩࡄࡐࡑ࠭ࣉ"):
            return file[l1l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࠨ࣊")]
def l1lll11_opy_(l11l1_opy_):
    items = []
    _111l1l_opy_(l11l1_opy_, items)
    return items
def _111l1l_opy_(l11l1_opy_, items):
    response = doJSON(l11l1_opy_)
    if response[l1l1l_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫ࣋")].has_key(l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫ࣌")):
        result = response[l1l1l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭࣍")][l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭࣎")]
        for item in result:
            if item[l1l1l_opy_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧ࣏ࠪ")] == l1l1l_opy_ (u"ࠩࡩ࡭ࡱ࡫࣐ࠧ"):
                l1llll1_opy_ = mapping.cleanLabel(item[l1l1l_opy_ (u"ࠪࡰࡦࡨࡥ࡭࣑ࠩ")])
                items.append(item)
            elif item[l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࣒࠭")] == l1l1l_opy_ (u"ࠬࡪࡩࡳࡧࡦࡸࡴࡸࡹࠨ࣓"):
                l1llll1_opy_ = mapping.cleanLabel(item[l1l1l_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬࣔ")])
                l1l111l1_opy_  = item[l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࠬࣕ")]
                dixie.log(item)
                dixie.log(l1l111l1_opy_)
                _111l1l_opy_(l1l111l1_opy_, items)
def l11lllll_opy_(url):
    if url.startswith(l1l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠺ࠨࣖ")):
        l1ll111_opy_ = (l1l1l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡨࡢࡤ࡫ࡳࡰࡦࡿࡥࡳ࠱ࡂࡹࡷࡲ࠽ࡶࡴ࡯ࠪࡲࡵࡤࡦ࠿࠵ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡻ࡫ࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠩࡍࡕࡏࡄ࠾ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࣗ"))
    if url.startswith(l1l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠴࠽ࠫࣘ")):
        l1ll111_opy_ = (l1l1l_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺ࠳ࡄࡻࡲ࡭࠿ࡸࡶࡱࠬ࡭ࡰࡦࡨࡁ࠶࠶࠱ࠧࡰࡤࡱࡪࡃࡗࡢࡶࡦ࡬࠰ࡒࡩࡷࡧࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࡂࠬࡳࡶࡤࡷ࡭ࡹࡲࡥࡴࡡࡸࡶࡱࡃࠦ࡭ࡱࡪ࡫ࡪࡪ࡟ࡪࡰࡀࡊࡦࡲࡳࡦࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࣙ"))
    if url.startswith(l1l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖ࠿࠭ࣚ")):
        l1ll111_opy_ = (l1l1l_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠵࠿ࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠫࡲ࡯ࡨࡩࡨࡨࡤ࡯࡮࠾ࡈࡤࡰࡸ࡫ࠦ࡮ࡱࡧࡩࡂ࠷࠱࠴ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡶࡸࡪࡴࠥ࠳࠲ࡏ࡭ࡻ࡫ࠦࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡵࡢࡹࡷࡲࠦࡶࡴ࡯ࡁࡺࡸ࡬ࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ࣛ"))
    if url.startswith(l1l1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡏࡔࡗ࠼ࠪࣜ")):
        l1ll111_opy_ = (l1l1l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡺࡶࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ࣝ"))
    if url.startswith(l1l1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪࣞ")):
        l1ll111_opy_ = (l1l1l_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡤࡦࡺ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡦࡲ࡬ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠦࡵ࡫ࡷࡰࡪࡃࠥ࠶ࡤࡆࡓࡑࡕࡒࠦ࠴࠳ࡻ࡭࡯ࡴࡦࠧ࠸ࡨࡆࡲ࡬ࠦ࠴࠳ࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠪ࠻ࡢࠦ࠴ࡩࡇࡔࡒࡏࡓࠧ࠸ࡨࠫࡻࡲ࡭ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࣟ"))
    if url.startswith(l1l1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡕࡆ࠿࠭࣠")):
        l1ll111_opy_ = (l1l1l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡨࡦࡴࡵࡴ࠰ࡁࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠦࡧࡣࡱࡥࡷࡺ࠽ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡳ࡯ࡥࡧࡀ࠻ࠫࡶࡩ࡭࡮ࡲࡻࡂࡒࡩࡷࡧࠨ࠶࠵࡙ࡴࡳࡧࡤࡱࡸࠬࡵࡳ࡮ࡀࡶࡦࡴࡤࡰ࡯ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ࣡"))
    try:
        dixie.ShowBusy()
        addon =  l1ll111_opy_.split(l1l1l_opy_ (u"࠭࠯࠰ࠩ࣢"), 1)[-1].split(l1l1l_opy_ (u"ࠧ࠰ࣣࠩ"), 1)[0]
        login = l1l1l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ࣤ") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1ll111_opy_)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1l111ll_opy_(e)
        return {l1l1l_opy_ (u"ࠩࡈࡶࡷࡵࡲࠨࣥ") : l1l1l_opy_ (u"ࠪࡔࡱࡻࡧࡪࡰࠣࡉࡷࡸ࡯ࡳࣦࠩ")}
def l1ll111l_opy_():
    modules = map(__import__, [l1l11l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l1l1l_opy_ (u"࡙ࠫࡸࡵࡦࠩࣧ")
    if len(modules[-1].Window(10**4).getProperty(l11lll_opy_)):
        return l1l1l_opy_ (u"࡚ࠬࡲࡶࡧࠪࣨ")
    return l1l1l_opy_ (u"࠭ࡆࡢ࡮ࡶࡩࣩࠬ")
def l1l111ll_opy_(e):
    l1ll11l1_opy_ = l1l1l_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠲ࠠࡢࡰࠣࡩࡷࡸ࡯ࡳࠢࡲࡧࡨࡻࡲࡦࡦ࠽ࠤࡏ࡙ࡏࡏࠢࡈࡶࡷࡵࡲ࠻ࠢࠨࡷࠬ࣪")  %e
    l1_opy_ = l1l1l_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡴࡨ࠱ࡱ࡯࡮࡬ࠢࡷ࡬࡮ࡹࠠࡤࡪࡤࡲࡳ࡫࡬ࠡࡣࡱࡨࠥࡺࡲࡺࠢࡤ࡫ࡦ࡯࡮࠯ࠩ࣫")
    l1ll1l11_opy_ = l1l1l_opy_ (u"ࠩࡘࡷࡪࡀࠠࡄࡱࡱࡸࡪࡾࡴࠡࡏࡨࡲࡺࠦ࠽࠿ࠢࡕࡩࡲࡵࡶࡦࠢࡖࡸࡷ࡫ࡡ࡮ࠩ࣬")
    dixie.log(e)
    dixie.DialogOK(l1ll11l1_opy_, l1_opy_, l1ll1l11_opy_)
if __name__ == l1l1l_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣ࣭ࠬ"):
    checkAddons()