# coding: UTF-8
import sys
l1ll111l_opy_ = sys.version_info [0] == 2
l11l1l1_opy_ = 2048
l1llll11_opy_ = 7
def l1ll1_opy_ (l1l1ll_opy_):
	global l11ll11_opy_
	l11l11_opy_ = ord (l1l1ll_opy_ [-1])
	l1ll11ll_opy_ = l1l1ll_opy_ [:-1]
	l1l11ll_opy_ = l11l11_opy_ % len (l1ll11ll_opy_)
	l11lll_opy_ = l1ll11ll_opy_ [:l1l11ll_opy_] + l1ll11ll_opy_ [l1l11ll_opy_:]
	if l1ll111l_opy_:
		l11l1_opy_ = unicode () .join ([unichr (ord (char) - l11l1l1_opy_ - (l111_opy_ + l11l11_opy_) % l1llll11_opy_) for l111_opy_, char in enumerate (l11lll_opy_)])
	else:
		l11l1_opy_ = str () .join ([chr (ord (char) - l11l1l1_opy_ - (l111_opy_ + l11l11_opy_) % l1llll11_opy_) for l111_opy_, char in enumerate (l11lll_opy_)])
	return eval (l11l1_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
import mapping
ADDON    = dixie.ADDON
l1_opy_ = dixie.PROFILE
l111lll_opy_  = os.path.join(l1_opy_, l1ll1_opy_ (u"ࠫ࡮ࡴࡩࠨࠀ"))
l1111l_opy_    = os.path.join(l111lll_opy_, l1ll1_opy_ (u"ࠬࡳࡡࡱࡲ࡬ࡲ࡬ࡹ࠮࡫ࡵࡲࡲࠬࠁ"))
l11ll1_opy_   = os.path.join(l111lll_opy_, l1ll1_opy_ (u"࠭࡭ࡢࡲࡶ࠲࡯ࡹ࡯࡯ࠩࠂ"))
LABELFILE  = os.path.join(l111lll_opy_, l1ll1_opy_ (u"ࠧ࡭ࡣࡥࡩࡱࡹ࠮࡫ࡵࡲࡲࠬࠃ"))
l1l11lll_opy_ = os.path.join(l111lll_opy_, l1ll1_opy_ (u"ࠨࡲࡵࡩ࡫࡯ࡸࡦࡵ࠱࡮ࡸࡵ࡮ࠨࠄ"))
l1lll1l1_opy_  = json.load(open(l1111l_opy_))
l1ll1l11_opy_      = json.load(open(l11ll1_opy_))
labelmaps = json.load(open(LABELFILE))
l11l_opy_  = json.load(open(l1l11lll_opy_))
l1ll111_opy_ = l1ll1_opy_ (u"ࠩࠪࠅ")
def l1ll11_opy_(i, t1, l1ll1l_opy_=[]):
 t = l1ll111_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1ll1l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11_opy_ = l1ll11_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l1l1l1_opy_ = l1ll11_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1lllll_opy_      = l1ll1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡧࡹࡼࠧࠆ")
l111111_opy_   = l1ll1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡹࡸࡥࡢ࡯ࡶࡹࡵࡸࡥ࡮ࡧ࠵ࠫࠇ")
l1l111l_opy_    = l1ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡶࡴ࡮ࠫࠈ")
l1l1ll1l_opy_ = l1ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡒࡩ࡮࡫ࡷࡰࡪࡹࡳࡊࡒࡗ࡚ࠬࠉ")
l1111_opy_       = l1ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡦࡢࡤ࡫ࡳࡸࡺࡩ࡯ࡩࠪࠊ")
l1ll11l_opy_       = l1ll1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡥࡨࡸࡻ࠭ࠋ")
l1ll1111_opy_   = l1ll1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡪࡲࡶ࡮ࢀ࡯࡯࡫ࡳࡸࡻ࠭ࠌ")
root      = l1ll1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡳࡴࡺࡉࡑࡖ࡙ࠫࠍ")
l111l1l_opy_      = l1ll1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡱࡪ࡭ࡡࡪࡲࡷࡺࠬࠎ")
l111l11_opy_  = l1ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡫ࡸࡥࡦࡸ࡬ࡩࡼ࠭ࠏ")
l1llllll_opy_  = l1ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡓࡡࡵࡵࡅࡹ࡮ࡲࡤࡴࡋࡓࡘ࡛࠭ࠐ")
l1ll1111_opy_   = l1ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡨࡰࡴ࡬ࡾࡴࡴࡩࡱࡶࡹࠫࠑ")
l1lll_opy_  = l1ll1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲࡷࡺࡸࡻࡢࡴࠩࠒ")
l11lll1_opy_      = l1ll1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡬࡬ࡲࡽࡺࡶ࠳ࠩࠓ")
l1llll_opy_   = l1ll1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡈࡲࡩࡲࡥࡴࡵࠪࠔ")
l1lll11l_opy_  = l1ll1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡊࡱࡧࡷ࡭ࡧࡶࡷ࡙ࡼࠧࠕ")
l1l1l1l1_opy_   = l1ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡲࡧࡸࡪࡹࡨࡦࡹࡼࠧࠖ")
dexter    = l1ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡪࡥࡹࠩࠗ")
l1l_opy_     = l1ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡖࡂࡆࡈࡖࠬ࠘")
l111ll1_opy_ = l1ll1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡔࡷࡳࡶࡪࡳࡡࡤࡻࡗ࡚ࠬ࠙")
l11llll_opy_     = l1ll1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡯ࡦ࡯ࡹࡼ࠭ࡱ࡮ࡸࡷࠬࠚ")
l1l1111_opy_   = l1ll1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡷࡻ࡮ࡹࡴࡦࡦࠪࠛ")
l1l1l1ll_opy_  = l1ll1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡴࡸࡧࡤࡥࡱࡱࠫࠜ")
l1l1lll1_opy_  = l1ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡇࡲࡡࡤ࡭ࡌࡧࡪ࡚ࡖࠨࠝ")
l1111l1_opy_    = [l1lllll_opy_, l111111_opy_, l1l111l_opy_, l1l1ll1l_opy_, l1111_opy_,l1ll11l_opy_, l1ll1111_opy_, root, l111l1l_opy_, l111l11_opy_, l1lll_opy_, l11lll1_opy_, l1llll_opy_, l1lll11l_opy_, l1l1l1l1_opy_, dexter, l1l_opy_, l111ll1_opy_, l11llll_opy_, l1l1111_opy_, l1l1l1ll_opy_, l1l1lll1_opy_]
def checkAddons():
    for addon in l1111l1_opy_:
        if l1ll11l1_opy_(addon):
            try: createINI(addon)
            except: continue
def l1ll11l1_opy_(addon):
    if xbmc.getCondVisibility(l1ll1_opy_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡈࡢࡵࡄࡨࡩࡵ࡮ࠩࠧࡶ࠭ࠬࠞ") % addon) == 1:
        dixie.log(l1ll1_opy_ (u"ࠧ࠾࠿ࡀࡁࠥࡧࡤࡥࡱࡱࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠ࠾࠿ࡀࡁࠬࠟ"))
        dixie.log(addon)
        return True
    return False
def createINI(addon):
    l1l11ll1_opy_  = str(addon).split(l1ll1_opy_ (u"ࠨ࠰ࠪࠠ"))[2] + l1ll1_opy_ (u"ࠩ࠱࡭ࡳ࡯ࠧࠡ")
    l1l1l1l_opy_   = os.path.join(l111lll_opy_, l1l11ll1_opy_)
    response = l11111l_opy_(addon)
    l1l11l1_opy_ = response[l1ll1_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪࠢ")][l1ll1_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪࠣ")]
    l1lll1_opy_  = l1ll1_opy_ (u"ࠬࡡࠧࠤ") + addon + l1ll1_opy_ (u"࠭࡝࡝ࡰࠪࠥ")
    l1llll1l_opy_  =  file(l1l1l1l_opy_, l1ll1_opy_ (u"ࠧࡸࠩࠦ"))
    l1llll1l_opy_.write(l1lll1_opy_)
    l1l1llll_opy_ = []
    for channel in l1l11l1_opy_:
        l111l1_opy_ = l1l1lll_opy_(addon)
        l1l11l_opy_  = channel[l1ll1_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࠧ")].split(l1ll1_opy_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࠨ"), 1)[0]
        if addon == dexter:
            l1l11l_opy_ = l1l11l_opy_.split(l1ll1_opy_ (u"ࠪࠤ࠰ࠦࠧࠩ"), 1)[0]
        if (addon == root) or (addon == l1l1ll1l_opy_):
            l1l11l_opy_ = l1l11l_opy_.split(l1ll1_opy_ (u"ࠫࠥ࠳ࠠࠨࠪ"), 1)[0]
        l111l_opy_ = l11ll_opy_(addon, l1l11l_opy_)
        l1l111_opy_ = l1111ll_opy_(addon, l11l_opy_, labelmaps, l1lll1l1_opy_, l1ll1l11_opy_, l1l11l_opy_)
        stream  = l111l1_opy_ + l111l_opy_
        l11l1l_opy_ = l1l111_opy_  + l1ll1_opy_ (u"ࠬࡃࠧࠫ") + stream
        if l11l1l_opy_ not in l1l1llll_opy_:
            l1l1llll_opy_.append(l11l1l_opy_)
    l1l1llll_opy_.sort()
    for item in l1l1llll_opy_:
        l1llll1l_opy_.write(l1ll1_opy_ (u"ࠨࠥࡴ࡞ࡱࠦࠬ") % item)
    l1llll1l_opy_.close()
def l11ll_opy_(addon, l1l11l_opy_):
    if addon == l1l1ll1l_opy_:
        l1l1ll1_opy_ = mapping.cleanLabel(l1l11l_opy_)
        l111l_opy_ = mapping.editPrefix(l11l_opy_, l1l1ll1_opy_)
        return l111l_opy_
    l1l1ll1_opy_ = mapping.cleanLabel(l1l11l_opy_)
    l111l_opy_ = mapping.cleanStreamLabel(l1l1ll1_opy_)
    return l111l_opy_
def l1111ll_opy_(addon, l11l_opy_, labelmaps, l1lll1l1_opy_, l1ll1l11_opy_, l1l11l_opy_):
    if addon == l1l1ll1l_opy_:
        return l1l1ll11_opy_(l11l_opy_, l1ll1l11_opy_, l1l11l_opy_)
    l11111_opy_    = mapping.cleanLabel(l1l11l_opy_)
    l1l1ll1_opy_ = mapping.mapLabel(labelmaps, l11111_opy_)
    l1l111_opy_ = mapping.cleanPrefix(l1l1ll1_opy_)
    return mapping.mapChannelName(l1lll1l1_opy_, l1l111_opy_)
def l1l1ll11_opy_(l11l_opy_, l1ll1l11_opy_, l1l11l_opy_):
    l1l1_opy_ = mapping.cleanLabel(l1l11l_opy_)
    l1l1ll1_opy_   = mapping.editPrefix(l11l_opy_, l1l1_opy_)
    l11l1ll_opy_   = mapping.mapEPGLabel(l11l_opy_, l1ll1l11_opy_, l1l1ll1_opy_)
    return l11l1ll_opy_
def l1ll_opy_(addon, file):
    l11111_opy_ = file[l1ll1_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭࠭")].split(l1ll1_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ࠮"), 1)[0]
    l11111_opy_ = l11111_opy_.split(l1ll1_opy_ (u"ࠩ࠮ࠫ࠯"), 1)[0]
    l11111_opy_ = mapping.cleanLabel(l11111_opy_)
    return l11111_opy_
def l1l1lll_opy_(addon):
    if addon == l1lllll_opy_:
        return l1ll1_opy_ (u"ࠪࡗࡈ࡚ࡖ࠻ࠩ࠰")
    if addon == l111111_opy_:
        return l1ll1_opy_ (u"ࠫࡘ࡛ࡐ࠻ࠩ࠱")
    if addon == l1l111l_opy_:
        return l1ll1_opy_ (u"࡛ࠬࡋࡕ࠼ࠪ࠲")
    if addon == l1l1ll1l_opy_:
        return l1ll1_opy_ (u"࠭ࡌࡊࡏࡌࡘ࠿࠭࠳")
    if addon == l1111_opy_:
        return l1ll1_opy_ (u"ࠧࡇࡃࡅ࠾ࠬ࠴")
    if addon == l1ll11l_opy_:
        return l1ll1_opy_ (u"ࠨࡃࡆࡉ࠿࠭࠵")
    if addon == l1ll1111_opy_:
        return l1ll1_opy_ (u"ࠩࡋࡓࡗࡏ࡚࠻ࠩ࠶")
    if addon == root:
        return l1ll1_opy_ (u"ࠪࡖࡔࡕࡔ࠳࠼ࠪ࠷")
    if addon == l111l1l_opy_:
        return l1ll1_opy_ (u"ࠫࡒࡋࡇࡂ࠼ࠪ࠸")
    if addon == l111l11_opy_:
        return l1ll1_opy_ (u"ࠬࡌࡒࡆࡇ࠽ࠫ࠹")
    if addon == l1llllll_opy_:
        return l1ll1_opy_ (u"࠭ࡍࡂࡖࡖ࠾ࠬ࠺")
    if addon == l1lll_opy_:
        return l1ll1_opy_ (u"ࠧࡊࡒࡗࡗ࠿࠭࠻")
    if addon == l11lll1_opy_:
        return l1ll1_opy_ (u"ࠨࡌࡌࡒ࡝࠸࠺ࠨ࠼")
    if addon == l1llll_opy_:
        return l1ll1_opy_ (u"ࠩࡈࡒࡉࡀࠧ࠽")
    if addon == l1lll11l_opy_:
        return l1ll1_opy_ (u"ࠪࡊࡑࡇ࠺ࠨ࠾")
    if addon == l1l1l1l1_opy_:
        return l1ll1_opy_ (u"ࠫࡒࡇࡘࡊ࠼ࠪ࠿")
    if addon == dexter:
        return l1ll1_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡈ࠿࠭ࡀ")
    if addon == l1l_opy_:
        return l1ll1_opy_ (u"࠭ࡖࡅࡔࡗ࡚࠿࠭ࡁ")
    if addon == l111ll1_opy_:
        return l1ll1_opy_ (u"ࠧࡔࡒࡕࡑ࠿࠭ࡂ")
    if addon == l11llll_opy_:
        return l1ll1_opy_ (u"ࠨࡏࡆࡏ࡙࡜࠺ࠨࡃ")
    if addon == l1l1111_opy_:
        return l1ll1_opy_ (u"ࠩࡗ࡛ࡎ࡙ࡔ࠻ࠩࡄ")
    if addon == l1l1l1ll_opy_:
        return l1ll1_opy_ (u"ࠪࡔࡗࡋࡓࡕ࠼ࠪࡅ")
    if addon == l1l1lll1_opy_:
        return l1ll1_opy_ (u"ࠫࡇࡒࡋࡊ࠼ࠪࡆ")
def getURL(url):
    if url.startswith(l1ll1_opy_ (u"࡙ࠬࡃࡕࡘࠪࡇ")):
        return ll_opy_(url, l1lllll_opy_)
    if url.startswith(l1ll1_opy_ (u"࠭ࡓࡖࡒࠪࡈ")):
        return ll_opy_(url, l111111_opy_)
    if url.startswith(l1ll1_opy_ (u"ࠧࡖࡍࡗࠫࡉ")):
        return ll_opy_(url, l1l111l_opy_)
    if url.startswith(l1ll1_opy_ (u"ࠨࡎࡌࡑࡎ࡚ࠧࡊ")):
        return ll_opy_(url, l1l1ll1l_opy_)
    if url.startswith(l1ll1_opy_ (u"ࠩࡉࡅࡇ࠭ࡋ")):
        return ll_opy_(url, l1111_opy_)
    if url.startswith(l1ll1_opy_ (u"ࠪࡅࡈࡋࠧࡌ")):
        return ll_opy_(url, l1ll11l_opy_)
    if url.startswith(l1ll1_opy_ (u"ࠫࡍࡕࡒࡊ࡜ࠪࡍ")):
        return ll_opy_(url, l1ll1111_opy_)
    if url.startswith(l1ll1_opy_ (u"ࠬࡘࡏࡐࡖ࠵ࠫࡎ")):
        return ll_opy_(url, root)
    if url.startswith(l1ll1_opy_ (u"࠭ࡍࡆࡉࡄࠫࡏ")):
        return ll_opy_(url, l111l1l_opy_)
    if url.startswith(l1ll1_opy_ (u"ࠧࡇࡔࡈࡉࠬࡐ")):
        return ll_opy_(url, l111l11_opy_)
    if url.startswith(l1ll1_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡃࡍࡗ࠽ࠫࡑ")):
        url = url.replace(l1ll1_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡄࡎࡘ࠾ࠬࡒ"), l1ll1_opy_ (u"ࠪࠫࡓ")).replace(l1ll1_opy_ (u"ࠫ࠲࠳ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪࡔ"), l1ll1_opy_ (u"ࠬࢂࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪࡕ"))
        return url
    if url.startswith(l1ll1_opy_ (u"࠭ࡍࡂࡖࡖࠫࡖ")):
        return ll_opy_(url, l1llllll_opy_)
    if url.startswith(l1ll1_opy_ (u"ࠧࡊࡒࡗࡗࠬࡗ")):
        return ll_opy_(url, l1lll_opy_)
    if url.startswith(l1ll1_opy_ (u"ࠨࡌࡌࡒ࡝࠸ࠧࡘ")):
        return ll_opy_(url, l11lll1_opy_)
    if url.startswith(l1ll1_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࡙ࠩ")):
        return ll_opy_(url, dexter)
    if url.startswith(l1ll1_opy_ (u"ࠪࡊࡑࡇ࡚ࠧ")):
        return ll_opy_(url, l1lll11l_opy_)
    if url.startswith(l1ll1_opy_ (u"ࠫࡒࡇࡘࡊ࡛ࠩ")):
        return ll_opy_(url, l1l1l1l1_opy_)
    if url.startswith(l1ll1_opy_ (u"ࠬࡋࡎࡅࠩ࡜")):
        return ll_opy_(url, l1llll_opy_)
    if url.startswith(l1ll1_opy_ (u"࠭ࡖࡅࡔࡗ࡚ࠬ࡝")):
        return ll_opy_(url, l1l_opy_)
    if url.startswith(l1ll1_opy_ (u"ࠧࡔࡒࡕࡑࠬ࡞")):
        return ll_opy_(url, l111ll1_opy_)
    if url.startswith(l1ll1_opy_ (u"ࠨࡏࡆࡏ࡙࡜ࠧ࡟")):
        return ll_opy_(url, l11llll_opy_)
    if url.startswith(l1ll1_opy_ (u"ࠩࡗ࡛ࡎ࡙ࡔࠨࡠ")):
        return ll_opy_(url, l1l1111_opy_)
    if url.startswith(l1ll1_opy_ (u"ࠪࡔࡗࡋࡓࡕࠩࡡ")):
        return ll_opy_(url, l1l1l1ll_opy_)
    if url.startswith(l1ll1_opy_ (u"ࠫࡇࡒࡋࡊࠩࡢ")):
        return ll_opy_(url, l1l1lll1_opy_)
    response  = l1l11l1l_opy_(url)
    l1lll1l_opy_ = url.split(l1ll1_opy_ (u"ࠬࡀࠧࡣ"), 1)[-1]
    try:
        result = response[l1ll1_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࡤ")]
        l11ll1l_opy_  = result[l1ll1_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࡥ")]
    except Exception as e:
        l1l1l11l_opy_(e)
        return None
    for file in l11ll1l_opy_:
        l1l11l_opy_  = file[l1ll1_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࡦ")].split(l1ll1_opy_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࡧ"), 1)[0]
        l1lll11_opy_  = l1l11l_opy_.split(l1ll1_opy_ (u"ࠪ࠯ࠬࡨ"), 1)[0]
        l1ll1ll_opy_ = mapping.cleanLabel(l1lll11_opy_)
        try:
            if l1lll1l_opy_ == l1ll1ll_opy_:
                return file[l1ll1_opy_ (u"ࠫ࡫࡯࡬ࡦࠩࡩ")]
        except:
            if (l1lll1l_opy_ in l1ll1ll_opy_) or (l1ll1ll_opy_ in l1lll1l_opy_):
                return file[l1ll1_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪࡪ")]
    return None
def ll_opy_(url, addon):
    PATH = l1lllll1_opy_(addon)
    try:
        response = json.load(open(PATH))
    except:
        response = l11111l_opy_(addon)
    l1l1l11_opy_      = url.split(l1ll1_opy_ (u"࠭࠺ࠨ࡫"), 1)[-1]
    stream    = l1l1l11_opy_.split(l1ll1_opy_ (u"ࠧࠡ࡝ࠪ࡬"), 1)[0]
    l1lll1l_opy_ = mapping.cleanLabel(stream)
    l11ll1l_opy_  = response[l1ll1_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨ࡭")][l1ll1_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨ࡮")]
    for file in l11ll1l_opy_:
        l1l11l_opy_  = file[l1ll1_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩ࡯")].split(l1ll1_opy_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࡰ"), 1)[0]
        if addon == dexter:
            l1l11l_opy_ = l1l11l_opy_.split(l1ll1_opy_ (u"ࠬࠦࠫࠡࠩࡱ"), 1)[0]
        if (addon == root) or (addon == l1l1ll1l_opy_):
            l1l11l_opy_ = l1l11l_opy_.split(l1ll1_opy_ (u"࠭ࠠ࠮ࠢࠪࡲ"), 1)[0]
        l1ll1ll_opy_ = l11ll_opy_(addon, l1l11l_opy_)
        try:
            if l1lll1l_opy_ == l1ll1ll_opy_:
                return file[l1ll1_opy_ (u"ࠧࡧ࡫࡯ࡩࠬࡳ")]
        except:
            if (l1lll1l_opy_ in l1ll1ll_opy_) or (l1ll1ll_opy_ in l1lll1l_opy_):
                return file[l1ll1_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ࡴ")]
    return None
def l11111l_opy_(addon):
    PATH  = l1lllll1_opy_(addon)
    if addon == l1l_opy_:
        query = l1ll1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡚ࡆࡊࡅࡓ࠱࡯࡭ࡻ࡫ࡴࡷ࠱ࡤࡰࡱ࠵ࠧࡵ")
    elif addon == l111111_opy_:
        query = l1ll1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡺࡲࡦࡣࡰࡷࡺࡶࡲࡦ࡯ࡨ࠶࠴ࡲࡩࡷࡧࡷࡺ࠴ࡧ࡬࡭࠱ࠪࡶ")
    elif addon == l1lllll_opy_:
        query = l1ll1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹࡣࡵࡸ࠲ࡰ࡮ࡼࡥࡵࡸ࠲ࡥࡱࡲ࠯ࠨࡷ")
    elif addon == l111111_opy_:
        query = l1ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡵࡴࡨࡥࡲࡹࡵࡱࡴࡨࡱࡪ࠸࠯࡭࡫ࡹࡩࡹࡼ࠯ࡢ࡮࡯࠳ࠬࡸ")
    elif addon == l111l11_opy_:
        query = l1ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡧࡴࡨࡩࡻ࡯ࡥࡸ࠱ࡂࡹࡷࡲ࠽ࡶࡴ࡯ࠪࡲࡵࡤࡦ࠿࠸ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡻ࡫ࠫࡕࡘࠪࡹ")
    elif addon == l1l111l_opy_:
        query = l1ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡷ࡮ࡸࡺࡸ࡫࠰ࡁࡸࡶࡱࡃࡨࡵࡶࡳࠩ࠸ࡇࠥ࠳ࡈࠨ࠶ࡋࡧࡤࡥࡱࡱࡧࡱࡵࡵࡥ࠰ࡲࡶ࡬ࠫ࠲ࡇࡷ࡮ࡸࡺࡸ࡫ࠦ࠴ࡉ࡙ࡐ࡚ࡵࡳ࡭ࠨ࠶ࡋࡒࡩࡷࡧࠨ࠶࠺࠸࠰ࡕࡘ࠱ࡸࡽࡺࠦ࡮ࡱࡧࡩࡂ࠷ࠦ࡯ࡣࡰࡩࡂࡒࡩࡷࡧ࠮ࡘ࡛ࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࡁࠫ࡬ࡡ࡯ࡣࡵࡸࡂࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࠪࡺ")
    else:
        query = l1lll1ll_opy_(addon)
    try:
        return json.load(open(PATH))
    except:
        content = doJSON(query)
        return l1l1l_opy_(PATH, addon, content)
def l1l1l_opy_(PATH, addon, content):
    json.dump(content, open(PATH,l1ll1_opy_ (u"ࠨࡹࠪࡻ")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    l1ll1l1_opy_  = (l1ll1_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬࡼ") % query)
    response = xbmc.executeJSONRPC(l1ll1l1_opy_)
    content  = json.loads(response)
    return content
def l1lllll1_opy_(addon):
    if addon == l1lllll_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"ࠪࡷࡨࡺࡥ࡮ࡲࠪࡽ"))
    if addon == l111111_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"ࠫࡸࡻࡰࡵࡧࡰࡴࠬࡾ"))
    if addon == l1l111l_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"ࠬࡻ࡫ࡵࡶࡨࡱࡵ࠭ࡿ"))
    if addon == l1l1ll1l_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"࠭࡬ࡪ࡯࡬ࡸࡪࡳࡰࠨࢀ"))
    if addon == l1111_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"ࠧࡧࡣࡥࡸࡪࡳࡰࠨࢁ"))
    if addon == l1ll11l_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"ࠨࡣࡦࡩࡹ࡫࡭ࡱࠩࢂ"))
    if addon == l1ll1111_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"ࠩ࡫ࡳࡷࡺࡥ࡮ࡲࠪࢃ"))
    if addon == root:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"ࠪࡶࡴ࠸ࡴࡦ࡯ࡳࠫࢄ"))
    if addon == l111l1l_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"ࠫࡲ࡫ࡧࡢࡶࡰࡴࠬࢅ"))
    if addon == l1llllll_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"ࠬࡳࡡࡵࡵࡷࡱࡵ࠭ࢆ"))
    if addon == l111l11_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"࠭ࡦࡳࡧࡨࡸࡲࡶࠧࢇ"))
    if addon == l1lll_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"ࠧࡪࡲࡷࡷࡹࡳࡰࠨ࢈"))
    if addon == l11lll1_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"ࠨ࡬࠵ࡸࡪࡳࡰࠨࢉ"))
    if addon == l1llll_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"ࠩࡨࡸࡪࡳࡰࠨࢊ"))
    if addon == l1lll11l_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"ࠪࡪࡹ࡫࡭ࡱࠩࢋ"))
    if addon == l1l1l1l1_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"ࠫࡲࡧࡸࡵࡧࡰࡴࠬࢌ"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"ࠬࡪࡴࡦ࡯ࡳࠫࢍ"))
    if addon == l1l_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"࠭ࡶࡥࡶࡨࡱࡵ࠭ࢎ"))
    if addon == l111ll1_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"ࠧࡴࡲࡵࡸࡪࡳࡰࠨ࢏"))
    if addon == l11llll_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"ࠨ࡯ࡦ࡯ࡹ࡫࡭ࡱࠩ࢐"))
    if addon == l1l1111_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"ࠩࡷࡻ࡮ࡺࡥ࡮ࡲࠪ࢑"))
    if addon == l1l1l1ll_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"ࠪࡴࡷ࡫ࡳࡵࡧࡰࡴࠬ࢒"))
    if addon == l1l1lll1_opy_:
        return os.path.join(dixie.PROFILE, l1ll1_opy_ (u"ࠫࡧࡲ࡫ࡪࡶࡨࡱࡵ࠭࢓"))
def l1lll1ll_opy_(addon):
    query = l1ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ࢔") + addon
    response = doJSON(query)
    l11ll1l_opy_    = response[l1ll1_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭࢕")][l1ll1_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭࢖")]
    for file in l11ll1l_opy_:
        l11l11l_opy_ = file[l1ll1_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࢗ")]
        l11111_opy_ = mapping.cleanLabel(l11l11l_opy_)
        l11111_opy_ = l11111_opy_.upper()
        if (l11111_opy_ == l1ll1_opy_ (u"ࠩࡏࡍ࡛ࡋࠠࡊࡒࡗ࡚ࠬ࢘")) or (l11111_opy_ == l1ll1_opy_ (u"ࠪࡐࡎ࡜ࡅࠡࡖ࡙࢙ࠫ")) or (l11111_opy_ == l1ll1_opy_ (u"ࠫࡑࡏࡖࡆࠢࡆࡌࡆࡔࡎࡆࡎࡖ࢚ࠫ")) or (l11111_opy_ == l1ll1_opy_ (u"ࠬࡒࡉࡗࡇ࢛ࠪ")) or (l11111_opy_ == l1ll1_opy_ (u"࠭ࡅࡏࡆࡏࡉࡘ࡙ࠠࡎࡇࡇࡍࡆ࠭࢜")) or (l11111_opy_ == l1ll1_opy_ (u"ࠧࡇࡎࡄ࡛ࡑࡋࡓࡔࡖ࡙ࠫ࢝")) or (l11111_opy_ == l1ll1_opy_ (u"ࠨࡏࡄ࡜ࡎ࡝ࡅࡃࠢࡗ࡚ࠬ࢞")) or (l11111_opy_ == l1ll1_opy_ (u"ࠩࡅࡐࡆࡉࡋࡊࡅࡈࠤ࡙࡜ࠧ࢟")) or (l11111_opy_ == l1ll1_opy_ (u"ࠪࡌࡔࡘࡉ࡛ࡑࡑࠤࡎࡖࡔࡗࠩࢠ")) or (l11111_opy_ == l1ll1_opy_ (u"ࠫࡋࡇࡂࠡࡋࡓࡘ࡛࠭ࢡ")):
            livetv = file[l1ll1_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪࢢ")]
            return l111ll_opy_(livetv)
def l111ll_opy_(livetv):
    response = doJSON(livetv)
    l11ll1l_opy_    = response[l1ll1_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࢣ")][l1ll1_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࢤ")]
    for file in l11ll1l_opy_:
        l11l11l_opy_ = file[l1ll1_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࢥ")]
        l11111_opy_ = mapping.cleanLabel(l11l11l_opy_)
        l11111_opy_ = l11111_opy_.upper()
        if l11111_opy_ == l1ll1_opy_ (u"ࠩࡄࡐࡑ࠭ࢦ"):
            return file[l1ll1_opy_ (u"ࠪࡪ࡮ࡲࡥࠨࢧ")]
def l1llll1_opy_(l1l11_opy_):
    items = []
    _11l111_opy_(l1l11_opy_, items)
    return items
def _11l111_opy_(l1l11_opy_, items):
    response = doJSON(l1l11_opy_)
    if response[l1ll1_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫࢨ")].has_key(l1ll1_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫࢩ")):
        result = response[l1ll1_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࢪ")][l1ll1_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࢫ")]
        for item in result:
            if item[l1ll1_opy_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪࢬ")] == l1ll1_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧࢭ"):
                l11111_opy_ = mapping.cleanLabel(item[l1ll1_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࢮ")])
                items.append(item)
            elif item[l1ll1_opy_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭ࢯ")] == l1ll1_opy_ (u"ࠬࡪࡩࡳࡧࡦࡸࡴࡸࡹࠨࢰ"):
                l11111_opy_ = mapping.cleanLabel(item[l1ll1_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬࢱ")])
                l1l1l111_opy_  = item[l1ll1_opy_ (u"ࠧࡧ࡫࡯ࡩࠬࢲ")]
                dixie.log(item)
                dixie.log(l1l1l111_opy_)
                _11l111_opy_(l1l1l111_opy_, items)
def l1l11l1l_opy_(url):
    if url.startswith(l1ll1_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠺ࠨࢳ")):
        l1ll1l1_opy_ = (l1ll1_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡨࡢࡤ࡫ࡳࡰࡦࡿࡥࡳ࠱ࡂࡹࡷࡲ࠽ࡶࡴ࡯ࠪࡲࡵࡤࡦ࠿࠵ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡻ࡫ࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠩࡍࡕࡏࡄ࠾ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࢴ"))
    if url.startswith(l1ll1_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠴࠽ࠫࢵ")):
        l1ll1l1_opy_ = (l1ll1_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺ࠳ࡄࡻࡲ࡭࠿ࡸࡶࡱࠬ࡭ࡰࡦࡨࡁ࠶࠶࠱ࠧࡰࡤࡱࡪࡃࡗࡢࡶࡦ࡬࠰ࡒࡩࡷࡧࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࡂࠬࡳࡶࡤࡷ࡭ࡹࡲࡥࡴࡡࡸࡶࡱࡃࠦ࡭ࡱࡪ࡫ࡪࡪ࡟ࡪࡰࡀࡊࡦࡲࡳࡦࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࢶ"))
    if url.startswith(l1ll1_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖ࠿࠭ࢷ")):
        l1ll1l1_opy_ = (l1ll1_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠵࠿ࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠫࡲ࡯ࡨࡩࡨࡨࡤ࡯࡮࠾ࡈࡤࡰࡸ࡫ࠦ࡮ࡱࡧࡩࡂ࠷࠱࠴ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡶࡸࡪࡴࠥ࠳࠲ࡏ࡭ࡻ࡫ࠦࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡵࡢࡹࡷࡲࠦࡶࡴ࡯ࡁࡺࡸ࡬ࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ࢸ"))
    if url.startswith(l1ll1_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡏࡔࡗ࠼ࠪࢹ")):
        l1ll1l1_opy_ = (l1ll1_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡺࡶࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ࢺ"))
    if url.startswith(l1ll1_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪࢻ")):
        l1ll1l1_opy_ = (l1ll1_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡤࡦࡺ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡦࡲ࡬ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠦࡵ࡫ࡷࡰࡪࡃࠥ࠶ࡤࡆࡓࡑࡕࡒࠦ࠴࠳ࡻ࡭࡯ࡴࡦࠧ࠸ࡨࡆࡲ࡬ࠦ࠴࠳ࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠪ࠻ࡢࠦ࠴ࡩࡇࡔࡒࡏࡓࠧ࠸ࡨࠫࡻࡲ࡭ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࢼ"))
    if url.startswith(l1ll1_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡕࡆ࠿࠭ࢽ")):
        l1ll1l1_opy_ = (l1ll1_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡨࡦࡴࡵࡴ࠰ࡁࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠦࡧࡣࡱࡥࡷࡺ࠽ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡳ࡯ࡥࡧࡀ࠻ࠫࡶࡩ࡭࡮ࡲࡻࡂࡒࡩࡷࡧࠨ࠶࠵࡙ࡴࡳࡧࡤࡱࡸࠬࡵࡳ࡮ࡀࡶࡦࡴࡤࡰ࡯ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨࢾ"))
    try:
        dixie.ShowBusy()
        addon =  l1ll1l1_opy_.split(l1ll1_opy_ (u"࠭࠯࠰ࠩࢿ"), 1)[-1].split(l1ll1_opy_ (u"ࠧ࠰ࠩࣀ"), 1)[0]
        login = l1ll1_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ࣁ") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1ll1l1_opy_)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1l1l11l_opy_(e)
        return {l1ll1_opy_ (u"ࠩࡈࡶࡷࡵࡲࠨࣂ") : l1ll1_opy_ (u"ࠪࡔࡱࡻࡧࡪࡰࠣࡉࡷࡸ࡯ࡳࠩࣃ")}
def l1ll1l1l_opy_():
    modules = map(__import__, [l1ll11_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l1ll1_opy_ (u"࡙ࠫࡸࡵࡦࠩࣄ")
    if len(modules[-1].Window(10**4).getProperty(l1l1l1_opy_)):
        return l1ll1_opy_ (u"࡚ࠬࡲࡶࡧࠪࣅ")
    return l1ll1_opy_ (u"࠭ࡆࡢ࡮ࡶࡩࠬࣆ")
def l1l1l11l_opy_(e):
    l1ll1ll1_opy_ = l1ll1_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠲ࠠࡢࡰࠣࡩࡷࡸ࡯ࡳࠢࡲࡧࡨࡻࡲࡦࡦ࠽ࠤࡏ࡙ࡏࡏࠢࡈࡶࡷࡵࡲ࠻ࠢࠨࡷࠬࣇ")  %e
    l1ll1lll_opy_ = l1ll1_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡴࡨ࠱ࡱ࡯࡮࡬ࠢࡷ࡬࡮ࡹࠠࡤࡪࡤࡲࡳ࡫࡬ࠡࡣࡱࡨࠥࡺࡲࡺࠢࡤ࡫ࡦ࡯࡮࠯ࠩࣈ")
    l1lll111_opy_ = l1ll1_opy_ (u"ࠩࡘࡷࡪࡀࠠࡄࡱࡱࡸࡪࡾࡴࠡࡏࡨࡲࡺࠦ࠽࠿ࠢࡕࡩࡲࡵࡶࡦࠢࡖࡸࡷ࡫ࡡ࡮ࠩࣉ")
    dixie.log(e)
    dixie.DialogOK(l1ll1ll1_opy_, l1ll1lll_opy_, l1lll111_opy_)
if __name__ == l1ll1_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬ࣊"):
    checkAddons()