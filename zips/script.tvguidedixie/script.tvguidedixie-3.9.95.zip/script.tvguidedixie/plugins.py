# coding: UTF-8
import sys
l1l11ll1_opy_ = sys.version_info [0] == 2
l1llll1l_opy_ = 2048
l1l1ll1l_opy_ = 7
def l11ll_opy_ (l1l11l_opy_):
	global l111111_opy_
	l1ll1lll_opy_ = ord (l1l11l_opy_ [-1])
	l1l1l1ll_opy_ = l1l11l_opy_ [:-1]
	l11l11l_opy_ = l1ll1lll_opy_ % len (l1l1l1ll_opy_)
	l11ll1_opy_ = l1l1l1ll_opy_ [:l11l11l_opy_] + l1l1l1ll_opy_ [l11l11l_opy_:]
	if l1l11ll1_opy_:
		l1llll_opy_ = unicode () .join ([unichr (ord (char) - l1llll1l_opy_ - (l111l1l_opy_ + l1ll1lll_opy_) % l1l1ll1l_opy_) for l111l1l_opy_, char in enumerate (l11ll1_opy_)])
	else:
		l1llll_opy_ = str () .join ([chr (ord (char) - l1llll1l_opy_ - (l111l1l_opy_ + l1ll1lll_opy_) % l1l1ll1l_opy_) for l111l1l_opy_, char in enumerate (l11ll1_opy_)])
	return eval (l1llll_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l1ll1lll1l_opy_     = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡴࡴࡷࠩ૽")
l1ll1llll1_opy_  = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡷ࡭࡫ࡳࡸࡻ࠭૾")
l1lll1l11l_opy_     = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡶ࡭ࡷࡹࡷࡱࠧ૿")
locked  = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮ࡲࡧࡰ࡫ࡤࡵࡸࠪ଀")
l1lll11l1l_opy_      = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸࡰࡹ࡯࡭ࡢࡶࡨࡱࡦࡴࡩࡢࠩଁ")
l11lllll_opy_    = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰ࡮ࡻࡸ࠯ࡶࡹࠫଂ")
l1lll11111_opy_     = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡉࡉࡓࡱࡱࡵࡸࡸ࠭ଃ")
l1lll11ll1_opy_  = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡥࡣࡱࡲࡸࠬ଄")
l1ll1lllll_opy_     = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡣ࡭ࡷ࡬ࡴࡹࡼࠧଅ")
l1ll1lll11_opy_ = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡶ࡭ࡷࡺ࠹࡫ࡸࡱࡣࡷࡷ࠳ࡩ࡯࡮ࠩଆ")
l1ll1l11_opy_ = [l1ll1lll1l_opy_, locked, l11lllll_opy_, l1ll1llll1_opy_, l1ll1lll11_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l11ll_opy_ (u"ࠩ࡬ࡲ࡮࠭ଇ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1ll1l1ll_opy_ = l11ll_opy_ (u"ࠪࠫଈ")
def l1ll11l1l_opy_(i, t1, l1ll1l1l1_opy_=[]):
 t = l1ll1l1ll_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1ll1l1l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11l11ll_opy_ = l1ll11l1l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11ll1ll_opy_ = l1ll11l1l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1ll1l11_opy_:
        if l1ll11ll1_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1ll11ll1_opy_(addon):
    if xbmc.getCondVisibility(l11ll_opy_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡍࡧࡳࡂࡦࡧࡳࡳ࠮ࠥࡴࠫࠪଉ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l1llll11l_opy_ = str(addon).split(l11ll_opy_ (u"ࠬ࠴ࠧଊ"))[2] + l11ll_opy_ (u"࠭࠮ࡪࡰ࡬ࠫଋ")
    l1111111_opy_  = os.path.join(PATH, l1llll11l_opy_)
    try:
        l11l111_opy_ = l11lll1l_opy_(addon)
    except KeyError:
        dixie.log(l11ll_opy_ (u"ࠧ࠮࠯࠰࠱࠲ࠦࡋࡦࡻࡈࡶࡷࡵࡲࠡ࡫ࡱࠤ࡬࡫ࡴࡇ࡫࡯ࡩࡸࠦ࠭࠮࠯࠰࠱ࠥ࠭ଌ") + addon)
        result = {l11ll_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࡳࠨ଍"): [{l11ll_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ଎"): l11ll_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࠩଏ"), l11ll_opy_ (u"ࡹࠬࡺࡹࡱࡧࠪଐ"): l11ll_opy_ (u"ࡺ࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧ଑"), l11ll_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࠬ଒"): l11ll_opy_ (u"ࡵࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡼࡽ࠭ଓ"), l11ll_opy_ (u"ࡶࠩ࡯ࡥࡧ࡫࡬ࠨଔ"): l11ll_opy_ (u"ࡷࠪࡒࡔࠦࡃࡉࡃࡑࡒࡊࡒࡓࠨକ")}], l11ll_opy_ (u"ࡸࠫࡱ࡯࡭ࡪࡶࡶࠫଖ"):{l11ll_opy_ (u"ࡹࠬࡹࡴࡢࡴࡷࠫଗ"): 0, l11ll_opy_ (u"ࡺ࠭ࡴࡰࡶࡤࡰࠬଘ"): 1, l11ll_opy_ (u"ࡻࠧࡦࡰࡧࠫଙ"): 1}}
    l11111l1_opy_  = l11ll_opy_ (u"ࠧ࡜ࠩଚ") + addon + l11ll_opy_ (u"ࠨ࡟࡟ࡲࠬଛ")
    l11l1l1l_opy_  =  file(l1111111_opy_, l11ll_opy_ (u"ࠩࡺࠫଜ"))
    l11l1l1l_opy_.write(l11111l1_opy_)
    l1lllll1l_opy_ = []
    for channel in l11l111_opy_:
        l1lll1ll11_opy_ = dixie.cleanLabel(channel[l11ll_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩଝ")])
        l1l1111_opy_   = dixie.cleanPrefix(l1lll1ll11_opy_)
        l11l1ll1_opy_ = dixie.mapChannelName(l1l1111_opy_)
        stream   = channel[l11ll_opy_ (u"ࠫ࡫࡯࡬ࡦࠩଞ")]
        l11l111l_opy_ = l11l1ll1_opy_ + l11ll_opy_ (u"ࠬࡃࠧଟ") + stream
        l1lllll1l_opy_.append(l11l111l_opy_)
        l1lllll1l_opy_.sort()
    for item in l1lllll1l_opy_:
        l11l1l1l_opy_.write(l11ll_opy_ (u"ࠨࠥࡴ࡞ࡱࠦଠ") % item)
    l11l1l1l_opy_.close()
def l11lll1l_opy_(addon):
    if (addon == l1ll1lll1l_opy_) or (addon == l1ll1llll1_opy_):
        if xbmcaddon.Addon(addon).getSetting(l11ll_opy_ (u"ࠧࡨࡧࡱࡶࡪ࠭ଡ")) == l11ll_opy_ (u"ࠨࡶࡵࡹࡪ࠭ଢ"):
            xbmcaddon.Addon(addon).setSetting(l11ll_opy_ (u"ࠩࡪࡩࡳࡸࡥࠨଣ"), l11ll_opy_ (u"ࠪࡪࡦࡲࡳࡦࠩତ"))
            xbmcgui.Window(10000).setProperty(l11ll_opy_ (u"ࠫࡕࡒࡕࡈࡋࡑࡣࡌࡋࡎࡓࡇࠪଥ"), l11ll_opy_ (u"࡚ࠬࡲࡶࡧࠪଦ"))
        if xbmcaddon.Addon(addon).getSetting(l11ll_opy_ (u"࠭ࡴࡷࡩࡸ࡭ࡩ࡫ࠧଧ")) == l11ll_opy_ (u"ࠧࡵࡴࡸࡩࠬନ"):
            xbmcaddon.Addon(addon).setSetting(l11ll_opy_ (u"ࠨࡶࡹ࡫ࡺ࡯ࡤࡦࠩ଩"), l11ll_opy_ (u"ࠩࡩࡥࡱࡹࡥࠨପ"))
            xbmcgui.Window(10000).setProperty(l11ll_opy_ (u"ࠪࡔࡑ࡛ࡇࡊࡐࡢࡘ࡛ࡍࡕࡊࡆࡈࠫଫ"), l11ll_opy_ (u"࡙ࠫࡸࡵࡦࠩବ"))
        l1l11ll_opy_  = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨଭ") + addon
        l1lll111l1_opy_ =  l1lll1l1l1_opy_(addon)
        query   =  l1l11ll_opy_ + l1lll111l1_opy_
        return sendJSON(query, addon)
    return l1l11l1l_opy_(addon)
def l1l11l1l_opy_(addon):
    if addon == l1ll1lll11_opy_:
        l1111ll_opy_ = [l11ll_opy_ (u"࠭࠱࠷࠳ࠪମ"), l11ll_opy_ (u"ࠧ࠲࠸࠳ࠫଯ"), l11ll_opy_ (u"ࠨ࠴࠶࠺ࠬର"), l11ll_opy_ (u"ࠩ࠵࠸࠷࠭଱"), l11ll_opy_ (u"ࠪ࠵࠺࠾ࠧଲ"), l11ll_opy_ (u"ࠫ࠶࠻࠹ࠨଳ")]
    if addon == l11lllll_opy_:
        l1111ll_opy_ = [l11ll_opy_ (u"ࠬ࠻ࠧ଴"), l11ll_opy_ (u"࠭࠱࠱࠸ࠪଵ"), l11ll_opy_ (u"ࠧ࠵ࠩଶ"), l11ll_opy_ (u"ࠨ࠴࠹࠷ࠬଷ"), l11ll_opy_ (u"ࠩ࠴࠷࠷࠭ସ")]
    if addon == locked:
        l1111ll_opy_ = [l11ll_opy_ (u"ࠪ࠷࠵࠭ହ"), l11ll_opy_ (u"ࠫ࠸࠷ࠧ଺"), l11ll_opy_ (u"ࠬ࠹࠲ࠨ଻"), l11ll_opy_ (u"࠭࠳࠴଼ࠩ"), l11ll_opy_ (u"ࠧ࠴࠶ࠪଽ"), l11ll_opy_ (u"ࠨ࠵࠸ࠫା"), l11ll_opy_ (u"ࠩ࠶࠼ࠬି"), l11ll_opy_ (u"ࠪ࠸࠵࠭ୀ"), l11ll_opy_ (u"ࠫ࠹࠷ࠧୁ"), l11ll_opy_ (u"ࠬ࠺࠵ࠨୂ"), l11ll_opy_ (u"࠭࠴࠸ࠩୃ"), l11ll_opy_ (u"ࠧ࠵࠻ࠪୄ"), l11ll_opy_ (u"ࠨ࠷࠵ࠫ୅")]
    if addon == l1lll11l1l_opy_:
        l1111ll_opy_ = [l11ll_opy_ (u"ࠩ࠵࠹ࠬ୆"), l11ll_opy_ (u"ࠪ࠶࠻࠭େ"), l11ll_opy_ (u"ࠫ࠷࠽ࠧୈ"), l11ll_opy_ (u"ࠬ࠸࠹ࠨ୉"), l11ll_opy_ (u"࠭࠳࠱ࠩ୊"), l11ll_opy_ (u"ࠧ࠴࠳ࠪୋ"), l11ll_opy_ (u"ࠨ࠵࠵ࠫୌ"), l11ll_opy_ (u"ࠩ࠶࠹୍ࠬ"), l11ll_opy_ (u"ࠪ࠷࠻࠭୎"), l11ll_opy_ (u"ࠫ࠸࠽ࠧ୏"), l11ll_opy_ (u"ࠬ࠹࠸ࠨ୐"), l11ll_opy_ (u"࠭࠳࠺ࠩ୑"), l11ll_opy_ (u"ࠧ࠵࠲ࠪ୒"), l11ll_opy_ (u"ࠨ࠶࠴ࠫ୓"), l11ll_opy_ (u"ࠩ࠷࠼ࠬ୔"), l11ll_opy_ (u"ࠪ࠸࠾࠭୕"), l11ll_opy_ (u"ࠫ࠺࠶ࠧୖ"), l11ll_opy_ (u"ࠬ࠻࠲ࠨୗ"), l11ll_opy_ (u"࠭࠵࠵ࠩ୘"), l11ll_opy_ (u"ࠧ࠶࠸ࠪ୙"), l11ll_opy_ (u"ࠨ࠷࠺ࠫ୚"), l11ll_opy_ (u"ࠩ࠸࠼ࠬ୛"), l11ll_opy_ (u"ࠪ࠹࠾࠭ଡ଼"), l11ll_opy_ (u"ࠫ࠻࠶ࠧଢ଼"), l11ll_opy_ (u"ࠬ࠼࠱ࠨ୞"), l11ll_opy_ (u"࠭࠶࠳ࠩୟ"), l11ll_opy_ (u"ࠧ࠷࠵ࠪୠ"), l11ll_opy_ (u"ࠨ࠸࠸ࠫୡ"), l11ll_opy_ (u"ࠩ࠹࠺ࠬୢ"), l11ll_opy_ (u"ࠪ࠺࠼࠭ୣ"), l11ll_opy_ (u"ࠫ࠻࠿ࠧ୤"), l11ll_opy_ (u"ࠬ࠽࠰ࠨ୥"), l11ll_opy_ (u"࠭࠷࠵ࠩ୦"), l11ll_opy_ (u"ࠧ࠸࠹ࠪ୧"), l11ll_opy_ (u"ࠨ࠹࠻ࠫ୨"), l11ll_opy_ (u"ࠩ࠻࠴ࠬ୩"), l11ll_opy_ (u"ࠪ࠼࠶࠭୪")]
    login = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴ࠱ࠪ୫") % addon
    sendJSON(login, addon)
    l11111l_opy_ = []
    for l1111l_opy_ in l1111ll_opy_:
        if (addon == l1ll1lll11_opy_) or (addon == l11lllll_opy_):
            query = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠦࡵ࠲ࡃࡲࡵࡤࡦࡡ࡬ࡨࡂࡩࡨࡢࡰࡱࡩࡱࡹࠦ࡮ࡱࡧࡩࡂࡩࡨࡢࡰࡱࡩࡱࡹࠦࡴࡧࡦࡸ࡮ࡵ࡮ࡠ࡫ࡧࡁࠪࡹࠧ୬") % (addon, l1111l_opy_)
        if (addon == locked) or (addon == l1lll11l1l_opy_):
            query = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶ࠳ࡄࡻࡲ࡭࠿ࠨࡷࠫࡳ࡯ࡥࡧࡀ࠸ࠫࡴࡡ࡮ࡧࡀࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧࡲ࡯ࡥࡾࡃࠦࡥࡣࡷࡩࡂࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࡁࠫࡶࡡࡨࡧࡀࠫ୭") % (addon, l1111l_opy_)
        response = sendJSON(query, addon)
        l11111l_opy_.extend(response)
    return l11111l_opy_
def sendJSON(query, addon):
    l111l11_opy_     = l11ll_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ୮") % query
    l1111_opy_  = xbmc.executeJSONRPC(l111l11_opy_)
    response = json.loads(l1111_opy_)
    result   = response[l11ll_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨ୯")]
    if xbmcgui.Window(10000).getProperty(l11ll_opy_ (u"ࠩࡓࡐ࡚ࡍࡉࡏࡡࡊࡉࡓࡘࡅࠨ୰")) == l11ll_opy_ (u"ࠪࡘࡷࡻࡥࠨୱ"):
        xbmcaddon.Addon(addon).setSetting(l11ll_opy_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ୲"), l11ll_opy_ (u"ࠬࡺࡲࡶࡧࠪ୳"))
    if xbmcgui.Window(10000).getProperty(l11ll_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡔࡗࡉࡘࡍࡉࡋࠧ୴")) == l11ll_opy_ (u"ࠧࡕࡴࡸࡩࠬ୵"):
        xbmcaddon.Addon(addon).setSetting(l11ll_opy_ (u"ࠨࡶࡹ࡫ࡺ࡯ࡤࡦࠩ୶"), l11ll_opy_ (u"ࠩࡷࡶࡺ࡫ࠧ୷"))
    return result[l11ll_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩ୸")]
def l1lll1l1l1_opy_(addon):
    if (addon == l1ll1lll1l_opy_) or (addon == l1ll1llll1_opy_):
        return l11ll_opy_ (u"ࠫ࠴ࡅࡣࡢࡶࡀ࠱࠷ࠬࡤࡢࡶࡨࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠨࡨࡲࡩࡊࡡࡵࡧࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦ࡮ࡱࡧࡩࡂ࠸ࠦ࡯ࡣࡰࡩࡂࡓࡹࠦ࠴࠳ࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡸࡥࡤࡱࡵࡨࡳࡧ࡭ࡦࠨࡶࡸࡦࡸࡴࡅࡣࡷࡩࠫࡻࡲ࡭࠿ࡸࡶࡱ࠭୹")
    return l11ll_opy_ (u"ࠬ࠭୺")
def l1111ll1_opy_():
    modules = map(__import__, [l1ll11l1l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11l11ll_opy_)):
        return l11ll_opy_ (u"࠭ࡔࡳࡷࡨࠫ୻")
    if len(modules[-1].Window(10**4).getProperty(l11ll1ll_opy_)):
        return l11ll_opy_ (u"ࠧࡕࡴࡸࡩࠬ୼")
    return l11ll_opy_ (u"ࠨࡈࡤࡰࡸ࡫ࠧ୽")
def l1lll111l_opy_(e, addon):
    l1111lll_opy_ = l11ll_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠭ࠢࡤࡲࠥ࡫ࡲࡳࡱࡵࠤࡴࡩࡣࡶࡴࡨࡨ࠿ࠦࡊࡔࡑࡑࠤࡊࡸࡲࡰࡴ࠽ࠤࠪࡹࠬࠡࠧࡶࠫ୾")  % (e, addon)
    l11l1111_opy_ = l11ll_opy_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡧࡴࡴࡴࡢࡥࡷࠤࡺࡹࠠࡰࡰࠣࡸ࡭࡫ࠠࡧࡱࡵࡹࡲ࠴ࠧ୿")
    l111l11l_opy_ = l11ll_opy_ (u"࡚ࠫࡶ࡬ࡰࡣࡧࠤࡦࠦ࡬ࡰࡩࠣࡺ࡮ࡧࠠࡵࡪࡨࠤࡦࡪࡤࡰࡰࠣࡷࡪࡺࡴࡪࡰࡪࡷࠥࡧ࡮ࡥࠢࡳࡳࡸࡺࠠࡵࡪࡨࠤࡱ࡯࡮࡬࠰ࠪ஀")
    dixie.log(addon)
    dixie.log(e)
def getPluginInfo(streamurl, kodiID=False):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l1lll111ll_opy_   = l11ll_opy_ (u"ࠬࡑ࡯ࡥ࡫ࠣࡔ࡛ࡘࠧ஁")
            l1lll1l111_opy_ = os.path.join(dixie.RESOURCES, l11ll_opy_ (u"࠭࡫ࡰࡦ࡬࠱ࡵࡼࡲ࠯ࡲࡱ࡫ࠬஂ"))
            return l1lll111ll_opy_, l1lll1l111_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l11ll_opy_ (u"ࠧࡳࡶࡰࡴࠬஃ")) or url.startswith(l11ll_opy_ (u"ࠨࡴࡷࡱࡵ࡫ࠧ஄")) or url.startswith(l11ll_opy_ (u"ࠩࡵࡸࡸࡶࠧஅ")) or url.startswith(l11ll_opy_ (u"ࠪ࡬ࡹࡺࡰࠨஆ")):
            l1lll111ll_opy_   = l11ll_opy_ (u"ࠫࡲ࠹ࡵࠡࡒ࡯ࡥࡾࡲࡩࡴࡶࠪஇ")
            l1lll1l111_opy_ = os.path.join(dixie.RESOURCES, l11ll_opy_ (u"ࠬ࡯ࡰࡵࡸ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡶ࡮ࡨࠩஈ"))
            return l1lll111ll_opy_, l1lll1l111_opy_
    except:
        pass
    if streamurl.startswith(l11ll_opy_ (u"࠭ࡰࡷࡴ࠽࠳࠴࠭உ")):
        l1lll111ll_opy_   = l11ll_opy_ (u"ࠧࡌࡱࡧ࡭ࠥࡖࡖࡓࠩஊ")
        l1lll1l111_opy_ = os.path.join(dixie.RESOURCES, l11ll_opy_ (u"ࠨ࡭ࡲࡨ࡮࠳ࡰࡷࡴ࠱ࡴࡳ࡭ࠧ஋"))
        return l1lll111ll_opy_, l1lll1l111_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        l1lll11lll_opy_ = streamurl.split(l11ll_opy_ (u"ࠩࡠࡓ࡙࡚࡟ࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ஌"), 1)[-1].split(l11ll_opy_ (u"ࠪ࠳ࠬ஍"), 1)[0]
    if l11ll_opy_ (u"ࠫࡢࡕࡔࡕࡡࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬஎ") in streamurl:
        l1lll11lll_opy_ = streamurl.split(l11ll_opy_ (u"ࠬࡣࡏࡕࡖࡢࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭ஏ"), 1)[-1].split(l11ll_opy_ (u"࠭࠯ࠨஐ"), 1)[0]
    if streamurl.startswith(l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ஑")):
        l1lll11lll_opy_ = streamurl.split(l11ll_opy_ (u"ࠨ࠱࠲ࠫஒ"), 1)[-1].split(l11ll_opy_ (u"ࠩ࠲ࠫஓ"), 1)[0]
    if l11ll_opy_ (u"ࠪࡣࡤ࡙ࡆࡠࡡࠪஔ") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡵࡸ࡯ࡨࡴࡤࡱ࠳ࡹࡵࡱࡧࡵ࠲࡫ࡧࡶࡰࡷࡵ࡭ࡹ࡫ࡳࠨக")
    if l11ll_opy_ (u"࡙ࠬࡃࡕࡘ࠽ࠫ஖") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹࡣࡵࡸࠪ஗")
    if l11ll_opy_ (u"ࠧࡔࡗࡓ࠾ࠬ஘") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡶࡵࡩࡦࡳࡳࡶࡲࡵࡩࡲ࡫࠲ࠨங")
    if l11ll_opy_ (u"ࠩࡘࡏ࡙ࡀࠧச") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸ࡯ࡹࡻࡲ࡬ࠩ஛")
    if l11ll_opy_ (u"ࠫࡑࡏࡍࡊࡖ࠽ࠫஜ") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡑ࡯࡭ࡪࡶ࡯ࡩࡸࡹࡉࡑࡖ࡙ࠫ஝")
    if l11ll_opy_ (u"࠭ࡆࡂࡄ࠽ࠫஞ") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡦࡢࡤ࡫ࡳࡸࡺࡩ࡯ࡩࠪட")
    if l11ll_opy_ (u"ࠨࡃࡆࡉ࠿࠭஠") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡦࡩࡹࡼࠧ஡")
    if l11ll_opy_ (u"ࠪࡌࡔࡘࡉ࡛࠼ࠪ஢") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡬ࡴࡸࡩࡻࡱࡱ࡭ࡵࡺࡶࠨண")
    if l11ll_opy_ (u"ࠬࡘࡏࡐࡖ࠵࠾ࠬத") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸ࡯ࡰࡶࡌࡔ࡙࡜ࠧ஥")
    if l11ll_opy_ (u"ࠧࡎࡇࡊࡅ࠿࠭஦") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡮ࡧࡪࡥ࡮ࡶࡴࡷࠩ஧")
    if l11ll_opy_ (u"࡙ࠩࡈࡗ࡚ࡖ࠻ࠩந") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡙ࡅࡉࡋࡒࠨன")
    if l11ll_opy_ (u"ࠫࡍࡊࡔࡗ࠼ࠪப") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡳࡡࡳࡶ࡫ࡹࡧ࠭஫")
    if l11ll_opy_ (u"࠭ࡈࡅࡖ࡙࠶࠿࠭஬") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࠶ࠬ஭")
    if l11ll_opy_ (u"ࠨࡊࡇࡘ࡛࠹࠺ࠨம") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࠸ࠧய")
    if l11ll_opy_ (u"ࠪࡌࡉ࡚ࡖ࠵࠼ࠪர") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡱ࠭ற")
    if l11ll_opy_ (u"ࠬࡏࡐࡍࡃ࡜࠾ࠬல") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡨࡢࡤ࡫ࡳࡰࡦࡿࡥࡳࠩள")
    if l11ll_opy_ (u"ࠧࡊࡒࡏࡅ࡞࠸࠺ࠨழ") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺࠫவ")
    if l11ll_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡓ࠼ࠪஶ") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠭ஷ")
    if l11ll_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡌࡘ࡛ࡀࠧஸ") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡺࡶࠨஹ")
    if l11ll_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡉࡀࠧ஺") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡤࡦࡺࠪ஻")
    if l11ll_opy_ (u"ࠨࡌࡌࡒ࡝࠸࠺ࠨ஼") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡬࡬ࡲࡽࡺࡶ࠳ࠩ஽")
    if l11ll_opy_ (u"ࠪࡑࡆ࡚ࡓ࠻ࠩா") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡑࡦࡺࡳࡃࡷ࡬ࡰࡩࡹࡉࡑࡖ࡙ࠫி")
    if l11ll_opy_ (u"ࠬࡘࡏࡐࡖ࠽ࠫீ") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸ࡯ࡰࡶ࡬ࡴࡹࡼࠧு")
    if l11ll_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡘࡂ࠻ࠩூ") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡧࡥࡳࡴࡺࠧ௃")
    if l11ll_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡄࡎࡘ࠾ࠬ௄") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡦࡰࡺ࡯ࡰࡵࡸࠪ௅")
    if l11ll_opy_ (u"ࠫࡎࡖࡔࡔࠩெ") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶࡴࡷࡵࡸࡦࡸ࠭ே")
    if l11ll_opy_ (u"࠭ࡌࡊࡘࡈࡘ࡛ࡀࠧை") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡬ࡪࡸࡨࡱ࡮ࡾࠧ௉")
    if l11ll_opy_ (u"ࠨࡇࡑࡈ࠿࠭ொ") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡇࡱࡨࡱ࡫ࡳࡴࠩோ")
    if l11ll_opy_ (u"ࠪࡊࡑࡇ࠺ࠨௌ") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡊࡱࡧࡷ࡭ࡧࡶࡷ࡙ࡼ்ࠧ")
    if l11ll_opy_ (u"ࠬࡓࡁ࡙ࡋ࠽ࠫ௎") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡳࡡࡹ࡫ࡺࡩࡧࡺࡶࠨ௏")
    if l11ll_opy_ (u"ࠧࡇࡎࡄࡗ࠿࠭ௐ") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡇ࡮ࡤࡻࡱ࡫ࡳࡴࡖࡹࠫ௑")
    if l11ll_opy_ (u"ࠩࡖࡔࡗࡓ࠺ࠨ௒") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡖࡹࡵࡸࡥ࡮ࡣࡦࡽ࡙࡜ࠧ௓")
    if l11ll_opy_ (u"ࠫࡒࡉࡋࡕࡘ࠽ࠫ௔") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡲࡩ࡫ࡵࡸ࠰ࡴࡱࡻࡳࠨ௕")
    if l11ll_opy_ (u"࠭ࡔࡘࡋࡖࡘ࠿࠭௖") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡴࡸ࡫ࡶࡸࡪࡪࠧௗ")
    if l11ll_opy_ (u"ࠨࡒࡕࡉࡘ࡚࠺ࠨ௘") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡲࡶࡥࡩࡪ࡯࡯ࠩ௙")
    if l11ll_opy_ (u"ࠪࡆࡑࡑࡉ࠻ࠩ௚") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡆࡱࡧࡣ࡬ࡋࡦࡩ࡙࡜ࠧ௛")
    if l11ll_opy_ (u"ࠬࡌࡒࡆࡇ࠽ࠫ௜") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡬ࡲࡦࡧࡹ࡭ࡪࡽࠧ௝")
    if l11ll_opy_ (u"ࠧࡶࡲࡱࡴ࠿࠭௞") in streamurl:
        l1lll11lll_opy_ = l11ll_opy_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯ࡪࡧ࡬ࡴࡳࡥࡳࡷࡱ࠲ࡻ࡯ࡥࡸࠩ௟")
    return l1lll1111l_opy_(l1lll11lll_opy_, kodiID)
def l1lll1111l_opy_(l1lll11lll_opy_, kodiID):
    l1lll111ll_opy_     = l11ll_opy_ (u"ࠩࠪ௠")
    l1lll1l111_opy_   = l11ll_opy_ (u"ࠪࠫ௡")
    try:
        l1lll1l1ll_opy_ = xbmcaddon.Addon(l1lll11lll_opy_).getAddonInfo(l11ll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩ௢"))
        l1lll111ll_opy_    = dixie.cleanLabel(l1lll1l1ll_opy_)
        l1lll1l111_opy_  = xbmcaddon.Addon(l1lll11lll_opy_).getAddonInfo(l11ll_opy_ (u"ࠬ࡯ࡣࡰࡰࠪ௣"))
        if kodiID:
            l1lll11l11_opy_ = xbmcaddon.Addon(l1lll11lll_opy_).getAddonInfo(l11ll_opy_ (u"࠭ࡩࡥࠩ௤"))
            return l1lll111ll_opy_, l1lll11l11_opy_
        return l1lll111ll_opy_, l1lll1l111_opy_
    except:
        l1lll111ll_opy_   = l11ll_opy_ (u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡕࡲࡹࡷࡩࡥࠨ௥")
        l1lll1l111_opy_ =  dixie.ICON
        return l1lll111ll_opy_, l1lll1l111_opy_
    return l1lll111ll_opy_, l1lll1l111_opy_
def selectStream(url, channel):
    l11llll_opy_ = url.split(l11ll_opy_ (u"ࠨࡾࠪ௦"))
    if len(l11llll_opy_) == 0:
        return None
    options, l1l11l11_opy_ = getOptions(l11llll_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l11llll_opy_) == 1:
            return l1l11l11_opy_[0]
    import selectDialog
    l1lllll1_opy_ = selectDialog.select(l11ll_opy_ (u"ࠩࡖࡩࡱ࡫ࡣࡵࠢࡤࠤࡸࡺࡲࡦࡣࡰࠫ௧"), options)
    if l1lllll1_opy_ < 0:
        raise Exception(l11ll_opy_ (u"ࠪࡗࡪࡲࡥࡤࡶ࡬ࡳࡳࠦࡃࡢࡰࡦࡩࡱ࠭௨"))
    return l1l11l11_opy_[l1lllll1_opy_]
def getOptions(l11llll_opy_, channel, addmore=True):
    options = []
    l1l11l11_opy_    = []
    for index, stream in enumerate(l11llll_opy_):
        l1lll111ll_opy_ = getPluginInfo(stream)
        l1lllll_opy_ = l1lll111ll_opy_[0]
        l1ll1ll1ll_opy_  = l1lll111ll_opy_[1]
        l1lllll_opy_ = l11ll_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡴࡸࡡ࡯ࡩࡨࡡࡠ࠭௩") + l1lllll_opy_ + l11ll_opy_ (u"ࠬࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠡࠩ௪")
        if stream.startswith(OPEN_OTT):
            l111l_opy_ = stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l11ll_opy_ (u"࠭ࠧ௫"))
            l1lllll_opy_  = l1lllll_opy_ + l111l_opy_
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l11ll_opy_ (u"ࠧࠨ௬"))
        else:
            l1lllll_opy_  = l1lllll_opy_ + channel
        options.append([l1lllll_opy_, index, l1ll1ll1ll_opy_])
        l1l11l11_opy_.append(stream)
    if addmore:
        options.append([l11ll_opy_ (u"ࠨࡃࡧࡨࠥࡳ࡯ࡳࡧ࠱࠲࠳࠭௭"), index + 1, dixie.ICON])
        l1l11l11_opy_.append(l11ll_opy_ (u"ࠩࡤࡨࡩࡓ࡯ࡳࡧࠪ௮"))
    return options, l1l11l11_opy_
if __name__ == l11ll_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬ௯"):
    checkAddons()