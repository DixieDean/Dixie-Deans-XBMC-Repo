# coding: UTF-8
import sys
l11llll_opy_ = sys.version_info [0] == 2
l1llll1_opy_ = 2048
l1llll_opy_ = 7
def l11l11_opy_ (ll_opy_):
	global l1lllll_opy_
	l1l1111_opy_ = ord (ll_opy_ [-1])
	l1111l_opy_ = ll_opy_ [:-1]
	l1ll111_opy_ = l1l1111_opy_ % len (l1111l_opy_)
	l1l1l_opy_ = l1111l_opy_ [:l1ll111_opy_] + l1111l_opy_ [l1ll111_opy_:]
	if l11llll_opy_:
		l1ll1ll_opy_ = unicode () .join ([unichr (ord (char) - l1llll1_opy_ - (l11ll1_opy_ + l1l1111_opy_) % l1llll_opy_) for l11ll1_opy_, char in enumerate (l1l1l_opy_)])
	else:
		l1ll1ll_opy_ = str () .join ([chr (ord (char) - l1llll1_opy_ - (l11ll1_opy_ + l1l1111_opy_) % l1llll_opy_) for l11ll1_opy_, char in enumerate (l1l1l_opy_)])
	return eval (l1ll1ll_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l11l1l111_opy_    = l11l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡰࡷࡺࠬ২")
l11l11l11_opy_ = l11l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡺࡰ࡮ࡶࡴࡷࠩ৩")
l11l1llll_opy_    = l11l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡹࡰࡺࡵࡳ࡭ࠪ৪")
locked = l11l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡱࡵࡣ࡬ࡧࡧࡸࡻ࠭৫")
l11l11111_opy_     = l11l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡻ࡬ࡵ࡫ࡰࡥࡹ࡫࡭ࡢࡰ࡬ࡥࠬ৬")
l111lll11_opy_   = l11l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡬ࡪࡷࡻ࠲ࡹࡼࠧ৭")
l11l11ll1_opy_    = l11l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡅࡅࡖࡴࡴࡸࡴࡴࠩ৮")
l11l1lll1_opy_ = l11l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡨࡦࡴࡵࡴࠨ৯")
l11l1l1ll_opy_    = l11l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡦࡰࡺ࡯ࡰࡵࡸࠪৰ")
l111llll1_opy_ = l11l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡺࡿࡡࡪࡲࡷࡺࠬৱ")
l11l11l_opy_ = [l11l1l111_opy_, locked, l111lll11_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l11l11_opy_ (u"ࠬ࡯࡮ࡪࠩ৲"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1l11l1_opy_ = l11l11_opy_ (u"࠭ࠧ৳")
def l11l111_opy_(i, t1, l1l111l_opy_=[]):
 t = l1l11l1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l111l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1l11_opy_ = l11l111_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11ll_opy_ = l11l111_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l11l11l_opy_:
        if l11l1ll_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l11l1ll_opy_(addon):
    if xbmc.getCondVisibility(l11l11_opy_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡉࡣࡶࡅࡩࡪ࡯࡯ࠪࠨࡷ࠮࠭৴") % addon) == 1:
        return True
    return False
def createINI(addon):
    l11_opy_ = str(addon).split(l11l11_opy_ (u"ࠨ࠰ࠪ৵"))[2] + l11l11_opy_ (u"ࠩ࠱࡭ࡳ࡯ࠧ৶")
    l1l_opy_  = os.path.join(PATH, l11_opy_)
    try:
        l1l1l1l_opy_ = l1_opy_(addon)
    except KeyError:
        dixie.log(l11l11_opy_ (u"ࠪ࠱࠲࠳࠭࠮ࠢࡎࡩࡾࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡨࡧࡷࡊ࡮ࡲࡥࡴࠢ࠰࠱࠲࠳࠭ࠡࠩ৷") + addon)
        result = {l11l11_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࡶࠫ৸"): [{l11l11_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ৹"): l11l11_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࠬ৺"), l11l11_opy_ (u"ࡵࠨࡶࡼࡴࡪ࠭৻"): l11l11_opy_ (u"ࡶࠩࡸࡲࡰࡴ࡯ࡸࡰࠪৼ"), l11l11_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࠨ৽"): l11l11_opy_ (u"ࡸࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾࡸࡹࠩ৾"), l11l11_opy_ (u"ࡹࠬࡲࡡࡣࡧ࡯ࠫ৿"): l11l11_opy_ (u"ࡺ࠭ࡎࡐࠢࡆࡌࡆࡔࡎࡆࡎࡖࠫ਀")}], l11l11_opy_ (u"ࡻࠧ࡭࡫ࡰ࡭ࡹࡹࠧਁ"):{l11l11_opy_ (u"ࡵࠨࡵࡷࡥࡷࡺࠧਂ"): 0, l11l11_opy_ (u"ࡶࠩࡷࡳࡹࡧ࡬ࠨਃ"): 1, l11l11_opy_ (u"ࡷࠪࡩࡳࡪࠧ਄"): 1}}
    l1l1l11_opy_  = file(l1l_opy_, l11l11_opy_ (u"ࠪࡻࠬਅ"))
    l1l1l11_opy_.write(l11l11_opy_ (u"ࠫࡠ࠭ਆ"))
    l1l1l11_opy_.write(addon)
    l1l1l11_opy_.write(l11l11_opy_ (u"ࠬࡣࠧਇ"))
    l1l1l11_opy_.write(l11l11_opy_ (u"࠭࡜࡯ࠩਈ"))
    l1ll11_opy_ = []
    for channel in l1l1l1l_opy_:
        l11lll_opy_ = dixie.cleanLabel(channel[l11l11_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ਉ")])
        l1ll1_opy_ = dixie.mapChannelName(l11lll_opy_)
        stream   = channel[l11l11_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ਊ")]
        l11l1_opy_ = l1ll1_opy_ + l11l11_opy_ (u"ࠩࡀࠫ਋") + stream
        l1ll11_opy_.append(l11l1_opy_)
        l1ll11_opy_.sort()
    for item in l1ll11_opy_:
        l1l1l11_opy_.write(l11l11_opy_ (u"ࠥࠩࡸࡢ࡮ࠣ਌") % item)
    l1l1l11_opy_.close()
def l1_opy_(addon):
    if (addon == l11l1l111_opy_) or (addon == l11l11l11_opy_) or (addon == l111llll1_opy_):
        try:
            if xbmcaddon.Addon(addon).getSetting(l11l11_opy_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ਍")) == l11l11_opy_ (u"ࠬࡺࡲࡶࡧࠪ਎"):
                xbmcaddon.Addon(addon).setSetting(l11l11_opy_ (u"࠭ࡧࡦࡰࡵࡩࠬਏ"), l11l11_opy_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭ਐ"))
                xbmcgui.Window(10000).setProperty(l11l11_opy_ (u"ࠨࡒࡏ࡙ࡌࡏࡎࡠࡉࡈࡒࡗࡋࠧ਑"), l11l11_opy_ (u"ࠩࡗࡶࡺ࡫ࠧ਒"))
            if xbmcaddon.Addon(addon).getSetting(l11l11_opy_ (u"ࠪࡸࡻ࡭ࡵࡪࡦࡨࠫਓ")) == l11l11_opy_ (u"ࠫࡹࡸࡵࡦࠩਔ"):
                xbmcaddon.Addon(addon).setSetting(l11l11_opy_ (u"ࠬࡺࡶࡨࡷ࡬ࡨࡪ࠭ਕ"), l11l11_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬਖ"))
                xbmcgui.Window(10000).setProperty(l11l11_opy_ (u"ࠧࡑࡎࡘࡋࡎࡔ࡟ࡕࡘࡊ࡙ࡎࡊࡅࠨਗ"), l11l11_opy_ (u"ࠨࡖࡵࡹࡪ࠭ਘ"))
        except: pass
        l1l11llll_opy_  = l11l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬਙ") + addon
        l11l1ll1l_opy_ =  l11ll111l_opy_(addon)
        query   =  l1l11llll_opy_ + l11l1ll1l_opy_
        return sendJSON(query, addon)
    return l111lll_opy_(addon)
def l111lll_opy_(addon):
    if addon == l111lll11_opy_:
        l111111_opy_ = [l11l11_opy_ (u"ࠪ࠹ࠬਚ"), l11l11_opy_ (u"ࠫ࠶࠶࠶ࠨਛ"), l11l11_opy_ (u"ࠬ࠺ࠧਜ"), l11l11_opy_ (u"࠭࠲࠷࠵ࠪਝ"), l11l11_opy_ (u"ࠧ࠲࠵࠵ࠫਞ")]
    if addon == locked:
        l111111_opy_ = [l11l11_opy_ (u"ࠨ࠵࠳ࠫਟ"), l11l11_opy_ (u"ࠩ࠶࠵ࠬਠ"), l11l11_opy_ (u"ࠪ࠷࠷࠭ਡ"), l11l11_opy_ (u"ࠫ࠸࠹ࠧਢ"), l11l11_opy_ (u"ࠬ࠹࠴ࠨਣ"), l11l11_opy_ (u"࠭࠳࠶ࠩਤ"), l11l11_opy_ (u"ࠧ࠴࠺ࠪਥ"), l11l11_opy_ (u"ࠨ࠶࠳ࠫਦ"), l11l11_opy_ (u"ࠩ࠷࠵ࠬਧ"), l11l11_opy_ (u"ࠪ࠸࠺࠭ਨ"), l11l11_opy_ (u"ࠫ࠹࠽ࠧ਩"), l11l11_opy_ (u"ࠬ࠺࠹ࠨਪ"), l11l11_opy_ (u"࠭࠵࠳ࠩਫ")]
    if addon == l11l11111_opy_:
        l111111_opy_ = [l11l11_opy_ (u"ࠧ࠳࠷ࠪਬ"), l11l11_opy_ (u"ࠨ࠴࠹ࠫਭ"), l11l11_opy_ (u"ࠩ࠵࠻ࠬਮ"), l11l11_opy_ (u"ࠪ࠶࠾࠭ਯ"), l11l11_opy_ (u"ࠫ࠸࠶ࠧਰ"), l11l11_opy_ (u"ࠬ࠹࠱ࠨ਱"), l11l11_opy_ (u"࠭࠳࠳ࠩਲ"), l11l11_opy_ (u"ࠧ࠴࠷ࠪਲ਼"), l11l11_opy_ (u"ࠨ࠵࠹ࠫ਴"), l11l11_opy_ (u"ࠩ࠶࠻ࠬਵ"), l11l11_opy_ (u"ࠪ࠷࠽࠭ਸ਼"), l11l11_opy_ (u"ࠫ࠸࠿ࠧ਷"), l11l11_opy_ (u"ࠬ࠺࠰ࠨਸ"), l11l11_opy_ (u"࠭࠴࠲ࠩਹ"), l11l11_opy_ (u"ࠧ࠵࠺ࠪ਺"), l11l11_opy_ (u"ࠨ࠶࠼ࠫ਻"), l11l11_opy_ (u"ࠩ࠸࠴਼ࠬ"), l11l11_opy_ (u"ࠪ࠹࠷࠭਽"), l11l11_opy_ (u"ࠫ࠺࠺ࠧਾ"), l11l11_opy_ (u"ࠬ࠻࠶ࠨਿ"), l11l11_opy_ (u"࠭࠵࠸ࠩੀ"), l11l11_opy_ (u"ࠧ࠶࠺ࠪੁ"), l11l11_opy_ (u"ࠨ࠷࠼ࠫੂ"), l11l11_opy_ (u"ࠩ࠹࠴ࠬ੃"), l11l11_opy_ (u"ࠪ࠺࠶࠭੄"), l11l11_opy_ (u"ࠫ࠻࠸ࠧ੅"), l11l11_opy_ (u"ࠬ࠼࠳ࠨ੆"), l11l11_opy_ (u"࠭࠶࠶ࠩੇ"), l11l11_opy_ (u"ࠧ࠷࠸ࠪੈ"), l11l11_opy_ (u"ࠨ࠸࠺ࠫ੉"), l11l11_opy_ (u"ࠩ࠹࠽ࠬ੊"), l11l11_opy_ (u"ࠪ࠻࠵࠭ੋ"), l11l11_opy_ (u"ࠫ࠼࠺ࠧੌ"), l11l11_opy_ (u"ࠬ࠽࠷ࠨ੍"), l11l11_opy_ (u"࠭࠷࠹ࠩ੎"), l11l11_opy_ (u"ࠧ࠹࠲ࠪ੏"), l11l11_opy_ (u"ࠨ࠺࠴ࠫ੐")]
    login = l11l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠪࡹ࠯ࠨੑ") % addon
    sendJSON(login, addon)
    l11111_opy_ = []
    for l111l1l_opy_ in l111111_opy_:
        if addon == l111lll11_opy_:
            query = l11l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳ࠰ࡁࡰࡳࡩ࡫࡟ࡪࡦࡀࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡳ࡯ࡥࡧࡀࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡹࡥࡤࡶ࡬ࡳࡳࡥࡩࡥ࠿ࠨࡷࠬ੒") % (addon, l111l1l_opy_)
        if (addon == locked) or (addon == l11l11111_opy_):
            query = l11l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴ࠱ࡂࡹࡷࡲ࠽ࠦࡵࠩࡱࡴࡪࡥ࠾࠶ࠩࡲࡦࡳࡥ࠾ࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࠬࡰ࡭ࡣࡼࡁࠫࡪࡡࡵࡧࡀࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠩࡴࡦ࡭ࡥ࠾ࠩ੓") % (addon, l111l1l_opy_)
        response = sendJSON(query, addon)
        l11111_opy_.extend(response)
    return l11111_opy_
def sendJSON(query, addon):
    l1111ll_opy_     = l11l11_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࠦࡵࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ੔") % query
    l111ll1_opy_  = xbmc.executeJSONRPC(l1111ll_opy_)
    response = json.loads(l111ll1_opy_)
    result   = response[l11l11_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭੕")]
    if xbmcgui.Window(10000).getProperty(l11l11_opy_ (u"ࠧࡑࡎࡘࡋࡎࡔ࡟ࡈࡇࡑࡖࡊ࠭੖")) == l11l11_opy_ (u"ࠨࡖࡵࡹࡪ࠭੗"):
        xbmcaddon.Addon(addon).setSetting(l11l11_opy_ (u"ࠩࡪࡩࡳࡸࡥࠨ੘"), l11l11_opy_ (u"ࠪࡸࡷࡻࡥࠨਖ਼"))
    if xbmcgui.Window(10000).getProperty(l11l11_opy_ (u"ࠫࡕࡒࡕࡈࡋࡑࡣ࡙࡜ࡇࡖࡋࡇࡉࠬਗ਼")) == l11l11_opy_ (u"࡚ࠬࡲࡶࡧࠪਜ਼"):
        xbmcaddon.Addon(addon).setSetting(l11l11_opy_ (u"࠭ࡴࡷࡩࡸ࡭ࡩ࡫ࠧੜ"), l11l11_opy_ (u"ࠧࡵࡴࡸࡩࠬ੝"))
    return result[l11l11_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧਫ਼")]
def l11ll111l_opy_(addon):
    if (addon == l11l1l111_opy_) or (addon == l11l11l11_opy_):
        return l11l11_opy_ (u"ࠩ࠲ࡃࡨࡧࡴ࠾࠯࠵ࠪࡩࡧࡴࡦࠨࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠦࡦࡰࡧࡈࡦࡺࡥࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡳ࡯ࡥࡧࡀ࠶ࠫࡴࡡ࡮ࡧࡀࡑࡾࠫ࠲࠱ࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠩࡶࡪࡩ࡯ࡳࡦࡱࡥࡲ࡫ࠦࡴࡶࡤࡶࡹࡊࡡࡵࡧࠩࡹࡷࡲ࠽ࡶࡴ࡯ࠫ੟")
    if addon == l111llll1_opy_:
        return l11l11_opy_ (u"ࠪ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡲࡩࡷࡧࡷࡺࡤࡧ࡬࡭ࠨࡨࡼࡹࡸࡡࠧࡲࡤ࡫ࡪࠬࡰ࡭ࡱࡷࠪࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠽ࠧࡶ࡬ࡸࡱ࡫࠽ࡂ࡮࡯ࠩ࠷࠶ࡣࡩࡣࡱࡲࡪࡲࡳࠧࡷࡵࡰࠬ੠")
    return l11l11_opy_ (u"ࠫࠬ੡")
def l1111_opy_():
    modules = map(__import__, [l11l111_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1l11_opy_)):
        return l11l11_opy_ (u"࡚ࠬࡲࡶࡧࠪ੢")
    if len(modules[-1].Window(10**4).getProperty(l11ll_opy_)):
        return l11l11_opy_ (u"࠭ࡔࡳࡷࡨࠫ੣")
    return l11l11_opy_ (u"ࠧࡇࡣ࡯ࡷࡪ࠭੤")
def l1l1ll1_opy_(e, addon):
    l1l111_opy_ = l11l11_opy_ (u"ࠨࡕࡲࡶࡷࡿࠬࠡࡣࡱࠤࡪࡸࡲࡰࡴࠣࡳࡨࡩࡵࡳࡧࡧ࠾ࠥࡐࡓࡐࡐࠣࡉࡷࡸ࡯ࡳ࠼ࠣࠩࡸ࠲ࠠࠦࡵࠪ੥")  % (e, addon)
    l111l_opy_ = l11l11_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡹࡸࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡦࡰࡴࡸࡱ࠳࠭੦")
    l1l1l1_opy_ = l11l11_opy_ (u"࡙ࠪࡵࡲ࡯ࡢࡦࠣࡥࠥࡲ࡯ࡨࠢࡹ࡭ࡦࠦࡴࡩࡧࠣࡥࡩࡪ࡯࡯ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠤࡦࡴࡤࠡࡲࡲࡷࡹࠦࡴࡩࡧࠣࡰ࡮ࡴ࡫࠯ࠩ੧")
    dixie.log(addon)
    dixie.log(e)
def getPlaylist():
    import requests
    l11l1l11l_opy_ = [l11l11_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱ࡋࡉ࡟࠻࡚ࡺ࡫ࡍࡩ࡜࠭੨"), l11l11_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲ࡼ࡫࠻ࡉ࠴ࡊࡒࡨ࡞ࡔࠧ੩"), l11l11_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳࡚ࡒࡣ࠱࠳ࡐࡓࡑ࡭ࡃࠨ੪"), l11l11_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡹ࠰ࡦࡳ࠴ࡰࡵࡏࡏࡑ࡫ࡼࡰࡐ࠱ࠩ੫"), l11l11_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡺ࠱ࡧࡴ࠵ࡤ࡫ࡄࡤ࠵ࡳࡼ࠹ࡈࡼࠪ੬"), l11l11_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡻ࠲ࡨࡵ࠯࡯ࡘࡶࡵࡨ࡭ࡣࡤ࠻ࡼࠫ੭"), l11l11_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡼ࠳ࡩ࡯࠰ࡺࡏࡇ࠾࠺ࡅࡗࡓࡹ࡝ࠬ੮"), l11l11_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱ࡷࡷࡊ࠹ࡊࡑࡶࡩࡑࡷ࠭੯"), l11l11_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲ࡩ࡛࡜ࡁࡸࡍࡌࡷࡘ࡮ࠧੰ"), l11l11_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳ࡽࡗࡰࡇࡌ࡚࡫࡮࡭ࡪࠨੱ")]
    l11l111ll_opy_ =  l11l11_opy_ (u"ࠧࠤࡇ࡛ࡘࡒ࠹ࡕࠨੲ")
    for url in l11l1l11l_opy_:
        try:
            request  = requests.get(url)
            l1l111111_opy_ = request.text
        except: pass
        if l11l111ll_opy_ in l1l111111_opy_:
            path = os.path.join(dixie.PROFILE, l11l11_opy_ (u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡱ࠸ࡻࠧੳ"))
            with open(path, l11l11_opy_ (u"ࠩࡺࠫੴ")) as f:
                f.write(l1l111111_opy_)
                break
def l11l1111l_opy_(addon):
    l1l11llll_opy_ = l11l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭ੵ") + addon
    l111ll1ll_opy_  = l11l11_opy_ (u"ࠫࡄࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࡨࡵࡶࡳࠩ࠸ࡧࠥ࠳ࡨࠨ࠶࡫ࡳࡥࡵࡣ࡯࡯ࡪࡺࡴ࡭ࡧ࠱ࡧࡴࠫ࠲ࡧࡗࡎࡘࡺࡸ࡫࠲࠺࠳࠶࠷࠶࠱࠷ࠧ࠵ࡪࡹ࡮ࡵ࡮ࡤࡶࠩ࠷࡬࡮ࡦࡹࠨ࠶࡫࡛࡫ࠦ࠴࠸࠶࠵ࡺࡵࡳ࡭ࠨ࠶࠺࠸࠰ࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠩ࠷࠻࠲࠱࡮࡬ࡺࡪࠫ࠲࠶࠴࠳ࡸࡻ࠴ࡪࡱࡩࠩࡱࡴࡪࡥ࠾࠳ࠩࡲࡦࡳࡥ࠾ࡎ࡬ࡺࡪࠫ࠲࠱ࡖ࡙ࠪࡺࡸ࡬࠾ࡪࡷࡸࡵࠫ࠳ࡢࠧ࠵ࡪࠪ࠸ࡦ࡮ࡧࡷࡥࡱࡱࡥࡵࡶ࡯ࡩ࠳ࡩ࡯ࠦ࠴ࡩ࡙ࡐ࡚ࡵࡳ࡭࠴࠼࠵࠸࠲࠱࠳࠹ࠩ࠷࡬ࡌࡪࡸࡨࠩ࠷࠻࠲࠱ࡖ࡙࠲ࡹࡾࡴࠨ੶")
    l11111_opy_  = []
    l11111_opy_ += sendJSON(l1l11llll_opy_ + l111ll1ll_opy_, addon)
    l11111_opy_.sort()
    return l11111_opy_
def l11ll1111_opy_(addon):
    l1l11llll_opy_ = l11l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ੷") + addon
    l111ll1ll_opy_ = l11l11_opy_ (u"࠭࠯ࡀࡨࡤࡲࡦࡸࡴ࠾ࡪࡷࡸࡵࠫ࠳ࡢࠧ࠵ࡪࠪ࠸ࡦࡨࡱࡲ࠲࡬ࡲࠥ࠳ࡨ࡛ࡨࡋ࠸࠸ࡕࠨࡰࡳࡩ࡫࠽࠲ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡹࡩࠪ࠸࠰ࡖࡍࠨ࠶࠵࡙ࡰࡰࡴࡷࡷࠫࡻࡲ࡭࠿࡫ࡸࡹࡶࡳࠦ࠵ࡤࠩ࠷࡬ࠥ࠳ࡨࡪࡳࡴ࠴ࡧ࡭ࠧ࠵ࡪ࠺ࡷࡑࡨࡇ࠷ࠫ੸")
    l111lll1l_opy_ = l11l11_opy_ (u"ࠧ࠰ࡁࡩࡥࡳࡧࡲࡵ࠿࡫ࡸࡹࡶࡳࠦ࠵ࡤࠩ࠷࡬ࠥ࠳ࡨࡪࡳࡴ࠴ࡧ࡭ࠧ࠵ࡪࡋ࡭ࡗࡎ࡭࡝ࠪࡲࡵࡤࡦ࠿࠴ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡻ࡫ࠥ࠳࠲ࡘࡗࠪ࠸ࡦࡄࡃࡑࠩ࠷࠶ࡓࡱࡱࡵࡸࡸࠬࡵࡳ࡮ࡀ࡬ࡹࡺࡰࡴࠧ࠶ࡥࠪ࠸ࡦࠦ࠴ࡩ࡫ࡴࡵ࠮ࡨ࡮ࠨ࠶࡫࡬࠹࡫ࡩ࠻ࡒࠬ੹")
    l11111_opy_  = []
    l11111_opy_ += sendJSON(l1l11llll_opy_ + l111ll1ll_opy_, addon)
    l11111_opy_ += sendJSON(l1l11llll_opy_ + l111lll1l_opy_, addon)
    return l11111_opy_
def getPluginInfo(streamurl):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l111lllll_opy_   = l11l11_opy_ (u"ࠨࡍࡲࡨ࡮ࠦࡐࡗࡔࠪ੺")
            l11l111l1_opy_ = os.path.join(dixie.RESOURCES, l11l11_opy_ (u"ࠩ࡮ࡳࡩ࡯࠭ࡱࡸࡵ࠲ࡵࡴࡧࠨ੻"))
            return l111lllll_opy_, l11l111l1_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l11l11_opy_ (u"ࠪࡶࡹࡳࡰࠨ੼")) or url.startswith(l11l11_opy_ (u"ࠫࡷࡺ࡭ࡱࡧࠪ੽")) or url.startswith(l11l11_opy_ (u"ࠬࡸࡴࡴࡲࠪ੾")) or url.startswith(l11l11_opy_ (u"࠭ࡨࡵࡶࡳࠫ੿")):
            l111lllll_opy_   = l11l11_opy_ (u"ࠧ࡮࠵ࡸࠤࡕࡲࡡࡺ࡮࡬ࡷࡹ࠭઀")
            l11l111l1_opy_ = os.path.join(dixie.RESOURCES, l11l11_opy_ (u"ࠨ࡫ࡳࡸࡻ࠳ࡰ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡲࡱ࡫ࠬઁ"))
            return l111lllll_opy_, l11l111l1_opy_
    except:
        pass
    if streamurl.startswith(dixie.OPEN_OTT):
        l11l11lll_opy_ = streamurl.split(l11l11_opy_ (u"ࠩࡠࡓ࡙࡚࡟ࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪં"), 1)[-1].split(l11l11_opy_ (u"ࠪ࠳ࠬઃ"), 1)[0]
    if l11l11_opy_ (u"ࠫࡢࡕࡔࡕࡡࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ઄") in streamurl:
        l11l11lll_opy_ = streamurl.split(l11l11_opy_ (u"ࠬࡣࡏࡕࡖࡢࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭અ"), 1)[-1].split(l11l11_opy_ (u"࠭࠯ࠨઆ"), 1)[0]
    if streamurl.startswith(l11l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪઇ")):
        l11l11lll_opy_ = streamurl.split(l11l11_opy_ (u"ࠨ࠱࠲ࠫઈ"), 1)[-1].split(l11l11_opy_ (u"ࠩ࠲ࠫઉ"), 1)[0]
    if l11l11_opy_ (u"ࠪࡣࡤ࡙ࡆࡠࡡࠪઊ") in streamurl:
        l11l11lll_opy_ = l11l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡵࡸ࡯ࡨࡴࡤࡱ࠳ࡹࡵࡱࡧࡵ࠲࡫ࡧࡶࡰࡷࡵ࡭ࡹ࡫ࡳࠨઋ")
    if l11l11_opy_ (u"ࠬࡎࡄࡕࡘ࠽ࠫઌ") in streamurl:
        l11l11lll_opy_ = l11l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹ࡭ࡢࡴࡷ࡬ࡺࡨࠧઍ")
    if l11l11_opy_ (u"ࠧࡉࡆࡗ࡚࠷ࡀࠧ઎") in streamurl:
        l11l11lll_opy_ = l11l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥ࠷࠭એ")
    if l11l11_opy_ (u"ࠩࡋࡈ࡙࡜࠳࠻ࠩઐ") in streamurl:
        l11l11lll_opy_ = l11l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧ࠲ࠨઑ")
    if l11l11_opy_ (u"ࠫࡍࡊࡔࡗ࠶࠽ࠫ઒") in streamurl:
        l11l11lll_opy_ = l11l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡲࠧઓ")
    if l11l11_opy_ (u"࠭ࡉࡑࡎࡄ࡝࠿࠭ઔ") in streamurl:
        l11l11lll_opy_ = l11l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡢࡣࡥ࡬ࡴࡱࡧࡹࡦࡴࠪક")
    if l11l11_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠲࠻ࠩખ") in streamurl:
        l11l11lll_opy_ = l11l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡰࡦࡿࡥࡳࡹࡺࡻࠬગ")
    if l11l11_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡔ࠽ࠫઘ") in streamurl:
        l11l11lll_opy_ = l11l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽࠧઙ")
    if l11l11_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡍ࡙࡜࠺ࠨચ") in streamurl:
        l11l11lll_opy_ = l11l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡴࡷࠩછ")
    if l11l11_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡊ࠺ࠨજ") in streamurl:
        l11l11lll_opy_ = l11l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡥࡧࡻࠫઝ")
    if l11l11_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡓࡄ࠽ࠫઞ") in streamurl:
        l11l11lll_opy_ = l11l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡩࡧࡵ࡯ࡵࠩટ")
    if l11l11_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡆࡐ࡚ࡀࠧઠ") in streamurl:
        l11l11lll_opy_ = l11l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡨࡲࡵࡪࡲࡷࡺࠬડ")
    if l11l11_opy_ (u"࠭ࡉࡑࡖࡖࠫઢ") in streamurl:
        l11l11lll_opy_ = l11l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࡭ࡵࡺࡶࠨણ")
    if l11l11_opy_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠻ࠩત") in streamurl:
        l11l11lll_opy_ = l11l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮࡬ࡺࡪࡳࡩࡹࠩથ")
    if l11l11_opy_ (u"ࠪࡊࡑࡇ࠺ࠨદ") in streamurl:
        l11l11lll_opy_ = l11l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡊࡱࡧࡷ࡭ࡧࡶࡷ࡙ࡼࠧધ")
    if l11l11_opy_ (u"ࠬࡌࡌࡂࡕ࠽ࠫન") in streamurl:
        l11l11lll_opy_ = l11l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡌ࡬ࡢࡹ࡯ࡩࡸࡹࡔࡷࠩ઩")
    if l11l11_opy_ (u"ࠧࡶࡲࡱࡴ࠿࠭પ") in streamurl:
        l11l11lll_opy_ = l11l11_opy_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯ࡪࡧ࡬ࡴࡳࡥࡳࡷࡱ࠲ࡻ࡯ࡥࡸࠩફ")
    return l11l1ll11_opy_(l11l11lll_opy_)
def l11l1ll11_opy_(l11l11lll_opy_):
    l111lllll_opy_   = l11l11_opy_ (u"ࠩࠪબ")
    l11l111l1_opy_ = l11l11_opy_ (u"ࠪࠫભ")
    if l11l11lll_opy_ == l11l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡨࡪࡾࠧમ"):
        l111lllll_opy_   = l11l11_opy_ (u"ࠬࡊࡥࡹࡶࡨࡶ࡙࡜ࠠࡍ࡫ࡷࡩࠬય")
        l11l111l1_opy_ = xbmcaddon.Addon(l11l11lll_opy_).getAddonInfo(l11l11_opy_ (u"࠭ࡩࡤࡱࡱࠫર"))
        return l111lllll_opy_, l11l111l1_opy_
    try:
        l111lllll_opy_   = xbmcaddon.Addon(l11l11lll_opy_).getAddonInfo(l11l11_opy_ (u"ࠧ࡯ࡣࡰࡩࠬ઱"))
        l11l111l1_opy_ = xbmcaddon.Addon(l11l11lll_opy_).getAddonInfo(l11l11_opy_ (u"ࠨ࡫ࡦࡳࡳ࠭લ"))
        return l111lllll_opy_, l11l111l1_opy_
    except:
        l111lllll_opy_   = l11l11_opy_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠣࡗࡴࡻࡲࡤࡧࠪળ")
        l11l111l1_opy_ =  dixie.ICON
        return l111lllll_opy_, l11l111l1_opy_
    return l111lllll_opy_, l11l111l1_opy_
def selectStream(url, channel):
    url = url.replace(l11l11_opy_ (u"ࠪࢀࡺࡹࡥࡳ࠯ࡤ࡫ࡪࡴࡴࠨ઴"), l11l11_opy_ (u"ࠫ࠲࠳ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪવ"))
    l11ll11_opy_ = url.split(l11l11_opy_ (u"ࠬࢂࠧશ"))
    if len(l11ll11_opy_) == 0:
        return None
    options, l11l1l1_opy_ = getOptions(l11ll11_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l11ll11_opy_) == 1:
            return l11l1l1_opy_[0]
    import selectDialog
    l11l1l1l1_opy_ = selectDialog.select(l11l11_opy_ (u"࠭ࡓࡦ࡮ࡨࡧࡹࠦࡡࠡࡵࡷࡶࡪࡧ࡭ࠨષ"), options)
    if l11l1l1l1_opy_ < 0:
        raise Exception(l11l11_opy_ (u"ࠧࡔࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡇࡦࡴࡣࡦ࡮ࠪસ"))
    return l11l1l1_opy_[l11l1l1l1_opy_]
def getOptions(l11ll11_opy_, channel, addmore=True):
    options = []
    l11l1l1_opy_    = []
    for index, stream in enumerate(l11ll11_opy_):
        l111lllll_opy_ = getPluginInfo(stream)
        l11lll_opy_ = l111lllll_opy_[0]
        l11l11l1l_opy_  = l111lllll_opy_[1]
        l11lll_opy_ = l11l11_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡱࡵࡥࡳ࡭ࡥ࡞࡝ࠪહ") + l11lll_opy_ + l11l11_opy_ (u"ࠩࡠ࡟࠴ࡉࡏࡍࡑࡕࡡࠥ࠭઺")
        if stream.startswith(OPEN_OTT):
            l11lll_opy_  = l11lll_opy_ + stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l11l11_opy_ (u"ࠪࠫ઻"))
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l11l11_opy_ (u"઼ࠫࠬ"))
        else:
            l11lll_opy_  = l11lll_opy_ + channel
        options.append([l11lll_opy_, index, l11l11l1l_opy_])
        l11l1l1_opy_.append(stream)
    if addmore:
        options.append([l11l11_opy_ (u"ࠬࡇࡤࡥࠢࡰࡳࡷ࡫࠮࠯࠰ࠪઽ"), index + 1, dixie.ICON])
        l11l1l1_opy_.append(l11l11_opy_ (u"࠭ࡡࡥࡦࡐࡳࡷ࡫ࠧા"))
    return options, l11l1l1_opy_
if __name__ == l11l11_opy_ (u"ࠧࡠࡡࡰࡥ࡮ࡴ࡟ࡠࠩિ"):
    checkAddons()
    getPlaylist()