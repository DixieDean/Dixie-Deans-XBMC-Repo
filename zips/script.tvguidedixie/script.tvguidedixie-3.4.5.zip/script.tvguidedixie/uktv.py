# coding: UTF-8
import sys
l1lll1ll_opy_ = sys.version_info [0] == 2
l1ll111_opy_ = 2048
l1ll1l_opy_ = 7
def l1111l_opy_ (ll_opy_):
	global l111_opy_
	l11111l_opy_ = ord (ll_opy_ [-1])
	l1llll1l_opy_ = ll_opy_ [:-1]
	l1ll1_opy_ = l11111l_opy_ % len (l1llll1l_opy_)
	l11l111_opy_ = l1llll1l_opy_ [:l1ll1_opy_] + l1llll1l_opy_ [l1ll1_opy_:]
	if l1lll1ll_opy_:
		l1l1l1l_opy_ = unicode () .join ([unichr (ord (char) - l1ll111_opy_ - (l11l1l_opy_ + l11111l_opy_) % l1ll1l_opy_) for l11l1l_opy_, char in enumerate (l11l111_opy_)])
	else:
		l1l1l1l_opy_ = str () .join ([chr (ord (char) - l1ll111_opy_ - (l11l1l_opy_ + l11111l_opy_) % l1ll1l_opy_) for l11l1l_opy_, char in enumerate (l11l111_opy_)])
	return eval (l1l1l1l_opy_)
import xbmc
import xbmcaddon
import json
import urllib
import os
import dixie
l11l1111l_opy_   = l1111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡷ࡮ࡸࡻ࡬ࡲࡢࡰࡦࡩࠬॸ")
l11l11l11_opy_   = l1111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡸࡷ࡫ࡡ࡮࠯ࡦࡳࡩ࡫ࡳࠨॹ")
l11l11111_opy_ = l1111l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡺࡶࡴࡷࡥࡷࠬॺ")
l11l11ll1_opy_   = l1111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸࠨॻ")
l11l1l11l_opy_   =  [l11l1111l_opy_, l11l11l11_opy_, l11l11111_opy_, l11l11ll1_opy_]
def checkAddons():
    for l11l11l_opy_ in l11l1l11l_opy_:
        if l11l1l1l1_opy_(l11l11l_opy_):
            l11ll11ll_opy_(l11l11l_opy_)
def l11l1l1l1_opy_(l11l11l_opy_):
    if xbmc.getCondVisibility(l1111l_opy_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡈࡢࡵࡄࡨࡩࡵ࡮ࠩࠧࡶ࠭ࠬॼ") % l11l11l_opy_) == 1:
        return True
    return False
def l11ll11ll_opy_(l11l11l_opy_):
    HOME = dixie.PROFILE
    PATH = os.path.join(HOME, l1111l_opy_ (u"ࠧࡪࡰ࡬ࠫॽ"))
    l11lll1l1_opy_ = l11ll1l1l_opy_(l11l11l_opy_) + l1111l_opy_ (u"ࠨ࠰࡬ࡲ࡮࠭ॾ")
    l11ll11l1_opy_  = os.path.join(PATH, l11lll1l1_opy_)
    response = l11lllll1_opy_(l11l11l_opy_)
    result   = response[l1111l_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩॿ")]
    l1lll111_opy_ = result[l1111l_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩঀ")]
    l11llll11_opy_  = file(l11ll11l1_opy_, l1111l_opy_ (u"ࠫࡼ࠭ঁ"))
    l11llll11_opy_.write(l1111l_opy_ (u"ࠬࡡࠧং"))
    l11llll11_opy_.write(l11l11l_opy_)
    l11llll11_opy_.write(l1111l_opy_ (u"࠭࡝ࠨঃ"))
    l11llll11_opy_.write(l1111l_opy_ (u"ࠧ࡝ࡰࠪ঄"))
    for l1llll1_opy_ in l1lll111_opy_:
        l1l1lll1_opy_   = l1llll1_opy_[l1111l_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧঅ")]
        stream  = l1llll1_opy_[l1111l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧআ")]
        l11l111ll_opy_  = l111lll1l_opy_(l11l11l_opy_, l1l1lll1_opy_)
        l1llll1_opy_ = l1l1l11_opy_(l11l11l_opy_, l11l111ll_opy_)
        l11llll11_opy_.write(l1111l_opy_ (u"ࠪࠩࡸ࠭ই") % l1llll1_opy_)
        l11llll11_opy_.write(l1111l_opy_ (u"ࠫࡂ࠭ঈ"))
        l11llll11_opy_.write(l1111l_opy_ (u"ࠬࠫࡳࠨউ") % stream)
        l11llll11_opy_.write(l1111l_opy_ (u"࠭࡜࡯ࠩঊ"))
    l11llll11_opy_.write(l1111l_opy_ (u"ࠧ࡝ࡰࠪঋ"))
    l11llll11_opy_.close()
def l11ll1l1l_opy_(l11l11l_opy_):
    if l11l11l_opy_ == l11l1111l_opy_:
        return l1111l_opy_ (u"ࠨࡷ࡮ࡸࡻ࡬ࡲࡢࡰࡦࡩࠬঌ")
    if l11l11l_opy_ == l11l11l11_opy_:
        return l1111l_opy_ (u"ࠩࡻࡸࡷ࡫ࡡ࡮࠯ࡦࡳࡩ࡫ࡳࠨ঍")
    if l11l11l_opy_ == l11l11111_opy_:
        return l1111l_opy_ (u"ࠪ࡭ࡵࡺࡶࡴࡷࡥࡷࠬ঎")
    if l11l11l_opy_ == l11l11ll1_opy_:
        return l1111l_opy_ (u"ࠫࡩ࡫ࡸࠨএ")
def l11lllll1_opy_(l11l11l_opy_):
    Addon    =  xbmcaddon.Addon(l11l11l_opy_)
    username =  Addon.getSetting(l1111l_opy_ (u"ࠬࡱࡡࡴࡷࡷࡥ࡯ࡧ࡮ࡪ࡯࡬ࠫঐ"))
    password =  Addon.getSetting(l1111l_opy_ (u"࠭ࡳࡢ࡮ࡤࡷࡴࡴࡡࠨ঑"))
    url      =  l1111l_opy_ (u"ࠧࠨ঒")
    if l11l11l_opy_ == l11l11ll1_opy_:
        url  =  Addon.getSetting('lehekylg1')
    l11l1lll1_opy_   = l1111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬঔ") + l11l11l_opy_
    l111lll11_opy_     = l1111l_opy_ (u"ࠪ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡹࡴࡳࡧࡤࡱࡤࡼࡩࡥࡧࡲࠪࡪࡾࡴࡳࡣࠩࡴࡦ࡭ࡥࠧࡲ࡯ࡳࡹࠬࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠿ࠩࡸ࡮ࡺ࡬ࡦ࠿ࡄࡰࡱࠬࡵࡳ࡮ࡀࠫক")
    l11ll1ll1_opy_  =  l11llll1l_opy_(l11l11l_opy_, url)
    l11l111l1_opy_  =  l11l1lll1_opy_ + l111lll11_opy_ + l11ll1ll1_opy_
    l11l11l1l_opy_ = l1111l_opy_ (u"ࠫࡺࡹࡥࡳࡰࡤࡱࡪࡃࠧখ") + username + l1111l_opy_ (u"ࠬࠬࡰࡢࡵࡶࡻࡴࡸࡤ࠾ࠩগ") + password + l1111l_opy_ (u"࠭ࠦࡵࡻࡳࡩࡂ࡭ࡥࡵࡡ࡯࡭ࡻ࡫࡟ࡴࡶࡵࡩࡦࡳࡳࠧࡥࡤࡸࡤ࡯ࡤ࠾࠲ࠪঘ")
    l11l1ll_opy_ = l11l1lll1_opy_  + l1111l_opy_ (u"ࠧ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿ࡶࡩࡨࡻࡲࡪࡶࡼࡣࡨ࡮ࡥࡤ࡭ࠩࡩࡽࡺࡲࡢࠨࡳࡥ࡬࡫ࠦࡱ࡮ࡲࡸࠫࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠧࡶ࡬ࡸࡱ࡫࠽ࡍ࡫ࡹࡩࠪ࠸࠰ࡕࡘࠩࡹࡷࡲࠧঙ")
    query = l11l111l1_opy_ +  urllib.quote_plus(l11l11l1l_opy_)
    l111llll1_opy_ = (l1111l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫচ") % l11l1ll_opy_)
    l111lllll_opy_ = (l1111l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬছ") % query)
    try:
        xbmc.executeJSONRPC(l111llll1_opy_)
        response = xbmc.executeJSONRPC(l111lllll_opy_)
        content = json.loads(response.decode(l1111l_opy_ (u"ࠪࡹࡹ࡬࠭࠹ࠩজ"), l1111l_opy_ (u"ࠫ࡮࡭࡮ࡰࡴࡨࠫঝ")))
        return content
    except Exception as e:
        l1l1l1l1_opy_(e)
        return {l1111l_opy_ (u"ࠬࡋࡲࡳࡱࡵࠫঞ") : l1111l_opy_ (u"࠭ࡐ࡭ࡷࡪ࡭ࡳࠦࡅࡳࡴࡲࡶࠬট")}
def l111lll1l_opy_(l11l11l_opy_, l1l1lll1_opy_):
    if (l11l11l_opy_ == l11l1111l_opy_) or (l11l11l_opy_ == l11l11l11_opy_) or (l11l11l_opy_ == l11l11111_opy_):
        l1l1lll1_opy_ = l1l1lll1_opy_.replace(l1111l_opy_ (u"ࠧࠡࠢࠪঠ"), l1111l_opy_ (u"ࠨࠢࠪড")).replace(l1111l_opy_ (u"ࠩࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬঢ"), l1111l_opy_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬণ"))
        return l1l1lll1_opy_
    if l11l11l_opy_ == l11l11ll1_opy_:
        l1l1lll1_opy_ = l1l1lll1_opy_.replace(l1111l_opy_ (u"ࠫࠥࠦࠧত"), l1111l_opy_ (u"ࠬࠦࠧথ")).replace(l1111l_opy_ (u"࠭ࠠ࡜࠱ࡅࡡࠬদ"), l1111l_opy_ (u"ࠧ࡜࠱ࡅࡡࠬধ"))
        return l1l1lll1_opy_
def l1l1l11_opy_(l11l11l_opy_, l11l111ll_opy_):
    if (l11l11l_opy_ == l11l1111l_opy_) or (l11l11l_opy_ == l11l11l11_opy_) or (l11l11l_opy_ == l11l11111_opy_):
        l1llll1_opy_ = l11l111ll_opy_.rsplit(l1111l_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪন"), 1)[0].split(l1111l_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡺ࡬࡮ࡺࡥ࡞ࠩ঩"), 1)[-1]
        return l1llll1_opy_
    if l11l11l_opy_ == l11l11ll1_opy_:
        l1llll1_opy_ = l11l111ll_opy_.rsplit(l1111l_opy_ (u"ࠪ࡟࠴ࡈ࡝ࠨপ"), 1)[0].split(l1111l_opy_ (u"ࠫࡠࡈ࡝ࠨফ"), 1)[-1]
        return l1llll1_opy_
def l11llll1l_opy_(l11l11l_opy_, url):
    if (l11l11l_opy_ == l11l1111l_opy_) or (l11l11l_opy_ == l11l11l11_opy_):
        return l1111l_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠹࠷࠯࠳࠻࠻࠳࠷࠳࠺࠰࠴࠹࠺ࡀ࠸࠱࠲࠳࠳ࡪࡴࡩࡨ࡯ࡤ࠶࠳ࡶࡨࡱࡁࠪব")
    if l11l11l_opy_ == l11l11111_opy_:
        return l1111l_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠲࠯ࡹࡨࡰࡨࡳ࠮ࡵࡸ࠽࠼࠵࠶࠰࠰ࡧࡱ࡭࡬ࡳࡡ࠳࠰ࡳ࡬ࡵࡅࠧভ")
    if l11l11l_opy_ == l11l11ll1_opy_:
        l111lll11_opy_ =  url + l1111l_opy_ (u"ࠧ࠻࠺࠳࠴࠵࠵ࡥ࡯࡫ࡪࡱࡦ࠸࠮ࡱࡪࡳࡃࠬম")
        return l111lll11_opy_
def l1l1l1l1_opy_(e):
    l1l1llll_opy_ = l1111l_opy_ (u"ࠨࡕࡲࡶࡷࡿࠬࠡࡣࡱࠤࡪࡸࡲࡰࡴࠣࡳࡨࡩࡵࡳࡧࡧ࠾ࠥࡐࡓࡐࡐࠣࡉࡷࡸ࡯ࡳ࠼ࠣࠩࡸ࠭য")  %e
    l1l1l1ll_opy_ = l1111l_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡹࡸࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡦࡰࡴࡸࡱ࠳࠭র")
    l1ll111l_opy_ = l1111l_opy_ (u"࡙ࠪࡵࡲ࡯ࡢࡦࠣࡥࠥࡲ࡯ࡨࠢࡹ࡭ࡦࠦࡴࡩࡧࠣࡥࡩࡪ࡯࡯ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠤࡦࡴࡤࠡࡲࡲࡷࡹࠦࡴࡩࡧࠣࡰ࡮ࡴ࡫࠯ࠩ঱")
    dixie.log(e)
    dixie.DialogOK(l1l1llll_opy_, l1l1l1ll_opy_, l1ll111l_opy_)
    dixie.SetSetting(SETTING, l1111l_opy_ (u"ࠫࠬল"))