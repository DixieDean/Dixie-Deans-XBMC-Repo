# -*- coding: utf-8 -*-
import sys
l1l1l1l1_opy_ = sys.version_info [0] == 2
l111l1l_opy_ = 2048
l1l1ll11_opy_ = 7
def l1l1l_opy_ (l1l111_opy_):
	global l111lll_opy_
	l1llllll_opy_ = ord (l1l111_opy_ [-1])
	l1l1ll1l_opy_ = l1l111_opy_ [:-1]
	l1l1111_opy_ = l1llllll_opy_ % len (l1l1ll1l_opy_)
	l11l11_opy_ = l1l1ll1l_opy_ [:l1l1111_opy_] + l1l1ll1l_opy_ [l1l1111_opy_:]
	if l1l1l1l1_opy_:
		l1111_opy_ = unicode () .join ([unichr (ord (char) - l111l1l_opy_ - (l1lll_opy_ + l1llllll_opy_) % l1l1ll11_opy_) for l1lll_opy_, char in enumerate (l11l11_opy_)])
	else:
		l1111_opy_ = str () .join ([chr (ord (char) - l111l1l_opy_ - (l1lll_opy_ + l1llllll_opy_) % l1l1ll11_opy_) for l1lll_opy_, char in enumerate (l11l11_opy_)])
	return eval (l1111_opy_)
import platform
try:    l111l1l1l_opy_ = platform.system
except: l111l1l1l_opy_ = None
def l111ll1l1_opy_():
    if l111l1l1l_opy_:
        return l111l1l1l_opy_()
    import sys
    if sys.platform.lower().startswith(l1l1l_opy_ (u"ࠨࡹ࡬ࡲࠬॢ")):
        return l1l1l_opy_ (u"࡚ࠩ࡭ࡳࡪ࡯ࡸࡵࠪॣ")
    return l1l1l_opy_ (u"ࠪࡓࡹ࡮ࡥࡳࠢࡒࡗࡪࡹࠠࡵࡱࠣࡦࡪࠦࡤࡦࡶࡨࡶࡲ࡯࡮ࡦࡦࠪ।")
platform.system = l111ll1l1_opy_
import requests
platform.system = l111l1l1l_opy_
import os
import json
import dixie
l1ll111l_opy_ = dixie.PROFILE
PATH = os.path.join(l1ll111l_opy_, l1l1l_opy_ (u"ࠫࡵࡲࡩࡴࡶࡶࠫ॥"))
def loadPlaylists():
    dixie.log(l1l1l_opy_ (u"ࠬࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࠥࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠡ࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃࠧ०"))
    if os.path.exists(PATH):
        return json.load(open(PATH))
    try:
        l111llll1_opy_()
        return json.load(open(PATH))
    except:
        dixie.log(l1l1l_opy_ (u"࠭࠽࠾࠿ࡀࠤࡕࡲࡡࡺ࡮࡬ࡷࡹࠦ࡬ࡰࡣࡧࠤࡪࡸࡲࡰࡴࠣࡁࡂࡃ࠽ࠨ१"))
        return []
def l111llll1_opy_():
    source = dixie.GetSetting(l1l1l_opy_ (u"ࠧࡪࡲࡷࡺ࠳ࡹ࡯ࡶࡴࡦࡩࠬ२"))
    if not source == l1l1l_opy_ (u"ࠨ࠳ࠪ३"):
        return l11l111l1_opy_()
    return l1111ll11_opy_()
def l11l111l1_opy_():
    l11ll1111_opy_ = []
    if dixie.GetSetting(l1l1l_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠱ࠩ४")) == l1l1l_opy_ (u"ࠪࡸࡷࡻࡥࠨ५"):
        l111ll11l_opy_  = dixie.GetSetting(l1l1l_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠳ࡣ࡚ࡘࡌࠨ६"))
        l11l1l111_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠴ࡤࡖࡏࡓࡖࠪ७"))
        l11l11111_opy_ = dixie.GetSetting(l1l1l_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠵ࡥࡔ࡚ࡒࡈࠫ८"))
        l11l1l1l1_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠶࡟ࡖࡕࡈࡖࠬ९"))
        l11l1l1ll_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠰ࡠࡒࡄࡗࡘ࠭॰"))
        if len(l111ll11l_opy_) > 0:
            l1111ll1l_opy_ = l11l1l11l_opy_(l111ll11l_opy_, l11l1l111_opy_, l11l11111_opy_, l11l1l1l1_opy_, l11l1l1ll_opy_)
            l11ll1111_opy_.append((l1111ll1l_opy_, l1l1l_opy_ (u"ࠩࡌࡔ࡙࡜࠱࠻ࠢࠪॱ")))
    if dixie.GetSetting(l1l1l_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠳ࠪॲ")) == l1l1l_opy_ (u"ࠫࡹࡸࡵࡦࠩॳ"):
        l111ll11l_opy_  = dixie.GetSetting(l1l1l_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠵ࡤ࡛ࡒࡍࠩॴ"))
        l11l1l111_opy_ = dixie.GetSetting(l1l1l_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠶ࡥࡐࡐࡔࡗࠫॵ"))
        l11l11111_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠷࡟ࡕ࡛ࡓࡉࠬॶ"))
        l11l1l1l1_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠱ࡠࡗࡖࡉࡗ࠭ॷ"))
        l11l1l1ll_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠲ࡡࡓࡅࡘ࡙ࠧॸ"))
        if len(l111ll11l_opy_) > 0:
            l11l11lll_opy_ = l11l1l11l_opy_(l111ll11l_opy_, l11l1l111_opy_, l11l11111_opy_, l11l1l1l1_opy_, l11l1l1ll_opy_)
            l11ll1111_opy_.append((l11l11lll_opy_, l1l1l_opy_ (u"ࠪࡍࡕ࡚ࡖ࠳࠼ࠣࠫॹ")))
    if dixie.GetSetting(l1l1l_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠵ࠫॺ")) == l1l1l_opy_ (u"ࠬࡺࡲࡶࡧࠪॻ"):
        l111ll11l_opy_  = dixie.GetSetting(l1l1l_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠷ࡥࡕࡓࡎࠪॼ"))
        l11l1l111_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠸࡟ࡑࡑࡕࡘࠬॽ"))
        l11l11111_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠲ࡠࡖ࡜ࡔࡊ࠭ॾ"))
        l11l1l1l1_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠳ࡡࡘࡗࡊࡘࠧॿ"))
        l11l1l1ll_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠴ࡢࡔࡆ࡙ࡓࠨঀ"))
        if len(l111ll11l_opy_) > 0:
            l11l11ll1_opy_ = l11l1l11l_opy_(l111ll11l_opy_, l11l1l111_opy_, l11l11111_opy_, l11l1l1l1_opy_, l11l1l1ll_opy_)
            l11ll1111_opy_.append((l11l11ll1_opy_, l1l1l_opy_ (u"ࠫࡎࡖࡔࡗ࠵࠽ࠤࠬঁ")))
    return l111l1l11_opy_(l1l1l_opy_ (u"࡛ࠬࡒࡍࡕࠪং"),  l11ll1111_opy_)
def l1111ll11_opy_():
    l11ll1111_opy_ = []
    if dixie.GetSetting(l1l1l_opy_ (u"࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡶࡼࡴࡪ࠭ঃ")) == l1l1l_opy_ (u"ࠧ࠱ࠩ঄"):
        if dixie.GetSetting(l1l1l_opy_ (u"ࠨࡗࡕࡐࡤࡕࠧঅ")) == l1l1l_opy_ (u"ࠩࡷࡶࡺ࡫ࠧআ"):
            l1111l1ll_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡻࡲ࡭ࠩই"))
            if len(l1111l1ll_opy_) > 0:
                l11ll1111_opy_.append((l1111l1ll_opy_, l1l1l_opy_ (u"࡚ࠫࡘࡌ࠲࠼ࠣࠫঈ")))
        if dixie.GetSetting(l1l1l_opy_ (u"࡛ࠬࡒࡍࡡ࠴ࠫউ")) == l1l1l_opy_ (u"࠭ࡴࡳࡷࡨࠫঊ"):
            l111l1lll_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡸࡶࡱ࠷ࠧঋ"))
            if len(l111l1lll_opy_) > 0:
                l11ll1111_opy_.append((l111l1lll_opy_, l1l1l_opy_ (u"ࠨࡗࡕࡐ࠷ࡀࠠࠨঌ")))
        if dixie.GetSetting(l1l1l_opy_ (u"ࠩࡘࡖࡑࡥ࠲ࠨ঍")) == l1l1l_opy_ (u"ࠪࡸࡷࡻࡥࠨ঎"):
            l11l11l1l_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡵࡳ࡮࠵ࠫএ"))
            if len(l11l11l1l_opy_) > 0:
                l11ll1111_opy_.append((l11l11l1l_opy_, l1l1l_opy_ (u"࡛ࠬࡒࡍ࠵࠽ࠤࠬঐ")))
        dixie.log(l11ll1111_opy_)
        return l111l1l11_opy_(l1l1l_opy_ (u"࠭ࡕࡓࡎࡖࠫ঑"),  l11ll1111_opy_)
    if dixie.GetSetting(l1l1l_opy_ (u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡷࡽࡵ࡫ࠧ঒")) == l1l1l_opy_ (u"ࠨ࠳ࠪও"):
        if dixie.GetSetting(l1l1l_opy_ (u"ࠩࡉࡍࡑࡋ࡟࠱ࠩঔ")) == l1l1l_opy_ (u"ࠪࡸࡷࡻࡥࠨক"):
            l11l1ll1l_opy_ = os.path.join(dixie.GetSetting(l1l1l_opy_ (u"ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡦࡪ࡮ࡨࠫখ")))
            if l11l1ll1l_opy_:
                l11ll1111_opy_.append((l11l1ll1l_opy_, l1l1l_opy_ (u"ࠬࡌࡉࡍࡇ࠴࠾ࠥ࠭গ")))
        if dixie.GetSetting(l1l1l_opy_ (u"࠭ࡆࡊࡎࡈࡣ࠵࠭ঘ")) == l1l1l_opy_ (u"ࠧࡵࡴࡸࡩࠬঙ"):
            l11l1lll1_opy_ = os.path.join(dixie.GetSetting(l1l1l_opy_ (u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡪ࡮ࡲࡥ࠲ࠩচ")))
            if l11l1lll1_opy_:
                l11ll1111_opy_.append((l11l1lll1_opy_, l1l1l_opy_ (u"ࠩࡉࡍࡑࡋ࠲࠻ࠢࠪছ")))
        if dixie.GetSetting(l1l1l_opy_ (u"ࠪࡊࡎࡒࡅࡠ࠲ࠪজ")) == l1l1l_opy_ (u"ࠫࡹࡸࡵࡦࠩঝ"):
            l11l1llll_opy_ = os.path.join(dixie.GetSetting(l1l1l_opy_ (u"ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡧ࡫࡯ࡩ࠷࠭ঞ")))
            if l11l1llll_opy_:
                l11ll1111_opy_.append((l11l1llll_opy_, l1l1l_opy_ (u"࠭ࡆࡊࡎࡈ࠷࠿ࠦࠧট")))
        dixie.log(l11ll1111_opy_)
        return l111l1l11_opy_(l1l1l_opy_ (u"ࠧࡇࡋࡏࡉࡘ࠭ঠ"), l11ll1111_opy_)
def l1111llll_opy_():
    l111l1111_opy_ = [l1l1l_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡺ࠱ࡧࡴ࠵ࡈࡆ࡜࠸࡞ࡾ࡯ࡊࡦ࡙ࠪড")]
    for url in l111l1111_opy_:
        request = requests.get(url)
        content = request.content
        if l1l1l_opy_ (u"ࠩࠦࡉ࡝࡚ࡍ࠴ࡗࠪঢ") in content:
            return l111l1l11_opy_(l1l1l_opy_ (u"ࠪࡇࡑࡕࡕࡅࠩণ"), [(url, l1l1l_opy_ (u"ࠫࠬত"))])
            break
def l111l1l11_opy_(l111l11ll_opy_, plist):
    dixie.log(l111l11ll_opy_)
    dixie.log(plist)
    playlists = []
    for item in plist:
        url = item[0]
        l111l11l1_opy_ = item[1]
        l11l111ll_opy_ = l11l1ll11_opy_(l111l11ll_opy_, url, l111l11l1_opy_)
        playlists.extend(l11l111ll_opy_)
    json.dump(playlists, open(PATH,l1l1l_opy_ (u"ࠬࡽࠧথ")))
def l11l1ll11_opy_(l111l11ll_opy_, url, l111l11l1_opy_):
    content  = l1111lll1_opy_(l111l11ll_opy_, url)
    pairs    = []
    for i in range(1,len(content), 2):
        if l11l11l11_opy_(content[i]) == True:
            l1llll1_opy_ = content[i]
            l11l1_opy_   = content[i+1]
            pairs.append([l1llll1_opy_, l11l1_opy_])
    l111ll111_opy_ = list()
    l1llll1_opy_   = l1l1l_opy_ (u"࠭ࠧদ")
    value   = l1l1l_opy_ (u"ࠧࠨধ")
    for item in pairs:
        l111lllll_opy_ = item[0]
        l11l1111l_opy_ = item[1]
        l111lll1l_opy_   = l111lllll_opy_.split(l1l1l_opy_ (u"ࠨ࠮ࠪন"))[-1].strip()
        l111lll11_opy_   = dixie.cleanLabel(l111lll1l_opy_)
        l1l11ll_opy_ = dixie.cleanPrefix(l111lll11_opy_)
        l11l1l_opy_ = dixie.mapChannelName(l1l11ll_opy_)
        value = l11l1111l_opy_.replace(l1l1l_opy_ (u"ࠩࡵࡸࡲࡶ࠺࠰࠱ࠧࡓࡕ࡚࠺ࡳࡶࡰࡴ࠲ࡸࡡࡸ࠿ࠪ঩"), l1l1l_opy_ (u"ࠪࠫপ")).replace(l1l1l_opy_ (u"ࠫࡡࡴࠧফ"), l1l1l_opy_ (u"ࠬ࠭ব"))
        l111ll111_opy_.append((l111l11l1_opy_, l11l1l_opy_, value))
    return l111ll111_opy_
def l11l11l11_opy_(l1llll1_opy_):
    dixie.log(l1l1l_opy_ (u"࠭࠽࠾࠿ࡀࡁࡂࡃࠠࡊࡒࡗ࡚ࠥࡒࡁࡃࡇࡏࠤࡂࡃ࠽࠾࠿ࡀࡁࠬভ"))
    dixie.log(l1llll1_opy_)
    if l1llll1_opy_ == l1l1l_opy_ (u"ࠧࠤࡇ࡛ࡘ࠲࡞࠭ࡆࡐࡇࡐࡎ࡙ࡔࠨম"):
        return False
    if len(l1llll1_opy_) < 1:
        return False
    l1llll1_opy_ = l1llll1_opy_.lower()
    filters = dixie.getFilters()
    for l111l111l_opy_ in filters:
        l111l111l_opy_ = l111l111l_opy_.lower()
        if l111l111l_opy_ in l1llll1_opy_:
            return False
    return True
def l1111lll1_opy_(l111l11ll_opy_, url):
    import urllib
    if (l111l11ll_opy_ == l1l1l_opy_ (u"ࠨࡗࡕࡐࡘ࠭য")) or (l111l11ll_opy_ == l1l1l_opy_ (u"ࠩࡆࡐࡔ࡛ࡄࠨর")):
        response = urllib.urlopen(url)
        content  = response.readlines()
        return content
    if l111l11ll_opy_ == l1l1l_opy_ (u"ࠪࡊࡎࡒࡅࡔࠩ঱"):
        with open(url) as content:
            return content.readlines()
def l11l1l11l_opy_(l111ll11l_opy_, l11l1l111_opy_, l11l11111_opy_, l11l1l1l1_opy_, l11l1l1ll_opy_):
    if l111ll11l_opy_.startswith(l1l1l_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬল")):
        url = l111ll11l_opy_
    else:
        url = l1l1l_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭঳") + l111ll11l_opy_
    url +=  l111l1ll1_opy_(l11l1l111_opy_)
    url += l1l1l_opy_ (u"࠭࠯ࡨࡧࡷ࠲ࡵ࡮ࡰࡀࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠫ঴")
    url +=  l11l1l1l1_opy_
    url += l1l1l_opy_ (u"ࠧࠧࡲࡤࡷࡸࡽ࡯ࡳࡦࡀࠫ঵")
    url +=  l11l1l1ll_opy_
    url += l1l1l_opy_ (u"ࠨࠨࡷࡽࡵ࡫࠽࡮࠵ࡸࡣࡵࡲࡵࡴࠨࡲࡹࡹࡶࡵࡵ࠿ࠪশ")
    url +=  l111ll1ll_opy_(l11l11111_opy_)
    return url
def l111l1ll1_opy_(l11l1l111_opy_):
    if not l11l1l111_opy_ == l1l1l_opy_ (u"ࠩࠪষ"):
        return l1l1l_opy_ (u"ࠪ࠾ࠬস") + l11l1l111_opy_
    return l1l1l_opy_ (u"ࠫࠬহ")
def l111ll1ll_opy_(l11l11111_opy_):
    if l11l11111_opy_ == l1l1l_opy_ (u"ࠬ࠶ࠧ঺"):
        return l1l1l_opy_ (u"࠭࡭࠴ࡷ࠻ࠫ঻")
    if l11l11111_opy_ == l1l1l_opy_ (u"ࠧ࠲়ࠩ"):
        return l1l1l_opy_ (u"ࠨ࡯ࡳࡩ࡬ࡺࡳࠨঽ")
if __name__ == l1l1l_opy_ (u"ࠩࡢࡣࡲࡧࡩ࡯ࡡࡢࠫা"):
    l111llll1_opy_()