# coding: UTF-8
import sys
l1llll11_opy_ = sys.version_info [0] == 2
l1ll11l_opy_ = 2048
l1ll11_opy_ = 7
def l111l1_opy_ (ll_opy_):
	global l1ll1_opy_
	l1111l1_opy_ = ord (ll_opy_ [-1])
	l1llll1_opy_ = ll_opy_ [:-1]
	l1l11_opy_ = l1111l1_opy_ % len (l1llll1_opy_)
	l11ll_opy_ = l1llll1_opy_ [:l1l11_opy_] + l1llll1_opy_ [l1l11_opy_:]
	if l1llll11_opy_:
		l1l1ll1_opy_ = unicode () .join ([unichr (ord (char) - l1ll11l_opy_ - (l11l1l_opy_ + l1111l1_opy_) % l1ll11_opy_) for l11l1l_opy_, char in enumerate (l11ll_opy_)])
	else:
		l1l1ll1_opy_ = str () .join ([chr (ord (char) - l1ll11l_opy_ - (l11l1l_opy_ + l1111l1_opy_) % l1ll11_opy_) for l11l1l_opy_, char in enumerate (l11ll_opy_)])
	return eval (l1l1ll1_opy_)
import xbmc
import xbmcaddon
import json
import urllib
import os
import dixie
l1l111111_opy_   = l111l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸ࡯ࡹࡼࡦࡳࡣࡱࡧࡪ࣭࠭")
l11ll1lll_opy_   = l111l1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡹࡸࡥࡢ࡯࠰ࡧࡴࡪࡥࡴ࣮ࠩ")
l11lllll1_opy_ = l111l1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶࡴࡷࡵࡸࡦࡸ࣯࠭")
l1l111l11_opy_   = l111l1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡪࡥࡹࣰࠩ")
l11l1llll_opy_   =  [l1l111111_opy_, l11ll1lll_opy_, l11lllll1_opy_, l1l111l11_opy_]
def checkAddons():
    for l11111_opy_ in l11l1llll_opy_:
        if l11lll11l_opy_(l11111_opy_):
            l11lll1l1_opy_(l11111_opy_)
def l11lll11l_opy_(l11111_opy_):
    if xbmc.getCondVisibility(l111l1_opy_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡉࡣࡶࡅࡩࡪ࡯࡯ࠪࠨࡷ࠮ࣱ࠭") % l11111_opy_) == 1:
        return True
    else:
        return False
def l11lll1l1_opy_(l11111_opy_):
    HOME = dixie.PROFILE
    PATH = os.path.join(HOME, l111l1_opy_ (u"ࠨ࡫ࡱ࡭ࣲࠬ"))
    l1l11l111_opy_ = l11llll1l_opy_(l11111_opy_) + l111l1_opy_ (u"ࠩ࠱࡭ࡳ࡯ࠧࣳ")
    l11ll1111_opy_  = os.path.join(PATH, l1l11l111_opy_)
    response = l1l11ll1l_opy_(l11111_opy_)
    result   = response[l111l1_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪࣴ")]
    l1lll11l_opy_ = result[l111l1_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪࣵ")]
    l1l11l1l1_opy_  = file(l11ll1111_opy_, l111l1_opy_ (u"ࠬࡽࣶࠧ"))
    l1l11l1l1_opy_.write(l111l1_opy_ (u"࡛࠭ࠨࣷ"))
    l1l11l1l1_opy_.write(l11111_opy_)
    l1l11l1l1_opy_.write(l111l1_opy_ (u"ࠧ࡞ࠩࣸ"))
    l1l11l1l1_opy_.write(l111l1_opy_ (u"ࠨ࡞ࡱࣹࠫ"))
    l11lll111_opy_ = []
    for channel in l1lll11l_opy_:
        l11llll11_opy_ = channel[l111l1_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨࣺ")]
        if l111l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡧࡩࡽ࠭ࣻ") in channel[l111l1_opy_ (u"ࠫ࡫࡯࡬ࡦࠩࣼ")]:
            stream = channel[l111l1_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪࣽ")].replace(l111l1_opy_ (u"࠭࠮ࡵࡵࠪࣾ"), l111l1_opy_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭ࣿ"))
        else:
            stream  = channel[l111l1_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ऀ")]
        l11lll1ll_opy_  = l11ll1l11_opy_(l11111_opy_, l11llll11_opy_)
        channel = l1l1l1l_opy_(l11111_opy_, l11lll1ll_opy_)
        l1l111lll_opy_ = channel + l111l1_opy_ (u"ࠩࡀࠫँ") + stream
        l11lll111_opy_.append(l1l111lll_opy_)
        l11lll111_opy_.sort()
    for item in l11lll111_opy_:
      l1l11l1l1_opy_.write(l111l1_opy_ (u"ࠥࠩࡸࡢ࡮ࠣं") % item)
    l1l11l1l1_opy_.close()
def l11llll1l_opy_(l11111_opy_):
    if l11111_opy_ == l1l111111_opy_:
        return l111l1_opy_ (u"ࠫࡺࡱࡴࡷࡨࡵࡥࡳࡩࡥࠨः")
    if l11111_opy_ == l11ll1lll_opy_:
        return l111l1_opy_ (u"ࠬࡾࡴࡳࡧࡤࡱ࠲ࡩ࡯ࡥࡧࡶࠫऄ")
    if l11111_opy_ == l11lllll1_opy_:
        return l111l1_opy_ (u"࠭ࡩࡱࡶࡹࡷࡺࡨࡳࠨअ")
    if l11111_opy_ == l1l111l11_opy_:
        return l111l1_opy_ (u"ࠧࡥࡧࡻࠫआ")
def l1l11ll1l_opy_(l11111_opy_):
    Addon    =  xbmcaddon.Addon(l11111_opy_)
    username =  Addon.getSetting(l111l1_opy_ (u"ࠨ࡭ࡤࡷࡺࡺࡡ࡫ࡣࡱ࡭ࡲ࡯ࠧइ"))
    password =  Addon.getSetting(l111l1_opy_ (u"ࠩࡶࡥࡱࡧࡳࡰࡰࡤࠫई"))
    l11ll111l_opy_   = l111l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭उ") + l11111_opy_
    l11ll11ll_opy_     = l111l1_opy_ (u"ࠫ࠴ࡅࡡࡤࡶ࡬ࡳࡳࡃࡳࡵࡴࡨࡥࡲࡥࡶࡪࡦࡨࡳࠫ࡫ࡸࡵࡴࡤࠪࡵࡧࡧࡦࠨࡳࡰࡴࡺࠦࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡀࠪࡹ࡯ࡴ࡭ࡧࡀࡅࡱࡲࠦࡶࡴ࡯ࡁࠬऊ")
    l11llllll_opy_  =  l1l11ll11_opy_(l11111_opy_)
    l11ll1l1l_opy_  =  l11ll111l_opy_ + l11ll11ll_opy_ + l11llllll_opy_
    l1l11l1ll_opy_ = l111l1_opy_ (u"ࠬࡻࡳࡦࡴࡱࡥࡲ࡫࠽ࠨऋ") + username + l111l1_opy_ (u"࠭ࠦࡱࡣࡶࡷࡼࡵࡲࡥ࠿ࠪऌ") + password + l111l1_opy_ (u"ࠧࠧࡶࡼࡴࡪࡃࡧࡦࡶࡢࡰ࡮ࡼࡥࡠࡵࡷࡶࡪࡧ࡭ࡴࠨࡦࡥࡹࡥࡩࡥ࠿࠳ࠫऍ")
    l1llll1l_opy_ = l11ll111l_opy_  + l111l1_opy_ (u"ࠨ࠱ࡂࡥࡨࡺࡩࡰࡰࡀࡷࡪࡩࡵࡳ࡫ࡷࡽࡤࡩࡨࡦࡥ࡮ࠪࡪࡾࡴࡳࡣࠩࡴࡦ࡭ࡥࠧࡲ࡯ࡳࡹࠬࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠨࡷ࡭ࡹࡲࡥ࠾ࡎ࡬ࡺࡪࠫ࠲࠱ࡖ࡙ࠪࡺࡸ࡬ࠨऎ")
    query = l11ll1l1l_opy_ +  urllib.quote_plus(l1l11l1ll_opy_)
    l1l111l1l_opy_ = (l111l1_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬए") % l1llll1l_opy_)
    l1l11l11l_opy_ = (l111l1_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ऐ") % query)
    try:
        xbmc.executeJSONRPC(l1l111l1l_opy_)
        response = xbmc.executeJSONRPC(l1l11l11l_opy_)
        content = json.loads(response.decode(l111l1_opy_ (u"ࠫࡺࡺࡦ࠮࠺ࠪऑ"), l111l1_opy_ (u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬऒ")))
        return content
    except Exception as e:
        l11ll11l1_opy_(e)
        return {l111l1_opy_ (u"࠭ࡅࡳࡴࡲࡶࠬओ") : l111l1_opy_ (u"ࠧࡑ࡮ࡸ࡫࡮ࡴࠠࡆࡴࡵࡳࡷ࠭औ")}
def l11ll1l11_opy_(l11111_opy_, l1l111ll1_opy_):
    if (l11111_opy_ == l1l111111_opy_) or (l11111_opy_ == l11ll1lll_opy_) or (l11111_opy_ == l11lllll1_opy_):
        l1l111ll1_opy_ = l1l111ll1_opy_.replace(l111l1_opy_ (u"ࠨࠢࠣࠫक"), l111l1_opy_ (u"ࠩࠣࠫख")).replace(l111l1_opy_ (u"ࠪࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ग"), l111l1_opy_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭घ"))
        return l1l111ll1_opy_
    if l11111_opy_ == l1l111l11_opy_:
        l1l111ll1_opy_ = l1l111ll1_opy_.replace(l111l1_opy_ (u"ࠬࠦࠠࠨङ"), l111l1_opy_ (u"࠭ࠠࠨच")).replace(l111l1_opy_ (u"ࠧࠡ࡝࠲ࡆࡢ࠭छ"), l111l1_opy_ (u"ࠨ࡝࠲ࡆࡢ࠭ज"))
        return l1l111ll1_opy_
def l1l1l1l_opy_(l11111_opy_, l11ll1ll1_opy_):
    if (l11111_opy_ == l1l111111_opy_) or (l11111_opy_ == l11ll1lll_opy_) or (l11111_opy_ == l11lllll1_opy_):
        channel = l11ll1ll1_opy_.rsplit(l111l1_opy_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫझ"), 1)[0].split(l111l1_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡻ࡭࡯ࡴࡦ࡟ࠪञ"), 1)[-1]
        return channel
    if l11111_opy_ == l1l111l11_opy_:
        channel = l11ll1ll1_opy_.rsplit(l111l1_opy_ (u"ࠫࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧट"))[0].replace(l111l1_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡽࡨࡪࡶࡨࡡࠬठ"), l111l1_opy_ (u"࠭ࠧड"))
        return channel
def l1l11ll11_opy_(l11111_opy_):
    if (l11111_opy_ == l1l111111_opy_) or (l11111_opy_ == l11ll1lll_opy_):
        return l111l1_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠴࠹࠱࠵࠽࠽࠮࠲࠵࠼࠲࠶࠻࠵࠻࠺࠳࠴࠵࠵ࡥ࡯࡫ࡪࡱࡦ࠸࠮ࡱࡪࡳࡃࠬढ")
    if l11111_opy_ == l11lllll1_opy_:
        return l111l1_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠴࠱ࡻࡪࡲࡣ࡮࠰ࡷࡺ࠿࠾࠰࠱࠲࠲ࡩࡳ࡯ࡧ࡮ࡣ࠵࠲ࡵ࡮ࡰࡀࠩण")
    if l11111_opy_ == l1l111l11_opy_:
        return l111l1_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠹࠽࠴࠶࠺࠰࠸࠸࠳࠻࠴࠻࠺࠳࠴࠵࠵ࡥ࡯࡫ࡪࡱࡦ࠸࠮ࡱࡪࡳࡃࠬत")
def l11ll11l1_opy_(e):
    l1l11111l_opy_ = l111l1_opy_ (u"ࠪࡗࡴࡸࡲࡺ࠮ࠣࡥࡳࠦࡥࡳࡴࡲࡶࠥࡵࡣࡤࡷࡵࡩࡩࡀࠠࡋࡕࡒࡒࠥࡋࡲࡳࡱࡵ࠾ࠥࠫࡳࠨथ")  %e
    l1l1111l1_opy_ = l111l1_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡨࡵ࡮ࡵࡣࡦࡸࠥࡻࡳࠡࡱࡱࠤࡹ࡮ࡥࠡࡨࡲࡶࡺࡳ࠮ࠨद")
    l1l1111ll_opy_ = l111l1_opy_ (u"࡛ࠬࡰ࡭ࡱࡤࡨࠥࡧࠠ࡭ࡱࡪࠤࡻ࡯ࡡࠡࡶ࡫ࡩࠥࡧࡤࡥࡱࡱࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸࠦࡡ࡯ࡦࠣࡴࡴࡹࡴࠡࡶ࡫ࡩࠥࡲࡩ࡯࡭࠱ࠫध")
    dixie.log(e)
    dixie.DialogOK(l1l11111l_opy_, l1l1111l1_opy_, l1l1111ll_opy_)
    dixie.SetSetting(SETTING, l111l1_opy_ (u"࠭ࠧन"))