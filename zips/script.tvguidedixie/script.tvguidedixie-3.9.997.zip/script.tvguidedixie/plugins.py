# coding: UTF-8
import sys
l1l1ll11_opy_ = sys.version_info [0] == 2
l111lll_opy_ = 2048
l1l1lll1_opy_ = 7
def l1l1l_opy_ (l1l111_opy_):
	global l11l11l_opy_
	l11111l_opy_ = ord (l1l111_opy_ [-1])
	l1l1llll_opy_ = l1l111_opy_ [:-1]
	l1l111l_opy_ = l11111l_opy_ % len (l1l1llll_opy_)
	l11l11_opy_ = l1l1llll_opy_ [:l1l111l_opy_] + l1l1llll_opy_ [l1l111l_opy_:]
	if l1l1ll11_opy_:
		l1111_opy_ = unicode () .join ([unichr (ord (char) - l111lll_opy_ - (l1lll_opy_ + l11111l_opy_) % l1l1lll1_opy_) for l1lll_opy_, char in enumerate (l11l11_opy_)])
	else:
		l1111_opy_ = str () .join ([chr (ord (char) - l111lll_opy_ - (l1lll_opy_ + l11111l_opy_) % l1l1lll1_opy_) for l1lll_opy_, char in enumerate (l11l11_opy_)])
	return eval (l1111_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l11l11l1l_opy_     = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡯ࡶࡹ्ࠫ")
l11l11111_opy_  = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡹ࡯࡭ࡵࡺࡶࠨॎ")
l11ll1111_opy_     = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸ࡯ࡹࡻࡲ࡬ࠩॏ")
locked  = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰࡴࡩ࡫ࡦࡦࡷࡺࠬॐ")
l111ll1ll_opy_      = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡲࡴࡪ࡯ࡤࡸࡪࡳࡡ࡯࡫ࡤࠫ॑")
l111llll1_opy_    = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲࡩࡶࡺ࠱ࡸࡻ॒࠭")
l11l111l1_opy_     = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡄࡄࡕࡳࡳࡷࡺࡳࠨ॓")
l11l1llll_opy_  = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡧࡥࡳࡴࡺࠧ॔")
l11l111ll_opy_     = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡥ࡯ࡹ࡮ࡶࡴࡷࠩॕ")
l11l1lll1_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸ࡯ࡹࡼ࠴ࡦࡺࡳࡥࡹࡹ࠮ࡤࡱࡰࠫॖ")
l1llllll_opy_ = [l11l11l1l_opy_, locked, l111llll1_opy_, l11l11111_opy_, l11l1lll1_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1l1l_opy_ (u"ࠫ࡮ࡴࡩࠨॗ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1l1ll1_opy_ = l1l1l_opy_ (u"ࠬ࠭क़")
def l1l11l_opy_(i, t1, l1l1l1_opy_=[]):
 t = l1l1ll1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l1l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11_opy_ = l1l11l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11lll_opy_ = l1l11l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1llllll_opy_:
        if l1l11ll_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1l11ll_opy_(addon):
    if xbmc.getCondVisibility(l1l1l_opy_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡈࡢࡵࡄࡨࡩࡵ࡮ࠩࠧࡶ࠭ࠬख़") % addon) == 1:
        return True
    return False
def createINI(addon):
    l1l11111_opy_ = str(addon).split(l1l1l_opy_ (u"ࠧ࠯ࠩग़"))[2] + l1l1l_opy_ (u"ࠨ࠰࡬ࡲ࡮࠭ज़")
    l1l1ll1l_opy_  = os.path.join(PATH, l1l11111_opy_)
    try:
        l1l1111_opy_ = l1lllll1_opy_(addon)
    except KeyError:
        dixie.log(l1l1l_opy_ (u"ࠩ࠰࠱࠲࠳࠭ࠡࡍࡨࡽࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡧࡦࡶࡉ࡭ࡱ࡫ࡳࠡ࠯࠰࠱࠲࠳ࠠࠨड़") + addon)
        result = {l1l1l_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࡵࠪढ़"): [{l1l1l_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧफ़"): l1l1l_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࠫय़"), l1l1l_opy_ (u"ࡻࠧࡵࡻࡳࡩࠬॠ"): l1l1l_opy_ (u"ࡵࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩॡ"), l1l1l_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࠧॢ"): l1l1l_opy_ (u"ࡷࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡾࡸࠨॣ"), l1l1l_opy_ (u"ࡸࠫࡱࡧࡢࡦ࡮ࠪ।"): l1l1l_opy_ (u"ࡹࠬࡔࡏࠡࡅࡋࡅࡓࡔࡅࡍࡕࠪ॥")}], l1l1l_opy_ (u"ࡺ࠭࡬ࡪ࡯࡬ࡸࡸ࠭०"):{l1l1l_opy_ (u"ࡻࠧࡴࡶࡤࡶࡹ࠭१"): 0, l1l1l_opy_ (u"ࡵࠨࡶࡲࡸࡦࡲࠧ२"): 1, l1l1l_opy_ (u"ࡶࠩࡨࡲࡩ࠭३"): 1}}
    l1l1ll_opy_  = l1l1l_opy_ (u"ࠩ࡞ࠫ४") + addon + l1l1l_opy_ (u"ࠪࡡࡡࡴࠧ५")
    l1lll1l1_opy_  =  file(l1l1ll1l_opy_, l1l1l_opy_ (u"ࠫࡼ࠭६"))
    l1lll1l1_opy_.write(l1l1ll_opy_)
    l1l1l1l1_opy_ = []
    for channel in l1l1111_opy_:
        l1l1_opy_ = dixie.cleanLabel(channel[l1l1l_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫ७")])
        l1l1l11_opy_   = dixie.cleanPrefix(l1l1_opy_)
        l11l1l_opy_ = dixie.mapChannelName(l1l1l11_opy_)
        stream   = channel[l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࠫ८")]
        l111l1_opy_ = l11l1l_opy_ + l1l1l_opy_ (u"ࠧ࠾ࠩ९") + stream
        l1l1l1l1_opy_.append(l111l1_opy_)
        l1l1l1l1_opy_.sort()
    for item in l1l1l1l1_opy_:
        l1lll1l1_opy_.write(l1l1l_opy_ (u"ࠣࠧࡶࡠࡳࠨ॰") % item)
    l1lll1l1_opy_.close()
def l1lllll1_opy_(addon):
    if (addon == l11l11l1l_opy_) or (addon == l11l11111_opy_):
        if xbmcaddon.Addon(addon).getSetting(l1l1l_opy_ (u"ࠩࡪࡩࡳࡸࡥࠨॱ")) == l1l1l_opy_ (u"ࠪࡸࡷࡻࡥࠨॲ"):
            xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"ࠫ࡬࡫࡮ࡳࡧࠪॳ"), l1l1l_opy_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫॴ"))
            xbmcgui.Window(10000).setProperty(l1l1l_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡇࡆࡐࡕࡉࠬॵ"), l1l1l_opy_ (u"ࠧࡕࡴࡸࡩࠬॶ"))
        if xbmcaddon.Addon(addon).getSetting(l1l1l_opy_ (u"ࠨࡶࡹ࡫ࡺ࡯ࡤࡦࠩॷ")) == l1l1l_opy_ (u"ࠩࡷࡶࡺ࡫ࠧॸ"):
            xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"ࠪࡸࡻ࡭ࡵࡪࡦࡨࠫॹ"), l1l1l_opy_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪॺ"))
            xbmcgui.Window(10000).setProperty(l1l1l_opy_ (u"ࠬࡖࡌࡖࡉࡌࡒࡤ࡚ࡖࡈࡗࡌࡈࡊ࠭ॻ"), l1l1l_opy_ (u"࠭ࡔࡳࡷࡨࠫॼ"))
        l111lllll_opy_  = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪॽ") + addon
        l11l1ll11_opy_ =  l11ll11l1_opy_(addon)
        query   =  l111lllll_opy_ + l11l1ll11_opy_
        return sendJSON(query, addon)
    return l11l1l111_opy_(addon)
def l11l1l111_opy_(addon):
    if addon == l11l1lll1_opy_:
        l11l1l11l_opy_ = [l1l1l_opy_ (u"ࠨ࠳࠹࠵ࠬॾ"), l1l1l_opy_ (u"ࠩ࠴࠺࠵࠭ॿ"), l1l1l_opy_ (u"ࠪ࠶࠸࠼ࠧঀ"), l1l1l_opy_ (u"ࠫ࠷࠺࠲ࠨঁ"), l1l1l_opy_ (u"ࠬ࠷࠵࠹ࠩং"), l1l1l_opy_ (u"࠭࠱࠶࠻ࠪঃ")]
    if addon == l111llll1_opy_:
        l11l1l11l_opy_ = [l1l1l_opy_ (u"ࠧ࠶ࠩ঄"), l1l1l_opy_ (u"ࠨ࠳࠳࠺ࠬঅ"), l1l1l_opy_ (u"ࠩ࠷ࠫআ"), l1l1l_opy_ (u"ࠪ࠶࠻࠹ࠧই"), l1l1l_opy_ (u"ࠫ࠶࠹࠲ࠨঈ")]
    if addon == locked:
        l11l1l11l_opy_ = [l1l1l_opy_ (u"ࠬ࠹࠰ࠨউ"), l1l1l_opy_ (u"࠭࠳࠲ࠩঊ"), l1l1l_opy_ (u"ࠧ࠴࠴ࠪঋ"), l1l1l_opy_ (u"ࠨ࠵࠶ࠫঌ"), l1l1l_opy_ (u"ࠩ࠶࠸ࠬ঍"), l1l1l_opy_ (u"ࠪ࠷࠺࠭঎"), l1l1l_opy_ (u"ࠫ࠸࠾ࠧএ"), l1l1l_opy_ (u"ࠬ࠺࠰ࠨঐ"), l1l1l_opy_ (u"࠭࠴࠲ࠩ঑"), l1l1l_opy_ (u"ࠧ࠵࠷ࠪ঒"), l1l1l_opy_ (u"ࠨ࠶࠺ࠫও"), l1l1l_opy_ (u"ࠩ࠷࠽ࠬঔ"), l1l1l_opy_ (u"ࠪ࠹࠷࠭ক")]
    if addon == l111ll1ll_opy_:
        l11l1l11l_opy_ = [l1l1l_opy_ (u"ࠫ࠷࠻ࠧখ"), l1l1l_opy_ (u"ࠬ࠸࠶ࠨগ"), l1l1l_opy_ (u"࠭࠲࠸ࠩঘ"), l1l1l_opy_ (u"ࠧ࠳࠻ࠪঙ"), l1l1l_opy_ (u"ࠨ࠵࠳ࠫচ"), l1l1l_opy_ (u"ࠩ࠶࠵ࠬছ"), l1l1l_opy_ (u"ࠪ࠷࠷࠭জ"), l1l1l_opy_ (u"ࠫ࠸࠻ࠧঝ"), l1l1l_opy_ (u"ࠬ࠹࠶ࠨঞ"), l1l1l_opy_ (u"࠭࠳࠸ࠩট"), l1l1l_opy_ (u"ࠧ࠴࠺ࠪঠ"), l1l1l_opy_ (u"ࠨ࠵࠼ࠫড"), l1l1l_opy_ (u"ࠩ࠷࠴ࠬঢ"), l1l1l_opy_ (u"ࠪ࠸࠶࠭ণ"), l1l1l_opy_ (u"ࠫ࠹࠾ࠧত"), l1l1l_opy_ (u"ࠬ࠺࠹ࠨথ"), l1l1l_opy_ (u"࠭࠵࠱ࠩদ"), l1l1l_opy_ (u"ࠧ࠶࠴ࠪধ"), l1l1l_opy_ (u"ࠨ࠷࠷ࠫন"), l1l1l_opy_ (u"ࠩ࠸࠺ࠬ঩"), l1l1l_opy_ (u"ࠪ࠹࠼࠭প"), l1l1l_opy_ (u"ࠫ࠺࠾ࠧফ"), l1l1l_opy_ (u"ࠬ࠻࠹ࠨব"), l1l1l_opy_ (u"࠭࠶࠱ࠩভ"), l1l1l_opy_ (u"ࠧ࠷࠳ࠪম"), l1l1l_opy_ (u"ࠨ࠸࠵ࠫয"), l1l1l_opy_ (u"ࠩ࠹࠷ࠬর"), l1l1l_opy_ (u"ࠪ࠺࠺࠭঱"), l1l1l_opy_ (u"ࠫ࠻࠼ࠧল"), l1l1l_opy_ (u"ࠬ࠼࠷ࠨ঳"), l1l1l_opy_ (u"࠭࠶࠺ࠩ঴"), l1l1l_opy_ (u"ࠧ࠸࠲ࠪ঵"), l1l1l_opy_ (u"ࠨ࠹࠷ࠫশ"), l1l1l_opy_ (u"ࠩ࠺࠻ࠬষ"), l1l1l_opy_ (u"ࠪ࠻࠽࠭স"), l1l1l_opy_ (u"ࠫ࠽࠶ࠧহ"), l1l1l_opy_ (u"ࠬ࠾࠱ࠨ঺")]
    login = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶ࠳ࠬ঻") % addon
    sendJSON(login, addon)
    l11l1l1_opy_ = []
    for l11ll111l_opy_ in l11l1l11l_opy_:
        if (addon == l11l1lll1_opy_) or (addon == l111llll1_opy_):
            query = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷ࠴ࡅ࡭ࡰࡦࡨࡣ࡮ࡪ࠽ࡤࡪࡤࡲࡳ࡫࡬ࡴࠨࡰࡳࡩ࡫࠽ࡤࡪࡤࡲࡳ࡫࡬ࡴࠨࡶࡩࡨࡺࡩࡰࡰࡢ࡭ࡩࡃࠥࡴ়ࠩ") % (addon, l11ll111l_opy_)
        if (addon == locked) or (addon == l111ll1ll_opy_):
            query = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸ࠵࠿ࡶࡴ࡯ࡁࠪࡹࠦ࡮ࡱࡧࡩࡂ࠺ࠦ࡯ࡣࡰࡩࡂࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࠩࡴࡱࡧࡹ࠾ࠨࡧࡥࡹ࡫࠽ࠧࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࡃࠦࡱࡣࡪࡩࡂ࠭ঽ") % (addon, l11ll111l_opy_)
        response = sendJSON(query, addon)
        l11l1l1_opy_.extend(response)
    return l11l1l1_opy_
def sendJSON(query, addon):
    l11l1ll1l_opy_     = l1l1l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬা") % query
    l11l11ll1_opy_  = xbmc.executeJSONRPC(l11l1ll1l_opy_)
    response = json.loads(l11l11ll1_opy_)
    result   = response[l1l1l_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪি")]
    if xbmcgui.Window(10000).getProperty(l1l1l_opy_ (u"ࠫࡕࡒࡕࡈࡋࡑࡣࡌࡋࡎࡓࡇࠪী")) == l1l1l_opy_ (u"࡚ࠬࡲࡶࡧࠪু"):
        xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"࠭ࡧࡦࡰࡵࡩࠬূ"), l1l1l_opy_ (u"ࠧࡵࡴࡸࡩࠬৃ"))
    if xbmcgui.Window(10000).getProperty(l1l1l_opy_ (u"ࠨࡒࡏ࡙ࡌࡏࡎࡠࡖ࡙ࡋ࡚ࡏࡄࡆࠩৄ")) == l1l1l_opy_ (u"ࠩࡗࡶࡺ࡫ࠧ৅"):
        xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"ࠪࡸࡻ࡭ࡵࡪࡦࡨࠫ৆"), l1l1l_opy_ (u"ࠫࡹࡸࡵࡦࠩে"))
    return result[l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫৈ")]
def l11ll11l1_opy_(addon):
    if (addon == l11l11l1l_opy_) or (addon == l11l11111_opy_):
        return l1l1l_opy_ (u"࠭࠯ࡀࡥࡤࡸࡂ࠳࠲ࠧࡦࡤࡸࡪࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠪࡪࡴࡤࡅࡣࡷࡩࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡰࡳࡩ࡫࠽࠳ࠨࡱࡥࡲ࡫࠽ࡎࡻࠨ࠶࠵ࡉࡨࡢࡰࡱࡩࡱࡹࠦࡳࡧࡦࡳࡷࡪ࡮ࡢ࡯ࡨࠪࡸࡺࡡࡳࡶࡇࡥࡹ࡫ࠦࡶࡴ࡯ࡁࡺࡸ࡬ࠨ৉")
    return l1l1l_opy_ (u"ࠧࠨ৊")
def l1ll111l_opy_():
    modules = map(__import__, [l1l11l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l1l1l_opy_ (u"ࠨࡖࡵࡹࡪ࠭ো")
    if len(modules[-1].Window(10**4).getProperty(l11lll_opy_)):
        return l1l1l_opy_ (u"ࠩࡗࡶࡺ࡫ࠧৌ")
    return l1l1l_opy_ (u"ࠪࡊࡦࡲࡳࡦ্ࠩ")
def l1l111ll_opy_(e, addon):
    l1ll11l1_opy_ = l1l1l_opy_ (u"ࠫࡘࡵࡲࡳࡻ࠯ࠤࡦࡴࠠࡦࡴࡵࡳࡷࠦ࡯ࡤࡥࡸࡶࡪࡪ࠺ࠡࡌࡖࡓࡓࠦࡅࡳࡴࡲࡶ࠿ࠦࠥࡴ࠮ࠣࠩࡸ࠭ৎ")  % (e, addon)
    l1_opy_ = l1l1l_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡩ࡯࡯ࡶࡤࡧࡹࠦࡵࡴࠢࡲࡲࠥࡺࡨࡦࠢࡩࡳࡷࡻ࡭࠯ࠩ৏")
    l1ll1l11_opy_ = l1l1l_opy_ (u"࠭ࡕࡱ࡮ࡲࡥࡩࠦࡡࠡ࡮ࡲ࡫ࠥࡼࡩࡢࠢࡷ࡬ࡪࠦࡡࡥࡦࡲࡲࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹࠠࡢࡰࡧࠤࡵࡵࡳࡵࠢࡷ࡬ࡪࠦ࡬ࡪࡰ࡮࠲ࠬ৐")
    dixie.log(addon)
    dixie.log(e)
def getPluginInfo(streamurl, kodiID=False):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l111ll1l1_opy_   = l1l1l_opy_ (u"ࠧࡌࡱࡧ࡭ࠥࡖࡖࡓࠩ৑")
            l111lll1l_opy_ = os.path.join(dixie.RESOURCES, l1l1l_opy_ (u"ࠨ࡭ࡲࡨ࡮࠳ࡰࡷࡴ࠱ࡴࡳ࡭ࠧ৒"))
            return l111ll1l1_opy_, l111lll1l_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l1l1l_opy_ (u"ࠩࡵࡸࡲࡶࠧ৓")) or url.startswith(l1l1l_opy_ (u"ࠪࡶࡹࡳࡰࡦࠩ৔")) or url.startswith(l1l1l_opy_ (u"ࠫࡷࡺࡳࡱࠩ৕")) or url.startswith(l1l1l_opy_ (u"ࠬ࡮ࡴࡵࡲࠪ৖")):
            l111ll1l1_opy_   = l1l1l_opy_ (u"࠭࡭࠴ࡷࠣࡔࡱࡧࡹ࡭࡫ࡶࡸࠬৗ")
            l111lll1l_opy_ = os.path.join(dixie.RESOURCES, l1l1l_opy_ (u"ࠧࡪࡲࡷࡺ࠲ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡱࡰࡪࠫ৘"))
            return l111ll1l1_opy_, l111lll1l_opy_
    except:
        pass
    if streamurl.startswith(l1l1l_opy_ (u"ࠨࡲࡹࡶ࠿࠵࠯ࠨ৙")):
        l111ll1l1_opy_   = l1l1l_opy_ (u"ࠩࡎࡳࡩ࡯ࠠࡑࡘࡕࠫ৚")
        l111lll1l_opy_ = os.path.join(dixie.RESOURCES, l1l1l_opy_ (u"ࠪ࡯ࡴࡪࡩ࠮ࡲࡹࡶ࠳ࡶ࡮ࡨࠩ৛"))
        return l111ll1l1_opy_, l111lll1l_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        l11l11l11_opy_ = streamurl.split(l1l1l_opy_ (u"ࠫࡢࡕࡔࡕࡡࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬড়"), 1)[-1].split(l1l1l_opy_ (u"ࠬ࠵ࠧঢ়"), 1)[0]
    if l1l1l_opy_ (u"࠭࡝ࡐࡖࡗࡣࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ৞") in streamurl:
        l11l11l11_opy_ = streamurl.split(l1l1l_opy_ (u"ࠧ࡞ࡑࡗࡘࡤࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨয়"), 1)[-1].split(l1l1l_opy_ (u"ࠨ࠱ࠪৠ"), 1)[0]
    if streamurl.startswith(l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬৡ")):
        l11l11l11_opy_ = streamurl.split(l1l1l_opy_ (u"ࠪ࠳࠴࠭ৢ"), 1)[-1].split(l1l1l_opy_ (u"ࠫ࠴࠭ৣ"), 1)[0]
    if l1l1l_opy_ (u"ࠬࡥ࡟ࡔࡈࡢࡣࠬ৤") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡰࡳࡱࡪࡶࡦࡳ࠮ࡴࡷࡳࡩࡷ࠴ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵࠪ৥")
    if l1l1l_opy_ (u"ࠧࡏࡋࡆࡉ࠿࠭০") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡯ࡣࡷ࡬ࡴࡹࡵࡣࡵ࡬ࡧࡪ࠭১")
    if l1l1l_opy_ (u"ࠩࡓࡖࡊࡓ࠺ࠨ২") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡳࡶࡪࡳࡩࡶ࡯࡬ࡴࡹࡼࠧ৩")
    if l1l1l_opy_ (u"ࠫࡌࡏ࡚࠻ࠩ৪") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡬࡯ࡺ࡮ࡱࡷࡺࠬ৫")
    if l1l1l_opy_ (u"࠭ࡇࡆࡊ࠽ࠫ৬") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡧࡦࡪࡲࡷࡹ࡯࡮ࡨࠩ৭")
    if l1l1l_opy_ (u"ࠨࡏࡗ࡜ࡎࡋ࠺ࠨ৮") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡯ࡤࡸࡷ࡯ࡸࡪࡴࡨࡰࡦࡴࡤࠨ৯")
    if l1l1l_opy_ (u"ࠪࡘ࡛ࡑ࠺ࠨৰ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡸࡻࡱࡩ࡯ࡩࡶࠫৱ")
    if l1l1l_opy_ (u"ࠬ࡞ࡔࡄ࠼ࠪ৲") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾࡴࡳࡧࡤࡱ࠲ࡩ࡯ࡥࡧࡶࠫ৳")
    if l1l1l_opy_ (u"ࠧࡔࡅࡗ࡚࠿࠭৴") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡥࡷࡺࠬ৵")
    if l1l1l_opy_ (u"ࠩࡖ࡙ࡕࡀࠧ৶") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡸࡷ࡫ࡡ࡮ࡵࡸࡴࡷ࡫࡭ࡦ࠴ࠪ৷")
    if l1l1l_opy_ (u"࡚ࠫࡑࡔ࠻ࠩ৸") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡶࡴ࡮ࠫ৹")
    if l1l1l_opy_ (u"࠭ࡌࡊࡏࡌࡘ࠿࠭৺") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡌࡪ࡯࡬ࡸࡱ࡫ࡳࡴࡋࡓࡘ࡛࠭৻")
    if l1l1l_opy_ (u"ࠨࡈࡄࡆ࠿࠭ৼ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡨࡤࡦ࡭ࡵࡳࡵ࡫ࡱ࡫ࠬ৽")
    if l1l1l_opy_ (u"ࠪࡅࡈࡋ࠺ࠨ৾") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡨ࡫ࡴࡷࠩ৿")
    if l1l1l_opy_ (u"ࠬࡎࡏࡓࡋ࡝࠾ࠬ਀") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡮࡯ࡳ࡫ࡽࡳࡳ࡯ࡰࡵࡸࠪਁ")
    if l1l1l_opy_ (u"ࠧࡓࡑࡒࡘ࠷ࡀࠧਂ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡱࡲࡸࡎࡖࡔࡗࠩਃ")
    if l1l1l_opy_ (u"ࠩࡐࡉࡌࡇ࠺ࠨ਄") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡰࡩ࡬ࡧࡩࡱࡶࡹࠫਅ")
    if l1l1l_opy_ (u"࡛ࠫࡊࡒࡕࡘ࠽ࠫਆ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡛ࡇࡄࡆࡔࠪਇ")
    if l1l1l_opy_ (u"࠭ࡈࡅࡖ࡙࠾ࠬਈ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳ࡮ࡣࡵࡸ࡭ࡻࡢࠨਉ")
    if l1l1l_opy_ (u"ࠨࡊࡇࡘ࡛࠸࠺ࠨਊ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࠸ࠧ਋")
    if l1l1l_opy_ (u"ࠪࡌࡉ࡚ࡖ࠴࠼ࠪ਌") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡺࡿࡡ࠳ࠩ਍")
    if l1l1l_opy_ (u"ࠬࡎࡄࡕࡘ࠷࠾ࠬ਎") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾ࡬ࠨਏ")
    if l1l1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡀࠧਐ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡣࡤࡦ࡭ࡵࡲࡡࡺࡧࡵࠫ਑")
    if l1l1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙࠳࠼ࠪ਒") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠭ਓ")
    if l1l1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡕ࠾ࠬਔ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶ࡬ࡢࡻࡨࡶࡼࡽࡷࠨਕ")
    if l1l1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡎ࡚ࡖ࠻ࠩਖ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡵࡸࠪਗ")
    if l1l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡄ࠻ࠩਘ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡦࡨࡼࠬਙ")
    if l1l1l_opy_ (u"ࠪࡎࡎࡔࡘ࠳࠼ࠪਚ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡮࡮ࡴࡸࡵࡸ࠵ࠫਛ")
    if l1l1l_opy_ (u"ࠬࡓࡁࡕࡕ࠽ࠫਜ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡓࡡࡵࡵࡅࡹ࡮ࡲࡤࡴࡋࡓࡘ࡛࠭ਝ")
    if l1l1l_opy_ (u"ࠧࡓࡑࡒࡘ࠿࠭ਞ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡱࡲࡸ࡮ࡶࡴࡷࠩਟ")
    if l1l1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡓࡄ࠽ࠫਠ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡩࡧࡵ࡯ࡵࠩਡ")
    if l1l1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡆࡐ࡚ࡀࠧਢ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡨࡲࡵࡪࡲࡷࡺࠬਣ")
    if l1l1l_opy_ (u"࠭ࡉࡑࡖࡖࠫਤ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱࡶࡹࡷࡺࡨࡳࠨਥ")
    if l1l1l_opy_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠻ࠩਦ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮࡬ࡺࡪࡳࡩࡹࠩਧ")
    if l1l1l_opy_ (u"ࠪࡉࡓࡊ࠺ࠨਨ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡉࡳࡪ࡬ࡦࡵࡶࠫ਩")
    if l1l1l_opy_ (u"ࠬࡌࡌࡂ࠼ࠪਪ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡌ࡬ࡢࡹ࡯ࡩࡸࡹࡔࡷࠩਫ")
    if l1l1l_opy_ (u"ࠧࡎࡃ࡛ࡍ࠿࠭ਬ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡮ࡣࡻ࡭ࡼ࡫ࡢࡵࡸࠪਭ")
    if l1l1l_opy_ (u"ࠩࡉࡐࡆ࡙࠺ࠨਮ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡉࡰࡦࡽ࡬ࡦࡵࡶࡘࡻ࠭ਯ")
    if l1l1l_opy_ (u"ࠫࡘࡖࡒࡎ࠼ࠪਰ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡘࡻࡰࡳࡧࡰࡥࡨࡿࡔࡗࠩ਱")
    if l1l1l_opy_ (u"࠭ࡍࡄࡍࡗ࡚࠿࠭ਲ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡭ࡤ࡭ࡷࡺ࠲ࡶ࡬ࡶࡵࠪਲ਼")
    if l1l1l_opy_ (u"ࠨࡖ࡚ࡍࡘ࡚࠺ࠨ਴") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡶࡺ࡭ࡸࡺࡥࡥࠩਵ")
    if l1l1l_opy_ (u"ࠪࡔࡗࡋࡓࡕ࠼ࠪਸ਼") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡴࡸࡧࡤࡥࡱࡱࠫ਷")
    if l1l1l_opy_ (u"ࠬࡈࡌࡌࡋ࠽ࠫਸ") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡈ࡬ࡢࡥ࡮ࡍࡨ࡫ࡔࡗࠩਹ")
    if l1l1l_opy_ (u"ࠧࡇࡔࡈࡉ࠿࠭਺") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡧࡴࡨࡩࡻ࡯ࡥࡸࠩ਻")
    if l1l1l_opy_ (u"ࠩࡸࡴࡳࡶ࠺ࠨ਼") in streamurl:
        l11l11l11_opy_ = l1l1l_opy_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱࡬ࡩ࡮࡯࡮ࡧࡵࡹࡳ࠴ࡶࡪࡧࡺࠫ਽")
    return l11l1l1ll_opy_(l11l11l11_opy_, kodiID)
def l11l1l1ll_opy_(l11l11l11_opy_, kodiID):
    l111ll1l1_opy_     = l1l1l_opy_ (u"ࠫࠬਾ")
    l111lll1l_opy_   = l1l1l_opy_ (u"ࠬ࠭ਿ")
    try:
        l11ll11ll_opy_ = xbmcaddon.Addon(l11l11l11_opy_).getAddonInfo(l1l1l_opy_ (u"࠭࡮ࡢ࡯ࡨࠫੀ"))
        l111ll1l1_opy_    = dixie.cleanLabel(l11ll11ll_opy_)
        l111lll1l_opy_  = xbmcaddon.Addon(l11l11l11_opy_).getAddonInfo(l1l1l_opy_ (u"ࠧࡪࡥࡲࡲࠬੁ"))
        if kodiID:
            l111lll11_opy_ = xbmcaddon.Addon(l11l11l11_opy_).getAddonInfo(l1l1l_opy_ (u"ࠨ࡫ࡧࠫੂ"))
            return l111ll1l1_opy_, l111lll11_opy_
        return l111ll1l1_opy_, l111lll1l_opy_
    except:
        l111ll1l1_opy_   = l1l1l_opy_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠣࡗࡴࡻࡲࡤࡧࠪ੃")
        l111lll1l_opy_ =  dixie.ICON
        return l111ll1l1_opy_, l111lll1l_opy_
    return l111ll1l1_opy_, l111lll1l_opy_
def selectStream(url, channel):
    l111ll11l_opy_ = url.split(l1l1l_opy_ (u"ࠪࢀࠬ੄"))
    if len(l111ll11l_opy_) == 0:
        return None
    options, l1l11l1_opy_ = getOptions(l111ll11l_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l111ll11l_opy_) == 1:
            return l1l11l1_opy_[0]
    import selectDialog
    l11l11lll_opy_ = selectDialog.select(l1l1l_opy_ (u"ࠫࡘ࡫࡬ࡦࡥࡷࠤࡦࠦࡳࡵࡴࡨࡥࡲ࠭੅"), options)
    if l11l11lll_opy_ < 0:
        raise Exception(l1l1l_opy_ (u"࡙ࠬࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡࡅࡤࡲࡨ࡫࡬ࠨ੆"))
    return l1l11l1_opy_[l11l11lll_opy_]
def getOptions(l111ll11l_opy_, channel, addmore=True):
    options = []
    l1l11l1_opy_    = []
    for index, stream in enumerate(l111ll11l_opy_):
        l111ll1l1_opy_ = getPluginInfo(stream)
        l1llll1_opy_ = l1l1l_opy_ (u"࠭ࠧੇ")
        l11l1111l_opy_  = l111ll1l1_opy_[1]
        if stream.startswith(OPEN_OTT):
            l11l1l1l1_opy_ = stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l1l1l_opy_ (u"ࠧࠨੈ"))
            l1llll1_opy_  = l1llll1_opy_ + l11l1l1l1_opy_
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l1l1l_opy_ (u"ࠨࠩ੉"))
        else:
            l1llll1_opy_  = l1llll1_opy_ + channel
        options.append([l1llll1_opy_, index, l11l1111l_opy_])
        l1l11l1_opy_.append(stream)
    if addmore:
        options.append([l1l1l_opy_ (u"ࠩࡄࡨࡩࠦ࡭ࡰࡴࡨ࠲࠳࠴ࠧ੊"), index + 1, dixie.ICON])
        l1l11l1_opy_.append(l1l1l_opy_ (u"ࠪࡥࡩࡪࡍࡰࡴࡨࠫੋ"))
    return options, l1l11l1_opy_
if __name__ == l1l1l_opy_ (u"ࠫࡤࡥ࡭ࡢ࡫ࡱࡣࡤ࠭ੌ"):
    checkAddons()