# coding: UTF-8
import sys
l1l11l1_opy_ = sys.version_info [0] == 2
l1l111l_opy_ = 2048
l1l1ll_opy_ = 7
def l1lll11_opy_ (ll_opy_):
	global l1ll1l_opy_
	l1ll1ll1_opy_ = ord (ll_opy_ [-1])
	l1l1l1l_opy_ = ll_opy_ [:-1]
	l1l1l_opy_ = l1ll1ll1_opy_ % len (l1l1l1l_opy_)
	l1llll1l_opy_ = l1l1l1l_opy_ [:l1l1l_opy_] + l1l1l1l_opy_ [l1l1l_opy_:]
	if l1l11l1_opy_:
		l11l1ll_opy_ = unicode () .join ([unichr (ord (char) - l1l111l_opy_ - (l1lllll_opy_ + l1ll1ll1_opy_) % l1l1ll_opy_) for l1lllll_opy_, char in enumerate (l1llll1l_opy_)])
	else:
		l11l1ll_opy_ = str () .join ([chr (ord (char) - l1l111l_opy_ - (l1lllll_opy_ + l1ll1ll1_opy_) % l1l1ll_opy_) for l1lllll_opy_, char in enumerate (l1llll1l_opy_)])
	return eval (l11l1ll_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l11ll11ll_opy_     = l1lll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡲࡹࡼࠧघ")
l11l1lll1_opy_  = l1lll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡼࡲࡩࡱࡶࡹࠫङ")
l11lllll1_opy_     = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡻ࡫ࡵࡷࡵ࡯ࠬच")
locked  = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡬ࡰࡥ࡮ࡩࡩࡺࡶࠨछ")
l11l1l1l1_opy_      = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡶ࡮ࡷ࡭ࡲࡧࡴࡦ࡯ࡤࡲ࡮ࡧࠧज")
l11l1ll11_opy_    = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮࡬ࡹࡽ࠴ࡴࡷࠩझ")
l11ll1111_opy_     = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡇࡇࡘࡶ࡯ࡳࡶࡶࠫञ")
l11llll1l_opy_  = l1lll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡪࡨ࡯ࡰࡶࠪट")
l11ll111l_opy_     = l1lll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡨࡲࡵࡪࡲࡷࡺࠬठ")
l11llll11_opy_ = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡻ࡫ࡵࡸ࠷ࡩࡽࡶࡡࡵࡵ࠱ࡧࡴࡳࠧड")
l1l1llll_opy_ = [l11ll11ll_opy_, locked, l11l1ll11_opy_, l11l1lll1_opy_, l11llll11_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1lll11_opy_ (u"ࠧࡪࡰ࡬ࠫढ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1lll111_opy_ = l1lll11_opy_ (u"ࠨࠩण")
def l1l1lll1_opy_(i, t1, l1ll1lll_opy_=[]):
 t = l1lll111_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1ll1lll_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11l1_opy_ = l1l1lll1_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l111l_opy_ = l1l1lll1_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1l1llll_opy_:
        if l1ll11l1_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1ll11l1_opy_(addon):
    if xbmc.getCondVisibility(l1lll11_opy_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡋࡥࡸࡇࡤࡥࡱࡱࠬࠪࡹࠩࠨत") % addon) == 1:
        return True
    return False
def createINI(addon):
    l11l111_opy_ = str(addon).split(l1lll11_opy_ (u"ࠪ࠲ࠬथ"))[2] + l1lll11_opy_ (u"ࠫ࠳࡯࡮ࡪࠩद")
    l1l_opy_  = os.path.join(PATH, l11l111_opy_)
    try:
        l1ll1ll_opy_ = l1_opy_(addon)
    except KeyError:
        dixie.log(l1lll11_opy_ (u"ࠬ࠳࠭࠮࠯࠰ࠤࡐ࡫ࡹࡆࡴࡵࡳࡷࠦࡩ࡯ࠢࡪࡩࡹࡌࡩ࡭ࡧࡶࠤ࠲࠳࠭࠮࠯ࠣࠫध") + addon)
        result = {l1lll11_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࡸ࠭न"): [{l1lll11_opy_ (u"ࡵࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪऩ"): l1lll11_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࠧप"), l1lll11_opy_ (u"ࡷࠪࡸࡾࡶࡥࠨफ"): l1lll11_opy_ (u"ࡸࠫࡺࡴ࡫࡯ࡱࡺࡲࠬब"), l1lll11_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࠪभ"): l1lll11_opy_ (u"ࡺ࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡹࡺࡻࠫम"), l1lll11_opy_ (u"ࡻࠧ࡭ࡣࡥࡩࡱ࠭य"): l1lll11_opy_ (u"ࡵࠨࡐࡒࠤࡈࡎࡁࡏࡐࡈࡐࡘ࠭र")}], l1lll11_opy_ (u"ࡶࠩ࡯࡭ࡲ࡯ࡴࡴࠩऱ"):{l1lll11_opy_ (u"ࡷࠪࡷࡹࡧࡲࡵࠩल"): 0, l1lll11_opy_ (u"ࡸࠫࡹࡵࡴࡢ࡮ࠪळ"): 1, l1lll11_opy_ (u"ࡹࠬ࡫࡮ࡥࠩऴ"): 1}}
    l1l1lll_opy_  = l1lll11_opy_ (u"ࠬࡡࠧव") + addon + l1lll11_opy_ (u"࠭࡝࡝ࡰࠪश")
    l1l11_opy_  =  file(l1l_opy_, l1lll11_opy_ (u"ࠧࡸࠩष"))
    l1l11_opy_.write(l1l1lll_opy_)
    l1ll1111_opy_ = []
    for channel in l1ll1ll_opy_:
        l1l111111_opy_ = dixie.cleanLabel(channel[l1lll11_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧस")])
        l1ll11ll_opy_   = dixie.cleanPrefix(l1l111111_opy_)
        l1111l1_opy_ = dixie.mapChannelName(l1ll11ll_opy_)
        stream   = channel[l1lll11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧह")]
        l1111_opy_ = l1111l1_opy_ + l1lll11_opy_ (u"ࠪࡁࠬऺ") + stream
        l1ll1111_opy_.append(l1111_opy_)
        l1ll1111_opy_.sort()
    for item in l1ll1111_opy_:
        l1l11_opy_.write(l1lll11_opy_ (u"ࠦࠪࡹ࡜࡯ࠤऻ") % item)
    l1l11_opy_.close()
def l1_opy_(addon):
    if (addon == l11ll11ll_opy_) or (addon == l11l1lll1_opy_):
        if xbmcaddon.Addon(addon).getSetting(l1lll11_opy_ (u"ࠬ࡭ࡥ࡯ࡴࡨ़ࠫ")) == l1lll11_opy_ (u"࠭ࡴࡳࡷࡨࠫऽ"):
            xbmcaddon.Addon(addon).setSetting(l1lll11_opy_ (u"ࠧࡨࡧࡱࡶࡪ࠭ा"), l1lll11_opy_ (u"ࠨࡨࡤࡰࡸ࡫ࠧि"))
            xbmcgui.Window(10000).setProperty(l1lll11_opy_ (u"ࠩࡓࡐ࡚ࡍࡉࡏࡡࡊࡉࡓࡘࡅࠨी"), l1lll11_opy_ (u"ࠪࡘࡷࡻࡥࠨु"))
        if xbmcaddon.Addon(addon).getSetting(l1lll11_opy_ (u"ࠫࡹࡼࡧࡶ࡫ࡧࡩࠬू")) == l1lll11_opy_ (u"ࠬࡺࡲࡶࡧࠪृ"):
            xbmcaddon.Addon(addon).setSetting(l1lll11_opy_ (u"࠭ࡴࡷࡩࡸ࡭ࡩ࡫ࠧॄ"), l1lll11_opy_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭ॅ"))
            xbmcgui.Window(10000).setProperty(l1lll11_opy_ (u"ࠨࡒࡏ࡙ࡌࡏࡎࡠࡖ࡙ࡋ࡚ࡏࡄࡆࠩॆ"), l1lll11_opy_ (u"ࠩࡗࡶࡺ࡫ࠧे"))
        l11l1ll1l_opy_  = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭ै") + addon
        l11lll1l1_opy_ =  l1l11111l_opy_(addon)
        query   =  l11l1ll1l_opy_ + l11lll1l1_opy_
        return sendJSON(query, addon)
    return l11ll1ll1_opy_(addon)
def l11ll1ll1_opy_(addon):
    if addon == l11llll11_opy_:
        l11ll1lll_opy_ = [l1lll11_opy_ (u"ࠫ࠶࠼࠱ࠨॉ"), l1lll11_opy_ (u"ࠬ࠷࠶࠱ࠩॊ"), l1lll11_opy_ (u"࠭࠲࠴࠸ࠪो"), l1lll11_opy_ (u"ࠧ࠳࠶࠵ࠫौ"), l1lll11_opy_ (u"ࠨ࠳࠸࠼्ࠬ"), l1lll11_opy_ (u"ࠩ࠴࠹࠾࠭ॎ")]
    if addon == l11l1ll11_opy_:
        l11ll1lll_opy_ = [l1lll11_opy_ (u"ࠪ࠹ࠬॏ"), l1lll11_opy_ (u"ࠫ࠶࠶࠶ࠨॐ"), l1lll11_opy_ (u"ࠬ࠺ࠧ॑"), l1lll11_opy_ (u"࠭࠲࠷࠵॒ࠪ"), l1lll11_opy_ (u"ࠧ࠲࠵࠵ࠫ॓")]
    if addon == locked:
        l11ll1lll_opy_ = [l1lll11_opy_ (u"ࠨ࠵࠳ࠫ॔"), l1lll11_opy_ (u"ࠩ࠶࠵ࠬॕ"), l1lll11_opy_ (u"ࠪ࠷࠷࠭ॖ"), l1lll11_opy_ (u"ࠫ࠸࠹ࠧॗ"), l1lll11_opy_ (u"ࠬ࠹࠴ࠨक़"), l1lll11_opy_ (u"࠭࠳࠶ࠩख़"), l1lll11_opy_ (u"ࠧ࠴࠺ࠪग़"), l1lll11_opy_ (u"ࠨ࠶࠳ࠫज़"), l1lll11_opy_ (u"ࠩ࠷࠵ࠬड़"), l1lll11_opy_ (u"ࠪ࠸࠺࠭ढ़"), l1lll11_opy_ (u"ࠫ࠹࠽ࠧफ़"), l1lll11_opy_ (u"ࠬ࠺࠹ࠨय़"), l1lll11_opy_ (u"࠭࠵࠳ࠩॠ")]
    if addon == l11l1l1l1_opy_:
        l11ll1lll_opy_ = [l1lll11_opy_ (u"ࠧ࠳࠷ࠪॡ"), l1lll11_opy_ (u"ࠨ࠴࠹ࠫॢ"), l1lll11_opy_ (u"ࠩ࠵࠻ࠬॣ"), l1lll11_opy_ (u"ࠪ࠶࠾࠭।"), l1lll11_opy_ (u"ࠫ࠸࠶ࠧ॥"), l1lll11_opy_ (u"ࠬ࠹࠱ࠨ०"), l1lll11_opy_ (u"࠭࠳࠳ࠩ१"), l1lll11_opy_ (u"ࠧ࠴࠷ࠪ२"), l1lll11_opy_ (u"ࠨ࠵࠹ࠫ३"), l1lll11_opy_ (u"ࠩ࠶࠻ࠬ४"), l1lll11_opy_ (u"ࠪ࠷࠽࠭५"), l1lll11_opy_ (u"ࠫ࠸࠿ࠧ६"), l1lll11_opy_ (u"ࠬ࠺࠰ࠨ७"), l1lll11_opy_ (u"࠭࠴࠲ࠩ८"), l1lll11_opy_ (u"ࠧ࠵࠺ࠪ९"), l1lll11_opy_ (u"ࠨ࠶࠼ࠫ॰"), l1lll11_opy_ (u"ࠩ࠸࠴ࠬॱ"), l1lll11_opy_ (u"ࠪ࠹࠷࠭ॲ"), l1lll11_opy_ (u"ࠫ࠺࠺ࠧॳ"), l1lll11_opy_ (u"ࠬ࠻࠶ࠨॴ"), l1lll11_opy_ (u"࠭࠵࠸ࠩॵ"), l1lll11_opy_ (u"ࠧ࠶࠺ࠪॶ"), l1lll11_opy_ (u"ࠨ࠷࠼ࠫॷ"), l1lll11_opy_ (u"ࠩ࠹࠴ࠬॸ"), l1lll11_opy_ (u"ࠪ࠺࠶࠭ॹ"), l1lll11_opy_ (u"ࠫ࠻࠸ࠧॺ"), l1lll11_opy_ (u"ࠬ࠼࠳ࠨॻ"), l1lll11_opy_ (u"࠭࠶࠶ࠩॼ"), l1lll11_opy_ (u"ࠧ࠷࠸ࠪॽ"), l1lll11_opy_ (u"ࠨ࠸࠺ࠫॾ"), l1lll11_opy_ (u"ࠩ࠹࠽ࠬॿ"), l1lll11_opy_ (u"ࠪ࠻࠵࠭ঀ"), l1lll11_opy_ (u"ࠫ࠼࠺ࠧঁ"), l1lll11_opy_ (u"ࠬ࠽࠷ࠨং"), l1lll11_opy_ (u"࠭࠷࠹ࠩঃ"), l1lll11_opy_ (u"ࠧ࠹࠲ࠪ঄"), l1lll11_opy_ (u"ࠨ࠺࠴ࠫঅ")]
    login = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠪࡹ࠯ࠨআ") % addon
    sendJSON(login, addon)
    l1ll11_opy_ = []
    for l11llllll_opy_ in l11ll1lll_opy_:
        if (addon == l11llll11_opy_) or (addon == l11l1ll11_opy_):
            query = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳ࠰ࡁࡰࡳࡩ࡫࡟ࡪࡦࡀࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡳ࡯ࡥࡧࡀࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡹࡥࡤࡶ࡬ࡳࡳࡥࡩࡥ࠿ࠨࡷࠬই") % (addon, l11llllll_opy_)
        if (addon == locked) or (addon == l11l1l1l1_opy_):
            query = l1lll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴ࠱ࡂࡹࡷࡲ࠽ࠦࡵࠩࡱࡴࡪࡥ࠾࠶ࠩࡲࡦࡳࡥ࠾ࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࠬࡰ࡭ࡣࡼࡁࠫࡪࡡࡵࡧࡀࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠩࡴࡦ࡭ࡥ࠾ࠩঈ") % (addon, l11llllll_opy_)
        response = sendJSON(query, addon)
        l1ll11_opy_.extend(response)
    return l1ll11_opy_
def sendJSON(query, addon):
    l11lll1ll_opy_     = l1lll11_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࠦࡵࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨউ") % query
    l11ll1l11_opy_  = xbmc.executeJSONRPC(l11lll1ll_opy_)
    response = json.loads(l11ll1l11_opy_)
    result   = response[l1lll11_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ঊ")]
    if xbmcgui.Window(10000).getProperty(l1lll11_opy_ (u"ࠧࡑࡎࡘࡋࡎࡔ࡟ࡈࡇࡑࡖࡊ࠭ঋ")) == l1lll11_opy_ (u"ࠨࡖࡵࡹࡪ࠭ঌ"):
        xbmcaddon.Addon(addon).setSetting(l1lll11_opy_ (u"ࠩࡪࡩࡳࡸࡥࠨ঍"), l1lll11_opy_ (u"ࠪࡸࡷࡻࡥࠨ঎"))
    if xbmcgui.Window(10000).getProperty(l1lll11_opy_ (u"ࠫࡕࡒࡕࡈࡋࡑࡣ࡙࡜ࡇࡖࡋࡇࡉࠬএ")) == l1lll11_opy_ (u"࡚ࠬࡲࡶࡧࠪঐ"):
        xbmcaddon.Addon(addon).setSetting(l1lll11_opy_ (u"࠭ࡴࡷࡩࡸ࡭ࡩ࡫ࠧ঑"), l1lll11_opy_ (u"ࠧࡵࡴࡸࡩࠬ঒"))
    return result[l1lll11_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧও")]
def l1l11111l_opy_(addon):
    if (addon == l11ll11ll_opy_) or (addon == l11l1lll1_opy_):
        return l1lll11_opy_ (u"ࠩ࠲ࡃࡨࡧࡴ࠾࠯࠵ࠪࡩࡧࡴࡦࠨࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠦࡦࡰࡧࡈࡦࡺࡥࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡳ࡯ࡥࡧࡀ࠶ࠫࡴࡡ࡮ࡧࡀࡑࡾࠫ࠲࠱ࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠩࡶࡪࡩ࡯ࡳࡦࡱࡥࡲ࡫ࠦࡴࡶࡤࡶࡹࡊࡡࡵࡧࠩࡹࡷࡲ࠽ࡶࡴ࡯ࠫঔ")
    return l1lll11_opy_ (u"ࠪࠫক")
def l1lll1_opy_():
    modules = map(__import__, [l1l1lll1_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11l1_opy_)):
        return l1lll11_opy_ (u"࡙ࠫࡸࡵࡦࠩখ")
    if len(modules[-1].Window(10**4).getProperty(l111l_opy_)):
        return l1lll11_opy_ (u"࡚ࠬࡲࡶࡧࠪগ")
    return l1lll11_opy_ (u"࠭ࡆࡢ࡮ࡶࡩࠬঘ")
def l1llllll_opy_(e, addon):
    l1111l_opy_ = l1lll11_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠲ࠠࡢࡰࠣࡩࡷࡸ࡯ࡳࠢࡲࡧࡨࡻࡲࡦࡦ࠽ࠤࡏ࡙ࡏࡏࠢࡈࡶࡷࡵࡲ࠻ࠢࠨࡷ࠱ࠦࠥࡴࠩঙ")  % (e, addon)
    l1llll_opy_ = l1lll11_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡥࡲࡲࡹࡧࡣࡵࠢࡸࡷࠥࡵ࡮ࠡࡶ࡫ࡩࠥ࡬࡯ࡳࡷࡰ࠲ࠬচ")
    l1l1_opy_ = l1lll11_opy_ (u"ࠩࡘࡴࡱࡵࡡࡥࠢࡤࠤࡱࡵࡧࠡࡸ࡬ࡥࠥࡺࡨࡦࠢࡤࡨࡩࡵ࡮ࠡࡵࡨࡸࡹ࡯࡮ࡨࡵࠣࡥࡳࡪࠠࡱࡱࡶࡸࠥࡺࡨࡦࠢ࡯࡭ࡳࡱ࠮ࠨছ")
    dixie.log(addon)
    dixie.log(e)
def getPluginInfo(streamurl):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l11l1l11l_opy_   = l1lll11_opy_ (u"ࠪࡏࡴࡪࡩࠡࡒ࡙ࡖࠬজ")
            l11l1l1ll_opy_ = os.path.join(dixie.RESOURCES, l1lll11_opy_ (u"ࠫࡰࡵࡤࡪ࠯ࡳࡺࡷ࠴ࡰ࡯ࡩࠪঝ"))
            return l11l1l11l_opy_, l11l1l1ll_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l1lll11_opy_ (u"ࠬࡸࡴ࡮ࡲࠪঞ")) or url.startswith(l1lll11_opy_ (u"࠭ࡲࡵ࡯ࡳࡩࠬট")) or url.startswith(l1lll11_opy_ (u"ࠧࡳࡶࡶࡴࠬঠ")) or url.startswith(l1lll11_opy_ (u"ࠨࡪࡷࡸࡵ࠭ড")):
            l11l1l11l_opy_   = l1lll11_opy_ (u"ࠩࡰ࠷ࡺࠦࡐ࡭ࡣࡼࡰ࡮ࡹࡴࠨঢ")
            l11l1l1ll_opy_ = os.path.join(dixie.RESOURCES, l1lll11_opy_ (u"ࠪ࡭ࡵࡺࡶ࠮ࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡴࡳ࡭ࠧণ"))
            return l11l1l11l_opy_, l11l1l1ll_opy_
    except:
        pass
    if streamurl.startswith(l1lll11_opy_ (u"ࠫࡵࡼࡲ࠻࠱࠲ࠫত")):
        l11l1l11l_opy_   = l1lll11_opy_ (u"ࠬࡑ࡯ࡥ࡫ࠣࡔ࡛ࡘࠧথ")
        l11l1l1ll_opy_ = os.path.join(dixie.RESOURCES, l1lll11_opy_ (u"࠭࡫ࡰࡦ࡬࠱ࡵࡼࡲ࠯ࡲࡱ࡫ࠬদ"))
        return l11l1l11l_opy_, l11l1l1ll_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        l11ll11l1_opy_ = streamurl.split(l1lll11_opy_ (u"ࠧ࡞ࡑࡗࡘࡤࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨধ"), 1)[-1].split(l1lll11_opy_ (u"ࠨ࠱ࠪন"), 1)[0]
    if l1lll11_opy_ (u"ࠩࡠࡓ࡙࡚࡟ࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ঩") in streamurl:
        l11ll11l1_opy_ = streamurl.split(l1lll11_opy_ (u"ࠪࡡࡔ࡚ࡔࡠࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫপ"), 1)[-1].split(l1lll11_opy_ (u"ࠫ࠴࠭ফ"), 1)[0]
    if streamurl.startswith(l1lll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨব")):
        l11ll11l1_opy_ = streamurl.split(l1lll11_opy_ (u"࠭࠯࠰ࠩভ"), 1)[-1].split(l1lll11_opy_ (u"ࠧ࠰ࠩম"), 1)[0]
    if l1lll11_opy_ (u"ࠨࡡࡢࡗࡋࡥ࡟ࠨয") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡳࡶࡴ࡭ࡲࡢ࡯࠱ࡷࡺࡶࡥࡳ࠰ࡩࡥࡻࡵࡵࡳ࡫ࡷࡩࡸ࠭র")
    if l1lll11_opy_ (u"ࠪࡅࡈࡋ࠺ࠨ঱") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡨ࡫ࡴࡷࠩল")
    if l1lll11_opy_ (u"ࠬࡎࡏࡓࡋ࡝࠾ࠬ঳") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡮࡯ࡳ࡫ࡽࡳࡳ࡯ࡰࡵࡸࠪ঴")
    if l1lll11_opy_ (u"ࠧࡓࡑࡒࡘ࠷ࡀࠧ঵") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡱࡲࡸࡎࡖࡔࡗࠩশ")
    if l1lll11_opy_ (u"ࠩࡐࡉࡌࡇ࠺ࠨষ") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡰࡩ࡬ࡧࡩࡱࡶࡹࠫস")
    if l1lll11_opy_ (u"࡛ࠫࡊࡒࡕࡘ࠽ࠫহ") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡛ࡇࡄࡆࡔࠪ঺")
    if l1lll11_opy_ (u"࠭ࡈࡅࡖ࡙࠾ࠬ঻") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳ࡮ࡣࡵࡸ࡭ࡻࡢࠨ়")
    if l1lll11_opy_ (u"ࠨࡊࡇࡘ࡛࠸࠺ࠨঽ") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࠸ࠧা")
    if l1lll11_opy_ (u"ࠪࡌࡉ࡚ࡖ࠴࠼ࠪি") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡺࡿࡡ࠳ࠩী")
    if l1lll11_opy_ (u"ࠬࡎࡄࡕࡘ࠷࠾ࠬু") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾ࡬ࠨূ")
    if l1lll11_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡀࠧৃ") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡣࡤࡦ࡭ࡵࡲࡡࡺࡧࡵࠫৄ")
    if l1lll11_opy_ (u"ࠩࡌࡔࡑࡇ࡙࠳࠼ࠪ৅") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠭৆")
    if l1lll11_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡕ࠾ࠬে") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶ࡬ࡢࡻࡨࡶࡼࡽࡷࠨৈ")
    if l1lll11_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡎ࡚ࡖ࠻ࠩ৉") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡵࡸࠪ৊")
    if l1lll11_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡄ࠻ࠩো") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡦࡨࡼࠬৌ")
    if l1lll11_opy_ (u"ࠪࡎࡎࡔࡘ࠳࠼্ࠪ") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡮࡮ࡴࡸࡵࡸ࠵ࠫৎ")
    if l1lll11_opy_ (u"ࠬࡓࡁࡕࡕ࠽ࠫ৏") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡓࡡࡵࡵࡅࡹ࡮ࡲࡤࡴࡋࡓࡘ࡛࠭৐")
    if l1lll11_opy_ (u"ࠧࡓࡑࡒࡘ࠿࠭৑") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡱࡲࡸ࡮ࡶࡴࡷࠩ৒")
    if l1lll11_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡓࡄ࠽ࠫ৓") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡩࡧࡵ࡯ࡵࠩ৔")
    if l1lll11_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡆࡐ࡚ࡀࠧ৕") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡨࡲࡵࡪࡲࡷࡺࠬ৖")
    if l1lll11_opy_ (u"࠭ࡉࡑࡖࡖࠫৗ") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱࡶࡹࡷࡺࡨࡳࠨ৘")
    if l1lll11_opy_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠻ࠩ৙") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮࡬ࡺࡪࡳࡩࡹࠩ৚")
    if l1lll11_opy_ (u"ࠪࡉࡓࡊ࠺ࠨ৛") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡉࡳࡪ࡬ࡦࡵࡶࠫড়")
    if l1lll11_opy_ (u"ࠬࡌࡌࡂ࠼ࠪঢ়") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡌ࡬ࡢࡹ࡯ࡩࡸࡹࡔࡷࠩ৞")
    if l1lll11_opy_ (u"ࠧࡎࡃ࡛ࡍ࠿࠭য়") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡮ࡣࡻ࡭ࡼ࡫ࡢࡵࡸࠪৠ")
    if l1lll11_opy_ (u"ࠩࡉࡐࡆ࡙࠺ࠨৡ") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡉࡰࡦࡽ࡬ࡦࡵࡶࡘࡻ࠭ৢ")
    if l1lll11_opy_ (u"ࠫࡘࡖࡒࡎ࠼ࠪৣ") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡘࡻࡰࡳࡧࡰࡥࡨࡿࡔࡗࠩ৤")
    if l1lll11_opy_ (u"࠭ࡍࡄࡍࡗ࡚࠿࠭৥") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡭ࡤ࡭ࡷࡺ࠲ࡶ࡬ࡶࡵࠪ০")
    if l1lll11_opy_ (u"ࠨࡖ࡚ࡍࡘ࡚࠺ࠨ১") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡶࡺ࡭ࡸࡺࡥࡥࠩ২")
    if l1lll11_opy_ (u"ࠪࡔࡗࡋࡓࡕ࠼ࠪ৩") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡴࡸࡧࡤࡥࡱࡱࠫ৪")
    if l1lll11_opy_ (u"ࠬࡈࡌࡌࡋ࠽ࠫ৫") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡈ࡬ࡢࡥ࡮ࡍࡨ࡫ࡔࡗࠩ৬")
    if l1lll11_opy_ (u"ࠧࡇࡔࡈࡉ࠿࠭৭") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡧࡴࡨࡩࡻ࡯ࡥࡸࠩ৮")
    if l1lll11_opy_ (u"ࠩࡸࡴࡳࡶ࠺ࠨ৯") in streamurl:
        l11ll11l1_opy_ = l1lll11_opy_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱࡬ࡩ࡮࡯࡮ࡧࡵࡹࡳ࠴ࡶࡪࡧࡺࠫৰ")
    return l11lll11l_opy_(l11ll11l1_opy_)
def l11lll11l_opy_(l11ll11l1_opy_):
    l11l1l11l_opy_   = l1lll11_opy_ (u"ࠫࠬৱ")
    l11l1l1ll_opy_ = l1lll11_opy_ (u"ࠬ࠭৲")
    try:
        l1l1111l1_opy_ = xbmcaddon.Addon(l11ll11l1_opy_).getAddonInfo(l1lll11_opy_ (u"࠭࡮ࡢ࡯ࡨࠫ৳"))
        l11l1l11l_opy_    = dixie.cleanLabel(l1l1111l1_opy_)
        l11l1l1ll_opy_  = xbmcaddon.Addon(l11ll11l1_opy_).getAddonInfo(l1lll11_opy_ (u"ࠧࡪࡥࡲࡲࠬ৴"))
        return l11l1l11l_opy_, l11l1l1ll_opy_
    except:
        l11l1l11l_opy_   = l1lll11_opy_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡖࡳࡺࡸࡣࡦࠩ৵")
        l11l1l1ll_opy_ =  dixie.ICON
        return l11l1l11l_opy_, l11l1l1ll_opy_
    return l11l1l11l_opy_, l11l1l1ll_opy_
def selectStream(url, channel):
    l11l1l111_opy_ = url.split(l1lll11_opy_ (u"ࠩࡿࠫ৶"))
    if len(l11l1l111_opy_) == 0:
        return None
    options, l111l11_opy_ = getOptions(l11l1l111_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l11l1l111_opy_) == 1:
            return l111l11_opy_[0]
    import selectDialog
    l11ll1l1l_opy_ = selectDialog.select(l1lll11_opy_ (u"ࠪࡗࡪࡲࡥࡤࡶࠣࡥࠥࡹࡴࡳࡧࡤࡱࠬ৷"), options)
    if l11ll1l1l_opy_ < 0:
        raise Exception(l1lll11_opy_ (u"ࠫࡘ࡫࡬ࡦࡥࡷ࡭ࡴࡴࠠࡄࡣࡱࡧࡪࡲࠧ৸"))
    return l111l11_opy_[l11ll1l1l_opy_]
def getOptions(l11l1l111_opy_, channel, addmore=True):
    options = []
    l111l11_opy_    = []
    for index, stream in enumerate(l11l1l111_opy_):
        l11l1l11l_opy_ = getPluginInfo(stream)
        l11111_opy_ = l11l1l11l_opy_[0]
        l11l1llll_opy_  = l11l1l11l_opy_[1]
        l11111_opy_ = l1lll11_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡵࡲࡢࡰࡪࡩࡢࡡࠧ৹") + l11111_opy_ + l1lll11_opy_ (u"࠭࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࠪ৺")
        if stream.startswith(OPEN_OTT):
            l11lll111_opy_ = stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l1lll11_opy_ (u"ࠧࠨ৻"))
            l11111_opy_  = l11111_opy_ + l11lll111_opy_
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l1lll11_opy_ (u"ࠨࠩৼ"))
        else:
            l11111_opy_  = l11111_opy_ + channel
        options.append([l11111_opy_, index, l11l1llll_opy_])
        l111l11_opy_.append(stream)
    if addmore:
        options.append([l1lll11_opy_ (u"ࠩࡄࡨࡩࠦ࡭ࡰࡴࡨ࠲࠳࠴ࠧ৽"), index + 1, dixie.ICON])
        l111l11_opy_.append(l1lll11_opy_ (u"ࠪࡥࡩࡪࡍࡰࡴࡨࠫ৾"))
    return options, l111l11_opy_
if __name__ == l1lll11_opy_ (u"ࠫࡤࡥ࡭ࡢ࡫ࡱࡣࡤ࠭৿"):
    checkAddons()