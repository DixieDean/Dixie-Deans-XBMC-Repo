# coding: UTF-8
import sys
l1l11ll_opy_ = sys.version_info [0] == 2
l1l11l1_opy_ = 2048
l1l1ll_opy_ = 7
def l1lll11_opy_ (ll_opy_):
	global l1lll1_opy_
	l1lll1l1_opy_ = ord (ll_opy_ [-1])
	l1l1ll1_opy_ = ll_opy_ [:-1]
	l111ll1_opy_ = l1lll1l1_opy_ % len (l1l1ll1_opy_)
	l11111l_opy_ = l1l1ll1_opy_ [:l111ll1_opy_] + l1l1ll1_opy_ [l111ll1_opy_:]
	if l1l11ll_opy_:
		l11lll1_opy_ = unicode () .join ([unichr (ord (char) - l1l11l1_opy_ - (l1lllll_opy_ + l1lll1l1_opy_) % l1l1ll_opy_) for l1lllll_opy_, char in enumerate (l11111l_opy_)])
	else:
		l11lll1_opy_ = str () .join ([chr (ord (char) - l1l11l1_opy_ - (l1lllll_opy_ + l1lll1l1_opy_) % l1l1ll_opy_) for l1lllll_opy_, char in enumerate (l11111l_opy_)])
	return eval (l11lll1_opy_)
import xbmc
import xbmcaddon
import json
import os
import dixie
l1ll11l_opy_ = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸ࡯ࡰࡶ࡬ࡴࡹࡼࠧࣾ")
l11llll1l_opy_   = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡘࡵࡴࡨࡥࡲࡏࡐࡕࡘࠪࣿ")
l11ll1lll_opy_  = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡹࡶࡵࡩࡦࡳ࠭ࡤࡱࡧࡩࡸ࠭ऀ")
l1l111111_opy_   = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡐࡨࡱࡿࢀࡹࡊࡒࡗ࡚ࠬँ")
l11llll11_opy_     = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡲࡸࡹࡧ࡬ࡱࡪࡤࠫं")
l1ll11ll_opy_ = [l11llll1l_opy_, l11ll1lll_opy_, l1l111111_opy_, l11llll11_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1lll11_opy_ (u"ࠫ࡮ࡴࡩࠨः"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1llll1l_opy_ = l1lll11_opy_ (u"ࠬ࠭ऄ")
def l1ll111l_opy_(i, t1, l1llll11_opy_=[]):
 t = l1llll1l_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1llll11_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11ll_opy_ = l1ll111l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11l1_opy_ = l1ll111l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1ll11ll_opy_:
        if l1ll1ll1_opy_(addon):
            createINI(addon)
def l1ll1ll1_opy_(addon):
    if xbmc.getCondVisibility(l1lll11_opy_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡈࡢࡵࡄࡨࡩࡵ࡮ࠩࠧࡶ࠭ࠬअ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l11l1ll_opy_ = str(addon).rsplit(l1lll11_opy_ (u"ࠧ࠯ࠩआ"), 1)[1] + l1lll11_opy_ (u"ࠨ࠰࡬ࡲ࡮࠭इ")
    l1l_opy_  = os.path.join(PATH, l11l1ll_opy_)
    try:
        l1ll1ll_opy_ = l11ll1l11_opy_(addon)
    except KeyError:
        dixie.log(l1lll11_opy_ (u"ࠩ࠰࠱࠲࠳࠭ࠡࡍࡨࡽࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡧࡦࡶࡉ࡭ࡱ࡫ࡳࠡ࠯࠰࠱࠲࠳ࠠࠨई") + addon)
        result = {l1lll11_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࡵࠪउ"): [{l1lll11_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧऊ"): l1lll11_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࠫऋ"), l1lll11_opy_ (u"ࡻࠧࡵࡻࡳࡩࠬऌ"): l1lll11_opy_ (u"ࡵࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩऍ"), l1lll11_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࠧऎ"): l1lll11_opy_ (u"ࡷࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡾࡸࠨए"), l1lll11_opy_ (u"ࡸࠫࡱࡧࡢࡦ࡮ࠪऐ"): l1lll11_opy_ (u"ࡹࠬࡔࡏࠡࡅࡋࡅࡓࡔࡅࡍࡕࠪऑ")}], l1lll11_opy_ (u"ࡺ࠭࡬ࡪ࡯࡬ࡸࡸ࠭ऒ"):{l1lll11_opy_ (u"ࡻࠧࡴࡶࡤࡶࡹ࠭ओ"): 0, l1lll11_opy_ (u"ࡵࠨࡶࡲࡸࡦࡲࠧऔ"): 1, l1lll11_opy_ (u"ࡶࠩࡨࡲࡩ࠭क"): 1}}
    l1ll111_opy_  = l1lll11_opy_ (u"ࠩ࡞ࠫख") + addon + l1lll11_opy_ (u"ࠪࡡࡡࡴࠧग")
    l1l1l_opy_  = file(l1l_opy_, l1lll11_opy_ (u"ࠫࡼ࠭घ"))
    l1l1l_opy_.write(l1ll111_opy_)
    l1ll1l11_opy_ = []
    try:
        for channel in l1ll1ll_opy_:
            l1ll1lll_opy_ = l1ll_opy_(addon, channel)
            l1ll1_opy_ = dixie.mapChannelName(l1ll1lll_opy_)
            stream   = channel[l1lll11_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪङ")]
            l111l_opy_ = l1ll1_opy_ + l1lll11_opy_ (u"࠭࠽ࠨच") + stream
            l1ll1l11_opy_.append(l111l_opy_)
            l1ll1l11_opy_.sort()
        for item in l1ll1l11_opy_:
            l1l1l_opy_.write(l1lll11_opy_ (u"ࠢࠦࡵ࡟ࡲࠧछ") % item)
        l1l1l_opy_.close()
    except Exception as e:
        l1111ll_opy_(e, addon)
        return {l1lll11_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࡳࠨज"): [{l1lll11_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬझ"): l1lll11_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࠩञ"), l1lll11_opy_ (u"ࡹࠬࡺࡹࡱࡧࠪट"): l1lll11_opy_ (u"ࡺ࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧठ"), l1lll11_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࠬड"): l1lll11_opy_ (u"ࡵࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡼࡽ࠭ढ"), l1lll11_opy_ (u"ࡶࠩ࡯ࡥࡧ࡫࡬ࠨण"): l1lll11_opy_ (u"ࡷࠪࡒࡔࠦࡃࡉࡃࡑࡒࡊࡒࡓࠨत")}], l1lll11_opy_ (u"ࡸࠫࡱ࡯࡭ࡪࡶࡶࠫथ"):{l1lll11_opy_ (u"ࡹࠬࡹࡴࡢࡴࡷࠫद"): 0, l1lll11_opy_ (u"ࡺ࠭ࡴࡰࡶࡤࡰࠬध"): 1, l1lll11_opy_ (u"ࡻࠧࡦࡰࡧࠫन"): 1}}
def l1ll_opy_(addon, file):
    l11111_opy_ = file[l1lll11_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ऩ")].split(l1lll11_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪप"), 1)[0]
    l11111_opy_ = dixie.cleanLabel(l11111_opy_)
    return dixie.cleanPrefix(l11111_opy_)
def l11ll1l11_opy_(addon):
    login = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠪࡹ࠯ࠨफ") % addon
    sendJSON(login, addon)
    if (addon == l1ll11l_opy_) or (addon == l11ll1lll_opy_) or (addon == l11llll11_opy_):
        return l1_opy_(addon)
    if (addon == l11llll1l_opy_) or (addon == l1l111111_opy_):
        l11ll1ll1_opy_ = [l1lll11_opy_ (u"ࠪ࠷ࠬब"), l1lll11_opy_ (u"ࠫ࠹࠭भ"), l1lll11_opy_ (u"ࠬ࠼ࠧम"), l1lll11_opy_ (u"࠭࠷ࠨय"), l1lll11_opy_ (u"ࠧ࠹ࠩर"), l1lll11_opy_ (u"ࠨ࠳࠴ࠫऱ"), l1lll11_opy_ (u"ࠩ࠴࠶ࠬल"), l1lll11_opy_ (u"ࠪ࠵࠹࠭ळ"), l1lll11_opy_ (u"ࠫ࠶࠻ࠧऴ"), l1lll11_opy_ (u"ࠬ࠹࠳ࠨव"), l1lll11_opy_ (u"࠭࠹࠲ࠩश"), l1lll11_opy_ (u"ࠧ࠺࠴ࠪष")]
    l1ll11_opy_ = []
    for l11lllll1_opy_ in l11ll1ll1_opy_:
        if (addon == l11llll1l_opy_) or (addon == l1l111111_opy_):
            query = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸ࠵࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࡴࡶࡵࡩࡦࡳ࡟ࡷ࡫ࡧࡩࡴࠬࡥࡹࡶࡵࡥࠫࡶࡡࡨࡧࠩࡴࡱࡵࡴࠧࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡁࠫࡺࡩࡵ࡮ࡨࡁࠫࡻࡲ࡭࠿ࠨࡷࠬस") % (addon, l11lllll1_opy_)
        response = sendJSON(query, addon)
        l1ll11_opy_.extend(response)
    return l1ll11_opy_
def l1_opy_(addon):
    query = l1l1111l1_opy_(addon)
    return sendJSON(query, addon)
def l1l1111l1_opy_(addon):
    Addon = xbmcaddon.Addon(addon)
    l1l111l11_opy_, l11lll111_opy_  = l1l1111ll_opy_(Addon, addon)
    l11lll1ll_opy_, l1l111l1l_opy_ = l11ll1l1l_opy_(Addon, addon)
    return l11lll11l_opy_(addon, l1l111l11_opy_, l11lll111_opy_, l11lll1ll_opy_, l1l111l1l_opy_)
def l1l1111ll_opy_(Addon, addon):
    if addon == l1ll11l_opy_:
        l1l111l11_opy_  = l1lll11_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡵࡳࡴࡺ࠭ࡪࡲࡷࡺ࠳࡯ࡳ࠮ࡨࡲࡹࡳࡪ࠮ࡰࡴࡪࠫह")
        l11lll111_opy_ = l1lll11_opy_ (u"ࠪ࠶࠺࠺࠶࠲ࠩऺ")
        return l1l111l11_opy_, l11lll111_opy_
    if addon == l11llll11_opy_:
        l1l111l11_opy_  = l1lll11_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡴࡺࡴࡵࡸ࠱࡫ࡦ࠭ऻ")
        l11lll111_opy_ = l1lll11_opy_ (u"ࠬ࠸࠰࠺࠷़ࠪ")
        return l1l111l11_opy_, l11lll111_opy_
    l1l111l11_opy_  = Addon.getSetting(l1lll11_opy_ (u"࠭࡬ࡦࡪࡨ࡯ࡾࡲࡧࠨऽ"))
    l11lll111_opy_ = Addon.getSetting(l1lll11_opy_ (u"ࠧࡱࡱࡵࡨ࡮ࡴࡵ࡮ࡤࡨࡶࠬा"))
    return l1l111l11_opy_, l11lll111_opy_
def l11ll1l1l_opy_(Addon, addon):
    if addon == l11llll11_opy_:
        l11lll1ll_opy_ = Addon.getSetting(l1lll11_opy_ (u"ࠨࡗࡶࡩࡷࡴࡡ࡮ࡧࠪि"))
        l1l111l1l_opy_ = Addon.getSetting(l1lll11_opy_ (u"ࠩࡓࡥࡸࡹࡷࡰࡴࡧࠫी"))
        return l11lll1ll_opy_, l1l111l1l_opy_
    l11lll1ll_opy_ = Addon.getSetting(l1lll11_opy_ (u"ࠪ࡯ࡦࡹࡵࡵࡣ࡭ࡥࡳ࡯࡭ࡪࠩु"))
    l1l111l1l_opy_ = Addon.getSetting(l1lll11_opy_ (u"ࠫࡸࡧ࡬ࡢࡵࡲࡲࡦ࠭ू"))
    return l11lll1ll_opy_, l1l111l1l_opy_
def l11lll11l_opy_(addon, l1l111l11_opy_, l11lll111_opy_, l11lll1ll_opy_, l1l111l1l_opy_):
    if addon == l1ll11l_opy_:
        action = l1lll11_opy_ (u"ࠬࡏ࠱࠲ࡋࡌ࠵࡮࠭ृ")
    else:
        action = l1lll11_opy_ (u"࠭ࡳࡵࡴࡨࡥࡲࡥࡶࡪࡦࡨࡳࠬॄ")
    l1l11111l_opy_  = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪॅ")
    l1l11111l_opy_ +=  addon
    l1l11111l_opy_ += l1lll11_opy_ (u"ࠨ࠱ࡂࡥࡨࡺࡩࡰࡰࡀࠩࡸࠬࡥࡹࡶࡵࡥࠫࡶࡡࡨࡧࠩࡴࡱࡵࡴࠧࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡁࠫࡺࡩࡵ࡮ࡨࡁࡆࡲ࡬ࠧࡷࡵࡰࡂ࠭ॆ") % (action)
    params  =  l1l111l11_opy_
    params += l1lll11_opy_ (u"ࠩ࠽ࠫे") + l11lll111_opy_
    params += l1lll11_opy_ (u"ࠪ࠳ࡪࡴࡩࡨ࡯ࡤ࠶࠳ࡶࡨࡱࡁࡸࡷࡪࡸ࡮ࡢ࡯ࡨࡁࠬै")
    params +=  l11lll1ll_opy_
    params += l1lll11_opy_ (u"ࠫࠫࡶࡡࡴࡵࡺࡳࡷࡪ࠽ࠨॉ")
    params +=  l1l111l1l_opy_
    params += l1lll11_opy_ (u"ࠬࠬࡴࡺࡲࡨࡁ࡬࡫ࡴࡠ࡮࡬ࡺࡪࡥࡳࡵࡴࡨࡥࡲࡹࠦࡤࡣࡷࡣ࡮ࡪ࠽࠱ࠩॊ")
    import urllib
    params = urllib.quote_plus(params)
    url = l1l11111l_opy_ + params
    return url
def login(addon):
    login = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶ࠳ࠬो") % addon
    sendJSON(login, addon)
def sendJSON(query, addon):
    l11lll1l1_opy_     = l1lll11_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪौ") % query
    l11llllll_opy_  = xbmc.executeJSONRPC(l11lll1l1_opy_)
    response = json.loads(l11llllll_opy_)
    result   = response[l1lll11_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨ्")]
    return result[l1lll11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨॎ")]
def l1llll_opy_():
    modules = map(__import__, [l1ll111l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11ll_opy_)):
        return l1lll11_opy_ (u"ࠪࡘࡷࡻࡥࠨॏ")
    if len(modules[-1].Window(10**4).getProperty(l11l1_opy_)):
        return l1lll11_opy_ (u"࡙ࠫࡸࡵࡦࠩॐ")
    return l1lll11_opy_ (u"ࠬࡌࡡ࡭ࡵࡨࠫ॑")
def l1111ll_opy_(e, addon):
    l1111l_opy_ = l1lll11_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠱ࠦࡡ࡯ࠢࡨࡶࡷࡵࡲࠡࡱࡦࡧࡺࡸࡥࡥ࠼ࠣࡎࡘࡕࡎࠡࡇࡵࡶࡴࡸ࠺ࠡࠧࡶ࠰ࠥࠫࡳࠨ॒")  % (e, addon)
    l1111_opy_ = l1lll11_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡤࡱࡱࡸࡦࡩࡴࠡࡷࡶࠤࡴࡴࠠࡵࡪࡨࠤ࡫ࡵࡲࡶ࡯࠱ࠫ॓")
    l111ll_opy_ = l1lll11_opy_ (u"ࠨࡗࡳࡰࡴࡧࡤࠡࡣࠣࡰࡴ࡭ࠠࡷ࡫ࡤࠤࡹ࡮ࡥࠡࡣࡧࡨࡴࡴࠠࡴࡧࡷࡸ࡮ࡴࡧࡴࠢࡤࡲࡩࠦࡰࡰࡵࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰ࠴ࠧ॔")
    dixie.log(addon)
    dixie.log(e)
if __name__ == l1lll11_opy_ (u"ࠩࡢࡣࡲࡧࡩ࡯ࡡࡢࠫॕ"):
    checkAddons()