# coding: UTF-8
import sys
l111l1l_opy_ = sys.version_info [0] == 2
l1lll1l_opy_ = 2048
l11l11_opy_ = 7
def l11ll1_opy_ (ll_opy_):
	global l1lll_opy_
	l1111_opy_ = ord (ll_opy_ [-1])
	l111lll_opy_ = ll_opy_ [:-1]
	l1ll1_opy_ = l1111_opy_ % len (l111lll_opy_)
	l1l1l_opy_ = l111lll_opy_ [:l1ll1_opy_] + l111lll_opy_ [l1ll1_opy_:]
	if l111l1l_opy_:
		l1ll1l1_opy_ = unicode () .join ([unichr (ord (char) - l1lll1l_opy_ - (l1l11l_opy_ + l1111_opy_) % l11l11_opy_) for l1l11l_opy_, char in enumerate (l1l1l_opy_)])
	else:
		l1ll1l1_opy_ = str () .join ([chr (ord (char) - l1lll1l_opy_ - (l1l11l_opy_ + l1111_opy_) % l11l11_opy_) for l1l11l_opy_, char in enumerate (l1l1l_opy_)])
	return eval (l1ll1l1_opy_)
import xbmc
import xbmcgui
import xbmcaddon
import json
import datetime
import os
import dixie
import mapping
l1111ll_opy_   = l11ll1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰ࡮ࡻࡸ࠯ࡶࡹࠫࠀ")
l1ll11l_opy_ = l11ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡺࡲࡦࡣࡰࡷࡪࡧࡳࡺ࠰ࡷࡺࠬࠁ")
l1l1l11_opy_ = l11ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹ࡭ࡢࡴࡷ࡬ࡺࡨࠧࠂ")
l11l1_opy_ = l11ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࠶ࠬࠃ")
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
def isValid(stream):
    dixie.log(l11ll1_opy_ (u"ࠨ࠯࠰࠱ࠥࡉࡨࡦࡥ࡮ࠤࡎ࡙ࠠࡗࡃࡏࡍࡉࠦࡳࡵࡴࡨࡥࡲࠦ࠭࠮࠯ࠪࠄ"))
    dixie.log(stream)
    if (l11ll1_opy_ (u"ࠩࡋࡓࡗࡏ࡚࠻ࠩࠅ") in stream) or (l11ll1_opy_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱ࠱࡮ࡶࡴࡷࠩࠆ") in stream):
        dixie.log(l11ll1_opy_ (u"ࠫ࠲࠳࠭ࠡࡊࡒࡖࡎࡠࡏࡏࠢࡗࡖ࡚ࡋࠠ࠮࠯࠰ࠫࠇ"))
        return True
    if (l11ll1_opy_ (u"ࠬࡌࡌࡂ࠼ࠪࠈ") in stream) or (l11ll1_opy_ (u"࠭ࡦ࡭ࡣࡺࡰࡪࡹࡳ࠮࡫ࡳࡸࡻ࠭ࠉ") in stream):
        dixie.log(l11ll1_opy_ (u"ࠧ࠮࠯࠰ࠤࡋࡒࡁࡘࡎࡈࡗࡘࠦࡔࡓࡗࡈࠤ࠲࠳࠭ࠨࠊ"))
        return True
    if l11ll1_opy_ (u"ࠨࡊࡇࡘ࡛࠭ࠋ") in stream:
        dixie.log(l11ll1_opy_ (u"ࠩ࠰࠱࠲ࠦࡈࡅࡖ࡙ࠤ࡙ࡘࡕࡆࠢ࠰࠱࠲࠭ࠌ"))
        return True
    if l1111ll_opy_ in stream:
        dixie.log(l11ll1_opy_ (u"ࠪ࠱࠲࠳ࠠࡍࡋࡘ࡜࡚ࠥࡒࡖࡇࠣ࠱࠲࠳ࠧࠍ"))
        return True
    if l1ll11l_opy_ in stream:
        dixie.log(l11ll1_opy_ (u"ࠫ࠲࠳࠭ࠡࡕࡗࡉࡆ࡙࡙ࠡࡖࡕ࡙ࡊࠦ࠭࠮࠯ࠪࠎ"))
        return True
    dixie.log(l11ll1_opy_ (u"ࠬ࠳࠭࠮࡙ࠢࡅࡑࡏࡄࠡࡈࡄࡐࡘࡋࠠ࠮࠯࠰ࠫࠏ"))
    return False
def getRecording(name, title, start, stream):
    if l11ll1_opy_ (u"࠭ࡈࡐࡔࡌ࡞࠿࠭ࠐ") in stream:
        dixie.log(l11ll1_opy_ (u"ࠧ࠮࠯࠰ࠤࡍࡕࡒࡊ࡜࠽ࠤ࡮ࡴࠠࡴࡶࡵࡩࡦࡳࠠ࠮࠯࠰ࠫࠑ"))
        return getIPTVRecording(name, title, start, stream)
    if l11ll1_opy_ (u"ࠨࡈࡏࡅ࠿࠭ࠒ") in stream:
        dixie.log(l11ll1_opy_ (u"ࠩ࠰࠱࠲ࠦࡆࡍࡃ࠽ࠤ࡮ࡴࠠࡴࡶࡵࡩࡦࡳࠠ࠮࠯࠰ࠫࠓ"))
        return getIPTVRecording(name, title, start, stream)
    if l11ll1_opy_ (u"ࠪࡌࡉ࡚ࡖࠨࠔ") in stream:
        dixie.log(l11ll1_opy_ (u"ࠫ࠲࠳࠭ࠡࡊࡇࡘ࡛ࡀࠠࡪࡰࠣࡷࡹࡸࡥࡢ࡯ࠣ࠱࠲࠳ࠧࠕ"))
        return getHDTVRecording(name, title, start, stream)
    if l1111ll_opy_ in stream:
        dixie.log(l11ll1_opy_ (u"ࠬ࠳࠭࠮ࠢࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮࡬ࡹࡽ࠴ࡴࡷࠢ࡬ࡲࠥࡹࡴࡳࡧࡤࡱࠥ࠳࠭࠮ࠩࠖ"))
        addon = l1111ll_opy_
        return l1ll_opy_(addon, name, title, start, stream)
    if l1ll11l_opy_ in stream:
        dixie.log(l11ll1_opy_ (u"࠭࠭࠮࠯ࠣࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡸࡷ࡫ࡡ࡮ࡵࡨࡥࡸࡿ࠮ࡵࡸࠣ࡭ࡳࠦࡳࡵࡴࡨࡥࡲࠦ࠭࠮࠯ࠪࠗ"))
        addon = l1ll11l_opy_
        return l1ll_opy_(addon, name, title, start, stream)
def getIPTVRecording(name, title, start, stream):
    dixie.log(l11ll1_opy_ (u"ࠧࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࠣࡇࡆ࡚ࡃࡉࠢࡘࡔࠥࡏࡐࡕࡘࠣࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥࠧ࠘"))
    dixie.log(name)
    dixie.log(title)
    dixie.log(start)
    dixie.log(stream)
    import time
    l1llll1_opy_ = stream.split(l11ll1_opy_ (u"ࠨࡾࠪ࠙"))
    dixie.log(l1llll1_opy_)
    for url in l1llll1_opy_:
        url   = url.split(CLOSE_OTT)[1].rsplit(l11ll1_opy_ (u"ࠩ࠽ࠫࠚ"))
        l111l_opy_ = url[0]
        dixie.log(url)
        addon = l1llll_opy_(l111l_opy_)
    dixie.log(l11ll1_opy_ (u"ࠪࡉࡕࡍࠠࡔࡶࡤࡶࡹࠦࡔࡪ࡯ࡨ࠲࠳࠴࠺ࠡࠧࡶࠫࠛ") % start)
    l11_opy_ = str(start)
    dixie.log(l11ll1_opy_ (u"ࠫࡹ࡯࡭ࡦࡵࡷࡶ࡮ࡴࡧ࠻ࠢࠨࡷࠬࠜ") % l11_opy_)
    l1ll11_opy_   = l11_opy_.split(l11ll1_opy_ (u"ࠬࠦࠧࠝ"))[0]
    l1l11ll_opy_  = l11_opy_.split(l11ll1_opy_ (u"࠭ࠠࠨࠞ"))[1]
    l11l_opy_  = time.strptime(l1l11ll_opy_,  l11ll1_opy_ (u"ࠧࠦࡊ࠽ࠩࡒࡀࠥࡔࠩࠟ"))
    theTime    = time.strftime(l11ll1_opy_ (u"ࠨࠧࡋ࠾ࠪࡓࠧࠠ"),  l11l_opy_)
    dixie.log(l11ll1_opy_ (u"ࠩࡌࡔ࡙࡜ࡳࡵࡣࡵࡸ࠿ࠦࠥࡴࠩࠡ") % theTime)
    l11l1l1_opy_ = time.strptime(l1ll11_opy_,   l11ll1_opy_ (u"ࠪࠩ࡞࠳ࠥ࡮࠯ࠨࡨࠬࠢ"))
    theDate    = time.strftime(l11ll1_opy_ (u"ࠫࠪ࡟࠯ࠦ࡯࠲ࠩࡩ࠭ࠣ"), l11l1l1_opy_)
    dixie.log(l11ll1_opy_ (u"ࠬࡏࡐࡕࡘࡧࡸ࡮ࡺ࡬ࡦ࠼ࠣࠩࡸ࠭ࠤ") % theDate)
    return getCatchupLink(addon, name, title, theDate, theTime)
def l1llll_opy_(l111l_opy_):
    if l111l_opy_ == l11ll1_opy_ (u"࠭ࡆࡍࡃࠪࠥ"):
        return l11ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡆ࡭ࡣࡺࡰࡪࡹࡳࡕࡸࠪࠦ")
    if l111l_opy_ == l11ll1_opy_ (u"ࠨࡊࡒࡖࡎࡠࠧࠧ"):
        return l11ll1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡪࡲࡶ࡮ࢀ࡯࡯࡫ࡳࡸࡻ࠭ࠨ")
def getCatchupLink(addon, channel, theShow, theDate, theTime):
    dixie.log(l11ll1_opy_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࠣ࡫ࡪࡺࡃࡢࡶࡦ࡬ࡺࡶࡌࡪࡰ࡮ࠤࡂࡃ࠽࠾࠿ࡀࠫࠩ"))
    HOME  = dixie.PROFILE
    iPATH = os.path.join(HOME, l11ll1_opy_ (u"ࠫ࡮ࡴࡩࠨࠪ"))
    LABELFILE = os.path.join(iPATH, l11ll1_opy_ (u"ࠬࡩࡡࡵࡥ࡫ࡹࡵ࠴ࡪࡴࡱࡱࠫࠫ"))
    labelmaps = json.load(open(LABELFILE))
    dixie.log(labelmaps)
    l11llll_opy_ = l11ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩࠬ") + addon
    item   = l11l111_opy_(addon)
    try:
        l1lll1_opy_  = findCatchup(l11llll_opy_, item)
        l1l11_opy_  = mapping.mapLabel(labelmaps, channel)
        dixie.log(l11ll1_opy_ (u"ࠧ࠾࠿ࡀࡁࡂࡃࠠ࡮ࡣࡳࡴࡪࡪࡌࡢࡤࡨࡰࠥࡃ࠽࠾࠿ࡀࡁࠬ࠭"))
        dixie.log(l1l11_opy_)
        l111_opy_   = findCatchup(l1lll1_opy_, l1l11_opy_)
        dixie.log(l11ll1_opy_ (u"ࠨ࠿ࡀࡁࡂࡃ࠽ࠡࡶ࡫ࡩࡈ࡮ࡡ࡯ࡰࡨࡰࠥࡃ࠽࠾࠿ࡀࡁࠬ࠮"))
        dixie.log(l111_opy_)
        l111ll_opy_ = theDate + l11ll1_opy_ (u"ࠩࠣ࠱ࠥ࠭࠯") + theTime
        l111ll_opy_ = l111ll_opy_.upper()
        dixie.log(l11ll1_opy_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࠣࡸ࡭࡫ࡒࡦࡥࡲࡶࡩ࡯࡮ࡨࠢࡀࡁࡂࡃ࠽࠾ࠩ࠰"))
        dixie.log(l111ll_opy_)
        l11111_opy_      = findCatchup(l111_opy_, l111ll_opy_, splitlabel=True)
        dixie.log(l11ll1_opy_ (u"ࠫࡂࡃ࠽࠾࠿ࡀࠤࡹ࡮ࡥࡍ࡫ࡱ࡯ࠥࡃ࠽࠾࠿ࡀࡁࠬ࠱"))
        dixie.log(l11111_opy_)
        dixie.DialogOK(l11ll1_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡵࡲࡢࡰࡪࡩࡢࡡࡂ࡞ࡅࡤࡸࡨ࡮࠭ࡶࡲࠣࡷࡹࡸࡥࡢ࡯ࠣࡪࡴࡻ࡮ࡥ࠰࡞࠳ࡇࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ࠲"), l11ll1_opy_ (u"࠭ࡏ࡯࠯ࡗࡥࡵࡶ࠮ࡕࡘࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡻࠥࡶ࡬ࡢࡻ࠽ࠤࡠࡉࡏࡍࡑࡕࠤࡴࡸࡡ࡯ࡩࡨࡡࡠࡈ࡝ࠦࡵ࡞࠳ࡇࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ࠳") % (theShow))
        return l11111_opy_
    except:
        return None
def l11l111_opy_(addon):
    if addon == l11ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡆ࡭ࡣࡺࡰࡪࡹࡳࡕࡸࠪ࠴"):
        return l11ll1_opy_ (u"ࠨࡈࡏࡅ࡜ࡒࡅࡔࡕࠣࡇࡆ࡚ࡃࡉࡗࡓࠫ࠵")
    if addon == l11ll1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡪࡲࡶ࡮ࢀ࡯࡯࡫ࡳࡸࡻ࠭࠶"):
        return l11ll1_opy_ (u"ࠪࡌࡔࡘࡉ࡛ࡑࡑࠤࡈࡇࡔࡄࡊࡘࡔࠬ࠷")
def findCatchup(query, item, splitlabel=False):
    dixie.log(l11ll1_opy_ (u"ࠫࡂࡃ࠽࠾࠿ࡀࠤࡋࡏࡎࡅࠢࡆࡅ࡙ࡉࡈࡖࡒࠣࡍ࡙ࡋࡍࠡ࠿ࡀࡁࡂࡃ࠽ࠨ࠸"))
    dixie.log(item)
    response = doJSON(query)
    l1111l_opy_    = response[l11ll1_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬ࠹")][l11ll1_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬ࠺")]
    for file in l1111l_opy_:
        l1l1_opy_ = file[l11ll1_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭࠻")]
        l1l1l1_opy_ = mapping.cleanLabel(l1l1_opy_)
        if splitlabel:
            l1l1l1_opy_ = l1l1l1_opy_.upper()
            l1l1l1_opy_ = l1l1l1_opy_.rsplit(l11ll1_opy_ (u"ࠨࠢ࠰ࠤࠬ࠼"), 1)[0]
        else:
            l1l1l1_opy_ = l1l1l1_opy_.upper()
        dixie.log(l11ll1_opy_ (u"ࠩࡀࡁࡂࡃ࠽࠾ࠢࡉࡍࡓࡊࠠࡄࡃࡗࡇࡍ࡛ࡐࠡ࠿ࡀࡁࡂࡃ࠽ࠨ࠽"))
        dixie.log(l1l1l1_opy_)
        if l1l1l1_opy_ == item.upper():
            dixie.log(l11ll1_opy_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࠣࡇࡆ࡚ࡃࡉࡗࡓࠤࡋࡏࡌࡆࠢࡀࡁࡂࡃ࠽࠾ࠩ࠾"))
            dixie.log(file[l11ll1_opy_ (u"ࠫ࡫࡯࡬ࡦࠩ࠿")])
            return file[l11ll1_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪࡀ")]
def doJSON(query):
    l1l111l_opy_  = (l11ll1_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࠧࡶࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩࡁ") % query)
    response = xbmc.executeJSONRPC(l1l111l_opy_)
    content  = json.loads(response)
    return content
def l1ll_opy_(addon, name, title, start, stream):
    import time
    dixie.log(l11ll1_opy_ (u"ࠧࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࠣࡇࡆ࡚ࡃࡉࠢࡘࡔࠥࡒࡘࡕࡘࠣࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥࠧࡂ"))
    l1llll1_opy_ = stream.split(l11ll1_opy_ (u"ࠨࡾࠪࡃ"))
    for url in l1llll1_opy_:
        if (l1ll11l_opy_ in url) or (l1111ll_opy_ in url):
            dixie.log(l11ll1_opy_ (u"ࠩࡏ࡜࡙࡜ࠠࡖࡔࡏ࠲࠳࠴࠺ࠡࠧࡶࠫࡄ") % url)
            l111l1_opy_ = url.split(CLOSE_OTT)[0].replace(OPEN_OTT, l11ll1_opy_ (u"ࠪࠫࡅ"))
            break
    import urllib
    l1l1ll1_opy_ = l1lllll_opy_()
    dixie.log(l11ll1_opy_ (u"ࠫࡊࡖࡇࠡࡕࡷࡥࡷࡺࠠࡕ࡫ࡰࡩ࠳࠴࠮࠻ࠢࠨࡷࠬࡆ") % start)
    dixie.log(l11ll1_opy_ (u"ࠬࡕࡦࡧࡵࡨࡸࠥ࡯࡮ࠡࡵࡨࡧࡴࡴࡤࡴ࠼ࠣࠩࡸ࠭ࡇ") % l1l1ll1_opy_)
    l11l11l_opy_  =  start - datetime.timedelta(seconds=l1l1ll1_opy_)
    dixie.log(l11ll1_opy_ (u"࠭ࡓࡵࡣࡵࡸ࡚ࠥࡩ࡮ࡧࠣࡳ࡫࡬ࡳࡦࡶ࠽ࠤࠪࡹࠧࡈ") % l11l11l_opy_)
    l1lll11_opy_     = l1ll1l_opy_(l111l1_opy_)
    l11_opy_ = str(l11l11l_opy_)
    l11lll1_opy_   = l11_opy_.split(l11ll1_opy_ (u"ࠧࠡࠩࡉ"))[0]
    l1l11ll_opy_  = l11_opy_.split(l11ll1_opy_ (u"ࠨࠢࠪࡊ"))[1]
    l11l1l_opy_  = time.strptime(l1l11ll_opy_,  l11ll1_opy_ (u"ࠩࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠫࡋ"))
    l11l1l_opy_  = time.strftime(l11ll1_opy_ (u"ࠪࠩࡎࡀࠥࡎࠢࠨࡴࠬࡌ"),  l11l1l_opy_)
    l1l1111_opy_ = time.strptime(l11lll1_opy_,   l11ll1_opy_ (u"ࠫࠪ࡟࠭ࠦ࡯࠰ࠩࡩ࠭ࡍ"))
    l1l1111_opy_ = time.strftime(l11ll1_opy_ (u"ࠬࠫࡁ࠭ࠢࠨࡆࠥࠫࡤࠨࡎ"), l1l1111_opy_)
    query = l11ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶ࠳ࡄࡩࡨࡢࡰࡱࡩࡱࡥࡩࡥ࠿ࠨࡷࠫࡪࡡࡵࡧࡀࠩࡸࠬࡤࡢࡶࡨࡣࡹ࡯ࡴ࡭ࡧࡀࠩࡸࠬࡩ࡮ࡩࡀࠪࡲࡵࡤࡦ࠿ࡵࡩࡨࡵࡲࡥ࡫ࡱ࡫ࡸࠬࡴࡪࡶ࡯ࡩࡂࠫࡳࠨࡏ") % (addon, l1lll11_opy_, l11lll1_opy_, l1l1111_opy_, l111l1_opy_)
    l1l111_opy_  = l11ll1_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࡐ") % query
    if not l1lll11_opy_:
        dixie.DialogOK(l11ll1_opy_ (u"ࠨࡕࡲࡶࡷࡿ࠮ࠨࡑ"), l11ll1_opy_ (u"࡚ࠩࡩࠥࡩ࡯ࡶ࡮ࡧࠤࡳࡵࡴࠡࡨ࡬ࡲࡩࠦࡡࠡࡥࡤࡸࡨ࡮ࡵࡱࠢࡶࡩࡷࡼࡩࡤࡧࠣࡪࡴࡸࠠࡵࡪ࡬ࡷࠥࡩࡨࡢࡰࡱࡩࡱ࠴ࠧࡒ"), l11ll1_opy_ (u"ࠪࡖࡪࡼࡥࡳࡶ࡬ࡲ࡬ࠦࡢࡢࡥ࡮ࠤࡹࡵࠠࡍ࡫ࡹࡩ࡚ࠥࡖ࠯ࠩࡓ"))
        return None
    l1ll1ll_opy_    = xbmc.executeJSONRPC(l1l111_opy_)
    response   = json.loads(l1ll1ll_opy_)
    result     = response[l11ll1_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫࡔ")]
    l1ll111_opy_ = result[l11ll1_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫࡕ")]
    for l11l1ll_opy_ in l1ll111_opy_:
        try:
            l11lll_opy_ = l11l1ll_opy_[l11ll1_opy_ (u"࠭ࡦࡪ࡮ࡨࠫࡖ")]
            l1l1l1_opy_   = l11l1ll_opy_[l11ll1_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ࡗ")]
            if l11l1l_opy_ in l1l1l1_opy_:
                dixie.DialogOK(l11ll1_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡱࡵࡥࡳ࡭ࡥ࡞ࡅࡤࡸࡨ࡮࠭ࡶࡲࠣࡷࡹࡸࡥࡢ࡯ࠣࡪࡴࡻ࡮ࡥ࠰࡞࠳ࡈࡕࡌࡐࡔࡠࠫࡘ"), l11ll1_opy_ (u"ࠩࡒࡲ࠲࡚ࡡࡱࡲ࠱ࡘ࡛ࠦࡷࡪ࡮࡯ࠤࡳࡵࡷࠡࡲ࡯ࡥࡾࡀࠠ࡜ࡅࡒࡐࡔࡘࠠࡰࡴࡤࡲ࡬࡫࡝࡜ࡄࡠࠩࡸࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠ࡙ࠫ") % (title))
                return l11lll_opy_
        except Exception, e:
            dixie.log(l11ll1_opy_ (u"ࠪࡉࡗࡘࡏࡓ࠼ࠣࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡴࡩࡴࡲࡻࡳࠦࡩ࡯ࠢࡪࡩࡹࡒࡘࡕࡘࡕࡩࡨࡵࡲࡥ࡫ࡱ࡫ࠥࠫࡳࠨ࡚") % str(e))
            dixie.DialogOK(l11ll1_opy_ (u"ࠫࡘࡵࡲࡳࡻ࠱࡛ࠫ"), l11ll1_opy_ (u"ࠬ࡝ࡥࠡࡥࡲࡹࡱࡪࠠ࡯ࡱࡷࠤ࡫࡯࡮ࡥࠢࡤࠤࡨࡧࡴࡤࡪࡸࡴࠥࡹࡴࡳࡧࡤࡱࠥ࡬࡯ࡳࠢࡷ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭࠯ࠩ࡜"), l11ll1_opy_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡴࡳࡻࠣࡥ࡬ࡧࡩ࡯ࠢ࡯ࡥࡹ࡫ࡲ࠯ࠩ࡝"))
            return None
def l1ll1l_opy_(l111l1_opy_):
    l111l1_opy_ = l111l1_opy_.upper()
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧ࠴ࡇࠪ࡞") : return 188
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡃࡅࡇࠥࡋࡁࡔࡖࠪ࡟") : return 363
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡄࡆࡈ࠭ࡠ") : return 346
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡅࡒࡉࠧࡡ") : return 375
    if l111l1_opy_ == l11ll1_opy_ (u"ࠫࡆࡒࡉࡃࡋࠣࡍࡗࡋࡌࡂࡐࡇࠫࡢ") : return 280
    if l111l1_opy_ == l11ll1_opy_ (u"ࠬࡇࡎࡊࡏࡄࡐࠥࡖࡌࡂࡐࡈࡘ࡛ࠥࡓࡂࠩࡣ") : return 386
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡁࡏࡋࡐࡅࡑࠦࡐࡍࡃࡑࡉ࡙࠭ࡤ") : return 19
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡂࡔࡈࡒࡆࠦࡓࡑࡑࡕࡘࡘࠦ࠱ࠡࡊࡇࠤࡈࡘࡏࡂࡖࡌࡅࠬࡥ") : return 403
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡃࡕࡉࡓࡇࠠࡔࡒࡒࡖ࡙࡙ࠠ࠳ࠢࡋࡈࠥࡉࡒࡐࡃࡗࡍࡆ࠭ࡦ") : return 404
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡄࡖࡊࡔࡁࠡࡕࡓࡓࡗ࡚ࡓࠡ࠵ࠣࡌࡉࠦࡃࡓࡑࡄࡘࡎࡇࠧࡧ") : return 405
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡅࡗࡋࡎࡂࠢࡖࡔࡔࡘࡔࡔࠢ࠷ࠤࡍࡊࠠࡄࡔࡒࡅ࡙ࡏࡁࠨࡨ") : return 406
    if l111l1_opy_ == l11ll1_opy_ (u"ࠫࡆࡘࡅࡏࡃࠣࡗࡕࡕࡒࡕࡕࠣ࠹࡙ࠥࡒࡃࠩࡩ") : return 407
    if l111l1_opy_ == l11ll1_opy_ (u"ࠬࡇࡔࠡࡖࡋࡉࠥࡘࡁࡄࡇࡖࠫࡪ") : return 273
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡂࡃࡅࠣࡓࡓࡋ࡛ࡉࡆࡠࠫ࡫") : return 210
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡃࡄࡆࠤ࡙࡝ࡏ࡜ࡊࡇࡡࠬ࡬") : return 211
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡄࡈࡍࡓࠦࡓࡑࡑࡕࡘࠥ࠷࠰ࠡࡊࡇ࡙ࠬࡋࡓࡕࠫࠪ࡭") : return 300
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡅࡉࡎࡔࠠࡔࡒࡒࡖ࡙ࠦ࠱࠲ࠢࡋࡈ࡚࠭ࡅࡔࡖࠬࠫ࡮") : return 389
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡆࡊࡏࡎࠡࡕࡓࡓࡗ࡚ࠠ࠲ࡊࡇ࡙ࠬࡋࡓࡕࠫࠪ࡯") : return 285
    if l111l1_opy_ == l11ll1_opy_ (u"ࠫࡇࡋࡉࡏࠢࡖࡔࡔࡘࡔࠡ࠴ࠣࡌࡉ࠮ࡔࡆࡕࡗ࠭ࠬࡰ") : return 286
    if l111l1_opy_ == l11ll1_opy_ (u"ࠬࡈࡅࡊࡐࠣࡗࡕࡕࡒࡕࠢ࠶ࠤࡍࡊࠨࡕࡇࡖࡘ࠮࠭ࡱ") : return 287
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡂࡆࡋࡑࠤࡘࡖࡏࡓࡖࠣ࠸ࠥࡎࡄࠩࡖࡈࡗ࡙࠯ࠧࡲ") : return 288
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡃࡇࡌࡒ࡙ࠥࡐࡐࡔࡗࠤ࠺ࠦࡈࡅࠪࡗࡉࡘ࡚ࠩࠨࡳ") : return 289
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡄࡈࡍࡓࠦࡓࡑࡑࡕࡘࠥ࠼ࠠࡉࡆࠫࡘࡊ࡙ࡔࠪࠩࡴ") : return 290
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡅࡉࡎࡔࠠࡔࡒࡒࡖ࡙ࠦ࠷ࠡࡊࡇ࡙ࠬࡋࡓࡕࠫࠪࡵ") : return 291
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡆࡊࡏࡎࠡࡕࡓࡓࡗ࡚ࠠ࠹ࠢࡋࡈ࡚࠭ࡅࡔࡖࠬࠫࡶ") : return 292
    if l111l1_opy_ == l11ll1_opy_ (u"ࠫࡇࡋࡉࡏࠢࡖࡔࡔࡘࡔࠡ࠻ࠣࡌࡉ࠮ࡔࡆࡕࡗ࠭ࠬࡷ") : return 293
    if l111l1_opy_ == l11ll1_opy_ (u"ࠬࡈࡔࠡࡕࡓࡓࡗ࡚ࠠ࠲ࠢࡋࡈࠥ࠮ࡔࡆࡕࡗ࠭ࠬࡸ") : return 306
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡂࡕࠢࡖࡔࡔࡘࡔࠡ࠳ࠪࡹ") : return 17
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡃࡖࠣࡗࡕࡕࡒࡕࠢ࠵ࠤࡍࡊࠠࠩࡖࡈࡗ࡙࠯ࠧࡺ") : return 307
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡄࡗࠤࡘࡖࡏࡓࡖࠣ࠶ࠬࡻ") : return 18
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡅࡘ࡙ࠥࡐࡐࡔࡗࠤࡊ࡙ࡐࡏࠩࡼ") : return 24
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡆ࡙ࠦࡓࡑࡑࡕࡘࠥࡋࡕࡓࡑࡓࡉࠬࡽ") : return 216
    if l111l1_opy_ == l11ll1_opy_ (u"ࠫࡇࡇࡂ࡚ࠢࡗ࡚ࠬࡾ") : return 299
    if l111l1_opy_ == l11ll1_opy_ (u"ࠬࡈࡌࡖࡇࠣࡌ࡚࡙ࡔࡍࡇࡕࠤࡊ࡛ࡒࡐࡒࡈࠫࡿ") : return 241
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡂࡐࡑࡐࡉࡗࡇࡎࡈࠩࢀ") : return 192
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡃࡑ࡛ࠤࡓࡇࡔࡊࡑࡑࠫࢁ") : return 185
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡄࡕࡍ࡙ࡏࡓࡉࠢࡈ࡙ࡗࡕࡓࡑࡑࡕࡘ࠷࠭ࢂ") : return 173
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡅࡖࡎ࡚ࡉࡔࡊࠣࡉ࡚ࡘࡏࡔࡒࡒࡖ࡙࠭ࢃ") : return 182
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡇࡇ࡙ࠠࡓࡇࡄࡐࡎ࡚࡙ࠨࢄ") : return 190
    if l111l1_opy_ == l11ll1_opy_ (u"ࠫࡈࡔࡂࡄࠩࢅ") : return 366
    if l111l1_opy_ == l11ll1_opy_ (u"ࠬࡉࡎࡏࠩࢆ") : return 365
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡃࡂࡔࡗࡓࡔࡔࠠࡏࡇࡗ࡛ࡔࡘࡋࠡࡗࡎࠫࢇ") : return 186
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡄࡃࡕࡘࡔࡕࡎࡊࡖࡒࠫ࢈") : return 250
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡅࡋࡉࡑ࡙ࡅࡂࠢࡗ࡚ࠬࢉ") : return 179
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡆࡓࡒࡋࡄ࡚ࠢࡆࡉࡓ࡚ࡒࡂࡎ࡙ࠣࡘࡇࠧࢊ") : return 374
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡇࡔࡓࡅࡅ࡛ࠣࡇࡊࡔࡔࡓࡃࡏࠫࢋ") : return 251
    if l111l1_opy_ == l11ll1_opy_ (u"ࠫࡈࡕࡍࡆࡆ࡜ࠤ࡝࡚ࡒࡂࠩࢌ") : return 176
    if l111l1_opy_ == l11ll1_opy_ (u"ࠬࡉࡒࡊࡏࡈࠤࡎࡔࡖࡆࡕࡗࡍࡌࡇࡔࡊࡑࡑࠫࢍ") : return 249
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡄࡂࡘࡈࠫࢎ") : return 230
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡅࡋࡖࡇࡔ࡜ࡅࡓ࡛ࠣࡌࡎ࡙ࡔࡐࡔ࡜ࠫ࢏") : return 20
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡆࡌࡗࡈࡕࡖࡆࡔ࡜ࠤࡘࡉࡉࡆࡐࡆࡉࠬ࢐") : return 103
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡇࡍࡘࡉࡏࡗࡇࡕ࡝࡚ࠥࡕࡓࡄࡒࠫ࢑") : return 102
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡈࡎ࡙ࡃࡐࡘࡈࡖ࡞࠷ࠧ࢒") : return 98
    if l111l1_opy_ == l11ll1_opy_ (u"ࠫࡉࡏࡓࡄࡑ࡙ࡉࡗ࡟ࠧ࢓") : return 370
    if l111l1_opy_ == l11ll1_opy_ (u"ࠬࡊࡉࡔࡐࡈ࡝ࡈࡎࡎࡍࠩ࢔") : return 117
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡄࡊࡕࡑࡉ࡞ࡐࡕࡏࡋࡒࡖࠬ࢕") : return 118
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡆࡕࡓࡒࠥ࠸ࠧ࢖") : return 349
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡇࡖࡔࡓ࠭ࢗ") : return 348
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡈࡈࡊࡔࠠࠬ࠳ࠪ࢘") : return 278
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡉࡎࡘࠠࡔࡒࡒࡖ࡙࡙࢙ࠧ") : return 30
    if l111l1_opy_ == l11ll1_opy_ (u"ࠫࡊ࡛ࡒࡐࡐࡈ࡛ࡘ࢚࠭") : return 398
    if l111l1_opy_ == l11ll1_opy_ (u"ࠬࡌࡏ࡙ࠢࡖࡔࡔࡘࡔࡔࠢ࠴࢛ࠫ") : return 352
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡆࡐ࡚ࠣࡒࡊ࡝ࡓࠨ࢜") : return 274
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡈࡑࡏࡈ࡛ࠥࡋࠨ࢝") : return 277
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡊ࠵ࠤ࡚ࡑࠧ࢞") : return 271
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡋࡆࡔࠦࡅࡂࡕࡗࠫ࢟") : return 376
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡌࡇࡕࠠࡇࡃࡐࡍࡑ࡟ࠧࢠ") : return 377
    if l111l1_opy_ == l11ll1_opy_ (u"ࠫࡍࡈࡏࠡࡕࡌࡋࡓࡇࡔࡖࡔࡈࠫࢡ") : return 378
    if l111l1_opy_ == l11ll1_opy_ (u"ࠬࡎࡂࡐࠢ࡝ࡓࡓࡋࠧࢢ") : return 379
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡈࡈࡖ࡙ࠫࢣ") : return 384
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡉࡋࡖࡘࡔࡘ࡙ࠡࡗࡎࠫࢤ") : return 268
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡊࡌࡗ࡙ࡕࡒ࡚ࠢࡘࡗࡆ࠭ࢥ") : return 369
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡋࡓࡒࡋࠠࠬ࠳ࠪࢦ") : return 279
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡌࡔࡘࡒࡐࡔࠣࡇࡍࡇࡎࡏࡇࡏࠤ࡚ࡑࠧࢧ") : return 183
    if l111l1_opy_ == l11ll1_opy_ (u"ࠫࡎࡊࠠࡖࡍࠪࢨ") : return 229
    if l111l1_opy_ == l11ll1_opy_ (u"ࠬࡏࡔࡗࠢ࠵ࠫࢩ") : return 208
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡉࡕࡘࠣ࠷ࠬࢪ") : return 207
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡊࡖ࡙ࠤ࠹࠭ࢫ") : return 209
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡋࡗ࡚ࠬࢬ") : return 206
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡏࡊࡈࠦࡔࡗࠩࢭ") : return 180
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡑࡎࡕࠠࡔࡖࡄࡈࡎ࡛ࡍࠡ࠳࠳࠶ࠥࡎࡄࠨࢮ") : return 334
    if l111l1_opy_ == l11ll1_opy_ (u"ࠫࡒࡏࡏࠡࡕࡗࡅࡉࡏࡕࡎࠢ࠴࠴࠸ࠦࡈࡅࠩࢯ") : return 335
    if l111l1_opy_ == l11ll1_opy_ (u"ࠬࡓࡉࡐࠢࡖࡘࡆࡊࡉࡖࡏࠣ࠵࠵࠺ࠠࡉࡆࠪࢰ") : return 336
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡍࡊࡑࠣࡗ࡙ࡇࡄࡊࡗࡐࠤ࠶࠶࠵ࠡࡊࡇࠫࢱ") : return 337
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡎࡋࡒࠤࡘ࡚ࡁࡅࡋࡘࡑࠥ࠷࠰࠷ࠢࡋࡈࠬࢲ") : return 338
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡏࡌࡓ࡙ࠥࡔࡂࡆࡌ࡙ࡒࠦ࠱࠱࠹ࠣࡌࡉ࠭ࢳ") : return 333
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡐࡘ࡛ࠦࡂࡂࡕࡈࠫࢴ") : return 132
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡑ࡙࡜ࠠࡅࡃࡑࡇࡊ࠭ࢵ") : return 131
    if l111l1_opy_ == l11ll1_opy_ (u"ࠫࡒ࡚ࡖࠡࡊࡌࡘࡘࠧࠧࢶ") : return 135
    if l111l1_opy_ == l11ll1_opy_ (u"ࠬࡓࡔࡗࠢࡐ࡙ࡘࡏࡃࠨࢷ") : return 217
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡍࡕࡘࠣࡖࡔࡉࡋࡔࠩࢸ") : return 133
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡎࡗࡗ࡚ࠬࢹ") : return 106
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡏࡒࡘࡔࡘࡓࠡࡗࡎࠫࢺ") : return 215
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡑࡆࡆ࠭ࢻ") : return 283
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡒࡇࡉࠠࡆࡃࡖࡘࠬࢼ") : return 361
    if l111l1_opy_ == l11ll1_opy_ (u"ࠫࡓࡏࡃࡌࠢࡗࡓࡔࡔࡓࠨࢽ") : return 296
    if l111l1_opy_ == l11ll1_opy_ (u"ࠬࡔࡁࡕࠢࡊࡉࡔࠦࡗࡊࡎࡇࠤ࡚ࡑࠧࢾ") : return 269
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡎࡂࡖࡌࡓࡓࡇࡌࠡࡉࡈࡓࡌࡘࡁࡑࡊࡌࡇ࡛ࠥࡋࠨࢿ") : return 270
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡏࡃࡗࡍࡔࡔࡁࡍࠢࡊࡉࡔࡍࡒࡂࡒࡋࡍࡈࠦࡕࡔࡃࠪࣀ") : return 371
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡐࡌࡇࡐࠦࡊࡖࡐࡌࡓࡗ࠭ࣁ") : return 297
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡑࡍࡈࡑࠠࡖࡍࠪࣂ") : return 295
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡔࡗࡋࡍࡊࡇࡕࡗࡕࡕࡒࡕࡕࠪࣃ") : return 29
    if l111l1_opy_ == l11ll1_opy_ (u"ࠫࡗ࡚ࡅࠡࡑࡑࡉࠬࣄ") : return 69
    if l111l1_opy_ == l11ll1_opy_ (u"ࠬࡘࡔࡆࠢࡗ࡛ࡔࡡࡈࡅ࡟ࠪࣅ") : return 70
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡒࡕࡇࡍࡖࠬࣆ") : return 89
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡓࡃࡆࡍࡓࡍࠠࡖࡍࠪࣇ") : return 26
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡔࡈࡅࡑࠦࡌࡊࡘࡈࡗࠬࣈ") : return 275
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡖࡏ࡞ࠦࡂࡖࡐࡇࡉࡘࡒࡉࡈࡃࠣ࠵ࠥࡎࡄ࡜ࡆࡈࡡࠬࣉ") : return 408
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡗࡐ࡟ࠠࡏࡇ࡚ࡗࠬ࣊") : return 263
    if l111l1_opy_ == l11ll1_opy_ (u"ࠫࡘࡑ࡙ࠡ࠳ࠪ࣋") : return 177
    if l111l1_opy_ == l11ll1_opy_ (u"࡙ࠬࡋ࡚ࠢ࠵ࠫ࣌") : return 178
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡓࡌ࡛ࠣࡅࡈ࡚ࡉࡐࡐࠣࡑࡔ࡜ࡉࡆࡕࠪ࣍") : return 16
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡔࡍ࡜ࠤࡆ࡚ࡌࡂࡐࡗࡍࡈ࠭࣎") : return 174
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡕࡎ࡝ࠥࡉࡏࡎࡇࡇ࡝ࠥࡓࡏࡗࡋࡈࡗ࣏ࠬ") : return 34
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡖࡏ࡞ࠦࡄࡓࡃࡐࡅࡗࡕࡍࠡࡏࡒ࡚ࡎࡋࡓࠨ࣐") : return 97
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡗࡐ࡟ࠠࡇࡃࡐࡍࡑ࡟ࠠࡎࡑ࡙ࡍࡊ࡙࣑ࠧ") : return 36
    if l111l1_opy_ == l11ll1_opy_ (u"ࠫࡘࡑ࡙ࠡࡉࡕࡉࡆ࡚ࡓࠡࡏࡒ࡚ࡎࡋࡓࠨ࣒") : return 37
    if l111l1_opy_ == l11ll1_opy_ (u"࡙ࠬࡋ࡚ࠢࡐࡓ࡛ࡏࡅࡔࠢࡇࡍࡘࡔࡅ࡚࣓ࠩ") : return 220
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡓࡌ࡛ࠣࡔࡗࡋࡍࡊࡇࡕࡉࠥࡓࡏࡗࡋࡈࡗࠬࣔ") : return 40
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡔࡍ࡜ࠤࡘࡉࡆࡊࡊࡒࡖࡗࡕࡒࠡࡏࡒ࡚ࡎࡋࡓࠨࣕ") : return 41
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡕࡎ࡝࡙ࠥࡅࡍࡇࡆࡘࠥࡓࡏࡗࡋࡈࡗࠬࣖ") : return 42
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡖࡏ࡞ࠦࡓࡑࠢࡑࡉ࡜࡙ࠠࡉࡓࠪࣗ") : return 175
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡗࡐ࡟ࠠࡔࡒࡒࡖ࡙ࠦ࠱ࠡࡊࡇࠤ࡚࠭ࡅࡔࡖࠬࠫࣘ") : return 301
    if l111l1_opy_ == l11ll1_opy_ (u"ࠫࡘࡑ࡙ࠡࡕࡓࡓࡗ࡚ࠠ࠳ࠢࡋࡈࠥ࠮ࡔࡆࡕࡗ࠭ࠬࣙ") : return 302
    if l111l1_opy_ == l11ll1_opy_ (u"࡙ࠬࡋ࡚ࠢࡖࡔࡔࡘࡔࠡ࠵ࠣࡌࡉࠦࠨࡕࡇࡖࡘ࠮࠭ࣚ") : return 303
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡓࡌ࡛ࠣࡗࡕࡕࡒࡕࠢ࠷ࠤࡍࡊࠠࠩࡖࡈࡗ࡙࠯ࠧࣛ") : return 304
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡔࡍ࡜ࠤࡘࡖࡏࡓࡖࠣ࠹ࠥࡎࡄࠡࠪࡗࡉࡘ࡚ࠩࠨࣜ") : return 305
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡕࡎ࡝࡙ࠥࡐࡐࡔࡗࡗࠥ࠷ࠧࣝ") : return 95
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡖࡏ࡞ࠦࡓࡑࡑࡕࡘࡘࠦ࠲ࠨࣞ") : return 136
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡗࡐ࡟ࠠࡔࡒࡒࡖ࡙࡙ࠠ࠴ࠩࣟ") : return 43
    if l111l1_opy_ == l11ll1_opy_ (u"ࠫࡘࡑ࡙ࠡࡕࡓࡓࡗ࡚ࡓࠡ࠶ࠪ࣠") : return 119
    if l111l1_opy_ == l11ll1_opy_ (u"࡙ࠬࡋ࡚ࠢࡖࡔࡔࡘࡔࡔࠢ࠸ࠫ࣡") : return 120
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡓࡌ࡛ࠣࡘࡍࡘࡉࡍࡎࡈࡖࠥࡓࡏࡗࡋࡈࡗࠬ࣢") : return 96
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡔࡍ࡜ࠤࡑࡏࡖࡊࡐࡊࣣࠫ") : return 298
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡕࡓࡓࡗ࡚ࡓࠡࡈ࠴ࠫࣤ") : return 45
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡖ࡝ࡋ࡟ࠠࡖࡕࡄࠫࣥ") : return 383
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡘࡈࡓࠠࠬ࠳࡙ࠣࡐࣦ࠭") : return 189
    if l111l1_opy_ == l11ll1_opy_ (u"࡙ࠫࡍ࠴ࠨࣧ") : return 88
    if l111l1_opy_ == l11ll1_opy_ (u"࡚ࠬࡓࡏࠢ࠴ࠫࣨ") : return 339
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡔࡔࡐࠣ࠶ࣩࠬ") : return 340
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡕࡕࡑࠤ࠸࠭࣪") : return 341
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡖࡖࡒࠥ࠺ࠧ࣫") : return 342
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩࡗࡗࡓࠦ࠵ࠨ࣬") : return 343
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡘ࡛࠹ࠠࡊࡇ࣭ࠪ") : return 87
    if l111l1_opy_ == l11ll1_opy_ (u"࡙ࠫࡘࡁࡗࡇࡏࠤࡈࡎࡁࡏࡐࡈࡐ࠰࠷ࠠࡖࡍ࣮ࠪ") : return 184
    if l111l1_opy_ == l11ll1_opy_ (u"࡛ࠬࡓࡂࠢࡉࡓ࡝ࠦࡓࡑࡑࡕࡘࡘ࣯࠭") : return 347
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡕࡔࡃࠣࡒࡊ࡚ࡗࡐࡔࡎࣰࠫ") : return 344
    if l111l1_opy_ == l11ll1_opy_ (u"ࠧࡖࡖ࡙ࠤࡎࡋࣱࠧ") : return 272
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨࡘࡌ࡚ࡆࠦࡔࡉࡇࠣࡌࡎ࡚ࡓࣲࠢࠩ") : return 130
    if l111l1_opy_ == l11ll1_opy_ (u"࡙ࠩࡍࡆ࡙ࡁࡕࠢࡊࡓࡑࡌࠧࣳ") : return 125
    if l111l1_opy_ == l11ll1_opy_ (u"࡛ࠪࡆ࡚ࡃࡉࠢࡌࡖࡊࡒࡁࡏࡆࠪࣴ") : return 281
    if l111l1_opy_ == l11ll1_opy_ (u"ࠫ࡝࡞ࡘ࠲ࠩࣵ") : return 314
    if l111l1_opy_ == l11ll1_opy_ (u"ࠬ࡞ࡘ࡙࠴ࣶࠪ") : return 315
    if l111l1_opy_ == l11ll1_opy_ (u"࠭ࡘ࡙࡚࠶ࠫࣷ") : return 316
    if l111l1_opy_ == l11ll1_opy_ (u"࡙࡚࡛ࠧ࠸ࠬࣸ") : return 317
    if l111l1_opy_ == l11ll1_opy_ (u"ࠨ࡚࡛࡜࠺ࣹ࠭") : return 318
    if l111l1_opy_ == l11ll1_opy_ (u"ࠩ࡜ࡉࡘ࡚ࡅࡓࡆࡄ࡝ࠥ࠱࠱ࠨࣺ") : return 282
    if l111l1_opy_ == l11ll1_opy_ (u"ࠪࡑࡔ࡜࠴ࡎࡇࡑ࠵ࠬࣻ") : return 33
def getHDTVRecording(name, title, start, stream):
    l1llll1_opy_ = stream.split(l11ll1_opy_ (u"ࠫࢁ࠭ࣼ"))
    for url in l1llll1_opy_:
        url   = url.split(CLOSE_OTT)[1].rsplit(l11ll1_opy_ (u"ࠬࡀࠧࣽ"))
        l111l_opy_ = url[0]
        if l111l_opy_ == l11ll1_opy_ (u"࠭ࡈࡅࡖ࡙ࠫࣾ"):
            addon = l11ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳ࡮ࡣࡵࡸ࡭ࡻࡢࠨࣿ")
        else:
            addon = l11ll1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥ࠷࠭ऀ")
    dixie.log(l11ll1_opy_ (u"ࠩࡄࡨࡩࡵ࡮ࠡࡋࡇ࠲࠳࠴࠺ࠡࠧࡶࠫँ") % addon)
    Addon  = xbmcaddon.Addon(id=addon)
    path   = Addon.getAddonInfo(l11ll1_opy_ (u"ࠪࡴࡦࡺࡨࠨं"))
    import sys
    sys.path.insert(0, path)
    import api
    l11ll_opy_ = Addon.getSetting(l11ll1_opy_ (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࠬः"))
    l11ll11_opy_  = Addon.getSetting(l11ll1_opy_ (u"ࠬࡹࡥࡳࡸࡨࡶࠬऄ"))
    l1l1l1l_opy_    = l11ll1_opy_ (u"࠭ࠦࡥ࠿࡮ࡳࡩ࡯ࠦࡴ࠿ࠪअ") + l11ll_opy_ + l11ll1_opy_ (u"ࠧࠧࡱࡀࠫआ") + l11ll11_opy_
    import urllib
    l1l1ll1_opy_ = l1lllll_opy_()
    dixie.log(l11ll1_opy_ (u"ࠨࡇࡓࡋ࡙ࠥࡴࡢࡴࡷࠤ࡙࡯࡭ࡦ࠰࠱࠲࠿ࠦࠥࡴࠩइ") % start)
    dixie.log(l11ll1_opy_ (u"ࠩࡒࡪ࡫ࡹࡥࡵࠢ࡬ࡲࠥࡹࡥࡤࡱࡱࡨࡸࡀࠠࠦࡵࠪई") % l1l1ll1_opy_)
    l11l11l_opy_  =  start - datetime.timedelta(seconds=l1l1ll1_opy_)
    dixie.log(l11ll1_opy_ (u"ࠪࡗࡹࡧࡲࡵࠢࡗ࡭ࡲ࡫ࠠࡰࡨࡩࡷࡪࡺ࠺ࠡࠧࡶࠫउ") % l11l11l_opy_)
    l11_opy_ = str(l11l11l_opy_)
    l111l11_opy_  = l11_opy_.split(l11ll1_opy_ (u"ࠫࠥ࠭ऊ"))[0]
    l1l11l1_opy_     = l111ll1_opy_(name)
    if not l1l11l1_opy_:
        dixie.DialogOK(l11ll1_opy_ (u"࡙ࠬ࡯ࡳࡴࡼ࠲ࠬऋ"), l11ll1_opy_ (u"࠭ࡗࡦࠢࡦࡳࡺࡲࡤࠡࡰࡲࡸࠥ࡬ࡩ࡯ࡦࠣࡥࠥࡩࡡࡵࡥ࡫ࡹࡵࠦࡳࡦࡴࡹ࡭ࡨ࡫ࠠࡧࡱࡵࠤࡹ࡮ࡩࡴࠢࡦ࡬ࡦࡴ࡮ࡦ࡮࠱ࠫऌ"), l11ll1_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡵࡴࡼࠤࡦࡴ࡯ࡵࡪࡨࡶࠥࡩࡨࡢࡰࡱࡩࡱ࠴ࠧऍ"))
        return None
    l1l1lll_opy_  = l11_opy_.split(l11ll1_opy_ (u"ࠨ࠯ࠪऎ"), 1)[-1].rsplit(l11ll1_opy_ (u"ࠩ࠽ࠫए"), 1)[0]
    theTime    = urllib.quote_plus(l1l1lll_opy_)
    response   = api.remote_call( l11ll1_opy_ (u"ࠥࡸࡻࡧࡲࡤࡪ࡬ࡺࡪ࠵ࡧࡦࡶࡢࡦࡾࡥࡣࡩࡣࡱࡲࡪࡲ࡟ࡢࡰࡧࡣࡩࡧࡴࡦ࠰ࡳ࡬ࡵࠨऐ") , {l11ll1_opy_ (u"ࠦࡩࡧࡴࡦࠤऑ"): l111l11_opy_, l11ll1_opy_ (u"ࠧ࡯ࡤࠣऒ"): l1l11l1_opy_ } )
    l1ll111_opy_ = response[l11ll1_opy_ (u"ࠨࡢࡰࡦࡼࠦओ")]
    if not l1ll111_opy_:
        dixie.DialogOK(l11ll1_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠴ࠧऔ"), l11ll1_opy_ (u"ࠨ࡙ࡨࠤࡨࡵࡵ࡭ࡦࠣࡲࡴࡺࠠࡧ࡫ࡱࡨࠥࡧࠠࡤࡣࡷࡧ࡭ࡻࡰࠡࡵࡷࡶࡪࡧ࡭ࠡࡨࡲࡶࠥࡺࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰ࠲ࠬक"), l11ll1_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡷࡶࡾࠦࡡࡨࡣ࡬ࡲࠥࡲࡡࡵࡧࡵ࠲ࠬख"))
        return None
    for l11l1ll_opy_ in l1ll111_opy_:
        l11lll_opy_ = l11l1ll_opy_[l11ll1_opy_ (u"ࠥࡴࡱࡵࡴࠣग")]
        if l1l1lll_opy_ in l11lll_opy_:
            dixie.DialogOK(l11ll1_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡴࡸࡡ࡯ࡩࡨࡡࡈࡧࡴࡤࡪ࠰ࡹࡵࠦࡳࡵࡴࡨࡥࡲࠦࡦࡰࡷࡱࡨ࠳ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧघ"), l11ll1_opy_ (u"ࠬࡕ࡮࠮ࡖࡤࡴࡵ࠴ࡔࡗࠢࡺ࡭ࡱࡲࠠ࡯ࡱࡺࠤࡵࡲࡡࡺ࠼ࠣ࡟ࡈࡕࡌࡐࡔࠣࡳࡷࡧ࡮ࡨࡧࡠ࡟ࡇࡣࠥࡴ࡝࠲ࡆࡢࡡ࠯ࡄࡑࡏࡓࡗࡣࠧङ") % (title))
            return l11l1ll_opy_[l11ll1_opy_ (u"ࠨࡵࡳ࡮ࠥच")] + l1l1l1l_opy_
def l111ll1_opy_(name):
    l1l1ll_opy_   = dixie.PROFILE
    l1l_opy_ = os.path.join(l1l1ll_opy_, l11ll1_opy_ (u"ࠧࡪࡰ࡬ࠫछ"), l11ll1_opy_ (u"ࠨࡥࡤࡸࡨ࡮ࡵࡱ࠰ࡷࡼࡹ࠭ज"))
    l1111l1_opy_   = json.load(open(l1l_opy_))
    for channel in l1111l1_opy_:
        if name.upper() == channel[l11ll1_opy_ (u"ࠩࡒࡘ࡙࡜ࠧझ")].upper():
            return channel[l11ll1_opy_ (u"࡙ࠪࡗࡒࠧञ")]
def l1lllll_opy_():
    import time
    gmt = time.gmtime()
    loc = time.localtime()
    GMT = datetime.datetime(*gmt[:6]).isoformat(l11ll1_opy_ (u"ࠫࠥ࠭ट"))
    LOC = datetime.datetime(*loc[:6]).isoformat(l11ll1_opy_ (u"ࠬࠦࠧठ"))
    dixie.log(gmt)
    dixie.log(loc)
    l1_opy_ = dixie.parseTime(GMT)
    l11ll1l_opy_ = dixie.parseTime(LOC)
    dixie.log(l1_opy_)
    dixie.log(l11ll1l_opy_)
    dixie.log(l11ll1_opy_ (u"࠭࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࠣࡓࡋࡌࡓࡆࡖࠣࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࠨड"))
    l1l1ll1_opy_ = l1_opy_ - l11ll1l_opy_
    dixie.log(l1l1ll1_opy_)
    l1l1ll1_opy_ = ((l1l1ll1_opy_.days * 86400) + (l1l1ll1_opy_.seconds + 1800)) / 3600
    dixie.log(l1l1ll1_opy_)
    l1l1ll1_opy_ *= -3600
    dixie.log(l1l1ll1_opy_)
    dixie.log(l11ll1_opy_ (u"ࠧࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࠩढ"))
    return l1l1ll1_opy_