# coding: UTF-8
import sys
l111l1l_opy_ = sys.version_info [0] == 2
l1llll1_opy_ = 2048
l11l1l_opy_ = 7
def l11lll_opy_ (ll_opy_):
	global l111_opy_
	l111l_opy_ = ord (ll_opy_ [-1])
	l111lll_opy_ = ll_opy_ [:-1]
	l1lll_opy_ = l111l_opy_ % len (l111lll_opy_)
	l1ll1_opy_ = l111lll_opy_ [:l1lll_opy_] + l111lll_opy_ [l1lll_opy_:]
	if l111l1l_opy_:
		l1ll1ll_opy_ = unicode () .join ([unichr (ord (char) - l1llll1_opy_ - (l1l1l1_opy_ + l111l_opy_) % l11l1l_opy_) for l1l1l1_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1ll1ll_opy_ = str () .join ([chr (ord (char) - l1llll1_opy_ - (l1l1l1_opy_ + l111l_opy_) % l11l1l_opy_) for l1l1l1_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1ll1ll_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
import mapping
ADDON    = dixie.ADDON
l1ll11_opy_ = dixie.PROFILE
l11l11ll_opy_  = os.path.join(l1ll11_opy_, l11lll_opy_ (u"ࠪ࡭ࡳ࡯ࠧथ"))
l111l1ll_opy_ = l11lll_opy_ (u"ࠫࠬद")
def l11111l1_opy_(i, t1, l111l1l1_opy_=[]):
 t = l111l1ll_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l111l1l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1ll1lll_opy_ = l11111l1_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l1ll1ll1_opy_ = l11111l1_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l11l1l1l_opy_       = l11lll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡫ࡧࡢࡩࡱࡶࡸ࡮ࡴࡧࠨध")
l111ll1l_opy_       = l11lll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡣࡦࡶࡹࠫन")
l1111l11_opy_   = l11lll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡨࡰࡴ࡬ࡾࡴࡴࡩࡱࡶࡹࠫऩ")
l11l1111_opy_     = l11lll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡱࡲࡸࡎࡖࡔࡗࠩप")
l111ll11_opy_      = l11lll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡯ࡨ࡫ࡦ࡯ࡰࡵࡸࠪफ")
l111l11l_opy_  = l11lll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡩࡶࡪ࡫ࡶࡪࡧࡺࠫब")
l111111_opy_  = l11lll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡑࡦࡺࡳࡃࡷ࡬ࡰࡩࡹࡉࡑࡖ࡙ࠫभ")
l1111l11_opy_   = l11lll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡭ࡵࡲࡪࡼࡲࡲ࡮ࡶࡴࡷࠩम")
l1l11lll_opy_  = l11lll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰࡵࡸࡶࡹࡧࡹࠧय")
l1l111l1_opy_      = l11lll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡪࡪࡰࡻࡸࡻ࠸ࠧर")
l1l11l1l_opy_  = l11lll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡱࡲࡸ࡮ࡶࡴࡷࠩऱ")
l1l11l11_opy_   = l11lll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡇࡱࡨࡱ࡫ࡳࡴࠩल")
l1111lll_opy_  = l11lll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡉࡰࡦࡽ࡬ࡦࡵࡶࡘࡻ࠭ळ")
l1l1ll1l_opy_   = l11lll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡱࡦࡾࡩࡸࡧࡥࡸࡻ࠭ऴ")
dexter    = l11lll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸࠨव")
l1lll111_opy_     = l11lll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡜ࡁࡅࡇࡕࠫश")
l1l1l111_opy_ = l11lll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡓࡶࡲࡵࡩࡲࡧࡣࡺࡖ࡙ࠫष")
l111llll_opy_     = l11lll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡮ࡥ࡮ࡸࡻ࠳ࡰ࡭ࡷࡶࠫस")
l1l1l1ll_opy_   = l11lll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡶࡺ࡭ࡸࡺࡥࡥࠩह")
l11l1l11_opy_  = l11lll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡳࡷࡦࡪࡤࡰࡰࠪऺ")
l1ll11ll_opy_  = l11lll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡆࡱࡧࡣ࡬ࡋࡦࡩ࡙࡜ࠧऻ")
l11111ll_opy_    = [l11l1l1l_opy_, l111ll1l_opy_, l1111l11_opy_, l11l1111_opy_, l111ll11_opy_, l111l11l_opy_, l111111_opy_, l1l11lll_opy_, l1l111l1_opy_, l1l11l1l_opy_, l1l11l11_opy_, l1111lll_opy_, l1l1ll1l_opy_, dexter, l1lll111_opy_, l1l1l111_opy_, l111llll_opy_, l1l1l1ll_opy_, l11l1l11_opy_, l1ll11ll_opy_]
def checkAddons():
    for addon in l11111ll_opy_:
        if l1111l1l_opy_(addon):
            try: createINI(addon)
            except: continue
def l1111l1l_opy_(addon):
    if xbmc.getCondVisibility(l11lll_opy_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠦࡵ़ࠬࠫ") % addon) == 1:
        dixie.log(l11lll_opy_ (u"࠭࠽࠾࠿ࡀࠤࡦࡪࡤࡰࡰࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦ࠽࠾࠿ࡀࠫऽ"))
        dixie.log(addon)
        return True
    return False
def createINI(addon):
    HOME  = dixie.PROFILE
    iPATH = os.path.join(HOME, l11lll_opy_ (u"ࠧࡪࡰ࡬ࠫा"))
    l11ll11l_opy_  = str(addon).split(l11lll_opy_ (u"ࠨ࠰ࠪि"))[2] + l11lll_opy_ (u"ࠩ࠱࡭ࡳ࡯ࠧी")
    l1l1111l_opy_   = os.path.join(iPATH, l11ll11l_opy_)
    l1l1lll1_opy_   = os.path.join(iPATH, l11lll_opy_ (u"ࠪࡱࡦࡶࡰࡪࡰࡪࡷ࠳ࡰࡳࡰࡰࠪु"))
    LABELFILE = os.path.join(iPATH, l11lll_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࡶ࠲࡯ࡹ࡯࡯ࠩू"))
    l1l1llll_opy_  = json.load(open(l1l1lll1_opy_))
    labelmaps = json.load(open(LABELFILE))
    response = l11111l_opy_(addon)
    l1111l1_opy_ = response[l11lll_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬृ")][l11lll_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬॄ")]
    l1l111ll_opy_  = l11lll_opy_ (u"ࠧ࡜ࠩॅ") + addon + l11lll_opy_ (u"ࠨ࡟࡟ࡲࠬॆ")
    l1lll11l_opy_  =  file(l1l1111l_opy_, l11lll_opy_ (u"ࠩࡺࠫे"))
    l1lll11l_opy_.write(l1l111ll_opy_)
    l11llll1_opy_ = []
    for channel in l1111l1_opy_:
        l1ll1111_opy_ = l1ll11l1_opy_(addon)
        l1llll11_opy_  = channel[l11lll_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩै")].split(l11lll_opy_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ॉ"), 1)[0]
        if addon == dexter:
            l1llll11_opy_ = l1llll11_opy_.split(l11lll_opy_ (u"ࠬࠦࠫࠡࠩॊ"), 1)[0]
        if addon == l11l1111_opy_:
            l1llll11_opy_ = l1llll11_opy_.split(l11lll_opy_ (u"࠭ࠠ࠮ࠢࠪो"), 1)[0]
        l11l1lll_opy_  = l11ll1ll_opy_(l1llll11_opy_)
        l1lll1l1_opy_  = l111l111_opy_(labelmaps, l1l1llll_opy_, l1llll11_opy_)
        stream  = l1ll1111_opy_ + l11l1lll_opy_
        l1ll1l1l_opy_ = l1lll1l1_opy_  + l11lll_opy_ (u"ࠧ࠾ࠩौ") + stream
        if l1ll1l1l_opy_ not in l11llll1_opy_:
            l11llll1_opy_.append(l1ll1l1l_opy_)
    l11llll1_opy_.sort()
    for item in l11llll1_opy_:
        l1lll11l_opy_.write(l11lll_opy_ (u"ࠣࠧࡶࡠࡳࠨ्") % item)
    l1lll11l_opy_.close()
def l11ll1ll_opy_(l1llll11_opy_):
    l1111ll1_opy_ = mapping.cleanLabel(l1llll11_opy_)
    l11l1lll_opy_ = mapping.cleanStreamLabel(l1111ll1_opy_)
    return l11l1lll_opy_
def l111l111_opy_(labelmaps, l1l1llll_opy_, l1llll11_opy_):
    l1l1ll_opy_    = mapping.cleanLabel(l1llll11_opy_)
    l1111ll1_opy_ = mapping.mapLabel(labelmaps, l1l1ll_opy_)
    l1lll1l1_opy_ = mapping.cleanPrefix(l1111ll1_opy_)
    return mapping.mapChannelName(l1l1llll_opy_, l1lll1l1_opy_)
def l1llllll_opy_(addon, file):
    l1l1ll_opy_ = file[l11lll_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨॎ")].split(l11lll_opy_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬॏ"), 1)[0]
    l1l1ll_opy_ = l1l1ll_opy_.split(l11lll_opy_ (u"ࠫ࠰࠭ॐ"), 1)[0]
    l1l1ll_opy_ = mapping.cleanLabel(l1l1ll_opy_)
    return l1l1ll_opy_
def l1ll11l1_opy_(addon):
    if addon == l11l1l1l_opy_:
        return l11lll_opy_ (u"ࠬࡌࡁࡃ࠼ࠪ॑")
    if addon == l111ll1l_opy_:
        return l11lll_opy_ (u"࠭ࡁࡄࡇ࠽॒ࠫ")
    if addon == l1111l11_opy_:
        return l11lll_opy_ (u"ࠧࡉࡑࡕࡍ࡟ࡀࠧ॓")
    if addon == l11l1111_opy_:
        return l11lll_opy_ (u"ࠨࡔࡒࡓ࡙࠸࠺ࠨ॔")
    if addon == l111ll11_opy_:
        return l11lll_opy_ (u"ࠩࡐࡉࡌࡇ࠺ࠨॕ")
    if addon == l111l11l_opy_:
        return l11lll_opy_ (u"ࠪࡊࡗࡋࡅ࠻ࠩॖ")
    if addon == l111111_opy_:
        return l11lll_opy_ (u"ࠫࡒࡇࡔࡔ࠼ࠪॗ")
    if addon == l1l11lll_opy_:
        return l11lll_opy_ (u"ࠬࡏࡐࡕࡕ࠽ࠫक़")
    if addon == l1l111l1_opy_:
        return l11lll_opy_ (u"࠭ࡊࡊࡐ࡛࠶࠿࠭ख़")
    if addon == l1l11l1l_opy_:
        return l11lll_opy_ (u"ࠧࡓࡑࡒࡘ࠿࠭ग़")
    if addon == l1l11l11_opy_:
        return l11lll_opy_ (u"ࠨࡇࡑࡈ࠿࠭ज़")
    if addon == l1111lll_opy_:
        return l11lll_opy_ (u"ࠩࡉࡐࡆࡀࠧड़")
    if addon == l1l1ll1l_opy_:
        return l11lll_opy_ (u"ࠪࡑࡆ࡞ࡉ࠻ࠩढ़")
    if addon == dexter:
        return l11lll_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡇ࠾ࠬफ़")
    if addon == l1lll111_opy_:
        return l11lll_opy_ (u"ࠬ࡜ࡄࡓࡖ࡙࠾ࠬय़")
    if addon == l1l1l111_opy_:
        return l11lll_opy_ (u"࠭ࡓࡑࡔࡐ࠾ࠬॠ")
    if addon == l111llll_opy_:
        return l11lll_opy_ (u"ࠧࡎࡅࡎࡘ࡛ࡀࠧॡ")
    if addon == l1l1l1ll_opy_:
        return l11lll_opy_ (u"ࠨࡖ࡚ࡍࡘ࡚࠺ࠨॢ")
    if addon == l11l1l11_opy_:
        return l11lll_opy_ (u"ࠩࡓࡖࡊ࡙ࡔ࠻ࠩॣ")
    if addon == l1ll11ll_opy_:
        return l11lll_opy_ (u"ࠪࡆࡑࡑࡉ࠻ࠩ।")
def getURL(url):
    if url.startswith(l11lll_opy_ (u"ࠫࡋࡇࡂࠨ॥")):
        return l1lllll1_opy_(url, l11l1l1l_opy_)
    if url.startswith(l11lll_opy_ (u"ࠬࡇࡃࡆࠩ०")):
        return l1lllll1_opy_(url, l111ll1l_opy_)
    if url.startswith(l11lll_opy_ (u"࠭ࡈࡐࡔࡌ࡞ࠬ१")):
        return l1lllll1_opy_(url, l1111l11_opy_)
    if url.startswith(l11lll_opy_ (u"ࠧࡓࡑࡒࡘ࠷࠭२")):
        return l1lllll1_opy_(url, l11l1111_opy_)
    if url.startswith(l11lll_opy_ (u"ࠨࡏࡈࡋࡆ࠭३")):
        return l1lllll1_opy_(url, l111ll11_opy_)
    if url.startswith(l11lll_opy_ (u"ࠩࡉࡖࡊࡋࠧ४")):
        return l1lllll1_opy_(url, l111l11l_opy_)
    if url.startswith(l11lll_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡅࡏ࡙࠿࠭५")):
        url = url.replace(l11lll_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡆࡐ࡚ࡀࠧ६"), l11lll_opy_ (u"ࠬ࠭७")).replace(l11lll_opy_ (u"࠭࠭࠮ࡷࡶࡩࡷ࠳ࡡࡨࡧࡱࡸࠬ८"), l11lll_opy_ (u"ࠧࡽࡷࡶࡩࡷ࠳ࡡࡨࡧࡱࡸࠬ९"))
        return url
    if url.startswith(l11lll_opy_ (u"ࠨࡏࡄࡘࡘ࠭॰")):
        return l1lllll1_opy_(url, l111111_opy_)
    if url.startswith(l11lll_opy_ (u"ࠩࡌࡔ࡙࡙ࠧॱ")):
        return l1lllll1_opy_(url, l1l11lll_opy_)
    if url.startswith(l11lll_opy_ (u"ࠪࡎࡎࡔࡘ࠳ࠩॲ")):
        return l1lllll1_opy_(url, l1l111l1_opy_)
    if url.startswith(l11lll_opy_ (u"ࠫࡗࡕࡏࡕࠩॳ")):
        return l1lllll1_opy_(url, l1l11l1l_opy_)
    if url.startswith(l11lll_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡈࠬॴ")):
        return l1lllll1_opy_(url, dexter)
    if url.startswith(l11lll_opy_ (u"࠭ࡆࡍࡃࠪॵ")):
        return l1lllll1_opy_(url, l1111lll_opy_)
    if url.startswith(l11lll_opy_ (u"ࠧࡎࡃ࡛ࡍࠬॶ")):
        return l1lllll1_opy_(url, l1l1ll1l_opy_)
    if url.startswith(l11lll_opy_ (u"ࠨࡇࡑࡈࠬॷ")):
        return l1lllll1_opy_(url, l1l11l11_opy_)
    if url.startswith(l11lll_opy_ (u"࡙ࠩࡈࡗ࡚ࡖࠨॸ")):
        return l1lllll1_opy_(url, l1lll111_opy_)
    if url.startswith(l11lll_opy_ (u"ࠪࡗࡕࡘࡍࠨॹ")):
        return l1lllll1_opy_(url, l1l1l111_opy_)
    if url.startswith(l11lll_opy_ (u"ࠫࡒࡉࡋࡕࡘࠪॺ")):
        return l1lllll1_opy_(url, l111llll_opy_)
    if url.startswith(l11lll_opy_ (u"࡚ࠬࡗࡊࡕࡗࠫॻ")):
        return l1lllll1_opy_(url, l1l1l1ll_opy_)
    if url.startswith(l11lll_opy_ (u"࠭ࡐࡓࡇࡖࡘࠬॼ")):
        return l1lllll1_opy_(url, l11l1l11_opy_)
    if url.startswith(l11lll_opy_ (u"ࠧࡃࡎࡎࡍࠬॽ")):
        return l1lllll1_opy_(url, l1ll11ll_opy_)
    response  = l1llll1l_opy_(url)
    l11lllll_opy_ = url.split(l11lll_opy_ (u"ࠨ࠼ࠪॾ"), 1)[-1]
    try:
        result = response[l11lll_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩॿ")]
        l111l1_opy_  = result[l11lll_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩঀ")]
    except Exception as e:
        l11l111l_opy_(e)
        return None
    for file in l111l1_opy_:
        l1llll11_opy_  = file[l11lll_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪঁ")].split(l11lll_opy_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧং"), 1)[0]
        l1l1ll1_opy_  = l1llll11_opy_.split(l11lll_opy_ (u"࠭ࠫࠨঃ"), 1)[0]
        l11l11l1_opy_ = mapping.cleanLabel(l1l1ll1_opy_)
        try:
            if l11lllll_opy_ == l11l11l1_opy_:
                return file[l11lll_opy_ (u"ࠧࡧ࡫࡯ࡩࠬ঄")]
        except:
            if (l11lllll_opy_ in l11l11l1_opy_) or (l11l11l1_opy_ in l11lllll_opy_):
                return file[l11lll_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭অ")]
    return None
def l1lllll1_opy_(url, addon):
    PATH = l1lll1ll_opy_(addon)
    try:
        response = json.load(open(PATH))
    except:
        response = l11111l_opy_(addon)
    l1lllll_opy_      = url.split(l11lll_opy_ (u"ࠩ࠽ࠫআ"), 1)[-1]
    stream    = l1lllll_opy_.split(l11lll_opy_ (u"ࠪࠤࡠ࠭ই"), 1)[0]
    l11lllll_opy_ = mapping.cleanLabel(stream)
    l111l1_opy_  = response[l11lll_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫঈ")][l11lll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫউ")]
    for file in l111l1_opy_:
        l1llll11_opy_  = file[l11lll_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬঊ")].split(l11lll_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩঋ"), 1)[0]
        if addon == dexter:
            l1llll11_opy_ = l1llll11_opy_.split(l11lll_opy_ (u"ࠨࠢ࠮ࠤࠬঌ"), 1)[0]
        if addon == l11l1111_opy_:
            l1llll11_opy_ = l1llll11_opy_.split(l11lll_opy_ (u"ࠩࠣ࠱ࠥ࠭঍"), 1)[0]
        l11l11l1_opy_ = l11ll1ll_opy_(l1llll11_opy_)
        try:
            if l11lllll_opy_ == l11l11l1_opy_:
                return file[l11lll_opy_ (u"ࠪࡪ࡮ࡲࡥࠨ঎")]
        except:
            if (l11lllll_opy_ in l11l11l1_opy_) or (l11l11l1_opy_ in l11lllll_opy_):
                return file[l11lll_opy_ (u"ࠫ࡫࡯࡬ࡦࠩএ")]
            if l11lll_opy_ (u"࡛ࠬࡓࡂ࠱ࡆࡅ࠿࠭ঐ") in l11l11l1_opy_:
                l11lll11_opy_ = l11l11l1_opy_.replace(l11lll_opy_ (u"࠭ࡕࡔࡃ࠲ࡇࡆࡀࠧ঑"), l11lll_opy_ (u"ࠧࡖࡕࡄ࠾ࠬ঒"))
                if dixie.fuzzyMatch(l11lllll_opy_, l11lll11_opy_):
                    return file[l11lll_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ও")]
    return None
def l11111l_opy_(addon):
    PATH  = l1lll1ll_opy_(addon)
    if addon == l1lll111_opy_:
        query = l11lll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡚ࡆࡊࡅࡓ࠱࡯࡭ࡻ࡫ࡴࡷ࠱ࡤࡰࡱ࠵ࠧঔ")
    elif addon == l111l11l_opy_:
        query = l11lll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡫ࡸࡥࡦࡸ࡬ࡩࡼ࠵࠿ࡶࡴ࡯ࡁࡺࡸ࡬ࠧ࡯ࡲࡨࡪࡃ࠵ࠧࡰࡤࡱࡪࡃࡌࡪࡸࡨ࠯࡙࡜ࠧক")
    else:
        query = l11ll111_opy_(addon)
    try:
        return json.load(open(PATH))
    except:
        content = doJSON(query)
        return l1l11ll1_opy_(PATH, addon, content)
def l1l11ll1_opy_(PATH, addon, content):
    json.dump(content, open(PATH,l11lll_opy_ (u"ࠫࡼ࠭খ")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    l1l111l_opy_  = (l11lll_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࠦࡵࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨগ") % query)
    response = xbmc.executeJSONRPC(l1l111l_opy_)
    content  = json.loads(response)
    return content
def l1lll1ll_opy_(addon):
    if addon == l11l1l1l_opy_:
        return os.path.join(dixie.PROFILE, l11lll_opy_ (u"࠭ࡦࡢࡤࡷࡩࡲࡶࠧঘ"))
    if addon == l111ll1l_opy_:
        return os.path.join(dixie.PROFILE, l11lll_opy_ (u"ࠧࡢࡥࡨࡸࡪࡳࡰࠨঙ"))
    if addon == l1111l11_opy_:
        return os.path.join(dixie.PROFILE, l11lll_opy_ (u"ࠨࡪࡲࡶࡹ࡫࡭ࡱࠩচ"))
    if addon == l11l1111_opy_:
        return os.path.join(dixie.PROFILE, l11lll_opy_ (u"ࠩࡵࡳ࠷ࡺࡥ࡮ࡲࠪছ"))
    if addon == l111ll11_opy_:
        return os.path.join(dixie.PROFILE, l11lll_opy_ (u"ࠪࡱࡪ࡭ࡡࡵ࡯ࡳࠫজ"))
    if addon == l111111_opy_:
        return os.path.join(dixie.PROFILE, l11lll_opy_ (u"ࠫࡲࡧࡴࡴࡶࡰࡴࠬঝ"))
    if addon == l111l11l_opy_:
        return os.path.join(dixie.PROFILE, l11lll_opy_ (u"ࠬ࡬ࡲࡦࡧࡷࡱࡵ࠭ঞ"))
    if addon == l1l11lll_opy_:
        return os.path.join(dixie.PROFILE, l11lll_opy_ (u"࠭ࡩࡱࡶࡶࡸࡲࡶࠧট"))
    if addon == l1l111l1_opy_:
        return os.path.join(dixie.PROFILE, l11lll_opy_ (u"ࠧ࡫࠴ࡷࡩࡲࡶࠧঠ"))
    if addon == l1l11l1l_opy_:
        return os.path.join(dixie.PROFILE, l11lll_opy_ (u"ࠨࡴࡲࡸࡪࡳࡰࠨড"))
    if addon == l1l11l11_opy_:
        return os.path.join(dixie.PROFILE, l11lll_opy_ (u"ࠩࡨࡸࡪࡳࡰࠨঢ"))
    if addon == l1111lll_opy_:
        return os.path.join(dixie.PROFILE, l11lll_opy_ (u"ࠪࡪࡹ࡫࡭ࡱࠩণ"))
    if addon == l1l1ll1l_opy_:
        return os.path.join(dixie.PROFILE, l11lll_opy_ (u"ࠫࡲࡧࡸࡵࡧࡰࡴࠬত"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l11lll_opy_ (u"ࠬࡪࡴࡦ࡯ࡳࠫথ"))
    if addon == l1lll111_opy_:
        return os.path.join(dixie.PROFILE, l11lll_opy_ (u"࠭ࡶࡥࡶࡨࡱࡵ࠭দ"))
    if addon == l1l1l111_opy_:
        return os.path.join(dixie.PROFILE, l11lll_opy_ (u"ࠧࡴࡲࡵࡸࡪࡳࡰࠨধ"))
    if addon == l111llll_opy_:
        return os.path.join(dixie.PROFILE, l11lll_opy_ (u"ࠨ࡯ࡦ࡯ࡹ࡫࡭ࡱࠩন"))
    if addon == l1l1l1ll_opy_:
        return os.path.join(dixie.PROFILE, l11lll_opy_ (u"ࠩࡷࡻ࡮ࡺࡥ࡮ࡲࠪ঩"))
    if addon == l11l1l11_opy_:
        return os.path.join(dixie.PROFILE, l11lll_opy_ (u"ࠪࡴࡷ࡫ࡳࡵࡧࡰࡴࠬপ"))
    if addon == l1ll11ll_opy_:
        return os.path.join(dixie.PROFILE, l11lll_opy_ (u"ࠫࡧࡲ࡫ࡪࡶࡨࡱࡵ࠭ফ"))
def l11ll111_opy_(addon):
    query = l11lll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨব") + addon
    response = doJSON(query)
    l111l1_opy_    = response[l11lll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ভ")][l11lll_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ম")]
    for file in l111l1_opy_:
        l11ll1l1_opy_ = file[l11lll_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧয")]
        l1l1ll_opy_ = mapping.cleanLabel(l11ll1l1_opy_)
        l1l1ll_opy_ = l1l1ll_opy_.upper()
        if (l1l1ll_opy_ == l11lll_opy_ (u"ࠩࡏࡍ࡛ࡋࠠࡊࡒࡗ࡚ࠬর")) or (l1l1ll_opy_ == l11lll_opy_ (u"ࠪࡐࡎ࡜ࡅࠡࡖ࡙ࠫ঱")) or (l1l1ll_opy_ == l11lll_opy_ (u"ࠫࡑࡏࡖࡆࠢࡆࡌࡆࡔࡎࡆࡎࡖࠫল")) or (l1l1ll_opy_ == l11lll_opy_ (u"ࠬࡒࡉࡗࡇࠪ঳")) or (l1l1ll_opy_ == l11lll_opy_ (u"࠭ࡅࡏࡆࡏࡉࡘ࡙ࠠࡎࡇࡇࡍࡆ࠭঴")) or (l1l1ll_opy_ == l11lll_opy_ (u"ࠧࡇࡎࡄ࡛ࡑࡋࡓࡔࡖ࡙ࠫ঵")) or (l1l1ll_opy_ == l11lll_opy_ (u"ࠨࡏࡄ࡜ࡎ࡝ࡅࡃࠢࡗ࡚ࠬশ")) or (l1l1ll_opy_ == l11lll_opy_ (u"ࠩࡅࡐࡆࡉࡋࡊࡅࡈࠤ࡙࡜ࠧষ")) or (l1l1ll_opy_ == l11lll_opy_ (u"ࠪࡌࡔࡘࡉ࡛ࡑࡑࠤࡎࡖࡔࡗࠩস")) or (l1l1ll_opy_ == l11lll_opy_ (u"ࠫࡋࡇࡂࠡࡋࡓࡘ࡛࠭হ")):
            livetv = file[l11lll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪ঺")]
            return l1ll111l_opy_(livetv)
def l1ll111l_opy_(livetv):
    response = doJSON(livetv)
    l111l1_opy_    = response[l11lll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭঻")][l11lll_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ়࠭")]
    for file in l111l1_opy_:
        l11ll1l1_opy_ = file[l11lll_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧঽ")]
        l1l1ll_opy_ = mapping.cleanLabel(l11ll1l1_opy_)
        l1l1ll_opy_ = l1l1ll_opy_.upper()
        if l1l1ll_opy_ == l11lll_opy_ (u"ࠩࡄࡐࡑ࠭া"):
            return file[l11lll_opy_ (u"ࠪࡪ࡮ࡲࡥࠨি")]
def l1l11111_opy_(l11lll1l_opy_):
    items = []
    _11l1ll1_opy_(l11lll1l_opy_, items)
    return items
def _11l1ll1_opy_(l11lll1l_opy_, items):
    response = doJSON(l11lll1l_opy_)
    if response[l11lll_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫী")].has_key(l11lll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫু")):
        result = response[l11lll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ূ")][l11lll_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ৃ")]
        for item in result:
            if item[l11lll_opy_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪৄ")] == l11lll_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧ৅"):
                l1l1ll_opy_ = mapping.cleanLabel(item[l11lll_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩ৆")])
                items.append(item)
            elif item[l11lll_opy_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭ে")] == l11lll_opy_ (u"ࠬࡪࡩࡳࡧࡦࡸࡴࡸࡹࠨৈ"):
                l1l1ll_opy_ = mapping.cleanLabel(item[l11lll_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬ৉")])
                l111lll1_opy_  = item[l11lll_opy_ (u"ࠧࡧ࡫࡯ࡩࠬ৊")]
                dixie.log(item)
                dixie.log(l111lll1_opy_)
                _11l1ll1_opy_(l111lll1_opy_, items)
def l1llll1l_opy_(url):
    if url.startswith(l11lll_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠺ࠨো")):
        l1l111l_opy_ = (l11lll_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡨࡢࡤ࡫ࡳࡰࡦࡿࡥࡳ࠱ࡂࡹࡷࡲ࠽ࡶࡴ࡯ࠪࡲࡵࡤࡦ࠿࠵ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡻ࡫ࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠩࡍࡕࡏࡄ࠾ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧৌ"))
    if url.startswith(l11lll_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠴࠽্ࠫ")):
        l1l111l_opy_ = (l11lll_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺ࠳ࡄࡻࡲ࡭࠿ࡸࡶࡱࠬ࡭ࡰࡦࡨࡁ࠶࠶࠱ࠧࡰࡤࡱࡪࡃࡗࡢࡶࡦ࡬࠰ࡒࡩࡷࡧࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࡂࠬࡳࡶࡤࡷ࡭ࡹࡲࡥࡴࡡࡸࡶࡱࡃࠦ࡭ࡱࡪ࡫ࡪࡪ࡟ࡪࡰࡀࡊࡦࡲࡳࡦࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧৎ"))
    if url.startswith(l11lll_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖ࠿࠭৏")):
        l1l111l_opy_ = (l11lll_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠵࠿ࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠫࡲ࡯ࡨࡩࡨࡨࡤ࡯࡮࠾ࡈࡤࡰࡸ࡫ࠦ࡮ࡱࡧࡩࡂ࠷࠱࠴ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡶࡸࡪࡴࠥ࠳࠲ࡏ࡭ࡻ࡫ࠦࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡵࡢࡹࡷࡲࠦࡶࡴ࡯ࡁࡺࡸ࡬ࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭৐"))
    if url.startswith(l11lll_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡏࡔࡗ࠼ࠪ৑")):
        l1l111l_opy_ = (l11lll_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡺࡶࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭৒"))
    if url.startswith(l11lll_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪ৓")):
        l1l111l_opy_ = (l11lll_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡤࡦࡺ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡦࡲ࡬ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠦࡵ࡫ࡷࡰࡪࡃࠥ࠶ࡤࡆࡓࡑࡕࡒࠦ࠴࠳ࡻ࡭࡯ࡴࡦࠧ࠸ࡨࡆࡲ࡬ࠦ࠴࠳ࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠪ࠻ࡢࠦ࠴ࡩࡇࡔࡒࡏࡓࠧ࠸ࡨࠫࡻࡲ࡭ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧ৔"))
    if url.startswith(l11lll_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡕࡆ࠿࠭৕")):
        l1l111l_opy_ = (l11lll_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡨࡦࡴࡵࡴ࠰ࡁࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠦࡧࡣࡱࡥࡷࡺ࠽ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡳ࡯ࡥࡧࡀ࠻ࠫࡶࡩ࡭࡮ࡲࡻࡂࡒࡩࡷࡧࠨ࠶࠵࡙ࡴࡳࡧࡤࡱࡸࠬࡵࡳ࡮ࡀࡶࡦࡴࡤࡰ࡯ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ৖"))
    try:
        dixie.ShowBusy()
        addon =  l1l111l_opy_.split(l11lll_opy_ (u"࠭࠯࠰ࠩৗ"), 1)[-1].split(l11lll_opy_ (u"ࠧ࠰ࠩ৘"), 1)[0]
        login = l11lll_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭৙") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1l111l_opy_)
        dixie.log(response)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l11l111l_opy_(e)
        return {l11lll_opy_ (u"ࠩࡈࡶࡷࡵࡲࠨ৚") : l11lll_opy_ (u"ࠪࡔࡱࡻࡧࡪࡰࠣࡉࡷࡸ࡯ࡳࠩ৛")}
def l1l1l11l_opy_():
    modules = map(__import__, [l11111l1_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1ll1lll_opy_)):
        return l11lll_opy_ (u"࡙ࠫࡸࡵࡦࠩড়")
    if len(modules[-1].Window(10**4).getProperty(l1ll1ll1_opy_)):
        return l11lll_opy_ (u"࡚ࠬࡲࡶࡧࠪঢ়")
    return l11lll_opy_ (u"࠭ࡆࡢ࡮ࡶࡩࠬ৞")
def l11l111l_opy_(e):
    l1l1l1l1_opy_ = l11lll_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠲ࠠࡢࡰࠣࡩࡷࡸ࡯ࡳࠢࡲࡧࡨࡻࡲࡦࡦ࠽ࠤࡏ࡙ࡏࡏࠢࡈࡶࡷࡵࡲ࠻ࠢࠨࡷࠬয়")  %e
    l1ll1l11_opy_ = l11lll_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡴࡨ࠱ࡱ࡯࡮࡬ࠢࡷ࡬࡮ࡹࠠࡤࡪࡤࡲࡳ࡫࡬ࠡࡣࡱࡨࠥࡺࡲࡺࠢࡤ࡫ࡦ࡯࡮࠯ࠩৠ")
    l1l1ll11_opy_ = l11lll_opy_ (u"ࠩࡘࡷࡪࡀࠠࡄࡱࡱࡸࡪࡾࡴࠡࡏࡨࡲࡺࠦ࠽࠿ࠢࡕࡩࡲࡵࡶࡦࠢࡖࡸࡷ࡫ࡡ࡮ࠩৡ")
    dixie.log(e)
    dixie.DialogOK(l1l1l1l1_opy_, l1ll1l11_opy_, l1l1ll11_opy_)
if __name__ == l11lll_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬৢ"):
    checkAddons()