# coding: UTF-8
import sys
l111l_opy_ = sys.version_info [0] == 2
l1l11ll_opy_ = 2048
l1ll1l_opy_ = 7
def l1lllll_opy_ (ll_opy_):
	global l1llll_opy_
	l1111_opy_ = ord (ll_opy_ [-1])
	l1ll11l1_opy_ = ll_opy_ [:-1]
	l111lll_opy_ = l1111_opy_ % len (l1ll11l1_opy_)
	l1ll1_opy_ = l1ll11l1_opy_ [:l111lll_opy_] + l1ll11l1_opy_ [l111lll_opy_:]
	if l111l_opy_:
		l11ll1l_opy_ = unicode () .join ([unichr (ord (char) - l1l11ll_opy_ - (l111ll_opy_ + l1111_opy_) % l1ll1l_opy_) for l111ll_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l11ll1l_opy_ = str () .join ([chr (ord (char) - l1l11ll_opy_ - (l111ll_opy_ + l1111_opy_) % l1ll1l_opy_) for l111ll_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l11ll1l_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l11l11lll_opy_     = l1lllll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡮ࡵࡸࠪঙ")
l11l111l1_opy_  = l1lllll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡸ࡮࡬ࡴࡹࡼࠧচ")
l11ll11ll_opy_     = l1lllll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡷ࡮ࡸࡺࡸ࡫ࠨছ")
locked  = l1lllll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡯ࡳࡨࡱࡥࡥࡶࡹࠫজ")
l111lll1l_opy_      = l1lllll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡹࡱࡺࡩ࡮ࡣࡷࡩࡲࡧ࡮ࡪࡣࠪঝ")
l11ll11_opy_    = l1lllll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡱ࡯ࡵࡹ࠰ࡷࡺࠬঞ")
l11l11l1l_opy_     = l1lllll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡊࡃࡔࡲࡲࡶࡹࡹࠧট")
l11ll111l_opy_  = l1lllll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡦࡤࡲࡳࡹ࠭ঠ")
l11l1ll11_opy_     = l1lllll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡤ࡮ࡸ࡭ࡵࡺࡶࠨড")
l11l1llll_opy_ = l1lllll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡷ࡮ࡸࡻ࠺ࡥࡹࡲࡤࡸࡸ࠴ࡣࡰ࡯ࠪঢ")
l1l1lll1_opy_ = [l11l11lll_opy_, locked, l11ll11_opy_, l11l111l1_opy_, l11l1llll_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1lllll_opy_ (u"ࠪ࡭ࡳ࡯ࠧণ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l11l11111_opy_ = l1lllll_opy_ (u"ࠫࠬত")
def l111ll1l1_opy_(i, t1, l111lllll_opy_=[]):
 t = l11l11111_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l111lllll_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11lll1l1_opy_ = l111ll1l1_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11lll11l_opy_ = l111ll1l1_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1l1lll1_opy_:
        if l11l1l1l1_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l11l1l1l1_opy_(addon):
    if xbmc.getCondVisibility(l1lllll_opy_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠦࡵࠬࠫথ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l11llllll_opy_ = str(addon).split(l1lllll_opy_ (u"࠭࠮ࠨদ"))[2] + l1lllll_opy_ (u"ࠧ࠯࡫ࡱ࡭ࠬধ")
    l111ll1ll_opy_  = os.path.join(PATH, l11llllll_opy_)
    try:
        l1111ll_opy_ = l1l11111l_opy_(addon)
    except KeyError:
        dixie.log(l1lllll_opy_ (u"ࠨ࠯࠰࠱࠲࠳ࠠࡌࡧࡼࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥ࡭ࡥࡵࡈ࡬ࡰࡪࡹࠠ࠮࠯࠰࠱࠲ࠦࠧন") + addon)
        result = {l1lllll_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࡴࠩ঩"): [{l1lllll_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭প"): l1lllll_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࠪফ"), l1lllll_opy_ (u"ࡺ࠭ࡴࡺࡲࡨࠫব"): l1lllll_opy_ (u"ࡻࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨভ"), l1lllll_opy_ (u"ࡵࠨࡨ࡬ࡰࡪ࠭ম"): l1lllll_opy_ (u"ࡶࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡽࡾࠧয"), l1lllll_opy_ (u"ࡷࠪࡰࡦࡨࡥ࡭ࠩর"): l1lllll_opy_ (u"ࡸࠫࡓࡕࠠࡄࡊࡄࡒࡓࡋࡌࡔࠩ঱")}], l1lllll_opy_ (u"ࡹࠬࡲࡩ࡮࡫ࡷࡷࠬল"):{l1lllll_opy_ (u"ࡺ࠭ࡳࡵࡣࡵࡸࠬ঳"): 0, l1lllll_opy_ (u"ࡻࠧࡵࡱࡷࡥࡱ࠭঴"): 1, l1lllll_opy_ (u"ࡵࠨࡧࡱࡨࠬ঵"): 1}}
    l11l1l1ll_opy_  = l1lllll_opy_ (u"ࠨ࡝ࠪশ") + addon + l1lllll_opy_ (u"ࠩࡠࡠࡳ࠭ষ")
    l11lll1ll_opy_  =  file(l111ll1ll_opy_, l1lllll_opy_ (u"ࠪࡻࠬস"))
    l11lll1ll_opy_.write(l11l1l1ll_opy_)
    l11l1l111_opy_ = []
    for channel in l1111ll_opy_:
        l11ll1l1l_opy_ = dixie.cleanLabel(channel[l1lllll_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪহ")])
        l1ll1ll1_opy_   = dixie.cleanPrefix(l11ll1l1l_opy_)
        l11llll11_opy_ = dixie.mapChannelName(l1ll1ll1_opy_)
        stream   = channel[l1lllll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪ঺")]
        l11lll111_opy_ = l11llll11_opy_ + l1lllll_opy_ (u"࠭࠽ࠨ঻") + stream
        l11l1l111_opy_.append(l11lll111_opy_)
        l11l1l111_opy_.sort()
    for item in l11l1l111_opy_:
        l11lll1ll_opy_.write(l1lllll_opy_ (u"ࠢࠦࡵ࡟ࡲ়ࠧ") % item)
    l11lll1ll_opy_.close()
def l1l11111l_opy_(addon):
    if (addon == l11l11lll_opy_) or (addon == l11l111l1_opy_):
        if xbmcaddon.Addon(addon).getSetting(l1lllll_opy_ (u"ࠨࡩࡨࡲࡷ࡫ࠧঽ")) == l1lllll_opy_ (u"ࠩࡷࡶࡺ࡫ࠧা"):
            xbmcaddon.Addon(addon).setSetting(l1lllll_opy_ (u"ࠪ࡫ࡪࡴࡲࡦࠩি"), l1lllll_opy_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪী"))
            xbmcgui.Window(10000).setProperty(l1lllll_opy_ (u"ࠬࡖࡌࡖࡉࡌࡒࡤࡍࡅࡏࡔࡈࠫু"), l1lllll_opy_ (u"࠭ࡔࡳࡷࡨࠫূ"))
        if xbmcaddon.Addon(addon).getSetting(l1lllll_opy_ (u"ࠧࡵࡸࡪࡹ࡮ࡪࡥࠨৃ")) == l1lllll_opy_ (u"ࠨࡶࡵࡹࡪ࠭ৄ"):
            xbmcaddon.Addon(addon).setSetting(l1lllll_opy_ (u"ࠩࡷࡺ࡬ࡻࡩࡥࡧࠪ৅"), l1lllll_opy_ (u"ࠪࡪࡦࡲࡳࡦࠩ৆"))
            xbmcgui.Window(10000).setProperty(l1lllll_opy_ (u"ࠫࡕࡒࡕࡈࡋࡑࡣ࡙࡜ࡇࡖࡋࡇࡉࠬে"), l1lllll_opy_ (u"࡚ࠬࡲࡶࡧࠪৈ"))
        l1llll1l_opy_  = l1lllll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ৉") + addon
        l11l1lll1_opy_ =  l11llll1l_opy_(addon)
        query   =  l1llll1l_opy_ + l11l1lll1_opy_
        return sendJSON(query, addon)
    return l11l1l11l_opy_(addon)
def l11l1l11l_opy_(addon):
    if addon == l11l1llll_opy_:
        l11l1111l_opy_ = [l1lllll_opy_ (u"ࠧ࠲࠸࠴ࠫ৊"), l1lllll_opy_ (u"ࠨ࠳࠹࠴ࠬো"), l1lllll_opy_ (u"ࠩ࠵࠷࠻࠭ৌ"), l1lllll_opy_ (u"ࠪ࠶࠹࠸্ࠧ"), l1lllll_opy_ (u"ࠫ࠶࠻࠸ࠨৎ"), l1lllll_opy_ (u"ࠬ࠷࠵࠺ࠩ৏")]
    if addon == l11ll11_opy_:
        l11l1111l_opy_ = [l1lllll_opy_ (u"࠭࠵ࠨ৐"), l1lllll_opy_ (u"ࠧ࠲࠲࠹ࠫ৑"), l1lllll_opy_ (u"ࠨ࠶ࠪ৒"), l1lllll_opy_ (u"ࠩ࠵࠺࠸࠭৓"), l1lllll_opy_ (u"ࠪ࠵࠸࠸ࠧ৔")]
    if addon == locked:
        l11l1111l_opy_ = [l1lllll_opy_ (u"ࠫ࠸࠶ࠧ৕"), l1lllll_opy_ (u"ࠬ࠹࠱ࠨ৖"), l1lllll_opy_ (u"࠭࠳࠳ࠩৗ"), l1lllll_opy_ (u"ࠧ࠴࠵ࠪ৘"), l1lllll_opy_ (u"ࠨ࠵࠷ࠫ৙"), l1lllll_opy_ (u"ࠩ࠶࠹ࠬ৚"), l1lllll_opy_ (u"ࠪ࠷࠽࠭৛"), l1lllll_opy_ (u"ࠫ࠹࠶ࠧড়"), l1lllll_opy_ (u"ࠬ࠺࠱ࠨঢ়"), l1lllll_opy_ (u"࠭࠴࠶ࠩ৞"), l1lllll_opy_ (u"ࠧ࠵࠹ࠪয়"), l1lllll_opy_ (u"ࠨ࠶࠼ࠫৠ"), l1lllll_opy_ (u"ࠩ࠸࠶ࠬৡ")]
    if addon == l111lll1l_opy_:
        l11l1111l_opy_ = [l1lllll_opy_ (u"ࠪ࠶࠺࠭ৢ"), l1lllll_opy_ (u"ࠫ࠷࠼ࠧৣ"), l1lllll_opy_ (u"ࠬ࠸࠷ࠨ৤"), l1lllll_opy_ (u"࠭࠲࠺ࠩ৥"), l1lllll_opy_ (u"ࠧ࠴࠲ࠪ০"), l1lllll_opy_ (u"ࠨ࠵࠴ࠫ১"), l1lllll_opy_ (u"ࠩ࠶࠶ࠬ২"), l1lllll_opy_ (u"ࠪ࠷࠺࠭৩"), l1lllll_opy_ (u"ࠫ࠸࠼ࠧ৪"), l1lllll_opy_ (u"ࠬ࠹࠷ࠨ৫"), l1lllll_opy_ (u"࠭࠳࠹ࠩ৬"), l1lllll_opy_ (u"ࠧ࠴࠻ࠪ৭"), l1lllll_opy_ (u"ࠨ࠶࠳ࠫ৮"), l1lllll_opy_ (u"ࠩ࠷࠵ࠬ৯"), l1lllll_opy_ (u"ࠪ࠸࠽࠭ৰ"), l1lllll_opy_ (u"ࠫ࠹࠿ࠧৱ"), l1lllll_opy_ (u"ࠬ࠻࠰ࠨ৲"), l1lllll_opy_ (u"࠭࠵࠳ࠩ৳"), l1lllll_opy_ (u"ࠧ࠶࠶ࠪ৴"), l1lllll_opy_ (u"ࠨ࠷࠹ࠫ৵"), l1lllll_opy_ (u"ࠩ࠸࠻ࠬ৶"), l1lllll_opy_ (u"ࠪ࠹࠽࠭৷"), l1lllll_opy_ (u"ࠫ࠺࠿ࠧ৸"), l1lllll_opy_ (u"ࠬ࠼࠰ࠨ৹"), l1lllll_opy_ (u"࠭࠶࠲ࠩ৺"), l1lllll_opy_ (u"ࠧ࠷࠴ࠪ৻"), l1lllll_opy_ (u"ࠨ࠸࠶ࠫৼ"), l1lllll_opy_ (u"ࠩ࠹࠹ࠬ৽"), l1lllll_opy_ (u"ࠪ࠺࠻࠭৾"), l1lllll_opy_ (u"ࠫ࠻࠽ࠧ৿"), l1lllll_opy_ (u"ࠬ࠼࠹ࠨ਀"), l1lllll_opy_ (u"࠭࠷࠱ࠩਁ"), l1lllll_opy_ (u"ࠧ࠸࠶ࠪਂ"), l1lllll_opy_ (u"ࠨ࠹࠺ࠫਃ"), l1lllll_opy_ (u"ࠩ࠺࠼ࠬ਄"), l1lllll_opy_ (u"ࠪ࠼࠵࠭ਅ"), l1lllll_opy_ (u"ࠫ࠽࠷ࠧਆ")]
    login = l1lllll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠦࡵ࠲ࠫਇ") % addon
    sendJSON(login, addon)
    l1l1lll_opy_ = []
    for l11ll1l11_opy_ in l11l1111l_opy_:
        if (addon == l11l1llll_opy_) or (addon == l11ll11_opy_):
            query = l1lllll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶ࠳ࡄࡳ࡯ࡥࡧࡢ࡭ࡩࡃࡣࡩࡣࡱࡲࡪࡲࡳࠧ࡯ࡲࡨࡪࡃࡣࡩࡣࡱࡲࡪࡲࡳࠧࡵࡨࡧࡹ࡯࡯࡯ࡡ࡬ࡨࡂࠫࡳࠨਈ") % (addon, l11ll1l11_opy_)
        if (addon == locked) or (addon == l111lll1l_opy_):
            query = l1lllll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷ࠴ࡅࡵࡳ࡮ࡀࠩࡸࠬ࡭ࡰࡦࡨࡁ࠹ࠬ࡮ࡢ࡯ࡨࡁࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡳࡰࡦࡿ࠽ࠧࡦࡤࡸࡪࡃࠦࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࡂࠬࡰࡢࡩࡨࡁࠬਉ") % (addon, l11ll1l11_opy_)
        response = sendJSON(query, addon)
        l1l1lll_opy_.extend(response)
    return l1l1lll_opy_
def sendJSON(query, addon):
    l111l1_opy_     = l1lllll_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫਊ") % query
    l1l111l_opy_  = xbmc.executeJSONRPC(l111l1_opy_)
    response = json.loads(l1l111l_opy_)
    result   = response[l1lllll_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩ਋")]
    if xbmcgui.Window(10000).getProperty(l1lllll_opy_ (u"ࠪࡔࡑ࡛ࡇࡊࡐࡢࡋࡊࡔࡒࡆࠩ਌")) == l1lllll_opy_ (u"࡙ࠫࡸࡵࡦࠩ਍"):
        xbmcaddon.Addon(addon).setSetting(l1lllll_opy_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ਎"), l1lllll_opy_ (u"࠭ࡴࡳࡷࡨࠫਏ"))
    if xbmcgui.Window(10000).getProperty(l1lllll_opy_ (u"ࠧࡑࡎࡘࡋࡎࡔ࡟ࡕࡘࡊ࡙ࡎࡊࡅࠨਐ")) == l1lllll_opy_ (u"ࠨࡖࡵࡹࡪ࠭਑"):
        xbmcaddon.Addon(addon).setSetting(l1lllll_opy_ (u"ࠩࡷࡺ࡬ࡻࡩࡥࡧࠪ਒"), l1lllll_opy_ (u"ࠪࡸࡷࡻࡥࠨਓ"))
    return result[l1lllll_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪਔ")]
def l11llll1l_opy_(addon):
    if (addon == l11l11lll_opy_) or (addon == l11l111l1_opy_):
        return l1lllll_opy_ (u"ࠬ࠵࠿ࡤࡣࡷࡁ࠲࠸ࠦࡥࡣࡷࡩࠫࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠩࡩࡳࡪࡄࡢࡶࡨࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧ࡯ࡲࡨࡪࡃ࠲ࠧࡰࡤࡱࡪࡃࡍࡺࠧ࠵࠴ࡈ࡮ࡡ࡯ࡰࡨࡰࡸࠬࡲࡦࡥࡲࡶࡩࡴࡡ࡮ࡧࠩࡷࡹࡧࡲࡵࡆࡤࡸࡪࠬࡵࡳ࡮ࡀࡹࡷࡲࠧਕ")
    return l1lllll_opy_ (u"࠭ࠧਖ")
def l11ll1ll1_opy_():
    modules = map(__import__, [l111ll1l1_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11lll1l1_opy_)):
        return l1lllll_opy_ (u"ࠧࡕࡴࡸࡩࠬਗ")
    if len(modules[-1].Window(10**4).getProperty(l11lll11l_opy_)):
        return l1lllll_opy_ (u"ࠨࡖࡵࡹࡪ࠭ਘ")
    return l1lllll_opy_ (u"ࠩࡉࡥࡱࡹࡥࠨਙ")
def l11l11l11_opy_(e, addon):
    l11ll1111_opy_ = l1lllll_opy_ (u"ࠪࡗࡴࡸࡲࡺ࠮ࠣࡥࡳࠦࡥࡳࡴࡲࡶࠥࡵࡣࡤࡷࡵࡩࡩࡀࠠࡋࡕࡒࡒࠥࡋࡲࡳࡱࡵ࠾ࠥࠫࡳ࠭ࠢࠨࡷࠬਚ")  % (e, addon)
    l11ll1lll_opy_ = l1lllll_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡨࡵ࡮ࡵࡣࡦࡸࠥࡻࡳࠡࡱࡱࠤࡹ࡮ࡥࠡࡨࡲࡶࡺࡳ࠮ࠨਛ")
    l11ll11l1_opy_ = l1lllll_opy_ (u"࡛ࠬࡰ࡭ࡱࡤࡨࠥࡧࠠ࡭ࡱࡪࠤࡻ࡯ࡡࠡࡶ࡫ࡩࠥࡧࡤࡥࡱࡱࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸࠦࡡ࡯ࡦࠣࡴࡴࡹࡴࠡࡶ࡫ࡩࠥࡲࡩ࡯࡭࠱ࠫਜ")
    dixie.log(addon)
    dixie.log(e)
def getPluginInfo(streamurl, kodiID=False):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l111lll11_opy_   = l1lllll_opy_ (u"࠭ࡋࡰࡦ࡬ࠤࡕ࡜ࡒࠨਝ")
            l11lllll1_opy_ = os.path.join(dixie.RESOURCES, l1lllll_opy_ (u"ࠧ࡬ࡱࡧ࡭࠲ࡶࡶࡳ࠰ࡳࡲ࡬࠭ਞ"))
            return l111lll11_opy_, l11lllll1_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l1lllll_opy_ (u"ࠨࡴࡷࡱࡵ࠭ਟ")) or url.startswith(l1lllll_opy_ (u"ࠩࡵࡸࡲࡶࡥࠨਠ")) or url.startswith(l1lllll_opy_ (u"ࠪࡶࡹࡹࡰࠨਡ")) or url.startswith(l1lllll_opy_ (u"ࠫ࡭ࡺࡴࡱࠩਢ")):
            l111lll11_opy_   = l1lllll_opy_ (u"ࠬࡳ࠳ࡶࠢࡓࡰࡦࡿ࡬ࡪࡵࡷࠫਣ")
            l11lllll1_opy_ = os.path.join(dixie.RESOURCES, l1lllll_opy_ (u"࠭ࡩࡱࡶࡹ࠱ࡵࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡰ࡯ࡩࠪਤ"))
            return l111lll11_opy_, l11lllll1_opy_
    except:
        pass
    if streamurl.startswith(l1lllll_opy_ (u"ࠧࡱࡸࡵ࠾࠴࠵ࠧਥ")):
        l111lll11_opy_   = l1lllll_opy_ (u"ࠨࡍࡲࡨ࡮ࠦࡐࡗࡔࠪਦ")
        l11lllll1_opy_ = os.path.join(dixie.RESOURCES, l1lllll_opy_ (u"ࠩ࡮ࡳࡩ࡯࠭ࡱࡸࡵ࠲ࡵࡴࡧࠨਧ"))
        return l111lll11_opy_, l11lllll1_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        l11l11ll1_opy_ = streamurl.split(l1lllll_opy_ (u"ࠪࡡࡔ࡚ࡔࡠࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫਨ"), 1)[-1].split(l1lllll_opy_ (u"ࠫ࠴࠭਩"), 1)[0]
    if l1lllll_opy_ (u"ࠬࡣࡏࡕࡖࡢࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭ਪ") in streamurl:
        l11l11ll1_opy_ = streamurl.split(l1lllll_opy_ (u"࠭࡝ࡐࡖࡗࡣࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧਫ"), 1)[-1].split(l1lllll_opy_ (u"ࠧ࠰ࠩਬ"), 1)[0]
    if streamurl.startswith(l1lllll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫਭ")):
        l11l11ll1_opy_ = streamurl.split(l1lllll_opy_ (u"ࠩ࠲࠳ࠬਮ"), 1)[-1].split(l1lllll_opy_ (u"ࠪ࠳ࠬਯ"), 1)[0]
    if l1lllll_opy_ (u"ࠫࡤࡥࡓࡇࡡࡢࠫਰ") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡶࡲࡰࡩࡵࡥࡲ࠴ࡳࡶࡲࡨࡶ࠳࡬ࡡࡷࡱࡸࡶ࡮ࡺࡥࡴࠩ਱")
    if l1lllll_opy_ (u"࠭ࡆࡂࡄ࠽ࠫਲ") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡦࡢࡤ࡫ࡳࡸࡺࡩ࡯ࡩࠪਲ਼")
    if l1lllll_opy_ (u"ࠨࡃࡆࡉ࠿࠭਴") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡦࡩࡹࡼࠧਵ")
    if l1lllll_opy_ (u"ࠪࡌࡔࡘࡉ࡛࠼ࠪਸ਼") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡬ࡴࡸࡩࡻࡱࡱ࡭ࡵࡺࡶࠨ਷")
    if l1lllll_opy_ (u"ࠬࡘࡏࡐࡖ࠵࠾ࠬਸ") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸ࡯ࡰࡶࡌࡔ࡙࡜ࠧਹ")
    if l1lllll_opy_ (u"ࠧࡎࡇࡊࡅ࠿࠭਺") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡮ࡧࡪࡥ࡮ࡶࡴࡷࠩ਻")
    if l1lllll_opy_ (u"࡙ࠩࡈࡗ࡚ࡖ࠻਼ࠩ") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡙ࡅࡉࡋࡒࠨ਽")
    if l1lllll_opy_ (u"ࠫࡍࡊࡔࡗ࠼ࠪਾ") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡳࡡࡳࡶ࡫ࡹࡧ࠭ਿ")
    if l1lllll_opy_ (u"࠭ࡈࡅࡖ࡙࠶࠿࠭ੀ") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࠶ࠬੁ")
    if l1lllll_opy_ (u"ࠨࡊࡇࡘ࡛࠹࠺ࠨੂ") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࠸ࠧ੃")
    if l1lllll_opy_ (u"ࠪࡌࡉ࡚ࡖ࠵࠼ࠪ੄") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡱ࠭੅")
    if l1lllll_opy_ (u"ࠬࡏࡐࡍࡃ࡜࠾ࠬ੆") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡨࡢࡤ࡫ࡳࡰࡦࡿࡥࡳࠩੇ")
    if l1lllll_opy_ (u"ࠧࡊࡒࡏࡅ࡞࠸࠺ࠨੈ") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺࠫ੉")
    if l1lllll_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡓ࠼ࠪ੊") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠭ੋ")
    if l1lllll_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡌࡘ࡛ࡀࠧੌ") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡺࡶࠨ੍")
    if l1lllll_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡉࡀࠧ੎") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡤࡦࡺࠪ੏")
    if l1lllll_opy_ (u"ࠨࡌࡌࡒ࡝࠸࠺ࠨ੐") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡬࡬ࡲࡽࡺࡶ࠳ࠩੑ")
    if l1lllll_opy_ (u"ࠪࡑࡆ࡚ࡓ࠻ࠩ੒") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡑࡦࡺࡳࡃࡷ࡬ࡰࡩࡹࡉࡑࡖ࡙ࠫ੓")
    if l1lllll_opy_ (u"ࠬࡘࡏࡐࡖ࠽ࠫ੔") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸ࡯ࡰࡶ࡬ࡴࡹࡼࠧ੕")
    if l1lllll_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡘࡂ࠻ࠩ੖") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡧࡥࡳࡴࡺࠧ੗")
    if l1lllll_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡄࡎࡘ࠾ࠬ੘") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡦࡰࡺ࡯ࡰࡵࡸࠪਖ਼")
    if l1lllll_opy_ (u"ࠫࡎࡖࡔࡔࠩਗ਼") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶࡴࡷࡵࡸࡦࡸ࠭ਜ਼")
    if l1lllll_opy_ (u"࠭ࡌࡊࡘࡈࡘ࡛ࡀࠧੜ") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡬ࡪࡸࡨࡱ࡮ࡾࠧ੝")
    if l1lllll_opy_ (u"ࠨࡇࡑࡈ࠿࠭ਫ਼") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡇࡱࡨࡱ࡫ࡳࡴࠩ੟")
    if l1lllll_opy_ (u"ࠪࡊࡑࡇ࠺ࠨ੠") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡊࡱࡧࡷ࡭ࡧࡶࡷ࡙ࡼࠧ੡")
    if l1lllll_opy_ (u"ࠬࡓࡁ࡙ࡋ࠽ࠫ੢") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡳࡡࡹ࡫ࡺࡩࡧࡺࡶࠨ੣")
    if l1lllll_opy_ (u"ࠧࡇࡎࡄࡗ࠿࠭੤") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡇ࡮ࡤࡻࡱ࡫ࡳࡴࡖࡹࠫ੥")
    if l1lllll_opy_ (u"ࠩࡖࡔࡗࡓ࠺ࠨ੦") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡖࡹࡵࡸࡥ࡮ࡣࡦࡽ࡙࡜ࠧ੧")
    if l1lllll_opy_ (u"ࠫࡒࡉࡋࡕࡘ࠽ࠫ੨") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡲࡩ࡫ࡵࡸ࠰ࡴࡱࡻࡳࠨ੩")
    if l1lllll_opy_ (u"࠭ࡔࡘࡋࡖࡘ࠿࠭੪") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡴࡸ࡫ࡶࡸࡪࡪࠧ੫")
    if l1lllll_opy_ (u"ࠨࡒࡕࡉࡘ࡚࠺ࠨ੬") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡲࡶࡥࡩࡪ࡯࡯ࠩ੭")
    if l1lllll_opy_ (u"ࠪࡆࡑࡑࡉ࠻ࠩ੮") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡆࡱࡧࡣ࡬ࡋࡦࡩ࡙࡜ࠧ੯")
    if l1lllll_opy_ (u"ࠬࡌࡒࡆࡇ࠽ࠫੰ") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡬ࡲࡦࡧࡹ࡭ࡪࡽࠧੱ")
    if l1lllll_opy_ (u"ࠧࡶࡲࡱࡴ࠿࠭ੲ") in streamurl:
        l11l11ll1_opy_ = l1lllll_opy_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯ࡪࡧ࡬ࡴࡳࡥࡳࡷࡱ࠲ࡻ࡯ࡥࡸࠩੳ")
    return l11l1ll1l_opy_(l11l11ll1_opy_, kodiID)
def l11l1ll1l_opy_(l11l11ll1_opy_, kodiID):
    l111lll11_opy_     = l1lllll_opy_ (u"ࠩࠪੴ")
    l11lllll1_opy_   = l1lllll_opy_ (u"ࠪࠫੵ")
    try:
        l1l111111_opy_ = xbmcaddon.Addon(l11l11ll1_opy_).getAddonInfo(l1lllll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩ੶"))
        l111lll11_opy_    = dixie.cleanLabel(l1l111111_opy_)
        l11lllll1_opy_  = xbmcaddon.Addon(l11l11ll1_opy_).getAddonInfo(l1lllll_opy_ (u"ࠬ࡯ࡣࡰࡰࠪ੷"))
        if kodiID:
            l111llll1_opy_ = xbmcaddon.Addon(l11l11ll1_opy_).getAddonInfo(l1lllll_opy_ (u"࠭ࡩࡥࠩ੸"))
            return l111lll11_opy_, l111llll1_opy_
        return l111lll11_opy_, l11lllll1_opy_
    except:
        l111lll11_opy_   = l1lllll_opy_ (u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡕࡲࡹࡷࡩࡥࠨ੹")
        l11lllll1_opy_ =  dixie.ICON
        return l111lll11_opy_, l11lllll1_opy_
    return l111lll11_opy_, l11lllll1_opy_
def selectStream(url, channel):
    l1ll1l1l_opy_ = url.split(l1lllll_opy_ (u"ࠨࡾࠪ੺"))
    if len(l1ll1l1l_opy_) == 0:
        return None
    options, l1llll11_opy_ = getOptions(l1ll1l1l_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l1ll1l1l_opy_) == 1:
            return l1llll11_opy_[0]
    import selectDialog
    l1llll1_opy_ = selectDialog.select(l1lllll_opy_ (u"ࠩࡖࡩࡱ࡫ࡣࡵࠢࡤࠤࡸࡺࡲࡦࡣࡰࠫ੻"), options)
    if l1llll1_opy_ < 0:
        raise Exception(l1lllll_opy_ (u"ࠪࡗࡪࡲࡥࡤࡶ࡬ࡳࡳࠦࡃࡢࡰࡦࡩࡱ࠭੼"))
    return l1llll11_opy_[l1llll1_opy_]
def getOptions(l1ll1l1l_opy_, channel, addmore=True):
    options = []
    l1llll11_opy_    = []
    for index, stream in enumerate(l1ll1l1l_opy_):
        l111lll11_opy_ = getPluginInfo(stream)
        l11l1l_opy_ = l111lll11_opy_[0]
        l11l111ll_opy_  = l111lll11_opy_[1]
        l11l1l_opy_ = l1lllll_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡴࡸࡡ࡯ࡩࡨࡡࡠ࠭੽") + l11l1l_opy_ + l1lllll_opy_ (u"ࠬࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠡࠩ੾")
        if stream.startswith(OPEN_OTT):
            l1lll11_opy_ = stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l1lllll_opy_ (u"࠭ࠧ੿"))
            l11l1l_opy_  = l11l1l_opy_ + l1lll11_opy_
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l1lllll_opy_ (u"ࠧࠨ઀"))
        else:
            l11l1l_opy_  = l11l1l_opy_ + channel
        options.append([l11l1l_opy_, index, l11l111ll_opy_])
        l1llll11_opy_.append(stream)
    if addmore:
        options.append([l1lllll_opy_ (u"ࠨࡃࡧࡨࠥࡳ࡯ࡳࡧ࠱࠲࠳࠭ઁ"), index + 1, dixie.ICON])
        l1llll11_opy_.append(l1lllll_opy_ (u"ࠩࡤࡨࡩࡓ࡯ࡳࡧࠪં"))
    return options, l1llll11_opy_
if __name__ == l1lllll_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬઃ"):
    checkAddons()