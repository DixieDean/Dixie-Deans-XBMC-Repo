# coding: UTF-8
import sys
l1l1lll1_opy_ = sys.version_info [0] == 2
l11l111_opy_ = 2048
l1lll11l_opy_ = 7
def l1l1l_opy_ (l1l11l_opy_):
	global l11l1l1_opy_
	l1111l1_opy_ = ord (l1l11l_opy_ [-1])
	l1ll1111_opy_ = l1l11l_opy_ [:-1]
	l1l11l1_opy_ = l1111l1_opy_ % len (l1ll1111_opy_)
	l11l1l_opy_ = l1ll1111_opy_ [:l1l11l1_opy_] + l1ll1111_opy_ [l1l11l1_opy_:]
	if l1l1lll1_opy_:
		l111l_opy_ = unicode () .join ([unichr (ord (char) - l11l111_opy_ - (l1lll_opy_ + l1111l1_opy_) % l1lll11l_opy_) for l1lll_opy_, char in enumerate (l11l1l_opy_)])
	else:
		l111l_opy_ = str () .join ([chr (ord (char) - l11l111_opy_ - (l1lll_opy_ + l1111l1_opy_) % l1lll11l_opy_) for l1lll_opy_, char in enumerate (l11l1l_opy_)])
	return eval (l111l_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l11l11lll_opy_     = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡱࡸࡻ࠭ु")
l11l111l1_opy_  = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡻࡱ࡯ࡰࡵࡸࠪू")
l11ll11l1_opy_     = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡶࡴ࡮ࠫृ")
locked  = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲ࡯ࡤ࡭ࡨࡨࡹࡼࠧॄ")
l111lll1l_opy_      = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡵ࡭ࡶ࡬ࡱࡦࡺࡥ࡮ࡣࡱ࡭ࡦ࠭ॅ")
l11l11111_opy_    = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡭࡫ࡸࡼ࠳ࡺࡶࠨॆ")
l11l11l11_opy_     = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡆࡆࡗࡵࡵࡲࡵࡵࠪे")
l11ll111l_opy_  = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡩࡧࡵ࡯ࡵࠩै")
l11l11l1l_opy_     = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡧࡱࡻࡩࡱࡶࡹࠫॉ")
l11ll1111_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡷ࠶ࡨࡼࡵࡧࡴࡴ࠰ࡦࡳࡲ࠭ॊ")
l111111_opy_ = [l11l11lll_opy_, locked, l11l11111_opy_, l11l111l1_opy_, l11ll1111_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1l1l_opy_ (u"࠭ࡩ࡯࡫ࠪो"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1l1lll_opy_ = l1l1l_opy_ (u"ࠧࠨौ")
def l1l1l1_opy_(i, t1, l1l1ll_opy_=[]):
 t = l1l1lll_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l1ll_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11_opy_ = l1l1l1_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l1l111_opy_ = l1l1l1_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l111111_opy_:
        if l1l1llll_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1l1llll_opy_(addon):
    if xbmc.getCondVisibility(l1l1l_opy_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫࠩࡸ࠯्ࠧ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l1l111l1_opy_ = str(addon).split(l1l1l_opy_ (u"ࠩ࠱ࠫॎ"))[2] + l1l1l_opy_ (u"ࠪ࠲࡮ࡴࡩࠨॏ")
    l1l1l11_opy_  = os.path.join(PATH, l1l111l1_opy_)
    try:
        l1l111l_opy_ = l1llllll_opy_(addon)
    except KeyError:
        dixie.log(l1l1l_opy_ (u"ࠫ࠲࠳࠭࠮࠯ࠣࡏࡪࡿࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡩࡨࡸࡋ࡯࡬ࡦࡵࠣ࠱࠲࠳࠭࠮ࠢࠪॐ") + addon)
        result = {l1l1l_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࡷࠬ॑"): [{l1l1l_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࡹࡿࡰࡦ॒ࠩ"): l1l1l_opy_ (u"ࡵࠨࡨ࡬ࡰࡪ࠭॓"), l1l1l_opy_ (u"ࡶࠩࡷࡽࡵ࡫ࠧ॔"): l1l1l_opy_ (u"ࡷࠪࡹࡳࡱ࡮ࡰࡹࡱࠫॕ"), l1l1l_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࠩॖ"): l1l1l_opy_ (u"ࡹࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸࡹࡺࠪॗ"), l1l1l_opy_ (u"ࡺ࠭࡬ࡢࡤࡨࡰࠬक़"): l1l1l_opy_ (u"ࡻࠧࡏࡑࠣࡇࡍࡇࡎࡏࡇࡏࡗࠬख़")}], l1l1l_opy_ (u"ࡵࠨ࡮࡬ࡱ࡮ࡺࡳࠨग़"):{l1l1l_opy_ (u"ࡶࠩࡶࡸࡦࡸࡴࠨज़"): 0, l1l1l_opy_ (u"ࡷࠪࡸࡴࡺࡡ࡭ࠩड़"): 1, l1l1l_opy_ (u"ࡸࠫࡪࡴࡤࠨढ़"): 1}}
    l1ll11_opy_  = l1l1l_opy_ (u"ࠫࡠ࠭फ़") + addon + l1l1l_opy_ (u"ࠬࡣ࡜࡯ࠩय़")
    l1lll1ll_opy_  =  file(l1l1l11_opy_, l1l1l_opy_ (u"࠭ࡷࠨॠ"))
    l1lll1ll_opy_.write(l1ll11_opy_)
    l1l1ll11_opy_ = []
    for channel in l1l111l_opy_:
        l1l1_opy_ = dixie.cleanLabel(channel[l1l1l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ॡ")])
        l1l1l1l_opy_   = dixie.cleanPrefix(l1l1_opy_)
        l11ll1_opy_ = dixie.mapChannelName(l1l1l1l_opy_)
        stream   = channel[l1l1l_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ॢ")]
        l111ll_opy_ = l11ll1_opy_ + l1l1l_opy_ (u"ࠩࡀࠫॣ") + stream
        l1l1ll11_opy_.append(l111ll_opy_)
        l1l1ll11_opy_.sort()
    for item in l1l1ll11_opy_:
        l1lll1ll_opy_.write(l1l1l_opy_ (u"ࠥࠩࡸࡢ࡮ࠣ।") % item)
    l1lll1ll_opy_.close()
def l1llllll_opy_(addon):
    if (addon == l11l11lll_opy_) or (addon == l11l111l1_opy_):
        if xbmcaddon.Addon(addon).getSetting(l1l1l_opy_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ॥")) == l1l1l_opy_ (u"ࠬࡺࡲࡶࡧࠪ०"):
            xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"࠭ࡧࡦࡰࡵࡩࠬ१"), l1l1l_opy_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭२"))
            xbmcgui.Window(10000).setProperty(l1l1l_opy_ (u"ࠨࡒࡏ࡙ࡌࡏࡎࡠࡉࡈࡒࡗࡋࠧ३"), l1l1l_opy_ (u"ࠩࡗࡶࡺ࡫ࠧ४"))
        if xbmcaddon.Addon(addon).getSetting(l1l1l_opy_ (u"ࠪࡸࡻ࡭ࡵࡪࡦࡨࠫ५")) == l1l1l_opy_ (u"ࠫࡹࡸࡵࡦࠩ६"):
            xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"ࠬࡺࡶࡨࡷ࡬ࡨࡪ࠭७"), l1l1l_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬ८"))
            xbmcgui.Window(10000).setProperty(l1l1l_opy_ (u"ࠧࡑࡎࡘࡋࡎࡔ࡟ࡕࡘࡊ࡙ࡎࡊࡅࠨ९"), l1l1l_opy_ (u"ࠨࡖࡵࡹࡪ࠭॰"))
        l11l1111l_opy_  = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬॱ") + addon
        l11l1lll1_opy_ =  l11ll1l11_opy_(addon)
        query   =  l11l1111l_opy_ + l11l1lll1_opy_
        return sendJSON(query, addon)
    return l11l1l1l1_opy_(addon)
def l11l1l1l1_opy_(addon):
    if addon == l11ll1111_opy_:
        l11l1l1ll_opy_ = [l1l1l_opy_ (u"ࠪ࠵࠻࠷ࠧॲ"), l1l1l_opy_ (u"ࠫ࠶࠼࠰ࠨॳ"), l1l1l_opy_ (u"ࠬ࠸࠳࠷ࠩॴ"), l1l1l_opy_ (u"࠭࠲࠵࠴ࠪॵ"), l1l1l_opy_ (u"ࠧ࠲࠷࠻ࠫॶ"), l1l1l_opy_ (u"ࠨ࠳࠸࠽ࠬॷ")]
    if addon == l11l11111_opy_:
        l11l1l1ll_opy_ = [l1l1l_opy_ (u"ࠩ࠸ࠫॸ"), l1l1l_opy_ (u"ࠪ࠵࠵࠼ࠧॹ"), l1l1l_opy_ (u"ࠫ࠹࠭ॺ"), l1l1l_opy_ (u"ࠬ࠸࠶࠴ࠩॻ"), l1l1l_opy_ (u"࠭࠱࠴࠴ࠪॼ")]
    if addon == locked:
        l11l1l1ll_opy_ = [l1l1l_opy_ (u"ࠧ࠴࠲ࠪॽ"), l1l1l_opy_ (u"ࠨ࠵࠴ࠫॾ"), l1l1l_opy_ (u"ࠩ࠶࠶ࠬॿ"), l1l1l_opy_ (u"ࠪ࠷࠸࠭ঀ"), l1l1l_opy_ (u"ࠫ࠸࠺ࠧঁ"), l1l1l_opy_ (u"ࠬ࠹࠵ࠨং"), l1l1l_opy_ (u"࠭࠳࠹ࠩঃ"), l1l1l_opy_ (u"ࠧ࠵࠲ࠪ঄"), l1l1l_opy_ (u"ࠨ࠶࠴ࠫঅ"), l1l1l_opy_ (u"ࠩ࠷࠹ࠬআ"), l1l1l_opy_ (u"ࠪ࠸࠼࠭ই"), l1l1l_opy_ (u"ࠫ࠹࠿ࠧঈ"), l1l1l_opy_ (u"ࠬ࠻࠲ࠨউ")]
    if addon == l111lll1l_opy_:
        l11l1l1ll_opy_ = [l1l1l_opy_ (u"࠭࠲࠶ࠩঊ"), l1l1l_opy_ (u"ࠧ࠳࠸ࠪঋ"), l1l1l_opy_ (u"ࠨ࠴࠺ࠫঌ"), l1l1l_opy_ (u"ࠩ࠵࠽ࠬ঍"), l1l1l_opy_ (u"ࠪ࠷࠵࠭঎"), l1l1l_opy_ (u"ࠫ࠸࠷ࠧএ"), l1l1l_opy_ (u"ࠬ࠹࠲ࠨঐ"), l1l1l_opy_ (u"࠭࠳࠶ࠩ঑"), l1l1l_opy_ (u"ࠧ࠴࠸ࠪ঒"), l1l1l_opy_ (u"ࠨ࠵࠺ࠫও"), l1l1l_opy_ (u"ࠩ࠶࠼ࠬঔ"), l1l1l_opy_ (u"ࠪ࠷࠾࠭ক"), l1l1l_opy_ (u"ࠫ࠹࠶ࠧখ"), l1l1l_opy_ (u"ࠬ࠺࠱ࠨগ"), l1l1l_opy_ (u"࠭࠴࠹ࠩঘ"), l1l1l_opy_ (u"ࠧ࠵࠻ࠪঙ"), l1l1l_opy_ (u"ࠨ࠷࠳ࠫচ"), l1l1l_opy_ (u"ࠩ࠸࠶ࠬছ"), l1l1l_opy_ (u"ࠪ࠹࠹࠭জ"), l1l1l_opy_ (u"ࠫ࠺࠼ࠧঝ"), l1l1l_opy_ (u"ࠬ࠻࠷ࠨঞ"), l1l1l_opy_ (u"࠭࠵࠹ࠩট"), l1l1l_opy_ (u"ࠧ࠶࠻ࠪঠ"), l1l1l_opy_ (u"ࠨ࠸࠳ࠫড"), l1l1l_opy_ (u"ࠩ࠹࠵ࠬঢ"), l1l1l_opy_ (u"ࠪ࠺࠷࠭ণ"), l1l1l_opy_ (u"ࠫ࠻࠹ࠧত"), l1l1l_opy_ (u"ࠬ࠼࠵ࠨথ"), l1l1l_opy_ (u"࠭࠶࠷ࠩদ"), l1l1l_opy_ (u"ࠧ࠷࠹ࠪধ"), l1l1l_opy_ (u"ࠨ࠸࠼ࠫন"), l1l1l_opy_ (u"ࠩ࠺࠴ࠬ঩"), l1l1l_opy_ (u"ࠪ࠻࠹࠭প"), l1l1l_opy_ (u"ࠫ࠼࠽ࠧফ"), l1l1l_opy_ (u"ࠬ࠽࠸ࠨব"), l1l1l_opy_ (u"࠭࠸࠱ࠩভ"), l1l1l_opy_ (u"ࠧ࠹࠳ࠪম")]
    login = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸ࠵ࠧয") % addon
    sendJSON(login, addon)
    l11l1ll_opy_ = []
    for l11ll11ll_opy_ in l11l1l1ll_opy_:
        if (addon == l11ll1111_opy_) or (addon == l11l11111_opy_):
            query = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠪࡹ࠯ࡀ࡯ࡲࡨࡪࡥࡩࡥ࠿ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪࡲࡵࡤࡦ࠿ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪࡸ࡫ࡣࡵ࡫ࡲࡲࡤ࡯ࡤ࠾ࠧࡶࠫর") % (addon, l11ll11ll_opy_)
        if (addon == locked) or (addon == l111lll1l_opy_):
            query = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳ࠰ࡁࡸࡶࡱࡃࠥࡴࠨࡰࡳࡩ࡫࠽࠵ࠨࡱࡥࡲ࡫࠽ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡶ࡬ࡢࡻࡀࠪࡩࡧࡴࡦ࠿ࠩࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮࠾ࠨࡳࡥ࡬࡫࠽ࠨ঱") % (addon, l11ll11ll_opy_)
        response = sendJSON(query, addon)
        l11l1ll_opy_.extend(response)
    return l11l1ll_opy_
def sendJSON(query, addon):
    l11l1llll_opy_     = l1l1l_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࠥࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧল") % query
    l11l1l111_opy_  = xbmc.executeJSONRPC(l11l1llll_opy_)
    response = json.loads(l11l1l111_opy_)
    result   = response[l1l1l_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬ঳")]
    if xbmcgui.Window(10000).getProperty(l1l1l_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡇࡆࡐࡕࡉࠬ঴")) == l1l1l_opy_ (u"ࠧࡕࡴࡸࡩࠬ঵"):
        xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"ࠨࡩࡨࡲࡷ࡫ࠧশ"), l1l1l_opy_ (u"ࠩࡷࡶࡺ࡫ࠧষ"))
    if xbmcgui.Window(10000).getProperty(l1l1l_opy_ (u"ࠪࡔࡑ࡛ࡇࡊࡐࡢࡘ࡛ࡍࡕࡊࡆࡈࠫস")) == l1l1l_opy_ (u"࡙ࠫࡸࡵࡦࠩহ"):
        xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"ࠬࡺࡶࡨࡷ࡬ࡨࡪ࠭঺"), l1l1l_opy_ (u"࠭ࡴࡳࡷࡨࠫ঻"))
    return result[l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ়࠭")]
def l11ll1l11_opy_(addon):
    if (addon == l11l11lll_opy_) or (addon == l11l111l1_opy_):
        return l1l1l_opy_ (u"ࠨ࠱ࡂࡧࡦࡺ࠽࠮࠴ࠩࡨࡦࡺࡥࠧࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠬࡥ࡯ࡦࡇࡥࡹ࡫ࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡲࡵࡤࡦ࠿࠵ࠪࡳࡧ࡭ࡦ࠿ࡐࡽࠪ࠸࠰ࡄࡪࡤࡲࡳ࡫࡬ࡴࠨࡵࡩࡨࡵࡲࡥࡰࡤࡱࡪࠬࡳࡵࡣࡵࡸࡉࡧࡴࡦࠨࡸࡶࡱࡃࡵࡳ࡮ࠪঽ")
    return l1l1l_opy_ (u"ࠩࠪা")
def l1ll11l1_opy_():
    modules = map(__import__, [l1l1l1_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l1l1l_opy_ (u"ࠪࡘࡷࡻࡥࠨি")
    if len(modules[-1].Window(10**4).getProperty(l1l111_opy_)):
        return l1l1l_opy_ (u"࡙ࠫࡸࡵࡦࠩী")
    return l1l1l_opy_ (u"ࠬࡌࡡ࡭ࡵࡨࠫু")
def l1l11l1l_opy_(e, addon):
    l1ll11ll_opy_ = l1l1l_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠱ࠦࡡ࡯ࠢࡨࡶࡷࡵࡲࠡࡱࡦࡧࡺࡸࡥࡥ࠼ࠣࡎࡘࡕࡎࠡࡇࡵࡶࡴࡸ࠺ࠡࠧࡶ࠰ࠥࠫࡳࠨূ")  % (e, addon)
    l1ll1l11_opy_ = l1l1l_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡤࡱࡱࡸࡦࡩࡴࠡࡷࡶࠤࡴࡴࠠࡵࡪࡨࠤ࡫ࡵࡲࡶ࡯࠱ࠫৃ")
    l1ll1l1l_opy_ = l1l1l_opy_ (u"ࠨࡗࡳࡰࡴࡧࡤࠡࡣࠣࡰࡴ࡭ࠠࡷ࡫ࡤࠤࡹ࡮ࡥࠡࡣࡧࡨࡴࡴࠠࡴࡧࡷࡸ࡮ࡴࡧࡴࠢࡤࡲࡩࠦࡰࡰࡵࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰ࠴ࠧৄ")
    dixie.log(addon)
    dixie.log(e)
def getPluginInfo(streamurl, kodiID=False):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l111lll11_opy_   = l1l1l_opy_ (u"ࠩࡎࡳࡩ࡯ࠠࡑࡘࡕࠫ৅")
            l111lllll_opy_ = os.path.join(dixie.RESOURCES, l1l1l_opy_ (u"ࠪ࡯ࡴࡪࡩ࠮ࡲࡹࡶ࠳ࡶ࡮ࡨࠩ৆"))
            return l111lll11_opy_, l111lllll_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l1l1l_opy_ (u"ࠫࡷࡺ࡭ࡱࠩে")) or url.startswith(l1l1l_opy_ (u"ࠬࡸࡴ࡮ࡲࡨࠫৈ")) or url.startswith(l1l1l_opy_ (u"࠭ࡲࡵࡵࡳࠫ৉")) or url.startswith(l1l1l_opy_ (u"ࠧࡩࡶࡷࡴࠬ৊")):
            l111lll11_opy_   = l1l1l_opy_ (u"ࠨ࡯࠶ࡹࠥࡖ࡬ࡢࡻ࡯࡭ࡸࡺࠧো")
            l111lllll_opy_ = os.path.join(dixie.RESOURCES, l1l1l_opy_ (u"ࠩ࡬ࡴࡹࡼ࠭ࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡳࡲ࡬࠭ৌ"))
            return l111lll11_opy_, l111lllll_opy_
    except:
        pass
    if streamurl.startswith(l1l1l_opy_ (u"ࠪࡴࡻࡸ࠺࠰࠱্ࠪ")):
        l111lll11_opy_   = l1l1l_opy_ (u"ࠫࡐࡵࡤࡪࠢࡓ࡚ࡗ࠭ৎ")
        l111lllll_opy_ = os.path.join(dixie.RESOURCES, l1l1l_opy_ (u"ࠬࡱ࡯ࡥ࡫࠰ࡴࡻࡸ࠮ࡱࡰࡪࠫ৏"))
        return l111lll11_opy_, l111lllll_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        l11l11ll1_opy_ = streamurl.split(l1l1l_opy_ (u"࠭࡝ࡐࡖࡗࡣࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ৐"), 1)[-1].split(l1l1l_opy_ (u"ࠧ࠰ࠩ৑"), 1)[0]
    if l1l1l_opy_ (u"ࠨ࡟ࡒࡘ࡙ࡥࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ৒") in streamurl:
        l11l11ll1_opy_ = streamurl.split(l1l1l_opy_ (u"ࠩࡠࡓ࡙࡚࡟ࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ৓"), 1)[-1].split(l1l1l_opy_ (u"ࠪ࠳ࠬ৔"), 1)[0]
    if streamurl.startswith(l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ৕")):
        l11l11ll1_opy_ = streamurl.split(l1l1l_opy_ (u"ࠬ࠵࠯ࠨ৖"), 1)[-1].split(l1l1l_opy_ (u"࠭࠯ࠨৗ"), 1)[0]
    if l1l1l_opy_ (u"ࠧࡠࡡࡖࡊࡤࡥࠧ৘") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡲࡵࡳ࡬ࡸࡡ࡮࠰ࡶࡹࡵ࡫ࡲ࠯ࡨࡤࡺࡴࡻࡲࡪࡶࡨࡷࠬ৙")
    if l1l1l_opy_ (u"ࠩࡊࡉࡍࡀࠧ৚") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡪࡩ࡭ࡵࡳࡵ࡫ࡱ࡫ࠬ৛")
    if l1l1l_opy_ (u"ࠫࡒ࡚ࡘࡊࡇ࠽ࠫড়") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡲࡧࡴࡳ࡫ࡻ࡭ࡷ࡫࡬ࡢࡰࡧࠫঢ়")
    if l1l1l_opy_ (u"࠭ࡔࡗࡍ࠽ࠫ৞") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡴࡷ࡭࡬ࡲ࡬ࡹࠧয়")
    if l1l1l_opy_ (u"ࠨ࡚ࡗࡇ࠿࠭ৠ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡺࡷࡶࡪࡧ࡭࠮ࡥࡲࡨࡪࡹࠧৡ")
    if l1l1l_opy_ (u"ࠪࡗࡈ࡚ࡖ࠻ࠩৢ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡨࡺࡶࠨৣ")
    if l1l1l_opy_ (u"࡙ࠬࡕࡑ࠼ࠪ৤") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹࡴࡳࡧࡤࡱࡸࡻࡰࡳࡧࡰࡩ࠷࠭৥")
    if l1l1l_opy_ (u"ࠧࡖࡍࡗ࠾ࠬ০") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡶ࡭ࡷࡹࡷࡱࠧ১")
    if l1l1l_opy_ (u"ࠩࡏࡍࡒࡏࡔ࠻ࠩ২") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡏ࡭ࡲ࡯ࡴ࡭ࡧࡶࡷࡎࡖࡔࡗࠩ৩")
    if l1l1l_opy_ (u"ࠫࡋࡇࡂ࠻ࠩ৪") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡫ࡧࡢࡩࡱࡶࡸ࡮ࡴࡧࠨ৫")
    if l1l1l_opy_ (u"࠭ࡁࡄࡇ࠽ࠫ৬") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡤࡧࡷࡺࠬ৭")
    if l1l1l_opy_ (u"ࠨࡊࡒࡖࡎࡠ࠺ࠨ৮") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡪࡲࡶ࡮ࢀ࡯࡯࡫ࡳࡸࡻ࠭৯")
    if l1l1l_opy_ (u"ࠪࡖࡔࡕࡔ࠳࠼ࠪৰ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡴࡵࡴࡊࡒࡗ࡚ࠬৱ")
    if l1l1l_opy_ (u"ࠬࡓࡅࡈࡃ࠽ࠫ৲") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡳࡥࡨࡣ࡬ࡴࡹࡼࠧ৳")
    if l1l1l_opy_ (u"ࠧࡗࡆࡕࡘ࡛ࡀࠧ৴") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡗࡃࡇࡉࡗ࠭৵")
    if l1l1l_opy_ (u"ࠩࡋࡈ࡙࡜࠺ࠨ৶") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡱࡦࡸࡴࡩࡷࡥࠫ৷")
    if l1l1l_opy_ (u"ࠫࡍࡊࡔࡗ࠴࠽ࠫ৸") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢ࠴ࠪ৹")
    if l1l1l_opy_ (u"࠭ࡈࡅࡖ࡙࠷࠿࠭৺") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࠶ࠬ৻")
    if l1l1l_opy_ (u"ࠨࡊࡇࡘ࡛࠺࠺ࠨৼ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡺ࡯ࠫ৽")
    if l1l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠼ࠪ৾") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡦࡧࡩࡩࡱ࡮ࡤࡽࡪࡸࠧ৿")
    if l1l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜࠶࠿࠭਀") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰ࡭ࡣࡼࡩࡷࡽࡷࡸࠩਁ")
    if l1l1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡘ࠺ࠨਂ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺࠫਃ")
    if l1l1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡊࡖ࡙࠾ࠬ਄") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡸࡻ࠭ਅ")
    if l1l1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡇ࠾ࠬਆ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸࠨਇ")
    if l1l1l_opy_ (u"࠭ࡊࡊࡐ࡛࠶࠿࠭ਈ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡪࡪࡰࡻࡸࡻ࠸ࠧਉ")
    if l1l1l_opy_ (u"ࠨࡏࡄࡘࡘࡀࠧਊ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡏࡤࡸࡸࡈࡵࡪ࡮ࡧࡷࡎࡖࡔࡗࠩ਋")
    if l1l1l_opy_ (u"ࠪࡖࡔࡕࡔ࠻ࠩ਌") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡴࡵࡴࡪࡲࡷࡺࠬ਍")
    if l1l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖࡇࡀࠧ਎") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡥࡣࡱࡲࡸࠬਏ")
    if l1l1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡉࡌࡖ࠼ࠪਐ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡤ࡮ࡸ࡭ࡵࡺࡶࠨ਑")
    if l1l1l_opy_ (u"ࠩࡌࡔ࡙࡙ࠧ਒") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡹࡼࡳࡶࡤࡶࠫਓ")
    if l1l1l_opy_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠾ࠬਔ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡱ࡯ࡶࡦ࡯࡬ࡼࠬਕ")
    if l1l1l_opy_ (u"࠭ࡅࡏࡆ࠽ࠫਖ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡅ࡯ࡦ࡯ࡩࡸࡹࠧਗ")
    if l1l1l_opy_ (u"ࠨࡈࡏࡅ࠿࠭ਘ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡈ࡯ࡥࡼࡲࡥࡴࡵࡗࡺࠬਙ")
    if l1l1l_opy_ (u"ࠪࡑࡆ࡞ࡉ࠻ࠩਚ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡱࡦࡾࡩࡸࡧࡥࡸࡻ࠭ਛ")
    if l1l1l_opy_ (u"ࠬࡌࡌࡂࡕ࠽ࠫਜ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡌ࡬ࡢࡹ࡯ࡩࡸࡹࡔࡷࠩਝ")
    if l1l1l_opy_ (u"ࠧࡔࡒࡕࡑ࠿࠭ਞ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡔࡷࡳࡶࡪࡳࡡࡤࡻࡗ࡚ࠬਟ")
    if l1l1l_opy_ (u"ࠩࡐࡇࡐ࡚ࡖ࠻ࠩਠ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡰࡧࡰࡺࡶ࠮ࡲ࡯ࡹࡸ࠭ਡ")
    if l1l1l_opy_ (u"࡙ࠫ࡝ࡉࡔࡖ࠽ࠫਢ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡹࡽࡩࡴࡶࡨࡨࠬਣ")
    if l1l1l_opy_ (u"࠭ࡐࡓࡇࡖࡘ࠿࠭ਤ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡰࡴࡣࡧࡨࡴࡴࠧਥ")
    if l1l1l_opy_ (u"ࠨࡄࡏࡏࡎࡀࠧਦ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡄ࡯ࡥࡨࡱࡉࡤࡧࡗ࡚ࠬਧ")
    if l1l1l_opy_ (u"ࠪࡊࡗࡋࡅ࠻ࠩਨ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡪࡷ࡫ࡥࡷ࡫ࡨࡻࠬ਩")
    if l1l1l_opy_ (u"ࠬࡻࡰ࡯ࡲ࠽ࠫਪ") in streamurl:
        l11l11ll1_opy_ = l1l1l_opy_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴ࡨࡥࡪࡲࡱࡪࡸࡵ࡯࠰ࡹ࡭ࡪࡽࠧਫ")
    return l11l1ll1l_opy_(l11l11ll1_opy_, kodiID)
def l11l1ll1l_opy_(l11l11ll1_opy_, kodiID):
    l111lll11_opy_     = l1l1l_opy_ (u"ࠧࠨਬ")
    l111lllll_opy_   = l1l1l_opy_ (u"ࠨࠩਭ")
    try:
        l11ll1l1l_opy_ = xbmcaddon.Addon(l11l11ll1_opy_).getAddonInfo(l1l1l_opy_ (u"ࠩࡱࡥࡲ࡫ࠧਮ"))
        l111lll11_opy_    = dixie.cleanLabel(l11ll1l1l_opy_)
        l111lllll_opy_  = xbmcaddon.Addon(l11l11ll1_opy_).getAddonInfo(l1l1l_opy_ (u"ࠪ࡭ࡨࡵ࡮ࠨਯ"))
        if kodiID:
            l111llll1_opy_ = xbmcaddon.Addon(l11l11ll1_opy_).getAddonInfo(l1l1l_opy_ (u"ࠫ࡮ࡪࠧਰ"))
            return l111lll11_opy_, l111llll1_opy_
        return l111lll11_opy_, l111lllll_opy_
    except:
        l111lll11_opy_   = l1l1l_opy_ (u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡓࡰࡷࡵࡧࡪ࠭਱")
        l111lllll_opy_ =  dixie.ICON
        return l111lll11_opy_, l111lllll_opy_
    return l111lll11_opy_, l111lllll_opy_
def selectStream(url, channel):
    l111ll1ll_opy_ = url.split(l1l1l_opy_ (u"࠭ࡼࠨਲ"))
    if len(l111ll1ll_opy_) == 0:
        return None
    options, l1l11ll_opy_ = getOptions(l111ll1ll_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l111ll1ll_opy_) == 1:
            return l1l11ll_opy_[0]
    import selectDialog
    l11l1l11l_opy_ = selectDialog.select(l1l1l_opy_ (u"ࠧࡔࡧ࡯ࡩࡨࡺࠠࡢࠢࡶࡸࡷ࡫ࡡ࡮ࠩਲ਼"), options)
    if l11l1l11l_opy_ < 0:
        raise Exception(l1l1l_opy_ (u"ࠨࡕࡨࡰࡪࡩࡴࡪࡱࡱࠤࡈࡧ࡮ࡤࡧ࡯ࠫ਴"))
    return l1l11ll_opy_[l11l1l11l_opy_]
def getOptions(l111ll1ll_opy_, channel, addmore=True):
    options = []
    l1l11ll_opy_    = []
    for index, stream in enumerate(l111ll1ll_opy_):
        l111lll11_opy_ = getPluginInfo(stream)
        l1lllll_opy_ = l111lll11_opy_[0]
        l11l111ll_opy_  = l111lll11_opy_[1]
        l1lllll_opy_ = l1l1l_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡲࡶࡦࡴࡧࡦ࡟࡞ࠫਵ") + l1lllll_opy_ + l1l1l_opy_ (u"ࠪࡡࡠ࠵ࡃࡐࡎࡒࡖࡢࠦࠧਸ਼")
        if stream.startswith(OPEN_OTT):
            l11l1ll11_opy_ = stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l1l1l_opy_ (u"ࠫࠬ਷"))
            l1lllll_opy_  = l1lllll_opy_ + l11l1ll11_opy_
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l1l1l_opy_ (u"ࠬ࠭ਸ"))
        else:
            l1lllll_opy_  = l1lllll_opy_ + channel
        options.append([l1lllll_opy_, index, l11l111ll_opy_])
        l1l11ll_opy_.append(stream)
    if addmore:
        options.append([l1l1l_opy_ (u"࠭ࡁࡥࡦࠣࡱࡴࡸࡥ࠯࠰࠱ࠫਹ"), index + 1, dixie.ICON])
        l1l11ll_opy_.append(l1l1l_opy_ (u"ࠧࡢࡦࡧࡑࡴࡸࡥࠨ਺"))
    return options, l1l11ll_opy_
if __name__ == l1l1l_opy_ (u"ࠨࡡࡢࡱࡦ࡯࡮ࡠࡡࠪ਻"):
    checkAddons()