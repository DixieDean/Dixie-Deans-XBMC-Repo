# coding: UTF-8
import sys
l1l1lll1_opy_ = sys.version_info [0] == 2
l11l111_opy_ = 2048
l1lll11l_opy_ = 7
def l1l1l_opy_ (l1l11l_opy_):
	global l11l1l1_opy_
	l1111l1_opy_ = ord (l1l11l_opy_ [-1])
	l1ll1111_opy_ = l1l11l_opy_ [:-1]
	l1l11l1_opy_ = l1111l1_opy_ % len (l1ll1111_opy_)
	l11l1l_opy_ = l1ll1111_opy_ [:l1l11l1_opy_] + l1ll1111_opy_ [l1l11l1_opy_:]
	if l1l1lll1_opy_:
		l111l_opy_ = unicode () .join ([unichr (ord (char) - l11l111_opy_ - (l1lll_opy_ + l1111l1_opy_) % l1lll11l_opy_) for l1lll_opy_, char in enumerate (l11l1l_opy_)])
	else:
		l111l_opy_ = str () .join ([chr (ord (char) - l11l111_opy_ - (l1lll_opy_ + l1111l1_opy_) % l1lll11l_opy_) for l1lll_opy_, char in enumerate (l11l1l_opy_)])
	return eval (l111l_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
import mapping
ADDON    = dixie.ADDON
l1_opy_ = dixie.PROFILE
l111l1l_opy_  = os.path.join(l1_opy_, l1l1l_opy_ (u"ࠫ࡮ࡴࡩࠨࠀ"))
l11111_opy_    = os.path.join(l111l1l_opy_, l1l1l_opy_ (u"ࠬࡳࡡࡱࡲ࡬ࡲ࡬ࡹ࠮࡫ࡵࡲࡲࠬࠁ"))
l11l11_opy_   = os.path.join(l111l1l_opy_, l1l1l_opy_ (u"࠭࡭ࡢࡲࡶ࠲࡯ࡹ࡯࡯ࠩࠂ"))
LABELFILE  = os.path.join(l111l1l_opy_, l1l1l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱࡹ࠮࡫ࡵࡲࡲࠬࠃ"))
l1l111ll_opy_ = os.path.join(l111l1l_opy_, l1l1l_opy_ (u"ࠨࡲࡵࡩ࡫࡯ࡸࡦࡵ࠱࡮ࡸࡵ࡮ࠨࠄ"))
l1ll1lll_opy_  = json.load(open(l11111_opy_))
l1ll111l_opy_      = json.load(open(l11l11_opy_))
labelmaps = json.load(open(LABELFILE))
l111_opy_  = json.load(open(l1l111ll_opy_))
l1l1lll_opy_ = l1l1l_opy_ (u"ࠩࠪࠅ")
def l1l1l1_opy_(i, t1, l1l1ll_opy_=[]):
 t = l1l1lll_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l1ll_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11_opy_ = l1l1l1_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l1l111_opy_ = l1l1l1_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1ll111_opy_       = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡧࡪࡺࡶࠨࠆ")
l1l1l1ll_opy_  = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡆࡱࡧࡣ࡬ࡋࡦࡩ࡙࡜ࠧࠇ")
dexter    = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸࠨࠈ")
l1lll1_opy_   = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡋ࡮ࡥ࡮ࡨࡷࡸ࠭ࠉ")
l1llll_opy_       = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡦࡢࡤ࡫ࡳࡸࡺࡩ࡯ࡩࠪࠊ")
l1ll1ll1_opy_  = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡇ࡮ࡤࡻࡱ࡫ࡳࡴࡖࡹࠫࠋ")
l1l1l111_opy_  = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡨࡵࡩࡪࡼࡩࡦࡹࠪࠌ")
l1ll1l_opy_    = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡪࡩ࡭ࡵࡳࡵ࡫ࡱ࡫ࠬࠍ")
l1l1ll1l_opy_   = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡬ࡴࡸࡩࡻࡱࡱ࡭ࡵࡺࡶࠨࠎ")
l1ll1_opy_  = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶࡴࡷࡵࡸࡦࡸ࠭ࠏ")
l11ll11_opy_      = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡰࡩ࡯ࡺࡷࡺ࠷࠭ࠐ")
l1l1l1l1_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡌࡪ࡯࡬ࡸࡱ࡫ࡳࡴࡋࡓࡘ࡛࠭ࠑ")
l11l_opy_  = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡮ࡣࡷࡶ࡮ࡾࡩࡳࡧ࡯ࡥࡳࡪࠧࠒ")
l1llll1l_opy_  = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡏࡤࡸࡸࡈࡵࡪ࡮ࡧࡷࡎࡖࡔࡗࠩࠓ")
l1l11ll1_opy_   = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡰࡥࡽ࡯ࡷࡦࡤࡷࡺࠬࠔ")
l11ll1l_opy_     = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡱࡨࡱࡴࡷ࠯ࡳࡰࡺࡹࠧࠕ")
l1111ll_opy_      = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡲ࡫ࡧࡢ࡫ࡳࡸࡻ࠭ࠖ")
l1l11lll_opy_  = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡶࡳࡢࡦࡧࡳࡳ࠭ࠗ")
root      = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡰࡱࡷࡍࡕ࡚ࡖࠨ࠘")
l1llll1_opy_      = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡥࡷࡺࠬ࠙")
l111l11_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡕࡸࡴࡷ࡫࡭ࡢࡥࡼࡘ࡛࠭ࠚ")
l1lllll1_opy_   = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡸࡷ࡫ࡡ࡮ࡵࡸࡴࡷ࡫࡭ࡦ࠴ࠪࠛ")
l11lll1_opy_   = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡸࡼ࡯ࡳࡵࡧࡧࠫࠜ")
l11llll_opy_   = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡹࡼ࡫ࡪࡰࡪࡷࠬࠝ")
l1l1111_opy_    = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡻ࡫ࡵࡷࡵ࡯ࠬࠞ")
l1l_opy_     = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡖࡂࡆࡈࡖࠬࠟ")
l1lll1l1_opy_   = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡹࡶࡵࡩࡦࡳ࠭ࡤࡱࡧࡩࡸ࠭ࠠ")
l111111_opy_    = [l1ll1l_opy_, l11llll_opy_, l11l_opy_, l1lll1l1_opy_, l1llll1_opy_, l1lllll1_opy_, l1l1111_opy_, l1l1l1l1_opy_, l1llll_opy_,l1ll111_opy_, l1l1ll1l_opy_, root, l1111ll_opy_, l1l1l111_opy_, l1ll1_opy_, l11ll11_opy_, l1lll1_opy_, l1ll1ll1_opy_, l1l11ll1_opy_, dexter, l1l_opy_, l111l11_opy_, l11ll1l_opy_, l11lll1_opy_, l1l11lll_opy_, l1l1l1ll_opy_]
def checkAddons():
    for addon in l111111_opy_:
        if l1l1llll_opy_(addon):
            try: createINI(addon)
            except: continue
def l1l1llll_opy_(addon):
    if xbmc.getCondVisibility(l1l1l_opy_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡋࡥࡸࡇࡤࡥࡱࡱࠬࠪࡹࠩࠨࠡ") % addon) == 1:
        dixie.log(l1l1l_opy_ (u"ࠪࡁࡂࡃ࠽ࠡࡣࡧࡨࡴࡴࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡁࡂࡃ࠽ࠨࠢ"))
        dixie.log(addon)
        return True
    return False
def createINI(addon):
    l1l111l1_opy_  = str(addon).split(l1l1l_opy_ (u"ࠫ࠳࠭ࠣ"))[2] + l1l1l_opy_ (u"ࠬ࠴ࡩ࡯࡫ࠪࠤ")
    l1l1l11_opy_   = os.path.join(l111l1l_opy_, l1l111l1_opy_)
    response = l1llllll_opy_(addon)
    l1l111l_opy_ = response[l1l1l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࠥ")][l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࠦ")]
    l1ll11_opy_  = l1l1l_opy_ (u"ࠨ࡝ࠪࠧ") + addon + l1l1l_opy_ (u"ࠩࡠࡠࡳ࠭ࠨ")
    l1lll1ll_opy_  =  file(l1l1l11_opy_, l1l1l_opy_ (u"ࠪࡻࠬࠩ"))
    l1lll1ll_opy_.write(l1ll11_opy_)
    l1l1ll11_opy_ = []
    for channel in l1l111l_opy_:
        l1111l_opy_ = l1l1ll1_opy_(addon)
        l11lll_opy_  = channel[l1l1l_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪࠪ")].split(l1l1l_opy_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࠫ"), 1)[0]
        if addon == dexter:
            l11lll_opy_ = l11lll_opy_.split(l1l1l_opy_ (u"࠭ࠠࠬࠢࠪࠬ"), 1)[0]
        if (addon == root) or (addon == l1l1l1l1_opy_) or (addon == l11llll_opy_) or (addon == l1ll1l_opy_):
            l11lll_opy_ = l11lll_opy_.split(l1l1l_opy_ (u"ࠧࠡ࠯ࠣࠫ࠭"), 1)[0]
        l1111_opy_ = l11l1_opy_(addon, l11lll_opy_)
        l11ll1_opy_ = l11111l_opy_(addon, l111_opy_, labelmaps, l1ll1lll_opy_, l1ll111l_opy_, l11lll_opy_)
        stream  = l1111l_opy_ + l1111_opy_
        l111ll_opy_ = l11ll1_opy_  + l1l1l_opy_ (u"ࠨ࠿ࠪ࠮") + stream
        if l111ll_opy_ not in l1l1ll11_opy_:
            l1l1ll11_opy_.append(l111ll_opy_)
    l1l1ll11_opy_.sort()
    for item in l1l1ll11_opy_:
        l1lll1ll_opy_.write(l1l1l_opy_ (u"ࠤࠨࡷࡡࡴࠢ࠯") % item)
    l1lll1ll_opy_.close()
def l11l1_opy_(addon, l11lll_opy_):
    if (addon == root) or (addon == l1l1l1l1_opy_) or (addon == l1llll_opy_) or (addon == l1lll1l1_opy_) or (addon == l11l_opy_) or (addon == l11llll_opy_) or (addon == l1ll1l_opy_):
        l1l1l1l_opy_ = mapping.cleanLabel(l11lll_opy_)
        l1111_opy_ = mapping.editPrefix(l111_opy_, l1l1l1l_opy_)
        return l1111_opy_
    l1l1l1l_opy_ = mapping.cleanLabel(l11lll_opy_)
    l1111_opy_ = mapping.cleanStreamLabel(l1l1l1l_opy_)
    return l1111_opy_
def l11111l_opy_(addon, l111_opy_, labelmaps, l1ll1lll_opy_, l1ll111l_opy_, l11lll_opy_):
    if (addon == root) or (addon == l1l1l1l1_opy_) or (addon == l1llll_opy_) or (addon == l1lll1l1_opy_) or (addon == l11l_opy_) or (addon == l11llll_opy_) or (addon == l1ll1l_opy_):
        return l1l1l11l_opy_(l111_opy_, l1ll111l_opy_, l11lll_opy_)
    l1lllll_opy_    = mapping.cleanLabel(l11lll_opy_)
    l1l1l1l_opy_ = mapping.mapLabel(labelmaps, l1lllll_opy_)
    l11ll1_opy_ = mapping.cleanPrefix(l1l1l1l_opy_)
    return mapping.mapChannelName(l1ll1lll_opy_, l11ll1_opy_)
def l1l1l11l_opy_(l111_opy_, l1ll111l_opy_, l11lll_opy_):
    l1l1_opy_ = mapping.cleanLabel(l11lll_opy_)
    l1l1l1l_opy_   = mapping.editPrefix(l111_opy_, l1l1_opy_)
    l11l11l_opy_   = mapping.mapEPGLabel(l111_opy_, l1ll111l_opy_, l1l1l1l_opy_)
    return l11l11l_opy_
def l1ll_opy_(addon, file):
    l1lllll_opy_ = file[l1l1l_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩ࠰")].split(l1l1l_opy_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࠱"), 1)[0]
    l1lllll_opy_ = l1lllll_opy_.split(l1l1l_opy_ (u"ࠬ࠱ࠧ࠲"), 1)[0]
    l1lllll_opy_ = mapping.cleanLabel(l1lllll_opy_)
    return l1lllll_opy_
def l1l1ll1_opy_(addon):
    if addon == l1ll1l_opy_:
        return l1l1l_opy_ (u"࠭ࡇࡆࡊ࠽ࠫ࠳")
    if addon == l11llll_opy_:
        return l1l1l_opy_ (u"ࠧࡕࡘࡎ࠾ࠬ࠴")
    if addon == l11l_opy_:
        return l1l1l_opy_ (u"ࠨࡏࡗ࡜ࡎࡋ࠺ࠨ࠵")
    if addon == l1lll1l1_opy_:
        return l1l1l_opy_ (u"࡛ࠩࡘࡈࡀࠧ࠶")
    if addon == l1llll1_opy_:
        return l1l1l_opy_ (u"ࠪࡗࡈ࡚ࡖ࠻ࠩ࠷")
    if addon == l1lllll1_opy_:
        return l1l1l_opy_ (u"ࠫࡘ࡛ࡐ࠻ࠩ࠸")
    if addon == l1l1111_opy_:
        return l1l1l_opy_ (u"࡛ࠬࡋࡕ࠼ࠪ࠹")
    if addon == l1l1l1l1_opy_:
        return l1l1l_opy_ (u"࠭ࡌࡊࡏࡌࡘ࠿࠭࠺")
    if addon == l1llll_opy_:
        return l1l1l_opy_ (u"ࠧࡇࡃࡅ࠾ࠬ࠻")
    if addon == l1ll111_opy_:
        return l1l1l_opy_ (u"ࠨࡃࡆࡉ࠿࠭࠼")
    if addon == l1l1ll1l_opy_:
        return l1l1l_opy_ (u"ࠩࡋࡓࡗࡏ࡚࠻ࠩ࠽")
    if addon == root:
        return l1l1l_opy_ (u"ࠪࡖࡔࡕࡔ࠳࠼ࠪ࠾")
    if addon == l1111ll_opy_:
        return l1l1l_opy_ (u"ࠫࡒࡋࡇࡂ࠼ࠪ࠿")
    if addon == l1l1l111_opy_:
        return l1l1l_opy_ (u"ࠬࡌࡒࡆࡇ࠽ࠫࡀ")
    if addon == l1llll1l_opy_:
        return l1l1l_opy_ (u"࠭ࡍࡂࡖࡖ࠾ࠬࡁ")
    if addon == l1ll1_opy_:
        return l1l1l_opy_ (u"ࠧࡊࡒࡗࡗ࠿࠭ࡂ")
    if addon == l11ll11_opy_:
        return l1l1l_opy_ (u"ࠨࡌࡌࡒ࡝࠸࠺ࠨࡃ")
    if addon == l1lll1_opy_:
        return l1l1l_opy_ (u"ࠩࡈࡒࡉࡀࠧࡄ")
    if addon == l1ll1ll1_opy_:
        return l1l1l_opy_ (u"ࠪࡊࡑࡇ࠺ࠨࡅ")
    if addon == l1l11ll1_opy_:
        return l1l1l_opy_ (u"ࠫࡒࡇࡘࡊ࠼ࠪࡆ")
    if addon == dexter:
        return l1l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡈ࠿࠭ࡇ")
    if addon == l1l_opy_:
        return l1l1l_opy_ (u"࠭ࡖࡅࡔࡗ࡚࠿࠭ࡈ")
    if addon == l111l11_opy_:
        return l1l1l_opy_ (u"ࠧࡔࡒࡕࡑ࠿࠭ࡉ")
    if addon == l11ll1l_opy_:
        return l1l1l_opy_ (u"ࠨࡏࡆࡏ࡙࡜࠺ࠨࡊ")
    if addon == l11lll1_opy_:
        return l1l1l_opy_ (u"ࠩࡗ࡛ࡎ࡙ࡔ࠻ࠩࡋ")
    if addon == l1l11lll_opy_:
        return l1l1l_opy_ (u"ࠪࡔࡗࡋࡓࡕ࠼ࠪࡌ")
    if addon == l1l1l1ll_opy_:
        return l1l1l_opy_ (u"ࠫࡇࡒࡋࡊ࠼ࠪࡍ")
def getURL(url):
    if url.startswith(l1l1l_opy_ (u"ࠬࡍࡅࡉࠩࡎ")):
        return ll_opy_(url, l1ll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡔࡗࡍࠪࡏ")):
        return ll_opy_(url, l11llll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡎࡖ࡛ࡍࡊ࠭ࡐ")):
        return ll_opy_(url, l11l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨ࡚ࡗࡇࠬࡑ")):
        return ll_opy_(url, l1lll1l1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡖࡇ࡙࡜ࠧࡒ")):
        return ll_opy_(url, l1llll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡗ࡚ࡖࠧࡓ")):
        return ll_opy_(url, l1lllll1_opy_)
    if url.startswith(l1l1l_opy_ (u"࡚ࠫࡑࡔࠨࡔ")):
        return ll_opy_(url, l1l1111_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡒࡉࡎࡋࡗࠫࡕ")):
        return ll_opy_(url, l1l1l1l1_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡆࡂࡄࠪࡖ")):
        return ll_opy_(url, l1llll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡂࡅࡈࠫࡗ")):
        return ll_opy_(url, l1ll111_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡊࡒࡖࡎࡠࠧࡘ")):
        return ll_opy_(url, l1l1ll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡕࡓࡔ࡚࠲ࠨ࡙")):
        return ll_opy_(url, root)
    if url.startswith(l1l1l_opy_ (u"ࠪࡑࡊࡍࡁࠨ࡚")):
        return ll_opy_(url, l1111ll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡋࡘࡅࡆ࡛ࠩ")):
        return ll_opy_(url, l1l1l111_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡇࡑ࡛࠺ࠨ࡜")):
        url = url.replace(l1l1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡈࡒࡕ࠻ࠩ࡝"), l1l1l_opy_ (u"ࠧࠨ࡞")).replace(l1l1l_opy_ (u"ࠨ࠯࠰ࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧ࡟"), l1l1l_opy_ (u"ࠩࡿࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧࡠ"))
        return url
    if url.startswith(l1l1l_opy_ (u"ࠪࡑࡆ࡚ࡓࠨࡡ")):
        return ll_opy_(url, l1llll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡎࡖࡔࡔࠩࡢ")):
        return ll_opy_(url, l1ll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡐࡉࡏ࡚࠵ࠫࡣ")):
        return ll_opy_(url, l11ll11_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡉ࠭ࡤ")):
        return ll_opy_(url, dexter)
    if url.startswith(l1l1l_opy_ (u"ࠧࡇࡎࡄࠫࡥ")):
        return ll_opy_(url, l1ll1ll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡏࡄ࡜ࡎ࠭ࡦ")):
        return ll_opy_(url, l1l11ll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡈࡒࡉ࠭ࡧ")):
        return ll_opy_(url, l1lll1_opy_)
    if url.startswith(l1l1l_opy_ (u"࡚ࠪࡉࡘࡔࡗࠩࡨ")):
        return ll_opy_(url, l1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡘࡖࡒࡎࠩࡩ")):
        return ll_opy_(url, l111l11_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡓࡃࡌࡖ࡙ࠫࡪ")):
        return ll_opy_(url, l11ll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡔࡘࡋࡖࡘࠬ࡫")):
        return ll_opy_(url, l11lll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡑࡔࡈࡗ࡙࠭࡬")):
        return ll_opy_(url, l1l11lll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡄࡏࡏࡎ࠭࡭")):
        return ll_opy_(url, l1l1l1ll_opy_)
    response  = l1l1111l_opy_(url)
    l1lll11_opy_ = url.split(l1l1l_opy_ (u"ࠩ࠽ࠫ࡮"), 1)[-1]
    l1lll11_opy_ = l1lll11_opy_.upper().replace(l1l1l_opy_ (u"ࠪࠤࠬ࡯"), l1l1l_opy_ (u"ࠫࠬࡰ"))
    try:
        result = response[l1l1l_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬࡱ")]
        l11l1ll_opy_  = result[l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬࡲ")]
    except Exception as e:
        l1l11l1l_opy_(e)
        return None
    for file in l11l1ll_opy_:
        l11lll_opy_  = file[l1l1l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ࡳ")].split(l1l1l_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࡴ"), 1)[0]
        l1ll1ll_opy_  = l11lll_opy_.split(l1l1l_opy_ (u"ࠩ࠮ࠫࡵ"), 1)[0]
        l1ll1l1_opy_ = mapping.cleanLabel(l1ll1ll_opy_)
        l1ll1l1_opy_ = l1ll1l1_opy_.upper().replace(l1l1l_opy_ (u"ࠪࠤࠬࡶ"), l1l1l_opy_ (u"ࠫࠬࡷ"))
        try:
            if l1lll11_opy_ == l1ll1l1_opy_:
                return file[l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪࡸ")]
        except:
            if (l1lll11_opy_ in l1ll1l1_opy_) or (l1ll1l1_opy_ in l1lll11_opy_):
                return file[l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࠫࡹ")]
    return None
def ll_opy_(url, addon):
    PATH = l1llll11_opy_(addon)
    try:
        response = json.load(open(PATH))
    except:
        response = l1llllll_opy_(addon)
    l1l11ll_opy_      = url.split(l1l1l_opy_ (u"ࠧ࠻ࠩࡺ"), 1)[-1]
    stream    = l1l11ll_opy_.split(l1l1l_opy_ (u"ࠨࠢ࡞ࠫࡻ"), 1)[0]
    l1lll11_opy_ = mapping.cleanLabel(stream)
    l1lll11_opy_ = l1lll11_opy_.upper().replace(l1l1l_opy_ (u"ࠩࠣࠫࡼ"), l1l1l_opy_ (u"ࠪࠫࡽ"))
    l11l1ll_opy_  = response[l1l1l_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫࡾ")][l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫࡿ")]
    for file in l11l1ll_opy_:
        l11lll_opy_  = file[l1l1l_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬࢀ")].split(l1l1l_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࢁ"), 1)[0]
        if addon == dexter:
            l11lll_opy_ = l11lll_opy_.split(l1l1l_opy_ (u"ࠨࠢ࠮ࠤࠬࢂ"), 1)[0]
        if (addon == root) or (addon == l1l1l1l1_opy_) or (addon == l11llll_opy_) or (addon == l1ll1l_opy_):
            l11lll_opy_ = l11lll_opy_.split(l1l1l_opy_ (u"ࠩࠣ࠱ࠥ࠭ࢃ"), 1)[0]
        l1ll1l1_opy_ = l11l1_opy_(addon, l11lll_opy_)
        l1ll1l1_opy_ = l1ll1l1_opy_.upper().replace(l1l1l_opy_ (u"ࠪࠤࠬࢄ"), l1l1l_opy_ (u"ࠫࠬࢅ"))
        try:
            if l1lll11_opy_ == l1ll1l1_opy_:
                return file[l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪࢆ")]
        except:
            if (l1lll11_opy_ in l1ll1l1_opy_) or (l1ll1l1_opy_ in l1lll11_opy_):
                return file[l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࠫࢇ")]
    return None
def l1llllll_opy_(addon):
    PATH  = l1llll11_opy_(addon)
    if addon == l1l_opy_:
        query = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡘࡄࡈࡊࡘ࠯࡭࡫ࡹࡩࡹࡼ࠯ࡢ࡮࡯࠳ࠬ࢈")
    elif addon == l1lllll1_opy_:
        query = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡸࡷ࡫ࡡ࡮ࡵࡸࡴࡷ࡫࡭ࡦ࠴࠲ࡰ࡮ࡼࡥࡵࡸ࠲ࡥࡱࡲ࠯ࠨࢉ")
    elif addon == l1llll1_opy_:
        query = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡨࡺࡶ࠰࡮࡬ࡺࡪࡺࡶ࠰ࡣ࡯ࡰ࠴࠭ࢊ")
    elif addon == l1lllll1_opy_:
        query = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡺࡲࡦࡣࡰࡷࡺࡶࡲࡦ࡯ࡨ࠶࠴ࡲࡩࡷࡧࡷࡺ࠴ࡧ࡬࡭࠱ࠪࢋ")
    elif addon == l1l1l111_opy_:
        query = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡬ࡲࡦࡧࡹ࡭ࡪࡽ࠯ࡀࡷࡵࡰࡂࡻࡲ࡭ࠨࡰࡳࡩ࡫࠽࠶ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡹࡩ࠰࡚ࡖࠨࢌ")
    elif addon == l1l1111_opy_:
        query = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡵ࡬ࡶࡸࡶࡰ࠵࠿ࡶࡴ࡯ࡁ࡭ࡺࡴࡱࠧ࠶ࡅࠪ࠸ࡆࠦ࠴ࡉࡥࡩࡪ࡯࡯ࡥ࡯ࡳࡺࡪ࠮ࡰࡴࡪࠩ࠷ࡌࡵ࡬ࡶࡸࡶࡰࠫ࠲ࡇࡗࡎࡘࡺࡸ࡫ࠦ࠴ࡉࡐ࡮ࡼࡥࠦ࠴࠸࠶࠵࡚ࡖ࠯ࡶࡻࡸࠫࡳ࡯ࡥࡧࡀ࠵ࠫࡴࡡ࡮ࡧࡀࡐ࡮ࡼࡥࠬࡖ࡙ࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠩࡪࡦࡴࡡࡳࡶࡀࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠨࢍ")
    else:
        query = l1lll111_opy_(addon)
    try:
        return json.load(open(PATH))
    except:
        content = doJSON(query)
        return l1l11_opy_(PATH, addon, content)
def l1l11_opy_(PATH, addon, content):
    json.dump(content, open(PATH,l1l1l_opy_ (u"࠭ࡷࠨࢎ")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    l1ll11l_opy_  = (l1l1l_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ࢏") % query)
    response = xbmc.executeJSONRPC(l1ll11l_opy_)
    content  = json.loads(response)
    return content
def l1llll11_opy_(addon):
    if addon == l1ll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡩࡨࡸࡪࡳࡰࠨ࢐"))
    if addon == l11l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡰࡸࡽࡺࡥ࡮ࡲࠪ࢑"))
    if addon == l11llll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡸࡻࡱࡴࡦ࡯ࡳࠫ࢒"))
    if addon == l1lll1l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡽࡺࡥ࡮ࡲࠪ࢓"))
    if addon == l1llll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡹࡣࡵࡧࡰࡴࠬ࢔"))
    if addon == l1lllll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡳࡶࡲࡷࡩࡲࡶࠧ࢕"))
    if addon == l1l1111_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡶ࡭ࡷࡸࡪࡳࡰࠨ࢖"))
    if addon == l1l1l1l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨ࡮࡬ࡱ࡮ࡺࡥ࡮ࡲࠪࢗ"))
    if addon == l1llll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡩࡥࡧࡺࡥ࡮ࡲࠪ࢘"))
    if addon == l1ll111_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡥࡨ࡫ࡴࡦ࡯ࡳ࢙ࠫ"))
    if addon == l1l1ll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫ࡭ࡵࡲࡵࡧࡰࡴ࢚ࠬ"))
    if addon == root:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡸ࡯࠳ࡶࡨࡱࡵ࢛࠭"))
    if addon == l1111ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭࡭ࡦࡩࡤࡸࡲࡶࠧ࢜"))
    if addon == l1llll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧ࡮ࡣࡷࡷࡹࡳࡰࠨ࢝"))
    if addon == l1l1l111_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡨࡵࡩࡪࡺ࡭ࡱࠩ࢞"))
    if addon == l1ll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩ࡬ࡴࡹࡹࡴ࡮ࡲࠪ࢟"))
    if addon == l11ll11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪ࡮࠷ࡺࡥ࡮ࡲࠪࢠ"))
    if addon == l1lll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡪࡺࡥ࡮ࡲࠪࢡ"))
    if addon == l1ll1ll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬ࡬ࡴࡦ࡯ࡳࠫࢢ"))
    if addon == l1l11ll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭࡭ࡢࡺࡷࡩࡲࡶࠧࢣ"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡥࡶࡨࡱࡵ࠭ࢤ"))
    if addon == l1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡸࡧࡸࡪࡳࡰࠨࢥ"))
    if addon == l111l11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡶࡴࡷࡺࡥ࡮ࡲࠪࢦ"))
    if addon == l11ll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡱࡨࡱࡴࡦ࡯ࡳࠫࢧ"))
    if addon == l11lll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡹࡽࡩࡵࡧࡰࡴࠬࢨ"))
    if addon == l1l11lll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡶࡲࡦࡵࡷࡩࡲࡶࠧࢩ"))
    if addon == l1l1l1ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡢ࡭࡭࡬ࡸࡪࡳࡰࠨࢪ"))
def l1lll111_opy_(addon):
    query = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪࢫ") + addon
    response = doJSON(query)
    l11l1ll_opy_    = response[l1l1l_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨࢬ")][l1l1l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨࢭ")]
    for file in l11l1ll_opy_:
        l111lll_opy_ = file[l1l1l_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࢮ")]
        l1lllll_opy_ = mapping.cleanLabel(l111lll_opy_)
        l1lllll_opy_ = l1lllll_opy_.upper()
        if (l1lllll_opy_ == l1l1l_opy_ (u"ࠫࡑࡏࡖࡆࠢࡌࡔ࡙࡜ࠧࢯ")) or (l1lllll_opy_ == l1l1l_opy_ (u"ࠬࡒࡉࡗࡇࠣࡘ࡛࠭ࢰ")) or (l1lllll_opy_ == l1l1l_opy_ (u"࠭ࡌࡊࡘࡈࠤࡈࡎࡁࡏࡐࡈࡐࡘ࠭ࢱ")) or (l1lllll_opy_ == l1l1l_opy_ (u"ࠧࡍࡋ࡙ࡉࠬࢲ")) or (l1lllll_opy_ == l1l1l_opy_ (u"ࠨࡇࡑࡈࡑࡋࡓࡔࠢࡐࡉࡉࡏࡁࠨࢳ")) or (l1lllll_opy_ == l1l1l_opy_ (u"ࠩࡉࡐࡆ࡝ࡌࡆࡕࡖࡘ࡛࠭ࢴ")) or (l1lllll_opy_ == l1l1l_opy_ (u"ࠪࡑࡆ࡞ࡉࡘࡇࡅࠤ࡙࡜ࠧࢵ")) or (l1lllll_opy_ == l1l1l_opy_ (u"ࠫࡇࡒࡁࡄࡍࡌࡇࡊࠦࡔࡗࠩࢶ")) or (l1lllll_opy_ == l1l1l_opy_ (u"ࠬࡎࡏࡓࡋ࡝ࡓࡓࠦࡉࡑࡖ࡙ࠫࢷ")) or (l1lllll_opy_ == l1l1l_opy_ (u"࠭ࡆࡂࡄࠣࡍࡕ࡚ࡖࠨࢸ")):
            livetv = file[l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࠬࢹ")]
            return l111l1_opy_(livetv)
def l111l1_opy_(livetv):
    response = doJSON(livetv)
    l11l1ll_opy_    = response[l1l1l_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨࢺ")][l1l1l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨࢻ")]
    for file in l11l1ll_opy_:
        l111lll_opy_ = file[l1l1l_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࢼ")]
        l1lllll_opy_ = mapping.cleanLabel(l111lll_opy_)
        l1lllll_opy_ = l1lllll_opy_.upper()
        if l1lllll_opy_ == l1l1l_opy_ (u"ࠫࡆࡒࡌࠨࢽ"):
            return file[l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪࢾ")]
def l1lll1l_opy_(l11ll_opy_):
    items = []
    _111ll1_opy_(l11ll_opy_, items)
    return items
def _111ll1_opy_(l11ll_opy_, items):
    response = doJSON(l11ll_opy_)
    if response[l1l1l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࢿ")].has_key(l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࣀ")):
        result = response[l1l1l_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨࣁ")][l1l1l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨࣂ")]
        for item in result:
            if item[l1l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬࣃ")] == l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࠩࣄ"):
                l1lllll_opy_ = mapping.cleanLabel(item[l1l1l_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫࣅ")])
                items.append(item)
            elif item[l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨࣆ")] == l1l1l_opy_ (u"ࠧࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠪࣇ"):
                l1lllll_opy_ = mapping.cleanLabel(item[l1l1l_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࣈ")])
                l1l11l11_opy_  = item[l1l1l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧࣉ")]
                dixie.log(item)
                dixie.log(l1l11l11_opy_)
                _111ll1_opy_(l1l11l11_opy_, items)
def l1l1111l_opy_(url):
    if url.startswith(l1l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠼ࠪ࣊")):
        l1ll11l_opy_ = (l1l1l_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡣࡤࡦ࡭ࡵࡲࡡࡺࡧࡵ࠳ࡄࡻࡲ࡭࠿ࡸࡶࡱࠬ࡭ࡰࡦࡨࡁ࠷ࠬ࡮ࡢ࡯ࡨࡁࡑ࡯ࡶࡦࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࡁࠫࡏࡐࡊࡆࡀࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ࣋"))
    if url.startswith(l1l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜࠶࠿࠭࣌")):
        l1ll11l_opy_ = (l1l1l_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠵࠿ࡶࡴ࡯ࡁࡺࡸ࡬ࠧ࡯ࡲࡨࡪࡃ࠱࠱࠳ࠩࡲࡦࡳࡥ࠾࡙ࡤࡸࡨ࡮ࠫࡍ࡫ࡹࡩࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴ࠽ࠧࡵࡸࡦࡹ࡯ࡴ࡭ࡧࡶࡣࡺࡸ࡬࠾ࠨ࡯ࡳ࡬࡭ࡥࡥࡡ࡬ࡲࡂࡌࡡ࡭ࡵࡨࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ࣍"))
    if url.startswith(l1l1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡘ࠺ࠨ࣎")):
        l1ll11l_opy_ = (l1l1l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶ࡬ࡢࡻࡨࡶࡼࡽࡷ࠰ࡁࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠦ࡭ࡱࡪ࡫ࡪࡪ࡟ࡪࡰࡀࡊࡦࡲࡳࡦࠨࡰࡳࡩ࡫࠽࠲࠳࠶ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡸࡺࡥ࡯ࠧ࠵࠴ࡑ࡯ࡶࡦࠨࡶࡹࡧࡺࡩࡵ࡮ࡨࡷࡤࡻࡲ࡭ࠨࡸࡶࡱࡃࡵࡳ࡮ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ࣏"))
    if url.startswith(l1l1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡊࡖ࡙࠾࣐ࠬ")):
        l1ll11l_opy_ = (l1l1l_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡵࡸࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ࣑"))
    if url.startswith(l1l1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡇ࠾࣒ࠬ")):
        l1ll11l_opy_ = (l1l1l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡦࡨࡼ࠴ࡅࡡࡤࡶ࡬ࡳࡳࡃࡡ࡭࡮ࠩࡩࡽࡺࡲࡢࠨࡳࡥ࡬࡫ࠦࡱ࡮ࡲࡸࠫࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠾ࠨࡷ࡭ࡹࡲࡥ࠾ࠧ࠸ࡦࡈࡕࡌࡐࡔࠨ࠶࠵ࡽࡨࡪࡶࡨࠩ࠺ࡪࡁ࡭࡮ࠨ࠶࠵ࡉࡨࡢࡰࡱࡩࡱࡹࠥ࠶ࡤࠨ࠶࡫ࡉࡏࡍࡑࡕࠩ࠺ࡪࠦࡶࡴ࡯ࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾ࣓ࠩ"))
    if url.startswith(l1l1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡗࡈ࠺ࠨࣔ")):
        l1ll11l_opy_ = (l1l1l_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡪࡨ࡯ࡰࡶ࠲ࡃࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠨࡩࡥࡳࡧࡲࡵ࠿ࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦ࡮ࡱࡧࡩࡂ࠽ࠦࡱ࡫࡯ࡰࡴࡽ࠽ࡍ࡫ࡹࡩࠪ࠸࠰ࡔࡶࡵࡩࡦࡳࡳࠧࡷࡵࡰࡂࡸࡡ࡯ࡦࡲࡱࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࣕ"))
    try:
        dixie.ShowBusy()
        addon =  l1ll11l_opy_.split(l1l1l_opy_ (u"ࠨ࠱࠲ࠫࣖ"), 1)[-1].split(l1l1l_opy_ (u"ࠩ࠲ࠫࣗ"), 1)[0]
        login = l1l1l_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠦࡵࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨࣘ") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1ll11l_opy_)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1l11l1l_opy_(e)
        return {l1l1l_opy_ (u"ࠫࡊࡸࡲࡰࡴࠪࣙ") : l1l1l_opy_ (u"ࠬࡖ࡬ࡶࡩ࡬ࡲࠥࡋࡲࡳࡱࡵࠫࣚ")}
def l1ll11l1_opy_():
    modules = map(__import__, [l1l1l1_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l1l1l_opy_ (u"࠭ࡔࡳࡷࡨࠫࣛ")
    if len(modules[-1].Window(10**4).getProperty(l1l111_opy_)):
        return l1l1l_opy_ (u"ࠧࡕࡴࡸࡩࠬࣜ")
    return l1l1l_opy_ (u"ࠨࡈࡤࡰࡸ࡫ࠧࣝ")
def l1l11l1l_opy_(e):
    l1ll11ll_opy_ = l1l1l_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠭ࠢࡤࡲࠥ࡫ࡲࡳࡱࡵࠤࡴࡩࡣࡶࡴࡨࡨ࠿ࠦࡊࡔࡑࡑࠤࡊࡸࡲࡰࡴ࠽ࠤࠪࡹࠧࣞ")  %e
    l1ll1l11_opy_ = l1l1l_opy_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡶࡪ࠳࡬ࡪࡰ࡮ࠤࡹ࡮ࡩࡴࠢࡦ࡬ࡦࡴ࡮ࡦ࡮ࠣࡥࡳࡪࠠࡵࡴࡼࠤࡦ࡭ࡡࡪࡰ࠱ࠫࣟ")
    l1ll1l1l_opy_ = l1l1l_opy_ (u"࡚ࠫࡹࡥ࠻ࠢࡆࡳࡳࡺࡥࡹࡶࠣࡑࡪࡴࡵࠡ࠿ࡁࠤࡗ࡫࡭ࡰࡸࡨࠤࡘࡺࡲࡦࡣࡰࠫ࣠")
    dixie.log(e)
    dixie.DialogOK(l1ll11ll_opy_, l1ll1l11_opy_, l1ll1l1l_opy_)
if __name__ == l1l1l_opy_ (u"ࠬࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠧ࣡"):
    checkAddons()