# coding: UTF-8
import sys
l1l11ll_opy_ = sys.version_info [0] == 2
l1l11l1_opy_ = 2048
l1l1ll_opy_ = 7
def l1lll11_opy_ (ll_opy_):
	global l1ll1l_opy_
	l1lll11l_opy_ = ord (ll_opy_ [-1])
	l1l1ll1_opy_ = ll_opy_ [:-1]
	l111l1l_opy_ = l1lll11l_opy_ % len (l1l1ll1_opy_)
	l111111_opy_ = l1l1ll1_opy_ [:l111l1l_opy_] + l1l1ll1_opy_ [l111l1l_opy_:]
	if l1l11ll_opy_:
		l11ll11_opy_ = unicode () .join ([unichr (ord (char) - l1l11l1_opy_ - (l1lllll_opy_ + l1lll11l_opy_) % l1l1ll_opy_) for l1lllll_opy_, char in enumerate (l111111_opy_)])
	else:
		l11ll11_opy_ = str () .join ([chr (ord (char) - l1l11l1_opy_ - (l1lllll_opy_ + l1lll11l_opy_) % l1l1ll_opy_) for l1lllll_opy_, char in enumerate (l111111_opy_)])
	return eval (l11ll11_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
import mapping
ADDON    = dixie.ADDON
l111l1_opy_ = dixie.PROFILE
l11l11_opy_  = os.path.join(l111l1_opy_, l1lll11_opy_ (u"ࠫ࡮ࡴࡩࠨࠀ"))
l1lll1ll_opy_ = l1lll11_opy_ (u"ࠬ࠭ࠁ")
def l1ll111l_opy_(i, t1, l1lll1l1_opy_=[]):
 t = l1lll1ll_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1lll1l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11l1_opy_ = l1ll111l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l111l_opy_ = l1ll111l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1llll11_opy_      = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡳࡥࡨࡣ࡬ࡴࡹࡼࠧࠂ")
l11lll1_opy_  = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡦࡳࡧࡨࡺ࡮࡫ࡷࠨࠃ")
l11_opy_  = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡎࡣࡷࡷࡇࡻࡩ࡭ࡦࡶࡍࡕ࡚ࡖࠨࠄ")
l1lll1l_opy_  = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡸࡻࡹࡵࡣࡵࠪࠅ")
l1l1lll_opy_      = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡭࡭ࡳࡾࡴࡷ࠴ࠪࠆ")
l1ll11l_opy_  = l1lll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡴࡵࡴࡪࡲࡷࡺࠬࠇ")
l11111l_opy_   = l1lll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡊࡴࡤ࡭ࡧࡶࡷࠬࠈ")
l1ll1lll_opy_  = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡌ࡬ࡢࡹ࡯ࡩࡸࡹࡔࡷࠩࠉ")
l11ll1l_opy_   = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡭ࡢࡺ࡬ࡻࡪࡨࡴࡷࠩࠊ")
dexter    = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡥࡧࡻࠫࠋ")
l11ll_opy_     = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡘࡄࡈࡊࡘࠧࠌ")
l11ll1_opy_ = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡖࡹࡵࡸࡥ࡮ࡣࡦࡽ࡙࡜ࠧࠍ")
l1llll1_opy_     = l1lll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡱࡨࡱࡴࡷ࠯ࡳࡰࡺࡹࠧࠎ")
l1llll1l_opy_   = l1lll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡹࡽࡩࡴࡶࡨࡨࠬࠏ")
l11l1ll_opy_  = l1lll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡶࡳࡢࡦࡧࡳࡳ࠭ࠐ")
l1l1l1_opy_  = l1lll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡂ࡭ࡣࡦ࡯ࡎࡩࡥࡕࡘࠪࠑ")
l1ll11l1_opy_    = [l1llll11_opy_, l11lll1_opy_, l11_opy_, l1lll1l_opy_, l1l1lll_opy_, l1ll11l_opy_, l11111l_opy_, l1ll1lll_opy_, l11ll1l_opy_, dexter, l11ll_opy_, l11ll1_opy_, l1llll1_opy_, l1llll1l_opy_, l11l1ll_opy_, l1l1l1_opy_]
def checkAddons():
    for addon in l1ll11l1_opy_:
        if l1ll1l1l_opy_(addon):
            try: createINI(addon)
            except: continue
def l1ll1l1l_opy_(addon):
    if xbmc.getCondVisibility(l1lll11_opy_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫࠩࡸ࠯ࠧࠒ") % addon) == 1:
        dixie.log(l1lll11_opy_ (u"ࠩࡀࡁࡂࡃࠠࡢࡦࡧࡳࡳࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠢࡀࡁࡂࡃࠧࠓ"))
        dixie.log(addon)
        return True
    return False
def createINI(addon):
    HOME  = dixie.PROFILE
    iPATH = os.path.join(HOME, l1lll11_opy_ (u"ࠪ࡭ࡳ࡯ࠧࠔ"))
    l11l11l_opy_  = str(addon).split(l1lll11_opy_ (u"ࠫ࠳࠭ࠕ"))[2] + l1lll11_opy_ (u"ࠬ࠴ࡩ࡯࡫ࠪࠖ")
    l1l_opy_   = os.path.join(iPATH, l11l11l_opy_)
    l11l1l_opy_   = os.path.join(iPATH, l1lll11_opy_ (u"࠭࡭ࡢࡲࡳ࡭ࡳ࡭ࡳ࠯࡬ࡶࡳࡳ࠭ࠗ"))
    LABELFILE = os.path.join(iPATH, l1lll11_opy_ (u"ࠧ࡭ࡣࡥࡩࡱࡹ࠮࡫ࡵࡲࡲࠬ࠘"))
    l111ll_opy_  = json.load(open(l11l1l_opy_))
    labelmaps = json.load(open(LABELFILE))
    response = l1_opy_(addon)
    l1ll1ll_opy_ = response[l1lll11_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨ࠙")][l1lll11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨࠚ")]
    l1ll111_opy_  = l1lll11_opy_ (u"ࠪ࡟ࠬࠛ") + addon + l1lll11_opy_ (u"ࠫࡢࡢ࡮ࠨࠜ")
    l1l11_opy_  =  file(l1l_opy_, l1lll11_opy_ (u"ࠬࡽࠧࠝ"))
    l1l11_opy_.write(l1ll111_opy_)
    l1ll11ll_opy_ = []
    for channel in l1ll1ll_opy_:
        l11lll_opy_ = l1l11l_opy_(addon)
        l1lll_opy_  = channel[l1lll11_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬࠞ")].split(l1lll11_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࠟ"), 1)[0]
        if addon == dexter:
            l1lll_opy_ = l1lll_opy_.split(l1lll11_opy_ (u"ࠨࠢ࠮ࠤࠬࠠ"), 1)[0]
        l111lll_opy_  = l11llll_opy_(l1lll_opy_)
        l1l1l_opy_  = l1lll111_opy_(labelmaps, l111ll_opy_, l1lll_opy_)
        stream  = l11lll_opy_ + l111lll_opy_
        l1111_opy_ = l1l1l_opy_  + l1lll11_opy_ (u"ࠩࡀࠫࠡ") + stream
        if l1111_opy_ not in l1ll11ll_opy_:
            l1ll11ll_opy_.append(l1111_opy_)
    l1ll11ll_opy_.sort()
    for item in l1ll11ll_opy_:
        l1l11_opy_.write(l1lll11_opy_ (u"ࠥࠩࡸࡢ࡮ࠣࠢ") % item)
    l1l11_opy_.close()
def l11llll_opy_(l1lll_opy_):
    l1ll1ll1_opy_ = mapping.cleanLabel(l1lll_opy_)
    l111lll_opy_ = mapping.cleanStreamLabel(l1ll1ll1_opy_)
    return l111lll_opy_
def l1lll111_opy_(labelmaps, l111ll_opy_, l1lll_opy_):
    l11111_opy_    = mapping.cleanLabel(l1lll_opy_)
    l1ll1ll1_opy_ = mapping.mapLabel(labelmaps, l11111_opy_)
    l1l1l_opy_ = mapping.cleanPrefix(l1ll1ll1_opy_)
    return mapping.mapChannelName(l111ll_opy_, l1l1l_opy_)
def l1ll_opy_(addon, file):
    l11111_opy_ = file[l1lll11_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪࠣ")].split(l1lll11_opy_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࠤ"), 1)[0]
    l11111_opy_ = l11111_opy_.split(l1lll11_opy_ (u"࠭ࠫࠨࠥ"), 1)[0]
    l11111_opy_ = mapping.cleanLabel(l11111_opy_)
    return l11111_opy_
def l1l11l_opy_(addon):
    if addon == l1llll11_opy_:
        return l1lll11_opy_ (u"ࠧࡎࡇࡊࡅ࠿࠭ࠦ")
    if addon == l11lll1_opy_:
        return l1lll11_opy_ (u"ࠨࡈࡕࡉࡊࡀࠧࠧ")
    if addon == l11_opy_:
        return l1lll11_opy_ (u"ࠩࡐࡅ࡙࡙࠺ࠨࠨ")
    if addon == l1lll1l_opy_:
        return l1lll11_opy_ (u"ࠪࡍࡕ࡚ࡓ࠻ࠩࠩ")
    if addon == l1l1lll_opy_:
        return l1lll11_opy_ (u"ࠫࡏࡏࡎ࡙࠴࠽ࠫࠪ")
    if addon == l1ll11l_opy_:
        return l1lll11_opy_ (u"ࠬࡘࡏࡐࡖ࠽ࠫࠫ")
    if addon == l11111l_opy_:
        return l1lll11_opy_ (u"࠭ࡅࡏࡆ࠽ࠫࠬ")
    if addon == l1ll1lll_opy_:
        return l1lll11_opy_ (u"ࠧࡇࡎࡄ࠾ࠬ࠭")
    if addon == l11ll1l_opy_:
        return l1lll11_opy_ (u"ࠨࡏࡄ࡜ࡎࡀࠧ࠮")
    if addon == dexter:
        return l1lll11_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪ࠯")
    if addon == l11ll_opy_:
        return l1lll11_opy_ (u"࡚ࠪࡉࡘࡔࡗ࠼ࠪ࠰")
    if addon == l11ll1_opy_:
        return l1lll11_opy_ (u"ࠫࡘࡖࡒࡎ࠼ࠪ࠱")
    if addon == l1llll1_opy_:
        return l1lll11_opy_ (u"ࠬࡓࡃࡌࡖ࡙࠾ࠬ࠲")
    if addon == l1llll1l_opy_:
        return l1lll11_opy_ (u"࠭ࡔࡘࡋࡖࡘ࠿࠭࠳")
    if addon == l11l1ll_opy_:
        return l1lll11_opy_ (u"ࠧࡑࡔࡈࡗ࡙ࡀࠧ࠴")
    if addon == l1l1l1_opy_:
        return l1lll11_opy_ (u"ࠨࡄࡏࡏࡎࡀࠧ࠵")
def getURL(url):
    if url.startswith(l1lll11_opy_ (u"ࠩࡐࡉࡌࡇࠧ࠶")):
        return l11l_opy_(url, l1llll11_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠪࡊࡗࡋࡅࠨ࠷")):
        return l11l_opy_(url, l11lll1_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡆࡐ࡚ࡀࠧ࠸")):
        url = url.replace(l1lll11_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡇࡑ࡛࠺ࠨ࠹"), l1lll11_opy_ (u"࠭ࠧ࠺")).replace(l1lll11_opy_ (u"ࠧ࠮࠯ࡸࡷࡪࡸ࠭ࡢࡩࡨࡲࡹ࠭࠻"), l1lll11_opy_ (u"ࠨࡾࡸࡷࡪࡸ࠭ࡢࡩࡨࡲࡹ࠭࠼"))
        return url
    if url.startswith(l1lll11_opy_ (u"ࠩࡐࡅ࡙࡙ࠧ࠽")):
        return l11l_opy_(url, l11_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠪࡍࡕ࡚ࡓࠨ࠾")):
        return l11l_opy_(url, l1lll1l_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠫࡏࡏࡎ࡙࠴ࠪ࠿")):
        return l11l_opy_(url, l1l1lll_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠬࡘࡏࡐࡖࠪࡀ")):
        return l11l_opy_(url, l1ll11l_opy_)
    if url.startswith(l1lll11_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡉ࠭ࡁ")):
        return l11l_opy_(url, dexter)
    if url.startswith(l1lll11_opy_ (u"ࠧࡇࡎࡄࠫࡂ")):
        return l11l_opy_(url, l1ll1lll_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠨࡏࡄ࡜ࡎ࠭ࡃ")):
        return l11l_opy_(url, l11ll1l_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠩࡈࡒࡉ࠭ࡄ")):
        return l11l_opy_(url, l11111l_opy_)
    if url.startswith(l1lll11_opy_ (u"࡚ࠪࡉࡘࡔࡗࠩࡅ")):
        return l11l_opy_(url, l11ll_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠫࡘࡖࡒࡎࠩࡆ")):
        return l11l_opy_(url, l11ll1_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠬࡓࡃࡌࡖ࡙ࠫࡇ")):
        return l11l_opy_(url, l1llll1_opy_)
    if url.startswith(l1lll11_opy_ (u"࠭ࡔࡘࡋࡖࡘࠬࡈ")):
        return l11l_opy_(url, l1llll1l_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠧࡑࡔࡈࡗ࡙࠭ࡉ")):
        return l11l_opy_(url, l11l1ll_opy_)
    if url.startswith(l1lll11_opy_ (u"ࠨࡄࡏࡏࡎ࠭ࡊ")):
        return l11l_opy_(url, l1l1l1_opy_)
    response  = l111_opy_(url)
    l1l1l11_opy_ = url.split(l1lll11_opy_ (u"ࠩ࠽ࠫࡋ"), 1)[-1]
    try:
        result = response[l1lll11_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪࡌ")]
        l1ll11_opy_  = result[l1lll11_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪࡍ")]
    except Exception as e:
        l1111l1_opy_(e)
        return None
    for file in l1ll11_opy_:
        l1lll_opy_  = file[l1lll11_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫࡎ")].split(l1lll11_opy_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࡏ"), 1)[0]
        l111l11_opy_  = l1lll_opy_.split(l1lll11_opy_ (u"ࠧࠬࠩࡐ"), 1)[0]
        l1111ll_opy_ = mapping.cleanLabel(l111l11_opy_)
        try:
            if l1l1l11_opy_ == l1111ll_opy_:
                return file[l1lll11_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ࡑ")]
        except:
            if (l1l1l11_opy_ in l1111ll_opy_) or (l1111ll_opy_ in l1l1l11_opy_):
                return file[l1lll11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧࡒ")]
    return None
def l11l_opy_(url, addon):
    PATH = l1ll1_opy_(addon)
    try:
        response = json.load(open(PATH))
    except:
        response = l1_opy_(addon)
    l1ll1l11_opy_      = url.split(l1lll11_opy_ (u"ࠪ࠾ࠬࡓ"), 1)[-1]
    stream    = l1ll1l11_opy_.split(l1lll11_opy_ (u"ࠫࠥࡡࠧࡔ"), 1)[0]
    l1l1l11_opy_ = mapping.cleanLabel(stream)
    l1ll11_opy_  = response[l1lll11_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬࡕ")][l1lll11_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬࡖ")]
    for file in l1ll11_opy_:
        l1lll_opy_  = file[l1lll11_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ࡗ")].split(l1lll11_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࡘ"), 1)[0]
        if addon == dexter:
            l1lll_opy_ = l1lll_opy_.split(l1lll11_opy_ (u"ࠩࠣ࠯࡙ࠥ࠭"), 1)[0]
        l1111ll_opy_ = l11llll_opy_(l1lll_opy_)
        try:
            if l1l1l11_opy_ == l1111ll_opy_:
                return file[l1lll11_opy_ (u"ࠪࡪ࡮ࡲࡥࠨ࡚")]
        except:
            if (l1l1l11_opy_ in l1111ll_opy_) or (l1111ll_opy_ in l1l1l11_opy_):
                return file[l1lll11_opy_ (u"ࠫ࡫࡯࡬ࡦ࡛ࠩ")]
            if l1lll11_opy_ (u"࡛ࠬࡓࡂ࠱ࡆࡅ࠿࠭࡜") in l1111ll_opy_:
                l1l1111_opy_ = l1111ll_opy_.replace(l1lll11_opy_ (u"࠭ࡕࡔࡃ࠲ࡇࡆࡀࠧ࡝"), l1lll11_opy_ (u"ࠧࡖࡕࡄ࠾ࠬ࡞"))
                if dixie.fuzzyMatch(l1l1l11_opy_, l1l1111_opy_):
                    return file[l1lll11_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭࡟")]
    return None
def l1_opy_(addon):
    PATH  = l1ll1_opy_(addon)
    if addon == l11ll_opy_:
        query = l1lll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡚ࡆࡊࡅࡓ࠱࡯࡭ࡻ࡫ࡴࡷ࠱ࡤࡰࡱ࠵ࠧࡠ")
    elif addon == l11lll1_opy_:
        query = l1lll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡫ࡸࡥࡦࡸ࡬ࡩࡼ࠵࠿ࡶࡴ࡯ࡁࡺࡸ࡬ࠧ࡯ࡲࡨࡪࡃ࠵ࠧࡰࡤࡱࡪࡃࡌࡪࡸࡨ࠯࡙࡜ࠧࡡ")
    else:
        query = l11l111_opy_(addon)
    try:
        return json.load(open(PATH))
    except:
        content = doJSON(query)
        return l1ll1l1_opy_(PATH, addon, content)
def l1ll1l1_opy_(PATH, addon, content):
    json.dump(content, open(PATH,l1lll11_opy_ (u"ࠫࡼ࠭ࡢ")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    l1lllll1_opy_  = (l1lll11_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࠦࡵࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨࡣ") % query)
    response = xbmc.executeJSONRPC(l1lllll1_opy_)
    content  = json.loads(response)
    return content
def l1ll1_opy_(addon):
    if addon == l1llll11_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"࠭࡭ࡦࡩࡤࡸࡲࡶࠧࡤ"))
    if addon == l11_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠧ࡮ࡣࡷࡷࡹࡳࡰࠨࡥ"))
    if addon == l11lll1_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠨࡨࡵࡩࡪࡺ࡭ࡱࠩࡦ"))
    if addon == l1lll1l_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠩ࡬ࡴࡹࡹࡴ࡮ࡲࠪࡧ"))
    if addon == l1l1lll_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠪ࡮࠷ࡺࡥ࡮ࡲࠪࡨ"))
    if addon == l1ll11l_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠫࡷࡵࡴࡦ࡯ࡳࠫࡩ"))
    if addon == l11111l_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠬ࡫ࡴࡦ࡯ࡳࠫࡪ"))
    if addon == l1ll1lll_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"࠭ࡦࡵࡧࡰࡴࠬ࡫"))
    if addon == l11ll1l_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠧ࡮ࡣࡻࡸࡪࡳࡰࠨ࡬"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠨࡦࡷࡩࡲࡶࠧ࡭"))
    if addon == l11ll_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠩࡹࡨࡹ࡫࡭ࡱࠩ࡮"))
    if addon == l11ll1_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠪࡷࡵࡸࡴࡦ࡯ࡳࠫ࡯"))
    if addon == l1llll1_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠫࡲࡩ࡫ࡵࡧࡰࡴࠬࡰ"))
    if addon == l1llll1l_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠬࡺࡷࡪࡶࡨࡱࡵ࠭ࡱ"))
    if addon == l11l1ll_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"࠭ࡰࡳࡧࡶࡸࡪࡳࡰࠨࡲ"))
    if addon == l1l1l1_opy_:
        return os.path.join(dixie.PROFILE, l1lll11_opy_ (u"ࠧࡣ࡮࡮࡭ࡹ࡫࡭ࡱࠩࡳ"))
def l11l111_opy_(addon):
    query = l1lll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫࡴ") + addon
    response = doJSON(query)
    l1ll11_opy_    = response[l1lll11_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩࡵ")][l1lll11_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩࡶ")]
    for file in l1ll11_opy_:
        l11l1l1_opy_ = file[l1lll11_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪࡷ")]
        l11111_opy_ = mapping.cleanLabel(l11l1l1_opy_)
        l11111_opy_ = l11111_opy_.upper()
        if (l11111_opy_ == l1lll11_opy_ (u"ࠬࡒࡉࡗࡇࠣࡍࡕ࡚ࡖࠨࡸ")) or (l11111_opy_ == l1lll11_opy_ (u"࠭ࡌࡊࡘࡈࠤ࡙࡜ࠧࡹ")) or (l11111_opy_ == l1lll11_opy_ (u"ࠧࡍࡋ࡙ࡉࠥࡉࡈࡂࡐࡑࡉࡑ࡙ࠧࡺ")) or (l11111_opy_ == l1lll11_opy_ (u"ࠨࡎࡌ࡚ࡊ࠭ࡻ")) or (l11111_opy_ == l1lll11_opy_ (u"ࠩࡈࡒࡉࡒࡅࡔࡕࠣࡑࡊࡊࡉࡂࠩࡼ")) or (l11111_opy_ == l1lll11_opy_ (u"ࠪࡊࡑࡇࡗࡍࡇࡖࡗ࡙࡜ࠧࡽ")) or (l11111_opy_ == l1lll11_opy_ (u"ࠫࡒࡇࡘࡊ࡙ࡈࡆ࡚ࠥࡖࠨࡾ")) or (l11111_opy_ == l1lll11_opy_ (u"ࠬࡈࡌࡂࡅࡎࡍࡈࡋࠠࡕࡘࠪࡿ")):
            livetv = file[l1lll11_opy_ (u"࠭ࡦࡪ࡮ࡨࠫࢀ")]
            return l1l111_opy_(livetv)
def l1l111_opy_(livetv):
    response = doJSON(livetv)
    l1ll11_opy_    = response[l1lll11_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧࢁ")][l1lll11_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧࢂ")]
    for file in l1ll11_opy_:
        l11l1l1_opy_ = file[l1lll11_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨࢃ")]
        l11111_opy_ = mapping.cleanLabel(l11l1l1_opy_)
        l11111_opy_ = l11111_opy_.upper()
        if l11111_opy_ == l1lll11_opy_ (u"ࠪࡅࡑࡒࠧࢄ"):
            return file[l1lll11_opy_ (u"ࠫ࡫࡯࡬ࡦࠩࢅ")]
def l1l1l1l_opy_(l1l111l_opy_):
    items = []
    _111ll1_opy_(l1l111l_opy_, items)
    return items
def _111ll1_opy_(l1l111l_opy_, items):
    response = doJSON(l1l111l_opy_)
    if response[l1lll11_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬࢆ")].has_key(l1lll11_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬࢇ")):
        result = response[l1lll11_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧ࢈")][l1lll11_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧࢉ")]
        for item in result:
            if item[l1lll11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫࢊ")] == l1lll11_opy_ (u"ࠪࡪ࡮ࡲࡥࠨࢋ"):
                l11111_opy_ = mapping.cleanLabel(item[l1lll11_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪࢌ")])
                items.append(item)
            elif item[l1lll11_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧࢍ")] == l1lll11_opy_ (u"࠭ࡤࡪࡴࡨࡧࡹࡵࡲࡺࠩࢎ"):
                l11111_opy_ = mapping.cleanLabel(item[l1lll11_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭࢏")])
                l1llllll_opy_  = item[l1lll11_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭࢐")]
                dixie.log(item)
                dixie.log(l1llllll_opy_)
                _111ll1_opy_(l1llllll_opy_, items)
def l111_opy_(url):
    if url.startswith(l1lll11_opy_ (u"ࠩࡌࡔࡑࡇ࡙࠻ࠩ࢑")):
        l1lllll1_opy_ = (l1lll11_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡢࡣࡥ࡬ࡴࡱࡧࡹࡦࡴ࠲ࡃࡺࡸ࡬࠾ࡷࡵࡰࠫࡳ࡯ࡥࡧࡀ࠶ࠫࡴࡡ࡮ࡧࡀࡐ࡮ࡼࡥࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࡀࠪࡎࡖࡉࡅ࠿ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ࢒"))
    if url.startswith(l1lll11_opy_ (u"ࠫࡎࡖࡌࡂ࡛࠵࠾ࠬ࢓")):
        l1lllll1_opy_ = (l1lll11_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡰࡦࡿࡥࡳࡹࡺࡻ࠴ࡅࡵࡳ࡮ࡀࡹࡷࡲࠦ࡮ࡱࡧࡩࡂ࠷࠰࠲ࠨࡱࡥࡲ࡫࠽ࡘࡣࡷࡧ࡭࠱ࡌࡪࡸࡨࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࡃࠦࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡵࡢࡹࡷࡲ࠽ࠧ࡮ࡲ࡫࡬࡫ࡤࡠ࡫ࡱࡁࡋࡧ࡬ࡴࡧࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ࢔"))
    if url.startswith(l1lll11_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡗࡀࠧ࢕")):
        l1lllll1_opy_ = (l1lll11_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽ࠯ࡀࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬ࠬ࡬ࡰࡩࡪࡩࡩࡥࡩ࡯࠿ࡉࡥࡱࡹࡥࠧ࡯ࡲࡨࡪࡃ࠱࠲࠵ࠩࡲࡦࡳࡥ࠾ࡎ࡬ࡷࡹ࡫࡮ࠦ࠴࠳ࡐ࡮ࡼࡥࠧࡵࡸࡦࡹ࡯ࡴ࡭ࡧࡶࡣࡺࡸ࡬ࠧࡷࡵࡰࡂࡻࡲ࡭ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧ࢖"))
    if url.startswith(l1lll11_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡉࡕࡘ࠽ࠫࢗ")):
        l1lllll1_opy_ = (l1lll11_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡴࡷࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧ࢘"))
    if url.startswith(l1lll11_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡆ࠽࢙ࠫ")):
        l1lllll1_opy_ = (l1lll11_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡥࡧࡻ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡧ࡬࡭ࠨࡨࡼࡹࡸࡡࠧࡲࡤ࡫ࡪࠬࡰ࡭ࡱࡷࠪࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠽ࠧࡶ࡬ࡸࡱ࡫࠽ࠦ࠷ࡥࡇࡔࡒࡏࡓࠧ࠵࠴ࡼ࡮ࡩࡵࡧࠨ࠹ࡩࡇ࡬࡭ࠧ࠵࠴ࡈ࡮ࡡ࡯ࡰࡨࡰࡸࠫ࠵ࡣࠧ࠵ࡪࡈࡕࡌࡐࡔࠨ࠹ࡩࠬࡵࡳ࡮ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ࢚"))
    if url.startswith(l1lll11_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖࡇࡀ࢛ࠧ")):
        l1lllll1_opy_ = (l1lll11_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡩࡧࡵ࡯ࡵ࠱ࡂࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠧࡨࡤࡲࡦࡸࡴ࠾ࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࠬ࡭ࡰࡦࡨࡁ࠼ࠬࡰࡪ࡮࡯ࡳࡼࡃࡌࡪࡸࡨࠩ࠷࠶ࡓࡵࡴࡨࡥࡲࡹࠦࡶࡴ࡯ࡁࡷࡧ࡮ࡥࡱࡰࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ࢜"))
    try:
        dixie.ShowBusy()
        addon =  l1lllll1_opy_.split(l1lll11_opy_ (u"ࠧ࠰࠱ࠪ࢝"), 1)[-1].split(l1lll11_opy_ (u"ࠨ࠱ࠪ࢞"), 1)[0]
        login = l1lll11_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧ࢟") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1lllll1_opy_)
        dixie.log(response)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1111l1_opy_(e)
        return {l1lll11_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠩࢠ") : l1lll11_opy_ (u"ࠫࡕࡲࡵࡨ࡫ࡱࠤࡊࡸࡲࡰࡴࠪࢡ")}
def l1lll1_opy_():
    modules = map(__import__, [l1ll111l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11l1_opy_)):
        return l1lll11_opy_ (u"࡚ࠬࡲࡶࡧࠪࢢ")
    if len(modules[-1].Window(10**4).getProperty(l111l_opy_)):
        return l1lll11_opy_ (u"࠭ࡔࡳࡷࡨࠫࢣ")
    return l1lll11_opy_ (u"ࠧࡇࡣ࡯ࡷࡪ࠭ࢤ")
def l1111l1_opy_(e):
    l1111l_opy_ = l1lll11_opy_ (u"ࠨࡕࡲࡶࡷࡿࠬࠡࡣࡱࠤࡪࡸࡲࡰࡴࠣࡳࡨࡩࡵࡳࡧࡧ࠾ࠥࡐࡓࡐࡐࠣࡉࡷࡸ࡯ࡳ࠼ࠣࠩࡸ࠭ࢥ")  %e
    l1llll_opy_ = l1lll11_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡵࡩ࠲ࡲࡩ࡯࡭ࠣࡸ࡭࡯ࡳࠡࡥ࡫ࡥࡳࡴࡥ࡭ࠢࡤࡲࡩࠦࡴࡳࡻࠣࡥ࡬ࡧࡩ࡯࠰ࠪࢦ")
    l1l1_opy_ = l1lll11_opy_ (u"࡙ࠪࡸ࡫࠺ࠡࡅࡲࡲࡹ࡫ࡸࡵࠢࡐࡩࡳࡻࠠ࠾ࡀࠣࡖࡪࡳ࡯ࡷࡧࠣࡗࡹࡸࡥࡢ࡯ࠪࢧ")
    dixie.log(e)
    dixie.DialogOK(l1111l_opy_, l1llll_opy_, l1l1_opy_)
if __name__ == l1lll11_opy_ (u"ࠫࡤࡥ࡭ࡢ࡫ࡱࡣࡤ࠭ࢨ"):
    checkAddons()