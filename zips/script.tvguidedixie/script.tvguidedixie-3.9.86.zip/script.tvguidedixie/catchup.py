# coding: UTF-8
import sys
l111lll_opy_ = sys.version_info [0] == 2
l1llll1_opy_ = 2048
l11l1l_opy_ = 7
def l11lll_opy_ (ll_opy_):
	global l1lll_opy_
	l1111_opy_ = ord (ll_opy_ [-1])
	l11l11l_opy_ = ll_opy_ [:-1]
	l1ll1_opy_ = l1111_opy_ % len (l11l11l_opy_)
	l1l1l_opy_ = l11l11l_opy_ [:l1ll1_opy_] + l11l11l_opy_ [l1ll1_opy_:]
	if l111lll_opy_:
		l1ll1ll_opy_ = unicode () .join ([unichr (ord (char) - l1llll1_opy_ - (l1l1l1_opy_ + l1111_opy_) % l11l1l_opy_) for l1l1l1_opy_, char in enumerate (l1l1l_opy_)])
	else:
		l1ll1ll_opy_ = str () .join ([chr (ord (char) - l1llll1_opy_ - (l1l1l1_opy_ + l1111_opy_) % l11l1l_opy_) for l1l1l1_opy_, char in enumerate (l1l1l_opy_)])
	return eval (l1ll1ll_opy_)
import xbmc
import xbmcgui
import xbmcaddon
import json
import datetime
import os
import dixie
import mapping
l111l1l_opy_   = l11lll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰ࡮ࡻࡸ࠯ࡶࡹࠫࠀ")
l1ll1l1_opy_ = l11lll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡺࡲࡦࡣࡰࡷࡪࡧࡳࡺ࠰ࡷࡺࠬࠁ")
l1l1l1l_opy_ = l11lll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹ࡭ࡢࡴࡷ࡬ࡺࡨࠧࠂ")
l11l1_opy_ = l11lll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࠶ࠬࠃ")
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
def isValid(stream):
    dixie.log(l11lll_opy_ (u"ࠨ࠯࠰࠱ࠥࡉࡨࡦࡥ࡮ࠤࡎ࡙ࠠࡗࡃࡏࡍࡉࠦࡳࡵࡴࡨࡥࡲࠦ࠭࠮࠯ࠪࠄ"))
    dixie.log(stream)
    if (l11lll_opy_ (u"ࠩࡉࡐࡆࡀࠧࠅ") in stream) or (l11lll_opy_ (u"ࠪࡪࡱࡧࡷ࡭ࡧࡶࡷ࠲࡯ࡰࡵࡸࠪࠆ") in stream):
        dixie.log(l11lll_opy_ (u"ࠫ࠲࠳࠭ࠡࡈࡏࡅ࡜ࡒࡅࡔࡕࠣࡘࡗ࡛ࡅࠡ࠯࠰࠱ࠬࠇ"))
        return True
    if l11lll_opy_ (u"ࠬࡎࡄࡕࡘࠪࠈ") in stream:
        dixie.log(l11lll_opy_ (u"࠭࠭࠮࠯ࠣࡌࡉ࡚ࡖࠡࡖࡕ࡙ࡊࠦ࠭࠮࠯ࠪࠉ"))
        return True
    if l111l1l_opy_ in stream:
        dixie.log(l11lll_opy_ (u"ࠧ࠮࠯࠰ࠤࡑࡏࡕ࡙ࠢࡗࡖ࡚ࡋࠠ࠮࠯࠰ࠫࠊ"))
        return True
    if l1ll1l1_opy_ in stream:
        dixie.log(l11lll_opy_ (u"ࠨ࠯࠰࠱࡙ࠥࡔࡆࡃࡖ࡝࡚ࠥࡒࡖࡇࠣ࠱࠲࠳ࠧࠋ"))
        return True
    dixie.log(l11lll_opy_ (u"ࠩ࠰࠱࠲ࠦࡖࡂࡎࡌࡈࠥࡌࡁࡍࡕࡈࠤ࠲࠳࠭ࠨࠌ"))
    return False
def getRecording(name, title, start, stream):
    if l11lll_opy_ (u"ࠪࡊࡑࡇ࠺ࠨࠍ") in stream:
        dixie.log(l11lll_opy_ (u"ࠫ࠲࠳࠭ࠡࡈࡏࡅ࠿ࠦࡩ࡯ࠢࡶࡸࡷ࡫ࡡ࡮ࠢ࠰࠱࠲࠭ࠎ"))
        return getIPTVRecording(name, title, start, stream)
    if l11lll_opy_ (u"ࠬࡎࡄࡕࡘࠪࠏ") in stream:
        dixie.log(l11lll_opy_ (u"࠭࠭࠮࠯ࠣࡌࡉ࡚ࡖ࠻ࠢ࡬ࡲࠥࡹࡴࡳࡧࡤࡱࠥ࠳࠭࠮ࠩࠐ"))
        return getHDTVRecording(name, title, start, stream)
    if l111l1l_opy_ in stream:
        dixie.log(l11lll_opy_ (u"ࠧ࠮࠯࠰ࠤࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰ࡮ࡻࡸ࠯ࡶࡹࠤ࡮ࡴࠠࡴࡶࡵࡩࡦࡳࠠ࠮࠯࠰ࠫࠑ"))
        addon = l111l1l_opy_
        return l1ll_opy_(addon, name, title, start, stream)
    if l1ll1l1_opy_ in stream:
        dixie.log(l11lll_opy_ (u"ࠨ࠯࠰࠱ࠥࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡺࡲࡦࡣࡰࡷࡪࡧࡳࡺ࠰ࡷࡺࠥ࡯࡮ࠡࡵࡷࡶࡪࡧ࡭ࠡ࠯࠰࠱ࠬࠒ"))
        addon = l1ll1l1_opy_
        return l1ll_opy_(addon, name, title, start, stream)
def getIPTVRecording(name, title, start, stream):
    dixie.log(l11lll_opy_ (u"ࠩࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࠥࡉࡁࡕࡅࡋࠤ࡚ࡖࠠࡊࡒࡗ࡚ࠥࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࠩࠓ"))
    dixie.log(name)
    dixie.log(title)
    dixie.log(start)
    dixie.log(stream)
    import time
    l1lllll_opy_ = stream.split(l11lll_opy_ (u"ࠪࢀࠬࠔ"))
    dixie.log(l1lllll_opy_)
    for url in l1lllll_opy_:
        url   = url.split(CLOSE_OTT)[1].rsplit(l11lll_opy_ (u"ࠫ࠿࠭ࠕ"))
        l111l_opy_ = url[0]
        dixie.log(url)
        if l111l_opy_ == l11lll_opy_ (u"ࠬࡌࡌࡂࠩࠖ"):
            addon = l11lll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡌ࡬ࡢࡹ࡯ࡩࡸࡹࡔࡷࠩࠗ")
    dixie.log(l11lll_opy_ (u"ࠧࡆࡒࡊࠤࡘࡺࡡࡳࡶࠣࡘ࡮ࡳࡥ࠯࠰࠱࠾ࠥࠫࡳࠨ࠘") % start)
    l11_opy_ = str(start)
    dixie.log(l11lll_opy_ (u"ࠨࡶ࡬ࡱࡪࡹࡴࡳ࡫ࡱ࡫࠿ࠦࠥࡴࠩ࠙") % l11_opy_)
    l1ll1l_opy_   = l11_opy_.split(l11lll_opy_ (u"ࠩࠣࠫࠚ"))[0]
    l1l1l11_opy_  = l11_opy_.split(l11lll_opy_ (u"ࠪࠤࠬࠛ"))[1]
    l11l_opy_  = time.strptime(l1l1l11_opy_,  l11lll_opy_ (u"ࠫࠪࡎ࠺ࠦࡏ࠽ࠩࡘ࠭ࠜ"))
    theTime    = time.strftime(l11lll_opy_ (u"ࠬࠫࡈ࠻ࠧࡐࠫࠝ"),  l11l_opy_)
    dixie.log(l11lll_opy_ (u"࠭ࡉࡑࡖ࡙ࡷࡹࡧࡲࡵ࠼ࠣࠩࡸ࠭ࠞ") % theTime)
    l11l1ll_opy_ = time.strptime(l1ll1l_opy_,   l11lll_opy_ (u"࡛ࠧࠦ࠰ࠩࡲ࠳ࠥࡥࠩࠟ"))
    theDate    = time.strftime(l11lll_opy_ (u"ࠨࠧ࡜࠳ࠪࡳ࠯ࠦࡦࠪࠠ"), l11l1ll_opy_)
    dixie.log(l11lll_opy_ (u"ࠩࡌࡔ࡙࡜ࡤࡵ࡫ࡷࡰࡪࡀࠠࠦࡵࠪࠡ") % theDate)
    return getCatchupLink(addon, name, title, theDate, theTime)
def getCatchupLink(addon, channel, theShow, theDate, theTime):
    dixie.log(l11lll_opy_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࠣ࡫ࡪࡺࡃࡢࡶࡦ࡬ࡺࡶࡌࡪࡰ࡮ࠤࡂࡃ࠽࠾࠿ࡀࠫࠢ"))
    HOME  = dixie.PROFILE
    iPATH = os.path.join(HOME, l11lll_opy_ (u"ࠫ࡮ࡴࡩࠨࠣ"))
    LABELFILE = os.path.join(iPATH, l11lll_opy_ (u"ࠬࡩࡡࡵࡥ࡫ࡹࡵ࠴ࡪࡴࡱࡱࠫࠤ"))
    labelmaps = json.load(open(LABELFILE))
    dixie.log(labelmaps)
    l1l1111_opy_ = l11lll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩࠥ") + addon
    item   = l11lll_opy_ (u"ࠧࡇࡎࡄ࡛ࡑࡋࡓࡔࠢࡆࡅ࡙ࡉࡈࡖࡒࠪࠦ")
    try:
        l1llll_opy_  = findCatchup(l1l1111_opy_, item)
        l1l11_opy_  = mapping.mapLabel(labelmaps, channel)
        dixie.log(l11lll_opy_ (u"ࠨ࠿ࡀࡁࡂࡃ࠽ࠡ࡯ࡤࡴࡵ࡫ࡤࡍࡣࡥࡩࡱࠦ࠽࠾࠿ࡀࡁࡂ࠭ࠧ"))
        dixie.log(l1l11_opy_)
        l111_opy_   = findCatchup(l1llll_opy_, l1l11_opy_)
        dixie.log(l11lll_opy_ (u"ࠩࡀࡁࡂࡃ࠽࠾ࠢࡷ࡬ࡪࡉࡨࡢࡰࡱࡩࡱࠦ࠽࠾࠿ࡀࡁࡂ࠭ࠨ"))
        dixie.log(l111_opy_)
        l11l11_opy_ = theDate + l11lll_opy_ (u"ࠪࠤ࠲ࠦࠧࠩ") + theTime
        l11l11_opy_ = l11l11_opy_.upper()
        dixie.log(l11lll_opy_ (u"ࠫࡂࡃ࠽࠾࠿ࡀࠤࡹ࡮ࡥࡓࡧࡦࡳࡷࡪࡩ࡯ࡩࠣࡁࡂࡃ࠽࠾࠿ࠪࠪ"))
        dixie.log(l11l11_opy_)
        l1111l_opy_      = findCatchup(l111_opy_, l11l11_opy_, splitlabel=True)
        dixie.log(l11lll_opy_ (u"ࠬࡃ࠽࠾࠿ࡀࡁࠥࡺࡨࡦࡎ࡬ࡲࡰࠦ࠽࠾࠿ࡀࡁࡂ࠭ࠫ"))
        dixie.log(l1111l_opy_)
        dixie.DialogOK(l11lll_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡯ࡳࡣࡱ࡫ࡪࡣ࡛ࡃ࡟ࡆࡥࡹࡩࡨ࠮ࡷࡳࠤࡸࡺࡲࡦࡣࡰࠤ࡫ࡵࡵ࡯ࡦ࠱࡟࠴ࡈ࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࠬ"), l11lll_opy_ (u"ࠧࡐࡰ࠰ࡘࡦࡶࡰ࠯ࡖ࡙ࠤࡼ࡯࡬࡭ࠢࡱࡳࡼࠦࡰ࡭ࡣࡼ࠾ࠥࡡࡃࡐࡎࡒࡖࠥࡵࡲࡢࡰࡪࡩࡢࡡࡂ࡞ࠧࡶ࡟࠴ࡈ࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࠭") % (theShow))
        return l1111l_opy_
    except:
        return None
def findCatchup(query, item, splitlabel=False):
    dixie.log(l11lll_opy_ (u"ࠨ࠿ࡀࡁࡂࡃ࠽ࠡࡈࡌࡒࡉࠦࡃࡂࡖࡆࡌ࡚ࡖࠠࡊࡖࡈࡑࠥࡃ࠽࠾࠿ࡀࡁࠬ࠮"))
    dixie.log(item)
    response = doJSON(query)
    l111l1_opy_    = response[l11lll_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩ࠯")][l11lll_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩ࠰")]
    for file in l111l1_opy_:
        l1l1_opy_ = file[l11lll_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪ࠱")]
        l1l1ll_opy_ = mapping.cleanLabel(l1l1_opy_)
        if splitlabel:
            l1l1ll_opy_ = l1l1ll_opy_.upper()
            l1l1ll_opy_ = l1l1ll_opy_.rsplit(l11lll_opy_ (u"ࠬࠦ࠭ࠡࠩ࠲"), 1)[0]
        else:
            l1l1ll_opy_ = l1l1ll_opy_.upper()
        dixie.log(l11lll_opy_ (u"࠭࠽࠾࠿ࡀࡁࡂࠦࡆࡊࡐࡇࠤࡈࡇࡔࡄࡊࡘࡔࠥࡃ࠽࠾࠿ࡀࡁࠬ࠳"))
        dixie.log(l1l1ll_opy_)
        if l1l1ll_opy_ == item.upper():
            dixie.log(l11lll_opy_ (u"ࠧ࠾࠿ࡀࡁࡂࡃࠠࡄࡃࡗࡇࡍ࡛ࡐࠡࡈࡌࡐࡊࠦ࠽࠾࠿ࡀࡁࡂ࠭࠴"))
            dixie.log(file[l11lll_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭࠵")])
            return file[l11lll_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧ࠶")]
def doJSON(query):
    l1l11l1_opy_  = (l11lll_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭࠷") % query)
    response = xbmc.executeJSONRPC(l1l11l1_opy_)
    content  = json.loads(response)
    return content
def l1ll_opy_(addon, name, title, start, stream):
    import time
    dixie.log(l11lll_opy_ (u"ࠫࡤࡥ࡟ࡠࡡࡢࡣࡤࡥࠠࡄࡃࡗࡇࡍࠦࡕࡑࠢࡏ࡜࡙࡜ࠠࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࠫ࠸"))
    l1lllll_opy_ = stream.split(l11lll_opy_ (u"ࠬࢂࠧ࠹"))
    for url in l1lllll_opy_:
        if (l1ll1l1_opy_ in url) or (l111l1l_opy_ in url):
            dixie.log(l11lll_opy_ (u"࠭ࡌ࡙ࡖ࡙ࠤ࡚ࡘࡌ࠯࠰࠱࠾ࠥࠫࡳࠨ࠺") % url)
            l111ll_opy_ = url.split(CLOSE_OTT)[0].replace(OPEN_OTT, l11lll_opy_ (u"ࠧࠨ࠻"))
            break
    import urllib
    l1l1lll_opy_ = l11111_opy_()
    dixie.log(l11lll_opy_ (u"ࠨࡇࡓࡋ࡙ࠥࡴࡢࡴࡷࠤ࡙࡯࡭ࡦ࠰࠱࠲࠿ࠦࠥࡴࠩ࠼") % start)
    dixie.log(l11lll_opy_ (u"ࠩࡒࡪ࡫ࡹࡥࡵࠢ࡬ࡲࠥࡹࡥࡤࡱࡱࡨࡸࡀࠠࠦࡵࠪ࠽") % l1l1lll_opy_)
    l11l1l1_opy_  =  start - datetime.timedelta(seconds=l1l1lll_opy_)
    dixie.log(l11lll_opy_ (u"ࠪࡗࡹࡧࡲࡵࠢࡗ࡭ࡲ࡫ࠠࡰࡨࡩࡷࡪࡺ࠺ࠡࠧࡶࠫ࠾") % l11l1l1_opy_)
    l1lll1l_opy_     = l1lll1_opy_(l111ll_opy_)
    l11_opy_ = str(l11l1l1_opy_)
    l11llll_opy_   = l11_opy_.split(l11lll_opy_ (u"ࠫࠥ࠭࠿"))[0]
    l1l1l11_opy_  = l11_opy_.split(l11lll_opy_ (u"ࠬࠦࠧࡀ"))[1]
    l11ll1_opy_  = time.strptime(l1l1l11_opy_,  l11lll_opy_ (u"࠭ࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠨࡁ"))
    l11ll1_opy_  = time.strftime(l11lll_opy_ (u"ࠧࠦࡋ࠽ࠩࡒࠦࠥࡱࠩࡂ"),  l11ll1_opy_)
    l1l111l_opy_ = time.strptime(l11llll_opy_,   l11lll_opy_ (u"ࠨࠧ࡜࠱ࠪࡳ࠭ࠦࡦࠪࡃ"))
    l1l111l_opy_ = time.strftime(l11lll_opy_ (u"ࠩࠨࡅ࠱ࠦࠥࡃࠢࠨࡨࠬࡄ"), l1l111l_opy_)
    query = l11lll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳ࠰ࡁࡦ࡬ࡦࡴ࡮ࡦ࡮ࡢ࡭ࡩࡃࠥࡴࠨࡧࡥࡹ࡫࠽ࠦࡵࠩࡨࡦࡺࡥࡠࡶ࡬ࡸࡱ࡫࠽ࠦࡵࠩ࡭ࡲ࡭࠽ࠧ࡯ࡲࡨࡪࡃࡲࡦࡥࡲࡶࡩ࡯࡮ࡨࡵࠩࡸ࡮ࡺ࡬ࡦ࠿ࠨࡷࠬࡅ") % (addon, l1lll1l_opy_, l11llll_opy_, l1l111l_opy_, l111ll_opy_)
    l1l11l_opy_  = l11lll_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࠥࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࡆ") % query
    if not l1lll1l_opy_:
        dixie.DialogOK(l11lll_opy_ (u"࡙ࠬ࡯ࡳࡴࡼ࠲ࠬࡇ"), l11lll_opy_ (u"࠭ࡗࡦࠢࡦࡳࡺࡲࡤࠡࡰࡲࡸࠥ࡬ࡩ࡯ࡦࠣࡥࠥࡩࡡࡵࡥ࡫ࡹࡵࠦࡳࡦࡴࡹ࡭ࡨ࡫ࠠࡧࡱࡵࠤࡹ࡮ࡩࡴࠢࡦ࡬ࡦࡴ࡮ࡦ࡮࠱ࠫࡈ"), l11lll_opy_ (u"ࠧࡓࡧࡹࡩࡷࡺࡩ࡯ࡩࠣࡦࡦࡩ࡫ࠡࡶࡲࠤࡑ࡯ࡶࡦࠢࡗ࡚࠳࠭ࡉ"))
        return None
    l1lll11_opy_    = xbmc.executeJSONRPC(l1l11l_opy_)
    response   = json.loads(l1lll11_opy_)
    result     = response[l11lll_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨࡊ")]
    l1ll11l_opy_ = result[l11lll_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨࡋ")]
    for l11ll11_opy_ in l1ll11l_opy_:
        try:
            l1l111_opy_ = l11ll11_opy_[l11lll_opy_ (u"ࠪࡪ࡮ࡲࡥࠨࡌ")]
            l1l1ll_opy_   = l11ll11_opy_[l11lll_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪࡍ")]
            if l11ll1_opy_ in l1l1ll_opy_:
                dixie.DialogOK(l11lll_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡵࡲࡢࡰࡪࡩࡢࡉࡡࡵࡥ࡫࠱ࡺࡶࠠࡴࡶࡵࡩࡦࡳࠠࡧࡱࡸࡲࡩ࠴࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨࡎ"), l11lll_opy_ (u"࠭ࡏ࡯࠯ࡗࡥࡵࡶ࠮ࡕࡘࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡻࠥࡶ࡬ࡢࡻ࠽ࠤࡠࡉࡏࡍࡑࡕࠤࡴࡸࡡ࡯ࡩࡨࡡࡠࡈ࡝ࠦࡵ࡞࠳ࡇࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨࡏ") % (title))
                return l1l111_opy_
        except Exception, e:
            dixie.log(l11lll_opy_ (u"ࠧࡆࡔࡕࡓࡗࡀࠠࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣࡸ࡭ࡸ࡯ࡸࡰࠣ࡭ࡳࠦࡧࡦࡶࡏ࡜࡙࡜ࡒࡦࡥࡲࡶࡩ࡯࡮ࡨࠢࠨࡷࠬࡐ") % str(e))
            dixie.DialogOK(l11lll_opy_ (u"ࠨࡕࡲࡶࡷࡿ࠮ࠨࡑ"), l11lll_opy_ (u"࡚ࠩࡩࠥࡩ࡯ࡶ࡮ࡧࠤࡳࡵࡴࠡࡨ࡬ࡲࡩࠦࡡࠡࡥࡤࡸࡨ࡮ࡵࡱࠢࡶࡸࡷ࡫ࡡ࡮ࠢࡩࡳࡷࠦࡴࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱ࠳࠭ࡒ"), l11lll_opy_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡸࡷࡿࠠࡢࡩࡤ࡭ࡳࠦ࡬ࡢࡶࡨࡶ࠳࠭ࡓ"))
            return None
def l1lll1_opy_(l111ll_opy_):
    l111ll_opy_ = l111ll_opy_.upper()
    if l111ll_opy_ == l11lll_opy_ (u"ࠫ࠸ࡋࠧࡔ") : return 188
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡇࡂࡄࠢࡈࡅࡘ࡚ࠧࡕ") : return 363
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡁࡃࡅࠪࡖ") : return 346
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡂࡏࡆࠫࡗ") : return 375
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡃࡏࡍࡇࡏࠠࡊࡔࡈࡐࡆࡔࡄࠨࡘ") : return 280
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡄࡒࡎࡓࡁࡍࠢࡓࡐࡆࡔࡅࡕࠢࡘࡗࡆ࡙࠭") : return 386
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡅࡓࡏࡍࡂࡎࠣࡔࡑࡇࡎࡆࡖ࡚ࠪ") : return 19
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡆࡘࡅࡏࡃࠣࡗࡕࡕࡒࡕࡕࠣ࠵ࠥࡎࡄࠡࡅࡕࡓࡆ࡚ࡉࡂ࡛ࠩ") : return 403
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡇࡒࡆࡐࡄࠤࡘࡖࡏࡓࡖࡖࠤ࠷ࠦࡈࡅࠢࡆࡖࡔࡇࡔࡊࡃࠪ࡜") : return 404
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡁࡓࡇࡑࡅ࡙ࠥࡐࡐࡔࡗࡗࠥ࠹ࠠࡉࡆࠣࡇࡗࡕࡁࡕࡋࡄࠫ࡝") : return 405
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡂࡔࡈࡒࡆࠦࡓࡑࡑࡕࡘࡘࠦ࠴ࠡࡊࡇࠤࡈࡘࡏࡂࡖࡌࡅࠬ࡞") : return 406
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡃࡕࡉࡓࡇࠠࡔࡒࡒࡖ࡙࡙ࠠ࠶ࠢࡖࡖࡇ࠭࡟") : return 407
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡄࡘ࡚ࠥࡈࡆࠢࡕࡅࡈࡋࡓࠨࡠ") : return 273
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡆࡇࡉࠠࡐࡐࡈ࡟ࡍࡊ࡝ࠨࡡ") : return 210
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡇࡈࡃࠡࡖ࡚ࡓࡠࡎࡄ࡞ࠩࡢ") : return 211
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡈࡅࡊࡐࠣࡗࡕࡕࡒࡕࠢ࠴࠴ࠥࡎࡄࠩࡖࡈࡗ࡙࠯ࠧࡣ") : return 300
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡂࡆࡋࡑࠤࡘࡖࡏࡓࡖࠣ࠵࠶ࠦࡈࡅࠪࡗࡉࡘ࡚ࠩࠨࡤ") : return 389
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡃࡇࡌࡒ࡙ࠥࡐࡐࡔࡗࠤ࠶ࡎࡄࠩࡖࡈࡗ࡙࠯ࠧࡥ") : return 285
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡄࡈࡍࡓࠦࡓࡑࡑࡕࡘࠥ࠸ࠠࡉࡆࠫࡘࡊ࡙ࡔࠪࠩࡦ") : return 286
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡅࡉࡎࡔࠠࡔࡒࡒࡖ࡙ࠦ࠳ࠡࡊࡇ࡙ࠬࡋࡓࡕࠫࠪࡧ") : return 287
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡆࡊࡏࡎࠡࡕࡓࡓࡗ࡚ࠠ࠵ࠢࡋࡈ࡚࠭ࡅࡔࡖࠬࠫࡨ") : return 288
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡇࡋࡉࡏࠢࡖࡔࡔࡘࡔࠡ࠷ࠣࡌࡉ࠮ࡔࡆࡕࡗ࠭ࠬࡩ") : return 289
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡈࡅࡊࡐࠣࡗࡕࡕࡒࡕࠢ࠹ࠤࡍࡊࠨࡕࡇࡖࡘ࠮࠭ࡪ") : return 290
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡂࡆࡋࡑࠤࡘࡖࡏࡓࡖࠣ࠻ࠥࡎࡄࠩࡖࡈࡗ࡙࠯ࠧ࡫") : return 291
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡃࡇࡌࡒ࡙ࠥࡐࡐࡔࡗࠤ࠽ࠦࡈࡅࠪࡗࡉࡘ࡚ࠩࠨ࡬") : return 292
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡄࡈࡍࡓࠦࡓࡑࡑࡕࡘࠥ࠿ࠠࡉࡆࠫࡘࡊ࡙ࡔࠪࠩ࡭") : return 293
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡅࡘ࡙ࠥࡐࡐࡔࡗࠤ࠶ࠦࡈࡅࠢࠫࡘࡊ࡙ࡔࠪࠩ࡮") : return 306
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡆ࡙ࠦࡓࡑࡑࡕࡘࠥ࠷ࠧ࡯") : return 17
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡇ࡚ࠠࡔࡒࡒࡖ࡙ࠦ࠲ࠡࡊࡇࠤ࡚࠭ࡅࡔࡖࠬࠫࡰ") : return 307
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡈࡔࠡࡕࡓࡓࡗ࡚ࠠ࠳ࠩࡱ") : return 18
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡂࡕࠢࡖࡔࡔࡘࡔࠡࡇࡖࡔࡓ࠭ࡲ") : return 24
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡃࡖࠣࡗࡕࡕࡒࡕࠢࡈ࡙ࡗࡕࡐࡆࠩࡳ") : return 216
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡄࡄࡆ࡞ࠦࡔࡗࠩࡴ") : return 299
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡅࡐ࡚ࡋࠠࡉࡗࡖࡘࡑࡋࡒࠡࡇࡘࡖࡔࡖࡅࠨࡵ") : return 241
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡆࡔࡕࡍࡆࡔࡄࡒࡌ࠭ࡶ") : return 192
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡇࡕࡘࠡࡐࡄࡘࡎࡕࡎࠨࡷ") : return 185
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡈࡒࡊࡖࡌࡗࡍࠦࡅࡖࡔࡒࡗࡕࡕࡒࡕ࠴ࠪࡸ") : return 173
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡂࡓࡋࡗࡍࡘࡎࠠࡆࡗࡕࡓࡘࡖࡏࡓࡖࠪࡹ") : return 182
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡄࡄࡖࠤࡗࡋࡁࡍࡋࡗ࡝ࠬࡺ") : return 190
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡅࡑࡆࡈ࠭ࡻ") : return 366
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡆࡒࡓ࠭ࡼ") : return 365
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡇࡆࡘࡔࡐࡑࡑࠤࡓࡋࡔࡘࡑࡕࡏ࡛ࠥࡋࠨࡽ") : return 186
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡈࡇࡒࡕࡑࡒࡒࡎ࡚ࡏࠨࡾ") : return 250
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡉࡈࡆࡎࡖࡉࡆࠦࡔࡗࠩࡿ") : return 179
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡃࡐࡏࡈࡈ࡞ࠦࡃࡆࡐࡗࡖࡆࡒࠠࡖࡕࡄࠫࢀ") : return 374
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡄࡑࡐࡉࡉ࡟ࠠࡄࡇࡑࡘࡗࡇࡌࠨࢁ") : return 251
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡅࡒࡑࡊࡊ࡙࡚ࠡࡗࡖࡆ࠭ࢂ") : return 176
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡆࡖࡎࡓࡅࠡࡋࡑ࡚ࡊ࡙ࡔࡊࡉࡄࡘࡎࡕࡎࠨࢃ") : return 249
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡈࡆ࡜ࡅࠨࢄ") : return 230
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡉࡏࡓࡄࡑ࡙ࡉࡗ࡟ࠠࡉࡋࡖࡘࡔࡘ࡙ࠨࢅ") : return 20
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡊࡉࡔࡅࡒ࡚ࡊࡘ࡙ࠡࡕࡆࡍࡊࡔࡃࡆࠩࢆ") : return 103
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡄࡊࡕࡆࡓ࡛ࡋࡒ࡚ࠢࡗ࡙ࡗࡈࡏࠨࢇ") : return 102
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡅࡋࡖࡇࡔ࡜ࡅࡓ࡛࠴ࠫ࢈") : return 98
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡆࡌࡗࡈࡕࡖࡆࡔ࡜ࠫࢉ") : return 370
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡇࡍࡘࡔࡅ࡚ࡅࡋࡒࡑ࠭ࢊ") : return 117
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡈࡎ࡙ࡎࡆ࡛ࡍ࡙ࡓࡏࡏࡓࠩࢋ") : return 118
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡊ࡙ࡐࡏࠢ࠵ࠫࢌ") : return 349
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡋࡓࡑࡐࠪࢍ") : return 348
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡅࡅࡇࡑࠤ࠰࠷ࠧࢎ") : return 278
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡆࡋࡕࠤࡘࡖࡏࡓࡖࡖࠫ࢏") : return 30
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡇࡘࡖࡔࡔࡅࡘࡕࠪ࢐") : return 398
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡉࡓ࡝ࠦࡓࡑࡑࡕࡘࡘࠦ࠱ࠨ࢑") : return 352
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡊࡔ࡞ࠠࡏࡇ࡚ࡗࠬ࢒") : return 274
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡌࡕࡌࡅࠢࡘࡏࠬ࢓") : return 277
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡎ࠲ࠡࡗࡎࠫ࢔") : return 271
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡈࡃࡑࠣࡉࡆ࡙ࡔࠨ࢕") : return 376
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡉࡄࡒࠤࡋࡇࡍࡊࡎ࡜ࠫ࢖") : return 377
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡊࡅࡓ࡙ࠥࡉࡈࡐࡄࡘ࡚ࡘࡅࠨࢗ") : return 378
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡋࡆࡔ࡚ࠦࡐࡐࡈࠫ࢘") : return 379
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡌࡌ࡚ࡖࠨ࢙") : return 384
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡍࡏࡓࡕࡑࡕ࡝࡛ࠥࡋࠨ࢚") : return 268
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡎࡉࡔࡖࡒࡖ࡞ࠦࡕࡔࡃ࢛ࠪ") : return 369
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡈࡐࡏࡈࠤ࠰࠷ࠧ࢜") : return 279
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡉࡑࡕࡖࡔࡘࠠࡄࡊࡄࡒࡓࡋࡌࠡࡗࡎࠫ࢝") : return 183
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡋࡇࠤ࡚ࡑࠧ࢞") : return 229
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡌࡘ࡛ࠦ࠲ࠨ࢟") : return 208
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡍ࡙࡜ࠠ࠴ࠩࢠ") : return 207
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡎ࡚ࡖࠡ࠶ࠪࢡ") : return 209
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡏࡔࡗࠩࢢ") : return 206
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡌࡇࡅࠣࡘ࡛࠭ࢣ") : return 180
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡎࡋࡒࠤࡘ࡚ࡁࡅࡋࡘࡑࠥ࠷࠰࠳ࠢࡋࡈࠬࢤ") : return 334
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡏࡌࡓ࡙ࠥࡔࡂࡆࡌ࡙ࡒࠦ࠱࠱࠵ࠣࡌࡉ࠭ࢥ") : return 335
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡐࡍࡔࠦࡓࡕࡃࡇࡍ࡚ࡓࠠ࠲࠲࠷ࠤࡍࡊࠧࢦ") : return 336
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡑࡎࡕࠠࡔࡖࡄࡈࡎ࡛ࡍࠡ࠳࠳࠹ࠥࡎࡄࠨࢧ") : return 337
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡒࡏࡏࠡࡕࡗࡅࡉࡏࡕࡎࠢ࠴࠴࠻ࠦࡈࡅࠩࢨ") : return 338
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡓࡉࡐࠢࡖࡘࡆࡊࡉࡖࡏࠣ࠵࠵࠽ࠠࡉࡆࠪࢩ") : return 333
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡍࡕࡘࠣࡆࡆ࡙ࡅࠨࢪ") : return 132
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡎࡖ࡙ࠤࡉࡇࡎࡄࡇࠪࢫ") : return 131
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡏࡗ࡚ࠥࡎࡉࡕࡕࠤࠫࢬ") : return 135
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡐࡘ࡛ࠦࡍࡖࡕࡌࡇࠬࢭ") : return 217
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡑ࡙࡜ࠠࡓࡑࡆࡏࡘ࠭ࢮ") : return 133
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡒ࡛ࡔࡗࠩࢯ") : return 106
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡓࡏࡕࡑࡕࡗ࡛ࠥࡋࠨࢰ") : return 215
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡎࡃࡃࠪࢱ") : return 283
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡏࡄࡆࠤࡊࡇࡓࡕࠩࢲ") : return 361
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡐࡌࡇࡐࠦࡔࡐࡑࡑࡗࠬࢳ") : return 296
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡑࡅ࡙ࠦࡇࡆࡑ࡛ࠣࡎࡒࡄࠡࡗࡎࠫࢴ") : return 269
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡒࡆ࡚ࡉࡐࡐࡄࡐࠥࡍࡅࡐࡉࡕࡅࡕࡎࡉࡄࠢࡘࡏࠬࢵ") : return 270
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡓࡇࡔࡊࡑࡑࡅࡑࠦࡇࡆࡑࡊࡖࡆࡖࡈࡊࡅ࡙ࠣࡘࡇࠧࢶ") : return 371
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡔࡉࡄࡍࠣࡎ࡚ࡔࡉࡐࡔࠪࢷ") : return 297
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡎࡊࡅࡎࠤ࡚ࡑࠧࢸ") : return 295
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡑࡔࡈࡑࡎࡋࡒࡔࡒࡒࡖ࡙࡙ࠧࢹ") : return 29
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡔࡗࡉࠥࡕࡎࡆࠩࢺ") : return 69
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡕࡘࡊࠦࡔࡘࡑ࡞ࡌࡉࡣࠧࢻ") : return 70
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡖ࡙ࡋࡊࡓࠩࢼ") : return 89
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡗࡇࡃࡊࡐࡊࠤ࡚ࡑࠧࢽ") : return 26
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡘࡅࡂࡎࠣࡐࡎ࡜ࡅࡔࠩࢾ") : return 275
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡓࡌ࡛ࠣࡆ࡚ࡔࡄࡆࡕࡏࡍࡌࡇࠠ࠲ࠢࡋࡈࡠࡊࡅ࡞ࠩࢿ") : return 408
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡔࡍ࡜ࠤࡓࡋࡗࡔࠩࣀ") : return 263
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡕࡎ࡝ࠥ࠷ࠧࣁ") : return 177
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡖࡏ࡞ࠦ࠲ࠨࣂ") : return 178
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡗࡐ࡟ࠠࡂࡅࡗࡍࡔࡔࠠࡎࡑ࡙ࡍࡊ࡙ࠧࣃ") : return 16
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡘࡑ࡙ࠡࡃࡗࡐࡆࡔࡔࡊࡅࠪࣄ") : return 174
    if l111ll_opy_ == l11lll_opy_ (u"࡙ࠬࡋ࡚ࠢࡆࡓࡒࡋࡄ࡚ࠢࡐࡓ࡛ࡏࡅࡔࠩࣅ") : return 34
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡓࡌ࡛ࠣࡈࡗࡇࡍࡂࡔࡒࡑࠥࡓࡏࡗࡋࡈࡗࠬࣆ") : return 97
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡔࡍ࡜ࠤࡋࡇࡍࡊࡎ࡜ࠤࡒࡕࡖࡊࡇࡖࠫࣇ") : return 36
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡕࡎ࡝ࠥࡍࡒࡆࡃࡗࡗࠥࡓࡏࡗࡋࡈࡗࠬࣈ") : return 37
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡖࡏ࡞ࠦࡍࡐࡘࡌࡉࡘࠦࡄࡊࡕࡑࡉ࡞࠭ࣉ") : return 220
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡗࡐ࡟ࠠࡑࡔࡈࡑࡎࡋࡒࡆࠢࡐࡓ࡛ࡏࡅࡔࠩ࣊") : return 40
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡘࡑ࡙ࠡࡕࡆࡊࡎࡎࡏࡓࡔࡒࡖࠥࡓࡏࡗࡋࡈࡗࠬ࣋") : return 41
    if l111ll_opy_ == l11lll_opy_ (u"࡙ࠬࡋ࡚ࠢࡖࡉࡑࡋࡃࡕࠢࡐࡓ࡛ࡏࡅࡔࠩ࣌") : return 42
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡓࡌ࡛ࠣࡗࡕࠦࡎࡆ࡙ࡖࠤࡍࡗࠧ࣍") : return 175
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡔࡍ࡜ࠤࡘࡖࡏࡓࡖࠣ࠵ࠥࡎࡄࠡࠪࡗࡉࡘ࡚ࠩࠨ࣎") : return 301
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡕࡎ࡝࡙ࠥࡐࡐࡔࡗࠤ࠷ࠦࡈࡅࠢࠫࡘࡊ࡙ࡔ࣏ࠪࠩ") : return 302
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡖࡏ࡞ࠦࡓࡑࡑࡕࡘࠥ࠹ࠠࡉࡆ࡙ࠣࠬࡋࡓࡕ࣐ࠫࠪ") : return 303
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡗࡐ࡟ࠠࡔࡒࡒࡖ࡙ࠦ࠴ࠡࡊࡇࠤ࡚࠭ࡅࡔࡖ࣑ࠬࠫ") : return 304
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡘࡑ࡙ࠡࡕࡓࡓࡗ࡚ࠠ࠶ࠢࡋࡈࠥ࠮ࡔࡆࡕࡗ࣒࠭ࠬ") : return 305
    if l111ll_opy_ == l11lll_opy_ (u"࡙ࠬࡋ࡚ࠢࡖࡔࡔࡘࡔࡔࠢ࠴࣓ࠫ") : return 95
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡓࡌ࡛ࠣࡗࡕࡕࡒࡕࡕࠣ࠶ࠬࣔ") : return 136
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡔࡍ࡜ࠤࡘࡖࡏࡓࡖࡖࠤ࠸࠭ࣕ") : return 43
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡕࡎ࡝࡙ࠥࡐࡐࡔࡗࡗࠥ࠺ࠧࣖ") : return 119
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡖࡏ࡞ࠦࡓࡑࡑࡕࡘࡘࠦ࠵ࠨࣗ") : return 120
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡗࡐ࡟ࠠࡕࡊࡕࡍࡑࡒࡅࡓࠢࡐࡓ࡛ࡏࡅࡔࠩࣘ") : return 96
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡘࡑ࡙ࠡࡎࡌ࡚ࡎࡔࡇࠨࣙ") : return 298
    if l111ll_opy_ == l11lll_opy_ (u"࡙ࠬࡐࡐࡔࡗࡗࠥࡌ࠱ࠨࣚ") : return 45
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡓ࡚ࡈ࡜ࠤ࡚࡙ࡁࠨࣛ") : return 383
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡕࡅࡐࠤ࠰࠷ࠠࡖࡍࠪࣜ") : return 189
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡖࡊ࠸ࠬࣝ") : return 88
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡗࡗࡓࠦ࠱ࠨࣞ") : return 339
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡘࡘࡔࠠ࠳ࠩࣟ") : return 340
    if l111ll_opy_ == l11lll_opy_ (u"࡙࡙ࠫࡎࠡ࠵ࠪ࣠") : return 341
    if l111ll_opy_ == l11lll_opy_ (u"࡚ࠬࡓࡏࠢ࠷ࠫ࣡") : return 342
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡔࡔࡐࠣ࠹ࠬ࣢") : return 343
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡕࡘ࠶ࠤࡎࡋࣣࠧ") : return 87
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡖࡕࡅ࡛ࡋࡌࠡࡅࡋࡅࡓࡔࡅࡍ࠭࠴ࠤ࡚ࡑࠧࣤ") : return 184
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡘࡗࡆࠦࡆࡐ࡚ࠣࡗࡕࡕࡒࡕࡕࠪࣥ") : return 347
    if l111ll_opy_ == l11lll_opy_ (u"࡙ࠪࡘࡇࠠࡏࡇࡗ࡛ࡔࡘࡋࠨࣦ") : return 344
    if l111ll_opy_ == l11lll_opy_ (u"࡚࡚ࠫࡖࠡࡋࡈࠫࣧ") : return 272
    if l111ll_opy_ == l11lll_opy_ (u"ࠬ࡜ࡉࡗࡃࠣࡘࡍࡋࠠࡉࡋࡗࡗࠦ࠭ࣨ") : return 130
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡖࡊࡃࡖࡅ࡙ࠦࡇࡐࡎࡉࣩࠫ") : return 125
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡘࡃࡗࡇࡍࠦࡉࡓࡇࡏࡅࡓࡊࠧ࣪") : return 281
    if l111ll_opy_ == l11lll_opy_ (u"ࠨ࡚࡛࡜࠶࠭࣫") : return 314
    if l111ll_opy_ == l11lll_opy_ (u"࡛ࠩ࡜࡝࠸ࠧ࣬") : return 315
    if l111ll_opy_ == l11lll_opy_ (u"ࠪ࡜࡝࡞࠳ࠨ࣭") : return 316
    if l111ll_opy_ == l11lll_opy_ (u"ࠫ࡝࡞ࡘ࠵࣮ࠩ") : return 317
    if l111ll_opy_ == l11lll_opy_ (u"ࠬ࡞ࡘ࡙࠷࣯ࠪ") : return 318
    if l111ll_opy_ == l11lll_opy_ (u"࡙࠭ࡆࡕࡗࡉࡗࡊࡁ࡚ࠢ࠮࠵ࣰࠬ") : return 282
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡎࡑ࡙࠸ࡒࡋࡎ࠲ࣱࠩ") : return 33
def getHDTVRecording(name, title, start, stream):
    l1lllll_opy_ = stream.split(l11lll_opy_ (u"ࠨࡾࣲࠪ"))
    for url in l1lllll_opy_:
        url   = url.split(CLOSE_OTT)[1].rsplit(l11lll_opy_ (u"ࠩ࠽ࠫࣳ"))
        l111l_opy_ = url[0]
        if l111l_opy_ == l11lll_opy_ (u"ࠪࡌࡉ࡚ࡖࠨࣴ"):
            addon = l11lll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡲࡧࡲࡵࡪࡸࡦࠬࣵ")
        else:
            addon = l11lll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢ࠴ࣶࠪ")
    dixie.log(l11lll_opy_ (u"࠭ࡁࡥࡦࡲࡲࠥࡏࡄ࠯࠰࠱࠾ࠥࠫࡳࠨࣷ") % addon)
    Addon  = xbmcaddon.Addon(id=addon)
    path   = Addon.getAddonInfo(l11lll_opy_ (u"ࠧࡱࡣࡷ࡬ࠬࣸ"))
    import sys
    sys.path.insert(0, path)
    import api
    l11ll_opy_ = Addon.getSetting(l11lll_opy_ (u"ࠨࡵࡨࡷࡸ࡯࡯࡯ࣹࠩ"))
    l11ll1l_opy_  = Addon.getSetting(l11lll_opy_ (u"ࠩࡶࡩࡷࡼࡥࡳࣺࠩ"))
    l1l1ll1_opy_    = l11lll_opy_ (u"ࠪࠪࡩࡃ࡫ࡰࡦ࡬ࠪࡸࡃࠧࣻ") + l11ll_opy_ + l11lll_opy_ (u"ࠫࠫࡵ࠽ࠨࣼ") + l11ll1l_opy_
    import urllib
    l1l1lll_opy_ = l11111_opy_()
    dixie.log(l11lll_opy_ (u"ࠬࡋࡐࡈࠢࡖࡸࡦࡸࡴࠡࡖ࡬ࡱࡪ࠴࠮࠯࠼ࠣࠩࡸ࠭ࣽ") % start)
    dixie.log(l11lll_opy_ (u"࠭ࡏࡧࡨࡶࡩࡹࠦࡩ࡯ࠢࡶࡩࡨࡵ࡮ࡥࡵ࠽ࠤࠪࡹࠧࣾ") % l1l1lll_opy_)
    l11l1l1_opy_  =  start - datetime.timedelta(seconds=l1l1lll_opy_)
    dixie.log(l11lll_opy_ (u"ࠧࡔࡶࡤࡶࡹࠦࡔࡪ࡯ࡨࠤࡴ࡬ࡦࡴࡧࡷ࠾ࠥࠫࡳࠨࣿ") % l11l1l1_opy_)
    l11_opy_ = str(l11l1l1_opy_)
    l111ll1_opy_  = l11_opy_.split(l11lll_opy_ (u"ࠨࠢࠪऀ"))[0]
    l1l11ll_opy_     = l11l111_opy_(name)
    if not l1l11ll_opy_:
        dixie.DialogOK(l11lll_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠯ࠩँ"), l11lll_opy_ (u"࡛ࠪࡪࠦࡣࡰࡷ࡯ࡨࠥࡴ࡯ࡵࠢࡩ࡭ࡳࡪࠠࡢࠢࡦࡥࡹࡩࡨࡶࡲࠣࡷࡪࡸࡶࡪࡥࡨࠤ࡫ࡵࡲࠡࡶ࡫࡭ࡸࠦࡣࡩࡣࡱࡲࡪࡲ࠮ࠨं"), l11lll_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡹࡸࡹࠡࡣࡱࡳࡹ࡮ࡥࡳࠢࡦ࡬ࡦࡴ࡮ࡦ࡮࠱ࠫः"))
        return None
    l1ll111_opy_  = l11_opy_.split(l11lll_opy_ (u"ࠬ࠳ࠧऄ"), 1)[-1].rsplit(l11lll_opy_ (u"࠭࠺ࠨअ"), 1)[0]
    theTime    = urllib.quote_plus(l1ll111_opy_)
    response   = api.remote_call( l11lll_opy_ (u"ࠢࡵࡸࡤࡶࡨ࡮ࡩࡷࡧ࠲࡫ࡪࡺ࡟ࡣࡻࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡣࡦࡴࡤࡠࡦࡤࡸࡪ࠴ࡰࡩࡲࠥआ") , {l11lll_opy_ (u"ࠣࡦࡤࡸࡪࠨइ"): l111ll1_opy_, l11lll_opy_ (u"ࠤ࡬ࡨࠧई"): l1l11ll_opy_ } )
    l1ll11l_opy_ = response[l11lll_opy_ (u"ࠥࡦࡴࡪࡹࠣउ")]
    if not l1ll11l_opy_:
        dixie.DialogOK(l11lll_opy_ (u"ࠫࡘࡵࡲࡳࡻ࠱ࠫऊ"), l11lll_opy_ (u"ࠬ࡝ࡥࠡࡥࡲࡹࡱࡪࠠ࡯ࡱࡷࠤ࡫࡯࡮ࡥࠢࡤࠤࡨࡧࡴࡤࡪࡸࡴࠥࡹࡴࡳࡧࡤࡱࠥ࡬࡯ࡳࠢࡷ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭࠯ࠩऋ"), l11lll_opy_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡴࡳࡻࠣࡥ࡬ࡧࡩ࡯ࠢ࡯ࡥࡹ࡫ࡲ࠯ࠩऌ"))
        return None
    for l11ll11_opy_ in l1ll11l_opy_:
        l1l111_opy_ = l11ll11_opy_[l11lll_opy_ (u"ࠢࡱ࡮ࡲࡸࠧऍ")]
        if l1ll111_opy_ in l1l111_opy_:
            dixie.DialogOK(l11lll_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡱࡵࡥࡳ࡭ࡥ࡞ࡅࡤࡸࡨ࡮࠭ࡶࡲࠣࡷࡹࡸࡥࡢ࡯ࠣࡪࡴࡻ࡮ࡥ࠰࡞࠳ࡈࡕࡌࡐࡔࡠࠫऎ"), l11lll_opy_ (u"ࠩࡒࡲ࠲࡚ࡡࡱࡲ࠱ࡘ࡛ࠦࡷࡪ࡮࡯ࠤࡳࡵࡷࠡࡲ࡯ࡥࡾࡀࠠ࡜ࡅࡒࡐࡔࡘࠠࡰࡴࡤࡲ࡬࡫࡝࡜ࡄࡠࠩࡸࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫए") % (title))
            return l11ll11_opy_[l11lll_opy_ (u"ࠥࡹࡷࡲࠢऐ")] + l1l1ll1_opy_
def l11l111_opy_(name):
    l1ll11_opy_   = dixie.PROFILE
    l1l_opy_ = os.path.join(l1ll11_opy_, l11lll_opy_ (u"ࠫ࡮ࡴࡩࠨऑ"), l11lll_opy_ (u"ࠬࡩࡡࡵࡥ࡫ࡹࡵ࠴ࡴࡹࡶࠪऒ"))
    l111l11_opy_   = json.load(open(l1l_opy_))
    for channel in l111l11_opy_:
        if name.upper() == channel[l11lll_opy_ (u"࠭ࡏࡕࡖ࡙ࠫओ")].upper():
            return channel[l11lll_opy_ (u"ࠧࡖࡔࡏࠫऔ")]
def l11111_opy_():
    import time
    gmt = time.gmtime()
    loc = time.localtime()
    GMT = datetime.datetime(*gmt[:6]).isoformat(l11lll_opy_ (u"ࠨࠢࠪक"))
    LOC = datetime.datetime(*loc[:6]).isoformat(l11lll_opy_ (u"ࠩࠣࠫख"))
    dixie.log(gmt)
    dixie.log(loc)
    l1_opy_ = dixie.parseTime(GMT)
    l11lll1_opy_ = dixie.parseTime(LOC)
    dixie.log(l1_opy_)
    dixie.log(l11lll1_opy_)
    dixie.log(l11lll_opy_ (u"ࠪࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥࠠࡐࡈࡉࡗࡊ࡚ࠠࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࠬग"))
    l1l1lll_opy_ = l1_opy_ - l11lll1_opy_
    dixie.log(l1l1lll_opy_)
    l1l1lll_opy_ = ((l1l1lll_opy_.days * 86400) + (l1l1lll_opy_.seconds + 1800)) / 3600
    dixie.log(l1l1lll_opy_)
    l1l1lll_opy_ *= -3600
    dixie.log(l1l1lll_opy_)
    dixie.log(l11lll_opy_ (u"ࠫࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤ࠭घ"))
    return l1l1lll_opy_