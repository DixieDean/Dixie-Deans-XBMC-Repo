# coding: UTF-8
import sys
l1l11ll1_opy_ = sys.version_info [0] == 2
l1llll1l_opy_ = 2048
l1l1ll1l_opy_ = 7
def l11ll_opy_ (l1l11l_opy_):
	global l111111_opy_
	l1ll1lll_opy_ = ord (l1l11l_opy_ [-1])
	l1l1l1ll_opy_ = l1l11l_opy_ [:-1]
	l11l11l_opy_ = l1ll1lll_opy_ % len (l1l1l1ll_opy_)
	l11ll1_opy_ = l1l1l1ll_opy_ [:l11l11l_opy_] + l1l1l1ll_opy_ [l11l11l_opy_:]
	if l1l11ll1_opy_:
		l1llll_opy_ = unicode () .join ([unichr (ord (char) - l1llll1l_opy_ - (l111l1l_opy_ + l1ll1lll_opy_) % l1l1ll1l_opy_) for l111l1l_opy_, char in enumerate (l11ll1_opy_)])
	else:
		l1llll_opy_ = str () .join ([chr (ord (char) - l1llll1l_opy_ - (l111l1l_opy_ + l1ll1lll_opy_) % l1l1ll1l_opy_) for l111l1l_opy_, char in enumerate (l11ll1_opy_)])
	return eval (l1llll_opy_)
import xbmc
import xbmcgui
import xbmcaddon
import json
import time
import datetime
import os
import dixie
import mapping
l1l111l_opy_  = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡊࡱࡧࡷ࡭ࡧࡶࡷ࡙ࡼࠧࠀ")
l11lll1_opy_   = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡭ࡵࡲࡪࡼࡲࡲ࡮ࡶࡴࡷࠩࠁ")
l1_opy_   = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡬ࡡࡣࡪࡲࡷࡹ࡯࡮ࡨࠩࠂ")
l1l11111_opy_     = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡤࡧࡷࡺࠬࠃ")
l1lll1_opy_     = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡱࡲࡸࡎࡖࡔࡗࠩࠄ")
l1l111ll_opy_ = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡎ࡬ࡱ࡮ࡺ࡬ࡦࡵࡶࡍࡕ࡚ࡖࠨࠅ")
l1ll_opy_     = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡙ࡅࡉࡋࡒࠨࠆ")
l1ll11l1_opy_   = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡹࡸࡥࡢ࡯ࡶࡹࡵࡸࡥ࡮ࡧ࠵ࠫࠇ")
l1lll1l_opy_      = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡩࡴࡷࠩࠈ")
l11lllll_opy_      = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲࡩࡶࡺ࠱ࡸࡻ࠭ࠉ")
l1ll1ll_opy_    = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡵࡴࡨࡥࡲࡹࡥࡢࡵࡼ࠲ࡹࡼࠧࠊ")
l1ll1l_opy_  = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴ࡯ࡤࡶࡹ࡮ࡵࡣࠩࠋ")
l11l11_opy_  = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࠸ࠧࠌ")
l1ll1l11_opy_   = [l1ll11l1_opy_, l1lll1l_opy_, l1ll_opy_, l1l111ll_opy_, l1l111l_opy_, l11lll1_opy_, l1_opy_, l1l11111_opy_, l1lll1_opy_]
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
def isValid(stream):
    if l11ll_opy_ (u"ࠪࡌࡔࡘࡉ࡛࠼ࠪࠍ") in stream:
        dixie.log(l11ll_opy_ (u"ࠫ࠲࠳࠭ࠡࡊࡒࡖࡎࡠࡏࡏࠢࡗࡖ࡚ࡋࠠ࠮࠯࠰ࠫࠎ"))
        return True
    if l11ll_opy_ (u"ࠬࡌࡌࡂ࠼ࠪࠏ") in stream:
        dixie.log(l11ll_opy_ (u"࠭࠭࠮࠯ࠣࡊࡑࡇࡗࡍࡇࡖࡗ࡚ࠥࡒࡖࡇࠣ࠱࠲࠳ࠧࠐ"))
        return True
    if l11ll_opy_ (u"ࠧࡇࡃࡅ࠾ࠬࠑ") in stream:
        dixie.log(l11ll_opy_ (u"ࠨ࠯࠰࠱ࠥࡌࡁࡃࡋࡓࡘ࡛ࠦࡔࡓࡗࡈࠤ࠲࠳࠭ࠨࠒ"))
        return True
    if l11ll_opy_ (u"ࠩࡄࡇࡊࡀࠧࠓ") in stream:
        dixie.log(l11ll_opy_ (u"ࠪ࠱࠲࠳ࠠࡂࡅࡈࡘ࡛ࠦࡔࡓࡗࡈࠤ࠲࠳࠭ࠨࠔ"))
        return True
    if l11ll_opy_ (u"ࠫࡗࡕࡏࡕ࠴࠽ࠫࠕ") in stream:
        dixie.log(l11ll_opy_ (u"ࠬ࠳࠭࠮ࠢࡕࡓࡔ࡚࠲ࠡࡖࡕ࡙ࡊࠦ࠭࠮࠯ࠪࠖ"))
        return True
    if l11ll_opy_ (u"࠭ࡌࡊࡏࡌࡘ࠿࠭ࠗ") in stream:
        dixie.log(l11ll_opy_ (u"ࠧ࠮࠯࠰ࠤࡑࡏࡍࡊࡖࡏࡉࡘ࡙ࠠࡕࡔࡘࡉࠥ࠳࠭࠮ࠩ࠘"))
        return True
    if l11ll_opy_ (u"ࠨࡘࡇࡖ࡙࡜࠺ࠨ࠙") in stream:
        dixie.log(l11ll_opy_ (u"ࠩ࠰࠱࠲ࠦࡖࡂࡆࡈࡖ࡚ࠥࡒࡖࡇࠣ࠱࠲࠳ࠧࠚ"))
        return True
    if l11ll_opy_ (u"ࠪࡗ࡚ࡖ࠺ࠨࠛ") in stream:
        dixie.log(l11ll_opy_ (u"ࠫ࠲࠳࠭ࠡࡕࡘࡔࡗࡋࡍࡆࠢࡗࡖ࡚ࡋࠠ࠮࠯࠰ࠫࠜ"))
        return True
    if l11ll_opy_ (u"࡙ࠬࡃࡕࡘ࠽ࠫࠝ") in stream:
        dixie.log(l11ll_opy_ (u"࠭࠭࠮࠯ࠣࡗࡈ࡚ࡖࠡࡖࡕ࡙ࡊࠦ࠭࠮࠯ࠪࠞ"))
        return True
    dixie.log(l11ll_opy_ (u"ࠧ࠮࠯࠰ࠤ࡛ࡇࡌࡊࡆࠣࡊࡆࡒࡓࡆࠢ࠰࠱࠲࠭ࠟ"))
    return False
def getRecording(name, title, start, stream):
    dixie.log(l11ll_opy_ (u"ࠨ࠿ࡀࡁࡂࡃ࠽ࠡࡩࡨࡸࡗ࡫ࡣࡰࡴࡧ࡭ࡳ࡭ࠠ࠾࠿ࡀࡁࡂࡃࠧࠠ"))
    l11llll_opy_   =  stream.split(l11ll_opy_ (u"ࠩࡿࠫࠡ"))
    l11ll1l_opy_    =  getAddonInfo(l11llll_opy_)
    catchup   = l11ll_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡳࡷࡧ࡮ࡨࡧࡠࠤࡠࡉࡡࡵࡥ࡫࠱ࡺࡶࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࡠ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࠢ")
    l11llll1_opy_ = l11ll_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞ࠢ࡞ࡒࡴࠦࡃࡢࡶࡦ࡬࠲ࡻࡰࠡࡃࡹࡥ࡮ࡲࡡࡣ࡮ࡨࡡࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠣ")
    options = []
    l1l_opy_ = []
    for item in l11ll1l_opy_:
        l1lllll_opy_ =  item[0]
        l1lllll_opy_ = l11ll_opy_ (u"ࠬࡡࡂ࡞ࠩࠤ") + l1lllll_opy_ + l11ll_opy_ (u"࡛࠭࠰ࡄࡠࠫࠥ")
        addon =  item[1]
        l1l1l_opy_ = l1l111l1_opy_(addon)
        l1llll11_opy_ = l1l1l1l1_opy_(addon, name)
        dixie.log(l1l1l_opy_)
        dixie.log(l1llll11_opy_)
        if not l1l1l_opy_:
            l111l1_opy_ = l1lllll_opy_ + l11llll1_opy_
            options.append(l111l1_opy_)
            l1l_opy_.append(addon)
        if l1l1l_opy_ and not l1llll11_opy_:
            l111l1_opy_ = l1lllll_opy_ + l11llll1_opy_
            options.append(l111l1_opy_)
            l1l_opy_.append(addon)
        if l1l1l_opy_ and l1llll11_opy_:
            l1lll_opy_ = l1lllll_opy_ + catchup
            options.append(l1lll_opy_)
            l1l_opy_.append(addon)
    l1lllll1_opy_ = xbmcgui.Dialog().select(l11ll_opy_ (u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡄࡃࡗࡇࡍ࠳ࡕࡑࠢࡄࡈࡉ࠳ࡏࡏࠩࠦ"), options)
    addon  = l1l_opy_[l1lllll1_opy_]
    if l1lllll1_opy_ > -1:
        return getIPTVRecording(addon, name, title, start, stream)
    dixie.DialogOK(l11ll_opy_ (u"ࠨࡐࡲࠤࡈࡧࡴࡤࡪ࠰ࡹࡵࠦࡁࡥࡦ࠰ࡳࡳࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠯ࠩࠧ"), l11ll_opy_ (u"ࠩࡕࡩࡻ࡫ࡲࡵ࡫ࡱ࡫ࠥࡨࡡࡤ࡭ࠣࡸࡴࠦࡌࡪࡸࡨࠤ࡙࡜࠮ࠨࠨ"))
    return
def getAddonInfo(l11llll_opy_):
    import plugins
    l11ll1l_opy_ = []
    for stream in l11llll_opy_:
        info    = plugins.getPluginInfo(stream, kodiID=True)
        l1lllll_opy_   = info[0]
        addon   = info[1]
        result  = [l1lllll_opy_, addon]
        if result not in l11ll1l_opy_:
            l11ll1l_opy_.append(result)
    dixie.log(l11ll1l_opy_)
    return l11ll1l_opy_
def l1l111l1_opy_(addon):
    for item in l1ll1l11_opy_:
        if addon == item:
            return True
    return False
def l1l1l1l1_opy_(addon, name):
    l11l111_opy_ = l1l1l1l_opy_(addon)
    dixie.log(l11l111_opy_)
    for item in l11l111_opy_:
        l1ll11ll_opy_  = name.upper()
        channel = item[0].upper()
        if l1ll11ll_opy_ == channel:
            return True
    return False
def l1l1l1l_opy_(addon):
    HOME  = dixie.PROFILE
    iPATH = os.path.join(HOME, l11ll_opy_ (u"ࠪ࡭ࡳ࡯ࠧࠩ"))
    if addon == l1_opy_:
        l11111_opy_ = os.path.join(iPATH, l11ll_opy_ (u"ࠫࡨࡧࡴࡤࡪࡸࡴࡋࡇࡂ࠯࡬ࡶࡳࡳ࠭ࠪ"))
        return json.load(open(l11111_opy_))
    if (addon == l1l111l_opy_) or (addon == l11lll1_opy_):
        l11111_opy_ = os.path.join(iPATH, l11ll_opy_ (u"ࠬࡩࡡࡵࡥ࡫ࡹࡵࡌࡌࡂ࠰࡭ࡷࡴࡴࠧࠫ"))
        return json.load(open(l11111_opy_))
    if addon == l1l11111_opy_:
        l11111_opy_ = os.path.join(iPATH, l11ll_opy_ (u"࠭ࡣࡢࡶࡦ࡬ࡺࡶࡁࡄࡇ࠱࡮ࡸࡵ࡮ࠨࠬ"))
        return json.load(open(l11111_opy_))
    if (addon == l1lll1_opy_) or (addon == l1l111ll_opy_):
        l11111_opy_ = os.path.join(iPATH, l11ll_opy_ (u"ࠧࡤࡣࡷࡧ࡭ࡻࡰࡓࡑࡒࡘ࠳ࡰࡳࡰࡰࠪ࠭"))
        return json.load(open(l11111_opy_))
    if (addon == l1ll_opy_) or (addon == l1ll11l1_opy_) or (addon == l1lll1l_opy_):
        l11111_opy_ = os.path.join(iPATH, l11ll_opy_ (u"ࠨࡥࡤࡸࡨ࡮ࡵࡱࡘࡄࡈࡊࡘ࠮࡫ࡵࡲࡲࠬ࠮"))
        return json.load(open(l11111_opy_))
    return [[l11ll_opy_ (u"ࠤࡑࡳࡳ࡫ࠢ࠯"), l11ll_opy_ (u"ࠥࡒࡴࡴࡥࠣ࠰")]]
def getIPTVRecording(addon, name, title, start, stream):
    dixie.log(l11ll_opy_ (u"ࠫࡤࡥ࡟ࡠࡡࡢࡣࡤࡥࠠࡄࡃࡗࡇࡍࠦࡕࡑࠢࡌࡔ࡙࡜ࠠࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࠫ࠱"))
    dixie.log(addon)
    dixie.log(name)
    dixie.log(title)
    dixie.log(start)
    dixie.log(stream)
    l1ll111_opy_ = l1lll11l_opy_(addon)
    l1l1l1_opy_  = start - datetime.timedelta(seconds=l1ll111_opy_)
    dixie.log(l11ll_opy_ (u"ࠬࡋࡐࡈࠢࡖࡸࡦࡸࡴࠡࡖ࡬ࡱࡪ࠴࠮࠯࠼ࠣࠩࡸ࠭࠲") % start)
    dixie.log(l11ll_opy_ (u"࠭ࡅࡑࡉࠣࡗࡹࡧࡲࡵࠢࡗ࡭ࡲ࡫ࠠࡐࡈࡉࡗࡊ࡚࠺ࠡࠧࡶࠫ࠳") % l1l1l1_opy_)
    l11l_opy_ = str(l1l1l1_opy_)
    dixie.log(l11ll_opy_ (u"ࠧࡵ࡫ࡰࡩࡸࡺࡲࡪࡰࡪ࠾ࠥࠫࡳࠨ࠴") % l11l_opy_)
    l11_opy_   = l11l_opy_.split(l11ll_opy_ (u"ࠨࠢࠪ࠵"))[0]
    l1l1llll_opy_  = l11l_opy_.split(l11ll_opy_ (u"ࠩࠣࠫ࠶"))[1]
    l1ll1l1_opy_   = time.strptime(l11_opy_, l11ll_opy_ (u"ࠪࠩ࡞࠳ࠥ࡮࠯ࠨࡨࠬ࠷"))
    theDate    = l1l11lll_opy_(addon, l1ll1l1_opy_)
    dixie.log(l11ll_opy_ (u"ࠫࡹ࡮ࡥࡅࡣࡷࡩ࠿ࠦࠥࡴࠩ࠸") % theDate)
    l1ll111l_opy_  = time.strptime(l1l1llll_opy_,  l11ll_opy_ (u"ࠬࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠧ࠹"))
    theTime    = time.strftime(l11ll_opy_ (u"࠭ࠥࡉ࠼ࠨࡑࠬ࠺"),  l1ll111l_opy_)
    dixie.log(l11ll_opy_ (u"ࠧࡵࡪࡨࡘ࡮ࡳࡥ࠻ࠢࠨࡷࠬ࠻") % theTime)
    return getCatchupLink(addon, name, title, theDate, theTime)
def l1lll11l_opy_(addon):
    l111ll1_opy_ = l1l1lll1_opy_()
    if (addon == l1ll_opy_) or (addon == l1ll11l1_opy_) or (addon == l1lll1l_opy_):
        l1ll111_opy_ = -l111ll1_opy_ - 7200
        dixie.log(l11ll_opy_ (u"ࠨࡘࡄࡈࡊࡘࠠࡕࡋࡐࡉ࡟ࡕࡎࡆ࠼ࠣࠩࡸ࠭࠼") % l111ll1_opy_)
        dixie.log(l11ll_opy_ (u"࡙ࠩࡅࡉࡋࡒࠡࡑࡉࡊࡘࡋࡔ࠻ࠢࠨࡷࠬ࠽") % l1ll111_opy_)
        return l1ll111_opy_
    l1ll111_opy_ = -l111ll1_opy_
    dixie.log(l11ll_opy_ (u"ࠪࡘࡎࡓࡅ࡛ࡑࡑࡉ࠿ࠦࠥࡴࠩ࠾") % l111ll1_opy_)
    dixie.log(l11ll_opy_ (u"ࠫࡔࡌࡆࡔࡇࡗ࠾ࠥࠫࡳࠨ࠿") % l1ll111_opy_)
    return l1ll111_opy_
def l1l1lll1_opy_():
    dixie.log(l11ll_opy_ (u"ࠬࡊࡁ࡚ࡎࡌࡋࡍ࡚࠺ࠡࠧࡶࠫࡀ") % time.daylight)
    dixie.log(l11ll_opy_ (u"࠭ࡔࡊࡏࡈ࡞ࡔࡔࡅ࠻ࠢࠨࡷࠬࡁ") % time.timezone)
    return time.timezone
def l1l11lll_opy_(addon, l1ll1l1_opy_):
    if (addon == l1l11111_opy_) or (addon == l1ll_opy_) or (addon == l1ll11l1_opy_) or (addon == l1lll1l_opy_):
        return time.strftime(l11ll_opy_ (u"ࠧࠦࡦ࠱ࠩࡲ࠭ࡂ"), l1ll1l1_opy_)
    if (addon == l1lll1_opy_) or (addon == l1l111ll_opy_):
        return time.strftime(l11ll_opy_ (u"ࠨࠧ࡜࠳ࠪࡳ࠯ࠦࡦࠪࡃ"), l1ll1l1_opy_)
    return time.strftime(l11ll_opy_ (u"ࠩࠨ࡝࠲ࠫ࡭࠮ࠧࡧࠫࡄ"), l1ll1l1_opy_)
def getCatchupLink(addon, channel, theShow, theDate, theTime):
    dixie.log(l11ll_opy_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࠣ࡫ࡪࡺࡃࡢࡶࡦ࡬ࡺࡶࡌࡪࡰ࡮ࠤࡂࡃ࠽࠾࠿ࡀࠫࡅ"))
    LABELFILE = l1ll1l1l_opy_(addon)
    dixie.log(l11ll_opy_ (u"ࠫࡂࡃ࠽࠾࠿ࡀࠤࡑࡇࡂࡆࡎࡉࡍࡑࡋࠬࠡ࡮ࡤࡦࡪࡲ࡭ࡢࡲࡶࠤࡂࡃ࠽࠾࠿ࡀࠫࡆ"))
    labelmaps = json.load(open(LABELFILE))
    dixie.log(LABELFILE)
    dixie.log(labelmaps)
    l1l11ll_opy_  = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨࡇ") + addon
    l1111l_opy_ =  l111_opy_(addon)
    try:
        l1111l1_opy_  = findCatchup(l11ll_opy_ (u"࠭ࡣࡢࡶࡦ࡬ࡺࡶ࡬ࡪࡰ࡮ࠫࡈ"), addon, l1l11ll_opy_, l1111l_opy_)
        l11l1l_opy_  = mapping.mapLabel(labelmaps, channel)
        l11l1l_opy_  = l11l1l_opy_.upper()
        dixie.log(l11ll_opy_ (u"ࠧ࠾࠿ࡀࡁࡂࡃࠠࡤࡣࡷࡧ࡭ࡻࡰ࡭࡫ࡱ࡯ࠥࡃ࠽࠾࠿ࡀࡁࠬࡉ"))
        print addon, l1111l1_opy_, l11l1l_opy_
        if (addon == l1ll_opy_) or (addon == l1ll11l1_opy_) or (addon == l1lll1l_opy_):
            l1ll1111_opy_ = l1l11l1l_opy_(l11ll_opy_ (u"ࠨࡘࡄࡈࡊࡘࠠࡄࡪࡤࡲࡳ࡫࡬ࡴࠩࡊ"), addon, l11l1l_opy_)
        else:
            l1ll1111_opy_ = findCatchup(l11ll_opy_ (u"ࠩࡷ࡬ࡪࡉࡨࡢࡰࡱࡩࡱ࠭ࡋ"), addon, l1111l1_opy_, l11l1l_opy_)
        dixie.log(l11ll_opy_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࠣࡸ࡭࡫ࡃࡩࡣࡱࡲࡪࡲࠠࡧ࡫ࡱࡨࡈࡧࡴࡤࡪࡸࡴࠥࡃ࠽࠾࠿ࡀࡁࠬࡌ"))
        print addon, l1111l1_opy_, l11l1l_opy_, l1ll1111_opy_
        l1l1l111_opy_ = l1l1ll_opy_(addon, theDate, theTime)
        l1lll11_opy_      = findCatchup(l11ll_opy_ (u"ࠫࡹ࡮ࡥࡍ࡫ࡱ࡯ࠬࡍ"), addon, l1ll1111_opy_, l1l1l111_opy_, splitlabel=True)
        dixie.CloseBusy()
        return l1lll11_opy_
    except:
        dixie.CloseBusy()
        dixie.DialogOK(l11ll_opy_ (u"࡙ࠬ࡯ࡳࡴࡼ࠲ࠬࡎ"), l11ll_opy_ (u"࠭ࡗࡦࠢࡦࡳࡺࡲࡤࠡࡰࡲࡸࠥ࡬ࡩ࡯ࡦࠣࡥࠥࡩࡡࡵࡥ࡫ࡹࡵࠦࡳࡵࡴࡨࡥࡲࠦࡦࡰࡴࠣࡸ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮࠰ࠪࡏ"), l11ll_opy_ (u"ࠧࡓࡧࡹࡩࡷࡺࡩ࡯ࡩࠣࡦࡦࡩ࡫ࠡࡶࡲࠤࡑ࡯ࡶࡦࠢࡗ࡚࠳࠭ࡐ"))
        return l11ll_opy_ (u"ࠨࠩࡑ")
def l1l11l1l_opy_(string, addon, item):
    dixie.log(l11ll_opy_ (u"ࠩࡀࡁࡂࡃ࠽࠾ࠢࡪࡩࡹ࡙ࡥࡤࡶ࡬ࡳࡳࡹࠠ࠾࠿ࡀࡁࡂࡃࠧࡒ"))
    l1111ll_opy_ = [l11ll_opy_ (u"ࠪ࠷ࠬࡓ"), l11ll_opy_ (u"ࠫ࠽࠭ࡔ"), l11ll_opy_ (u"ࠬ࠿ࠧࡕ"),l11ll_opy_ (u"࠭࠱࠱ࠩࡖ"), l11ll_opy_ (u"ࠧ࠳࠺ࠪࡗ"), l11ll_opy_ (u"ࠨ࠴࠻࠸ࠬࡘ")]
    l11111l_opy_ = []
    for l1111l_opy_ in l1111ll_opy_:
        query = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠪࡹ࠯ࡤࡣࡷࡧ࡭ࡻࡰ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲ࠩࡸ࡙࠭") % (addon, l1111l_opy_)
        dixie.log(l11ll_opy_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࠣࡵࡺ࡫ࡲࡺࠢࡀࡁࡂࡃ࠽࠾࡚ࠩ"))
        dixie.log(query)
        response = sendJSON(query, addon)
        l11111l_opy_.extend(response)
    for file in l11111l_opy_:
        l1l1lll_opy_ = file[l11ll_opy_ (u"ࠫࡱࡧࡢࡦ࡮࡛ࠪ")]
        dixie.log(l11ll_opy_ (u"ࠬࡃ࠽࠾࠿ࡀࡁࠥ࡜ࡁࡅࡇࡕࠤࡗࡇࡗࠡࡎࡄࡆࡊࡒࠠ࠾࠿ࡀࡁࡂࡃࠧ࡜"))
        dixie.log(l1l1lll_opy_)
        l111l_opy_ = mapping.cleanLabel(l1l1lll_opy_)
        l1lllll_opy_  = cleanPrefix(l111l_opy_)
        l1lllll_opy_  = l1lllll_opy_.upper()
        if l1lllll_opy_ == item.upper():
            dixie.log(l11ll_opy_ (u"࠭࠽࠾࠿ࡀࡁࡂࠦࡖࡂࡆࡈࡖࠥࡓࡁࡕࡅࡋࠤࡋࡕࡕࡏࡆࠣࡁࡂࡃ࠽࠾࠿ࠪ࡝"))
            dixie.log(item)
            dixie.log(l1lllll_opy_)
            return file[l11ll_opy_ (u"ࠧࡧ࡫࡯ࡩࠬ࡞")]
def sendJSON(query, addon):
    l111l11_opy_     = l11ll_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫ࡟") % query
    l1111_opy_  = xbmc.executeJSONRPC(l111l11_opy_)
    response = json.loads(l1111_opy_)
    result   = response[l11ll_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩࡠ")]
    return result[l11ll_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩࡡ")]
def l1ll1l1l_opy_(addon):
    HOME  = dixie.PROFILE
    iPATH = os.path.join(HOME, l11ll_opy_ (u"ࠫ࡮ࡴࡩࠨࡢ"))
    if addon == l1_opy_:
         return os.path.join(iPATH, l11ll_opy_ (u"ࠬࡩࡡࡵࡥ࡫ࡹࡵࡌࡁࡃ࠰࡭ࡷࡴࡴࠧࡣ"))
    if (addon == l1l111l_opy_) or (addon == l11lll1_opy_):
         return os.path.join(iPATH, l11ll_opy_ (u"࠭ࡣࡢࡶࡦ࡬ࡺࡶࡆࡍࡃ࠱࡮ࡸࡵ࡮ࠨࡤ"))
    if addon == l1l11111_opy_:
        return os.path.join(iPATH, l11ll_opy_ (u"ࠧࡤࡣࡷࡧ࡭ࡻࡰࡂࡅࡈ࠲࡯ࡹ࡯࡯ࠩࡥ"))
    if (addon == l1lll1_opy_) or (addon == l1l111ll_opy_):
        return os.path.join(iPATH, l11ll_opy_ (u"ࠨࡥࡤࡸࡨ࡮ࡵࡱࡔࡒࡓ࡙࠴ࡪࡴࡱࡱࠫࡦ"))
    if (addon == l1ll_opy_) or (addon == l1ll11l1_opy_) or (addon == l1lll1l_opy_):
        return os.path.join(iPATH, l11ll_opy_ (u"ࠩࡦࡥࡹࡩࡨࡶࡲ࡙ࡅࡉࡋࡒ࠯࡬ࡶࡳࡳ࠭ࡧ"))
def l111_opy_(addon):
    dixie.log(l11ll_opy_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࠣ࡫ࡪࡺࡃࡢࡶࡦ࡬ࡺࡶࡓࡦࡥࡷ࡭ࡴࡴࠠ࠾࠿ࡀࡁࡂࡃࠧࡨ"))
    dixie.log(addon)
    l1111ll_opy_ = [[l1_opy_, l11ll_opy_ (u"ࠫࡋࡇࡂࠡࡅࡄࡘࡈࡎࡕࡑࠩࡩ")], [l1l111l_opy_, l11ll_opy_ (u"ࠬࡌࡌࡂ࡙ࡏࡉࡘ࡙ࠠࡄࡃࡗࡇࡍ࡛ࡐࠨࡪ")], [l11lll1_opy_, l11ll_opy_ (u"࠭ࡈࡐࡔࡌ࡞ࡔࡔࠠࡄࡃࡗࡇࡍ࡛ࡐࠨ࡫")], [l1l11111_opy_, l11ll_opy_ (u"ࠧࡕࡘࠣࡇࡆ࡚ࡃࡉࠢࡘࡔࠬ࡬")], [l1lll1_opy_, l11ll_opy_ (u"ࠨࡅࡄࡘࡈࡎࡕࡑࠢࡗ࡚ࠬ࡭")], [l1l111ll_opy_, l11ll_opy_ (u"ࠩࡆࡅ࡙ࡉࡈࡖࡒࠣࡘ࡛࠭࡮")], [l1ll_opy_, l11ll_opy_ (u"ࠪࡘ࡛ࠦࡃࡂࡖࡆࡌ࡚ࡖࠧ࡯")], [l1ll11l1_opy_, l11ll_opy_ (u"࡙ࠫ࡜ࠠࡄࡃࡗࡇࡍ࡛ࡐࠨࡰ")], [l1lll1l_opy_, l11ll_opy_ (u"࡚ࠬࡖࠡࡅࡄࡘࡈࡎࡕࡑࠩࡱ")]]
    for l1111l_opy_ in l1111ll_opy_:
        if addon == l1111l_opy_[0]:
            dixie.log(l11ll_opy_ (u"࠭࠽࠾࠿ࡀࡁࡂࠦࡳࡦࡥࡷ࡭ࡴࡴࠠࡧࡱࡸࡲࡩࠦ࠽࠾࠿ࡀࡁࡂ࠭ࡲ"))
            dixie.log(l1111l_opy_[1])
            return l1111l_opy_[1]
def findCatchup(string, addon, query, item, splitlabel=False):
    dixie.log(l11ll_opy_ (u"ࠧ࠾࠿ࡀࡁࡂࡃࠠࡇࡋࡑࡈࠥࡉࡁࡕࡅࡋ࡙ࡕࠦࡉࡕࡇࡐࠤࡂࡃ࠽࠾࠿ࡀࠫࡳ"))
    dixie.log(string)
    response = doJSON(query)
    l11111l_opy_    = response[l11ll_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨࡴ")][l11ll_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨࡵ")]
    for file in l11111l_opy_:
        l1l1lll_opy_ = file[l11ll_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࡶ")]
        dixie.log(l11ll_opy_ (u"ࠫࡂࡃ࠽࠾࠿ࡀࠤࡗࡇࡗࠡࡎࡄࡆࡊࡒࠠ࠾࠿ࡀࡁࡂࡃࠧࡷ"))
        dixie.log(l1l1lll_opy_)
        l111l_opy_   = mapping.cleanLabel(l1l1lll_opy_)
        l1lllll_opy_    = cleanPrefix(l111l_opy_)
        if splitlabel:
            l1lllll_opy_ = l1l1l11l_opy_(addon, l1lllll_opy_)
        else:
            l1lllll_opy_ = l1lllll_opy_.upper()
        dixie.log(l11ll_opy_ (u"ࠬࡃ࠽࠾࠿ࡀࡁࠥࡌࡉࡏࡆࠣࡇࡆ࡚ࡃࡉࡗࡓࠤࡂࡃ࠽࠾࠿ࡀࠫࡸ"))
        dixie.log(item)
        dixie.log(l1lllll_opy_)
        if l1lllll_opy_ == item.upper():
            dixie.log(l11ll_opy_ (u"࠭࠽࠾࠿ࡀࡁࡂࠦࡍࡂࡖࡆࡌࠥࡌࡏࡖࡐࡇࠤࡂࡃ࠽࠾࠿ࡀࠫࡹ"))
            dixie.log(item)
            dixie.log(l1lllll_opy_)
            return file[l11ll_opy_ (u"ࠧࡧ࡫࡯ࡩࠬࡺ")]
def l1l1l11l_opy_(addon, l1lllll_opy_):
    l1lllll_opy_ = l1lllll_opy_.upper()
    if addon == l1l11111_opy_:
        return l1lllll_opy_.rsplit(l11ll_opy_ (u"ࠨࠋࠪࡻ"), 1)[0]
    return l1lllll_opy_.rsplit(l11ll_opy_ (u"ࠩࠣ࠱ࠥ࠭ࡼ"), 1)[0]
def l1l1ll_opy_(addon, theDate, theTime):
    if addon == l1l11111_opy_:
        return theDate + l11ll_opy_ (u"ࠪࠍࠬࡽ") + theTime
    return theDate + l11ll_opy_ (u"ࠫࠥ࠳ࠠࠨࡾ") + theTime
def doJSON(query):
    l1l1l11_opy_  = (l11ll_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࠦࡵࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨࡿ") % query)
    response = xbmc.executeJSONRPC(l1l1l11_opy_)
    content  = json.loads(response)
    return content
def cleanPrefix(text):
    l1l1111_opy_ = text.strip()
    l1ll1_opy_  = [l11ll_opy_ (u"࠭ࡕࡌ࠼ࠪࢀ"), l11ll_opy_ (u"ࠧࡊࡐࡗ࠾ࠥ࠭ࢁ"), l11ll_opy_ (u"ࠨࡎࡌ࡚ࡊࠦࠧࢂ"), l11ll_opy_ (u"ࠩࡘࡏࠥࡲࠠࠨࢃ"),l11ll_opy_ (u"ࠪࡍࡓࡀࠠࠨࢄ"), l11ll_opy_ (u"ࠫࡎࡔࠠ࡭ࠢࠪࢅ"), l11ll_opy_ (u"ࠬࡏࡎࠡࡾࠣࠫࢆ"), l11ll_opy_ (u"࠭ࡄࡆࠢ࡯ࠤࠬࢇ"), l11ll_opy_ (u"ࠧࡓࡃࡇࠤࡱࠦࠧ࢈"), l11ll_opy_ (u"ࠨࡘࡌࡔࠥࡲࠠࠨࢉ"), l11ll_opy_ (u"ࠩࠣࡐࡴࡩࡡ࡭ࠩࢊ"), l11ll_opy_ (u"࡙ࠪࡘࡇ࠯ࡄࡃࠣ࠾ࠥ࠭ࢋ"), l11ll_opy_ (u"࡚࡙ࠫࡁ࠰ࡅࡄ࠾ࠥ࠭ࢌ"), l11ll_opy_ (u"ࠬࡉࡁ࠻ࠢࠪࢍ"),l11ll_opy_ (u"࠭ࡃࡂࠢ࠽ࠤࠬࢎ"),l11ll_opy_ (u"ࠧࡄࡃࠣࠫ࢏"),l11ll_opy_ (u"ࠨࡗࡎࠤ࡛ࡏࡐࠡ࠼ࠣࠫ࢐"), l11ll_opy_ (u"ࠩࡘࡏࠥࡀࠠࠨ࢑"), l11ll_opy_ (u"࡙ࠪࡐࡀࠠࠨ࢒"), l11ll_opy_ (u"࡚ࠫࡑࠠࡽࠢࠪ࢓"), l11ll_opy_ (u"࡛ࠬࡓࡂࠢ࠽ࠤࡑࡏࡖࡆࠢࠪ࢔"), l11ll_opy_ (u"࠭ࡕࡔࡃࠣࢀࠥࡒࡉࡗࡇࠣࠫ࢕"), l11ll_opy_ (u"ࠧࡖࡕࡄࠤ࠿ࠦࠧ࢖"), l11ll_opy_ (u"ࠨࡗࡖࡅࠥࡀࠧࢗ"), l11ll_opy_ (u"ࠩࡘࡗࡆࡀࠠࠨ࢘"), l11ll_opy_ (u"࡙ࠪࡘࡇࠠࡽ࢙ࠢࠪ"), l11ll_opy_ (u"࡚࡙ࠫࡁ࢚ࠡࠩ"), l11ll_opy_ (u"࡛ࠬࡓࠡࡾ࢛ࠣࠫ"),l11ll_opy_ (u"࠭ࡕࡔ࠼ࠣࠫ࢜"), l11ll_opy_ (u"ࠧࡏࡑࡕࡈࡎࡉࠠࠨ࢝")]
    for prefix in l1ll1_opy_:
        if prefix in l1l1111_opy_:
            l1l1111_opy_ = l1l1111_opy_.replace(prefix, l11ll_opy_ (u"ࠨࠩ࢞"))
    return l1l1111_opy_.strip()
def l11lll_opy_(addon, name, title, start, stream):
    import time
    dixie.log(l11ll_opy_ (u"ࠩࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࠥࡉࡁࡕࡅࡋࠤ࡚ࡖࠠࡍ࡚ࡗ࡚ࠥࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࠩ࢟"))
    l1l11l11_opy_ = stream.split(l11ll_opy_ (u"ࠪࢀࠬࢠ"))
    for url in l1l11l11_opy_:
        if (l1ll1ll_opy_ in url) or (l11lllll_opy_ in url):
            dixie.log(l11ll_opy_ (u"ࠫࡑ࡞ࡔࡗࠢࡘࡖࡑ࠴࠮࠯࠼ࠣࠩࡸ࠭ࢡ") % url)
            l1llll1_opy_ = url.split(CLOSE_OTT)[0].replace(OPEN_OTT, l11ll_opy_ (u"ࠬ࠭ࢢ"))
            break
    import urllib
    l1ll111_opy_ = l1llllll_opy_()
    dixie.log(l11ll_opy_ (u"࠭ࡅࡑࡉࠣࡗࡹࡧࡲࡵࠢࡗ࡭ࡲ࡫࠮࠯࠰࠽ࠤࠪࡹࠧࢣ") % start)
    dixie.log(l11ll_opy_ (u"ࠧࡐࡨࡩࡷࡪࡺࠠࡪࡰࠣࡷࡪࡩ࡯࡯ࡦࡶ࠾ࠥࠫࡳࠨࢤ") % l1ll111_opy_)
    l1l1l1_opy_  =  start - datetime.timedelta(seconds=l1ll111_opy_)
    dixie.log(l11ll_opy_ (u"ࠨࡕࡷࡥࡷࡺࠠࡕ࡫ࡰࡩࠥࡵࡦࡧࡵࡨࡸ࠿ࠦࠥࡴࠩࢥ") % l1l1l1_opy_)
    l11l1l1_opy_     = l111ll_opy_(l1llll1_opy_)
    l11l_opy_ = str(l1l1l1_opy_)
    l1l11l1_opy_   = l11l_opy_.split(l11ll_opy_ (u"ࠩࠣࠫࢦ"))[0]
    l1l1llll_opy_  = l11l_opy_.split(l11ll_opy_ (u"ࠪࠤࠬࢧ"))[1]
    l11l1_opy_  = time.strptime(l1l1llll_opy_,  l11ll_opy_ (u"ࠫࠪࡎ࠺ࠦࡏ࠽ࠩࡘ࠭ࢨ"))
    l11l1_opy_  = time.strftime(l11ll_opy_ (u"ࠬࠫࡉ࠻ࠧࡐࠤࠪࡶࠧࢩ"),  l11l1_opy_)
    l1lll111_opy_ = time.strptime(l1l11l1_opy_,   l11ll_opy_ (u"࡚࠭ࠥ࠯ࠨࡱ࠲ࠫࡤࠨࢪ"))
    l1lll111_opy_ = time.strftime(l11ll_opy_ (u"ࠧࠦࡃ࠯ࠤࠪࡈࠠࠦࡦࠪࢫ"), l1lll111_opy_)
    query = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸ࠵࠿ࡤࡪࡤࡲࡳ࡫࡬ࡠ࡫ࡧࡁࠪࡹࠦࡥࡣࡷࡩࡂࠫࡳࠧࡦࡤࡸࡪࡥࡴࡪࡶ࡯ࡩࡂࠫࡳࠧ࡫ࡰ࡫ࡂࠬ࡭ࡰࡦࡨࡁࡷ࡫ࡣࡰࡴࡧ࡭ࡳ࡭ࡳࠧࡶ࡬ࡸࡱ࡫࠽ࠦࡵࠪࢬ") % (addon, l11l1l1_opy_, l1l11l1_opy_, l1lll111_opy_, l1llll1_opy_)
    l111l11_opy_  = l11ll_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬࢭ") % query
    if not l11l1l1_opy_:
        dixie.DialogOK(l11ll_opy_ (u"ࠪࡗࡴࡸࡲࡺ࠰ࠪࢮ"), l11ll_opy_ (u"ࠫ࡜࡫ࠠࡤࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡪ࡮ࡴࡤࠡࡣࠣࡧࡦࡺࡣࡩࡷࡳࠤࡸ࡫ࡲࡷ࡫ࡦࡩࠥ࡬࡯ࡳࠢࡷ࡬࡮ࡹࠠࡤࡪࡤࡲࡳ࡫࡬࠯ࠩࢯ"), l11ll_opy_ (u"ࠬࡘࡥࡷࡧࡵࡸ࡮ࡴࡧࠡࡤࡤࡧࡰࠦࡴࡰࠢࡏ࡭ࡻ࡫ࠠࡕࡘ࠱ࠫࢰ"))
        return None
    l1111_opy_    = xbmc.executeJSONRPC(l111l11_opy_)
    response   = json.loads(l1111_opy_)
    result     = response[l11ll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࢱ")]
    l1ll11l_opy_ = result[l11ll_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࢲ")]
    for l1ll1ll1_opy_ in l1ll11l_opy_:
        try:
            l1l11_opy_ = l1ll1ll1_opy_[l11ll_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ࢳ")]
            l1lllll_opy_   = l1ll1ll1_opy_[l11ll_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨࢴ")]
            if l11l1_opy_ in l1lllll_opy_:
                dixie.DialogOK(l11ll_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡳࡷࡧ࡮ࡨࡧࡠࡇࡦࡺࡣࡩ࠯ࡸࡴࠥࡹࡴࡳࡧࡤࡱࠥ࡬࡯ࡶࡰࡧ࠲ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢵ"), l11ll_opy_ (u"ࠫࡔࡴ࠭ࡕࡣࡳࡴ࠳࡚ࡖࠡࡹ࡬ࡰࡱࠦ࡮ࡰࡹࠣࡴࡱࡧࡹ࠻ࠢ࡞ࡇࡔࡒࡏࡓࠢࡲࡶࡦࡴࡧࡦ࡟࡞ࡆࡢࠫࡳ࡜࠱ࡅࡡࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢶ") % (title))
                return l1l11_opy_
        except Exception, e:
            dixie.log(l11ll_opy_ (u"ࠬࡋࡒࡓࡑࡕ࠾ࠥࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡࡶ࡫ࡶࡴࡽ࡮ࠡ࡫ࡱࠤ࡬࡫ࡴࡍ࡚ࡗ࡚ࡗ࡫ࡣࡰࡴࡧ࡭ࡳ࡭ࠠࠦࡵࠪࢷ") % str(e))
            dixie.DialogOK(l11ll_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠳࠭ࢸ"), l11ll_opy_ (u"ࠧࡘࡧࠣࡧࡴࡻ࡬ࡥࠢࡱࡳࡹࠦࡦࡪࡰࡧࠤࡦࠦࡣࡢࡶࡦ࡬ࡺࡶࠠࡴࡶࡵࡩࡦࡳࠠࡧࡱࡵࠤࡹ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯࠱ࠫࢹ"), l11ll_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡶࡵࡽࠥࡧࡧࡢ࡫ࡱࠤࡱࡧࡴࡦࡴ࠱ࠫࢺ"))
            return None
def l111ll_opy_(l1llll1_opy_):
    l1llll1_opy_ = l1llll1_opy_.upper()
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩ࠶ࡉࠬࢻ") : return 188
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡅࡇࡉࠠࡆࡃࡖࡘࠬࢼ") : return 363
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡆࡈࡃࠨࢽ") : return 346
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡇࡍࡄࠩࢾ") : return 375
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡁࡍࡋࡅࡍࠥࡏࡒࡆࡎࡄࡒࡉ࠭ࢿ") : return 280
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡂࡐࡌࡑࡆࡒࠠࡑࡎࡄࡒࡊ࡚ࠠࡖࡕࡄࠫࣀ") : return 386
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡃࡑࡍࡒࡇࡌࠡࡒࡏࡅࡓࡋࡔࠨࣁ") : return 19
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡄࡖࡊࡔࡁࠡࡕࡓࡓࡗ࡚ࡓࠡ࠳ࠣࡌࡉࠦࡃࡓࡑࡄࡘࡎࡇࠧࣂ") : return 403
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡅࡗࡋࡎࡂࠢࡖࡔࡔࡘࡔࡔࠢ࠵ࠤࡍࡊࠠࡄࡔࡒࡅ࡙ࡏࡁࠨࣃ") : return 404
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡆࡘࡅࡏࡃࠣࡗࡕࡕࡒࡕࡕࠣ࠷ࠥࡎࡄࠡࡅࡕࡓࡆ࡚ࡉࡂࠩࣄ") : return 405
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡇࡒࡆࡐࡄࠤࡘࡖࡏࡓࡖࡖࠤ࠹ࠦࡈࡅࠢࡆࡖࡔࡇࡔࡊࡃࠪࣅ") : return 406
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡁࡓࡇࡑࡅ࡙ࠥࡐࡐࡔࡗࡗࠥ࠻ࠠࡔࡔࡅࠫࣆ") : return 407
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡂࡖࠣࡘࡍࡋࠠࡓࡃࡆࡉࡘ࠭ࣇ") : return 273
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡄࡅࡇࠥࡕࡎࡆ࡝ࡋࡈࡢ࠭ࣈ") : return 210
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡅࡆࡈࠦࡔࡘࡑ࡞ࡌࡉࡣࠧࣉ") : return 211
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡆࡊࡏࡎࠡࡕࡓࡓࡗ࡚ࠠ࠲࠲ࠣࡌࡉ࠮ࡔࡆࡕࡗ࠭ࠬ࣊") : return 300
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡇࡋࡉࡏࠢࡖࡔࡔࡘࡔࠡ࠳࠴ࠤࡍࡊࠨࡕࡇࡖࡘ࠮࠭࣋") : return 389
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡈࡅࡊࡐࠣࡗࡕࡕࡒࡕࠢ࠴ࡌࡉ࠮ࡔࡆࡕࡗ࠭ࠬ࣌") : return 285
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡂࡆࡋࡑࠤࡘࡖࡏࡓࡖࠣ࠶ࠥࡎࡄࠩࡖࡈࡗ࡙࠯ࠧ࣍") : return 286
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡃࡇࡌࡒ࡙ࠥࡐࡐࡔࡗࠤ࠸ࠦࡈࡅࠪࡗࡉࡘ࡚ࠩࠨ࣎") : return 287
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡄࡈࡍࡓࠦࡓࡑࡑࡕࡘࠥ࠺ࠠࡉࡆࠫࡘࡊ࡙ࡔ࣏ࠪࠩ") : return 288
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡅࡉࡎࡔࠠࡔࡒࡒࡖ࡙ࠦ࠵ࠡࡊࡇ࡙ࠬࡋࡓࡕ࣐ࠫࠪ") : return 289
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡆࡊࡏࡎࠡࡕࡓࡓࡗ࡚ࠠ࠷ࠢࡋࡈ࡚࠭ࡅࡔࡖ࣑ࠬࠫ") : return 290
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡇࡋࡉࡏࠢࡖࡔࡔࡘࡔࠡ࠹ࠣࡌࡉ࠮ࡔࡆࡕࡗ࣒࠭ࠬ") : return 291
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡈࡅࡊࡐࠣࡗࡕࡕࡒࡕࠢ࠻ࠤࡍࡊࠨࡕࡇࡖࡘ࠮࣓࠭") : return 292
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡂࡆࡋࡑࠤࡘࡖࡏࡓࡖࠣ࠽ࠥࡎࡄࠩࡖࡈࡗ࡙࠯ࠧࣔ") : return 293
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡃࡖࠣࡗࡕࡕࡒࡕࠢ࠴ࠤࡍࡊࠠࠩࡖࡈࡗ࡙࠯ࠧࣕ") : return 306
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡄࡗࠤࡘࡖࡏࡓࡖࠣ࠵ࠬࣖ") : return 17
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡅࡘ࡙ࠥࡐࡐࡔࡗࠤ࠷ࠦࡈࡅࠢࠫࡘࡊ࡙ࡔࠪࠩࣗ") : return 307
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡆ࡙ࠦࡓࡑࡑࡕࡘࠥ࠸ࠧࣘ") : return 18
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡇ࡚ࠠࡔࡒࡒࡖ࡙ࠦࡅࡔࡒࡑࠫࣙ") : return 24
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡈࡔࠡࡕࡓࡓࡗ࡚ࠠࡆࡗࡕࡓࡕࡋࠧࣚ") : return 216
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡂࡂࡄ࡜ࠤ࡙࡜ࠧࣛ") : return 299
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡃࡎࡘࡉࠥࡎࡕࡔࡖࡏࡉࡗࠦࡅࡖࡔࡒࡔࡊ࠭ࣜ") : return 241
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡄࡒࡓࡒࡋࡒࡂࡐࡊࠫࣝ") : return 192
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡅࡓ࡝ࠦࡎࡂࡖࡌࡓࡓ࠭ࣞ") : return 185
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡆࡗࡏࡔࡊࡕࡋࠤࡊ࡛ࡒࡐࡕࡓࡓࡗ࡚࠲ࠨࣟ") : return 173
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡇࡘࡉࡕࡋࡖࡌࠥࡋࡕࡓࡑࡖࡔࡔࡘࡔࠨ࣠") : return 182
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡉࡂࡔࠢࡕࡉࡆࡒࡉࡕ࡛ࠪ࣡") : return 190
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡃࡏࡄࡆࠫ࣢") : return 366
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡄࡐࡑࣣࠫ") : return 365
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡅࡄࡖ࡙ࡕࡏࡏࠢࡑࡉ࡙࡝ࡏࡓࡍ࡙ࠣࡐ࠭ࣤ") : return 186
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡆࡅࡗ࡚ࡏࡐࡐࡌࡘࡔ࠭ࣥ") : return 250
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡇࡍࡋࡌࡔࡇࡄࠤ࡙࡜ࣦࠧ") : return 179
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡈࡕࡍࡆࡆ࡜ࠤࡈࡋࡎࡕࡔࡄࡐ࡛ࠥࡓࡂࠩࣧ") : return 374
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡉࡏࡎࡇࡇ࡝ࠥࡉࡅࡏࡖࡕࡅࡑ࠭ࣨ") : return 251
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡃࡐࡏࡈࡈ࡞ࠦࡘࡕࡔࡄࣩࠫ") : return 176
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡄࡔࡌࡑࡊࠦࡉࡏࡘࡈࡗ࡙ࡏࡇࡂࡖࡌࡓࡓ࠭࣪") : return 249
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡆࡄ࡚ࡊ࠭࣫") : return 230
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡇࡍࡘࡉࡏࡗࡇࡕ࡝ࠥࡎࡉࡔࡖࡒࡖ࡞࠭࣬") : return 20
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡈࡎ࡙ࡃࡐࡘࡈࡖ࡞ࠦࡓࡄࡋࡈࡒࡈࡋ࣭ࠧ") : return 103
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡉࡏࡓࡄࡑ࡙ࡉࡗ࡟ࠠࡕࡗࡕࡆࡔ࣮࠭") : return 102
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡊࡉࡔࡅࡒ࡚ࡊࡘ࡙࠲࣯ࠩ") : return 98
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡄࡊࡕࡆࡓ࡛ࡋࡒࣰ࡚ࠩ") : return 370
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡅࡋࡖࡒࡊ࡟ࡃࡉࡐࡏࣱࠫ") : return 117
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡆࡌࡗࡓࡋ࡙ࡋࡗࡑࡍࡔࡘࣲࠧ") : return 118
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡈࡗࡕࡔࠠ࠳ࠩࣳ") : return 349
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡉࡘࡖࡎࠨࣴ") : return 348
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡊࡊࡅࡏࠢ࠮࠵ࠬࣵ") : return 278
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡋࡉࡓࠢࡖࡔࡔࡘࡔࡔࣶࠩ") : return 30
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡅࡖࡔࡒࡒࡊ࡝ࡓࠨࣷ") : return 398
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡇࡑ࡛ࠤࡘࡖࡏࡓࡖࡖࠤ࠶࠭ࣸ") : return 352
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡈࡒ࡜ࠥࡔࡅࡘࡕࣹࠪ") : return 274
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡊࡓࡑࡊࠠࡖࡍࣺࠪ") : return 277
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡌ࠷ࠦࡕࡌࠩࣻ") : return 271
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡍࡈࡏࠡࡇࡄࡗ࡙࠭ࣼ") : return 376
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡎࡂࡐࠢࡉࡅࡒࡏࡌ࡚ࠩࣽ") : return 377
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡈࡃࡑࠣࡗࡎࡍࡎࡂࡖࡘࡖࡊ࠭ࣾ") : return 378
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡉࡄࡒࠤ࡟ࡕࡎࡆࠩࣿ") : return 379
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡊࡊࡘ࡛࠭ऀ") : return 384
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡋࡍࡘ࡚ࡏࡓ࡛࡙ࠣࡐ࠭ँ") : return 268
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡌࡎ࡙ࡔࡐࡔ࡜ࠤ࡚࡙ࡁࠨं") : return 369
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡍࡕࡍࡆࠢ࠮࠵ࠬः") : return 279
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡎࡏࡓࡔࡒࡖࠥࡉࡈࡂࡐࡑࡉࡑࠦࡕࡌࠩऄ") : return 183
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡉࡅࠢࡘࡏࠬअ") : return 229
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡊࡖ࡙ࠤ࠷࠭आ") : return 208
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡋࡗ࡚ࠥ࠹ࠧइ") : return 207
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡌࡘ࡛ࠦ࠴ࠨई") : return 209
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡍ࡙࡜ࠧउ") : return 206
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡑࡌࡃࠡࡖ࡙ࠫऊ") : return 180
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡓࡉࡐࠢࡖࡘࡆࡊࡉࡖࡏࠣ࠵࠵࠸ࠠࡉࡆࠪऋ") : return 334
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡍࡊࡑࠣࡗ࡙ࡇࡄࡊࡗࡐࠤ࠶࠶࠳ࠡࡊࡇࠫऌ") : return 335
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡎࡋࡒࠤࡘ࡚ࡁࡅࡋࡘࡑࠥ࠷࠰࠵ࠢࡋࡈࠬऍ") : return 336
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡏࡌࡓ࡙ࠥࡔࡂࡆࡌ࡙ࡒࠦ࠱࠱࠷ࠣࡌࡉ࠭ऎ") : return 337
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡐࡍࡔࠦࡓࡕࡃࡇࡍ࡚ࡓࠠ࠲࠲࠹ࠤࡍࡊࠧए") : return 338
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡑࡎࡕࠠࡔࡖࡄࡈࡎ࡛ࡍࠡ࠳࠳࠻ࠥࡎࡄࠨऐ") : return 333
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡒ࡚ࡖࠡࡄࡄࡗࡊ࠭ऑ") : return 132
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡓࡔࡗࠢࡇࡅࡓࡉࡅࠨऒ") : return 131
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡍࡕࡘࠣࡌࡎ࡚ࡓࠢࠩओ") : return 135
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡎࡖ࡙ࠤࡒ࡛ࡓࡊࡅࠪऔ") : return 217
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡏࡗ࡚ࠥࡘࡏࡄࡍࡖࠫक") : return 133
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡐ࡙࡙࡜ࠧख") : return 106
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡑࡔ࡚ࡏࡓࡕ࡙ࠣࡐ࠭ग") : return 215
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡓࡈࡁࠨघ") : return 283
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡔࡂࡄࠢࡈࡅࡘ࡚ࠧङ") : return 361
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡎࡊࡅࡎࠤ࡙ࡕࡏࡏࡕࠪच") : return 296
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡏࡃࡗࠤࡌࡋࡏ࡙ࠡࡌࡐࡉࠦࡕࡌࠩछ") : return 269
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡐࡄࡘࡎࡕࡎࡂࡎࠣࡋࡊࡕࡇࡓࡃࡓࡌࡎࡉࠠࡖࡍࠪज") : return 270
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡑࡅ࡙ࡏࡏࡏࡃࡏࠤࡌࡋࡏࡈࡔࡄࡔࡍࡏࡃࠡࡗࡖࡅࠬझ") : return 371
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡒࡎࡉࡋࠡࡌࡘࡒࡎࡕࡒࠨञ") : return 297
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡓࡏࡃࡌࠢࡘࡏࠬट") : return 295
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡖࡒࡆࡏࡌࡉࡗ࡙ࡐࡐࡔࡗࡗࠬठ") : return 29
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡒࡕࡇࠣࡓࡓࡋࠧड") : return 69
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡓࡖࡈࠤ࡙࡝ࡏ࡜ࡊࡇࡡࠬढ") : return 70
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡔࡗࡉࡏࡘࠧण") : return 89
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡕࡅࡈࡏࡎࡈࠢࡘࡏࠬत") : return 26
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡖࡊࡇࡌࠡࡎࡌ࡚ࡊ࡙ࠧथ") : return 275
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡘࡑ࡙ࠡࡄࡘࡒࡉࡋࡓࡍࡋࡊࡅࠥ࠷ࠠࡉࡆ࡞ࡈࡊࡣࠧद") : return 408
    if l1llll1_opy_ == l11ll_opy_ (u"࡙ࠬࡋ࡚ࠢࡑࡉ࡜࡙ࠧध") : return 263
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡓࡌ࡛ࠣ࠵ࠬन") : return 177
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡔࡍ࡜ࠤ࠷࠭ऩ") : return 178
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡕࡎ࡝ࠥࡇࡃࡕࡋࡒࡒࠥࡓࡏࡗࡋࡈࡗࠬप") : return 16
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡖࡏ࡞ࠦࡁࡕࡎࡄࡒ࡙ࡏࡃࠨफ") : return 174
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡗࡐ࡟ࠠࡄࡑࡐࡉࡉ࡟ࠠࡎࡑ࡙ࡍࡊ࡙ࠧब") : return 34
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡘࡑ࡙ࠡࡆࡕࡅࡒࡇࡒࡐࡏࠣࡑࡔ࡜ࡉࡆࡕࠪभ") : return 97
    if l1llll1_opy_ == l11ll_opy_ (u"࡙ࠬࡋ࡚ࠢࡉࡅࡒࡏࡌ࡚ࠢࡐࡓ࡛ࡏࡅࡔࠩम") : return 36
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡓࡌ࡛ࠣࡋࡗࡋࡁࡕࡕࠣࡑࡔ࡜ࡉࡆࡕࠪय") : return 37
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡔࡍ࡜ࠤࡒࡕࡖࡊࡇࡖࠤࡉࡏࡓࡏࡇ࡜ࠫर") : return 220
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡕࡎ࡝ࠥࡖࡒࡆࡏࡌࡉࡗࡋࠠࡎࡑ࡙ࡍࡊ࡙ࠧऱ") : return 40
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡖࡏ࡞ࠦࡓࡄࡈࡌࡌࡔࡘࡒࡐࡔࠣࡑࡔ࡜ࡉࡆࡕࠪल") : return 41
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡗࡐ࡟ࠠࡔࡇࡏࡉࡈ࡚ࠠࡎࡑ࡙ࡍࡊ࡙ࠧळ") : return 42
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡘࡑ࡙ࠡࡕࡓࠤࡓࡋࡗࡔࠢࡋࡕࠬऴ") : return 175
    if l1llll1_opy_ == l11ll_opy_ (u"࡙ࠬࡋ࡚ࠢࡖࡔࡔࡘࡔࠡ࠳ࠣࡌࡉࠦࠨࡕࡇࡖࡘ࠮࠭व") : return 301
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡓࡌ࡛ࠣࡗࡕࡕࡒࡕࠢ࠵ࠤࡍࡊࠠࠩࡖࡈࡗ࡙࠯ࠧश") : return 302
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡔࡍ࡜ࠤࡘࡖࡏࡓࡖࠣ࠷ࠥࡎࡄࠡࠪࡗࡉࡘ࡚ࠩࠨष") : return 303
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡕࡎ࡝࡙ࠥࡐࡐࡔࡗࠤ࠹ࠦࡈࡅࠢࠫࡘࡊ࡙ࡔࠪࠩस") : return 304
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡖࡏ࡞ࠦࡓࡑࡑࡕࡘࠥ࠻ࠠࡉࡆ࡙ࠣࠬࡋࡓࡕࠫࠪह") : return 305
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡗࡐ࡟ࠠࡔࡒࡒࡖ࡙࡙ࠠ࠲ࠩऺ") : return 95
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡘࡑ࡙ࠡࡕࡓࡓࡗ࡚ࡓࠡ࠴ࠪऻ") : return 136
    if l1llll1_opy_ == l11ll_opy_ (u"࡙ࠬࡋ࡚ࠢࡖࡔࡔࡘࡔࡔࠢ࠶़ࠫ") : return 43
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡓࡌ࡛ࠣࡗࡕࡕࡒࡕࡕࠣ࠸ࠬऽ") : return 119
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡔࡍ࡜ࠤࡘࡖࡏࡓࡖࡖࠤ࠺࠭ा") : return 120
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡕࡎ࡝࡚ࠥࡈࡓࡋࡏࡐࡊࡘࠠࡎࡑ࡙ࡍࡊ࡙ࠧि") : return 96
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡖࡏ࡞ࠦࡌࡊࡘࡌࡒࡌ࠭ी") : return 298
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡗࡕࡕࡒࡕࡕࠣࡊ࠶࠭ु") : return 45
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫࡘ࡟ࡆ࡚ࠢࡘࡗࡆ࠭ू") : return 383
    if l1llll1_opy_ == l11ll_opy_ (u"࡚ࠬࡃࡎࠢ࠮࠵࡛ࠥࡋࠨृ") : return 189
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡔࡈ࠶ࠪॄ") : return 88
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡕࡕࡑࠤ࠶࠭ॅ") : return 339
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡖࡖࡒࠥ࠸ࠧॆ") : return 340
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡗࡗࡓࠦ࠳ࠨे") : return 341
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪࡘࡘࡔࠠ࠵ࠩै") : return 342
    if l1llll1_opy_ == l11ll_opy_ (u"࡙࡙ࠫࡎࠡ࠷ࠪॉ") : return 343
    if l1llll1_opy_ == l11ll_opy_ (u"࡚ࠬࡖ࠴ࠢࡌࡉࠬॊ") : return 87
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡔࡓࡃ࡙ࡉࡑࠦࡃࡉࡃࡑࡒࡊࡒࠫ࠲ࠢࡘࡏࠬो") : return 184
    if l1llll1_opy_ == l11ll_opy_ (u"ࠧࡖࡕࡄࠤࡋࡕࡘࠡࡕࡓࡓࡗ࡚ࡓࠨौ") : return 347
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨࡗࡖࡅࠥࡔࡅࡕ࡙ࡒࡖࡐ्࠭") : return 344
    if l1llll1_opy_ == l11ll_opy_ (u"ࠩࡘࡘ࡛ࠦࡉࡆࠩॎ") : return 272
    if l1llll1_opy_ == l11ll_opy_ (u"࡚ࠪࡎ࡜ࡁࠡࡖࡋࡉࠥࡎࡉࡕࡕࠤࠫॏ") : return 130
    if l1llll1_opy_ == l11ll_opy_ (u"࡛ࠫࡏࡁࡔࡃࡗࠤࡌࡕࡌࡇࠩॐ") : return 125
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬ࡝ࡁࡕࡅࡋࠤࡎࡘࡅࡍࡃࡑࡈࠬ॑") : return 281
    if l1llll1_opy_ == l11ll_opy_ (u"࠭ࡘ࡙࡚࠴॒ࠫ") : return 314
    if l1llll1_opy_ == l11ll_opy_ (u"࡙࡚࡛ࠧ࠶ࠬ॓") : return 315
    if l1llll1_opy_ == l11ll_opy_ (u"ࠨ࡚࡛࡜࠸࠭॔") : return 316
    if l1llll1_opy_ == l11ll_opy_ (u"࡛ࠩ࡜࡝࠺ࠧॕ") : return 317
    if l1llll1_opy_ == l11ll_opy_ (u"ࠪ࡜࡝࡞࠵ࠨॖ") : return 318
    if l1llll1_opy_ == l11ll_opy_ (u"ࠫ࡞ࡋࡓࡕࡇࡕࡈࡆ࡟ࠠࠬ࠳ࠪॗ") : return 282
    if l1llll1_opy_ == l11ll_opy_ (u"ࠬࡓࡏࡗ࠶ࡐࡉࡓ࠷ࠧक़") : return 33
def getHDTVRecording(name, title, start, stream):
    l1l11l11_opy_ = stream.split(l11ll_opy_ (u"࠭ࡼࠨख़"))
    for url in l1l11l11_opy_:
        url   = url.split(CLOSE_OTT)[1].rsplit(l11ll_opy_ (u"ࠧ࠻ࠩग़"))
        l1l111_opy_ = url[0]
        if l1l111_opy_ == l11ll_opy_ (u"ࠨࡊࡇࡘ࡛࠭ज़"):
            addon = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡰࡥࡷࡺࡨࡶࡤࠪड़")
        else:
            addon = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧ࠲ࠨढ़")
    dixie.log(l11ll_opy_ (u"ࠫࡆࡪࡤࡰࡰࠣࡍࡉ࠴࠮࠯࠼ࠣࠩࡸ࠭फ़") % addon)
    Addon  = xbmcaddon.Addon(id=addon)
    path   = Addon.getAddonInfo(l11ll_opy_ (u"ࠬࡶࡡࡵࡪࠪय़"))
    import sys
    sys.path.insert(0, path)
    import api
    l1l1_opy_ = Addon.getSetting(l11ll_opy_ (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧॠ"))
    l1ll11_opy_  = Addon.getSetting(l11ll_opy_ (u"ࠧࡴࡧࡵࡺࡪࡸࠧॡ"))
    l1l1ll1_opy_    = l11ll_opy_ (u"ࠨࠨࡧࡁࡰࡵࡤࡪࠨࡶࡁࠬॢ") + l1l1_opy_ + l11ll_opy_ (u"ࠩࠩࡳࡂ࠭ॣ") + l1ll11_opy_
    import urllib
    l1ll111_opy_ = l1llllll_opy_()
    dixie.log(l11ll_opy_ (u"ࠪࡉࡕࡍࠠࡔࡶࡤࡶࡹࠦࡔࡪ࡯ࡨ࠲࠳࠴࠺ࠡࠧࡶࠫ।") % start)
    dixie.log(l11ll_opy_ (u"ࠫࡔ࡬ࡦࡴࡧࡷࠤ࡮ࡴࠠࡴࡧࡦࡳࡳࡪࡳ࠻ࠢࠨࡷࠬ॥") % l1ll111_opy_)
    l1l1l1_opy_  =  start - datetime.timedelta(seconds=l1ll111_opy_)
    dixie.log(l11ll_opy_ (u"࡙ࠬࡴࡢࡴࡷࠤ࡙࡯࡭ࡦࠢࡲࡪ࡫ࡹࡥࡵ࠼ࠣࠩࡸ࠭०") % l1l1l1_opy_)
    l11l_opy_ = str(l1l1l1_opy_)
    l11l1ll_opy_  = l11l_opy_.split(l11ll_opy_ (u"࠭ࠠࠨ१"))[0]
    l1lll1l1_opy_     = l1lll1ll_opy_(name)
    if not l1lll1l1_opy_:
        dixie.DialogOK(l11ll_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠴ࠧ२"), l11ll_opy_ (u"ࠨ࡙ࡨࠤࡨࡵࡵ࡭ࡦࠣࡲࡴࡺࠠࡧ࡫ࡱࡨࠥࡧࠠࡤࡣࡷࡧ࡭ࡻࡰࠡࡵࡨࡶࡻ࡯ࡣࡦࠢࡩࡳࡷࠦࡴࡩ࡫ࡶࠤࡨ࡮ࡡ࡯ࡰࡨࡰ࠳࠭३"), l11ll_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡷࡶࡾࠦࡡ࡯ࡱࡷ࡬ࡪࡸࠠࡤࡪࡤࡲࡳ࡫࡬࠯ࠩ४"))
        return None
    l1l1111l_opy_  = l11l_opy_.split(l11ll_opy_ (u"ࠪ࠱ࠬ५"), 1)[-1].rsplit(l11ll_opy_ (u"ࠫ࠿࠭६"), 1)[0]
    theTime    = urllib.quote_plus(l1l1111l_opy_)
    response   = api.remote_call( l11ll_opy_ (u"ࠧࡺࡶࡢࡴࡦ࡬࡮ࡼࡥ࠰ࡩࡨࡸࡤࡨࡹࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡡࡤࡲࡩࡥࡤࡢࡶࡨ࠲ࡵ࡮ࡰࠣ७") , {l11ll_opy_ (u"ࠨࡤࡢࡶࡨࠦ८"): l11l1ll_opy_, l11ll_opy_ (u"ࠢࡪࡦࠥ९"): l1lll1l1_opy_ } )
    l1ll11l_opy_ = response[l11ll_opy_ (u"ࠣࡤࡲࡨࡾࠨ॰")]
    if not l1ll11l_opy_:
        dixie.DialogOK(l11ll_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠯ࠩॱ"), l11ll_opy_ (u"࡛ࠪࡪࠦࡣࡰࡷ࡯ࡨࠥࡴ࡯ࡵࠢࡩ࡭ࡳࡪࠠࡢࠢࡦࡥࡹࡩࡨࡶࡲࠣࡷࡹࡸࡥࡢ࡯ࠣࡪࡴࡸࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲ࠴ࠧॲ"), l11ll_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡹࡸࡹࠡࡣࡪࡥ࡮ࡴࠠ࡭ࡣࡷࡩࡷ࠴ࠧॳ"))
        return None
    for l1ll1ll1_opy_ in l1ll11l_opy_:
        l1l11_opy_ = l1ll1ll1_opy_[l11ll_opy_ (u"ࠧࡶ࡬ࡰࡶࠥॴ")]
        if l1l1111l_opy_ in l1l11_opy_:
            dixie.DialogOK(l11ll_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡯ࡳࡣࡱ࡫ࡪࡣࡃࡢࡶࡦ࡬࠲ࡻࡰࠡࡵࡷࡶࡪࡧ࡭ࠡࡨࡲࡹࡳࡪ࠮࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩॵ"), l11ll_opy_ (u"ࠧࡐࡰ࠰ࡘࡦࡶࡰ࠯ࡖ࡙ࠤࡼ࡯࡬࡭ࠢࡱࡳࡼࠦࡰ࡭ࡣࡼ࠾ࠥࡡࡃࡐࡎࡒࡖࠥࡵࡲࡢࡰࡪࡩࡢࡡࡂ࡞ࠧࡶ࡟࠴ࡈ࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩॶ") % (title))
            return l1ll1ll1_opy_[l11ll_opy_ (u"ࠣࡷࡵࡰࠧॷ")] + l1l1ll1_opy_
def l1lll1ll_opy_(name):
    l1l1ll11_opy_   = dixie.PROFILE
    ll_opy_ = os.path.join(l1l1ll11_opy_, l11ll_opy_ (u"ࠩ࡬ࡲ࡮࠭ॸ"), l11ll_opy_ (u"ࠪࡧࡦࡺࡣࡩࡷࡳ࠲ࡹࡾࡴࠨॹ"))
    l11l111_opy_   = json.load(open(ll_opy_))
    for channel in l11l111_opy_:
        if name.upper() == channel[l11ll_opy_ (u"ࠫࡔ࡚ࡔࡗࠩॺ")].upper():
            return channel[l11ll_opy_ (u"࡛ࠬࡒࡍࠩॻ")]
def l1llllll_opy_():
    import time
    gmt = time.gmtime()
    loc = time.localtime()
    GMT = datetime.datetime(*gmt[:6]).isoformat(l11ll_opy_ (u"࠭ࠠࠨॼ"))
    LOC = datetime.datetime(*loc[:6]).isoformat(l11ll_opy_ (u"ࠧࠡࠩॽ"))
    dixie.log(gmt)
    dixie.log(loc)
    l11ll11_opy_ = dixie.parseTime(GMT)
    l111lll_opy_ = dixie.parseTime(LOC)
    dixie.log(l11ll11_opy_)
    dixie.log(l111lll_opy_)
    dixie.log(l11ll_opy_ (u"ࠨࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࠥࡕࡆࡇࡕࡈࡘࠥࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࠪॾ"))
    l1ll111_opy_ = l11ll11_opy_ - l111lll_opy_
    dixie.log(l1ll111_opy_)
    l1ll111_opy_ = ((l1ll111_opy_.days * 86400) + (l1ll111_opy_.seconds + 1800)) / 3600
    dixie.log(l1ll111_opy_)
    l1ll111_opy_ *= -3600
    dixie.log(l1ll111_opy_)
    dixie.log(l11ll_opy_ (u"ࠩࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࠫॿ"))
    return l1ll111_opy_