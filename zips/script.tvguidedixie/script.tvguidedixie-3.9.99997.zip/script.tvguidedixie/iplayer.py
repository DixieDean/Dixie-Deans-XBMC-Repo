# coding: UTF-8
import sys
l1l11ll1_opy_ = sys.version_info [0] == 2
l11111l_opy_ = 2048
l1ll111l_opy_ = 7
def l1l1l_opy_ (l11ll1_opy_):
	global l1111ll_opy_
	l1lll1ll_opy_ = ord (l11ll1_opy_ [-1])
	l1l1l11l_opy_ = l11ll1_opy_ [:-1]
	l11ll11_opy_ = l1lll1ll_opy_ % len (l1l1l11l_opy_)
	l111l1_opy_ = l1l1l11l_opy_ [:l11ll11_opy_] + l1l1l11l_opy_ [l11ll11_opy_:]
	if l1l11ll1_opy_:
		l1llll_opy_ = unicode () .join ([unichr (ord (char) - l11111l_opy_ - (l1lll_opy_ + l1lll1ll_opy_) % l1ll111l_opy_) for l1lll_opy_, char in enumerate (l111l1_opy_)])
	else:
		l1llll_opy_ = str () .join ([chr (ord (char) - l11111l_opy_ - (l1lll_opy_ + l1lll1ll_opy_) % l1ll111l_opy_) for l1lll_opy_, char in enumerate (l111l1_opy_)])
	return eval (l1llll_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
import mapping
ADDON    = dixie.ADDON
l1l1ll1l_opy_ = dixie.PROFILE
l1lllll1_opy_  = os.path.join(l1l1ll1l_opy_, l1l1l_opy_ (u"ࠫ࡮ࡴࡩࠨࠀ"))
l1lll11_opy_    = os.path.join(l1lllll1_opy_, l1l1l_opy_ (u"ࠬࡳࡡࡱࡲ࡬ࡲ࡬ࡹ࠮࡫ࡵࡲࡲࠬࠁ"))
l1111l_opy_   = os.path.join(l1lllll1_opy_, l1l1l_opy_ (u"࠭࡭ࡢࡲࡶ࠲࡯ࡹ࡯࡯ࠩࠂ"))
LABELFILE  = os.path.join(l1lllll1_opy_, l1l1l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱࡹ࠮࡫ࡵࡲࡲࠬࠃ"))
l11ll1ll_opy_ = os.path.join(l1lllll1_opy_, l1l1l_opy_ (u"ࠨࡲࡵࡩ࡫࡯ࡸࡦࡵ࠱࡮ࡸࡵ࡮ࠨࠄ"))
l1l1llll_opy_  = json.load(open(l1lll11_opy_))
l1l1l1l1_opy_      = json.load(open(l1111l_opy_))
labelmaps = json.load(open(LABELFILE))
l111_opy_  = json.load(open(l11ll1ll_opy_))
l1l11ll_opy_ = l1l1l_opy_ (u"ࠩࠪࠅ")
def l11lll_opy_(i, t1, l1l11l_opy_=[]):
 t = l1l11ll_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l11l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11_opy_ = l11lll_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11l1l_opy_ = l11lll_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1l1l11_opy_       = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡧࡪࡺࡶࠨࠆ")
l1l111ll_opy_  = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡆࡱࡧࡣ࡬ࡋࡦࡩ࡙࡜ࠧࠇ")
dexter    = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸࠨࠈ")
l1ll11_opy_   = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡋ࡮ࡥ࡮ࡨࡷࡸ࠭ࠉ")
l1ll1l_opy_       = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡦࡢࡤ࡫ࡳࡸࡺࡩ࡯ࡩࠪࠊ")
l1l11111_opy_  = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡧࡴࡨࡩࡻ࡯ࡥࡸࠩࠋ")
l1l1ll_opy_    = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡩࡨ࡬ࡴࡹࡴࡪࡰࡪࠫࠌ")
l11lll1_opy_   = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡫ࡳࡷ࡯ࡺࡰࡰ࡬ࡴࡹࡼࠧࠍ")
l1ll1_opy_  = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡺࡶࡴࡷࡥࡷࠬࠎ")
l111l1l_opy_      = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡯࡯࡮ࡹࡶࡹ࠶ࠬࠏ")
l1l111l1_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡒࡩ࡮࡫ࡷࡰࡪࡹࡳࡊࡒࡗ࡚ࠬࠐ")
l11ll11l_opy_    = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡌࡪ࡯࡬ࡸࡱ࡫ࡳࡴࡘ࠶ࠫࠑ")
l11l_opy_  = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡮ࡣࡷࡶ࡮ࡾࡩࡳࡧ࡯ࡥࡳࡪࠧࠒ")
l1ll1l1l_opy_  = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡏࡤࡸࡸࡈࡵࡪ࡮ࡧࡷࡎࡖࡔࡗࠩࠓ")
l11llll1_opy_   = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡰࡥࡽ࡯ࡷࡦࡤࡷࡺࠬࠔ")
l111ll1_opy_     = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡱࡨࡱࡴࡷ࠯ࡳࡰࡺࡹࠧࠕ")
l1lllll_opy_      = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡲ࡫ࡧࡢ࡫ࡳࡸࡻ࠭ࠖ")
l1_opy_     = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡔࡡࡵࡪࡲ࠲ࡎࡖࡔࡗࠩࠗ")
l1l111_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡮ࡢࡶ࡫ࡳࡦࡴ࡯ࡷࡣࠪ࠘")
nice      = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡯ࡣࡷ࡬ࡴࡹࡵࡣࡵ࡬ࡧࡪ࠭࠙")
l11ll_opy_   = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡲࡵࡩࡲ࡯ࡵ࡮࡫ࡳࡸࡻ࠭ࠚ")
l11lllll_opy_  = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡳࡷࡦࡪࡤࡰࡰࠪࠛ")
root      = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡴࡵࡴࡊࡒࡗ࡚ࠬࠜ")
l1l1l111_opy_     = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡬࡯ࡺ࡮ࡱࡷࡺࠬࠝ")
l1l11l1_opy_    = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡭ࡩࡻ࡯ࡲࡷࡵࡵࡲࡵࡵࠪࠞ")
l1ll1l1_opy_      = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡤࡶࡹࠫࠟ")
l1llll1l_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡔࡷࡳࡶࡪࡳࡡࡤࡻࡗ࡚ࠬࠠ")
l1ll1ll1_opy_   = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡷࡶࡪࡧ࡭ࡴࡷࡳࡶࡪࡳࡥ࠳ࠩࠡ")
l1llll11_opy_   = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡷࡻ࡮ࡹࡴࡦࡦࡷࡺࠬࠢ")
l11l111_opy_   = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡸࡻࡱࡩ࡯ࡩࡶࠫࠣ")
l11l1l1_opy_    = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡶࡴ࡮ࠫࠤ")
l1l_opy_     = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡜ࡁࡅࡇࡕࠫࠥ")
l1lll11l_opy_     = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡖࡊࡒࡖࡹࡵ࡫ࡲࡔࡶࡵࡩࡦࡳࡳࡕࡘࠪࠦ")
l1ll11l1_opy_   = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡹࡶࡵࡩࡦࡳ࠭ࡤࡱࡧࡩࡸ࠭ࠧ")
l1lll111_opy_    = [l1l111_opy_, l1lll11l_opy_, l11ll11l_opy_, l1_opy_, nice, l11ll_opy_, l1l1l111_opy_, l1l11l1_opy_, l1l1ll_opy_, l11l111_opy_, l11l_opy_, l1ll11l1_opy_, l1ll1l1_opy_, l1ll1ll1_opy_, l11l1l1_opy_, l1ll1l_opy_, l1l1l11_opy_, l11lll1_opy_, root, l1lllll_opy_, l1l11111_opy_, l1ll1_opy_, l111l1l_opy_, l1ll11_opy_, l11llll1_opy_, dexter, l1l_opy_, l1llll1l_opy_, l111ll1_opy_, l1llll11_opy_, l11lllll_opy_, l1l111ll_opy_]
def checkAddons():
    for addon in l1lll111_opy_:
        if l1l11lll_opy_(addon):
            try: createINI(addon)
            except: continue
def l1l11lll_opy_(addon):
    if xbmc.getCondVisibility(l1l1l_opy_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡋࡥࡸࡇࡤࡥࡱࡱࠬࠪࡹࠩࠨࠨ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l11ll1l1_opy_  = str(addon).split(l1l1l_opy_ (u"ࠪ࠲ࠬࠩ"))[2] + l1l1l_opy_ (u"ࠫ࠳࡯࡮ࡪࠩࠪ")
    l11llll_opy_   = os.path.join(l1lllll1_opy_, l11ll1l1_opy_)
    response = l1ll1lll_opy_(addon)
    if (addon == l1l_opy_) or (addon == l1ll1ll1_opy_):
        l11l1ll_opy_ = response
    else:
        l11l1ll_opy_ = response[l1l1l_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬࠫ")][l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬࠬ")]
    l1l1l1_opy_  = l1l1l_opy_ (u"ࠧ࡜ࠩ࠭") + addon + l1l1l_opy_ (u"ࠨ࡟࡟ࡲࠬ࠮")
    l1ll11ll_opy_  =  file(l11llll_opy_, l1l1l_opy_ (u"ࠩࡺࠫ࠯"))
    l1ll11ll_opy_.write(l1l1l1_opy_)
    l1l11l11_opy_ = []
    for channel in l11l1ll_opy_:
        l1lll1l_opy_ = l1l111l_opy_(addon)
        l11l11_opy_  = channel[l1l1l_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩ࠰")].split(l1l1l_opy_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࠱"), 1)[0]
        if addon == dexter:
            l11l11_opy_ = l11l11_opy_.split(l1l1l_opy_ (u"ࠬࠦࠫࠡࠩ࠲"), 1)[0]
        if (addon == l1l111_opy_) or (addon == l1lll11l_opy_) or (addon == l1llll11_opy_) or (addon == l11ll11l_opy_) or (addon == l1_opy_) or (addon == nice) or (addon == l1l1l111_opy_) or (addon == l1l11l1_opy_) or (addon == root) or (addon == l1l111l1_opy_) or (addon == l11l111_opy_) or (addon == l1l1ll_opy_):
            l11l11_opy_ = l11l11_opy_.split(l1l1l_opy_ (u"࠭ࠠ࠮ࠢࠪ࠳"), 1)[0]
        l1lll1_opy_ = l1111_opy_(addon, l11l11_opy_)
        l111ll_opy_ = l1lll1l1_opy_(addon, l111_opy_, labelmaps, l1l1llll_opy_, l1l1l1l1_opy_, l11l11_opy_)
        stream  = l1lll1l_opy_ + l1lll1_opy_
        l11111_opy_ = l111ll_opy_  + l1l1l_opy_ (u"ࠧ࠾ࠩ࠴") + stream
        if l11111_opy_ not in l1l11l11_opy_:
            l1l11l11_opy_.append(l11111_opy_)
    l1l11l11_opy_.sort()
    for item in l1l11l11_opy_:
        l1ll11ll_opy_.write(l1l1l_opy_ (u"ࠣࠧࡶࡠࡳࠨ࠵") % item)
    l1ll11ll_opy_.close()
def l1111_opy_(addon, l11l11_opy_):
    if (addon == l1l111_opy_) or (addon == l1lll11l_opy_) or (addon == l1llll11_opy_) or (addon == l11ll11l_opy_) or (addon == l1_opy_) or (addon == nice) or (addon == l11ll_opy_) or (addon == l1l1l111_opy_) or (addon == l1l11l1_opy_) or (addon == root) or (addon == l1l111l1_opy_) or (addon == l1ll1l_opy_) or (addon == l1ll11l1_opy_) or (addon == l11l_opy_) or (addon == l11l111_opy_) or (addon == l1l1ll_opy_):
        l1l1111_opy_ = mapping.cleanLabel(l11l11_opy_)
        l1lll1_opy_ = mapping.editPrefix(l111_opy_, l1l1111_opy_)
        return l1lll1_opy_
    l1l1111_opy_ = mapping.cleanLabel(l11l11_opy_)
    l1lll1_opy_ = mapping.cleanStreamLabel(l1l1111_opy_)
    return l1lll1_opy_
def l1lll1l1_opy_(addon, l111_opy_, labelmaps, l1l1llll_opy_, l1l1l1l1_opy_, l11l11_opy_):
    if (addon == l1l111_opy_) or (addon == l1lll11l_opy_) or (addon == l1llll11_opy_) or (addon == l11ll11l_opy_) or (addon == l1_opy_) or (addon == nice) or (addon == l11ll_opy_) or (addon == l1l1l111_opy_) or (addon == l1l11l1_opy_) or (addon == root) or (addon == l1l111l1_opy_) or (addon == l1ll1l_opy_) or (addon == l1ll11l1_opy_) or (addon == l11l_opy_) or (addon == l11l111_opy_) or (addon == l1l1ll_opy_):
        return l1l1111l_opy_(l111_opy_, l1l1l1l1_opy_, l11l11_opy_)
    l1ll1ll_opy_    = mapping.cleanLabel(l11l11_opy_)
    l1l1111_opy_ = mapping.mapLabel(labelmaps, l1ll1ll_opy_)
    l111ll_opy_ = mapping.cleanPrefix(l1l1111_opy_)
    return mapping.mapChannelName(l1l1llll_opy_, l111ll_opy_)
def l1l1111l_opy_(l111_opy_, l1l1l1l1_opy_, l11l11_opy_):
    l1l1_opy_ = mapping.cleanLabel(l11l11_opy_)
    l1l1111_opy_   = mapping.editPrefix(l111_opy_, l1l1_opy_)
    l1111l1_opy_   = mapping.mapEPGLabel(l111_opy_, l1l1l1l1_opy_, l1l1111_opy_)
    return l1111l1_opy_
def l1ll_opy_(addon, file):
    l1ll1ll_opy_ = file[l1l1l_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨ࠶")].split(l1l1l_opy_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ࠷"), 1)[0]
    l1ll1ll_opy_ = l1ll1ll_opy_.split(l1l1l_opy_ (u"ࠫ࠰࠭࠸"), 1)[0]
    l1ll1ll_opy_ = mapping.cleanLabel(l1ll1ll_opy_)
    return l1ll1ll_opy_
def l1l111l_opy_(addon):
    if addon == l1l111_opy_:
        return l1l1l_opy_ (u"ࠬࡇࡎࡐࡘࡄ࠾ࠬ࠹")
    if addon == l1lll11l_opy_:
        return l1l1l_opy_ (u"࠭ࡖࡊࡒࡖࡗ࠿࠭࠺")
    if addon == l11ll11l_opy_:
        return l1l1l_opy_ (u"ࠧࡍࡋࡐ࠶࠿࠭࠻")
    if addon == l1_opy_:
        return l1l1l_opy_ (u"ࠨࡐࡄࡘࡍࡀࠧ࠼")
    if addon == nice:
        return l1l1l_opy_ (u"ࠩࡑࡍࡈࡋ࠺ࠨ࠽")
    if addon == l11ll_opy_:
        return l1l1l_opy_ (u"ࠪࡔࡗࡋࡍ࠻ࠩ࠾")
    if addon == l1l1l111_opy_:
        return l1l1l_opy_ (u"ࠫࡌࡏ࡚࠻ࠩ࠿")
    if addon == l1l11l1_opy_:
        return l1l1l_opy_ (u"ࠬࡍࡓࡑࡔࡗࡗ࠿࠭ࡀ")
    if addon == l1l1ll_opy_:
        return l1l1l_opy_ (u"࠭ࡇࡆࡊ࠽ࠫࡁ")
    if addon == l11l111_opy_:
        return l1l1l_opy_ (u"ࠧࡕࡘࡎ࠾ࠬࡂ")
    if addon == l11l_opy_:
        return l1l1l_opy_ (u"ࠨࡏࡗ࡜ࡎࡋ࠺ࠨࡃ")
    if addon == l1ll11l1_opy_:
        return l1l1l_opy_ (u"࡛ࠩࡘࡈࡀࠧࡄ")
    if addon == l1ll1l1_opy_:
        return l1l1l_opy_ (u"ࠪࡗࡈ࡚ࡖ࠻ࠩࡅ")
    if addon == l1ll1ll1_opy_:
        return l1l1l_opy_ (u"ࠫࡘ࡛ࡐ࠻ࠩࡆ")
    if addon == l11l1l1_opy_:
        return l1l1l_opy_ (u"࡛ࠬࡋࡕ࠼ࠪࡇ")
    if addon == l1l111l1_opy_:
        return l1l1l_opy_ (u"࠭ࡌࡊࡏࡌࡘ࠿࠭ࡈ")
    if addon == l1ll1l_opy_:
        return l1l1l_opy_ (u"ࠧࡇࡃࡅ࠾ࠬࡉ")
    if addon == l1l1l11_opy_:
        return l1l1l_opy_ (u"ࠨࡃࡆࡉ࠿࠭ࡊ")
    if addon == l11lll1_opy_:
        return l1l1l_opy_ (u"ࠩࡋࡓࡗࡏ࡚࠻ࠩࡋ")
    if addon == root:
        return l1l1l_opy_ (u"ࠪࡖࡔࡕࡔ࠳࠼ࠪࡌ")
    if addon == l1lllll_opy_:
        return l1l1l_opy_ (u"ࠫࡒࡋࡇࡂ࠼ࠪࡍ")
    if addon == l1l11111_opy_:
        return l1l1l_opy_ (u"ࠬࡌࡒࡆࡇ࠽ࠫࡎ")
    if addon == l1ll1l1l_opy_:
        return l1l1l_opy_ (u"࠭ࡍࡂࡖࡖ࠾ࠬࡏ")
    if addon == l1ll1_opy_:
        return l1l1l_opy_ (u"ࠧࡊࡒࡗࡗ࠿࠭ࡐ")
    if addon == l111l1l_opy_:
        return l1l1l_opy_ (u"ࠨࡌࡌࡒ࡝࠸࠺ࠨࡑ")
    if addon == l1ll11_opy_:
        return l1l1l_opy_ (u"ࠩࡈࡒࡉࡀࠧࡒ")
    if addon == l11llll1_opy_:
        return l1l1l_opy_ (u"ࠪࡑࡆ࡞ࡉ࠻ࠩࡓ")
    if addon == dexter:
        return l1l1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡇ࠾ࠬࡔ")
    if addon == l1l_opy_:
        return l1l1l_opy_ (u"ࠬ࡜ࡄࡓࡖ࡙࠾ࠬࡕ")
    if addon == l1llll1l_opy_:
        return l1l1l_opy_ (u"࠭ࡓࡑࡔࡐ࠾ࠬࡖ")
    if addon == l111ll1_opy_:
        return l1l1l_opy_ (u"ࠧࡎࡅࡎࡘ࡛ࡀࠧࡗ")
    if addon == l1llll11_opy_:
        return l1l1l_opy_ (u"ࠨࡖ࡚ࡍࡘ࡚࠺ࠨࡘ")
    if addon == l11lllll_opy_:
        return l1l1l_opy_ (u"ࠩࡓࡖࡊ࡙ࡔ࠻࡙ࠩ")
    if addon == l1l111ll_opy_:
        return l1l1l_opy_ (u"ࠪࡆࡑࡑࡉ࠻࡚ࠩ")
def getURL(url):
    if url.startswith(l1l1l_opy_ (u"ࠫࡆࡔࡏࡗࡃ࡛ࠪ")):
        return ll_opy_(url, l1l111_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬ࡜ࡉࡑࡕࡖࠫ࡜")):
        return ll_opy_(url, l1lll11l_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡌࡊࡏ࠵ࠫ࡝")):
        return ll_opy_(url, l11ll11l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡏࡃࡗࡌࠬ࡞")):
        return ll_opy_(url, l1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡐࡌࡇࡊ࠭࡟")):
        return ll_opy_(url, nice)
    if url.startswith(l1l1l_opy_ (u"ࠩࡓࡖࡊࡓࠧࡠ")):
        return ll_opy_(url, l11ll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡋࡎࡠࠧࡡ")):
        return ll_opy_(url, l1l1l111_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡌ࡙ࡐࡓࡖࡖࠫࡢ")):
        return ll_opy_(url, l1l11l1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡍࡅࡉࠩࡣ")):
        return ll_opy_(url, l1l1ll_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡔࡗࡍࠪࡤ")):
        return ll_opy_(url, l11l111_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡎࡖ࡛ࡍࡊ࠭ࡥ")):
        return ll_opy_(url, l11l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨ࡚ࡗࡇࠬࡦ")):
        return ll_opy_(url, l1ll11l1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡖࡇ࡙࡜ࠧࡧ")):
        return ll_opy_(url, l1ll1l1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡗ࡚ࡖࠧࡨ")):
        return ll_opy_(url, l1ll1ll1_opy_)
    if url.startswith(l1l1l_opy_ (u"࡚ࠫࡑࡔࠨࡩ")):
        return ll_opy_(url, l11l1l1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡒࡉࡎࡋࡗࠫࡪ")):
        return ll_opy_(url, l1l111l1_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡆࡂࡄࠪ࡫")):
        return ll_opy_(url, l1ll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡂࡅࡈࠫ࡬")):
        return ll_opy_(url, l1l1l11_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡊࡒࡖࡎࡠࠧ࡭")):
        return ll_opy_(url, l11lll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡕࡓࡔ࡚࠲ࠨ࡮")):
        return ll_opy_(url, root)
    if url.startswith(l1l1l_opy_ (u"ࠪࡑࡊࡍࡁࠨ࡯")):
        return ll_opy_(url, l1lllll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡋࡘࡅࡆࠩࡰ")):
        return ll_opy_(url, l1l11111_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡇࡑ࡛࠺ࠨࡱ")):
        url = url.replace(l1l1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡈࡒࡕ࠻ࠩࡲ"), l1l1l_opy_ (u"ࠧࠨࡳ")).replace(l1l1l_opy_ (u"ࠨ࠯࠰ࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧࡴ"), l1l1l_opy_ (u"ࠩࡿࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧࡵ"))
        return url
    if url.startswith(l1l1l_opy_ (u"ࠪࡑࡆ࡚ࡓࠨࡶ")):
        return ll_opy_(url, l1ll1l1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡎࡖࡔࡔࠩࡷ")):
        return ll_opy_(url, l1ll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡐࡉࡏ࡚࠵ࠫࡸ")):
        return ll_opy_(url, l111l1l_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡉ࠭ࡹ")):
        return ll_opy_(url, dexter)
    if url.startswith(l1l1l_opy_ (u"ࠧࡎࡃ࡛ࡍࠬࡺ")):
        return ll_opy_(url, l11llll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡇࡑࡈࠬࡻ")):
        return ll_opy_(url, l1ll11_opy_)
    if url.startswith(l1l1l_opy_ (u"࡙ࠩࡈࡗ࡚ࡖࠨࡼ")):
        return ll_opy_(url, l1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡗࡕࡘࡍࠨࡽ")):
        return ll_opy_(url, l1llll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡒࡉࡋࡕࡘࠪࡾ")):
        return ll_opy_(url, l111ll1_opy_)
    if url.startswith(l1l1l_opy_ (u"࡚ࠬࡗࡊࡕࡗࠫࡿ")):
        return ll_opy_(url, l1llll11_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡐࡓࡇࡖࡘࠬࢀ")):
        return ll_opy_(url, l11lllll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡃࡎࡎࡍࠬࢁ")):
        return ll_opy_(url, l1l111ll_opy_)
    response  = l11ll111_opy_(url)
    l1ll111_opy_ = url.split(l1l1l_opy_ (u"ࠨ࠼ࠪࢂ"), 1)[-1]
    l1ll111_opy_ = l1ll111_opy_.upper().replace(l1l1l_opy_ (u"ࠩࠣࠫࢃ"), l1l1l_opy_ (u"ࠪࠫࢄ"))
    try:
        result = response[l1l1l_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫࢅ")]
        l111l11_opy_  = result[l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫࢆ")]
    except Exception as e:
        l11lll1l_opy_(e)
        return None
    for file in l111l11_opy_:
        l11l11_opy_  = file[l1l1l_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬࢇ")].split(l1l1l_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࢈"), 1)[0]
        l1l1lll_opy_  = l11l11_opy_.split(l1l1l_opy_ (u"ࠨ࠭ࠪࢉ"), 1)[0]
        l1l1ll1_opy_ = mapping.cleanLabel(l1l1lll_opy_)
        l1l1ll1_opy_ = l1l1ll1_opy_.upper().replace(l1l1l_opy_ (u"ࠩࠣࠫࢊ"), l1l1l_opy_ (u"ࠪࠫࢋ"))
        try:
            if l1ll111_opy_ == l1l1ll1_opy_:
                return file[l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࠩࢌ")]
        except:
            if (l1ll111_opy_ in l1l1ll1_opy_) or (l1l1ll1_opy_ in l1ll111_opy_):
                return file[l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪࢍ")]
    return None
def ll_opy_(url, addon):
    PATH = l1ll1l11_opy_(addon)
    try:
        response = json.load(open(PATH))
    except:
        response = l1ll1lll_opy_(addon)
    l1l11l1l_opy_      = url.split(l1l1l_opy_ (u"࠭࠺ࠨࢎ"), 1)[-1]
    stream    = l1l11l1l_opy_.split(l1l1l_opy_ (u"ࠧࠡ࡝ࠪ࢏"), 1)[0]
    l1ll111_opy_ = mapping.cleanLabel(stream)
    l1ll111_opy_ = l1ll111_opy_.upper().replace(l1l1l_opy_ (u"ࠨࠢࠪ࢐"), l1l1l_opy_ (u"ࠩࠪ࢑"))
    if (addon == l1l_opy_) or (addon == l1ll1ll1_opy_):
        l111l11_opy_ = response
    else:
        l111l11_opy_ = response[l1l1l_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪ࢒")][l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪ࢓")]
    for file in l111l11_opy_:
        l11l11_opy_  = file[l1l1l_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫ࢔")].split(l1l1l_opy_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ࢕"), 1)[0]
        if addon == dexter:
            l11l11_opy_ = l11l11_opy_.split(l1l1l_opy_ (u"ࠧࠡ࠭ࠣࠫ࢖"), 1)[0]
        if (addon == l1l111_opy_) or (addon == l1lll11l_opy_) or (addon == l1llll11_opy_) or (addon == l11ll11l_opy_) or (addon == l1_opy_) or (addon == nice) or (addon == l1l1l111_opy_) or (addon == l1l11l1_opy_) or (addon == root) or (addon == l1l111l1_opy_) or (addon == l11l111_opy_) or (addon == l1l1ll_opy_):
            l11l11_opy_ = l11l11_opy_.split(l1l1l_opy_ (u"ࠨࠢ࠰ࠤࠬࢗ"), 1)[0]
        l1l1ll1_opy_ = l1111_opy_(addon, l11l11_opy_)
        l1l1ll1_opy_ = l1l1ll1_opy_.upper().replace(l1l1l_opy_ (u"ࠩࠣࠫ࢘"), l1l1l_opy_ (u"࢙ࠪࠫ"))
        try:
            if l1ll111_opy_ == l1l1ll1_opy_:
                return file[l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦ࢚ࠩ")]
        except:
            if (l1ll111_opy_ in l1l1ll1_opy_) or (l1l1ll1_opy_ in l1ll111_opy_):
                return file[l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧ࢛ࠪ")]
    return None
def l1ll1lll_opy_(addon):
    PATH = l1ll1l11_opy_(addon)
    if (addon == l1l_opy_) or (addon == l1ll1ll1_opy_):
        content = l11ll1l_opy_(addon)
        return l1l11_opy_(PATH, addon, content)
    elif addon == l1ll1l1_opy_:
        query = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡥࡷࡺ࠴ࡲࡩࡷࡧࡷࡺ࠴ࡧ࡬࡭࠱ࠪ࢜")
    elif addon == l1l11111_opy_:
        query = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡨࡵࡩࡪࡼࡩࡦࡹ࠲ࡃࡺࡸ࡬࠾ࡷࡵࡰࠫࡳ࡯ࡥࡧࡀ࠹ࠫࡴࡡ࡮ࡧࡀࡐ࡮ࡼࡥࠬࡖ࡙ࠫ࢝")
    elif addon == l11l1l1_opy_:
        query = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸ࡯ࡹࡻࡲ࡬࠱ࡂࡹࡷࡲ࠽ࡩࡶࡷࡴࠪ࠹ࡁࠦ࠴ࡉࠩ࠷ࡌࡡࡥࡦࡲࡲࡨࡲ࡯ࡶࡦ࠱ࡳࡷ࡭ࠥ࠳ࡈࡸ࡯ࡹࡻࡲ࡬ࠧ࠵ࡊ࡚ࡑࡔࡶࡴ࡮ࠩ࠷ࡌࡌࡪࡸࡨࠩ࠷࠻࠲࠱ࡖ࡙࠲ࡹࡾࡴࠧ࡯ࡲࡨࡪࡃ࠱ࠧࡰࡤࡱࡪࡃࡌࡪࡸࡨ࠯࡙࡜ࠦࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࡂࠬࡦࡢࡰࡤࡶࡹࡃࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠫ࢞")
    else:
        query = l1ll1111_opy_(addon)
    try:
        return json.load(open(PATH))
    except:
        content = doJSON(query)
        return l1l11_opy_(PATH, addon, content)
def l11ll1l_opy_(addon):
    if (addon == l1l_opy_) or (addon == l1ll1ll1_opy_):
        groups = [l1l1l_opy_ (u"ࠩ࠸࠼ࠬ࢟"), l1l1l_opy_ (u"ࠪ࠺࠻࠭ࢠ"), l1l1l_opy_ (u"ࠫ࠻࠽ࠧࢡ"), l1l1l_opy_ (u"ࠬ࠼࠹ࠨࢢ"), l1l1l_opy_ (u"࠭࠷࠵ࠩࢣ")]
    l111l11_opy_ = []
    for group in groups:
        if (addon == l1l_opy_) or (addon == l1ll1ll1_opy_):
            query = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷ࠴ࡲࡩࡷࡧࡷࡺ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ࠦࡵࠪࢤ") % (addon, group)
        content = doJSON(query, addon)
        l111l11_opy_.extend(content)
    return l111l11_opy_
def l1l11_opy_(PATH, addon, content):
    json.dump(content, open(PATH,l1l1l_opy_ (u"ࠨࡹࠪࢥ")), indent=3)
    return json.load(open(PATH))
def doJSON(query, addon=l1l1l_opy_ (u"ࠩࠪࢦ")):
    dixie.log(l1l1l_opy_ (u"ࠪࡁࡂࡃ࠽ࠡࡦࡲࡎࡘࡕࡎࠡࡳࡸࡩࡷࡿࠠ࠾࠿ࡀࡁࠬࢧ"))
    dixie.log(query)
    if (addon == l1l_opy_) or (addon == l1ll1ll1_opy_):
        l111lll_opy_     = l1l1l_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࠥࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࢨ") % query
        l111l_opy_  = xbmc.executeJSONRPC(l111lll_opy_)
        response = json.loads(l111l_opy_)
        result   = response[l1l1l_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬࢩ")]
        return result[l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬࢪ")]
    l1l1l1l_opy_  = (l1l1l_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࢫ") % query)
    response = xbmc.executeJSONRPC(l1l1l1l_opy_)
    content  = json.loads(response)
    return content
def l1ll1l11_opy_(addon):
    if addon == l1l111_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡣࡱࡳࡻࡧࡴࡦ࡯ࡳࠫࢬ"))
    if addon == l1lll11l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡹ࡭ࡵࡹࡳࡵࡧࡰࡴࠬࢭ"))
    if addon == l11ll11l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡰ࡮ࡳ࠲ࡵࡧࡰࡴࠬࢮ"))
    if addon == l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡳࡧࡴࡩࡱࡷࡩࡲࡶࠧࢯ"))
    if addon == nice:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡴࡩࡤࡧࡷࡩࡲࡶࠧࢰ"))
    if addon == l11ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡰࡳࡧࡰࡸࡪࡳࡰࠨࢱ"))
    if addon == l1l1l111_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡨ࡫ࡽࡸࡪࡳࡰࠨࢲ"))
    if addon == l1l11l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡩࡶࡴࡷࡺࡳࡵࡧࡰࡴࠬࢳ"))
    if addon == l1l1ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡪࡩࡹ࡫࡭ࡱࠩࢴ"))
    if addon == l11l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡱࡹࡾࡴࡦ࡯ࡳࠫࢵ"))
    if addon == l11l111_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡹࡼ࡫ࡵࡧࡰࡴࠬࢶ"))
    if addon == l1ll11l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡾࡴࡦ࡯ࡳࠫࢷ"))
    if addon == l1ll1l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡳࡤࡶࡨࡱࡵ࠭ࢸ"))
    if addon == l1ll1ll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡴࡷࡳࡸࡪࡳࡰࠨࢹ"))
    if addon == l11l1l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡷ࡮ࡸࡹ࡫࡭ࡱࠩࢺ"))
    if addon == l1l111l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩ࡯࡭ࡲ࡯ࡴࡦ࡯ࡳࠫࢻ"))
    if addon == l1ll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡪࡦࡨࡴࡦ࡯ࡳࠫࢼ"))
    if addon == l1l1l11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡦࡩࡥࡵࡧࡰࡴࠬࢽ"))
    if addon == l11lll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬ࡮࡯ࡳࡶࡨࡱࡵ࠭ࢾ"))
    if addon == root:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡲࡰ࠴ࡷࡩࡲࡶࠧࢿ"))
    if addon == l1lllll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧ࡮ࡧࡪࡥࡹࡳࡰࠨࣀ"))
    if addon == l1ll1l1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨ࡯ࡤࡸࡸࡺ࡭ࡱࠩࣁ"))
    if addon == l1l11111_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡩࡶࡪ࡫ࡴ࡮ࡲࠪࣂ"))
    if addon == l1ll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪ࡭ࡵࡺࡳࡵ࡯ࡳࠫࣃ"))
    if addon == l111l1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫ࡯࠸ࡴࡦ࡯ࡳࠫࣄ"))
    if addon == l1ll11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬ࡫ࡴࡦ࡯ࡳࠫࣅ"))
    if addon == l11llll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭࡭ࡢࡺࡷࡩࡲࡶࠧࣆ"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡥࡶࡨࡱࡵ࠭ࣇ"))
    if addon == l1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡸࡧࡸࡪࡳࡰࠨࣈ"))
    if addon == l1llll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡶࡴࡷࡺࡥ࡮ࡲࠪࣉ"))
    if addon == l111ll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡱࡨࡱࡴࡦ࡯ࡳࠫ࣊"))
    if addon == l1llll11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡹࡽࡩࡵࡧࡰࡴࠬ࣋"))
    if addon == l11lllll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡶࡲࡦࡵࡷࡩࡲࡶࠧ࣌"))
    if addon == l1l111ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡢ࡭࡭࡬ࡸࡪࡳࡰࠨ࣍"))
def l1ll1111_opy_(addon):
    query = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ࣎") + addon
    response = doJSON(query)
    l111l11_opy_    = response[l1l1l_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨ࣏")][l1l1l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨ࣐")]
    for file in l111l11_opy_:
        l111111_opy_ = file[l1l1l_opy_ (u"ࠪࡰࡦࡨࡥ࡭࣑ࠩ")]
        l1ll1ll_opy_ = mapping.cleanLabel(l111111_opy_)
        l1ll1ll_opy_ = l1ll1ll_opy_.upper()
        if (l1ll1ll_opy_ == l1l1l_opy_ (u"ࠫࡑࡏࡖࡆࠢࡌࡔ࡙࡜࣒ࠧ")) or (l1ll1ll_opy_ == l1l1l_opy_ (u"ࠬࡒࡉࡗࡇࠣࡘ࡛࣓࠭")) or (l1ll1ll_opy_ == l1l1l_opy_ (u"࠭ࡌࡊࡘࡈࠤࡈࡎࡁࡏࡐࡈࡐࡘ࠭ࣔ")) or (l1ll1ll_opy_ == l1l1l_opy_ (u"ࠧࡍࡋ࡙ࡉࠬࣕ")) or (l1ll1ll_opy_ == l1l1l_opy_ (u"ࠨࡇࡑࡈࡑࡋࡓࡔࠢࡐࡉࡉࡏࡁࠨࣖ")) or (l1ll1ll_opy_ == l1l1l_opy_ (u"ࠩࡉࡐࡆ࡝ࡌࡆࡕࡖࡘ࡛࠭ࣗ")) or (l1ll1ll_opy_ == l1l1l_opy_ (u"ࠪࡑࡆ࡞ࡉࡘࡇࡅࠤ࡙࡜ࠧࣘ")) or (l1ll1ll_opy_ == l1l1l_opy_ (u"ࠫࡇࡒࡁࡄࡍࡌࡇࡊࠦࡔࡗࠩࣙ")) or (l1ll1ll_opy_ == l1l1l_opy_ (u"ࠬࡎࡏࡓࡋ࡝ࡓࡓࠦࡉࡑࡖ࡙ࠫࣚ")) or (l1ll1ll_opy_ == l1l1l_opy_ (u"࠭ࡆࡂࡄࠣࡍࡕ࡚ࡖࠨࣛ"))or (l1ll1ll_opy_ == l1l1l_opy_ (u"ࠧࡗࡋࡓࠤࡘ࡛ࡐࡆࡔࡖࡘࡗࡋࡁࡎࡕࠣࡘ࡛ࠦ࠭ࠡࡎࡌ࡚ࡊࠦࡓࡕࡔࡈࡅࡒ࡙ࠧࣜ")):
            livetv = file[l1l1l_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ࣝ")]
            return l1llll1_opy_(livetv)
def l1llll1_opy_(livetv):
    response = doJSON(livetv)
    l111l11_opy_    = response[l1l1l_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩࣞ")][l1l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩࣟ")]
    for file in l111l11_opy_:
        l111111_opy_ = file[l1l1l_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪ࣠")]
        l1ll1ll_opy_ = mapping.cleanLabel(l111111_opy_)
        l1ll1ll_opy_ = l1ll1ll_opy_.upper()
        if (l1ll1ll_opy_ == l1l1l_opy_ (u"ࠬࡇࡌࡍࠩ࣡")) or (l1ll1ll_opy_ == l1l1l_opy_ (u"࠭ࡁࡍࡎࠣࡇࡍࡇࡎࡏࡇࡏࡗࠬ࣢")):
            return file[l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࣣࠬ")]
def l1ll11l_opy_(l11l1_opy_):
    items = []
    _1llllll_opy_(l11l1_opy_, items)
    return items
def _1llllll_opy_(l11l1_opy_, items):
    response = doJSON(l11l1_opy_)
    if response[l1l1l_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨࣤ")].has_key(l1l1l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨࣥ")):
        result = response[l1l1l_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࣦࠪ")][l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪࣧ")]
        for item in result:
            if item[l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧࣨ")] == l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࣩࠫ"):
                l1ll1ll_opy_ = mapping.cleanLabel(item[l1l1l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭࣪")])
                items.append(item)
            elif item[l1l1l_opy_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ࣫")] == l1l1l_opy_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠬ࣬"):
                l1ll1ll_opy_ = mapping.cleanLabel(item[l1l1l_opy_ (u"ࠪࡰࡦࡨࡥ࡭࣭ࠩ")])
                l11lll11_opy_  = item[l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦ࣮ࠩ")]
                _1llllll_opy_(l11lll11_opy_, items)
def l11ll111_opy_(url):
    if url.startswith(l1l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜࠾࣯ࠬ")):
        l1l1l1l_opy_ = (l1l1l_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡥࡦࡨ࡯ࡰ࡭ࡣࡼࡩࡷ࠵࠿ࡶࡴ࡯ࡁࡺࡸ࡬ࠧ࡯ࡲࡨࡪࡃ࠲ࠧࡰࡤࡱࡪࡃࡌࡪࡸࡨࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࡃࠦࡊࡒࡌࡈࡂࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࣰࠫ"))
    if url.startswith(l1l1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞࠸࠺ࠨࣱ")):
        l1l1l1l_opy_ = (l1l1l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶ࡬ࡢࡻࡨࡶࡼࡽࡷ࠰ࡁࡸࡶࡱࡃࡵࡳ࡮ࠩࡱࡴࡪࡥ࠾࠳࠳࠵ࠫࡴࡡ࡮ࡧࡀ࡛ࡦࡺࡣࡩ࠭ࡏ࡭ࡻ࡫ࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠩࡷࡺࡨࡴࡪࡶ࡯ࡩࡸࡥࡵࡳ࡮ࡀࠪࡱࡵࡧࡨࡧࡧࡣ࡮ࡴ࠽ࡇࡣ࡯ࡷࡪࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࣲࠫ"))
    if url.startswith(l1l1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡓ࠼ࠪࣳ")):
        l1l1l1l_opy_ = (l1l1l_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱ࡮ࡤࡽࡪࡸࡷࡸࡹ࠲ࡃࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࡊࡥࡧࡣࡸࡰࡹࡌ࡯࡭ࡦࡨࡶ࠳ࡶ࡮ࡨࠨ࡯ࡳ࡬࡭ࡥࡥࡡ࡬ࡲࡂࡌࡡ࡭ࡵࡨࠪࡲࡵࡤࡦ࠿࠴࠵࠸ࠬ࡮ࡢ࡯ࡨࡁࡑ࡯ࡳࡵࡧࡱࠩ࠷࠶ࡌࡪࡸࡨࠪࡸࡻࡢࡵ࡫ࡷࡰࡪࡹ࡟ࡶࡴ࡯ࠪࡺࡸ࡬࠾ࡷࡵࡰࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࣴ"))
    if url.startswith(l1l1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡌࡘ࡛ࡀࠧࣵ")):
        l1l1l1l_opy_ = (l1l1l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡷࡺࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࣶࠪ"))
    if url.startswith(l1l1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡉࡀࠧࣷ")):
        l1l1l1l_opy_ = (l1l1l_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡨࡪࡾ࠯ࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡣ࡯ࡰࠫ࡫ࡸࡵࡴࡤࠪࡵࡧࡧࡦࠨࡳࡰࡴࡺࠦࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡀࠪࡹ࡯ࡴ࡭ࡧࡀࠩ࠺ࡨࡃࡐࡎࡒࡖࠪ࠸࠰ࡸࡪ࡬ࡸࡪࠫ࠵ࡥࡃ࡯ࡰࠪ࠸࠰ࡄࡪࡤࡲࡳ࡫࡬ࡴࠧ࠸ࡦࠪ࠸ࡦࡄࡑࡏࡓࡗࠫ࠵ࡥࠨࡸࡶࡱࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࣸ"))
    if url.startswith(l1l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡒࡃ࠼ࣹࠪ")):
        l1l1l1l_opy_ = (l1l1l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡥࡣࡱࡲࡸ࠴ࡅࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠪ࡫ࡧ࡮ࡢࡴࡷࡁࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡰࡳࡩ࡫࠽࠸ࠨࡳ࡭ࡱࡲ࡯ࡸ࠿ࡏ࡭ࡻ࡫ࠥ࠳࠲ࡖࡸࡷ࡫ࡡ࡮ࡵࠩࡹࡷࡲ࠽ࡳࡣࡱࡨࡴࡳࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࣺࠬ"))
    try:
        dixie.ShowBusy()
        addon =  l1l1l1l_opy_.split(l1l1l_opy_ (u"ࠪ࠳࠴࠭ࣻ"), 1)[-1].split(l1l1l_opy_ (u"ࠫ࠴࠭ࣼ"), 1)[0]
        login = l1l1l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࣽ") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1l1l1l_opy_)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l11lll1l_opy_(e)
        return {l1l1l_opy_ (u"࠭ࡅࡳࡴࡲࡶࠬࣾ") : l1l1l_opy_ (u"ࠧࡑ࡮ࡸ࡫࡮ࡴࠠࡆࡴࡵࡳࡷ࠭ࣿ")}
def l1l1l1ll_opy_():
    modules = map(__import__, [l11lll_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l1l1l_opy_ (u"ࠨࡖࡵࡹࡪ࠭ऀ")
    if len(modules[-1].Window(10**4).getProperty(l11l1l_opy_)):
        return l1l1l_opy_ (u"ࠩࡗࡶࡺ࡫ࠧँ")
    return l1l1l_opy_ (u"ࠪࡊࡦࡲࡳࡦࠩं")
def l11lll1l_opy_(e):
    l1l1ll11_opy_ = l1l1l_opy_ (u"ࠫࡘࡵࡲࡳࡻ࠯ࠤࡦࡴࠠࡦࡴࡵࡳࡷࠦ࡯ࡤࡥࡸࡶࡪࡪ࠺ࠡࡌࡖࡓࡓࠦࡅࡳࡴࡲࡶ࠿ࠦࠥࡴࠩः")  %e
    l11l11l_opy_ = l1l1l_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡸࡥ࠮࡮࡬ࡲࡰࠦࡴࡩ࡫ࡶࠤࡨ࡮ࡡ࡯ࡰࡨࡰࠥࡧ࡮ࡥࠢࡷࡶࡾࠦࡡࡨࡣ࡬ࡲ࠳࠭ऄ")
    l1l1lll1_opy_ = l1l1l_opy_ (u"࠭ࡕࡴࡧ࠽ࠤࡈࡵ࡮ࡵࡧࡻࡸࠥࡓࡥ࡯ࡷࠣࡁࡃࠦࡒࡦ࡯ࡲࡺࡪࠦࡓࡵࡴࡨࡥࡲ࠭अ")
    dixie.DialogOK(l1l1ll11_opy_, l11l11l_opy_, l1l1lll1_opy_)
if __name__ == l1l1l_opy_ (u"ࠧࡠࡡࡰࡥ࡮ࡴ࡟ࡠࠩआ"):
    checkAddons()