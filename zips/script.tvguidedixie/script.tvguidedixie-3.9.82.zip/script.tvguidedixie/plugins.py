# coding: UTF-8
import sys
l1l11l1_opy_ = sys.version_info [0] == 2
l1l111l_opy_ = 2048
l1l1l1_opy_ = 7
def l1ll1ll_opy_ (ll_opy_):
	global l1ll1l_opy_
	l1lll11l_opy_ = ord (ll_opy_ [-1])
	l1l1l1l_opy_ = ll_opy_ [:-1]
	l111l11_opy_ = l1lll11l_opy_ % len (l1l1l1l_opy_)
	l1llllll_opy_ = l1l1l1l_opy_ [:l111l11_opy_] + l1l1l1l_opy_ [l111l11_opy_:]
	if l1l11l1_opy_:
		l11ll11_opy_ = unicode () .join ([unichr (ord (char) - l1l111l_opy_ - (l1llll1_opy_ + l1lll11l_opy_) % l1l1l1_opy_) for l1llll1_opy_, char in enumerate (l1llllll_opy_)])
	else:
		l11ll11_opy_ = str () .join ([chr (ord (char) - l1l111l_opy_ - (l1llll1_opy_ + l1lll11l_opy_) % l1l1l1_opy_) for l1llll1_opy_, char in enumerate (l1llllll_opy_)])
	return eval (l11ll11_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l11111l1l_opy_     = l1ll1ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡳࡺࡶࠨব")
l11111ll1_opy_  = l1ll1ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡽ࡬ࡪࡲࡷࡺࠬভ")
l111l111l_opy_     = l1ll1ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡵ࡬ࡶࡸࡶࡰ࠭ম")
locked  = l1ll1ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡭ࡱࡦ࡯ࡪࡪࡴࡷࠩয")
l1111ll1l_opy_      = l1ll1ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡷ࡯ࡸ࡮ࡳࡡࡵࡧࡰࡥࡳ࡯ࡡࠨর")
l1111ll11_opy_    = l1ll1ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡯࡭ࡺࡾ࠮ࡵࡸࠪ঱")
l1111l111_opy_     = l1ll1ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡈࡈ࡙ࡰࡰࡴࡷࡷࠬল")
l1111lll1_opy_  = l1ll1ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷ࡫ࡢࡰࡱࡷࠫ঳")
l11111lll_opy_     = l1ll1ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡩ࡬ࡶ࡫ࡳࡸࡻ࠭঴")
l111111ll_opy_ = l1ll1ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡵ࡬ࡶࡹ࠸ࡪࡾࡰࡢࡶࡶ࠲ࡨࡵ࡭ࠨ঵")
l1ll11l1_opy_ = [l11111l1l_opy_, locked, l1111ll11_opy_, l11111ll1_opy_, l111111ll_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1ll1ll_opy_ (u"ࠨ࡫ࡱ࡭ࠬশ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1lll1ll_opy_ = l1ll1ll_opy_ (u"ࠩࠪষ")
def l1ll1111_opy_(i, t1, l1lll1l1_opy_=[]):
 t = l1lll1ll_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1lll1l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11l1_opy_ = l1ll1111_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l111l_opy_ = l1ll1111_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1ll11l1_opy_:
        if l1ll1l1l_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1ll1l1l_opy_(addon):
    if xbmc.getCondVisibility(l1ll1ll_opy_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡌࡦࡹࡁࡥࡦࡲࡲ࠭ࠫࡳࠪࠩস") % addon) == 1:
        return True
    return False
def createINI(addon):
    l11l11l_opy_ = str(addon).split(l1ll1ll_opy_ (u"ࠫ࠳࠭হ"))[2] + l1ll1ll_opy_ (u"ࠬ࠴ࡩ࡯࡫ࠪ঺")
    l1l_opy_  = os.path.join(PATH, l11l11l_opy_)
    try:
        l1ll1l1_opy_ = l1_opy_(addon)
    except KeyError:
        dixie.log(l1ll1ll_opy_ (u"࠭࠭࠮࠯࠰࠱ࠥࡑࡥࡺࡇࡵࡶࡴࡸࠠࡪࡰࠣ࡫ࡪࡺࡆࡪ࡮ࡨࡷࠥ࠳࠭࠮࠯࠰ࠤࠬ঻") + addon)
        result = {l1ll1ll_opy_ (u"ࡵࠨࡨ࡬ࡰࡪࡹ়ࠧ"): [{l1ll1ll_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫঽ"): l1ll1ll_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࠨা"), l1ll1ll_opy_ (u"ࡸࠫࡹࡿࡰࡦࠩি"): l1ll1ll_opy_ (u"ࡹࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭ী"), l1ll1ll_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࠫু"): l1ll1ll_opy_ (u"ࡻࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡺࡻࡼࠬূ"), l1ll1ll_opy_ (u"ࡵࠨ࡮ࡤࡦࡪࡲࠧৃ"): l1ll1ll_opy_ (u"ࡶࠩࡑࡓࠥࡉࡈࡂࡐࡑࡉࡑ࡙ࠧৄ")}], l1ll1ll_opy_ (u"ࡷࠪࡰ࡮ࡳࡩࡵࡵࠪ৅"):{l1ll1ll_opy_ (u"ࡸࠫࡸࡺࡡࡳࡶࠪ৆"): 0, l1ll1ll_opy_ (u"ࡹࠬࡺ࡯ࡵࡣ࡯ࠫে"): 1, l1ll1ll_opy_ (u"ࡺ࠭ࡥ࡯ࡦࠪৈ"): 1}}
    l1l1lll_opy_  = l1ll1ll_opy_ (u"࡛࠭ࠨ৉") + addon + l1ll1ll_opy_ (u"ࠧ࡞࡞ࡱࠫ৊")
    l1l11_opy_  =  file(l1l_opy_, l1ll1ll_opy_ (u"ࠨࡹࠪো"))
    l1l11_opy_.write(l1l1lll_opy_)
    l1ll11ll_opy_ = []
    for channel in l1ll1l1_opy_:
        l111l1l1l_opy_ = dixie.cleanLabel(channel[l1ll1ll_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨৌ")])
        l1ll1ll1_opy_   = dixie.cleanPrefix(l111l1l1l_opy_)
        l1l1l_opy_ = dixie.mapChannelName(l1ll1ll1_opy_)
        stream   = channel[l1ll1ll_opy_ (u"ࠪࡪ࡮ࡲࡥࠨ্")]
        l1111_opy_ = l1l1l_opy_ + l1ll1ll_opy_ (u"ࠫࡂ࠭ৎ") + stream
        l1ll11ll_opy_.append(l1111_opy_)
        l1ll11ll_opy_.sort()
    for item in l1ll11ll_opy_:
        l1l11_opy_.write(l1ll1ll_opy_ (u"ࠧࠫࡳ࡝ࡰࠥ৏") % item)
    l1l11_opy_.close()
def l1_opy_(addon):
    if (addon == l11111l1l_opy_) or (addon == l11111ll1_opy_):
        if xbmcaddon.Addon(addon).getSetting(l1ll1ll_opy_ (u"࠭ࡧࡦࡰࡵࡩࠬ৐")) == l1ll1ll_opy_ (u"ࠧࡵࡴࡸࡩࠬ৑"):
            xbmcaddon.Addon(addon).setSetting(l1ll1ll_opy_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ৒"), l1ll1ll_opy_ (u"ࠩࡩࡥࡱࡹࡥࠨ৓"))
            xbmcgui.Window(10000).setProperty(l1ll1ll_opy_ (u"ࠪࡔࡑ࡛ࡇࡊࡐࡢࡋࡊࡔࡒࡆࠩ৔"), l1ll1ll_opy_ (u"࡙ࠫࡸࡵࡦࠩ৕"))
        if xbmcaddon.Addon(addon).getSetting(l1ll1ll_opy_ (u"ࠬࡺࡶࡨࡷ࡬ࡨࡪ࠭৖")) == l1ll1ll_opy_ (u"࠭ࡴࡳࡷࡨࠫৗ"):
            xbmcaddon.Addon(addon).setSetting(l1ll1ll_opy_ (u"ࠧࡵࡸࡪࡹ࡮ࡪࡥࠨ৘"), l1ll1ll_opy_ (u"ࠨࡨࡤࡰࡸ࡫ࠧ৙"))
            xbmcgui.Window(10000).setProperty(l1ll1ll_opy_ (u"ࠩࡓࡐ࡚ࡍࡉࡏࡡࡗ࡚ࡌ࡛ࡉࡅࡇࠪ৚"), l1ll1ll_opy_ (u"ࠪࡘࡷࡻࡥࠨ৛"))
        l1l111111_opy_  = l1ll1ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧড়") + addon
        l1111l1l1_opy_ =  l111l11l1_opy_(addon)
        query   =  l1l111111_opy_ + l1111l1l1_opy_
        return sendJSON(query, addon)
    return l11ll11ll_opy_(addon)
def l11ll11ll_opy_(addon):
    if addon == l111111ll_opy_:
        l11ll1l1l_opy_ = [l1ll1ll_opy_ (u"ࠬ࠷࠶࠲ࠩঢ়"), l1ll1ll_opy_ (u"࠭࠱࠷࠲ࠪ৞"), l1ll1ll_opy_ (u"ࠧ࠳࠵࠹ࠫয়"), l1ll1ll_opy_ (u"ࠨ࠴࠷࠶ࠬৠ"), l1ll1ll_opy_ (u"ࠩ࠴࠹࠽࠭ৡ"), l1ll1ll_opy_ (u"ࠪ࠵࠺࠿ࠧৢ")]
    if addon == l1111ll11_opy_:
        l11ll1l1l_opy_ = [l1ll1ll_opy_ (u"ࠫ࠺࠭ৣ"), l1ll1ll_opy_ (u"ࠬ࠷࠰࠷ࠩ৤"), l1ll1ll_opy_ (u"࠭࠴ࠨ৥"), l1ll1ll_opy_ (u"ࠧ࠳࠸࠶ࠫ০"), l1ll1ll_opy_ (u"ࠨ࠳࠶࠶ࠬ১")]
    if addon == locked:
        l11ll1l1l_opy_ = [l1ll1ll_opy_ (u"ࠩ࠶࠴ࠬ২"), l1ll1ll_opy_ (u"ࠪ࠷࠶࠭৩"), l1ll1ll_opy_ (u"ࠫ࠸࠸ࠧ৪"), l1ll1ll_opy_ (u"ࠬ࠹࠳ࠨ৫"), l1ll1ll_opy_ (u"࠭࠳࠵ࠩ৬"), l1ll1ll_opy_ (u"ࠧ࠴࠷ࠪ৭"), l1ll1ll_opy_ (u"ࠨ࠵࠻ࠫ৮"), l1ll1ll_opy_ (u"ࠩ࠷࠴ࠬ৯"), l1ll1ll_opy_ (u"ࠪ࠸࠶࠭ৰ"), l1ll1ll_opy_ (u"ࠫ࠹࠻ࠧৱ"), l1ll1ll_opy_ (u"ࠬ࠺࠷ࠨ৲"), l1ll1ll_opy_ (u"࠭࠴࠺ࠩ৳"), l1ll1ll_opy_ (u"ࠧ࠶࠴ࠪ৴")]
    if addon == l1111ll1l_opy_:
        l11ll1l1l_opy_ = [l1ll1ll_opy_ (u"ࠨ࠴࠸ࠫ৵"), l1ll1ll_opy_ (u"ࠩ࠵࠺ࠬ৶"), l1ll1ll_opy_ (u"ࠪ࠶࠼࠭৷"), l1ll1ll_opy_ (u"ࠫ࠷࠿ࠧ৸"), l1ll1ll_opy_ (u"ࠬ࠹࠰ࠨ৹"), l1ll1ll_opy_ (u"࠭࠳࠲ࠩ৺"), l1ll1ll_opy_ (u"ࠧ࠴࠴ࠪ৻"), l1ll1ll_opy_ (u"ࠨ࠵࠸ࠫৼ"), l1ll1ll_opy_ (u"ࠩ࠶࠺ࠬ৽"), l1ll1ll_opy_ (u"ࠪ࠷࠼࠭৾"), l1ll1ll_opy_ (u"ࠫ࠸࠾ࠧ৿"), l1ll1ll_opy_ (u"ࠬ࠹࠹ࠨ਀"), l1ll1ll_opy_ (u"࠭࠴࠱ࠩਁ"), l1ll1ll_opy_ (u"ࠧ࠵࠳ࠪਂ"), l1ll1ll_opy_ (u"ࠨ࠶࠻ࠫਃ"), l1ll1ll_opy_ (u"ࠩ࠷࠽ࠬ਄"), l1ll1ll_opy_ (u"ࠪ࠹࠵࠭ਅ"), l1ll1ll_opy_ (u"ࠫ࠺࠸ࠧਆ"), l1ll1ll_opy_ (u"ࠬ࠻࠴ࠨਇ"), l1ll1ll_opy_ (u"࠭࠵࠷ࠩਈ"), l1ll1ll_opy_ (u"ࠧ࠶࠹ࠪਉ"), l1ll1ll_opy_ (u"ࠨ࠷࠻ࠫਊ"), l1ll1ll_opy_ (u"ࠩ࠸࠽ࠬ਋"), l1ll1ll_opy_ (u"ࠪ࠺࠵࠭਌"), l1ll1ll_opy_ (u"ࠫ࠻࠷ࠧ਍"), l1ll1ll_opy_ (u"ࠬ࠼࠲ࠨ਎"), l1ll1ll_opy_ (u"࠭࠶࠴ࠩਏ"), l1ll1ll_opy_ (u"ࠧ࠷࠷ࠪਐ"), l1ll1ll_opy_ (u"ࠨ࠸࠹ࠫ਑"), l1ll1ll_opy_ (u"ࠩ࠹࠻ࠬ਒"), l1ll1ll_opy_ (u"ࠪ࠺࠾࠭ਓ"), l1ll1ll_opy_ (u"ࠫ࠼࠶ࠧਔ"), l1ll1ll_opy_ (u"ࠬ࠽࠴ࠨਕ"), l1ll1ll_opy_ (u"࠭࠷࠸ࠩਖ"), l1ll1ll_opy_ (u"ࠧ࠸࠺ࠪਗ"), l1ll1ll_opy_ (u"ࠨ࠺࠳ࠫਘ"), l1ll1ll_opy_ (u"ࠩ࠻࠵ࠬਙ")]
    login = l1ll1ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳ࠰ࠩਚ") % addon
    sendJSON(login, addon)
    l1l1ll_opy_ = []
    for l11llll1l_opy_ in l11ll1l1l_opy_:
        if (addon == l111111ll_opy_) or (addon == l1111ll11_opy_):
            query = l1ll1ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴ࠱ࡂࡱࡴࡪࡥࡠ࡫ࡧࡁࡨ࡮ࡡ࡯ࡰࡨࡰࡸࠬ࡭ࡰࡦࡨࡁࡨ࡮ࡡ࡯ࡰࡨࡰࡸࠬࡳࡦࡥࡷ࡭ࡴࡴ࡟ࡪࡦࡀࠩࡸ࠭ਛ") % (addon, l11llll1l_opy_)
        if (addon == locked) or (addon == l1111ll1l_opy_):
            query = l1ll1ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠦࡵ࠲ࡃࡺࡸ࡬࠾ࠧࡶࠪࡲࡵࡤࡦ࠿࠷ࠪࡳࡧ࡭ࡦ࠿ࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦࡱ࡮ࡤࡽࡂࠬࡤࡢࡶࡨࡁࠫࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࡀࠪࡵࡧࡧࡦ࠿ࠪਜ") % (addon, l11llll1l_opy_)
        response = sendJSON(query, addon)
        l1l1ll_opy_.extend(response)
    return l1l1ll_opy_
def sendJSON(query, addon):
    l11lll11l_opy_     = l1ll1ll_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࠧࡶࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩਝ") % query
    l11lllll1_opy_  = xbmc.executeJSONRPC(l11lll11l_opy_)
    response = json.loads(l11lllll1_opy_)
    result   = response[l1ll1ll_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧਞ")]
    if xbmcgui.Window(10000).getProperty(l1ll1ll_opy_ (u"ࠨࡒࡏ࡙ࡌࡏࡎࡠࡉࡈࡒࡗࡋࠧਟ")) == l1ll1ll_opy_ (u"ࠩࡗࡶࡺ࡫ࠧਠ"):
        xbmcaddon.Addon(addon).setSetting(l1ll1ll_opy_ (u"ࠪ࡫ࡪࡴࡲࡦࠩਡ"), l1ll1ll_opy_ (u"ࠫࡹࡸࡵࡦࠩਢ"))
    if xbmcgui.Window(10000).getProperty(l1ll1ll_opy_ (u"ࠬࡖࡌࡖࡉࡌࡒࡤ࡚ࡖࡈࡗࡌࡈࡊ࠭ਣ")) == l1ll1ll_opy_ (u"࠭ࡔࡳࡷࡨࠫਤ"):
        xbmcaddon.Addon(addon).setSetting(l1ll1ll_opy_ (u"ࠧࡵࡸࡪࡹ࡮ࡪࡥࠨਥ"), l1ll1ll_opy_ (u"ࠨࡶࡵࡹࡪ࠭ਦ"))
    return result[l1ll1ll_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨਧ")]
def l111l11l1_opy_(addon):
    if (addon == l11111l1l_opy_) or (addon == l11111ll1_opy_):
        return l1ll1ll_opy_ (u"ࠪ࠳ࡄࡩࡡࡵ࠿࠰࠶ࠫࡪࡡࡵࡧࠩࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠧࡧࡱࡨࡉࡧࡴࡦࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࠬ࡭ࡰࡦࡨࡁ࠷ࠬ࡮ࡢ࡯ࡨࡁࡒࡿࠥ࠳࠲ࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪࡷ࡫ࡣࡰࡴࡧࡲࡦࡳࡥࠧࡵࡷࡥࡷࡺࡄࡢࡶࡨࠪࡺࡸ࡬࠾ࡷࡵࡰࠬਨ")
    return l1ll1ll_opy_ (u"ࠫࠬ਩")
def l1lll1_opy_():
    modules = map(__import__, [l1ll1111_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11l1_opy_)):
        return l1ll1ll_opy_ (u"࡚ࠬࡲࡶࡧࠪਪ")
    if len(modules[-1].Window(10**4).getProperty(l111l_opy_)):
        return l1ll1ll_opy_ (u"࠭ࡔࡳࡷࡨࠫਫ")
    return l1ll1ll_opy_ (u"ࠧࡇࡣ࡯ࡷࡪ࠭ਬ")
def l11111l_opy_(e, addon):
    l11111_opy_ = l1ll1ll_opy_ (u"ࠨࡕࡲࡶࡷࡿࠬࠡࡣࡱࠤࡪࡸࡲࡰࡴࠣࡳࡨࡩࡵࡳࡧࡧ࠾ࠥࡐࡓࡐࡐࠣࡉࡷࡸ࡯ࡳ࠼ࠣࠩࡸ࠲ࠠࠦࡵࠪਭ")  % (e, addon)
    l1llll_opy_ = l1ll1ll_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡹࡸࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡦࡰࡴࡸࡱ࠳࠭ਮ")
    l1l1_opy_ = l1ll1ll_opy_ (u"࡙ࠪࡵࡲ࡯ࡢࡦࠣࡥࠥࡲ࡯ࡨࠢࡹ࡭ࡦࠦࡴࡩࡧࠣࡥࡩࡪ࡯࡯ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠤࡦࡴࡤࠡࡲࡲࡷࡹࠦࡴࡩࡧࠣࡰ࡮ࡴ࡫࠯ࠩਯ")
    dixie.log(addon)
    dixie.log(e)
def getPluginInfo(streamurl):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l1111l1ll_opy_   = l1ll1ll_opy_ (u"ࠫࡐࡵࡤࡪࠢࡓ࡚ࡗ࠭ਰ")
            l111l1111_opy_ = os.path.join(dixie.RESOURCES, l1ll1ll_opy_ (u"ࠬࡱ࡯ࡥ࡫࠰ࡴࡻࡸ࠮ࡱࡰࡪࠫ਱"))
            return l1111l1ll_opy_, l111l1111_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l1ll1ll_opy_ (u"࠭ࡲࡵ࡯ࡳࠫਲ")) or url.startswith(l1ll1ll_opy_ (u"ࠧࡳࡶࡰࡴࡪ࠭ਲ਼")) or url.startswith(l1ll1ll_opy_ (u"ࠨࡴࡷࡷࡵ࠭਴")) or url.startswith(l1ll1ll_opy_ (u"ࠩ࡫ࡸࡹࡶࠧਵ")):
            l1111l1ll_opy_   = l1ll1ll_opy_ (u"ࠪࡱ࠸ࡻࠠࡑ࡮ࡤࡽࡱ࡯ࡳࡵࠩਸ਼")
            l111l1111_opy_ = os.path.join(dixie.RESOURCES, l1ll1ll_opy_ (u"ࠫ࡮ࡶࡴࡷ࠯ࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡵࡴࡧࠨ਷"))
            return l1111l1ll_opy_, l111l1111_opy_
    except:
        pass
    if streamurl.startswith(l1ll1ll_opy_ (u"ࠬࡶࡶࡳ࠼࠲࠳ࠬਸ")):
        l1111l1ll_opy_   = l1ll1ll_opy_ (u"࠭ࡋࡰࡦ࡬ࠤࡕ࡜ࡒࠨਹ")
        l111l1111_opy_ = os.path.join(dixie.RESOURCES, l1ll1ll_opy_ (u"ࠧ࡬ࡱࡧ࡭࠲ࡶࡶࡳ࠰ࡳࡲ࡬࠭਺"))
        return l1111l1ll_opy_, l111l1111_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        l1111llll_opy_ = streamurl.split(l1ll1ll_opy_ (u"ࠨ࡟ࡒࡘ࡙ࡥࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ਻"), 1)[-1].split(l1ll1ll_opy_ (u"ࠩ࠲਼ࠫ"), 1)[0]
    if l1ll1ll_opy_ (u"ࠪࡡࡔ࡚ࡔࡠࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫ਽") in streamurl:
        l1111llll_opy_ = streamurl.split(l1ll1ll_opy_ (u"ࠫࡢࡕࡔࡕࡡࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬਾ"), 1)[-1].split(l1ll1ll_opy_ (u"ࠬ࠵ࠧਿ"), 1)[0]
    if streamurl.startswith(l1ll1ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩੀ")):
        l1111llll_opy_ = streamurl.split(l1ll1ll_opy_ (u"ࠧ࠰࠱ࠪੁ"), 1)[-1].split(l1ll1ll_opy_ (u"ࠨ࠱ࠪੂ"), 1)[0]
    if l1ll1ll_opy_ (u"ࠩࡢࡣࡘࡌ࡟ࡠࠩ੃") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡴࡷࡵࡧࡳࡣࡰ࠲ࡸࡻࡰࡦࡴ࠱ࡪࡦࡼ࡯ࡶࡴ࡬ࡸࡪࡹࠧ੄")
    if l1ll1ll_opy_ (u"࡛ࠫࡊࡒࡕࡘ࠽ࠫ੅") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡛ࡇࡄࡆࡔࠪ੆")
    if l1ll1ll_opy_ (u"࠭ࡈࡅࡖ࡙࠾ࠬੇ") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳ࡮ࡣࡵࡸ࡭ࡻࡢࠨੈ")
    if l1ll1ll_opy_ (u"ࠨࡊࡇࡘ࡛࠸࠺ࠨ੉") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࠸ࠧ੊")
    if l1ll1ll_opy_ (u"ࠪࡌࡉ࡚ࡖ࠴࠼ࠪੋ") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡺࡿࡡ࠳ࠩੌ")
    if l1ll1ll_opy_ (u"ࠬࡎࡄࡕࡘ࠷࠾੍ࠬ") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾ࡬ࠨ੎")
    if l1ll1ll_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡀࠧ੏") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡣࡤࡦ࡭ࡵࡲࡡࡺࡧࡵࠫ੐")
    if l1ll1ll_opy_ (u"ࠩࡌࡔࡑࡇ࡙࠳࠼ࠪੑ") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠭੒")
    if l1ll1ll_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡕ࠾ࠬ੓") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶ࡬ࡢࡻࡨࡶࡼࡽࡷࠨ੔")
    if l1ll1ll_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡎ࡚ࡖ࠻ࠩ੕") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡵࡸࠪ੖")
    if l1ll1ll_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡄ࠻ࠩ੗") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡦࡨࡼࠬ੘")
    if l1ll1ll_opy_ (u"ࠪࡎࡎࡔࡘ࠳࠼ࠪਖ਼") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡮࡮ࡴࡸࡵࡸ࠵ࠫਗ਼")
    if l1ll1ll_opy_ (u"ࠬࡓࡁࡕࡕ࠽ࠫਜ਼") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡓࡡࡵࡵࡅࡹ࡮ࡲࡤࡴࡋࡓࡘ࡛࠭ੜ")
    if l1ll1ll_opy_ (u"ࠧࡓࡑࡒࡘ࠿࠭੝") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡱࡲࡸ࡮ࡶࡴࡷࠩਫ਼")
    if l1ll1ll_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡓࡄ࠽ࠫ੟") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡩࡧࡵ࡯ࡵࠩ੠")
    if l1ll1ll_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡆࡐ࡚ࡀࠧ੡") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡨࡲࡵࡪࡲࡷࡺࠬ੢")
    if l1ll1ll_opy_ (u"࠭ࡉࡑࡖࡖࠫ੣") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱࡶࡹࡷࡺࡨࡳࠨ੤")
    if l1ll1ll_opy_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠻ࠩ੥") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮࡬ࡺࡪࡳࡩࡹࠩ੦")
    if l1ll1ll_opy_ (u"ࠪࡉࡓࡊ࠺ࠨ੧") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡉࡳࡪ࡬ࡦࡵࡶࠫ੨")
    if l1ll1ll_opy_ (u"ࠬࡌࡌࡂ࠼ࠪ੩") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡌ࡬ࡢࡹ࡯ࡩࡸࡹࡔࡷࠩ੪")
    if l1ll1ll_opy_ (u"ࠧࡇࡎࡄࡗ࠿࠭੫") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡇ࡮ࡤࡻࡱ࡫ࡳࡴࡖࡹࠫ੬")
    if l1ll1ll_opy_ (u"ࠩࡖࡔࡗࡓ࠺ࠨ੭") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡖࡹࡵࡸࡥ࡮ࡣࡦࡽ࡙࡜ࠧ੮")
    if l1ll1ll_opy_ (u"ࠫࡒࡉࡋࡕࡘ࠽ࠫ੯") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡲࡩ࡫ࡵࡸ࠰ࡴࡱࡻࡳࠨੰ")
    if l1ll1ll_opy_ (u"࠭ࡔࡘࡋࡖࡘ࠿࠭ੱ") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡴࡸ࡫ࡶࡸࡪࡪࠧੲ")
    if l1ll1ll_opy_ (u"ࠨࡒࡕࡉࡘ࡚࠺ࠨੳ") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡲࡶࡥࡩࡪ࡯࡯ࠩੴ")
    if l1ll1ll_opy_ (u"ࠪࡆࡑࡑࡉ࠻ࠩੵ") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡆࡱࡧࡣ࡬ࡋࡦࡩ࡙࡜ࠧ੶")
    if l1ll1ll_opy_ (u"ࠬࡌࡒࡆࡇ࠽ࠫ੷") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡬ࡲࡦࡧࡹ࡭ࡪࡽࠧ੸")
    if l1ll1ll_opy_ (u"ࠧࡶࡲࡱࡴ࠿࠭੹") in streamurl:
        l1111llll_opy_ = l1ll1ll_opy_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯ࡪࡧ࡬ࡴࡳࡥࡳࡷࡱ࠲ࡻ࡯ࡥࡸࠩ੺")
    return l11111l11_opy_(l1111llll_opy_)
def l11111l11_opy_(l1111llll_opy_):
    l1111l1ll_opy_   = l1ll1ll_opy_ (u"ࠩࠪ੻")
    l111l1111_opy_ = l1ll1ll_opy_ (u"ࠪࠫ੼")
    try:
        l111l1l11_opy_ = xbmcaddon.Addon(l1111llll_opy_).getAddonInfo(l1ll1ll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩ੽"))
        l1111l1ll_opy_    = dixie.cleanLabel(l111l1l11_opy_)
        l111l1111_opy_  = xbmcaddon.Addon(l1111llll_opy_).getAddonInfo(l1ll1ll_opy_ (u"ࠬ࡯ࡣࡰࡰࠪ੾"))
        return l1111l1ll_opy_, l111l1111_opy_
    except:
        l1111l1ll_opy_   = l1ll1ll_opy_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡔࡱࡸࡶࡨ࡫ࠧ੿")
        l111l1111_opy_ =  dixie.ICON
        return l1111l1ll_opy_, l111l1111_opy_
    return l1111l1ll_opy_, l111l1111_opy_
def selectStream(url, channel):
    l1111l11l_opy_ = url.split(l1ll1ll_opy_ (u"ࠧࡽࠩ઀"))
    if len(l1111l11l_opy_) == 0:
        return None
    options, l1ll1l11_opy_ = getOptions(l1111l11l_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l1111l11l_opy_) == 1:
            return l1ll1l11_opy_[0]
    import selectDialog
    l111l11ll_opy_ = selectDialog.select(l1ll1ll_opy_ (u"ࠨࡕࡨࡰࡪࡩࡴࠡࡣࠣࡷࡹࡸࡥࡢ࡯ࠪઁ"), options)
    if l111l11ll_opy_ < 0:
        raise Exception(l1ll1ll_opy_ (u"ࠩࡖࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡉࡡ࡯ࡥࡨࡰࠬં"))
    return l1ll1l11_opy_[l111l11ll_opy_]
def getOptions(l1111l11l_opy_, channel, addmore=True):
    options = []
    l1ll1l11_opy_    = []
    for index, stream in enumerate(l1111l11l_opy_):
        l1111l1ll_opy_ = getPluginInfo(stream)
        l1lllll_opy_ = l1111l1ll_opy_[0]
        l111111l1_opy_  = l1111l1ll_opy_[1]
        l1lllll_opy_ = l1ll1ll_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡳࡷࡧ࡮ࡨࡧࡠ࡟ࠬઃ") + l1lllll_opy_ + l1ll1ll_opy_ (u"ࠫࡢࡡ࠯ࡄࡑࡏࡓࡗࡣࠠࠨ઄")
        if stream.startswith(OPEN_OTT):
            l11l111l1_opy_ = stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l1ll1ll_opy_ (u"ࠬ࠭અ"))
            l1lllll_opy_  = l1lllll_opy_ + l11l111l1_opy_
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l1ll1ll_opy_ (u"࠭ࠧઆ"))
        else:
            l1lllll_opy_  = l1lllll_opy_ + channel
        options.append([l1lllll_opy_, index, l111111l1_opy_])
        l1ll1l11_opy_.append(stream)
    if addmore:
        options.append([l1ll1ll_opy_ (u"ࠧࡂࡦࡧࠤࡲࡵࡲࡦ࠰࠱࠲ࠬઇ"), index + 1, dixie.ICON])
        l1ll1l11_opy_.append(l1ll1ll_opy_ (u"ࠨࡣࡧࡨࡒࡵࡲࡦࠩઈ"))
    return options, l1ll1l11_opy_
if __name__ == l1ll1ll_opy_ (u"ࠩࡢࡣࡲࡧࡩ࡯ࡡࡢࠫઉ"):
    checkAddons()