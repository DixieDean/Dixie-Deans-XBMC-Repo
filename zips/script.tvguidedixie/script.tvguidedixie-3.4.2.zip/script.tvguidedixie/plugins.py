# coding: UTF-8
import sys
l1lll1ll_opy_ = sys.version_info [0] == 2
l1ll111_opy_ = 2048
l1ll1l_opy_ = 7
def l1111l_opy_ (ll_opy_):
	global l111_opy_
	l11111l_opy_ = ord (ll_opy_ [-1])
	l1llll1l_opy_ = ll_opy_ [:-1]
	l1ll1_opy_ = l11111l_opy_ % len (l1llll1l_opy_)
	l11l111_opy_ = l1llll1l_opy_ [:l1ll1_opy_] + l1llll1l_opy_ [l1ll1_opy_:]
	if l1lll1ll_opy_:
		l1l1l1l_opy_ = unicode () .join ([unichr (ord (char) - l1ll111_opy_ - (l11l1l_opy_ + l11111l_opy_) % l1ll1l_opy_) for l11l1l_opy_, char in enumerate (l11l111_opy_)])
	else:
		l1l1l1l_opy_ = str () .join ([chr (ord (char) - l1ll111_opy_ - (l11l1l_opy_ + l11111l_opy_) % l1ll1l_opy_) for l11l1l_opy_, char in enumerate (l11l111_opy_)])
	return eval (l1l1l1l_opy_)
import xbmc
import xbmcaddon
import json
import os
import shutil
import dixie
l11ll111l_opy_     = l1111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡮ࡵࡸࠪऍ")
l11ll1lll_opy_     = l1111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡶ࡭ࡷࡹࡷࡱࠧऎ")
l11l1l11l_opy_ = [l11ll111l_opy_, l11ll1lll_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1111l_opy_ (u"ࠩ࡬ࡲ࡮࠭ए"))
def checkAddons():
    for l11l11l_opy_ in l11l1l11l_opy_:
        if l11l1l1l1_opy_(l11l11l_opy_):
            try: l11ll1l11_opy_(l11l11l_opy_)
            except: pass
def l11l1l1l1_opy_(l11l11l_opy_):
    if xbmc.getCondVisibility(l1111l_opy_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡌࡦࡹࡁࡥࡦࡲࡲ࠭ࠫࡳࠪࠩऐ") % l11l11l_opy_) == 1:
        return True
    return False
def l11ll1l11_opy_(l11l11l_opy_):
    l11lll1l1_opy_ = l11ll1l1l_opy_(l11l11l_opy_) + l1111l_opy_ (u"ࠫ࠳࡯࡮ࡪࠩऑ")
    l11ll11ll_opy_  = os.path.join(PATH, l11lll1l1_opy_)
    l1lll111_opy_ = l11lllll1_opy_(l11l11l_opy_)
    l11llll11_opy_  = file(l11ll11ll_opy_, l1111l_opy_ (u"ࠬࡽࠧऒ"))
    l11llll11_opy_.write(l1111l_opy_ (u"࡛࠭ࠨओ"))
    l11llll11_opy_.write(l11l11l_opy_)
    l11llll11_opy_.write(l1111l_opy_ (u"ࠧ࡞ࠩऔ"))
    l11llll11_opy_.write(l1111l_opy_ (u"ࠨ࡞ࡱࠫक"))
    for l1llll1_opy_ in l1lll111_opy_:
        l1l1lll1_opy_   = l1llll1_opy_[l1111l_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨख")]
        l1l1lll1_opy_ = l1l1lll1_opy_.replace(l1111l_opy_ (u"ࠪࠤࡠ࠭ग"), l1111l_opy_ (u"ࠫࡠ࠭घ")).replace(l1111l_opy_ (u"ࠬࡣࠠࠨङ"), l1111l_opy_ (u"࠭࡝ࠨच")).replace(l1111l_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡢࡳࡸࡥࡢ࠭छ"), l1111l_opy_ (u"ࠨࠩज")).replace(l1111l_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢ࡯࡭ࡲ࡫ࡧࡳࡧࡨࡲࡢ࠭झ"), l1111l_opy_ (u"ࠪࠫञ")).replace(l1111l_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡾ࡫࡬࡭ࡱࡺࡡࠬट"), l1111l_opy_ (u"ࠬ࠭ठ")).replace(l1111l_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࠬड"), l1111l_opy_ (u"ࠧࠨढ")).replace(l1111l_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡱࡵࡥࡳ࡭ࡥ࡞ࠩण"), l1111l_opy_ (u"ࠩࠪत")).replace(l1111l_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࠨथ"), l1111l_opy_ (u"ࠫࠬद")).replace(l1111l_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡽࡨࡪࡶࡨࡡࠬध"), l1111l_opy_ (u"࠭ࠧन")).replace(l1111l_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩऩ"), l1111l_opy_ (u"ࠨࠩप"))
        stream  = l1llll1_opy_[l1111l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧफ")]
        l11llll11_opy_.write(l1111l_opy_ (u"ࠪࠩࡸ࠭ब") % l1l1lll1_opy_)
        l11llll11_opy_.write(l1111l_opy_ (u"ࠫࡂ࠭भ"))
        l11llll11_opy_.write(l1111l_opy_ (u"ࠬࠫࡳࠨम") % stream)
        l11llll11_opy_.write(l1111l_opy_ (u"࠭࡜࡯ࠩय"))
    l11llll11_opy_.write(l1111l_opy_ (u"ࠧ࡝ࡰࠪर"))
    l11llll11_opy_.close()
def l11ll1l1l_opy_(l11l11l_opy_):
    if l11l11l_opy_ == l11ll111l_opy_:
        return l1111l_opy_ (u"ࠨࡰࡷࡺࠬऱ")
    if l11l11l_opy_ == l11ll1lll_opy_:
        return l1111l_opy_ (u"ࠩࡸ࡯ࡹ࠭ल")
def l11lllll1_opy_(l11l11l_opy_):
    if l11l11l_opy_ == l11ll1lll_opy_:
        return l11ll1111_opy_(l11l11l_opy_)
    if l11l11l_opy_ == l11ll111l_opy_:
        xbmcaddon.Addon(l11ll111l_opy_).setSetting(l1111l_opy_ (u"ࠪ࡫ࡪࡴࡲࡦࠩळ"), l1111l_opy_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪऴ"))
        xbmcaddon.Addon(l11ll111l_opy_).setSetting(l1111l_opy_ (u"ࠬࡺࡶࡨࡷ࡬ࡨࡪ࠭व"), l1111l_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬश"))
    l11l1lll1_opy_  = l1111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪष") + l11l11l_opy_
    l11ll1ll1_opy_ =  l11llll1l_opy_(l11l11l_opy_)
    query   =  l11l1lll1_opy_ + l11ll1ll1_opy_
    return sendJSON(query, l11l11l_opy_)
def getPluginInfo(l11l1llll_opy_):
    if l11l1llll_opy_.isdigit():
        l11l1l1ll_opy_   = l1111l_opy_ (u"ࠨࡍࡲࡨ࡮ࠦࡐࡗࡔࠣࡇ࡭ࡧ࡮࡯ࡧ࡯ࠫस")
        l11l1ll11_opy_ = os.path.join(dixie.RESOURCES, l1111l_opy_ (u"ࠩ࡮ࡳࡩ࡯࠭ࡱࡸࡵ࠲ࡵࡴࡧࠨह"))
        return l11l1l1ll_opy_, l11l1ll11_opy_
    if l11l1llll_opy_.startswith(l1111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭ऺ")):
        name = l11l1llll_opy_.split(l1111l_opy_ (u"ࠫ࠴࠵ࠧऻ"), 1)[-1].rsplit(l1111l_opy_ (u"ࠬ࠵़ࠧ"), 1)[0]
    if l11l1llll_opy_.startswith(l1111l_opy_ (u"࠭ࡈࡅࡖ࡙࠾ࠬऽ")):
        name = l1111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡨࡥࡶࡹࠫा")
    if l11l1llll_opy_.startswith(l1111l_opy_ (u"ࠨࡊࡇࡘ࡛࠸࠺ࠨि")):
        name = l1111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࡯ࡰࡵࡸࠪी")
    if l11l1llll_opy_.startswith(l1111l_opy_ (u"ࠪࡌࡉ࡚ࡖ࠴࠼ࠪु")):
        name = l1111l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡱ࠭ू")
    if l11l1llll_opy_.startswith(l1111l_opy_ (u"ࠬࡏࡐࡍࡃ࡜࠾ࠬृ")):
        name = l1111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡨࡢࡤ࡫ࡳࡰࡦࡿࡥࡳࠩॄ")
    if l11l1llll_opy_.startswith(l1111l_opy_ (u"ࠧࡊࡒࡏࡅ࡞࠸࠺ࠨॅ")):
        name = l1111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺࠫॆ")
    if l11l1llll_opy_.startswith(l1111l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡊࡖ࡙࠾ࠬे")):
        name = l1111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡸࡻ࠭ै")
    if l11l1llll_opy_.startswith(l1111l_opy_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠾ࠬॉ")):
        name = l1111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡱ࡯ࡶࡦ࡯࡬ࡼࠬॊ")
    if l11l1llll_opy_.startswith(l1111l_opy_ (u"࠭ࡵࡱࡰࡳ࠾ࠬो")):
        name = l1111l_opy_ (u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮ࡩࡦ࡫ࡳࡲ࡫ࡲࡶࡰ࠱ࡺ࡮࡫ࡷࠨौ")
    try:
        l11l1l1ll_opy_   = xbmcaddon.Addon(name).getAddonInfo(l1111l_opy_ (u"ࠨࡰࡤࡱࡪ्࠭"))
        l11l1ll11_opy_ = xbmcaddon.Addon(name).getAddonInfo(l1111l_opy_ (u"ࠩ࡬ࡧࡴࡴࠧॎ"))
        l11l1llll_opy_  = l1111l_opy_ (u"ࠥࡳࡸ࠴ࡲࡦ࡯ࡲࡺࡪ࠮࡯ࡴ࠰ࡳࡥࡹ࡮࠮࡫ࡱ࡬ࡲ࠭ࡾࡢ࡮ࡥ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪࡖࡡࡵࡪࠫࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡱࡴࡲࡪ࡮ࡲࡥ࠰ࠩࠬ࠰ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢ࠱ࡶࡧࡷ࡯ࡰࡵ࠰ࡷࡺࡵࡵࡲࡵࡣ࡯࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠳ࡪࡢࠨࠫࠬࠦॏ")
        eval(l11l1llll_opy_)
    except: pass
    return l11l1l1ll_opy_, l11l1ll11_opy_
def l11ll1111_opy_(l11l11l_opy_):
    l11l1lll1_opy_ = l1111l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧॐ") + l11l11l_opy_
    l11l11lll_opy_ = l1111l_opy_ (u"ࠬ࠵࠿ࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡰࡳࡩ࡫࠽࠲ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡹࡩࠪ࠸࠰ࡕࡘࠩࡹࡷࡲ࠽ࡩࡶࡷࡴࠪ࠹ࡡࠦ࠴ࡩࠩ࠷࡬࡭ࡦࡶࡤࡰࡰ࡫ࡴࡵ࡮ࡨ࠲ࡨࡵࠥ࠳ࡨࡘࡏ࡙ࡻࡲ࡬࠳࠻࠴࠷࠸࠰࠲࠸ࠨ࠶࡫ࡒࡩࡷࡧࠨ࠶࠺࠸࠰ࡕࡘ࠱ࡸࡽࡺࠧ॑")
    l11l1l111_opy_ = l1111l_opy_ (u"࠭࠯ࡀࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࠩࡱࡴࡪࡥ࠾࠳ࠩࡲࡦࡳࡥ࠾ࡕࡳࡳࡷࡺࡳࠧࡷࡵࡰࡂ࡮ࡴࡵࡲࠨ࠷ࡦࠫ࠲ࡧࠧ࠵ࡪࡲ࡫ࡴࡢ࡮࡮ࡩࡹࡺ࡬ࡦ࠰ࡦࡳࠪ࠸ࡦࡖࡍࡗࡹࡷࡱ࠱࠹࠲࠵࠶࠵࠷࠶ࠦ࠴ࡩࡗࡵࡵࡲࡵࡵࡏ࡭ࡸࡺ࠮ࡵࡺࡷ॒ࠫ")
    l1ll1lll_opy_  = []
    l1ll1lll_opy_ += sendJSON(l11l1lll1_opy_ + l11l11lll_opy_, l11l11l_opy_)
    l1ll1lll_opy_ += sendJSON(l11l1lll1_opy_ + l11l1l111_opy_, l11l11l_opy_)
    return l1ll1lll_opy_
def l11llll1l_opy_(l11l11l_opy_):
    if l11l11l_opy_ == l11ll111l_opy_:
        return l1111l_opy_ (u"ࠧ࠰ࡁࡦࡥࡹࡃ࠭࠳ࠨࡰࡳࡩ࡫࠽࠳ࠨࡱࡥࡲ࡫࠽ࡎࡻࠨ࠶࠵ࡉࡨࡢࡰࡱࡩࡱࡹࠦࡶࡴ࡯ࡁࡺࡸ࡬ࠨ॓")
def sendJSON(query, l11l11l_opy_):
    try:
        l11lll_opy_     = l1111l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫ॔") % query
        l1l1lll_opy_  = xbmc.executeJSONRPC(l11lll_opy_)
        response = json.loads(l1l1lll_opy_)
        result   = response[l1111l_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩॕ")]
        return result[l1111l_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩॖ")]
    except Exception as e:
        l1l1l1l1_opy_(e, l11l11l_opy_)
        return {l1111l_opy_ (u"ࠫࡊࡸࡲࡰࡴࠪॗ") : l1111l_opy_ (u"ࠬࡖ࡬ࡶࡩ࡬ࡲࠥࡋࡲࡳࡱࡵࠫक़")}
def l1l1l1l1_opy_(e, l11l11l_opy_):
    l1l1llll_opy_ = l1111l_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠱ࠦࡡ࡯ࠢࡨࡶࡷࡵࡲࠡࡱࡦࡧࡺࡸࡥࡥ࠼ࠣࡎࡘࡕࡎࠡࡇࡵࡶࡴࡸ࠺ࠡࠧࡶ࠰ࠥࠫࡳࠨख़")  % (e, l11l11l_opy_)
    l1l1l1ll_opy_ = l1111l_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡤࡱࡱࡸࡦࡩࡴࠡࡷࡶࠤࡴࡴࠠࡵࡪࡨࠤ࡫ࡵࡲࡶ࡯࠱ࠫग़")
    l1ll111l_opy_ = l1111l_opy_ (u"ࠨࡗࡳࡰࡴࡧࡤࠡࡣࠣࡰࡴ࡭ࠠࡷ࡫ࡤࠤࡹ࡮ࡥࠡࡣࡧࡨࡴࡴࠠࡴࡧࡷࡸ࡮ࡴࡧࡴࠢࡤࡲࡩࠦࡰࡰࡵࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰ࠴ࠧज़")
    dixie.log(l11l11l_opy_)
    dixie.log(e)
def getPlaylist():
    import requests
    l11ll11l1_opy_ = [l1111l_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡪࡳ࠷ࡲ࠮ࡪࡰ࡮࠳ࡰࡵࡤࡪࠩड़"), l1111l_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡼ࠳ࡩ࡯࠰ࡦࡥࡧ࡭࠶࠱ࠨढ़"), l1111l_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪ࠰ࡦࡧࡱࡪ࠮ࡪࡱࠪफ़"), l1111l_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧࡩࡰ࠰ࡦࡧࡱࡵࡵࡥࡶࡹ࠲ࡴࡸࡧ࠰࡭ࡲࡨ࡮࠭य़")]
    l11l1ll1l_opy_ =  l1111l_opy_ (u"࠭ࠣࡆ࡚ࡗࡑ࠸࡛ࠧॠ")
    for url in l11ll11l1_opy_:
        dixie.log(url)
        try:
            request  = requests.get(url)
            l11lll11l_opy_ = request.text
        except: pass
        if l11l1ll1l_opy_ in l11lll11l_opy_:
            path = os.path.join(dixie.PROFILE, l1111l_opy_ (u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡰ࠷ࡺ࠭ॡ"))
            with open(path, l1111l_opy_ (u"ࠨࡹࠪॢ")) as f:
                f.write(l11lll11l_opy_)
                break
    import urllib
    l11lll111_opy_ = os.path.join(PATH, l1111l_opy_ (u"ࠩࡷࡩࡲࡶࡩ࡯࡫ࠪॣ"))
    l11ll11ll_opy_  = os.path.join(PATH, l1111l_opy_ (u"ࠪ࡭ࡳ࡯࠲࠯࡫ࡱ࡭ࠬ।"))
    l11ll11l1_opy_  = l1111l_opy_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡸࡡࡸ࠰ࡪ࡭ࡹ࡮ࡵࡣࡷࡶࡩࡷࡩ࡯࡯ࡶࡨࡲࡹ࠴ࡣࡰ࡯࠲ࡖࡪࡴࡥࡨࡣࡧࡩࡸ࡚ࡖ࠰ࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳ࡸࡥ࡯ࡧࡪࡥࡩ࡫ࡳࡵࡸ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡥࡩࡪ࡯࡯ࡵ࠵࠲࡮ࡴࡩࠨ॥")
    urllib.urlretrieve(l11ll11l1_opy_, l11lll111_opy_)
    temp = open(l11lll111_opy_)
    l11lll1ll_opy_  = open(l11ll11ll_opy_, l1111l_opy_ (u"ࠬࡽࡴࠨ०"))
    for line in temp:
        l11lll1ll_opy_.write(line.replace(
                               l1111l_opy_ (u"࡛࠭ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡤࡦࡺࡠࠫ१"), l1111l_opy_ (u"ࠧ࡜ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡹࡺࡻࡡࠬ२"))
                               .replace(l1111l_opy_ (u"ࠨ࡝ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡈ࠱ࡘ࠳࡜࡝ࠨ३"), l1111l_opy_ (u"ࠩ࡞ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡼࡽࡣࠧ४"))
                               .replace(l1111l_opy_ (u"ࠪ࡟ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽ࡝ࠨ५"), l1111l_opy_ (u"ࠫࡠࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡾࡸ࡞ࠩ६"))
                               .replace(l1111l_opy_ (u"ࠬࡡࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡴࡷ࡟ࠪ७"), l1111l_opy_ (u"࡛࠭ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸࡹࡺࡠࠫ८"))
                               .replace(l1111l_opy_ (u"ࠧ࡜ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡣࡤࡦ࡭ࡵࡲࡡࡺࡧࡵࡡࠬ९"), l1111l_opy_ (u"ࠨ࡝ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡺࡻࡼࡢ࠭॰"))
                               .replace(l1111l_opy_ (u"ࠩ࡞ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡦࡥࡸࡺࡡࡸࡣࡼࡡࠬॱ"), l1111l_opy_ (u"ࠪ࡟ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡽࡾ࡝ࠨॲ"))
                               .replace(l1111l_opy_ (u"ࠫࡠࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡲ࡝ࠨॳ"), l1111l_opy_ (u"ࠬࡡࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾࡸࡹ࡟ࠪॴ"))
                               )
    temp.close()
    l11lll1ll_opy_.close()
    os.remove(l11lll111_opy_)