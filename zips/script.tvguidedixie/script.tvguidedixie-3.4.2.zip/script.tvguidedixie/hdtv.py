# coding: UTF-8
import sys
l1lll1ll_opy_ = sys.version_info [0] == 2
l1ll111_opy_ = 2048
l1ll1l_opy_ = 7
def l1111l_opy_ (ll_opy_):
	global l111_opy_
	l11111l_opy_ = ord (ll_opy_ [-1])
	l1llll1l_opy_ = ll_opy_ [:-1]
	l1ll1_opy_ = l11111l_opy_ % len (l1llll1l_opy_)
	l11l111_opy_ = l1llll1l_opy_ [:l1ll1_opy_] + l1llll1l_opy_ [l1ll1_opy_:]
	if l1lll1ll_opy_:
		l1l1l1l_opy_ = unicode () .join ([unichr (ord (char) - l1ll111_opy_ - (l11l1l_opy_ + l11111l_opy_) % l1ll1l_opy_) for l11l1l_opy_, char in enumerate (l11l111_opy_)])
	else:
		l1l1l1l_opy_ = str () .join ([chr (ord (char) - l1ll111_opy_ - (l11l1l_opy_ + l11111l_opy_) % l1ll1l_opy_) for l11l1l_opy_, char in enumerate (l11l111_opy_)])
	return eval (l1l1l1l_opy_)
import xbmc
import xbmcgui
import json
import time
import datetime
import os
from threading import Timer
import dixie
PATH     =  os.path.join(dixie.PROFILE, l1111l_opy_ (u"ࠧࡵࡧࡰࡴࠬ࢈"))
SETTING  = l1111l_opy_ (u"ࠨࡎࡒࡋࡎࡔ࡟ࡉࡆࡗ࡚ࠬࢉ")
l1l11l_opy_ =  80
def getURL(url):
    if dixie.validTime(SETTING, 60 * 60 * 8):
        response = json.load(open(PATH))
    else:
        response = l1l1ll11_opy_(url)
        l1lll1_opy_(SETTING)
    stream = url.split(l1111l_opy_ (u"ࠩ࠽ࠫࢊ"), 1)[-1].lower()
    try:
        result = response[l1111l_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪࢋ")]
        l1ll1lll_opy_  = result[l1111l_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪࢌ")]
    except Exception as e:
        l1l1l1l1_opy_(e)
        return None
    for file in l1ll1lll_opy_:
        l1l1lll1_opy_   = file[l1111l_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫࢍ")]
        l1l1lll1_opy_   = l1l1lll1_opy_.replace(l1111l_opy_ (u"࠭ࠠࠡࠩࢎ"), l1111l_opy_ (u"ࠧࠡࠩ࢏")).replace(l1111l_opy_ (u"ࠨࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࢐"), l1111l_opy_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࢑"))
        l1llll1_opy_ = l1l1lll1_opy_.rsplit(l1111l_opy_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ࢒"), 1)[0].split(l1111l_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡼ࡮ࡩࡵࡧࡠࠫ࢓"), 1)[-1]
        if stream == l1llll1_opy_.lower():
            return file[l1111l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪ࢔")]
    return None
def l1l1ll11_opy_(url):
    try:
        message = l1111l_opy_ (u"࠭ࡌࡰࡩࡪ࡭ࡳ࡭ࠠࡪࡰࡷࡳࠥࡹࡥࡳࡸࡨࡶ࠳ࠦࡏ࡯ࡧࠣࡱࡴࡳࡥ࡯ࡶࠣࡴࡱ࡫ࡡࡴࡧ࠱ࠫ࢕")
        dixie.notify(message)
        dixie.ShowBusy()
        response = l1ll11ll_opy_(url)
        dixie.CloseBusy()
        return response
    except Exception as e:
        l1l1l1l1_opy_(e)
        return {l1111l_opy_ (u"ࠧࡆࡴࡵࡳࡷ࠭࢖") : l1111l_opy_ (u"ࠨࡒ࡯ࡹ࡬࡯࡮ࠡࡇࡵࡶࡴࡸࠧࢗ")}
def l1ll11ll_opy_(url):
    doJSON(url)
    return json.load(open(PATH))
def doJSON(url):
    l11l1ll_opy_ = l1ll1ll1_opy_(url)
    xbmc.executeJSONRPC(l11l1ll_opy_)
    l1ll1l1l_opy_  = l1ll1111_opy_(url)
    response = xbmc.executeJSONRPC(l1ll1l1l_opy_)
    content = json.loads(response.decode(l1111l_opy_ (u"ࠩ࡯ࡥࡹ࡯࡮࠮࠳ࠪ࢘"), l1111l_opy_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧ࢙ࠪ")))
    json.dump(content, open(PATH,l1111l_opy_ (u"ࠫࡼ࢚࠭")), indent=0)
    l1ll11l1_opy_(url)
def l1ll1ll1_opy_(url):
    l11111_opy_ = l1llll_opy_(url)
    l11l1ll_opy_   = (l1111l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷ࠴ࡅࡡࡤࡶ࡬ࡳࡳࡃ࡭ࡢ࡫ࡱࡣࡱ࡯ࡳࡵࠨࡷ࡭ࡹࡲࡥ࠾ࠨࡸࡶࡱࡃࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁ࢛ࠬ") % l11111_opy_)
    return l11l1ll_opy_
def l1ll1111_opy_(url):
    l11111_opy_ = l1llll_opy_(url)
    l1ll1l1l_opy_ = (l1111l_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸ࠵࠿ࡢࡥࡷ࡭ࡴࡴ࠽࡭࡫ࡹࡩࡹࡼ࡟ࡢ࡮࡯ࠪࡹ࡯ࡴ࡭ࡧࡀࡅࡱࡲࠫࡤࡪࡤࡲࡳ࡫࡬ࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧ࢜") % l11111_opy_)
    return l1ll1l1l_opy_
def l1llll_opy_(url):
    if url.startswith(l1111l_opy_ (u"ࠧࡉࡆࡗ࡚࠿࠭࢝")):
        return l1111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡩࡦࡷࡺࠬ࢞")
    if url.startswith(l1111l_opy_ (u"ࠩࡋࡈ࡙࡜࠲࠻ࠩ࢟")):
        return l1111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧࡩࡱࡶࡹࠫࢠ")
    if url.startswith(l1111l_opy_ (u"ࠫࡍࡊࡔࡗ࠵࠽ࠫࢡ")):
        return l1111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢࡶࡹࠫࢢ")
    if url.startswith(l1111l_opy_ (u"࠭ࡈࡅࡖ࡙࠸࠿࠭ࢣ")):
        return l1111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸ࡭ࠩࢤ")
def l1ll11l1_opy_(url):
    name   = dixie.TITLE + l1111l_opy_ (u"ࠨࠢࡋࡈ࡙࡜ࠠࡖࡲࡧࡥࡹ࡫ࠧࢥ")
    l1ll1l11_opy_ = os.path.join(dixie.HOME, l1111l_opy_ (u"ࠩ࡫ࡨࡹࡼ࠮ࡱࡻࠪࢦ"))
    args   = url
    cmd    = l1111l_opy_ (u"ࠪࡅࡱࡧࡲ࡮ࡅ࡯ࡳࡨࡱࠨࠦࡵ࠯ࠤࡗࡻ࡮ࡔࡥࡵ࡭ࡵࡺࠨࠦࡵ࠯ࠤࠪࡹࠩ࠭ࠢࠨࡨ࠱ࠦࡔࡳࡷࡨ࠭ࠬࢧ") % (name, l1ll1l11_opy_, args, l1l11l_opy_)
    xbmc.executebuiltin(l1111l_opy_ (u"ࠫࡈࡧ࡮ࡤࡧ࡯ࡅࡱࡧࡲ࡮ࠪࠨࡷ࠱࡚ࡲࡶࡧࠬࠫࢨ") % name)
    xbmc.executebuiltin(cmd)
def l1lll1_opy_(l1l1ll1l_opy_):
    now = datetime.datetime.today()
    dixie.SetSetting(l1l1ll1l_opy_, str(now))
def l1l1l1l1_opy_(e):
    l1l1llll_opy_ = l1111l_opy_ (u"࡙ࠬ࡯ࡳࡴࡼ࠰ࠥࡧ࡮ࠡࡧࡵࡶࡴࡸࠠࡰࡥࡦࡹࡷ࡫ࡤ࠻ࠢࡍࡗࡔࡔࠠࡆࡴࡵࡳࡷࡀࠠࠦࡵࠪࢩ")  %e
    l1l1l1ll_opy_ = l1111l_opy_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡲࡦ࠯࡯࡭ࡳࡱࠠࡵࡪ࡬ࡷࠥࡩࡨࡢࡰࡱࡩࡱࠦࡡ࡯ࡦࠣࡸࡷࡿࠠࡢࡩࡤ࡭ࡳ࠴ࠧࢪ")
    l1ll111l_opy_ = l1111l_opy_ (u"ࠧࡖࡵࡨ࠾ࠥࡉ࡯࡯ࡶࡨࡼࡹࠦࡍࡦࡰࡸࠤࡂࡄࠠࡓࡧࡰࡳࡻ࡫ࠠࡔࡶࡵࡩࡦࡳࠧࢫ")
    dixie.log(e)
    dixie.DialogOK(l1l1llll_opy_, l1l1l1ll_opy_, l1ll111l_opy_)
    dixie.SetSetting(SETTING, l1111l_opy_ (u"ࠨࠩࢬ"))
if __name__ == l1111l_opy_ (u"ࠩࡢࡣࡲࡧࡩ࡯ࡡࡢࠫࢭ"):
    url = sys.argv[1]
    doJSON(url)