# coding: UTF-8
import sys
l1lll1ll_opy_ = sys.version_info [0] == 2
l1ll111_opy_ = 2048
l1ll1l_opy_ = 7
def l1111l_opy_ (ll_opy_):
	global l111_opy_
	l11111l_opy_ = ord (ll_opy_ [-1])
	l1llll1l_opy_ = ll_opy_ [:-1]
	l1ll1_opy_ = l11111l_opy_ % len (l1llll1l_opy_)
	l11l111_opy_ = l1llll1l_opy_ [:l1ll1_opy_] + l1llll1l_opy_ [l1ll1_opy_:]
	if l1lll1ll_opy_:
		l1l1l1l_opy_ = unicode () .join ([unichr (ord (char) - l1ll111_opy_ - (l11l1l_opy_ + l11111l_opy_) % l1ll1l_opy_) for l11l1l_opy_, char in enumerate (l11l111_opy_)])
	else:
		l1l1l1l_opy_ = str () .join ([chr (ord (char) - l1ll111_opy_ - (l11l1l_opy_ + l11111l_opy_) % l1ll1l_opy_) for l11l1l_opy_, char in enumerate (l11l111_opy_)])
	return eval (l1l1l1l_opy_)
import xbmc
import xbmcgui
import xbmcaddon
import dixie
import urllib2
import re
import json
import os
import datetime
from hashlib import md5
from threading import Timer
global l11ll1l_opy_, l1ll11_opy_, l11l11_opy_, l1lll1l1_opy_
l11ll1l_opy_  = None
l1ll11_opy_  = False
l11l11_opy_ = 0
l1lll1l1_opy_ = 0
ADDON = dixie.ADDON
HOME  = ADDON.getAddonInfo(l1111l_opy_ (u"ࠫࡵࡧࡴࡩࠩࠀ"))
ICON  = os.path.join(HOME, l1111l_opy_ (u"ࠬ࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧࠁ"))
ICON  = xbmc.translatePath(ICON)
TITLE = dixie.TITLE
SETTING = l1111l_opy_ (u"࠭ࡌࡐࡉࡌࡒࡤࡎࡄࡕࡘࠪࠂ")
l1l111l_opy_           = l1111l_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲࡫࡯࡬࡮ࡱࡱ࠲ࡨࡵ࡭࠰ࠩࠃ")
l111l_opy_       =  l1l111l_opy_ + l1111l_opy_ (u"ࠨࡣࡳ࡭࠴࡯࡮ࡪࡶ࠲ࠫࠄ")
l11_opy_      =  l1l111l_opy_ + l1111l_opy_ (u"ࠩࡤࡴ࡮࠵࡬ࡰࡩ࡬ࡲࡄࡹࡥࡴࡵ࡬ࡳࡳࡥ࡫ࡦࡻࡀࠩࡸࠬ࡬ࡰࡩ࡬ࡲࡂࠫࡳࠧࡲࡤࡷࡸࡽ࡯ࡳࡦࡀࠩࡸ࠭ࠅ")
l1lll_opy_     =  l1l111l_opy_ + l1111l_opy_ (u"ࠪࡥࡵ࡯࠯࡭ࡱࡪࡳࡺࡺ࠿ࡴࡧࡶࡷ࡮ࡵ࡮ࡠ࡭ࡨࡽࡂࠫࡳࠨࠆ")
l11ll1_opy_     =  l1l111l_opy_ + l1111l_opy_ (u"ࠫࡦࡶࡩ࠰ࡦࡹࡶ࠲ࡧࡤࡥࡁࡶࡩࡸࡹࡩࡰࡰࡢ࡯ࡪࡿ࠽ࠦࡵࠩࡧ࡭ࡧ࡮࡯ࡧ࡯ࡣ࡮ࡪ࠽ࠦࡵࠩࡴࡷࡵࡧࡳࡣࡰࡱࡪࡥࡩࡥ࠿ࠨࡷࠫࡹࡴࡢࡴࡷࡣࡹ࡯࡭ࡦ࠿ࠨࡷࠬࠇ")
l111ll1_opy_ =  l1l111l_opy_ + l1111l_opy_ (u"ࠬࡧࡰࡪ࠱ࡧࡺࡷ࠳࡬ࡪࡵࡷࡃࡸ࡫ࡳࡴ࡫ࡲࡲࡤࡱࡥࡺ࠿ࠨࡷࠬࠈ")
l1l11ll_opy_     =  l1l111l_opy_ + l1111l_opy_ (u"࠭ࡡࡱ࡫࠲ࡨࡻࡸ࠭ࡳࡧࡰࡳࡻ࡫࠿ࡴࡧࡶࡷ࡮ࡵ࡮ࡠ࡭ࡨࡽࡂࠫࡳࠧࡴࡨࡧࡴࡸࡤࡪࡰࡪࡣ࡮ࡪ࠽ࠦࡵࠪࠉ")
l111lll_opy_      =  l1l111l_opy_ + l1111l_opy_ (u"ࠧࡵࡸ࠲ࡥࡵ࡯࠯ࡵࡸࡪࡹ࡮ࡪࡥ࠰ࠧࡶࡃࡸ࡫ࡳࡴ࡫ࡲࡲࡤࡱࡥࡺ࠿ࠨࡷࠬࠊ")
l1l11l_opy_ = 275
l1lll11_opy_  = l1111l_opy_ (u"ࠨࠩࠋ")
l11ll11_opy_  = l1111l_opy_ (u"ࠩࠪࠌ")
AVAILABLE = False
if not AVAILABLE:
    try:
        l11l11l_opy_    = xbmcaddon.Addon(l1111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡉ࠲࡙࠴ࡖࠨࠍ"))
        l1lll11_opy_ = l11l11l_opy_.getSetting(l1111l_opy_ (u"ࠫ࡫࡯࡬࡮ࡱࡱࡣࡺࡹࡥࡳࠩࠎ"))
        l11ll11_opy_ = l11l11l_opy_.getSetting(l1111l_opy_ (u"ࠬ࡬ࡩ࡭࡯ࡲࡲࡤࡶࡡࡴࡵࠪࠏ"))
        l11ll11_opy_ = md5(l11ll11_opy_).hexdigest()
        AVAILABLE = len(l1lll11_opy_) > 0 and len(l11ll11_opy_) > 0
    except:
        AVAILABLE = False
if not AVAILABLE:
    try:
        l11l11l_opy_    = xbmcaddon.Addon(l1111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡩࡳࡦࡺࡳࡥࡹࡺࡶࠨࠐ"))
        l1lll11_opy_ = l11l11l_opy_.getSetting(l1111l_opy_ (u"ࠧࡶࡵࡨࡶࠬࠑ"))
        l11ll11_opy_ = l11l11l_opy_.getSetting(l1111l_opy_ (u"ࠨࡲࡤࡷࡸ࠭ࠒ"))
        l11ll11_opy_ = md5(l11ll11_opy_).hexdigest()
        AVAILABLE = len(l1lll11_opy_) > 0 and len(l11ll11_opy_) > 0
    except:
        AVAILABLE = False
dixie.log(l1111l_opy_ (u"ࠩࡉ࡭ࡱࡳ࡯࡯ࠢࡘࡷࡪࡸ࡮ࡢ࡯ࡨࠤ࠿ࠦࠥࡴࠩࠓ") % l1lll11_opy_)
dixie.log(l1111l_opy_ (u"ࠪࡊ࡮ࡲ࡭ࡰࡰࠣࡔࡦࡹࡳࡸࡱࡵࡨࠥࡀࠠࠦࡵࠪࠔ") % l11ll11_opy_)
if AVAILABLE:
    dixie.log(l1111l_opy_ (u"ࠫࡋ࡯࡬࡮ࡱࡱࠤ࡮ࡹࠠࡂࡘࡄࡍࡑࡇࡂࡍࡇࠪࠕ"))
else:
    dixie.log(l1111l_opy_ (u"ࠬࡌࡩ࡭࡯ࡲࡲࠥ࡯ࡳࠡࡐࡒࡘࠥࡇࡖࡂࡋࡏࡅࡇࡒࡅࠨࠖ"))
def notify(message, length=5000):
    cmd = l1111l_opy_ (u"࠭ࡘࡃࡏࡆ࠲ࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࠫࠩࡸ࠲ࠥࡴ࠮ࠨࡨ࠱ࠫࡳࠪࠩࠗ") % (TITLE, message, length, ICON)
    xbmc.executebuiltin(cmd)
def l1l1l_opy_():
    return l1111l_opy_ (u"ࠧࠡࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳ࠼ࠢࡘ࠿ࠥ࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠸࠲࠶ࡁࠠࡦࡰ࠰ࡋࡇࡁࠠࡳࡸ࠽࠵࠳࠿࠮࠱࠰࠶࠭ࠥࡍࡥࡤ࡭ࡲ࠳࠷࠶࠰࠹࠲࠼࠶࠹࠷࠷ࠡࡈ࡬ࡶࡪ࡬࡯ࡹ࠱࠶࠲࠵࠴࠳ࠨ࠘")
def isValid(stream):
    if stream.startswith(l1111l_opy_ (u"ࠨࡊࡇࡘ࡛࠭࠙")):
        return True
    if not AVAILABLE:
        return False
    if stream.startswith(l1111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡊ࠳࡚࠮ࡗࠩࠚ")):
        return True
    if stream.startswith(l1111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡨࡹࡥࡹࡲࡤࡸࡹࡼࠧࠛ")):
        return True
    return False
def l1ll11l_opy_(url):
    global l1lll1l1_opy_
    try:
        req  = urllib2.Request(url)
        req.add_header(l1111l_opy_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨࠜ"), l1l1l_opy_())
        resp = urllib2.urlopen(req, timeout=10)
        headers = resp.headers
        l1lll1l_opy_     = headers[l1111l_opy_ (u"ࠬࡊࡡࡵࡧࠪࠝ")].split(l1111l_opy_ (u"࠭ࠬࠡࠩࠞ"))[-1]
        l1lll1l_opy_     = datetime.datetime.strptime(l1lll1l_opy_, l1111l_opy_ (u"ࠧࠦࡦࠣࠩࡧ࡚ࠦࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠨࠟ"))
        l1lll1l1_opy_ = l1lll1l_opy_ - datetime.datetime.today()
        l1lll1l1_opy_ = ((l1lll1l1_opy_.days * 86400) + (l1lll1l1_opy_.seconds + 1800)) / 3600
        l1lll1l1_opy_ *= -3600
        l1111ll_opy_ = resp.read()
        resp.close()
        return l1111ll_opy_
    except Exception, e:
        dixie.log(l1111l_opy_ (u"ࠨࡇࡵࡶࡴࡸࠠࡪࡰࠣࡋࡪࡺࡈࡕࡏࡏ࠰ࠥࡻࡲ࡭ࠢࡀࠤࠪࡹࠧࠠ") % url)
        dixie.log(str(e))
        return str(e)
def l111ll_opy_():
    if (not l1lll11_opy_) or (not l11ll11_opy_):
        return
    l1llllll_opy_()
    try:
        global l11l11_opy_
        l11l11_opy_ = 0
        response  = l1ll11l_opy_(l111l_opy_)
        l11l11_opy_ = re.compile(l1111l_opy_ (u"ࠩࠥࡷࡪࡹࡳࡪࡱࡱࡣࡰ࡫ࡹࠣ࠼ࠥࠬ࠳࠱࠿ࠪࠤࠪࠡ")).search(response).group(1)
    except:
        pass
def l11l1ll_opy_():
    dixie.log(l1111l_opy_ (u"ࠪࡉࡳࡺࡥࡳ࡫ࡱ࡫ࠥࡲ࡯ࡨ࡫ࡱࠫࠢ"))
    global l11ll1l_opy_, l1ll11_opy_, l11l11_opy_
    l1ll11_opy_ = False
    if l11l11_opy_ == 0:
        l111ll_opy_()
    url   = l11_opy_ % (l11l11_opy_, l1lll11_opy_, l11ll11_opy_)
    l11l1ll_opy_ = l1ll11l_opy_(url)
    l1ll11_opy_ = l1111l_opy_ (u"ࠫࡊࡘࡒࡐࡔࠪࠣ") not in l11l1ll_opy_.upper()
    if l1ll11_opy_:
        message = l1111l_opy_ (u"ࠬࡒ࡯ࡨࡩࡨࡨࠥ࡯࡮ࡵࡱࠣࡊ࡮ࡲ࡭ࡰࡰࠪࠤ")
    else:
        message = l1111l_opy_ (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡏࡳ࡬ࠦࡩ࡯ࡶࡲࠤࡋ࡯࡬࡮ࡱࡱࠫࠥ")
    dixie.log(message)
    notify(message)
    if l1ll11_opy_:
        l11ll1l_opy_ = Timer(l1l11l_opy_, l1l1111_opy_)
        l11ll1l_opy_.start()
def l1llllll_opy_():
    global l11ll1l_opy_
    if l11ll1l_opy_:
        l11ll1l_opy_.cancel()
        del l11ll1l_opy_
        l11ll1l_opy_ = None
def l1l1111_opy_():
    l1llllll_opy_()
    global l1ll11_opy_, l11l11_opy_
    if not l1ll11_opy_:
        return
    id = l11l11_opy_
    l1ll11_opy_  = False
    l11l11_opy_ = 0
    try:
        url    = l1lll_opy_ % id
        l1l1111_opy_ = l1ll11l_opy_(url)
        l1l1ll1_opy_  = json.loads(l1l1111_opy_)
        if l1111l_opy_ (u"ࠧࡴࡷࡦࡧࡪࡹࡳࠨࠦ") in l1l1ll1_opy_:
            l1ll11_opy_ = not l1l1ll1_opy_[l1111l_opy_ (u"ࠨࡵࡸࡧࡨ࡫ࡳࡴࠩࠧ")]
        if l1ll11_opy_:
            dixie.log(l1111l_opy_ (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡒ࡯ࡨࡱࡸࡸࠥࡵࡦࠡࡈ࡬ࡰࡲࡵ࡮ࠨࠨ"))
        else:
            dixie.log(l1111l_opy_ (u"ࠪࡐࡴ࡭ࡧࡦࡦࠣࡳࡺࡺࠠࡰࡨࠣࡊ࡮ࡲ࡭ࡰࡰࠪࠩ"))
    except:
        pass
def l1ll_opy_(l1l111_opy_):
    global l1lll1l1_opy_
    start   = datetime.datetime(1970, 1, 1)
    l1l1_opy_   = l1l111_opy_ - start
    seconds = (l1l1_opy_.days * 86400) + l1l1_opy_.seconds
    return seconds - l1lll1l1_opy_
def l1lllll_opy_(l1llll1_opy_):
    global l11l11_opy_
    try:
        if l11l11_opy_ == 0:
            return None
        l1lll11l_opy_ = l1ll11l_opy_(l111lll_opy_ % (l1llll1_opy_, l11l11_opy_))
        return l1lll11l_opy_
    except Exception, e:
        dixie.log(l1111l_opy_ (u"ࠫࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣ࡫ࡪࡺࡇࡶ࡫ࡧࡩࠥࠫࡳࠨࠪ") % str(e))
        return None
def l1l1l11_opy_(l1l1l1_opy_):
    try:
        return int(re.compile(l1111l_opy_ (u"ࠬࡻࡲ࡭࠿ࠫ࠲࠰ࡅࠩࠧࠩࠫ")).search(l1l1l1_opy_).group(1))
    except:
        pass
    try:
        l11l1l1_opy_ = l1l1l1_opy_.rsplit(l1111l_opy_ (u"࠭ࡣࡩࡡࡩࡥࡳࡧࡲࡵ࠿ࠪࠬ"), 1)[-1]
        l11l1l1_opy_ = int(l11l1l1_opy_.split(l1111l_opy_ (u"ࠧ࠽ࡀࠪ࠭"), 1)[0])
        return l11l1l1_opy_
    except:
        return None
def getProgram(l1llll1_opy_, start):
    dixie.log(l1111l_opy_ (u"ࠨࡇࡱࡸࡪࡸࡩ࡯ࡩࠣ࡫ࡪࡺࡐࡳࡱࡪࡶࡦࡳࠧ࠮"))
    dixie.log(l1111l_opy_ (u"ࠩࡆ࡬ࡦࡴ࡮ࡦ࡮ࠣࡁࠥࠫࡳࠨ࠯") % str(l1llll1_opy_))
    dixie.log(l1111l_opy_ (u"ࠪࡗࡹࡧࡲࡵࠢࠣࠤࡂࠦࠥࡴࠩ࠰") % str(start))
    try:
        l11l_opy_ = l1ll_opy_(start)
        dixie.log(l1111l_opy_ (u"ࠫࡘࡺࡡࡳࡶࡗࡗࠥࡃࠠࠦࡵࠪ࠱") % str(l11l_opy_))
        dixie.log(l1111l_opy_ (u"ࠬࡺࡹࡱࡧࠫࡗࡹࡧࡲࡵࡖࡖ࠭ࠥࡃࠠࠦࡵࠪ࠲") % type(l11l_opy_))
        l1lll11l_opy_ = l1lllll_opy_(l1llll1_opy_)
        if not l1lll11l_opy_:
            return None
        l1lll11l_opy_ = json.loads(l1lll11l_opy_)
        for l1ll1ll_opy_ in l1lll11l_opy_:
            dixie.log(l1111l_opy_ (u"࠭࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࠩ࠳"))
            dixie.log(l1111l_opy_ (u"ࠧࡕࡻࡳࡩࠥࡃࠠࠦࡵࠪ࠴") % type(l1ll1ll_opy_))
            dixie.log(l1111l_opy_ (u"ࠨࡖࡼࡴࡪࠦ࡯ࡧࠢࡳࡶࡴ࡭ࡲࡢ࡯࡞ࡷࡹࡧࡲࡵࡦࡤࡸࡪࡺࡩ࡮ࡧࡠࠤࡂࠦࠥࡴࠩ࠵") % type(l1ll1ll_opy_[l1111l_opy_ (u"ࠩࡶࡸࡦࡸࡴࡥࡣࡷࡩࡹ࡯࡭ࡦࠩ࠶")]))
            dixie.log(l1ll1ll_opy_)
            dixie.log(l1111l_opy_ (u"ࠪࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤ࠭࠷"))
            dixie.log(l1111l_opy_ (u"ࠫ࠶ࠦࠠࠡࠩ࠸"))
            dixie.log(l1111l_opy_ (u"ࠬ࠸ࠠࠡࠢࠪ࠹"))
            dixie.log(l1111l_opy_ (u"࠭࠳ࠡࠢࠣࠫ࠺"))
            if l1111l_opy_ (u"ࠧࡴࡶࡤࡶࡹࡪࡡࡵࡧࡷ࡭ࡲ࡫ࠧ࠻") in l1ll1ll_opy_ and l1111l_opy_ (u"ࠨࡲࡵࡳ࡬ࡸࡡ࡮࡯ࡨࠫ࠼") in l1ll1ll_opy_:
                if int(l1ll1ll_opy_[l1111l_opy_ (u"ࠩࡶࡸࡦࡸࡴࡥࡣࡷࡩࡹ࡯࡭ࡦࠩ࠽")]) == l11l_opy_:
                    return l1ll1ll_opy_[l1111l_opy_ (u"ࠪࡴࡷࡵࡧࡳࡣࡰࡱࡪ࠭࠾")]
    except Exception, e:
        dixie.log(l1111l_opy_ (u"ࠫࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣ࡫ࡪࡺࡐࡳࡱࡪࡶࡦࡳࠠࠦࡵࠪ࠿") % str(e))
    dixie.log(l1111l_opy_ (u"ࠬࡘࡥࡵࡷࡵࡲ࡮ࡴࡧࠡࡐࡲࡲࡪࠦࡦࡳࡱࡰࠤ࡬࡫ࡴࡑࡴࡲ࡫ࡷࡧ࡭ࠨࡀ"))
    return None
def verifyLogin():
    dixie.log(l1111l_opy_ (u"࠭ࡅ࡯ࡶࡨࡶ࡮ࡴࡧࠡࡘࡨࡶ࡮࡬ࡹࡍࡱࡪ࡭ࡳ࠭ࡁ"))
    try:
        global l1ll11_opy_
        if not l1ll11_opy_:
            dixie.log(l1111l_opy_ (u"ࠧࡂࡶࡷࡩࡲࡶࡴࡪࡰࡪࠤࡹࡵࠠࡍࡱࡪ࡭ࡳ࠭ࡂ"))
            l11l1ll_opy_()
        if not l1ll11_opy_:
            dixie.log(l1111l_opy_ (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡑࡵࡧࡪࡰࠪࡃ"))
            dixie.DialogOK(l1111l_opy_ (u"ࠩࡑࡳࡹࠦ࡬ࡰࡩࡪࡩࡩࠦࡩ࡯ࡶࡲࠤࡋ࡯࡬࡮ࡱࡱ࠲ࠬࡄ"), l1111l_opy_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡧ࡭࡫ࡣ࡬ࠢࡧࡩࡹࡧࡩ࡭ࡵࠣࡥࡳࡪࠠࡵࡴࡼࠤࡦ࡭ࡡࡪࡰ࠱ࠫࡅ"))
            return False
        return True
    except Exception, e:
        dixie.log(l1111l_opy_ (u"ࠫࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰ࡚ࠣࡪࡸࡩࡧࡻࡏࡳ࡬࡯࡮ࠡࠧࡶࠫࡆ") % str(e))
    return False
def isRecorded(name, start):
    if not verifyLogin():
        return False, None
    l111111_opy_ = getRecording(name, start)
    if l111111_opy_ == None:
        dixie.log(l1111l_opy_ (u"ࠬࠫࡳࠡ࡫ࡶࠤࡓࡕࡔࠡࡔࡈࡇࡔࡘࡄࡆࡆࠪࡇ") % name)
        return False, None
    dixie.log(l1111l_opy_ (u"࠭ࠥࡴࠢ࡬ࡷࠥࡘࡅࡄࡑࡕࡈࡊࡊࠧࡈ") % name)
    return True, l111111_opy_
def record(name, start, end, l1l1l1_opy_, l1llll11_opy_=True):
    output = l1111l_opy_ (u"ࠧࡂࡶࡷࡩࡲࡶࡴࡪࡰࡪࠤࡹࡵࠠࡴࡧࡷࠤࡷ࡫ࡣࡰࡴࡧ࡭ࡳ࡭ࠠࡧࡱࡵࠤࠪࡹࠠࡴࡶࡤࡶࡹࡀࠥࡴࠢࡨࡲࡩࡀࠥࡴࠢࡶࡸࡷ࡫ࡡ࡮࠼ࠨࡷࠬࡉ") % (name, start, end, l1l1l1_opy_)
    dixie.log(output)
    if not verifyLogin():
        dixie.log(l1111l_opy_ (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡻ࡫ࡲࡪࡨࡼࠤࡱࡵࡧࡪࡰࠪࡊ"))
        return False
    global l11l11_opy_
    l1llll1_opy_ = l1l1l11_opy_(l1l1l1_opy_)
    if not l1llll1_opy_:
        dixie.log(l1111l_opy_ (u"ࠩࡱࡳࡹࠦࡣࡩࡣࡱࡲࡪࡲࠧࡋ"))
        dixie.DialogOK(l1111l_opy_ (u"ࠪࡒࡴࠦࡶࡢ࡮࡬ࡨࠥࡩࡨࡢࡰࡱࡩࡱࠦࡦࡰࡷࡱࡨࠥ࡯࡮ࠡࡵࡷࡶࡪࡧ࡭࠯ࠩࡌ"), l1111l_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡪࡪࡩࡵࠢࡶࡸࡷ࡫ࡡ࡮ࠢࡤࡲࡩࠦࡴࡳࡻࠣࡥ࡬ࡧࡩ࡯࠰ࠪࡍ"))
        return False
    l1ll1ll_opy_ = getProgram(l1llll1_opy_, start)
    if not l1ll1ll_opy_:
        dixie.log(l1111l_opy_ (u"ࠬࡴ࡯ࡵࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠪࡎ"))
        dixie.DialogOK(l1111l_opy_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠠ࡯ࡱࡷࠤ࡫ࡵࡵ࡯ࡦࠣ࡭ࡳࠦࡆࡪ࡮ࡰࡳࡳࠦࡧࡶ࡫ࡧࡩ࠳࠭ࡏ"))
        return False
    url     = l11ll1_opy_ % (l11l11_opy_, l1llll1_opy_, l1ll1ll_opy_, l1ll_opy_(start))
    record  = l1ll11l_opy_(url)
    l111l1l_opy_ = False
    dixie.log(l1111l_opy_ (u"ࠧࡳࡧࡦࡳࡷࡪࠠࡵࡣࡶ࡯ࠥࡻࡲ࡭ࠢ࠽ࠤࠪࡹࠧࡐ") % url)
    dixie.log(l1111l_opy_ (u"ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࠩࡸ࠭ࡑ") % record)
    try:
        l1l1ll1_opy_ = json.loads(record)
        dixie.log(l1111l_opy_ (u"ࠩࡄࡷࠥࡐࡓࡐࡐࠪࡒ"))
        dixie.log(l1l1ll1_opy_)
        if l1111l_opy_ (u"ࠪࡷࡺࡩࡣࡦࡵࡶࠫࡓ") in l1l1ll1_opy_:
           l111l1l_opy_ = l1l1ll1_opy_[l1111l_opy_ (u"ࠫࡸࡻࡣࡤࡧࡶࡷࠬࡔ")]
    except Exception, e:
        error = record.split(l1111l_opy_ (u"ࠬࡀࠧࡕ"))[-1].strip()
        dixie.log(l1111l_opy_ (u"࠭ࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥࡸࡥࡤࡱࡵࡨࠥࠫࡳࠨࡖ") % str(e))
        dixie.log(error)
        if not l1llll11_opy_:
            return False
        dixie.DialogOK(name, l1111l_opy_ (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡷࡨ࡮ࡥࡥࡷ࡯ࡩࠥࡸࡥࡤࡱࡵࡨ࡮ࡴࡧ࠯ࠩࡗ"), error)
        return False
    if not l1llll11_opy_:
        return l1ll1ll_opy_
    if l111l1l_opy_:
        if end < datetime.datetime.today():
            dixie.DialogOK(name, l1111l_opy_ (u"ࠨࡊࡤࡷࠥࡨࡥࡦࡰࠣࡶࡪࡩ࡯ࡳࡦࡨࡨ࠳࠭ࡘ"))
        else:
            dixie.DialogOK(name, l1111l_opy_ (u"ࠩࡋࡥࡸࠦࡢࡦࡧࡱࠤࡸࡩࡨࡦࡦࡸࡰࡪࡪࠠࡵࡱࠣࡦࡪࠦࡲࡦࡥࡲࡶࡩ࡫ࡤ࠯࡙ࠩ"))
    else:
        dixie.DialogOK(l1111l_opy_ (u"ࠪࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡳࡤࡪࡨࡨࡺࡲࡥࠡࡴࡨࡧࡴࡸࡤࡪࡰࡪ࠲࡚ࠬ"))
    return l1ll1ll_opy_
def getRecording(name, start):
    if not verifyLogin():
        return False
    global l11l11_opy_
    url        = l111ll1_opy_ % l11l11_opy_
    l1l11l1_opy_ = l1ll11l_opy_(url)
    l1l11l1_opy_ = json.loads(l1l11l1_opy_)
    l1l11l1_opy_ = l1l11l1_opy_[l1111l_opy_ (u"ࠫࡷ࡫ࡣࡰࡴࡧ࡭ࡳ࡭ࡳࠨ࡛")]
    l11l_opy_ = l1ll_opy_(start)
    name    = name.lower()
    for l111111_opy_ in l1l11l1_opy_:
        try:
            title = l111111_opy_[l1111l_opy_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ࡜")].lower()
            start = int(l111111_opy_[l1111l_opy_ (u"࠭ࡴࡪ࡯ࡨࡣࡸࡺࡡࡳࡶࠪ࡝")])
            if (start == l11l_opy_):
                dixie.log(l1111l_opy_ (u"ࠧࡅࡱࡺࡲࡱࡵࡡࡥࠢࡘࡖࡑࠦ࠽ࠡࠧࡶࠫ࡞") % l111111_opy_[l1111l_opy_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡹࡷࡲࠧ࡟")])
                return l111111_opy_[l1111l_opy_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡺࡸ࡬ࠨࡠ")]
        except Exception, e:
            dixie.log(l1111l_opy_ (u"ࠪࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡴࡩࡴࡲࡻࡳࠦࡩ࡯ࠢࡪࡩࡹࡘࡥࡤࡱࡵࡨ࡮ࡴࡧࠡࠧࡶࠫࡡ") % str(e))
    return None
def getHDTVRecording(name, start, stream):
    import urllib
    l11lll1_opy_ = l1111_opy_()
    dixie.log(l1111l_opy_ (u"ࠫࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࠣࡇࡆ࡚ࡃࡉࠢࡘࡔࠥࡎࡄࡕࡘࠣࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࠪࡢ"))
    dixie.log(name)
    dixie.log(stream)
    dixie.log(l1111l_opy_ (u"ࠬࡋࡐࡈࠢࡖࡸࡦࡸࡴࠡࡖ࡬ࡱࡪ࠴࠮࠯࠼ࠣࠩࡸ࠭ࡣ") % start)
    dixie.log(l1111l_opy_ (u"࠭ࡏࡧࡨࡶࡩࡹࠦࡩ࡯ࠢࡶࡩࡨࡵ࡮ࡥࡵ࠽ࠤࠪࡹࠧࡤ") % l11lll1_opy_)
    l1lllll1_opy_  =  start - datetime.timedelta(seconds=l11lll1_opy_)
    dixie.log(l1111l_opy_ (u"ࠧࡔࡶࡤࡶࡹࠦࡔࡪ࡯ࡨࠤࡴ࡬ࡦࡴࡧࡷ࠾ࠥࠫࡳࠨࡥ") % l1lllll1_opy_)
    l11l1_opy_ =  str(l1lllll1_opy_)
    l1_opy_  =  l11l1_opy_.split(l1111l_opy_ (u"ࠨࠢࠪࡦ"))[0]
    l1ll1l1_opy_  =  getRecordURL(name)
    if l1ll1l1_opy_ is None:
        dixie.DialogOK(l1111l_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠯ࠩࡧ"), l1111l_opy_ (u"࡛ࠪࡪࠦࡣࡰࡷ࡯ࡨࠥࡴ࡯ࡵࠢࡩ࡭ࡳࡪࠠࡢࠢࡦࡥࡹࡩࡨࡶࡲࠣࡷࡪࡸࡶࡪࡥࡨࠤ࡫ࡵࡲࠡࡶ࡫࡭ࡸࠦࡣࡩࡣࡱࡲࡪࡲ࠮ࠨࡨ"), l1111l_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡹࡸࡹࠡࡣࡱࡳࡹ࡮ࡥࡳࠢࡦ࡬ࡦࡴ࡮ࡦ࡮࠱ࠫࡩ"))
        return None
    l11llll_opy_  =  l11l1_opy_.split(l1111l_opy_ (u"ࠬ࠳ࠧࡪ"), 1)[-1].rsplit(l1111l_opy_ (u"࠭࠺ࠨ࡫"), 1)[0]
    l1l11_opy_    =  urllib.quote_plus(l11llll_opy_)
    l111l11_opy_  = l1111l_opy_ (u"ࠧࡱ࡮ࡲࡸࡂ࠭࡬") + l1l11_opy_
    l11111_opy_    =  l1llll_opy_(stream)
    dixie.log(l11111_opy_)
    l111l1_opy_  = l1111l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭࡭") % l11111_opy_
    l11ll_opy_  = l1111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠪࡹ࠯ࡀࡣࡦࡸ࡮ࡵ࡮࠾࡮࡬ࡺࡪࡺࡶࡠࡥࡤࡸࡨ࡮ࡵࡱࡡࡥࡽࡤࡩࡨࡢࡰࡱࡩࡱࡥࡡ࡯ࡦࡢࡨࡦࡺࡥࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠬࡴࡪࡶ࡯ࡩࡂࠫࡳࠧࡷࡵࡰࡂࠫࡳࠨ࡮") % (l11111_opy_, l1_opy_, l1ll1l1_opy_)
    l11lll_opy_       = l1111l_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭࡯") % l11ll_opy_
    if not dixie.validTime(SETTING, 60 * 60 * 8):
        xbmc.executeJSONRPC(l111l1_opy_)
        l1lll1_opy_(SETTING)
    l1l1lll_opy_    =  xbmc.executeJSONRPC(l11lll_opy_)
    response   =  json.loads(l1l1lll_opy_)
    result     =  response[l1111l_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫࡰ")]
    l1l11l1_opy_ =  result[l1111l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫࡱ")]
    for l111111_opy_ in l1l11l1_opy_:
        try:
            l1ll1ll_opy_ = l111111_opy_[l1111l_opy_ (u"࠭ࡦࡪ࡮ࡨࠫࡲ")]
            if l111l11_opy_ in l1ll1ll_opy_:
                dixie.log(l1111l_opy_ (u"ࠧࡱࡴࡲ࡫ࡷࡧ࡭ࡊࡆࠣࡁࠥࠫࡳࠨࡳ") % l1ll1ll_opy_)
                return l1ll1ll_opy_
        except Exception, e:
            dixie.log(l1111l_opy_ (u"ࠨࡇࡕࡖࡔࡘ࠺ࠡࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤࡹ࡮ࡲࡰࡹࡱࠤ࡮ࡴࠠࡨࡧࡷࡌࡉ࡚ࡖࡓࡧࡦࡳࡷࡪࡩ࡯ࡩࠣࠩࡸ࠭ࡴ") % str(e))
            dixie.DialogOK(l1111l_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠯ࠩࡵ"), l1111l_opy_ (u"࡛ࠪࡪࠦࡣࡰࡷ࡯ࡨࠥࡴ࡯ࡵࠢࡩ࡭ࡳࡪࠠࡢࠢࡦࡥࡹࡩࡨࡶࡲࠣࡷࡹࡸࡥࡢ࡯ࠣࡪࡴࡸࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲ࠴ࠧࡶ"), l1111l_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡹࡸࡹࠡࡣࡪࡥ࡮ࡴࠠ࡭ࡣࡷࡩࡷ࠴ࠧࡷ"))
            return None
    return None
def l1llll_opy_(stream):
    if stream.startswith(l1111l_opy_ (u"ࠬࡎࡄࡕࡘ࠽ࠫࡸ")):
        return l1111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡮ࡤࡵࡸࠪࡹ")
    if stream.startswith(l1111l_opy_ (u"ࠧࡉࡆࡗ࡚࠷ࡀࠧࡺ")):
        return l1111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥ࡮ࡶࡴࡷࠩࡻ")
    if stream.startswith(l1111l_opy_ (u"ࠩࡋࡈ࡙࡜࠳࠻ࠩࡼ")):
        return l1111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡰࠬࡽ")
def getRecordURL(name):
    l1l1ll_opy_   = dixie.PROFILE
    l1l_opy_ = os.path.join(l1l1ll_opy_, l1111l_opy_ (u"ࠫ࡮ࡴࡩࠨࡾ"), l1111l_opy_ (u"ࠬࡩࡡࡵࡥ࡫ࡹࡵ࠴ࡴࡹࡶࠪࡿ"))
    l1lll111_opy_   = json.load(open(l1l_opy_))
    for l1llll1_opy_ in l1lll111_opy_:
        if name.upper() == l1llll1_opy_[l1111l_opy_ (u"࠭ࡏࡕࡖ࡙ࠫࢀ")].upper():
            return l1llll1_opy_[l1111l_opy_ (u"ࠧࡖࡔࡏࠫࢁ")]
def l1111_opy_():
    import requests
    response = requests.get(l1111l_opy_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡴ࡮࠴ࡩࡱ࡫ࡩࡽ࠳ࡵࡲࡨࠩࢂ"))
    headers  = response.headers
    l1lll1l_opy_      = headers[l1111l_opy_ (u"ࠩࡇࡥࡹ࡫ࠧࢃ")].split(l1111l_opy_ (u"ࠪ࠰ࠥ࠭ࢄ"))[-1]
    l1lll1l_opy_      = datetime.datetime.strptime(l1lll1l_opy_, l1111l_opy_ (u"ࠫࠪࡪࠠࠦࡤࠣࠩ࡞ࠦࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠡࡉࡐࡘࠬࢅ"))
    l11lll1_opy_ = l1lll1l_opy_ - datetime.datetime.today()
    l11lll1_opy_ = ((l11lll1_opy_.days * 86400) + (l11lll1_opy_.seconds + 1800)) / 3600
    l11lll1_opy_ *= -3600
    return l11lll1_opy_
def l1111l1_opy_(url):
    if not verifyLogin():
        return False
    try:
        l111l11_opy_ = url.rsplit(l1111l_opy_ (u"ࠬ࠵ࠧࢆ"), 1)[-1].split(l1111l_opy_ (u"࠭࠮ࠨࢇ"), 1)[0]
        global l11l11_opy_
        url        = l1l11ll_opy_ % (l11l11_opy_, l111l11_opy_)
        response   = l1ll11l_opy_(url)
        response   = json.loads(response)
    except:
        pass