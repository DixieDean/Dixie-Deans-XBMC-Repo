# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l11lll_opy_ = 2048
l1l1l_opy_ = 7
def l1ll11_opy_ (ll_opy_):
	global l1l111_opy_
	l1lll1l_opy_ = ord (ll_opy_ [-1])
	l1l1l1_opy_ = ll_opy_ [:-1]
	l11_opy_ = l1lll1l_opy_ % len (l1l1l1_opy_)
	l111_opy_ = l1l1l1_opy_ [:l11_opy_] + l1l1l1_opy_ [l11_opy_:]
	if l1_opy_:
		l111ll_opy_ = unicode () .join ([unichr (ord (char) - l11lll_opy_ - (l1lll1_opy_ + l1lll1l_opy_) % l1l1l_opy_) for l1lll1_opy_, char in enumerate (l111_opy_)])
	else:
		l111ll_opy_ = str () .join ([chr (ord (char) - l11lll_opy_ - (l1lll1_opy_ + l1lll1l_opy_) % l1l1l_opy_) for l1lll1_opy_, char in enumerate (l111_opy_)])
	return eval (l111ll_opy_)
import xbmc
import xbmcaddon
import dixie
l1ll111ll_opy_ = l1ll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡲࡧࡲࡵࡪࡸࡦࠬࣙ")
import os
import sys
try:
    addon = xbmcaddon.Addon(id = l1ll111ll_opy_)
    path  = addon.getAddonInfo(l1ll11_opy_ (u"ࠬࡶࡡࡵࡪࠪࣚ"))
    sys.path.insert(0, path)
    import api
except: pass
PATH = os.path.join(dixie.PROFILE, l1ll11_opy_ (u"࠭ࡳࡩࡶࡨࡱࡵ࠭ࣛ"))
def createINI():
    api.login()
    HOME = dixie.PROFILE
    PATH = os.path.join(HOME, l1ll11_opy_ (u"ࠧࡪࡰ࡬ࠫࣜ"))
    l1l1_opy_ = l1ll11_opy_ (u"ࠨࡵࡰࡥࡷࡺࡨࡶࡤ࠱࡭ࡳ࡯ࠧࣝ")
    l1l_opy_  = os.path.join(PATH, l1l1_opy_)
    response = api.remote_call( l1ll11_opy_ (u"ࠤࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶ࠳ࡱ࡯ࡳࡵ࠰ࡳ࡬ࡵࠨࣞ") , {l1ll11_opy_ (u"ࠪࡥࠬࣟ"): l1ll11_opy_ (u"ࠫ࠵࠭࣠"), l1ll11_opy_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭࣡"): l1ll11_opy_ (u"࠭ࡡ࡭࡮ࠪ࣢")} )
    l11111_opy_ = response[l1ll11_opy_ (u"ࠧࡣࡱࡧࡽࣣࠬ")]
    l1l111l_opy_  = l1ll11_opy_ (u"ࠨ࡝ࠪࣤ") + l1ll111ll_opy_ + l1ll11_opy_ (u"ࠩࡠࡠࡳ࠭ࣥ")
    l1ll_opy_  =  file(l1l_opy_, l1ll11_opy_ (u"ࠪࡻࣦࠬ"))
    l1ll_opy_.write(l1l111l_opy_)
    l1ll1l1_opy_ = []
    for channel in l11111_opy_:
        category =  channel[l1ll11_opy_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ࣧ")]
        category = l1ll11_opy_ (u"ࠬ࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰ࠤࠬࣨ") + category + l1ll11_opy_ (u"࠭ࠠ࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲ࡃࣩࠧ")
        l1llll_opy_    =  channel[l1ll11_opy_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭࣪")]
        l1l11l1_opy_ =  dixie.mapChannelName(l1llll_opy_)
        stream   = l1ll11_opy_ (u"ࠨࡊࡇࡘ࡛ࡀࠧ࣫") + l1llll_opy_
        l1l11ll_opy_  =  l1l11l1_opy_ + l1ll11_opy_ (u"ࠩࡀࠫ࣬") + stream
        if category not in l1ll1l1_opy_:
            l1ll1l1_opy_.append(category)
        if l1l11ll_opy_ not in l1ll1l1_opy_:
            l1ll1l1_opy_.append(l1l11ll_opy_)
    l1ll1l1_opy_.append(l1ll11_opy_ (u"ࠪࡘ࡛ࠦ࠳ࠡࡆࡎࡁࡍࡊࡔࡗ࠼ࡗ࡚ࠥ࠹ࠠࡅࡍ࣭ࠪ"))
    l1ll1l1_opy_.append(l1ll11_opy_ (u"࡙ࠫ࡜ࠠ࠵ࠢࡇࡏࡂࡎࡄࡕࡘ࠽ࡘ࡛ࠦ࠴ࠡࡆࡎ࣮ࠫ"))
    l1ll1l1_opy_.append(l1ll11_opy_ (u"࡚ࠬࡖࠡ࠵ࠣࡗࡊࡃࡈࡅࡖ࡙࠾࡙࡜ࠠ࠴ࠢࡖࡉ࣯ࠬ"))
    l1ll1l1_opy_.append(l1ll11_opy_ (u"࠭ࡔࡗࠢ࠷ࠤࡘࡋ࠽ࡉࡆࡗ࡚࠿࡚ࡖࠡ࠶ࠣࡗࡊࣰ࠭"))
    for item in l1ll1l1_opy_:
        l1ll_opy_.write(l1ll11_opy_ (u"ࠢࠦࡵ࡟ࡲࣱࠧ") % item)
    l1ll_opy_.close()
def getURL(url):
    if (url.startswith(l1ll11_opy_ (u"ࠨࡊࡇࡘ࡛࠸࠺ࠨࣲ"))) or (url.startswith(l1ll11_opy_ (u"ࠩࡋࡈ࡙࡜࠳࠻ࠩࣳ"))):
        dixie.log(l1ll11_opy_ (u"ࠪ࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰ࠤࡗ࡛࡙ࡂࠢ࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯ࠪࣴ"))
        import hdtv
        return hdtv.getURL(url)
    api.login()
    channel   = url.split(l1ll11_opy_ (u"ࠫ࠿࠭ࣵ"), 1)[-1]
    l1ll111l1_opy_ = l1ll1111l_opy_(channel)
    response  = api.remote_call( l1ll11_opy_ (u"ࠧࡹࡴࡳࡧࡤࡱ࠴࡭ࡥࡵ࠰ࡳ࡬ࡵࠨࣶ") , { l1ll11_opy_ (u"ࠨࡴࠣࣷ") : l1ll11_opy_ (u"ࠢࡤࡪࡤࡲࡳ࡫࡬ࠣࣸ") , l1ll11_opy_ (u"ࠣ࡫ࡧࣹࠦ") : l1ll111l1_opy_ } )
    return response[l1ll11_opy_ (u"ࠤࡥࡳࡩࡿࣺࠢ")][l1ll11_opy_ (u"ࠥࡹࡷࡲࠢࣻ")]
def l1ll1111l_opy_(channel):
    response = api.remote_call( l1ll11_opy_ (u"ࠦࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠵࡬ࡪࡵࡷ࠲ࡵ࡮ࡰࠣࣼ") , {l1ll11_opy_ (u"ࠬࡧࠧࣽ"): l1ll11_opy_ (u"࠭࠰ࠨࣾ"), l1ll11_opy_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨࣿ"): l1ll11_opy_ (u"ࠨࡣ࡯ࡰࠬऀ")} )
    items = response[l1ll11_opy_ (u"ࠤࡥࡳࡩࡿࠢँ")]
    for item in items:
        if channel == item[l1ll11_opy_ (u"ࠥࡸ࡮ࡺ࡬ࡦࠤं")]:
            return item[l1ll11_opy_ (u"ࠦ࡮ࡪࠢः")]