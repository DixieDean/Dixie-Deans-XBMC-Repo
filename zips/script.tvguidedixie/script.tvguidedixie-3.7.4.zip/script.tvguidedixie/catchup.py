# coding: UTF-8
import sys
l1l1l1_opy_ = sys.version_info [0] == 2
l11ll1_opy_ = 2048
l1l11_opy_ = 7
def l1ll1l_opy_ (ll_opy_):
	global l1l11l_opy_
	l1l1l_opy_ = ord (ll_opy_ [-1])
	l1l1l11_opy_ = ll_opy_ [:-1]
	l1ll_opy_ = l1l1l_opy_ % len (l1l1l11_opy_)
	l1l1_opy_ = l1l1l11_opy_ [:l1ll_opy_] + l1l1l11_opy_ [l1ll_opy_:]
	if l1l1l1_opy_:
		l1111l_opy_ = unicode () .join ([unichr (ord (char) - l11ll1_opy_ - (l1111_opy_ + l1l1l_opy_) % l1l11_opy_) for l1111_opy_, char in enumerate (l1l1_opy_)])
	else:
		l1111l_opy_ = str () .join ([chr (ord (char) - l11ll1_opy_ - (l1111_opy_ + l1l1l_opy_) % l1l11_opy_) for l1111_opy_, char in enumerate (l1l1_opy_)])
	return eval (l1111l_opy_)
import xbmc
import xbmcgui
import xbmcaddon
import json
import datetime
import os
import dixie
try:
    import sys
    l111l1_opy_ = xbmcaddon.Addon(id=l1ll1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡲࡧࡲࡵࡪࡸࡦࠬࠀ"))
    path  = l111l1_opy_.getAddonInfo(l1ll1l_opy_ (u"ࠬࡶࡡࡵࡪࠪࠁ"))
    sys.path.insert(0, path)
    import api
except: pass
l1l111l_opy_   = l1ll1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲࡩࡶࡺ࠱ࡸࡻ࠭ࠂ")
l111ll_opy_ = l1ll1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡵࡴࡨࡥࡲࡹࡥࡢࡵࡼ࠲ࡹࡼࠧࠃ")
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
def isValid(stream):
    if l1ll1l_opy_ (u"ࠨࡊࡇࡘ࡛ࡀࠧࠄ") in stream:
        return True
    if l1l111l_opy_ in stream:
        return True
    if l111ll_opy_ in stream:
        return True
    return False
def getRecording(name, title, start, stream):
    if l1ll1l_opy_ (u"ࠩࡋࡈ࡙࡜࠺ࠨࠅ") in stream:
        dixie.log(l1ll1l_opy_ (u"ࠪ࠱࠲࠳ࠠࡉࡆࡗ࡚࠿ࠦࡩ࡯ࠢࡶࡸࡷ࡫ࡡ࡮ࠢ࠰࠱࠲࠭ࠆ"))
        return getHDTVRecording(name, title, start, stream)
    if l1l111l_opy_ in stream:
        dixie.log(l1ll1l_opy_ (u"ࠫ࠲࠳࠭ࠡࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡭࡫ࡸࡼ࠳ࡺࡶࠡ࡫ࡱࠤࡸࡺࡲࡦࡣࡰࠤ࠲࠳࠭ࠨࠇ"))
        addon = l1l111l_opy_
        return l11_opy_(addon, name, title, start, stream)
    if l111ll_opy_ in stream:
        dixie.log(l1ll1l_opy_ (u"ࠬ࠳࠭࠮ࠢࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮࡬ࡹࡽ࠴ࡴࡷࠢ࡬ࡲࠥࡹࡴࡳࡧࡤࡱࠥ࠳࠭࠮ࠩࠈ"))
        addon = l111ll_opy_
        return l11_opy_(addon, name, title, start, stream)
def l11_opy_(addon, name, title, start, stream):
    import time
    dixie.log(l1ll1l_opy_ (u"࠭࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࠢࡆࡅ࡙ࡉࡈࠡࡗࡓࠤࡑ࡞ࡔࡗࠢࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤ࠭ࠉ"))
    dixie.log(l1ll1l_opy_ (u"ࠧࡆࡒࡊࠤࡘࡺࡡࡳࡶࠣࡘ࡮ࡳࡥ࠯࠰࠱࠾ࠥࠫࡳࠨࠊ") % start)
    dixie.log(title)
    l11lll_opy_ = stream.split(l1ll1l_opy_ (u"ࠨࡾࠪࠋ"))
    for url in l11lll_opy_:
        if l1l111l_opy_ or l111ll_opy_ in url:
            l1l1ll_opy_ = url.split(CLOSE_OTT)[0].replace(OPEN_OTT, l1ll1l_opy_ (u"ࠩࠪࠌ"))
    l11l1l_opy_     = l11ll_opy_(l1l1ll_opy_)
    l1ll1_opy_ = str(start)
    l1ll111_opy_   = l1ll1_opy_.split(l1ll1l_opy_ (u"ࠪࠤࠬࠍ"))[0]
    l1ll1ll_opy_  = l1ll1_opy_.split(l1ll1l_opy_ (u"ࠫࠥ࠭ࠎ"))[1]
    l1ll11_opy_  = time.strptime(l1ll1ll_opy_,  l1ll1l_opy_ (u"ࠬࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠧࠏ"))
    l1ll11_opy_  = time.strftime(l1ll1l_opy_ (u"࠭ࠥࡊ࠼ࠨࡑࠥࠫࡰࠨࠐ"),  l1ll11_opy_)
    l1ll11l_opy_ = time.strptime(l1ll111_opy_,   l1ll1l_opy_ (u"࡛ࠧࠦ࠰ࠩࡲ࠳ࠥࡥࠩࠑ"))
    l1ll11l_opy_ = time.strftime(l1ll1l_opy_ (u"ࠨࠧࡄ࠰ࠥࠫࡂࠡࠧࡧࠫࠒ"), l1ll11l_opy_)
    query = l1ll1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠪࡹ࠯ࡀࡥ࡫ࡥࡳࡴࡥ࡭ࡡ࡬ࡨࡂࠫࡳࠧࡦࡤࡸࡪࡃࠥࡴࠨࡧࡥࡹ࡫࡟ࡵ࡫ࡷࡰࡪࡃࠥࡴࠨ࡬ࡱ࡬ࡃࠦ࡮ࡱࡧࡩࡂࡸࡥࡤࡱࡵࡨ࡮ࡴࡧࡴࠨࡷ࡭ࡹࡲࡥ࠾ࠧࡶࠫࠓ") % (addon, l11l1l_opy_, l1ll111_opy_, l1ll11l_opy_, l1l1ll_opy_)
    l1llll_opy_  = l1ll1l_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ࠔ") % query
    if not l11l1l_opy_:
        dixie.DialogOK(l1ll1l_opy_ (u"ࠫࡘࡵࡲࡳࡻ࠱ࠫࠕ"), l1ll1l_opy_ (u"ࠬ࡝ࡥࠡࡥࡲࡹࡱࡪࠠ࡯ࡱࡷࠤ࡫࡯࡮ࡥࠢࡤࠤࡨࡧࡴࡤࡪࡸࡴࠥࡹࡥࡳࡸ࡬ࡧࡪࠦࡦࡰࡴࠣࡸ࡭࡯ࡳࠡࡥ࡫ࡥࡳࡴࡥ࡭࠰ࠪࠖ"), l1ll1l_opy_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡴࡳࡻࠣࡥࡳࡵࡴࡩࡧࡵࠤࡨ࡮ࡡ࡯ࡰࡨࡰ࠳࠭ࠗ"))
        return None
    l11l11_opy_    = xbmc.executeJSONRPC(l1llll_opy_)
    response   = json.loads(l11l11_opy_)
    result     = response[l1ll1l_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧ࠘")]
    l11111_opy_ = result[l1ll1l_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧ࠙")]
    for l1l1ll1_opy_ in l11111_opy_:
        try:
            l1lll1_opy_ = l1l1ll1_opy_[l1ll1l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧࠚ")]
            l111l_opy_   = l1l1ll1_opy_[l1ll1l_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࠛ")]
            if l1ll11_opy_ in l111l_opy_:
                dixie.DialogOK(l1ll1l_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡴࡸࡡ࡯ࡩࡨࡡࡈࡧࡴࡤࡪ࠰ࡹࡵࠦࡳࡵࡴࡨࡥࡲࠦࡦࡰࡷࡱࡨ࠳ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࠜ"), l1ll1l_opy_ (u"ࠬࡕ࡮࠮ࡖࡤࡴࡵ࠴ࡔࡗࠢࡺ࡭ࡱࡲࠠ࡯ࡱࡺࠤࡵࡲࡡࡺ࠼ࠣ࡟ࡈࡕࡌࡐࡔࠣࡳࡷࡧ࡮ࡨࡧࡠ࡟ࡇࡣࠥࡴ࡝࠲ࡆࡢࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࠝ") % (title))
                return l1lll1_opy_
        except Exception, e:
            dixie.log(l1ll1l_opy_ (u"࠭ࡅࡓࡔࡒࡖ࠿ࠦࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡷ࡬ࡷࡵࡷ࡯ࠢ࡬ࡲࠥ࡭ࡥࡵࡎ࡛ࡘ࡛ࡘࡥࡤࡱࡵࡨ࡮ࡴࡧࠡࠧࡶࠫࠞ") % str(e))
            dixie.DialogOK(l1ll1l_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠴ࠧࠟ"), l1ll1l_opy_ (u"ࠨ࡙ࡨࠤࡨࡵࡵ࡭ࡦࠣࡲࡴࡺࠠࡧ࡫ࡱࡨࠥࡧࠠࡤࡣࡷࡧ࡭ࡻࡰࠡࡵࡷࡶࡪࡧ࡭ࠡࡨࡲࡶࠥࡺࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰ࠲ࠬࠠ"), l1ll1l_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡷࡶࡾࠦࡡࡨࡣ࡬ࡲࠥࡲࡡࡵࡧࡵ࠲ࠬࠡ"))
            return None
def l11ll_opy_(l1l1ll_opy_):
    l1l1ll_opy_ = l1l1ll_opy_.upper()
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪ࠷ࡊ࠭ࠢ") : return 188
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫࡆࡈࡃࠡࡇࡄࡗ࡙࠭ࠣ") : return 363
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠬࡇࡂࡄࠩࠤ") : return 346
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡁࡎࡅࠪࠥ") : return 375
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡂࡎࡌࡆࡎࠦࡉࡓࡇࡏࡅࡓࡊࠧࠦ") : return 280
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡃࡑࡍࡒࡇࡌࠡࡒࡏࡅࡓࡋࡔࠡࡗࡖࡅࠬࠧ") : return 386
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡄࡒࡎࡓࡁࡍࠢࡓࡐࡆࡔࡅࡕࠩࠨ") : return 19
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪࡅࡗࡋࡎࡂࠢࡖࡔࡔࡘࡔࡔࠢ࠴ࠤࡍࡊࠠࡄࡔࡒࡅ࡙ࡏࡁࠨࠩ") : return 403
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫࡆࡘࡅࡏࡃࠣࡗࡕࡕࡒࡕࡕࠣ࠶ࠥࡎࡄࠡࡅࡕࡓࡆ࡚ࡉࡂࠩࠪ") : return 404
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠬࡇࡒࡆࡐࡄࠤࡘࡖࡏࡓࡖࡖࠤ࠸ࠦࡈࡅࠢࡆࡖࡔࡇࡔࡊࡃࠪࠫ") : return 405
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡁࡓࡇࡑࡅ࡙ࠥࡐࡐࡔࡗࡗࠥ࠺ࠠࡉࡆࠣࡇࡗࡕࡁࡕࡋࡄࠫࠬ") : return 406
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡂࡔࡈࡒࡆࠦࡓࡑࡑࡕࡘࡘࠦ࠵ࠡࡕࡕࡆࠬ࠭") : return 407
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡃࡗࠤ࡙ࡎࡅࠡࡔࡄࡇࡊ࡙ࠧ࠮") : return 273
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡅࡆࡈࠦࡏࡏࡇ࡞ࡌࡉࡣࠧ࠯") : return 210
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪࡆࡇࡉࠠࡕ࡙ࡒ࡟ࡍࡊ࡝ࠨ࠰") : return 211
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫࡇࡋࡉࡏࠢࡖࡔࡔࡘࡔࠡ࠳࠳ࠤࡍࡊࠨࡕࡇࡖࡘ࠮࠭࠱") : return 300
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠬࡈࡅࡊࡐࠣࡗࡕࡕࡒࡕࠢ࠴࠵ࠥࡎࡄࠩࡖࡈࡗ࡙࠯ࠧ࠲") : return 389
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡂࡆࡋࡑࠤࡘࡖࡏࡓࡖࠣ࠵ࡍࡊࠨࡕࡇࡖࡘ࠮࠭࠳") : return 285
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡃࡇࡌࡒ࡙ࠥࡐࡐࡔࡗࠤ࠷ࠦࡈࡅࠪࡗࡉࡘ࡚ࠩࠨ࠴") : return 286
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡄࡈࡍࡓࠦࡓࡑࡑࡕࡘࠥ࠹ࠠࡉࡆࠫࡘࡊ࡙ࡔࠪࠩ࠵") : return 287
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡅࡉࡎࡔࠠࡔࡒࡒࡖ࡙ࠦ࠴ࠡࡊࡇ࡙ࠬࡋࡓࡕࠫࠪ࠶") : return 288
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪࡆࡊࡏࡎࠡࡕࡓࡓࡗ࡚ࠠ࠶ࠢࡋࡈ࡚࠭ࡅࡔࡖࠬࠫ࠷") : return 289
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫࡇࡋࡉࡏࠢࡖࡔࡔࡘࡔࠡ࠸ࠣࡌࡉ࠮ࡔࡆࡕࡗ࠭ࠬ࠸") : return 290
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠬࡈࡅࡊࡐࠣࡗࡕࡕࡒࡕࠢ࠺ࠤࡍࡊࠨࡕࡇࡖࡘ࠮࠭࠹") : return 291
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡂࡆࡋࡑࠤࡘࡖࡏࡓࡖࠣ࠼ࠥࡎࡄࠩࡖࡈࡗ࡙࠯ࠧ࠺") : return 292
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡃࡇࡌࡒ࡙ࠥࡐࡐࡔࡗࠤ࠾ࠦࡈࡅࠪࡗࡉࡘ࡚ࠩࠨ࠻") : return 293
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡄࡗࠤࡘࡖࡏࡓࡖࠣ࠵ࠥࡎࡄࠡࠪࡗࡉࡘ࡚ࠩࠨ࠼") : return 306
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡅࡘ࡙ࠥࡐࡐࡔࡗࠤ࠶࠭࠽") : return 17
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪࡆ࡙ࠦࡓࡑࡑࡕࡘࠥ࠸ࠠࡉࡆ࡙ࠣࠬࡋࡓࡕࠫࠪ࠾") : return 307
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫࡇ࡚ࠠࡔࡒࡒࡖ࡙ࠦ࠲ࠨ࠿") : return 18
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠬࡈࡔࠡࡕࡓࡓࡗ࡚ࠠࡆࡕࡓࡒࠬࡀ") : return 24
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡂࡕࠢࡖࡔࡔࡘࡔࠡࡇࡘࡖࡔࡖࡅࠨࡁ") : return 216
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡃࡃࡅ࡝࡚ࠥࡖࠨࡂ") : return 299
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡄࡏ࡙ࡊࠦࡈࡖࡕࡗࡐࡊࡘࠠࡆࡗࡕࡓࡕࡋࠧࡃ") : return 241
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡅࡓࡔࡓࡅࡓࡃࡑࡋࠬࡄ") : return 192
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪࡆࡔ࡞ࠠࡏࡃࡗࡍࡔࡔࠧࡅ") : return 185
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫࡇࡘࡉࡕࡋࡖࡌࠥࡋࡕࡓࡑࡖࡔࡔࡘࡔ࠳ࠩࡆ") : return 173
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠬࡈࡒࡊࡖࡌࡗࡍࠦࡅࡖࡔࡒࡗࡕࡕࡒࡕࠩࡇ") : return 182
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡃࡃࡕࠣࡖࡊࡇࡌࡊࡖ࡜ࠫࡈ") : return 190
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡄࡐࡅࡇࠬࡉ") : return 366
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡅࡑࡒࠬࡊ") : return 365
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡆࡅࡗ࡚ࡏࡐࡐࠣࡒࡊ࡚ࡗࡐࡔࡎࠤ࡚ࡑࠧࡋ") : return 186
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪࡇࡆࡘࡔࡐࡑࡑࡍ࡙ࡕࠧࡌ") : return 250
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫࡈࡎࡅࡍࡕࡈࡅ࡚ࠥࡖࠨࡍ") : return 179
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠬࡉࡏࡎࡇࡇ࡝ࠥࡉࡅࡏࡖࡕࡅࡑࠦࡕࡔࡃࠪࡎ") : return 374
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡃࡐࡏࡈࡈ࡞ࠦࡃࡆࡐࡗࡖࡆࡒࠧࡏ") : return 251
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡄࡑࡐࡉࡉ࡟࡙ࠠࡖࡕࡅࠬࡐ") : return 176
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡅࡕࡍࡒࡋࠠࡊࡐ࡙ࡉࡘ࡚ࡉࡈࡃࡗࡍࡔࡔࠧࡑ") : return 249
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡇࡅ࡛ࡋࠧࡒ") : return 230
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪࡈࡎ࡙ࡃࡐࡘࡈࡖ࡞ࠦࡈࡊࡕࡗࡓࡗ࡟ࠧࡓ") : return 20
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫࡉࡏࡓࡄࡑ࡙ࡉࡗ࡟ࠠࡔࡅࡌࡉࡓࡉࡅࠨࡔ") : return 103
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠬࡊࡉࡔࡅࡒ࡚ࡊࡘ࡙ࠡࡖࡘࡖࡇࡕࠧࡕ") : return 102
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡄࡊࡕࡆࡓ࡛ࡋࡒ࡚࠳ࠪࡖ") : return 98
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡅࡋࡖࡇࡔ࡜ࡅࡓ࡛ࠪࡗ") : return 370
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡆࡌࡗࡓࡋ࡙ࡄࡊࡑࡐࠬࡘ") : return 117
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡇࡍࡘࡔࡅ࡚ࡌࡘࡒࡎࡕࡒࠨ࡙") : return 118
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪࡉࡘࡖࡎࠡ࠴࡚ࠪ") : return 349
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫࡊ࡙ࡐࡏ࡛ࠩ") : return 348
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠬࡋࡄࡆࡐࠣ࠯࠶࠭࡜") : return 278
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡅࡊࡔࠣࡗࡕࡕࡒࡕࡕࠪ࡝") : return 30
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡆࡗࡕࡓࡓࡋࡗࡔࠩ࡞") : return 398
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡈࡒ࡜࡙ࠥࡐࡐࡔࡗࡗࠥ࠷ࠧ࡟") : return 352
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡉࡓ࡝ࠦࡎࡆ࡙ࡖࠫࡠ") : return 274
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪࡋࡔࡒࡄࠡࡗࡎࠫࡡ") : return 277
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫࡍ࠸ࠠࡖࡍࠪࡢ") : return 271
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠬࡎࡂࡐࠢࡈࡅࡘ࡚ࠧࡣ") : return 376
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡈࡃࡑࠣࡊࡆࡓࡉࡍ࡛ࠪࡤ") : return 377
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡉࡄࡒࠤࡘࡏࡇࡏࡃࡗ࡙ࡗࡋࠧࡥ") : return 378
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡊࡅࡓࠥࡠࡏࡏࡇࠪࡦ") : return 379
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡋࡋ࡙࡜ࠧࡧ") : return 384
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪࡌࡎ࡙ࡔࡐࡔ࡜ࠤ࡚ࡑࠧࡨ") : return 268
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫࡍࡏࡓࡕࡑࡕ࡝࡛ࠥࡓࡂࠩࡩ") : return 369
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠬࡎࡏࡎࡇࠣ࠯࠶࠭ࡪ") : return 279
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡈࡐࡔࡕࡓࡗࠦࡃࡉࡃࡑࡒࡊࡒࠠࡖࡍࠪ࡫") : return 183
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡊࡆ࡙ࠣࡐ࠭࡬") : return 229
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡋࡗ࡚ࠥ࠸ࠧ࡭") : return 208
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡌࡘ࡛ࠦ࠳ࠨ࡮") : return 207
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪࡍ࡙࡜ࠠ࠵ࠩ࡯") : return 209
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫࡎ࡚ࡖࠨࡰ") : return 206
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠬࡒࡆࡄࠢࡗ࡚ࠬࡱ") : return 180
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡍࡊࡑࠣࡗ࡙ࡇࡄࡊࡗࡐࠤ࠶࠶࠲ࠡࡊࡇࠫࡲ") : return 334
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡎࡋࡒࠤࡘ࡚ࡁࡅࡋࡘࡑࠥ࠷࠰࠴ࠢࡋࡈࠬࡳ") : return 335
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡏࡌࡓ࡙ࠥࡔࡂࡆࡌ࡙ࡒࠦ࠱࠱࠶ࠣࡌࡉ࠭ࡴ") : return 336
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡐࡍࡔࠦࡓࡕࡃࡇࡍ࡚ࡓࠠ࠲࠲࠸ࠤࡍࡊࠧࡵ") : return 337
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪࡑࡎࡕࠠࡔࡖࡄࡈࡎ࡛ࡍࠡ࠳࠳࠺ࠥࡎࡄࠨࡶ") : return 338
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫࡒࡏࡏࠡࡕࡗࡅࡉࡏࡕࡎࠢ࠴࠴࠼ࠦࡈࡅࠩࡷ") : return 333
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠬࡓࡔࡗࠢࡅࡅࡘࡋࠧࡸ") : return 132
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡍࡕࡘࠣࡈࡆࡔࡃࡆࠩࡹ") : return 131
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡎࡖ࡙ࠤࡍࡏࡔࡔࠣࠪࡺ") : return 135
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡏࡗ࡚ࠥࡓࡕࡔࡋࡆࠫࡻ") : return 217
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡐࡘ࡛ࠦࡒࡐࡅࡎࡗࠬࡼ") : return 133
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪࡑ࡚࡚ࡖࠨࡽ") : return 106
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫࡒࡕࡔࡐࡔࡖࠤ࡚ࡑࠧࡾ") : return 215
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠬࡔࡂࡂࠩࡿ") : return 283
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡎࡃࡅࠣࡉࡆ࡙ࡔࠨࢀ") : return 361
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡏࡋࡆࡏ࡚ࠥࡏࡐࡐࡖࠫࢁ") : return 296
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡐࡄࡘࠥࡍࡅࡐ࡚ࠢࡍࡑࡊࠠࡖࡍࠪࢂ") : return 269
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡑࡅ࡙ࡏࡏࡏࡃࡏࠤࡌࡋࡏࡈࡔࡄࡔࡍࡏࡃࠡࡗࡎࠫࢃ") : return 270
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪࡒࡆ࡚ࡉࡐࡐࡄࡐࠥࡍࡅࡐࡉࡕࡅࡕࡎࡉࡄࠢࡘࡗࡆ࠭ࢄ") : return 371
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫࡓࡏࡃࡌࠢࡍ࡙ࡓࡏࡏࡓࠩࢅ") : return 297
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠬࡔࡉࡄࡍ࡙ࠣࡐ࠭ࢆ") : return 295
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡐࡓࡇࡐࡍࡊࡘࡓࡑࡑࡕࡘࡘ࠭ࢇ") : return 29
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡓࡖࡈࠤࡔࡔࡅࠨ࢈") : return 69
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡔࡗࡉ࡚ࠥࡗࡐ࡝ࡋࡈࡢ࠭ࢉ") : return 70
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡕࡘࡊࡐࡒࠨࢊ") : return 89
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪࡖࡆࡉࡉࡏࡉ࡙ࠣࡐ࠭ࢋ") : return 26
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫࡗࡋࡁࡍࠢࡏࡍ࡛ࡋࡓࠨࢌ") : return 275
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࡙ࠬࡋ࡚ࠢࡅ࡙ࡓࡊࡅࡔࡎࡌࡋࡆࠦ࠱ࠡࡊࡇ࡟ࡉࡋ࡝ࠨࢍ") : return 408
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡓࡌ࡛ࠣࡒࡊ࡝ࡓࠨࢎ") : return 263
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡔࡍ࡜ࠤ࠶࠭࢏") : return 177
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡕࡎ࡝ࠥ࠸ࠧ࢐") : return 178
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡖࡏ࡞ࠦࡁࡄࡖࡌࡓࡓࠦࡍࡐࡘࡌࡉࡘ࠭࢑") : return 16
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪࡗࡐ࡟ࠠࡂࡖࡏࡅࡓ࡚ࡉࡄࠩ࢒") : return 174
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫࡘࡑ࡙ࠡࡅࡒࡑࡊࡊ࡙ࠡࡏࡒ࡚ࡎࡋࡓࠨ࢓") : return 34
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࡙ࠬࡋ࡚ࠢࡇࡖࡆࡓࡁࡓࡑࡐࠤࡒࡕࡖࡊࡇࡖࠫ࢔") : return 97
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡓࡌ࡛ࠣࡊࡆࡓࡉࡍ࡛ࠣࡑࡔ࡜ࡉࡆࡕࠪ࢕") : return 36
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡔࡍ࡜ࠤࡌࡘࡅࡂࡖࡖࠤࡒࡕࡖࡊࡇࡖࠫ࢖") : return 37
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡕࡎ࡝ࠥࡓࡏࡗࡋࡈࡗࠥࡊࡉࡔࡐࡈ࡝ࠬࢗ") : return 220
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡖࡏ࡞ࠦࡐࡓࡇࡐࡍࡊࡘࡅࠡࡏࡒ࡚ࡎࡋࡓࠨ࢘") : return 40
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪࡗࡐ࡟ࠠࡔࡅࡉࡍࡍࡕࡒࡓࡑࡕࠤࡒࡕࡖࡊࡇࡖ࢙ࠫ") : return 41
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫࡘࡑ࡙ࠡࡕࡈࡐࡊࡉࡔࠡࡏࡒ࡚ࡎࡋࡓࠨ࢚") : return 42
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࡙ࠬࡋ࡚ࠢࡖࡔࠥࡔࡅࡘࡕࠣࡌࡖ࢛࠭") : return 175
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡓࡌ࡛ࠣࡗࡕࡕࡒࡕࠢ࠴ࠤࡍࡊࠠࠩࡖࡈࡗ࡙࠯ࠧ࢜") : return 301
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡔࡍ࡜ࠤࡘࡖࡏࡓࡖࠣ࠶ࠥࡎࡄࠡࠪࡗࡉࡘ࡚ࠩࠨ࢝") : return 302
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡕࡎ࡝࡙ࠥࡐࡐࡔࡗࠤ࠸ࠦࡈࡅࠢࠫࡘࡊ࡙ࡔࠪࠩ࢞") : return 303
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡖࡏ࡞ࠦࡓࡑࡑࡕࡘࠥ࠺ࠠࡉࡆ࡙ࠣࠬࡋࡓࡕࠫࠪ࢟") : return 304
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪࡗࡐ࡟ࠠࡔࡒࡒࡖ࡙ࠦ࠵ࠡࡊࡇࠤ࡚࠭ࡅࡔࡖࠬࠫࢠ") : return 305
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫࡘࡑ࡙ࠡࡕࡓࡓࡗ࡚ࡓࠡ࠳ࠪࢡ") : return 95
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࡙ࠬࡋ࡚ࠢࡖࡔࡔࡘࡔࡔࠢ࠵ࠫࢢ") : return 136
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡓࡌ࡛ࠣࡗࡕࡕࡒࡕࡕࠣ࠷ࠬࢣ") : return 43
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡔࡍ࡜ࠤࡘࡖࡏࡓࡖࡖࠤ࠹࠭ࢤ") : return 119
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡕࡎ࡝࡙ࠥࡐࡐࡔࡗࡗࠥ࠻ࠧࢥ") : return 120
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡖࡏ࡞ࠦࡔࡉࡔࡌࡐࡑࡋࡒࠡࡏࡒ࡚ࡎࡋࡓࠨࢦ") : return 96
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪࡗࡐ࡟ࠠࡍࡋ࡙ࡍࡓࡍࠧࢧ") : return 298
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫࡘࡖࡏࡓࡖࡖࠤࡋ࠷ࠧࢨ") : return 45
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࡙࡙ࠬࡇ࡛࡙ࠣࡘࡇࠧࢩ") : return 383
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡔࡄࡏࠣ࠯࠶ࠦࡕࡌࠩࢪ") : return 189
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡕࡉ࠷ࠫࢫ") : return 88
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡖࡖࡒࠥ࠷ࠧࢬ") : return 339
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡗࡗࡓࠦ࠲ࠨࢭ") : return 340
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪࡘࡘࡔࠠ࠴ࠩࢮ") : return 341
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࡙࡙ࠫࡎࠡ࠶ࠪࢯ") : return 342
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࡚ࠬࡓࡏࠢ࠸ࠫࢰ") : return 343
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡔࡗ࠵ࠣࡍࡊ࠭ࢱ") : return 87
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠧࡕࡔࡄ࡚ࡊࡒࠠࡄࡊࡄࡒࡓࡋࡌࠬ࠳࡙ࠣࡐ࠭ࢲ") : return 184
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨࡗࡖࡅࠥࡌࡏ࡙ࠢࡖࡔࡔࡘࡔࡔࠩࢳ") : return 347
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠩࡘࡗࡆࠦࡎࡆࡖ࡚ࡓࡗࡑࠧࢴ") : return 344
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࡙࡙ࠪ࡜ࠠࡊࡇࠪࢵ") : return 272
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࡛ࠫࡏࡖࡂࠢࡗࡌࡊࠦࡈࡊࡖࡖࠥࠬࢶ") : return 130
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠬ࡜ࡉࡂࡕࡄࡘࠥࡍࡏࡍࡈࠪࢷ") : return 125
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡗࡂࡖࡆࡌࠥࡏࡒࡆࡎࡄࡒࡉ࠭ࢸ") : return 281
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࡙࡚࡛ࠧ࠵ࠬࢹ") : return 314
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠨ࡚࡛࡜࠷࠭ࢺ") : return 315
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࡛ࠩ࡜࡝࠹ࠧࢻ") : return 316
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠪ࡜࡝࡞࠴ࠨࢼ") : return 317
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠫ࡝࡞ࡘ࠶ࠩࢽ") : return 318
    if l1l1ll_opy_ == l1ll1l_opy_ (u"ࠬ࡟ࡅࡔࡖࡈࡖࡉࡇ࡙ࠡ࠭࠴ࠫࢾ") : return 282
    if l1l1ll_opy_ == l1ll1l_opy_ (u"࠭ࡍࡐࡘ࠷ࡑࡊࡔ࠱ࠨࢿ") : return 33
def getHDTVRecording(name, title, start, stream):
    l1lll_opy_ = l111l1_opy_.getSetting(l1ll1l_opy_ (u"ࠧࡴࡧࡶࡷ࡮ࡵ࡮ࠨࣀ"))
    l1l1lll_opy_  = l111l1_opy_.getSetting(l1ll1l_opy_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࠨࣁ"))
    l1lll1l_opy_    = l1ll1l_opy_ (u"ࠩࠩࡨࡂࡱ࡯ࡥ࡫ࠩࡷࡂ࠭ࣂ") + l1lll_opy_ + l1ll1l_opy_ (u"ࠪࠪࡴࡃࠧࣃ") + l1l1lll_opy_
    dixie.log(l1ll1l_opy_ (u"ࠫࡤࡥ࡟ࡠࡡࡢࡣࡤࡥࠠࡄࡃࡗࡇࡍࠦࡕࡑࠢࡋࡈ࡙࡜ࠠࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࠫࣄ"))
    dixie.log(name)
    dixie.log(title)
    dixie.log(start)
    dixie.log(stream)
    import urllib
    l1llll1_opy_ = l1l111_opy_()
    dixie.log(l1ll1l_opy_ (u"ࠬࡋࡐࡈࠢࡖࡸࡦࡸࡴࠡࡖ࡬ࡱࡪ࠴࠮࠯࠼ࠣࠩࡸ࠭ࣅ") % start)
    dixie.log(l1ll1l_opy_ (u"࠭ࡏࡧࡨࡶࡩࡹࠦࡩ࡯ࠢࡶࡩࡨࡵ࡮ࡥࡵ࠽ࠤࠪࡹࠧࣆ") % l1llll1_opy_)
    l1l1l1l_opy_  =  start - datetime.timedelta(seconds=l1llll1_opy_)
    dixie.log(l1ll1l_opy_ (u"ࠧࡔࡶࡤࡶࡹࠦࡔࡪ࡯ࡨࠤࡴ࡬ࡦࡴࡧࡷ࠾ࠥࠫࡳࠨࣇ") % l1l1l1l_opy_)
    l1ll1_opy_ = str(l1l1l1l_opy_)
    l1l11l1_opy_  = l1ll1_opy_.split(l1ll1l_opy_ (u"ࠨࠢࠪࣈ"))[0]
    l1ll1l1_opy_     = l1l11ll_opy_(name)
    if not l1ll1l1_opy_:
        dixie.DialogOK(l1ll1l_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠯ࠩࣉ"), l1ll1l_opy_ (u"࡛ࠪࡪࠦࡣࡰࡷ࡯ࡨࠥࡴ࡯ࡵࠢࡩ࡭ࡳࡪࠠࡢࠢࡦࡥࡹࡩࡨࡶࡲࠣࡷࡪࡸࡶࡪࡥࡨࠤ࡫ࡵࡲࠡࡶ࡫࡭ࡸࠦࡣࡩࡣࡱࡲࡪࡲ࠮ࠨ࣊"), l1ll1l_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡹࡸࡹࠡࡣࡱࡳࡹ࡮ࡥࡳࠢࡦ࡬ࡦࡴ࡮ࡦ࡮࠱ࠫ࣋"))
        return None
    l1lllll_opy_  = l1ll1_opy_.split(l1ll1l_opy_ (u"ࠬ࠳ࠧ࣌"), 1)[-1].rsplit(l1ll1l_opy_ (u"࠭࠺ࠨ࣍"), 1)[0]
    l11l_opy_    = urllib.quote_plus(l1lllll_opy_)
    response   = api.remote_call( l1ll1l_opy_ (u"ࠢࡵࡸࡤࡶࡨ࡮ࡩࡷࡧ࠲࡫ࡪࡺ࡟ࡣࡻࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡣࡦࡴࡤࡠࡦࡤࡸࡪ࠴ࡰࡩࡲࠥ࣎") , {l1ll1l_opy_ (u"ࠣࡦࡤࡸࡪࠨ࣏"): l1l11l1_opy_, l1ll1l_opy_ (u"ࠤ࡬ࡨ࣐ࠧ"): l1ll1l1_opy_ } )
    l11111_opy_ = response[l1ll1l_opy_ (u"ࠥࡦࡴࡪࡹ࣑ࠣ")]
    if not l11111_opy_:
        dixie.DialogOK(l1ll1l_opy_ (u"ࠫࡘࡵࡲࡳࡻ࠱࣒ࠫ"), l1ll1l_opy_ (u"ࠬ࡝ࡥࠡࡥࡲࡹࡱࡪࠠ࡯ࡱࡷࠤ࡫࡯࡮ࡥࠢࡤࠤࡨࡧࡴࡤࡪࡸࡴࠥࡹࡴࡳࡧࡤࡱࠥ࡬࡯ࡳࠢࡷ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭࠯࣓ࠩ"), l1ll1l_opy_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡴࡳࡻࠣࡥ࡬ࡧࡩ࡯ࠢ࡯ࡥࡹ࡫ࡲ࠯ࠩࣔ"))
        return None
    for l1l1ll1_opy_ in l11111_opy_:
        l1lll1_opy_ = l1l1ll1_opy_[l1ll1l_opy_ (u"ࠢࡱ࡮ࡲࡸࠧࣕ")]
        if l1lllll_opy_ in l1lll1_opy_:
            dixie.DialogOK(l1ll1l_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡱࡵࡥࡳ࡭ࡥ࡞ࡅࡤࡸࡨ࡮࠭ࡶࡲࠣࡷࡹࡸࡥࡢ࡯ࠣࡪࡴࡻ࡮ࡥ࠰࡞࠳ࡈࡕࡌࡐࡔࡠࠫࣖ"), l1ll1l_opy_ (u"ࠩࡒࡲ࠲࡚ࡡࡱࡲ࠱ࡘ࡛ࠦࡷࡪ࡮࡯ࠤࡳࡵࡷࠡࡲ࡯ࡥࡾࡀࠠ࡜ࡅࡒࡐࡔࡘࠠࡰࡴࡤࡲ࡬࡫࡝࡜ࡄࡠࠩࡸࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫࣗ") % (title))
            return l1l1ll1_opy_[l1ll1l_opy_ (u"ࠥࡹࡷࡲࠢࣘ")] + l1lll1l_opy_
def l1l11ll_opy_(name):
    l11l1_opy_   = dixie.PROFILE
    l1l_opy_ = os.path.join(l11l1_opy_, l1ll1l_opy_ (u"ࠫ࡮ࡴࡩࠨࣙ"), l1ll1l_opy_ (u"ࠬࡩࡡࡵࡥ࡫ࡹࡵ࠴ࡴࡹࡶࠪࣚ"))
    l1lll11_opy_   = json.load(open(l1l_opy_))
    for channel in l1lll11_opy_:
        if name.upper() == channel[l1ll1l_opy_ (u"࠭ࡏࡕࡖ࡙ࠫࣛ")].upper():
            return channel[l1ll1l_opy_ (u"ࠧࡖࡔࡏࠫࣜ")]
def l1l111_opy_():
    dixie.log(l1ll1l_opy_ (u"ࠨࡡࡢࡣࡤࡥ࡟ࠡࡉࡨࡸ࡚ࠥࡩ࡮ࡧࠣࡓ࡫࡬ࡳࡦࡶࠣࡣࡤࡥ࡟ࡠࡡࠪࣝ"))
    import time
    gmt = time.gmtime()
    loc = time.localtime()
    GMT = datetime.datetime(*gmt[:6]).isoformat(l1ll1l_opy_ (u"ࠩࠣࠫࣞ"))
    LOC = datetime.datetime(*loc[:6]).isoformat(l1ll1l_opy_ (u"ࠪࠤࠬࣟ"))
    dixie.log(gmt)
    dixie.log(loc)
    l1_opy_ = dixie.parseTime(GMT)
    l111_opy_ = dixie.parseTime(LOC)
    dixie.log(l1_opy_)
    dixie.log(l111_opy_)
    dixie.log(l1ll1l_opy_ (u"ࠫࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࠡࡑࡉࡊࡘࡋࡔࠡࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤ࠭࣠"))
    l1llll1_opy_ = l1_opy_ - l111_opy_
    dixie.log(l1llll1_opy_)
    l1llll1_opy_ = ((l1llll1_opy_.days * 86400) + (l1llll1_opy_.seconds + 1800)) / 3600
    dixie.log(l1llll1_opy_)
    l1llll1_opy_ *= -3600
    dixie.log(l1llll1_opy_)
    dixie.log(l1ll1l_opy_ (u"ࠬࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥࠧ࣡"))
    return l1llll1_opy_