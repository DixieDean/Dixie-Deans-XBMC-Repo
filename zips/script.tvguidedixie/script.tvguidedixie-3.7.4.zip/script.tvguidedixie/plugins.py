# coding: UTF-8
import sys
l1l1l1_opy_ = sys.version_info [0] == 2
l11ll1_opy_ = 2048
l1l11_opy_ = 7
def l1ll1l_opy_ (ll_opy_):
	global l1l11l_opy_
	l1l1l_opy_ = ord (ll_opy_ [-1])
	l1l1l11_opy_ = ll_opy_ [:-1]
	l1ll_opy_ = l1l1l_opy_ % len (l1l1l11_opy_)
	l1l1_opy_ = l1l1l11_opy_ [:l1ll_opy_] + l1l1l11_opy_ [l1ll_opy_:]
	if l1l1l1_opy_:
		l1111l_opy_ = unicode () .join ([unichr (ord (char) - l11ll1_opy_ - (l1111_opy_ + l1l1l_opy_) % l1l11_opy_) for l1111_opy_, char in enumerate (l1l1_opy_)])
	else:
		l1111l_opy_ = str () .join ([chr (ord (char) - l11ll1_opy_ - (l1111_opy_ + l1l1l_opy_) % l1l11_opy_) for l1111_opy_, char in enumerate (l1l1_opy_)])
	return eval (l1111l_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l11llll1l_opy_    = l1ll1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡲࡹࡼࠧᄩ")
l1l111l1l_opy_    = l1ll1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡶࡴ࡮ࠫᄪ")
locked = l1ll1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲ࡯ࡤ࡭ࡨࡨࡹࡼࠧᄫ")
l1l111111_opy_   = l1ll1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡵࡴࡨࡥࡲࡺࡶࡣࡱࡻࠫᄬ")
l11ll1111_opy_     = l1ll1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡲࡲࡶࡹࡹ࡭ࡢࡰ࡬ࡥࠬᄭ")
l1l11l11l_opy_     = l1ll1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡳࡳࡷࡺࡳ࡯ࡣࡷ࡭ࡴࡴࡨࡥࡶࡹࠫᄮ")
l11ll1l11_opy_     = l1ll1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸࡰࡹ࡯࡭ࡢࡶࡨࡱࡦࡴࡩࡢࠩᄯ")
l1l111l_opy_   = l1ll1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰ࡮ࡻࡸ࠯ࡶࡹࠫᄰ")
l11lll11l_opy_    = l1ll1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡉࡉࡓࡱࡱࡵࡸࡸ࠭ᄱ")
l1l111l11_opy_ = l1ll1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡥࡣࡱࡲࡸࠬᄲ")
l11lll1l1_opy_    = l1ll1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡣ࡭ࡷ࡬ࡴࡹࡼࠧᄳ")
l111ll_opy_ = l1ll1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡶࡵࡩࡦࡳࡳࡦࡣࡶࡽ࠳ࡺࡶࠨᄴ")
l1l1111l1_opy_ = l1ll1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࡯ࡰࡵࡸࠪᄵ")
l11l1llll_opy_ = [l11llll1l_opy_, l1l111l_opy_, l111ll_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1ll1l_opy_ (u"ࠪ࡭ࡳ࡯ࠧᄶ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l11111l_opy_ = l1ll1l_opy_ (u"ࠫࠬᄷ")
def l1lll111_opy_(i, t1, l111111_opy_=[]):
 t = l11111l_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l111111_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1llll11_opy_ = l1lll111_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l1lll1ll_opy_ = l1lll111_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l11l1llll_opy_:
        if l11ll111l_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l11ll111l_opy_(addon):
    if xbmc.getCondVisibility(l1ll1l_opy_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠦࡵࠬࠫᄸ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l11l111_opy_ = str(addon).split(l1ll1l_opy_ (u"࠭࠮ࠨᄹ"))[2] + l1ll1l_opy_ (u"ࠧ࠯࡫ࡱ࡭ࠬᄺ")
    l11l11l_opy_  = os.path.join(PATH, l11l111_opy_)
    try:
        l1lll11_opy_ = l1l11l1ll_opy_(addon)
    except KeyError:
        dixie.log(l1ll1l_opy_ (u"ࠨ࠯࠰࠱࠲࠳ࠠࡌࡧࡼࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥ࡭ࡥࡵࡈ࡬ࡰࡪࡹࠠ࠮࠯࠰࠱࠲ࠦࠧᄻ") + addon)
        result = {l1ll1l_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࡴࠩᄼ"): [{l1ll1l_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭ᄽ"): l1ll1l_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࠪᄾ"), l1ll1l_opy_ (u"ࡺ࠭ࡴࡺࡲࡨࠫᄿ"): l1ll1l_opy_ (u"ࡻࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨᅀ"), l1ll1l_opy_ (u"ࡵࠨࡨ࡬ࡰࡪ࠭ᅁ"): l1ll1l_opy_ (u"ࡶࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡽࡾࠧᅂ"), l1ll1l_opy_ (u"ࡷࠪࡰࡦࡨࡥ࡭ࠩᅃ"): l1ll1l_opy_ (u"ࡸࠫࡓࡕࠠࡄࡊࡄࡒࡓࡋࡌࡔࠩᅄ")}], l1ll1l_opy_ (u"ࡹࠬࡲࡩ࡮࡫ࡷࡷࠬᅅ"):{l1ll1l_opy_ (u"ࡺ࠭ࡳࡵࡣࡵࡸࠬᅆ"): 0, l1ll1l_opy_ (u"ࡻࠧࡵࡱࡷࡥࡱ࠭ᅇ"): 1, l1ll1l_opy_ (u"ࡵࠨࡧࡱࡨࠬᅈ"): 1}}
    l11l1l1_opy_  = file(l11l11l_opy_, l1ll1l_opy_ (u"ࠨࡹࠪᅉ"))
    l11l1l1_opy_.write(l1ll1l_opy_ (u"ࠩ࡞ࠫᅊ"))
    l11l1l1_opy_.write(addon)
    l11l1l1_opy_.write(l1ll1l_opy_ (u"ࠪࡡࠬᅋ"))
    l11l1l1_opy_.write(l1ll1l_opy_ (u"ࠫࡡࡴࠧᅌ"))
    l11lll1_opy_ = []
    for channel in l1lll11_opy_:
        l111l_opy_    = channel[l1ll1l_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫᅍ")]
        l111l_opy_    = l111l_opy_.replace(l1ll1l_opy_ (u"࠭ࠠࠡࠢࠣࠤࠬᅎ"), l1ll1l_opy_ (u"ࠧࠡࠩᅏ")).replace(l1ll1l_opy_ (u"ࠨ࠰࠱࠲࠳࠴ࠧᅐ"), l1ll1l_opy_ (u"ࠩࠪᅑ")).replace(l1ll1l_opy_ (u"ࠪ࠾ࠬᅒ"), l1ll1l_opy_ (u"ࠫࠬᅓ")).replace(l1ll1l_opy_ (u"࡛ࠬࠦࠨᅔ"), l1ll1l_opy_ (u"࡛࠭ࠨᅕ")).replace(l1ll1l_opy_ (u"ࠧ࡞ࠢࠪᅖ"), l1ll1l_opy_ (u"ࠨ࡟ࠪᅗ")).replace(l1ll1l_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡤࡵࡺࡧ࡝ࠨᅘ"), l1ll1l_opy_ (u"ࠪࠫᅙ")).replace(l1ll1l_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡱ࡯࡭ࡦࡩࡵࡩࡪࡴ࡝ࠨᅚ"), l1ll1l_opy_ (u"ࠬ࠭ᅛ")).replace(l1ll1l_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡧࡳࡧࡨࡲࡢ࠭ᅜ"), l1ll1l_opy_ (u"ࠧࠨᅝ")).replace(l1ll1l_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡻࡨࡰࡱࡵࡷ࡞ࠩᅞ"), l1ll1l_opy_ (u"ࠩࠪᅟ")).replace(l1ll1l_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞ࠩᅠ"), l1ll1l_opy_ (u"ࠫࠬᅡ")).replace(l1ll1l_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡵࡲࡢࡰࡪࡩࡢ࠭ᅢ"), l1ll1l_opy_ (u"࠭ࠧᅣ")).replace(l1ll1l_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࠬᅤ"), l1ll1l_opy_ (u"ࠨࠩᅥ")).replace(l1ll1l_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡺ࡬࡮ࡺࡥ࡞ࠩᅦ"), l1ll1l_opy_ (u"ࠪࠫᅧ")).replace(l1ll1l_opy_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᅨ"), l1ll1l_opy_ (u"ࠬ࠭ᅩ")).replace(l1ll1l_opy_ (u"࡛࠭ࡊ࡟ࠪᅪ"), l1ll1l_opy_ (u"ࠧࠨᅫ")).replace(l1ll1l_opy_ (u"ࠨ࡝࠲ࡍࡢ࠭ᅬ"), l1ll1l_opy_ (u"ࠩࠪᅭ")).replace(l1ll1l_opy_ (u"ࠪ࡟ࡇࡣࠧᅮ"), l1ll1l_opy_ (u"ࠫࠬᅯ")).replace(l1ll1l_opy_ (u"ࠬࡡ࠯ࡃ࡟ࠪᅰ"), l1ll1l_opy_ (u"࠭ࠧᅱ"))
        l11ll11_opy_ = dixie.mapChannelName(l111l_opy_)
        stream   = channel[l1ll1l_opy_ (u"ࠧࡧ࡫࡯ࡩࠬᅲ")]
        l111lll_opy_ = l11ll11_opy_ + l1ll1l_opy_ (u"ࠨ࠿ࠪᅳ") + stream
        l11lll1_opy_.append(l111lll_opy_)
        l11lll1_opy_.sort()
    for item in l11lll1_opy_:
        l11l1l1_opy_.write(l1ll1l_opy_ (u"ࠤࠨࡷࡡࡴࠢᅴ") % item)
    l11l1l1_opy_.close()
def l1l11l1ll_opy_(addon):
    if addon == l1l111l_opy_:
        return l11lll1ll_opy_(addon)
    l11ll1lll_opy_  = l1ll1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭ᅵ") + addon
    l1l1111ll_opy_ =  l1l11l1l1_opy_(addon)
    query   =  l11ll1lll_opy_ + l1l1111ll_opy_
    return sendJSON(query, addon)
def l11lll1ll_opy_(addon):
    l1l11111l_opy_ = [l1ll1l_opy_ (u"ࠫ࠺࠭ᅶ"), l1ll1l_opy_ (u"ࠬ࠷࠰࠷ࠩᅷ"), l1ll1l_opy_ (u"࠭࠴ࠨᅸ"), l1ll1l_opy_ (u"ࠧ࠳࠸࠶ࠫᅹ"), l1ll1l_opy_ (u"ࠨ࠳࠶࠶ࠬᅺ")]
    l111l1l_opy_ = []
    for l1l111ll1_opy_ in l1l11111l_opy_:
        l1llll_opy_  = l1ll1l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲࡩࡶࡺ࠱ࡸࡻ࠵࠿࡮ࡱࡧࡩࡤ࡯ࡤ࠾ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠩࡱࡴࡪࡥ࠾ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠩࡷࡪࡩࡴࡪࡱࡱࡣ࡮ࡪ࠽ࠦࡵࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨᅻ") % l1l111ll1_opy_
        l11l11_opy_  = xbmc.executeJSONRPC(l1llll_opy_)
        response = json.loads(l11l11_opy_)
        l111l1l_opy_.extend(response[l1ll1l_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪᅼ")][l1ll1l_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪᅽ")])
    return l111l1l_opy_
def sendJSON(query, addon):
    l1llll_opy_     = l1ll1l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࠦࡵࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨᅾ") % query
    l11l11_opy_  = xbmc.executeJSONRPC(l1llll_opy_)
    response = json.loads(l11l11_opy_)
    result   = response[l1ll1l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ᅿ")]
    return result[l1ll1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ᆀ")]
def l11llll11_opy_(addon):
    l11ll1lll_opy_ = l1ll1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫᆁ") + addon
    l11l1ll1l_opy_  = l1ll1l_opy_ (u"ࠩࡂࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁ࡭ࡺࡴࡱࠧ࠶ࡥࠪ࠸ࡦࠦ࠴ࡩࡱࡪࡺࡡ࡭࡭ࡨࡸࡹࡲࡥ࠯ࡥࡲࠩ࠷࡬ࡕࡌࡖࡸࡶࡰ࠷࠸࠱࠴࠵࠴࠶࠼ࠥ࠳ࡨࡷ࡬ࡺࡳࡢࡴࠧ࠵ࡪࡳ࡫ࡷࠦ࠴ࡩ࡙ࡰࠫ࠲࠶࠴࠳ࡸࡺࡸ࡫ࠦ࠴࠸࠶࠵ࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠧ࠵࠹࠷࠶࡬ࡪࡸࡨࠩ࠷࠻࠲࠱ࡶࡹ࠲࡯ࡶࡧࠧ࡯ࡲࡨࡪࡃ࠱ࠧࡰࡤࡱࡪࡃࡌࡪࡸࡨࠩ࠷࠶ࡔࡗࠨࡸࡶࡱࡃࡨࡵࡶࡳࠩ࠸ࡧࠥ࠳ࡨࠨ࠶࡫ࡳࡥࡵࡣ࡯࡯ࡪࡺࡴ࡭ࡧ࠱ࡧࡴࠫ࠲ࡧࡗࡎࡘࡺࡸ࡫࠲࠺࠳࠶࠷࠶࠱࠷ࠧ࠵ࡪࡑ࡯ࡶࡦࠧ࠵࠹࠷࠶ࡔࡗ࠰ࡷࡼࡹ࠭ᆂ")
    l111l1l_opy_  = []
    l111l1l_opy_ += sendJSON(l11ll1lll_opy_ + l11l1ll1l_opy_, addon)
    l111l1l_opy_.sort()
    return l111l1l_opy_
def l1l11l111_opy_(addon):
    l11ll1lll_opy_ = l1ll1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭ᆃ") + addon
    l11l1ll1l_opy_ = l1ll1l_opy_ (u"ࠫ࠴ࡅࡦࡢࡰࡤࡶࡹࡃࡨࡵࡶࡳࠩ࠸ࡧࠥ࠳ࡨࠨ࠶࡫࡭࡯ࡰ࠰ࡪࡰࠪ࠸ࡦ࡙ࡦࡉ࠶࠽࡚ࠦ࡮ࡱࡧࡩࡂ࠷ࠦ࡯ࡣࡰࡩࡂࡒࡩࡷࡧࠨ࠶࠵࡛ࡋࠦ࠴࠳ࡗࡵࡵࡲࡵࡵࠩࡹࡷࡲ࠽ࡩࡶࡷࡴࡸࠫ࠳ࡢࠧ࠵ࡪࠪ࠸ࡦࡨࡱࡲ࠲࡬ࡲࠥ࠳ࡨ࠸ࡵࡖ࡭ࡅ࠵ࠩᆄ")
    l11l1lll1_opy_ = l1ll1l_opy_ (u"ࠬ࠵࠿ࡧࡣࡱࡥࡷࡺ࠽ࡩࡶࡷࡴࡸࠫ࠳ࡢࠧ࠵ࡪࠪ࠸ࡦࡨࡱࡲ࠲࡬ࡲࠥ࠳ࡨࡉ࡫࡜ࡓ࡫࡛ࠨࡰࡳࡩ࡫࠽࠲ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡹࡩࠪ࠸࠰ࡖࡕࠨ࠶࡫ࡉࡁࡏࠧ࠵࠴ࡘࡶ࡯ࡳࡶࡶࠪࡺࡸ࡬࠾ࡪࡷࡸࡵࡹࠥ࠴ࡣࠨ࠶࡫ࠫ࠲ࡧࡩࡲࡳ࠳࡭࡬ࠦ࠴ࡩࡪ࠾ࡰࡧ࠹ࡐࠪᆅ")
    l111l1l_opy_  = []
    l111l1l_opy_ += sendJSON(l11ll1lll_opy_ + l11l1ll1l_opy_, addon)
    l111l1l_opy_ += sendJSON(l11ll1lll_opy_ + l11l1lll1_opy_, addon)
    return l111l1l_opy_
def l1l11l1l1_opy_(addon):
    if addon == l11llll1l_opy_:
        return l1ll1l_opy_ (u"࠭࠯ࡀࡥࡤࡸࡂ࠳࠲ࠧࡦࡤࡸࡪࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠪࡪࡴࡤࡅࡣࡷࡩࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡰࡳࡩ࡫࠽࠳ࠨࡱࡥࡲ࡫࠽ࡎࡻࠨ࠶࠵ࡉࡨࡢࡰࡱࡩࡱࡹࠦࡳࡧࡦࡳࡷࡪ࡮ࡢ࡯ࡨࠪࡸࡺࡡࡳࡶࡇࡥࡹ࡫ࠦࡶࡴ࡯ࡁࡺࡸ࡬ࠨᆆ")
    if addon == l1l1111l1_opy_:
        return l1ll1l_opy_ (u"ࠧ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿࡯࡭ࡻ࡫ࡴࡷࡡࡤࡰࡱࠬࡥࡹࡶࡵࡥࠫࡶࡡࡨࡧࠩࡴࡱࡵࡴࠧࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡁࠫࡺࡩࡵ࡮ࡨࡁࡆࡲ࡬ࠦ࠴࠳ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡻࡲ࡭ࠩᆇ")
    return l1ll1l_opy_ (u"ࠨࠩᆈ")
def l1llll1l_opy_():
    modules = map(__import__, [l1lll111_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1llll11_opy_)):
        return l1ll1l_opy_ (u"ࠩࡗࡶࡺ࡫ࠧᆉ")
    if len(modules[-1].Window(10**4).getProperty(l1lll1ll_opy_)):
        return l1ll1l_opy_ (u"ࠪࡘࡷࡻࡥࠨᆊ")
    return l1ll1l_opy_ (u"ࠫࡋࡧ࡬ࡴࡧࠪᆋ")
def l1lll1l1_opy_(e, addon):
    l1lllll1_opy_ = l1ll1l_opy_ (u"࡙ࠬ࡯ࡳࡴࡼ࠰ࠥࡧ࡮ࠡࡧࡵࡶࡴࡸࠠࡰࡥࡦࡹࡷ࡫ࡤ࠻ࠢࡍࡗࡔࡔࠠࡆࡴࡵࡳࡷࡀࠠࠦࡵ࠯ࠤࠪࡹࠧᆌ")  % (e, addon)
    l1llllll_opy_ = l1ll1l_opy_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡣࡰࡰࡷࡥࡨࡺࠠࡶࡵࠣࡳࡳࠦࡴࡩࡧࠣࡪࡴࡸࡵ࡮࠰ࠪᆍ")
    l1lll11l_opy_ = l1ll1l_opy_ (u"ࠧࡖࡲ࡯ࡳࡦࡪࠠࡢࠢ࡯ࡳ࡬ࠦࡶࡪࡣࠣࡸ࡭࡫ࠠࡢࡦࡧࡳࡳࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠡࡣࡱࡨࠥࡶ࡯ࡴࡶࠣࡸ࡭࡫ࠠ࡭࡫ࡱ࡯࠳࠭ᆎ")
    dixie.log(addon)
    dixie.log(e)
def getPlaylist():
    import requests
    l11lllll1_opy_ = [l1ll1l_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡺ࠱ࡧࡴ࠵ࡈࡆ࡜࠸࡞ࡾ࡯ࡊࡦ࡙ࠪᆏ"), l1ll1l_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡻ࠲ࡨࡵ࠯ࡹࡨ࠸ࡍ࠸ࡎࡏࡥ࡛ࡑࠫᆐ"), l1ll1l_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡼ࠳ࡩ࡯࠰ࡗࡏࡧ࠵࠷ࡍࡐࡎࡪࡇࠬᆑ"), l1ll1l_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱࡭ࡹࡓࡓࡎࡨࡹ࡭ࡔ࠵࠭ᆒ"), l1ll1l_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲ࡨ࡯ࡈࡡ࠲ࡰࡹ࠽ࡌࢀࠧᆓ"), l1ll1l_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳ࡳ࡜ࡳࡲࡥࡪࡧࡨ࠿ࡹࠨᆔ"), l1ll1l_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡹ࠰ࡦࡳ࠴ࡾࡌࡄ࠻࠷ࡉ࡛ࡗࡶ࡚ࠩᆕ"), l1ll1l_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡺ࠱ࡧࡴ࠵ࡴࡴࡇ࠶ࡎࡕࡺࡦࡎࡴࠪᆖ"), l1ll1l_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡻ࠲ࡨࡵ࠯ࡦࡘ࡙ࡅࡼࡑࡉࡴࡕ࡫ࠫᆗ"), l1ll1l_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡼ࠳ࡩ࡯࠰ࡺࡔࡴࡋࡐࡗࡨ࡫ࡪ࡮ࠬᆘ")]
    l11ll1ll1_opy_ =  l1ll1l_opy_ (u"ࠫࠨࡋࡘࡕࡏ࠶࡙ࠬᆙ")
    for url in l11lllll1_opy_:
        try:
            request  = requests.get(url)
            l1l111lll_opy_ = request.text
        except: pass
        if l11ll1ll1_opy_ in l1l111lll_opy_:
            path = os.path.join(dixie.PROFILE, l1ll1l_opy_ (u"ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠮࡮࠵ࡸࠫᆚ"))
            with open(path, l1ll1l_opy_ (u"࠭ࡷࠨᆛ")) as f:
                f.write(l1l111lll_opy_)
                break
def getPluginInfo(streamurl):
    if not l1llll1l_opy_() == l1ll1l_opy_ (u"ࠧࡕࡴࡸࡩࠬᆜ"):
        return
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l11ll11ll_opy_   = l1ll1l_opy_ (u"ࠨࡍࡲࡨ࡮ࠦࡐࡗࡔࠪᆝ")
            l11ll1l1l_opy_ = os.path.join(dixie.RESOURCES, l1ll1l_opy_ (u"ࠩ࡮ࡳࡩ࡯࠭ࡱࡸࡵ࠲ࡵࡴࡧࠨᆞ"))
            return l11ll11ll_opy_, l11ll1l1l_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l1ll1l_opy_ (u"ࠪࡶࡹࡳࡰࠨᆟ")) or url.startswith(l1ll1l_opy_ (u"ࠫࡷࡺ࡭ࡱࡧࠪᆠ")) or url.startswith(l1ll1l_opy_ (u"ࠬࡸࡴࡴࡲࠪᆡ")) or url.startswith(l1ll1l_opy_ (u"࠭ࡨࡵࡶࡳࠫᆢ")):
            l11ll11ll_opy_   = l1ll1l_opy_ (u"ࠧ࡮࠵ࡸࠤࡕࡲࡡࡺ࡮࡬ࡷࡹ࠭ᆣ")
            l11ll1l1l_opy_ = os.path.join(dixie.RESOURCES, l1ll1l_opy_ (u"ࠨ࡫ࡳࡸࡻ࠳ࡰ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡲࡱ࡫ࠬᆤ"))
            return l11ll11ll_opy_, l11ll1l1l_opy_
    except:
        pass
    if streamurl.startswith(dixie.OPEN_OTT):
        name = streamurl.split(l1ll1l_opy_ (u"ࠩࡠࡓ࡙࡚࡟ࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪᆥ"), 1)[-1].split(l1ll1l_opy_ (u"ࠪ࠳ࠬᆦ"), 1)[0]
    if l1ll1l_opy_ (u"ࠫࡢࡕࡔࡕࡡࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬᆧ") in streamurl:
        name = streamurl.split(l1ll1l_opy_ (u"ࠬࡣࡏࡕࡖࡢࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭ᆨ"), 1)[-1].split(l1ll1l_opy_ (u"࠭࠯ࠨᆩ"), 1)[0]
    if streamurl.startswith(l1ll1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪᆪ")):
        name = streamurl.split(l1ll1l_opy_ (u"ࠨ࠱࠲ࠫᆫ"), 1)[-1].split(l1ll1l_opy_ (u"ࠩ࠲ࠫᆬ"), 1)[0]
    if l1ll1l_opy_ (u"ࠪࡣࡤ࡙ࡆࡠࡡࠪᆭ") in streamurl:
        name = l1ll1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡵࡸ࡯ࡨࡴࡤࡱ࠳ࡹࡵࡱࡧࡵ࠲࡫ࡧࡶࡰࡷࡵ࡭ࡹ࡫ࡳࠨᆮ")
    if l1ll1l_opy_ (u"ࠬࡎࡄࡕࡘ࠽ࠫᆯ") in streamurl:
        name = l1ll1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹ࡭ࡢࡴࡷ࡬ࡺࡨࠧᆰ")
    if l1ll1l_opy_ (u"ࠧࡉࡆࡗ࡚࠷ࡀࠧᆱ") in streamurl:
        name = l1ll1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥ࡮ࡶࡴࡷࠩᆲ")
    if l1ll1l_opy_ (u"ࠩࡋࡈ࡙࡜࠳࠻ࠩᆳ") in streamurl:
        name = l1ll1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧࡴࡷࠩᆴ")
    if l1ll1l_opy_ (u"ࠫࡍࡊࡔࡗ࠶࠽ࠫᆵ") in streamurl:
        name = l1ll1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡲࠧᆶ")
    if l1ll1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝࠿࠭ᆷ") in streamurl:
        name = l1ll1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡢࡣࡥ࡬ࡴࡱࡧࡹࡦࡴࠪᆸ")
    if l1ll1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠲࠻ࠩᆹ") in streamurl:
        name = l1ll1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡰࡦࡿࡥࡳࡹࡺࡻࠬᆺ")
    if l1ll1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡔ࠽ࠫᆻ") in streamurl:
        name = l1ll1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽࠧᆼ")
    if l1ll1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡍ࡙࡜࠺ࠨᆽ") in streamurl:
        name = l1ll1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡴࡷࠩᆾ")
    if l1ll1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡊ࠺ࠨᆿ") in streamurl:
        name = l1ll1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡥࡧࡻࠫᇀ")
    if l1ll1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡓࡄ࠽ࠫᇁ") in streamurl:
        name = l1ll1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡩࡧࡵ࡯ࡵࠩᇂ")
    if l1ll1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡆࡐ࡚ࡀࠧᇃ") in streamurl:
        name = l1ll1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡨࡲࡵࡪࡲࡷࡺࠬᇄ")
    if l1ll1l_opy_ (u"࠭ࡉࡑࡖࡖࠫᇅ") in streamurl:
        name = l1ll1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࡭ࡵࡺࡶࠨᇆ")
    if l1ll1l_opy_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠻ࠩᇇ") in streamurl:
        name = l1ll1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮࡬ࡺࡪࡳࡩࡹࠩᇈ")
    if l1ll1l_opy_ (u"ࠪࡹࡵࡴࡰ࠻ࠩᇉ") in streamurl:
        name = l1ll1l_opy_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲࡭ࡪࡨࡰ࡯ࡨࡶࡺࡴ࠮ࡷ࡫ࡨࡻࠬᇊ")
    try:
        l11ll11ll_opy_   = xbmcaddon.Addon(name).getAddonInfo(l1ll1l_opy_ (u"ࠬࡴࡡ࡮ࡧࠪᇋ"))
        l11ll1l1l_opy_ = xbmcaddon.Addon(name).getAddonInfo(l1ll1l_opy_ (u"࠭ࡩࡤࡱࡱࠫᇌ"))
    except:
        l11ll11ll_opy_   = l1ll1l_opy_ (u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡕࡲࡹࡷࡩࡥࠨᇍ")
        l11ll1l1l_opy_ =  dixie.ICON
    return l11ll11ll_opy_, l11ll1l1l_opy_
def selectStream(url, channel):
    url = url.replace(l1ll1l_opy_ (u"ࠨࡾࡸࡷࡪࡸ࠭ࡢࡩࡨࡲࡹ࠭ᇎ"), l1ll1l_opy_ (u"ࠩ࠰࠱ࡺࡹࡥࡳ࠯ࡤ࡫ࡪࡴࡴࠨᇏ"))
    l11ll11l1_opy_ = url.split(l1ll1l_opy_ (u"ࠪࢀࠬᇐ"))
    if len(l11ll11l1_opy_) == 0:
        return None
    options, l11lll_opy_ = getOptions(l11ll11l1_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l11ll11l1_opy_) == 1:
            return l11lll_opy_[0]
    import selectDialog
    l11llllll_opy_ = selectDialog.select(l1ll1l_opy_ (u"ࠫࡘ࡫࡬ࡦࡥࡷࠤࡦࠦࡳࡵࡴࡨࡥࡲ࠭ᇑ"), options)
    if l11llllll_opy_ < 0:
        raise Exception(l1ll1l_opy_ (u"࡙ࠬࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡࡅࡤࡲࡨ࡫࡬ࠨᇒ"))
    return l11lll_opy_[l11llllll_opy_]
def getOptions(l11ll11l1_opy_, channel, addmore=True):
    if not l1llll1l_opy_() == l1ll1l_opy_ (u"࠭ࡔࡳࡷࡨࠫᇓ"):
        return
    options = []
    l11lll_opy_    = []
    for index, stream in enumerate(l11ll11l1_opy_):
        l11ll11ll_opy_ = getPluginInfo(stream)
        l111l_opy_ = l11ll11ll_opy_[0]
        l11lll111_opy_  = l11ll11ll_opy_[1]
        l111l_opy_  = l1ll1l_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡰࡴࡤࡲ࡬࡫࡝࡜ࠩᇔ") + l111l_opy_ + l1ll1l_opy_ (u"ࠨ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠤࠬᇕ")
        if stream.startswith(OPEN_OTT):
            l111l_opy_  = l111l_opy_ + stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l1ll1l_opy_ (u"ࠩࠪᇖ"))
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l1ll1l_opy_ (u"ࠪࠫᇗ"))
        else:
            l111l_opy_  = l111l_opy_ + channel
        options.append([l111l_opy_, index, l11lll111_opy_])
        l11lll_opy_.append(stream)
    if addmore:
        options.append([l1ll1l_opy_ (u"ࠫࡆࡪࡤࠡ࡯ࡲࡶࡪ࠴࠮࠯ࠩᇘ"), index + 1, dixie.ICON])
        l11lll_opy_.append(l1ll1l_opy_ (u"ࠬࡧࡤࡥࡏࡲࡶࡪ࠭ᇙ"))
    return options, l11lll_opy_