# coding: UTF-8
import sys
l1l1l1_opy_ = sys.version_info [0] == 2
l11ll1_opy_ = 2048
l1l11_opy_ = 7
def l1ll1l_opy_ (ll_opy_):
	global l1l11l_opy_
	l1l1l_opy_ = ord (ll_opy_ [-1])
	l1l1l11_opy_ = ll_opy_ [:-1]
	l1ll_opy_ = l1l1l_opy_ % len (l1l1l11_opy_)
	l1l1_opy_ = l1l1l11_opy_ [:l1ll_opy_] + l1l1l11_opy_ [l1ll_opy_:]
	if l1l1l1_opy_:
		l1111l_opy_ = unicode () .join ([unichr (ord (char) - l11ll1_opy_ - (l1111_opy_ + l1l1l_opy_) % l1l11_opy_) for l1111_opy_, char in enumerate (l1l1_opy_)])
	else:
		l1111l_opy_ = str () .join ([chr (ord (char) - l11ll1_opy_ - (l1111_opy_ + l1l1l_opy_) % l1l11_opy_) for l1111_opy_, char in enumerate (l1l1_opy_)])
	return eval (l1111l_opy_)
import xbmc
import xbmcaddon
import json
import urllib
import os
import dixie
l11l11ll1_opy_   = l1ll1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡵ࡬ࡶࡹࡪࡷࡧ࡮ࡤࡧࠪᦊ")
l11l1l1l1_opy_   = l1ll1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡹࡶࡵࡩࡦࡳ࠭ࡤࡱࡧࡩࡸ࠭ᦋ")
l11l111ll_opy_ = l1ll1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࡯ࡰࡵࡸࠪᦌ")
l111lllll_opy_    = l1ll1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡴࡹ࡮ࡩ࡫ࡪࡲࡷࡺࠬᦍ")
l111lll11_opy_   = l1ll1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡪࡺࡺࡵࡳࡧࡶࡸࡷ࡫ࡡ࡮ࡵࠪᦎ")
l11l11111_opy_    = l1ll1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡶࡩ࡯ࡼࠪᦏ")
l11l1l11l_opy_  = l1ll1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹࡴࡦࡣ࡯ࡸ࡭ࡻ࡮ࡥࡧࡵ࡫ࡷࡵࡵ࡯ࡦࠪᦐ")
l11l1llll_opy_   =  [l11l11ll1_opy_, l11l1l1l1_opy_, l111lllll_opy_, l111lll11_opy_, l11l11111_opy_, l11l1l11l_opy_]
def checkAddons():
    for addon in l11l1llll_opy_:
        if l11ll111l_opy_(addon):
            createINI(addon)
def l11ll111l_opy_(addon):
    if xbmc.getCondVisibility(l1ll1l_opy_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡉࡣࡶࡅࡩࡪ࡯࡯ࠪࠨࡷ࠮࠭ᦑ") % addon) == 1:
        return True
    else:
        return False
def createINI(addon):
    HOME = dixie.PROFILE
    PATH = os.path.join(HOME, l1ll1l_opy_ (u"ࠨ࡫ࡱ࡭ࠬᦒ"))
    l11l111_opy_ = str(addon).split(l1ll1l_opy_ (u"ࠩ࠱ࠫᦓ"))[2] + l1ll1l_opy_ (u"ࠪ࠲࡮ࡴࡩࠨᦔ")
    l11l11l_opy_  = os.path.join(PATH, l11l111_opy_)
    response = l1l11l1ll_opy_(addon)
    try:
        result = response[l1ll1l_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫᦕ")]
    except KeyError:
        dixie.log(l1ll1l_opy_ (u"ࠬ࠳࠭࠮࠯࠰ࠤࡐ࡫ࡹࡆࡴࡵࡳࡷࠦࡩ࡯ࠢࡪࡩࡹࡌࡩ࡭ࡧࡶࠤ࠲࠳࠭࠮࠯ࠣࠫᦖ") + addon)
        result = {l1ll1l_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࡸ࠭ᦗ"): [{l1ll1l_opy_ (u"ࡵࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪᦘ"): l1ll1l_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࠧᦙ"), l1ll1l_opy_ (u"ࡷࠪࡸࡾࡶࡥࠨᦚ"): l1ll1l_opy_ (u"ࡸࠫࡺࡴ࡫࡯ࡱࡺࡲࠬᦛ"), l1ll1l_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࠪᦜ"): l1ll1l_opy_ (u"ࡺ࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡹࡺࡻࠫᦝ"), l1ll1l_opy_ (u"ࡻࠧ࡭ࡣࡥࡩࡱ࠭ᦞ"): l1ll1l_opy_ (u"ࡵࠨࡐࡒࠤࡈࡎࡁࡏࡐࡈࡐࡘ࠭ᦟ")}], l1ll1l_opy_ (u"ࡶࠩ࡯࡭ࡲ࡯ࡴࡴࠩᦠ"): {l1ll1l_opy_ (u"ࡷࠪࡷࡹࡧࡲࡵࠩᦡ"): 0, l1ll1l_opy_ (u"ࡸࠫࡹࡵࡴࡢ࡮ࠪᦢ"): 1, l1ll1l_opy_ (u"ࡹࠬ࡫࡮ࡥࠩᦣ"): 1}}
    l1lll11_opy_ = result[l1ll1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫᦤ")]
    l11l1l1_opy_  = file(l11l11l_opy_, l1ll1l_opy_ (u"࠭ࡷࠨᦥ"))
    l11l1l1_opy_.write(l1ll1l_opy_ (u"ࠧ࡜ࠩᦦ"))
    l11l1l1_opy_.write(addon)
    l11l1l1_opy_.write(l1ll1l_opy_ (u"ࠨ࡟ࠪᦧ"))
    l11l1l1_opy_.write(l1ll1l_opy_ (u"ࠩ࡟ࡲࠬᦨ"))
    l11lll1_opy_ = []
    for channel in l1lll11_opy_:
        l111l_opy_ = channel[l1ll1l_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩᦩ")].split(l1ll1l_opy_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᦪ"), 1)[0].replace(l1ll1l_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡽࡨࡪࡶࡨࡡࠬᦫ"), l1ll1l_opy_ (u"࠭ࠧ᦬"))
        stream = channel[l1ll1l_opy_ (u"ࠧࡧ࡫࡯ࡩࠬ᦭")]
        if addon == l11l111ll_opy_:
            l111lll_opy_ = channel + l1ll1l_opy_ (u"ࠨ࠿ࡌࡔ࡙࡙࠺ࠨ᦮") + l111llll1_opy_
        else:
            l111lll_opy_ = l111l_opy_ + l1ll1l_opy_ (u"ࠩࡀࠫ᦯") + stream
        l11lll1_opy_.append(l111lll_opy_)
        l11lll1_opy_.sort()
    for item in l11lll1_opy_:
      l11l1l1_opy_.write(l1ll1l_opy_ (u"ࠥࠩࡸࡢ࡮ࠣᦰ") % item)
    l11l1l1_opy_.close()
def l1l11l1ll_opy_(addon):
    l11l11l11_opy_ = (l1ll1l_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࠥࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧᦱ") % addon)
    if addon == l11l1l11l_opy_:
        login = l1ll1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡵࡧࡤࡰࡹ࡮ࡵ࡯ࡦࡨࡶ࡬ࡸ࡯ࡶࡰࡧ࠳ࡄࡳ࡯ࡥࡧࡀ࡫ࡪࡴࡲࡦࡵࠩࡴࡴࡸࡴࡢ࡮ࡀࠩ࠼ࡨࠥ࠳࠴ࡱࡥࡲ࡫ࠥ࠳࠴ࠨ࠷ࡦࠫ࠲࠱ࠧ࠵࠶ࠪ࠻ࡢࡊࠧ࠸ࡨࠪ࠻ࡢࡄࡑࡏࡓࡗࠫ࠲࠱ࡹ࡫࡭ࡹ࡫ࠥ࠶ࡦࡆࡰ࡮ࡩ࡫ࠦ࠴࠳ࡘࡴࠫ࠲࠱ࡘ࡬ࡩࡼࠫ࠲࠱ࡖ࡫ࡩࠪ࠸࠰ࡍ࡫ࡶࡸࠪ࠸࠰ࡐࡨࠨ࠶࠵ࡉࡨࡢࡰࡱࡩࡱࡹࠥ࠶ࡤࠨ࠶࡫ࡉࡏࡍࡑࡕࠩ࠺ࡪࠥ࠶ࡤࠨ࠶࡫ࡏࠥ࠶ࡦࠨ࠶࠷ࠫ࠲ࡤࠧ࠵࠴ࠪ࠸࠲ࡱࡣࡵࡩࡳࡺࡡ࡭ࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࠩ࠷࠸ࡦࡢ࡮ࡶࡩࠪ࠸࠲ࠦ࠴ࡦࠩ࠷࠶ࠥ࠳࠴ࡸࡶࡱࠫ࠲࠳ࠧ࠶ࡥࠪ࠸࠰ࠦ࠴࠵࡬ࡹࡺࡰࠦ࠵ࡤࠩ࠷࡬ࠥ࠳ࡨࡰࡻ࠶࠴ࡩࡱࡶࡹ࠺࠻࠴ࡴࡷࠧ࠵࠶ࠪ࠸ࡣࠦ࠴࠳ࠩ࠷࠸ࡰࡱࡣࡶࡷࡼࡵࡲࡥࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࠩ࠷࠸࠰࠱࠲࠳ࠩ࠷࠸ࠥ࠳ࡥࠨ࠶࠵ࠫ࠲࠳࡯ࡤࡧࠪ࠸࠲ࠦ࠵ࡤࠩ࠷࠶ࠥ࠳࠴࠳࠴ࠪ࠹ࡡ࠲ࡃࠨ࠷ࡦ࠽࠸ࠦ࠵ࡤ࠸࠸ࠫ࠳ࡢ࠳࠵ࠩ࠸ࡧ࠷࠵ࠧ࠵࠶ࠪ࠸ࡣࠦ࠴࠳ࠩ࠷࠸ࡳࡦࡴ࡬ࡥࡱࠫ࠲࠳ࠧ࠶ࡥࠪ࠸࠰ࠦ࠹ࡥࠩ࠷࠸ࡳࡦࡰࡧࡣࡸ࡫ࡲࡪࡣ࡯ࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࡺࡲࡶࡧࠨ࠶ࡨࠫ࠲࠱ࠧ࠵࠶ࡨࡻࡳࡵࡱࡰࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࡺࡲࡶࡧࠨ࠶ࡨࠫ࠲࠱ࠧ࠵࠶ࡸࡴࠥ࠳࠴ࠨ࠷ࡦࠫ࠲࠱ࠧ࠵࠶ࠪ࠸࠲ࠦ࠴ࡦࠩ࠷࠶ࠥ࠳࠴ࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࠪ࠸࠲ࠦ࠵ࡤࠩ࠷࠶ࠥ࠳࠴ࠨ࠶࠷ࠫ࠲ࡤࠧ࠵࠴ࠪ࠸࠲ࡥࡧࡹ࡭ࡨ࡫࡟ࡪࡦ࠵ࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࠫ࠲࠳ࠧ࠵࠶ࠪ࠸ࡣࠦ࠴࠳ࠩ࠷࠸ࡤࡦࡸ࡬ࡧࡪࡥࡩࡥࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࠩ࠷࠸ࠥ࠳࠴ࠨ࠻ࡩࠫ࠲ࡤࠧ࠵࠴ࠪ࠸࠲ࡱࡣࡶࡷࡼࡵࡲࡥࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࡲࡺࡲ࡬ࠦ࠴ࡦࠩ࠷࠶ࠥ࠳࠴࡯ࡳ࡬࡯࡮ࠦ࠴࠵ࠩ࠸ࡧࠥ࠳࠲ࡱࡹࡱࡲࠥ࠸ࡦࠪᦲ")
    else:
        login = l1ll1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩᦳ") + addon + l1ll1l_opy_ (u"ࠧ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿ࡶࡩࡨࡻࡲࡪࡶࡼࡣࡨ࡮ࡥࡤ࡭ࠩࡩࡽࡺࡲࡢࠨࡳࡥ࡬࡫ࠦࡱ࡮ࡲࡸࠫࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠧࡶ࡬ࡸࡱ࡫࠽ࡍ࡫ࡹࡩࠪ࠸࠰ࡕࡘࠩࡹࡷࡲࠧᦴ")
    query = l11l1ll11_opy_(addon)
    l11l1111l_opy_ = (l1ll1l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫᦵ") % login)
    l11l111l1_opy_ = (l1ll1l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬᦶ") % query)
    try:
        xbmc.executeJSONRPC(l11l11l11_opy_)
        if addon != l11l111ll_opy_:
            xbmc.executeJSONRPC(l11l1111l_opy_)
        response = xbmc.executeJSONRPC(l11l111l1_opy_)
        content  = json.loads(response.decode(l1ll1l_opy_ (u"ࠪࡹࡹ࡬࠭࠹ࠩᦷ"), l1ll1l_opy_ (u"ࠫ࡮࡭࡮ࡰࡴࡨࠫᦸ")))
        return content
    except:
        dixie.log(l1ll1l_opy_ (u"ࠬ࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳ࠠࡑ࡮ࡸ࡫࡮ࡴࠠࡆࡴࡵࡳࡷࠦ࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭ࠨᦹ"))
        return {l1ll1l_opy_ (u"࠭ࡅࡳࡴࡲࡶࠬᦺ") : l1ll1l_opy_ (u"ࠧࡑ࡮ࡸ࡫࡮ࡴࠠࡆࡴࡵࡳࡷ࠭ᦻ")}
def l11l1ll11_opy_(addon):
    if addon == l11l111ll_opy_:
        return l1ll1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧࡩࡱࡶࡹ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡲࡩࡷࡧࡷࡺࡤࡧ࡬࡭ࠨࡨࡼࡹࡸࡡࠧࡲࡤ࡫ࡪࠬࡰ࡭ࡱࡷࠪࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠽ࠦ࠴ࡩ࡙ࡸ࡫ࡲࡴࠧ࠵ࡪࡷ࡯ࡣࡩࡣࡵࡨࠪ࠸ࡦࡍ࡫ࡥࡶࡦࡸࡹࠦ࠴ࡩࡅࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮ࠦ࠴࠳ࡗࡺࡶࡰࡰࡴࡷࠩ࠷࡬ࡋࡰࡦ࡬ࠩ࠷࡬ࡡࡥࡦࡲࡲࡸࠫ࠲ࡧࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲࡷࡺࡸࡻࡢࡴ࠴࠱࠸ࠪ࠸ࡦࡳࡧࡶࡳࡺࡸࡣࡦࡵࠨ࠶࡫࡯࡭ࡨࠧ࠵ࡪ࡭ࡵࡴ࠯ࡲࡱ࡫ࠫࡺࡩࡵ࡮ࡨࡁࡆࡲ࡬ࠦ࠴࠳ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡻࡲ࡭ࠩᦼ")
    if addon == l111lllll_opy_:
        return l1ll1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡵࡺ࡯ࡣ࡬࡫ࡳࡸࡻ࠵࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࡴࡶࡵࡩࡦࡳ࡟ࡷ࡫ࡧࡩࡴࠬࡥࡹࡶࡵࡥࠫࡶࡡࡨࡧࠩࡴࡱࡵࡴࠧࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡁࠫࡺࡩࡵ࡮ࡨࡁࡆࡲ࡬ࠧࡷࡵࡰࡂ࠶ࠧᦽ")
    if addon == l111lll11_opy_:
        return l1ll1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡫ࡻࡴࡶࡴࡨࡷࡹࡸࡥࡢ࡯ࡶ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡹࡴࡳࡧࡤࡱࡤࡼࡩࡥࡧࡲࠪࡪࡾࡴࡳࡣࠩࡴࡦ࡭ࡥࠧࡲ࡯ࡳࡹࠬࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠿ࠩࡸ࡮ࡺ࡬ࡦ࠿ࡄࡰࡱࠬࡵࡳ࡮ࡀ࠴ࠬᦾ")
    if addon == l11l1l11l_opy_:
        return l1ll1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹࡴࡦࡣ࡯ࡸ࡭ࡻ࡮ࡥࡧࡵ࡫ࡷࡵࡵ࡯ࡦ࠲ࡃ࡬࡫࡮ࡳࡧࡢࡲࡦࡳࡥ࠾ࡃ࡯ࡰࠫࡶ࡯ࡳࡶࡤࡰࡂࠫ࠷ࡃࠧ࠵࠶ࡳࡧ࡭ࡦࠧ࠵࠶ࠪ࠹ࡁࠬࠧ࠵࠶ࠪ࠻ࡂࡊࠧ࠸ࡈࠪ࠻ࡂࡄࡑࡏࡓࡗ࠱ࡷࡩ࡫ࡷࡩࠪ࠻ࡄࡄ࡮࡬ࡧࡰ࠱ࡔࡰ࡙࠭࡭ࡪࡽࠫࡕࡪࡨ࠯ࡑ࡯ࡳࡵ࠭ࡒࡪ࠰ࡉࡨࡢࡰࡱࡩࡱࡹࠥ࠶ࡄࠨ࠶ࡋࡉࡏࡍࡑࡕࠩ࠺ࡊࠥ࠶ࡄࠨ࠶ࡋࡏࠥ࠶ࡆࠨ࠶࠷ࠫ࠲ࡄ࠭ࠨ࠶࠷ࡶࡡࡳࡧࡱࡸࡦࡲࠥ࠳࠴ࠨ࠷ࡆ࠱ࠥ࠳࠴ࡩࡥࡱࡹࡥࠦ࠴࠵ࠩ࠷ࡉࠫࠦ࠴࠵ࡹࡷࡲࠥ࠳࠴ࠨ࠷ࡆ࠱ࠥ࠳࠴࡫ࡸࡹࡶࠥ࠴ࡃࠨ࠶ࡋࠫ࠲ࡇ࡯ࡺ࠵࠳࡯ࡰࡵࡸ࠹࠺࠳ࡺࡶࠦ࠴࠵ࠩ࠷ࡉࠫࠦ࠴࠵ࡴࡵࡧࡳࡴࡹࡲࡶࡩࠫ࠲࠳ࠧ࠶ࡅ࠰ࠫ࠲࠳࠲࠳࠴࠵ࠫ࠲࠳ࠧ࠵ࡇ࠰ࠫ࠲࠳࡯ࡤࡧࠪ࠸࠲ࠦ࠵ࡄ࠯ࠪ࠸࠲࠱࠲ࠨ࠷ࡆ࠷ࡁࠦ࠵ࡄ࠻࠽ࠫ࠳ࡂ࠶࠶ࠩ࠸ࡇ࠱࠳ࠧ࠶ࡅ࠼࠺ࠥ࠳࠴ࠨ࠶ࡈ࠱ࠥ࠳࠴ࡶࡩࡷ࡯ࡡ࡭ࠧ࠵࠶ࠪ࠹ࡁࠬࠧ࠺ࡆࠪ࠸࠲ࡴࡧࡱࡨࡤࡹࡥࡳ࡫ࡤࡰࠪ࠸࠲ࠦ࠵ࡄ࠯ࡹࡸࡵࡦࠧ࠵ࡇ࠰ࠫ࠲࠳ࡥࡸࡷࡹࡵ࡭ࠦ࠴࠵ࠩ࠸ࡇࠫࡵࡴࡸࡩࠪ࠸ࡃࠬࠧ࠵࠶ࡸࡴࠥ࠳࠴ࠨ࠷ࡆ࠱ࠥ࠳࠴ࠨ࠶࠷ࠫ࠲ࡄ࠭ࠨ࠶࠷ࡹࡩࡨࡰࡤࡸࡺࡸࡥࠦ࠴࠵ࠩ࠸ࡇࠫࠦ࠴࠵ࠩ࠷࠸ࠥ࠳ࡅ࠮ࠩ࠷࠸ࡤࡦࡸ࡬ࡧࡪࡥࡩࡥ࠴ࠨ࠶࠷ࠫ࠳ࡂ࠭ࠨ࠶࠷ࠫ࠲࠳ࠧ࠵ࡇ࠰ࠫ࠲࠳ࡦࡨࡺ࡮ࡩࡥࡠ࡫ࡧࠩ࠷࠸ࠥ࠴ࡃ࠮ࠩ࠷࠸ࠥ࠳࠴ࠨ࠻ࡉࠫ࠲ࡄ࠭ࠨ࠶࠷ࡶࡡࡴࡵࡺࡳࡷࡪࠥ࠳࠴ࠨ࠷ࡆ࠱࡮ࡶ࡮࡯ࠩ࠷ࡉࠫࠦ࠴࠵ࡰࡴ࡭ࡩ࡯ࠧ࠵࠶ࠪ࠹ࡁࠬࡰࡸࡰࡱࠫ࠷ࡅࠨࡰࡳࡩ࡫࠽ࡤࡪࡤࡲࡳ࡫࡬ࡴࠨࡪࡩࡳࡸࡥࡠ࡫ࡧࡁࠪ࠸ࡁࠨᦿ")
    else:
        Addon = xbmcaddon.Addon(addon)
        username =  Addon.getSetting(l1ll1l_opy_ (u"ࠬࡱࡡࡴࡷࡷࡥ࡯ࡧ࡮ࡪ࡯࡬ࠫᧀ"))
        password =  Addon.getSetting(l1ll1l_opy_ (u"࠭ࡳࡢ࡮ࡤࡷࡴࡴࡡࠨᧁ"))
        l1lll1l_opy_     = l1ll1l_opy_ (u"ࠧ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿ࡶࡸࡷ࡫ࡡ࡮ࡡࡹ࡭ࡩ࡫࡯ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠦࡵ࡫ࡷࡰࡪࡃࡁ࡭࡮ࠩࡹࡷࡲ࠽ࠨᧂ")
        l1l1111ll_opy_  =  l1l11l1l1_opy_(addon)
        l11ll1lll_opy_   = l1ll1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫᧃ") + addon
        l11l11lll_opy_  =  l11ll1lll_opy_ + l1lll1l_opy_ + l1l1111ll_opy_
        l11l1l1ll_opy_ = l1ll1l_opy_ (u"ࠩࡸࡷࡪࡸ࡮ࡢ࡯ࡨࡁࠬᧄ") + username + l1ll1l_opy_ (u"ࠪࠪࡵࡧࡳࡴࡹࡲࡶࡩࡃࠧᧅ") + password + l1ll1l_opy_ (u"ࠫࠫࡺࡹࡱࡧࡀ࡫ࡪࡺ࡟࡭࡫ࡹࡩࡤࡹࡴࡳࡧࡤࡱࡸࠬࡣࡢࡶࡢ࡭ࡩࡃ࠰ࠨᧆ")
        return l11l11lll_opy_ + urllib.quote_plus(l11l1l1ll_opy_)
def l1l11l1l1_opy_(addon):
    if (addon == l11l11ll1_opy_) or (addon == l11l1l1l1_opy_):
        return l1ll1l_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠹࠷࠯࠳࠻࠻࠳࠷࠳࠺࠰࠴࠹࠺ࡀ࠸࠱࠲࠳࠳ࡪࡴࡩࡨ࡯ࡤ࠶࠳ࡶࡨࡱࡁࠪᧇ")
    if addon == l11l11111_opy_:
        return l1ll1l_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡱ࡫ࡱࡾࡹࡼࡰࡳࡱ࠱ࡸࡰࡀ࠸࠱࠲࠳࠳ࡪࡴࡩࡨ࡯ࡤ࠶࠳ࡶࡨࡱࡁࠪᧈ")
def l111lll1l_opy_(addon, l111l_opy_):
    if (addon == l11l11ll1_opy_) or (addon == l11l1l1l1_opy_):
        l111l_opy_ = l111l_opy_.replace(l1ll1l_opy_ (u"ࠧࠡࠢࠪᧉ"), l1ll1l_opy_ (u"ࠨࠢࠪ᧊")).replace(l1ll1l_opy_ (u"ࠩࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᧋"), l1ll1l_opy_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᧌"))
        return l111l_opy_
    if (addon == l111lllll_opy_) or (addon == l111lll11_opy_) or (addon == l11l1l11l_opy_):
        return l111l_opy_
def l11l11l1l_opy_(addon, l11l1l111_opy_):
    if (addon == l11l11ll1_opy_) or (addon == l11l1l1l1_opy_):
        channel = l11l1l111_opy_.rsplit(l1ll1l_opy_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭᧍"), 1)[0].split(l1ll1l_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡽࡨࡪࡶࡨࡡࠬ᧎"), 1)[-1]
        channel = channel.replace(l1ll1l_opy_ (u"࠭ࡂࡃࡅࠣ࠵ࠬ᧏"), l1ll1l_opy_ (u"ࠧࡃࡄࡆࠤࡔࡴࡥࠨ᧐")).replace(l1ll1l_opy_ (u"ࠨࡄࡅࡇࠥ࠸ࠧ᧑"), l1ll1l_opy_ (u"ࠩࡅࡆࡈࠦࡔࡸࡱࠪ᧒")).replace(l1ll1l_opy_ (u"ࠪࡆࡇࡉࠠ࠵ࠩ᧓"), l1ll1l_opy_ (u"ࠫࡇࡈࡃࠡࡈࡒ࡙ࡗ࠭᧔")).replace(l1ll1l_opy_ (u"ࠬࡏࡔࡗࠢ࠴ࠫ᧕"), l1ll1l_opy_ (u"࠭ࡉࡕࡘ࠴ࠫ᧖")).replace(l1ll1l_opy_ (u"ࠧࡊࡖ࡙ࠤ࠷࠭᧗"), l1ll1l_opy_ (u"ࠨࡋࡗ࡚࠷࠭᧘")).replace(l1ll1l_opy_ (u"ࠩࡌࡘ࡛ࠦ࠳ࠨ᧙"), l1ll1l_opy_ (u"ࠪࡍ࡙࡜࠳ࠨ᧚")).replace(l1ll1l_opy_ (u"ࠫࡎ࡚ࡖࠡ࠶ࠪ᧛"), l1ll1l_opy_ (u"ࠬࡏࡔࡗ࠶ࠪ᧜"))
        return channel
    if (addon == l111lllll_opy_) or (addon == l111lll11_opy_):
        channel = l11l1l111_opy_.rsplit(l1ll1l_opy_ (u"࠭ࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ᧝"))[0].replace(l1ll1l_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡸࡪ࡬ࡸࡪࡣࠧ᧞"), l1ll1l_opy_ (u"ࠨࠩ᧟"))
        channel = channel.replace(l1ll1l_opy_ (u"ࠩ࠽ࠫ᧠"), l1ll1l_opy_ (u"ࠪࠫ᧡")).replace(l1ll1l_opy_ (u"ࠫࡇࡈࡃࠡ࠳ࠪ᧢"), l1ll1l_opy_ (u"ࠬࡈࡂࡄࠢࡒࡲࡪ࠭᧣")).replace(l1ll1l_opy_ (u"࠭ࡂࡃࡅࠣ࠶ࠬ᧤"), l1ll1l_opy_ (u"ࠧࡃࡄࡆࠤ࡙ࡽ࡯ࠨ᧥")).replace(l1ll1l_opy_ (u"ࠨࡄࡅࡇࠥ࠺ࠧ᧦"), l1ll1l_opy_ (u"ࠩࡅࡆࡈࠦࡆࡐࡗࡕࠫ᧧")).replace(l1ll1l_opy_ (u"ࠪࡍ࡙࡜ࠠ࠲ࠩ᧨"), l1ll1l_opy_ (u"ࠫࡎ࡚ࡖ࠲ࠩ᧩")).replace(l1ll1l_opy_ (u"ࠬࡏࡔࡗࠢ࠵ࠫ᧪"), l1ll1l_opy_ (u"࠭ࡉࡕࡘ࠵ࠫ᧫")).replace(l1ll1l_opy_ (u"ࠧࡊࡖ࡙ࠤ࠸࠭᧬"), l1ll1l_opy_ (u"ࠨࡋࡗ࡚࠸࠭᧭")).replace(l1ll1l_opy_ (u"ࠩࡌࡘ࡛ࠦ࠴ࠨ᧮"), l1ll1l_opy_ (u"ࠪࡍ࡙࡜࠴ࠨ᧯"))
        return channel
    else:
        channel = l11l1l111_opy_.replace(l1ll1l_opy_ (u"ࠫࡇࡈࡃࠡ࠳ࠪ᧰"), l1ll1l_opy_ (u"ࠬࡈࡂࡄࠢࡒࡲࡪ࠭᧱")).replace(l1ll1l_opy_ (u"࠭ࡂࡃࡅࠣ࠶ࠬ᧲"), l1ll1l_opy_ (u"ࠧࡃࡄࡆࠤ࡙ࡽ࡯ࠨ᧳")).replace(l1ll1l_opy_ (u"ࠨࡄࡅࡇࠥ࠺ࠧ᧴"), l1ll1l_opy_ (u"ࠩࡅࡆࡈࠦࡆࡐࡗࡕࠫ᧵")).replace(l1ll1l_opy_ (u"ࠪࡍ࡙࡜ࠠ࠲ࠩ᧶"), l1ll1l_opy_ (u"ࠫࡎ࡚ࡖ࠲ࠩ᧷")).replace(l1ll1l_opy_ (u"ࠬࡏࡔࡗࠢ࠵ࠫ᧸"), l1ll1l_opy_ (u"࠭ࡉࡕࡘ࠵ࠫ᧹")).replace(l1ll1l_opy_ (u"ࠧࡊࡖ࡙ࠤ࠸࠭᧺"), l1ll1l_opy_ (u"ࠨࡋࡗ࡚࠸࠭᧻")).replace(l1ll1l_opy_ (u"ࠩࡌࡘ࡛ࠦ࠴ࠨ᧼"), l1ll1l_opy_ (u"ࠪࡍ࡙࡜࠴ࠨ᧽"))
        return channel
def l1lll1l1_opy_(e):
    l1lllll1_opy_ = l1ll1l_opy_ (u"ࠫࡘࡵࡲࡳࡻ࠯ࠤࡦࡴࠠࡦࡴࡵࡳࡷࠦ࡯ࡤࡥࡸࡶࡪࡪ࠺ࠡࡌࡖࡓࡓࠦࡅࡳࡴࡲࡶ࠿ࠦࠥࡴࠩ᧾")  %e
    l1llllll_opy_ = l1ll1l_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡩ࡯࡯ࡶࡤࡧࡹࠦࡵࡴࠢࡲࡲࠥࡺࡨࡦࠢࡩࡳࡷࡻ࡭࠯ࠩ᧿")
    l1lll11l_opy_ = l1ll1l_opy_ (u"࠭ࡕࡱ࡮ࡲࡥࡩࠦࡡࠡ࡮ࡲ࡫ࠥࡼࡩࡢࠢࡷ࡬ࡪࠦࡡࡥࡦࡲࡲࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹࠠࡢࡰࡧࠤࡵࡵࡳࡵࠢࡷ࡬ࡪࠦ࡬ࡪࡰ࡮࠲ࠬᨀ")
    dixie.log(e)
    dixie.DialogOK(l1lllll1_opy_, l1llllll_opy_, l1lll11l_opy_)
    dixie.SetSetting(SETTING, l1ll1l_opy_ (u"ࠧࠨᨁ"))