# coding: UTF-8
import sys
l1l1l1l1_opy_ = sys.version_info [0] == 2
l111l1l_opy_ = 2048
l1l1ll11_opy_ = 7
def l1l1l_opy_ (l1l111_opy_):
	global l111lll_opy_
	l1llllll_opy_ = ord (l1l111_opy_ [-1])
	l1l1ll1l_opy_ = l1l111_opy_ [:-1]
	l1l1111_opy_ = l1llllll_opy_ % len (l1l1ll1l_opy_)
	l11l11_opy_ = l1l1ll1l_opy_ [:l1l1111_opy_] + l1l1ll1l_opy_ [l1l1111_opy_:]
	if l1l1l1l1_opy_:
		l1111_opy_ = unicode () .join ([unichr (ord (char) - l111l1l_opy_ - (l1lll_opy_ + l1llllll_opy_) % l1l1ll11_opy_) for l1lll_opy_, char in enumerate (l11l11_opy_)])
	else:
		l1111_opy_ = str () .join ([chr (ord (char) - l111l1l_opy_ - (l1lll_opy_ + l1llllll_opy_) % l1l1ll11_opy_) for l1lll_opy_, char in enumerate (l11l11_opy_)])
	return eval (l1111_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
import mapping
ADDON    = dixie.ADDON
l1ll111l_opy_ = dixie.PROFILE
l1111l1_opy_  = os.path.join(l1ll111l_opy_, l1l1l_opy_ (u"ࠫ࡮ࡴࡩࠨࠀ"))
l1lllll_opy_    = os.path.join(l1111l1_opy_, l1l1l_opy_ (u"ࠬࡳࡡࡱࡲ࡬ࡲ࡬ࡹ࠮࡫ࡵࡲࡲࠬࠁ"))
l111ll_opy_   = os.path.join(l1111l1_opy_, l1l1l_opy_ (u"࠭࡭ࡢࡲࡶ࠲࡯ࡹ࡯࡯ࠩࠂ"))
LABELFILE  = os.path.join(l1111l1_opy_, l1l1l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱࡹ࠮࡫ࡵࡲࡲࠬࠃ"))
l11lllll_opy_ = os.path.join(l1111l1_opy_, l1l1l_opy_ (u"ࠨࡲࡵࡩ࡫࡯ࡸࡦࡵ࠱࡮ࡸࡵ࡮ࠨࠄ"))
l1ll1l11_opy_  = json.load(open(l1lllll_opy_))
l1l1lll1_opy_      = json.load(open(l111ll_opy_))
labelmaps = json.load(open(LABELFILE))
l111_opy_  = json.load(open(l11lllll_opy_))
l1l1ll1_opy_ = l1l1l_opy_ (u"ࠩࠪࠅ")
def l1l11l_opy_(i, t1, l1l1l1_opy_=[]):
 t = l1l1ll1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l1l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11_opy_ = l1l11l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11lll_opy_ = l1l11l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1l1lll_opy_       = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡧࡪࡺࡶࠨࠆ")
l1l11lll_opy_  = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡆࡱࡧࡣ࡬ࡋࡦࡩ࡙࡜ࠧࠇ")
dexter    = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸࠨࠈ")
l1ll1l_opy_   = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡋ࡮ࡥ࡮ࡨࡷࡸ࠭ࠉ")
l1lll1_opy_       = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡦࡢࡤ࡫ࡳࡸࡺࡩ࡯ࡩࠪࠊ")
l1ll11ll_opy_  = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡇ࡮ࡤࡻࡱ࡫ࡳࡴࡖࡹࠫࠋ")
l1l11l11_opy_  = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡨࡵࡩࡪࡼࡩࡦࡹࠪࠌ")
l1ll11_opy_    = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡪࡩ࡭ࡵࡳࡵ࡫ࡱ࡫ࠬࠍ")
l1l111l_opy_   = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡬ࡴࡸࡩࡻࡱࡱ࡭ࡵࡺࡶࠨࠎ")
l1ll1_opy_  = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶࡴࡷࡵࡸࡦࡸ࠭ࠏ")
l11l11l_opy_      = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡰࡩ࡯ࡺࡷࡺ࠷࠭ࠐ")
l1l11ll1_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡌࡪ࡯࡬ࡸࡱ࡫ࡳࡴࡋࡓࡘ࡛࠭ࠑ")
l11lll1l_opy_    = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡍ࡫ࡰ࡭ࡹࡲࡥࡴࡵ࡙࠶ࠬࠒ")
l11l_opy_  = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡯ࡤࡸࡷ࡯ࡸࡪࡴࡨࡰࡦࡴࡤࠨࠓ")
l1lll1l1_opy_  = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡐࡥࡹࡹࡂࡶ࡫࡯ࡨࡸࡏࡐࡕࡘࠪࠔ")
l1l111l1_opy_   = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡱࡦࡾࡩࡸࡧࡥࡸࡻ࠭ࠕ")
l11l1l1_opy_     = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡲࡩ࡫ࡵࡸ࠰ࡴࡱࡻࡳࠨࠖ")
l111111_opy_      = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡳࡥࡨࡣ࡬ࡴࡹࡼࠧࠗ")
l1_opy_     = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡎࡢࡶ࡫ࡳ࠳ࡏࡐࡕࡘࠪ࠘")
nice      = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡯ࡣࡷ࡬ࡴࡹࡵࡣࡵ࡬ࡧࡪ࠭࠙")
l11ll_opy_   = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡲࡵࡩࡲ࡯ࡵ࡮࡫ࡳࡸࡻ࠭ࠚ")
l1l111ll_opy_  = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡳࡷࡦࡪࡤࡰࡰࠪࠛ")
root      = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡴࡵࡴࡊࡒࡗ࡚ࠬࠜ")
l1ll1ll1_opy_     = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡬࡯ࡺ࡮ࡱࡷࡺࠬࠝ")
l1l1l1l_opy_    = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡭ࡩࡻ࡯ࡲࡷࡵࡵࡲࡵࡵࠪࠞ")
l1lll1l_opy_      = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡤࡶࡹࠫࠟ")
l11111l_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡔࡷࡳࡶࡪࡳࡡࡤࡻࡗ࡚ࠬࠠ")
l1lll1ll_opy_   = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡷࡶࡪࡧ࡭ࡴࡷࡳࡶࡪࡳࡥ࠳ࠩࠡ")
l11l1ll_opy_   = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡷࡻ࡮ࡹࡴࡦࡦࡷࡺࠬࠢ")
l11ll11_opy_   = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡸࡻࡱࡩ࡯ࡩࡶࠫࠣ")
l11lll1_opy_    = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡶࡴ࡮ࠫࠤ")
l1l_opy_     = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡜ࡁࡅࡇࡕࠫࠥ")
l1ll1lll_opy_   = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸࡵࡴࡨࡥࡲ࠳ࡣࡰࡦࡨࡷࠬࠦ")
l1llll1l_opy_    = [l11lll1l_opy_, l1_opy_, nice, l11ll_opy_, l1ll1ll1_opy_, l1l1l1l_opy_, l1ll11_opy_, l11ll11_opy_, l11l_opy_, l1ll1lll_opy_, l1lll1l_opy_, l1lll1ll_opy_, l11lll1_opy_, l1l11ll1_opy_, l1lll1_opy_, l1l1lll_opy_, l1l111l_opy_, root, l111111_opy_, l1l11l11_opy_, l1ll1_opy_, l11l11l_opy_, l1ll1l_opy_, l1ll11ll_opy_, l1l111l1_opy_, dexter,l1l_opy_, l11111l_opy_, l11l1l1_opy_, l11l1ll_opy_, l1l111ll_opy_, l1l11lll_opy_]
def checkAddons():
    for addon in l1llll1l_opy_:
        if l1l11l1_opy_(addon):
            try: createINI(addon)
            except: continue
def l1l11l1_opy_(addon):
    if xbmc.getCondVisibility(l1l1l_opy_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫࠩࡸ࠯ࠧࠧ") % addon) == 1:
        dixie.log(l1l1l_opy_ (u"ࠩࡀࡁࡂࡃࠠࡢࡦࡧࡳࡳࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠢࡀࡁࡂࡃࠧࠨ"))
        dixie.log(addon)
        return True
    return False
def createINI(addon):
    l11llll1_opy_  = str(addon).split(l1l1l_opy_ (u"ࠪ࠲ࠬࠩ"))[2] + l1l1l_opy_ (u"ࠫ࠳࡯࡮ࡪࠩࠪ")
    l1l1l1ll_opy_   = os.path.join(l1111l1_opy_, l11llll1_opy_)
    response = l1llll11_opy_(addon)
    l11llll_opy_ = response[l1l1l_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬࠫ")][l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬࠬ")]
    l1l1ll_opy_  = l1l1l_opy_ (u"ࠧ࡜ࠩ࠭") + addon + l1l1l_opy_ (u"ࠨ࡟࡟ࡲࠬ࠮")
    l1lll111_opy_  =  file(l1l1l1ll_opy_, l1l1l_opy_ (u"ࠩࡺࠫ࠯"))
    l1lll111_opy_.write(l1l1ll_opy_)
    l1l1l111_opy_ = []
    for channel in l11llll_opy_:
        l11111_opy_ = l1l1l11_opy_(addon)
        l11ll1_opy_  = channel[l1l1l_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩ࠰")].split(l1l1l_opy_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࠱"), 1)[0]
        if addon == dexter:
            l11ll1_opy_ = l11ll1_opy_.split(l1l1l_opy_ (u"ࠬࠦࠫࠡࠩ࠲"), 1)[0]
        if (addon == l11l1ll_opy_) or (addon == l11lll1l_opy_) or (addon == l1_opy_) or (addon == nice) or (addon == l1ll1ll1_opy_) or (addon == l1l1l1l_opy_) or (addon == root) or (addon == l1l11ll1_opy_) or (addon == l11ll11_opy_) or (addon == l1ll11_opy_):
            l11ll1_opy_ = l11ll1_opy_.split(l1l1l_opy_ (u"࠭ࠠ࠮ࠢࠪ࠳"), 1)[0]
        l1llll_opy_ = l111l_opy_(addon, l11ll1_opy_)
        l11l1l_opy_ = l1lllll1_opy_(addon, l111_opy_, labelmaps, l1ll1l11_opy_, l1l1lll1_opy_, l11ll1_opy_)
        stream  = l11111_opy_ + l1llll_opy_
        l111l1_opy_ = l11l1l_opy_  + l1l1l_opy_ (u"ࠧ࠾ࠩ࠴") + stream
        if l111l1_opy_ not in l1l1l111_opy_:
            l1l1l111_opy_.append(l111l1_opy_)
    l1l1l111_opy_.sort()
    for item in l1l1l111_opy_:
        l1lll111_opy_.write(l1l1l_opy_ (u"ࠣࠧࡶࡠࡳࠨ࠵") % item)
    l1lll111_opy_.close()
def l111l_opy_(addon, l11ll1_opy_):
    if (addon == l11l1ll_opy_) or (addon == l11lll1l_opy_) or (addon == l1_opy_) or (addon == nice) or (addon == l11ll_opy_) or (addon == l1ll1ll1_opy_) or (addon == l1l1l1l_opy_) or (addon == root) or (addon == l1l11ll1_opy_) or (addon == l1lll1_opy_) or (addon == l1ll1lll_opy_) or (addon == l11l_opy_) or (addon == l11ll11_opy_) or (addon == l1ll11_opy_):
        l1l11ll_opy_ = mapping.cleanLabel(l11ll1_opy_)
        l1llll_opy_ = mapping.editPrefix(l111_opy_, l1l11ll_opy_)
        return l1llll_opy_
    l1l11ll_opy_ = mapping.cleanLabel(l11ll1_opy_)
    l1llll_opy_ = mapping.cleanStreamLabel(l1l11ll_opy_)
    return l1llll_opy_
def l1lllll1_opy_(addon, l111_opy_, labelmaps, l1ll1l11_opy_, l1l1lll1_opy_, l11ll1_opy_):
    if (addon == l11l1ll_opy_) or (addon == l11lll1l_opy_) or (addon == l1_opy_) or (addon == nice) or (addon == l11ll_opy_) or (addon == l1ll1ll1_opy_) or (addon == l1l1l1l_opy_) or (addon == root) or (addon == l1l11ll1_opy_) or (addon == l1lll1_opy_) or (addon == l1ll1lll_opy_) or (addon == l11l_opy_) or (addon == l11ll11_opy_) or (addon == l1ll11_opy_):
        return l1l11l1l_opy_(l111_opy_, l1l1lll1_opy_, l11ll1_opy_)
    l1llll1_opy_    = mapping.cleanLabel(l11ll1_opy_)
    l1l11ll_opy_ = mapping.mapLabel(labelmaps, l1llll1_opy_)
    l11l1l_opy_ = mapping.cleanPrefix(l1l11ll_opy_)
    return mapping.mapChannelName(l1ll1l11_opy_, l11l1l_opy_)
def l1l11l1l_opy_(l111_opy_, l1l1lll1_opy_, l11ll1_opy_):
    l1l1_opy_ = mapping.cleanLabel(l11ll1_opy_)
    l1l11ll_opy_   = mapping.editPrefix(l111_opy_, l1l1_opy_)
    l111ll1_opy_   = mapping.mapEPGLabel(l111_opy_, l1l1lll1_opy_, l1l11ll_opy_)
    return l111ll1_opy_
def l1ll_opy_(addon, file):
    l1llll1_opy_ = file[l1l1l_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨ࠶")].split(l1l1l_opy_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ࠷"), 1)[0]
    l1llll1_opy_ = l1llll1_opy_.split(l1l1l_opy_ (u"ࠫ࠰࠭࠸"), 1)[0]
    l1llll1_opy_ = mapping.cleanLabel(l1llll1_opy_)
    return l1llll1_opy_
def l1l1l11_opy_(addon):
    if addon == l11lll1l_opy_:
        return l1l1l_opy_ (u"ࠬࡒࡉࡎ࠴࠽ࠫ࠹")
    if addon == l1_opy_:
        return l1l1l_opy_ (u"࠭ࡎࡂࡖࡋ࠾ࠬ࠺")
    if addon == nice:
        return l1l1l_opy_ (u"ࠧࡏࡋࡆࡉ࠿࠭࠻")
    if addon == l11ll_opy_:
        return l1l1l_opy_ (u"ࠨࡒࡕࡉࡒࡀࠧ࠼")
    if addon == l1ll1ll1_opy_:
        return l1l1l_opy_ (u"ࠩࡊࡍ࡟ࡀࠧ࠽")
    if addon == l1l1l1l_opy_:
        return l1l1l_opy_ (u"ࠪࡋࡘࡖࡒࡕࡕ࠽ࠫ࠾")
    if addon == l1ll11_opy_:
        return l1l1l_opy_ (u"ࠫࡌࡋࡈ࠻ࠩ࠿")
    if addon == l11ll11_opy_:
        return l1l1l_opy_ (u"࡚ࠬࡖࡌ࠼ࠪࡀ")
    if addon == l11l_opy_:
        return l1l1l_opy_ (u"࠭ࡍࡕ࡚ࡌࡉ࠿࠭ࡁ")
    if addon == l1ll1lll_opy_:
        return l1l1l_opy_ (u"࡙ࠧࡖࡆ࠾ࠬࡂ")
    if addon == l1lll1l_opy_:
        return l1l1l_opy_ (u"ࠨࡕࡆࡘ࡛ࡀࠧࡃ")
    if addon == l1lll1ll_opy_:
        return l1l1l_opy_ (u"ࠩࡖ࡙ࡕࡀࠧࡄ")
    if addon == l11lll1_opy_:
        return l1l1l_opy_ (u"࡙ࠪࡐ࡚࠺ࠨࡅ")
    if addon == l1l11ll1_opy_:
        return l1l1l_opy_ (u"ࠫࡑࡏࡍࡊࡖ࠽ࠫࡆ")
    if addon == l1lll1_opy_:
        return l1l1l_opy_ (u"ࠬࡌࡁࡃ࠼ࠪࡇ")
    if addon == l1l1lll_opy_:
        return l1l1l_opy_ (u"࠭ࡁࡄࡇ࠽ࠫࡈ")
    if addon == l1l111l_opy_:
        return l1l1l_opy_ (u"ࠧࡉࡑࡕࡍ࡟ࡀࠧࡉ")
    if addon == root:
        return l1l1l_opy_ (u"ࠨࡔࡒࡓ࡙࠸࠺ࠨࡊ")
    if addon == l111111_opy_:
        return l1l1l_opy_ (u"ࠩࡐࡉࡌࡇ࠺ࠨࡋ")
    if addon == l1l11l11_opy_:
        return l1l1l_opy_ (u"ࠪࡊࡗࡋࡅ࠻ࠩࡌ")
    if addon == l1lll1l1_opy_:
        return l1l1l_opy_ (u"ࠫࡒࡇࡔࡔ࠼ࠪࡍ")
    if addon == l1ll1_opy_:
        return l1l1l_opy_ (u"ࠬࡏࡐࡕࡕ࠽ࠫࡎ")
    if addon == l11l11l_opy_:
        return l1l1l_opy_ (u"࠭ࡊࡊࡐ࡛࠶࠿࠭ࡏ")
    if addon == l1ll1l_opy_:
        return l1l1l_opy_ (u"ࠧࡆࡐࡇ࠾ࠬࡐ")
    if addon == l1ll11ll_opy_:
        return l1l1l_opy_ (u"ࠨࡈࡏࡅ࠿࠭ࡑ")
    if addon == l1l111l1_opy_:
        return l1l1l_opy_ (u"ࠩࡐࡅ࡝ࡏ࠺ࠨࡒ")
    if addon == dexter:
        return l1l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡆ࠽ࠫࡓ")
    if addon == l1l_opy_:
        return l1l1l_opy_ (u"࡛ࠫࡊࡒࡕࡘ࠽ࠫࡔ")
    if addon == l11111l_opy_:
        return l1l1l_opy_ (u"࡙ࠬࡐࡓࡏ࠽ࠫࡕ")
    if addon == l11l1l1_opy_:
        return l1l1l_opy_ (u"࠭ࡍࡄࡍࡗ࡚࠿࠭ࡖ")
    if addon == l11l1ll_opy_:
        return l1l1l_opy_ (u"ࠧࡕ࡙ࡌࡗ࡙ࡀࠧࡗ")
    if addon == l1l111ll_opy_:
        return l1l1l_opy_ (u"ࠨࡒࡕࡉࡘ࡚࠺ࠨࡘ")
    if addon == l1l11lll_opy_:
        return l1l1l_opy_ (u"ࠩࡅࡐࡐࡏ࠺ࠨ࡙")
def getURL(url):
    if url.startswith(l1l1l_opy_ (u"ࠪࡐࡎࡓ࠲ࠨ࡚")):
        return ll_opy_(url, l11lll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡓࡇࡔࡉ࡛ࠩ")):
        return ll_opy_(url, l1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡔࡉࡄࡇࠪ࡜")):
        return ll_opy_(url, nice)
    if url.startswith(l1l1l_opy_ (u"࠭ࡐࡓࡇࡐࠫ࡝")):
        return ll_opy_(url, l11ll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡈࡋ࡝ࠫ࡞")):
        return ll_opy_(url, l1ll1ll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡉࡖࡔࡗ࡚ࡓࠨ࡟")):
        return ll_opy_(url, l1l1l1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡊࡉࡍ࠭ࡠ")):
        return ll_opy_(url, l1ll11_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡘ࡛ࡑࠧࡡ")):
        return ll_opy_(url, l11ll11_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡒ࡚ࡘࡊࡇࠪࡢ")):
        return ll_opy_(url, l11l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬ࡞ࡔࡄࠩࡣ")):
        return ll_opy_(url, l1ll1lll_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡓࡄࡖ࡙ࠫࡤ")):
        return ll_opy_(url, l1lll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡔࡗࡓࠫࡥ")):
        return ll_opy_(url, l1lll1ll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡗࡎࡘࠬࡦ")):
        return ll_opy_(url, l11lll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡏࡍࡒࡏࡔࠨࡧ")):
        return ll_opy_(url, l1l11ll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡊࡆࡈࠧࡨ")):
        return ll_opy_(url, l1lll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡆࡉࡅࠨࡩ")):
        return ll_opy_(url, l1l1lll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡎࡏࡓࡋ࡝ࠫࡪ")):
        return ll_opy_(url, l1l111l_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡒࡐࡑࡗ࠶ࠬ࡫")):
        return ll_opy_(url, root)
    if url.startswith(l1l1l_opy_ (u"ࠧࡎࡇࡊࡅࠬ࡬")):
        return ll_opy_(url, l111111_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡈࡕࡉࡊ࠭࡭")):
        return ll_opy_(url, l1l11l11_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡄࡎࡘ࠾ࠬ࡮")):
        url = url.replace(l1l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡅࡏ࡙࠿࠭࡯"), l1l1l_opy_ (u"ࠫࠬࡰ")).replace(l1l1l_opy_ (u"ࠬ࠳࠭ࡶࡵࡨࡶ࠲ࡧࡧࡦࡰࡷࠫࡱ"), l1l1l_opy_ (u"࠭ࡼࡶࡵࡨࡶ࠲ࡧࡧࡦࡰࡷࠫࡲ"))
        return url
    if url.startswith(l1l1l_opy_ (u"ࠧࡎࡃࡗࡗࠬࡳ")):
        return ll_opy_(url, l1lll1l1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡋࡓࡘࡘ࠭ࡴ")):
        return ll_opy_(url, l1ll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡍࡍࡓ࡞࠲ࠨࡵ")):
        return ll_opy_(url, l11l11l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡆࠪࡶ")):
        return ll_opy_(url, dexter)
    if url.startswith(l1l1l_opy_ (u"ࠫࡋࡒࡁࠨࡷ")):
        return ll_opy_(url, l1ll11ll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡓࡁ࡙ࡋࠪࡸ")):
        return ll_opy_(url, l1l111l1_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡅࡏࡆࠪࡹ")):
        return ll_opy_(url, l1ll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡗࡆࡕࡘ࡛࠭ࡺ")):
        return ll_opy_(url, l1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡕࡓࡖࡒ࠭ࡻ")):
        return ll_opy_(url, l11111l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡐࡇࡐ࡚ࡖࠨࡼ")):
        return ll_opy_(url, l11l1l1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡘ࡜ࡏࡓࡕࠩࡽ")):
        return ll_opy_(url, l11l1ll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡕࡘࡅࡔࡖࠪࡾ")):
        return ll_opy_(url, l1l111ll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡈࡌࡌࡋࠪࡿ")):
        return ll_opy_(url, l1l11lll_opy_)
    response  = l11lll11_opy_(url)
    l1ll1ll_opy_ = url.split(l1l1l_opy_ (u"࠭࠺ࠨࢀ"), 1)[-1]
    l1ll1ll_opy_ = l1ll1ll_opy_.upper().replace(l1l1l_opy_ (u"ࠧࠡࠩࢁ"), l1l1l_opy_ (u"ࠨࠩࢂ"))
    try:
        result = response[l1l1l_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩࢃ")]
        l11l111_opy_  = result[l1l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩࢄ")]
    except Exception as e:
        l1l1111l_opy_(e)
        return None
    for file in l11l111_opy_:
        l11ll1_opy_  = file[l1l1l_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪࢅ")].split(l1l1l_opy_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࢆ"), 1)[0]
        l1ll1l1_opy_  = l11ll1_opy_.split(l1l1l_opy_ (u"࠭ࠫࠨࢇ"), 1)[0]
        l1ll11l_opy_ = mapping.cleanLabel(l1ll1l1_opy_)
        l1ll11l_opy_ = l1ll11l_opy_.upper().replace(l1l1l_opy_ (u"ࠧࠡࠩ࢈"), l1l1l_opy_ (u"ࠨࠩࢉ"))
        dixie.log(l1l1l_opy_ (u"ࠩࡀࡁࡂࡃࠠࡧ࡫࡯ࡩࡱࡧࡢࡦ࡮ࠣࡁࡂࡃ࠽ࠨࢊ"))
        dixie.log(l1ll11l_opy_)
        try:
            if l1ll1ll_opy_ == l1ll11l_opy_:
                dixie.log(l1l1l_opy_ (u"ࠪࡁࡂࡃ࠽ࠡࡧࡻࡥࡨࡺࠠ࡮ࡣࡷࡧ࡭ࠦ࠽࠾࠿ࡀࠫࢋ"))
                dixie.log(l1ll11l_opy_)
                return file[l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࠩࢌ")]
        except:
            if (l1ll1ll_opy_ in l1ll11l_opy_) or (l1ll11l_opy_ in l1ll1ll_opy_):
                dixie.log(l1l1l_opy_ (u"ࠬࡃ࠽࠾࠿ࠣࡴࡦࡸࡴࡪࡣ࡯ࠤࡲࡧࡴࡤࡪࠣࡁࡂࡃ࠽ࠨࢍ"))
                dixie.log(l1ll11l_opy_)
                dixie.log(l1ll1ll_opy_)
                return file[l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࠫࢎ")]
    return None
def ll_opy_(url, addon):
    dixie.log(l1l1l_opy_ (u"ࠧ࠾࠿ࡀࡁࠥ࡭ࡥࡵࡇࡻࡸࡷࡧࡕࡓࡎࠣࡁࡂࡃ࠽ࠨ࢏"))
    dixie.log(url)
    dixie.log(addon)
    PATH = l1lll11l_opy_(addon)
    try:
        response = json.load(open(PATH))
    except:
        response = l1llll11_opy_(addon)
    l1l1l11l_opy_      = url.split(l1l1l_opy_ (u"ࠨ࠼ࠪ࢐"), 1)[-1]
    stream    = l1l1l11l_opy_.split(l1l1l_opy_ (u"ࠩࠣ࡟ࠬ࢑"), 1)[0]
    l1ll1ll_opy_ = mapping.cleanLabel(stream)
    l1ll1ll_opy_ = l1ll1ll_opy_.upper().replace(l1l1l_opy_ (u"ࠪࠤࠬ࢒"), l1l1l_opy_ (u"ࠫࠬ࢓"))
    dixie.log(l1l1l_opy_ (u"ࠬࡃ࠽࠾࠿ࠣࡷࡹࡸࡥࡢ࡯ࡘࡶࡱࠦ࠽࠾࠿ࡀࠫ࢔"))
    dixie.log(l1ll1ll_opy_)
    l11l111_opy_  = response[l1l1l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭࢕")][l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭࢖")]
    for file in l11l111_opy_:
        l11ll1_opy_  = file[l1l1l_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࢗ")].split(l1l1l_opy_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࢘"), 1)[0]
        if addon == dexter:
            l11ll1_opy_ = l11ll1_opy_.split(l1l1l_opy_ (u"ࠪࠤ࠰࢙ࠦࠧ"), 1)[0]
        if (addon == l11l1ll_opy_) or (addon == l11lll1l_opy_) or (addon == l1_opy_) or (addon == nice) or (addon == l1ll1ll1_opy_) or (addon == l1l1l1l_opy_) or (addon == root) or (addon == l1l11ll1_opy_) or (addon == l11ll11_opy_) or (addon == l1ll11_opy_):
            l11ll1_opy_ = l11ll1_opy_.split(l1l1l_opy_ (u"ࠫࠥ࠳ࠠࠨ࢚"), 1)[0]
        l1ll11l_opy_ = l111l_opy_(addon, l11ll1_opy_)
        l1ll11l_opy_ = l1ll11l_opy_.upper().replace(l1l1l_opy_ (u"࢛ࠬࠦࠧ"), l1l1l_opy_ (u"࠭ࠧ࢜"))
        dixie.log(l1l1l_opy_ (u"ࠧ࠾࠿ࡀࡁࠥ࡬ࡩ࡭ࡧ࡯ࡥࡧ࡫࡬ࠡ࠿ࡀࡁࡂ࠭࢝"))
        dixie.log(l1ll11l_opy_)
        try:
            if l1ll1ll_opy_ == l1ll11l_opy_:
                dixie.log(l1l1l_opy_ (u"ࠨ࠿ࡀࡁࡂࠦࡥࡹࡣࡦࡸࠥࡳࡡࡵࡥ࡫ࠤࡂࡃ࠽࠾ࠩ࢞"))
                dixie.log(l1ll1ll_opy_)
                return file[l1l1l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧ࢟")]
        except:
            if (l1ll1ll_opy_ in l1ll11l_opy_) or (l1ll11l_opy_ in l1ll1ll_opy_):
                dixie.log(l1l1l_opy_ (u"ࠪࡁࡂࡃ࠽ࠡࡲࡤࡶࡹ࡯ࡡ࡭ࠢࡰࡥࡹࡩࡨࠡ࠿ࡀࡁࡂ࠭ࢠ"))
                dixie.log(l1ll11l_opy_)
                dixie.log(l1ll1ll_opy_)
                return file[l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࠩࢡ")]
    return None
def l1llll11_opy_(addon):
    PATH  = l1lll11l_opy_(addon)
    if addon == l1l_opy_:
        query = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡖࡂࡆࡈࡖ࠴ࡲࡩࡷࡧࡷࡺ࠴ࡧ࡬࡭࠱ࠪࢢ")
    elif addon == l1lll1ll_opy_:
        query = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡶࡵࡩࡦࡳࡳࡶࡲࡵࡩࡲ࡫࠲࠰࡮࡬ࡺࡪࡺࡶ࠰ࡣ࡯ࡰ࠴࠭ࢣ")
    elif addon == l1lll1l_opy_:
        query = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡦࡸࡻ࠵࡬ࡪࡸࡨࡸࡻ࠵ࡡ࡭࡮࠲ࠫࢤ")
    elif addon == l1lll1ll_opy_:
        query = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡸࡷ࡫ࡡ࡮ࡵࡸࡴࡷ࡫࡭ࡦ࠴࠲ࡰ࡮ࡼࡥࡵࡸ࠲ࡥࡱࡲ࠯ࠨࢥ")
    elif addon == l1l11l11_opy_:
        query = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡪࡷ࡫ࡥࡷ࡫ࡨࡻ࠴ࡅࡵࡳ࡮ࡀࡹࡷࡲࠦ࡮ࡱࡧࡩࡂ࠻ࠦ࡯ࡣࡰࡩࡂࡒࡩࡷࡧ࠮ࡘ࡛࠭ࢦ")
    elif addon == l11lll1_opy_:
        query = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡶࡴ࡮࠳ࡄࡻࡲ࡭࠿࡫ࡸࡹࡶࠥ࠴ࡃࠨ࠶ࡋࠫ࠲ࡇࡣࡧࡨࡴࡴࡣ࡭ࡱࡸࡨ࠳ࡵࡲࡨࠧ࠵ࡊࡺࡱࡴࡶࡴ࡮ࠩ࠷ࡌࡕࡌࡖࡸࡶࡰࠫ࠲ࡇࡎ࡬ࡺࡪࠫ࠲࠶࠴࠳ࡘ࡛࠴ࡴࡹࡶࠩࡱࡴࡪࡥ࠾࠳ࠩࡲࡦࡳࡥ࠾ࡎ࡬ࡺࡪ࠱ࡔࡗࠨࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴ࠽ࠧࡨࡤࡲࡦࡸࡴ࠾ࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂ࠭ࢧ")
    else:
        query = l1ll1l1l_opy_(addon)
    try:
        return json.load(open(PATH))
    except:
        content = doJSON(query)
        return l1l11_opy_(PATH, addon, content)
def l1l11_opy_(PATH, addon, content):
    json.dump(content, open(PATH,l1l1l_opy_ (u"ࠫࡼ࠭ࢨ")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    dixie.log(l1l1l_opy_ (u"ࠬࡃ࠽࠾࠿ࠣࡨࡴࡐࡓࡐࡐࠣࡵࡺ࡫ࡲࡺࠢࡀࡁࡂࡃࠧࢩ"))
    dixie.log(query)
    l1ll111_opy_  = (l1l1l_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࠧࡶࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩࢪ") % query)
    response = xbmc.executeJSONRPC(l1ll111_opy_)
    content  = json.loads(response)
    return content
def l1lll11l_opy_(addon):
    if addon == l11lll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧ࡭࡫ࡰ࠶ࡹ࡫࡭ࡱࠩࢫ"))
    if addon == l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡰࡤࡸ࡭ࡵࡴࡦ࡯ࡳࠫࢬ"))
    if addon == nice:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡱ࡭ࡨ࡫ࡴࡦ࡯ࡳࠫࢭ"))
    if addon == l11ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡴࡷ࡫࡭ࡵࡧࡰࡴࠬࢮ"))
    if addon == l1ll1ll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫ࡬࡯ࡺࡵࡧࡰࡴࠬࢯ"))
    if addon == l1l1l1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬ࡭ࡳࡱࡴࡷࡷࡹ࡫࡭ࡱࠩࢰ"))
    if addon == l1ll11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡧࡦࡶࡨࡱࡵ࠭ࢱ"))
    if addon == l11l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧ࡮ࡶࡻࡸࡪࡳࡰࠨࢲ"))
    if addon == l11ll11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡶࡹ࡯ࡹ࡫࡭ࡱࠩࢳ"))
    if addon == l1ll1lll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡻࡸࡪࡳࡰࠨࢴ"))
    if addon == l1lll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡷࡨࡺࡥ࡮ࡲࠪࢵ"))
    if addon == l1lll1ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡸࡻࡰࡵࡧࡰࡴࠬࢶ"))
    if addon == l11lll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡻ࡫ࡵࡶࡨࡱࡵ࠭ࢷ"))
    if addon == l1l11ll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭࡬ࡪ࡯࡬ࡸࡪࡳࡰࠨࢸ"))
    if addon == l1lll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡧࡣࡥࡸࡪࡳࡰࠨࢹ"))
    if addon == l1l1lll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡣࡦࡩࡹ࡫࡭ࡱࠩࢺ"))
    if addon == l1l111l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩ࡫ࡳࡷࡺࡥ࡮ࡲࠪࢻ"))
    if addon == root:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡶࡴ࠸ࡴࡦ࡯ࡳࠫࢼ"))
    if addon == l111111_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡲ࡫ࡧࡢࡶࡰࡴࠬࢽ"))
    if addon == l1lll1l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡳࡡࡵࡵࡷࡱࡵ࠭ࢾ"))
    if addon == l1l11l11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡦࡳࡧࡨࡸࡲࡶࠧࢿ"))
    if addon == l1ll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡪࡲࡷࡷࡹࡳࡰࠨࣀ"))
    if addon == l11l11l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨ࡬࠵ࡸࡪࡳࡰࠨࣁ"))
    if addon == l1ll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡨࡸࡪࡳࡰࠨࣂ"))
    if addon == l1ll11ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡪࡹ࡫࡭ࡱࠩࣃ"))
    if addon == l1l111l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡲࡧࡸࡵࡧࡰࡴࠬࣄ"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡪࡴࡦ࡯ࡳࠫࣅ"))
    if addon == l1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡶࡥࡶࡨࡱࡵ࠭ࣆ"))
    if addon == l11111l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡴࡲࡵࡸࡪࡳࡰࠨࣇ"))
    if addon == l11l1l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨ࡯ࡦ࡯ࡹ࡫࡭ࡱࠩࣈ"))
    if addon == l11l1ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡷࡻ࡮ࡺࡥ࡮ࡲࠪࣉ"))
    if addon == l1l111ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡴࡷ࡫ࡳࡵࡧࡰࡴࠬ࣊"))
    if addon == l1l11lll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡧࡲ࡫ࡪࡶࡨࡱࡵ࠭࣋"))
def l1ll1l1l_opy_(addon):
    query = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ࣌") + addon
    response = doJSON(query)
    l11l111_opy_    = response[l1l1l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭࣍")][l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭࣎")]
    for file in l11l111_opy_:
        l111l11_opy_ = file[l1l1l_opy_ (u"ࠨ࡮ࡤࡦࡪࡲ࣏ࠧ")]
        l1llll1_opy_ = mapping.cleanLabel(l111l11_opy_)
        l1llll1_opy_ = l1llll1_opy_.upper()
        if (l1llll1_opy_ == l1l1l_opy_ (u"ࠩࡏࡍ࡛ࡋࠠࡊࡒࡗ࡚࣐ࠬ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠪࡐࡎ࡜ࡅࠡࡖ࡙࣑ࠫ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠫࡑࡏࡖࡆࠢࡆࡌࡆࡔࡎࡆࡎࡖ࣒ࠫ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠬࡒࡉࡗࡇ࣓ࠪ")) or (l1llll1_opy_ == l1l1l_opy_ (u"࠭ࡅࡏࡆࡏࡉࡘ࡙ࠠࡎࡇࡇࡍࡆ࠭ࣔ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠧࡇࡎࡄ࡛ࡑࡋࡓࡔࡖ࡙ࠫࣕ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠨࡏࡄ࡜ࡎ࡝ࡅࡃࠢࡗ࡚ࠬࣖ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠩࡅࡐࡆࡉࡋࡊࡅࡈࠤ࡙࡜ࠧࣗ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠪࡌࡔࡘࡉ࡛ࡑࡑࠤࡎࡖࡔࡗࠩࣘ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠫࡋࡇࡂࠡࡋࡓࡘ࡛࠭ࣙ")):
            livetv = file[l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪࣚ")]
            return l1111l_opy_(livetv)
def l1111l_opy_(livetv):
    response = doJSON(livetv)
    l11l111_opy_    = response[l1l1l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࣛ")][l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࣜ")]
    for file in l11l111_opy_:
        l111l11_opy_ = file[l1l1l_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࣝ")]
        l1llll1_opy_ = mapping.cleanLabel(l111l11_opy_)
        l1llll1_opy_ = l1llll1_opy_.upper()
        if l1llll1_opy_ == l1l1l_opy_ (u"ࠩࡄࡐࡑ࠭ࣞ"):
            return file[l1l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࠨࣟ")]
def l1lll11_opy_(l11l1_opy_):
    items = []
    _1111ll_opy_(l11l1_opy_, items)
    return items
def _1111ll_opy_(l11l1_opy_, items):
    response = doJSON(l11l1_opy_)
    if response[l1l1l_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫ࣠")].has_key(l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫ࣡")):
        result = response[l1l1l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭࣢")][l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸࣣ࠭")]
        for item in result:
            if item[l1l1l_opy_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪࣤ")] == l1l1l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧࣥ"):
                l1llll1_opy_ = mapping.cleanLabel(item[l1l1l_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࣦࠩ")])
                items.append(item)
            elif item[l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭ࣧ")] == l1l1l_opy_ (u"ࠬࡪࡩࡳࡧࡦࡸࡴࡸࡹࠨࣨ"):
                l1llll1_opy_ = mapping.cleanLabel(item[l1l1l_opy_ (u"࠭࡬ࡢࡤࡨࡰࣩࠬ")])
                l1l11111_opy_  = item[l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࠬ࣪")]
                dixie.log(item)
                dixie.log(l1l11111_opy_)
                _1111ll_opy_(l1l11111_opy_, items)
def l11lll11_opy_(url):
    if url.startswith(l1l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠺ࠨ࣫")):
        l1ll111_opy_ = (l1l1l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡨࡢࡤ࡫ࡳࡰࡦࡿࡥࡳ࠱ࡂࡹࡷࡲ࠽ࡶࡴ࡯ࠪࡲࡵࡤࡦ࠿࠵ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡻ࡫ࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠩࡍࡕࡏࡄ࠾ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧ࣬"))
    if url.startswith(l1l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠴࠽࣭ࠫ")):
        l1ll111_opy_ = (l1l1l_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺ࠳ࡄࡻࡲ࡭࠿ࡸࡶࡱࠬ࡭ࡰࡦࡨࡁ࠶࠶࠱ࠧࡰࡤࡱࡪࡃࡗࡢࡶࡦ࡬࠰ࡒࡩࡷࡧࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࡂࠬࡳࡶࡤࡷ࡭ࡹࡲࡥࡴࡡࡸࡶࡱࡃࠦ࡭ࡱࡪ࡫ࡪࡪ࡟ࡪࡰࡀࡊࡦࡲࡳࡦࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃ࣮ࠧ"))
    if url.startswith(l1l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖ࠿࣯࠭")):
        l1ll111_opy_ = (l1l1l_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠵࠿ࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠫࡲ࡯ࡨࡩࡨࡨࡤ࡯࡮࠾ࡈࡤࡰࡸ࡫ࠦ࡮ࡱࡧࡩࡂ࠷࠱࠴ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡶࡸࡪࡴࠥ࠳࠲ࡏ࡭ࡻ࡫ࠦࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡵࡢࡹࡷࡲࠦࡶࡴ࡯ࡁࡺࡸ࡬ࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂࣰ࠭"))
    if url.startswith(l1l1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡏࡔࡗ࠼ࣱࠪ")):
        l1ll111_opy_ = (l1l1l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡺࡶࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂࣲ࠭"))
    if url.startswith(l1l1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪࣳ")):
        l1ll111_opy_ = (l1l1l_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡤࡦࡺ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡦࡲ࡬ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠦࡵ࡫ࡷࡰࡪࡃࠥ࠶ࡤࡆࡓࡑࡕࡒࠦ࠴࠳ࡻ࡭࡯ࡴࡦࠧ࠸ࡨࡆࡲ࡬ࠦ࠴࠳ࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠪ࠻ࡢࠦ࠴ࡩࡇࡔࡒࡏࡓࠧ࠸ࡨࠫࡻࡲ࡭ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࣴ"))
    if url.startswith(l1l1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡕࡆ࠿࠭ࣵ")):
        l1ll111_opy_ = (l1l1l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡨࡦࡴࡵࡴ࠰ࡁࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠦࡧࡣࡱࡥࡷࡺ࠽ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡳ࡯ࡥࡧࡀ࠻ࠫࡶࡩ࡭࡮ࡲࡻࡂࡒࡩࡷࡧࠨ࠶࠵࡙ࡴࡳࡧࡤࡱࡸࠬࡵࡳ࡮ࡀࡶࡦࡴࡤࡰ࡯ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨࣶ"))
    try:
        dixie.ShowBusy()
        addon =  l1ll111_opy_.split(l1l1l_opy_ (u"࠭࠯࠰ࠩࣷ"), 1)[-1].split(l1l1l_opy_ (u"ࠧ࠰ࠩࣸ"), 1)[0]
        login = l1l1l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂࣹ࠭") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1ll111_opy_)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1l1111l_opy_(e)
        return {l1l1l_opy_ (u"ࠩࡈࡶࡷࡵࡲࠨࣺ") : l1l1l_opy_ (u"ࠪࡔࡱࡻࡧࡪࡰࠣࡉࡷࡸ࡯ࡳࠩࣻ")}
def l1l1llll_opy_():
    modules = map(__import__, [l1l11l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l1l1l_opy_ (u"࡙ࠫࡸࡵࡦࠩࣼ")
    if len(modules[-1].Window(10**4).getProperty(l11lll_opy_)):
        return l1l1l_opy_ (u"࡚ࠬࡲࡶࡧࠪࣽ")
    return l1l1l_opy_ (u"࠭ࡆࡢ࡮ࡶࡩࠬࣾ")
def l1l1111l_opy_(e):
    l1ll1111_opy_ = l1l1l_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠲ࠠࡢࡰࠣࡩࡷࡸ࡯ࡳࠢࡲࡧࡨࡻࡲࡦࡦ࠽ࠤࡏ࡙ࡏࡏࠢࡈࡶࡷࡵࡲ࠻ࠢࠨࡷࠬࣿ")  %e
    l11ll1l_opy_ = l1l1l_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡴࡨ࠱ࡱ࡯࡮࡬ࠢࡷ࡬࡮ࡹࠠࡤࡪࡤࡲࡳ࡫࡬ࠡࡣࡱࡨࠥࡺࡲࡺࠢࡤ࡫ࡦ࡯࡮࠯ࠩऀ")
    l1ll11l1_opy_ = l1l1l_opy_ (u"ࠩࡘࡷࡪࡀࠠࡄࡱࡱࡸࡪࡾࡴࠡࡏࡨࡲࡺࠦ࠽࠿ࠢࡕࡩࡲࡵࡶࡦࠢࡖࡸࡷ࡫ࡡ࡮ࠩँ")
    dixie.log(e)
    dixie.DialogOK(l1ll1111_opy_, l11ll1l_opy_, l1ll11l1_opy_)
if __name__ == l1l1l_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬं"):
    checkAddons()