# coding: UTF-8
import sys
l1l1l1l1_opy_ = sys.version_info [0] == 2
l111l1l_opy_ = 2048
l1l1ll11_opy_ = 7
def l1l1l_opy_ (l1l111_opy_):
	global l111lll_opy_
	l1llllll_opy_ = ord (l1l111_opy_ [-1])
	l1l1ll1l_opy_ = l1l111_opy_ [:-1]
	l1l1111_opy_ = l1llllll_opy_ % len (l1l1ll1l_opy_)
	l11l11_opy_ = l1l1ll1l_opy_ [:l1l1111_opy_] + l1l1ll1l_opy_ [l1l1111_opy_:]
	if l1l1l1l1_opy_:
		l1111_opy_ = unicode () .join ([unichr (ord (char) - l111l1l_opy_ - (l1lll_opy_ + l1llllll_opy_) % l1l1ll11_opy_) for l1lll_opy_, char in enumerate (l11l11_opy_)])
	else:
		l1111_opy_ = str () .join ([chr (ord (char) - l111l1l_opy_ - (l1lll_opy_ + l1llllll_opy_) % l1l1ll11_opy_) for l1lll_opy_, char in enumerate (l11l11_opy_)])
	return eval (l1111_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l1llllll11_opy_     = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡱࡸࡻ࠭ি")
l1lllll111_opy_  = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡻࡱ࡯ࡰࡵࡸࠪী")
l11111lll_opy_     = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡶࡴ࡮ࠫু")
locked  = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲ࡯ࡤ࡭ࡨࡨࡹࡼࠧূ")
l1llll11ll_opy_      = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡵ࡭ࡶ࡬ࡱࡦࡺࡥ࡮ࡣࡱ࡭ࡦ࠭ৃ")
l1llll1ll1_opy_    = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡭࡫ࡸࡼ࠳ࡺࡶࠨৄ")
l1lllll1l1_opy_     = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡆࡆࡗࡵࡵࡲࡵࡵࠪ৅")
l11111ll1_opy_  = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡩࡧࡵ࡯ࡵࠩ৆")
l1111111l_opy_     = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡧࡱࡻࡩࡱࡶࡹࠫে")
l11111l1l_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡷ࠶ࡨࡼࡵࡧࡴࡴ࠰ࡦࡳࡲ࠭ৈ")
l1llll1l_opy_ = [l1llllll11_opy_, locked, l1llll1ll1_opy_, l1lllll111_opy_, l11111l1l_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1l1l_opy_ (u"࠭ࡩ࡯࡫ࠪ৉"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1l1ll1_opy_ = l1l1l_opy_ (u"ࠧࠨ৊")
def l1l11l_opy_(i, t1, l1l1l1_opy_=[]):
 t = l1l1ll1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l1l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11_opy_ = l1l11l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11lll_opy_ = l1l11l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1llll1l_opy_:
        if l1l11l1_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1l11l1_opy_(addon):
    if xbmc.getCondVisibility(l1l1l_opy_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫࠩࡸ࠯ࠧো") % addon) == 1:
        return True
    return False
def createINI(addon):
    l11llll1_opy_ = str(addon).split(l1l1l_opy_ (u"ࠩ࠱ࠫৌ"))[2] + l1l1l_opy_ (u"ࠪ࠲࡮ࡴࡩࠨ্")
    l1l1l1ll_opy_  = os.path.join(PATH, l11llll1_opy_)
    try:
        l11llll_opy_ = l1llll11_opy_(addon)
    except KeyError:
        dixie.log(l1l1l_opy_ (u"ࠫ࠲࠳࠭࠮࠯ࠣࡏࡪࡿࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡩࡨࡸࡋ࡯࡬ࡦࡵࠣ࠱࠲࠳࠭࠮ࠢࠪৎ") + addon)
        result = {l1l1l_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࡷࠬ৏"): [{l1l1l_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ৐"): l1l1l_opy_ (u"ࡵࠨࡨ࡬ࡰࡪ࠭৑"), l1l1l_opy_ (u"ࡶࠩࡷࡽࡵ࡫ࠧ৒"): l1l1l_opy_ (u"ࡷࠪࡹࡳࡱ࡮ࡰࡹࡱࠫ৓"), l1l1l_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࠩ৔"): l1l1l_opy_ (u"ࡹࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸࡹࡺࠪ৕"), l1l1l_opy_ (u"ࡺ࠭࡬ࡢࡤࡨࡰࠬ৖"): l1l1l_opy_ (u"ࡻࠧࡏࡑࠣࡇࡍࡇࡎࡏࡇࡏࡗࠬৗ")}], l1l1l_opy_ (u"ࡵࠨ࡮࡬ࡱ࡮ࡺࡳࠨ৘"):{l1l1l_opy_ (u"ࡶࠩࡶࡸࡦࡸࡴࠨ৙"): 0, l1l1l_opy_ (u"ࡷࠪࡸࡴࡺࡡ࡭ࠩ৚"): 1, l1l1l_opy_ (u"ࡸࠫࡪࡴࡤࠨ৛"): 1}}
    l1l1ll_opy_  = l1l1l_opy_ (u"ࠫࡠ࠭ড়") + addon + l1l1l_opy_ (u"ࠬࡣ࡜࡯ࠩঢ়")
    l1lll111_opy_  =  file(l1l1l1ll_opy_, l1l1l_opy_ (u"࠭ࡷࠨ৞"))
    l1lll111_opy_.write(l1l1ll_opy_)
    l1l1l111_opy_ = []
    for channel in l11llll_opy_:
        l1l1_opy_ = dixie.cleanLabel(channel[l1l1l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭য়")])
        l1l11ll_opy_   = dixie.cleanPrefix(l1l1_opy_)
        l11l1l_opy_ = dixie.mapChannelName(l1l11ll_opy_)
        stream   = channel[l1l1l_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ৠ")]
        l111l1_opy_ = l11l1l_opy_ + l1l1l_opy_ (u"ࠩࡀࠫৡ") + stream
        l1l1l111_opy_.append(l111l1_opy_)
        l1l1l111_opy_.sort()
    for item in l1l1l111_opy_:
        l1lll111_opy_.write(l1l1l_opy_ (u"ࠥࠩࡸࡢ࡮ࠣৢ") % item)
    l1lll111_opy_.close()
def l1llll11_opy_(addon):
    if (addon == l1llllll11_opy_) or (addon == l1lllll111_opy_):
        if xbmcaddon.Addon(addon).getSetting(l1l1l_opy_ (u"ࠫ࡬࡫࡮ࡳࡧࠪৣ")) == l1l1l_opy_ (u"ࠬࡺࡲࡶࡧࠪ৤"):
            xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"࠭ࡧࡦࡰࡵࡩࠬ৥"), l1l1l_opy_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭০"))
            xbmcgui.Window(10000).setProperty(l1l1l_opy_ (u"ࠨࡒࡏ࡙ࡌࡏࡎࡠࡉࡈࡒࡗࡋࠧ১"), l1l1l_opy_ (u"ࠩࡗࡶࡺ࡫ࠧ২"))
        if xbmcaddon.Addon(addon).getSetting(l1l1l_opy_ (u"ࠪࡸࡻ࡭ࡵࡪࡦࡨࠫ৩")) == l1l1l_opy_ (u"ࠫࡹࡸࡵࡦࠩ৪"):
            xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"ࠬࡺࡶࡨࡷ࡬ࡨࡪ࠭৫"), l1l1l_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬ৬"))
            xbmcgui.Window(10000).setProperty(l1l1l_opy_ (u"ࠧࡑࡎࡘࡋࡎࡔ࡟ࡕࡘࡊ࡙ࡎࡊࡅࠨ৭"), l1l1l_opy_ (u"ࠨࡖࡵࡹࡪ࠭৮"))
        l1llll1lll_opy_  = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ৯") + addon
        l111111ll_opy_ =  l1111l11l_opy_(addon)
        query   =  l1llll1lll_opy_ + l111111ll_opy_
        return sendJSON(query, addon)
    return l1llllllll_opy_(addon)
def l1llllllll_opy_(addon):
    if addon == l11111l1l_opy_:
        l11111111_opy_ = [l1l1l_opy_ (u"ࠪ࠵࠻࠷ࠧৰ"), l1l1l_opy_ (u"ࠫ࠶࠼࠰ࠨৱ"), l1l1l_opy_ (u"ࠬ࠸࠳࠷ࠩ৲"), l1l1l_opy_ (u"࠭࠲࠵࠴ࠪ৳"), l1l1l_opy_ (u"ࠧ࠲࠷࠻ࠫ৴"), l1l1l_opy_ (u"ࠨ࠳࠸࠽ࠬ৵")]
    if addon == l1llll1ll1_opy_:
        l11111111_opy_ = [l1l1l_opy_ (u"ࠩ࠸ࠫ৶"), l1l1l_opy_ (u"ࠪ࠵࠵࠼ࠧ৷"), l1l1l_opy_ (u"ࠫ࠹࠭৸"), l1l1l_opy_ (u"ࠬ࠸࠶࠴ࠩ৹"), l1l1l_opy_ (u"࠭࠱࠴࠴ࠪ৺")]
    if addon == locked:
        l11111111_opy_ = [l1l1l_opy_ (u"ࠧ࠴࠲ࠪ৻"), l1l1l_opy_ (u"ࠨ࠵࠴ࠫৼ"), l1l1l_opy_ (u"ࠩ࠶࠶ࠬ৽"), l1l1l_opy_ (u"ࠪ࠷࠸࠭৾"), l1l1l_opy_ (u"ࠫ࠸࠺ࠧ৿"), l1l1l_opy_ (u"ࠬ࠹࠵ࠨ਀"), l1l1l_opy_ (u"࠭࠳࠹ࠩਁ"), l1l1l_opy_ (u"ࠧ࠵࠲ࠪਂ"), l1l1l_opy_ (u"ࠨ࠶࠴ࠫਃ"), l1l1l_opy_ (u"ࠩ࠷࠹ࠬ਄"), l1l1l_opy_ (u"ࠪ࠸࠼࠭ਅ"), l1l1l_opy_ (u"ࠫ࠹࠿ࠧਆ"), l1l1l_opy_ (u"ࠬ࠻࠲ࠨਇ")]
    if addon == l1llll11ll_opy_:
        l11111111_opy_ = [l1l1l_opy_ (u"࠭࠲࠶ࠩਈ"), l1l1l_opy_ (u"ࠧ࠳࠸ࠪਉ"), l1l1l_opy_ (u"ࠨ࠴࠺ࠫਊ"), l1l1l_opy_ (u"ࠩ࠵࠽ࠬ਋"), l1l1l_opy_ (u"ࠪ࠷࠵࠭਌"), l1l1l_opy_ (u"ࠫ࠸࠷ࠧ਍"), l1l1l_opy_ (u"ࠬ࠹࠲ࠨ਎"), l1l1l_opy_ (u"࠭࠳࠶ࠩਏ"), l1l1l_opy_ (u"ࠧ࠴࠸ࠪਐ"), l1l1l_opy_ (u"ࠨ࠵࠺ࠫ਑"), l1l1l_opy_ (u"ࠩ࠶࠼ࠬ਒"), l1l1l_opy_ (u"ࠪ࠷࠾࠭ਓ"), l1l1l_opy_ (u"ࠫ࠹࠶ࠧਔ"), l1l1l_opy_ (u"ࠬ࠺࠱ࠨਕ"), l1l1l_opy_ (u"࠭࠴࠹ࠩਖ"), l1l1l_opy_ (u"ࠧ࠵࠻ࠪਗ"), l1l1l_opy_ (u"ࠨ࠷࠳ࠫਘ"), l1l1l_opy_ (u"ࠩ࠸࠶ࠬਙ"), l1l1l_opy_ (u"ࠪ࠹࠹࠭ਚ"), l1l1l_opy_ (u"ࠫ࠺࠼ࠧਛ"), l1l1l_opy_ (u"ࠬ࠻࠷ࠨਜ"), l1l1l_opy_ (u"࠭࠵࠹ࠩਝ"), l1l1l_opy_ (u"ࠧ࠶࠻ࠪਞ"), l1l1l_opy_ (u"ࠨ࠸࠳ࠫਟ"), l1l1l_opy_ (u"ࠩ࠹࠵ࠬਠ"), l1l1l_opy_ (u"ࠪ࠺࠷࠭ਡ"), l1l1l_opy_ (u"ࠫ࠻࠹ࠧਢ"), l1l1l_opy_ (u"ࠬ࠼࠵ࠨਣ"), l1l1l_opy_ (u"࠭࠶࠷ࠩਤ"), l1l1l_opy_ (u"ࠧ࠷࠹ࠪਥ"), l1l1l_opy_ (u"ࠨ࠸࠼ࠫਦ"), l1l1l_opy_ (u"ࠩ࠺࠴ࠬਧ"), l1l1l_opy_ (u"ࠪ࠻࠹࠭ਨ"), l1l1l_opy_ (u"ࠫ࠼࠽ࠧ਩"), l1l1l_opy_ (u"ࠬ࠽࠸ࠨਪ"), l1l1l_opy_ (u"࠭࠸࠱ࠩਫ"), l1l1l_opy_ (u"ࠧ࠹࠳ࠪਬ")]
    login = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸ࠵ࠧਭ") % addon
    sendJSON(login, addon)
    l11l111_opy_ = []
    for l1111l111_opy_ in l11111111_opy_:
        if (addon == l11111l1l_opy_) or (addon == l1llll1ll1_opy_):
            query = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠪࡹ࠯ࡀ࡯ࡲࡨࡪࡥࡩࡥ࠿ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪࡲࡵࡤࡦ࠿ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪࡸ࡫ࡣࡵ࡫ࡲࡲࡤ࡯ࡤ࠾ࠧࡶࠫਮ") % (addon, l1111l111_opy_)
        if (addon == locked) or (addon == l1llll11ll_opy_):
            query = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳ࠰ࡁࡸࡶࡱࡃࠥࡴࠨࡰࡳࡩ࡫࠽࠵ࠨࡱࡥࡲ࡫࠽ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡶ࡬ࡢࡻࡀࠪࡩࡧࡴࡦ࠿ࠩࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮࠾ࠨࡳࡥ࡬࡫࠽ࠨਯ") % (addon, l1111l111_opy_)
        response = sendJSON(query, addon)
        l11l111_opy_.extend(response)
    return l11l111_opy_
def sendJSON(query, addon):
    l11111l11_opy_     = l1l1l_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࠥࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧਰ") % query
    l1llllll1l_opy_  = xbmc.executeJSONRPC(l11111l11_opy_)
    response = json.loads(l1llllll1l_opy_)
    result   = response[l1l1l_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬ਱")]
    if xbmcgui.Window(10000).getProperty(l1l1l_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡇࡆࡐࡕࡉࠬਲ")) == l1l1l_opy_ (u"ࠧࡕࡴࡸࡩࠬਲ਼"):
        xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ਴"), l1l1l_opy_ (u"ࠩࡷࡶࡺ࡫ࠧਵ"))
    if xbmcgui.Window(10000).getProperty(l1l1l_opy_ (u"ࠪࡔࡑ࡛ࡇࡊࡐࡢࡘ࡛ࡍࡕࡊࡆࡈࠫਸ਼")) == l1l1l_opy_ (u"࡙ࠫࡸࡵࡦࠩ਷"):
        xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"ࠬࡺࡶࡨࡷ࡬ࡨࡪ࠭ਸ"), l1l1l_opy_ (u"࠭ࡴࡳࡷࡨࠫਹ"))
    return result[l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭਺")]
def l1111l11l_opy_(addon):
    if (addon == l1llllll11_opy_) or (addon == l1lllll111_opy_):
        return l1l1l_opy_ (u"ࠨ࠱ࡂࡧࡦࡺ࠽࠮࠴ࠩࡨࡦࡺࡥࠧࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠬࡥ࡯ࡦࡇࡥࡹ࡫ࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡲࡵࡤࡦ࠿࠵ࠪࡳࡧ࡭ࡦ࠿ࡐࡽࠪ࠸࠰ࡄࡪࡤࡲࡳ࡫࡬ࡴࠨࡵࡩࡨࡵࡲࡥࡰࡤࡱࡪࠬࡳࡵࡣࡵࡸࡉࡧࡴࡦࠨࡸࡶࡱࡃࡵࡳ࡮ࠪ਻")
    return l1l1l_opy_ (u"਼ࠩࠪ")
def l1l1llll_opy_():
    modules = map(__import__, [l1l11l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l1l1l_opy_ (u"ࠪࡘࡷࡻࡥࠨ਽")
    if len(modules[-1].Window(10**4).getProperty(l11lll_opy_)):
        return l1l1l_opy_ (u"࡙ࠫࡸࡵࡦࠩਾ")
    return l1l1l_opy_ (u"ࠬࡌࡡ࡭ࡵࡨࠫਿ")
def l1l1111l_opy_(e, addon):
    l1ll1111_opy_ = l1l1l_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠱ࠦࡡ࡯ࠢࡨࡶࡷࡵࡲࠡࡱࡦࡧࡺࡸࡥࡥ࠼ࠣࡎࡘࡕࡎࠡࡇࡵࡶࡴࡸ࠺ࠡࠧࡶ࠰ࠥࠫࡳࠨੀ")  % (e, addon)
    l11ll1l_opy_ = l1l1l_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡤࡱࡱࡸࡦࡩࡴࠡࡷࡶࠤࡴࡴࠠࡵࡪࡨࠤ࡫ࡵࡲࡶ࡯࠱ࠫੁ")
    l1ll11l1_opy_ = l1l1l_opy_ (u"ࠨࡗࡳࡰࡴࡧࡤࠡࡣࠣࡰࡴ࡭ࠠࡷ࡫ࡤࠤࡹ࡮ࡥࠡࡣࡧࡨࡴࡴࠠࡴࡧࡷࡸ࡮ࡴࡧࡴࠢࡤࡲࡩࠦࡰࡰࡵࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰ࠴ࠧੂ")
    dixie.log(addon)
    dixie.log(e)
def getPluginInfo(streamurl, kodiID=False):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l1llll11l1_opy_   = l1l1l_opy_ (u"ࠩࡎࡳࡩ࡯ࠠࡑࡘࡕࠫ੃")
            l1llll1l1l_opy_ = os.path.join(dixie.RESOURCES, l1l1l_opy_ (u"ࠪ࡯ࡴࡪࡩ࠮ࡲࡹࡶ࠳ࡶ࡮ࡨࠩ੄"))
            return l1llll11l1_opy_, l1llll1l1l_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l1l1l_opy_ (u"ࠫࡷࡺ࡭ࡱࠩ੅")) or url.startswith(l1l1l_opy_ (u"ࠬࡸࡴ࡮ࡲࡨࠫ੆")) or url.startswith(l1l1l_opy_ (u"࠭ࡲࡵࡵࡳࠫੇ")) or url.startswith(l1l1l_opy_ (u"ࠧࡩࡶࡷࡴࠬੈ")):
            l1llll11l1_opy_   = l1l1l_opy_ (u"ࠨ࡯࠶ࡹࠥࡖ࡬ࡢࡻ࡯࡭ࡸࡺࠧ੉")
            l1llll1l1l_opy_ = os.path.join(dixie.RESOURCES, l1l1l_opy_ (u"ࠩ࡬ࡴࡹࡼ࠭ࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡳࡲ࡬࠭੊"))
            return l1llll11l1_opy_, l1llll1l1l_opy_
    except:
        pass
    if streamurl.startswith(l1l1l_opy_ (u"ࠪࡴࡻࡸ࠺࠰࠱ࠪੋ")):
        l1llll11l1_opy_   = l1l1l_opy_ (u"ࠫࡐࡵࡤࡪࠢࡓ࡚ࡗ࠭ੌ")
        l1llll1l1l_opy_ = os.path.join(dixie.RESOURCES, l1l1l_opy_ (u"ࠬࡱ࡯ࡥ࡫࠰ࡴࡻࡸ࠮ࡱࡰࡪ੍ࠫ"))
        return l1llll11l1_opy_, l1llll1l1l_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        l1lllll1ll_opy_ = streamurl.split(l1l1l_opy_ (u"࠭࡝ࡐࡖࡗࡣࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ੎"), 1)[-1].split(l1l1l_opy_ (u"ࠧ࠰ࠩ੏"), 1)[0]
    if l1l1l_opy_ (u"ࠨ࡟ࡒࡘ࡙ࡥࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ੐") in streamurl:
        l1lllll1ll_opy_ = streamurl.split(l1l1l_opy_ (u"ࠩࡠࡓ࡙࡚࡟ࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪੑ"), 1)[-1].split(l1l1l_opy_ (u"ࠪ࠳ࠬ੒"), 1)[0]
    if streamurl.startswith(l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ੓")):
        l1lllll1ll_opy_ = streamurl.split(l1l1l_opy_ (u"ࠬ࠵࠯ࠨ੔"), 1)[-1].split(l1l1l_opy_ (u"࠭࠯ࠨ੕"), 1)[0]
    if l1l1l_opy_ (u"ࠧࡈࡕࡓࡖ࡙࡙࠺ࠨ੖") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡨ࡫ࡽࡱࡴࡹࡰࡰࡴࡷࡷࠬ੗")
    if l1l1l_opy_ (u"ࠩࡢࡣࡘࡌ࡟ࡠࠩ੘") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡴࡷࡵࡧࡳࡣࡰ࠲ࡸࡻࡰࡦࡴ࠱ࡪࡦࡼ࡯ࡶࡴ࡬ࡸࡪࡹࠧਖ਼")
    if l1l1l_opy_ (u"ࠫࡑࡏࡍ࠳࠼ࠪਗ਼") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡑ࡯࡭ࡪࡶ࡯ࡩࡸࡹࡖ࠳ࠩਜ਼")
    if l1l1l_opy_ (u"࠭ࡎࡂࡖࡋ࠾ࠬੜ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡎࡢࡶ࡫ࡳ࠳ࡏࡐࡕࡘࠪ੝")
    if l1l1l_opy_ (u"ࠨࡐࡌࡇࡊࡀࠧਫ਼") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡰࡤࡸ࡭ࡵࡳࡶࡤࡶ࡭ࡨ࡫ࠧ੟")
    if l1l1l_opy_ (u"ࠪࡔࡗࡋࡍ࠻ࠩ੠") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡴࡷ࡫࡭ࡪࡷࡰ࡭ࡵࡺࡶࠨ੡")
    if l1l1l_opy_ (u"ࠬࡍࡉ࡛࠼ࠪ੢") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡭ࡩࡻ࡯ࡲࡸࡻ࠭੣")
    if l1l1l_opy_ (u"ࠧࡈࡇࡋ࠾ࠬ੤") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡨࡧ࡫ࡳࡸࡺࡩ࡯ࡩࠪ੥")
    if l1l1l_opy_ (u"ࠩࡐࡘ࡝ࡏࡅ࠻ࠩ੦") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡰࡥࡹࡸࡩࡹ࡫ࡵࡩࡱࡧ࡮ࡥࠩ੧")
    if l1l1l_opy_ (u"࡙ࠫ࡜ࡋ࠻ࠩ੨") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡹࡼ࡫ࡪࡰࡪࡷࠬ੩")
    if l1l1l_opy_ (u"࠭ࡘࡕࡅ࠽ࠫ੪") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸࡵࡴࡨࡥࡲ࠳ࡣࡰࡦࡨࡷࠬ੫")
    if l1l1l_opy_ (u"ࠨࡕࡆࡘ࡛ࡀࠧ੬") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡦࡸࡻ࠭੭")
    if l1l1l_opy_ (u"ࠪࡗ࡚ࡖ࠺ࠨ੮") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡹࡸࡥࡢ࡯ࡶࡹࡵࡸࡥ࡮ࡧ࠵ࠫ੯")
    if l1l1l_opy_ (u"࡛ࠬࡋࡕ࠼ࠪੰ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡻ࡫ࡵࡷࡵ࡯ࠬੱ")
    if l1l1l_opy_ (u"ࠧࡍࡋࡐࡍ࡙ࡀࠧੲ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡍ࡫ࡰ࡭ࡹࡲࡥࡴࡵࡌࡔ࡙࡜ࠧੳ")
    if l1l1l_opy_ (u"ࠩࡉࡅࡇࡀࠧੴ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡩࡥࡧ࡮࡯ࡴࡶ࡬ࡲ࡬࠭ੵ")
    if l1l1l_opy_ (u"ࠫࡆࡉࡅ࠻ࠩ੶") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡩࡥࡵࡸࠪ੷")
    if l1l1l_opy_ (u"࠭ࡈࡐࡔࡌ࡞࠿࠭੸") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡨࡰࡴ࡬ࡾࡴࡴࡩࡱࡶࡹࠫ੹")
    if l1l1l_opy_ (u"ࠨࡔࡒࡓ࡙࠸࠺ࠨ੺") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡲࡳࡹࡏࡐࡕࡘࠪ੻")
    if l1l1l_opy_ (u"ࠪࡑࡊࡍࡁ࠻ࠩ੼") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡱࡪ࡭ࡡࡪࡲࡷࡺࠬ੽")
    if l1l1l_opy_ (u"ࠬ࡜ࡄࡓࡖ࡙࠾ࠬ੾") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡜ࡁࡅࡇࡕࠫ੿")
    if l1l1l_opy_ (u"ࠧࡉࡆࡗ࡚࠿࠭઀") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴ࡯ࡤࡶࡹ࡮ࡵࡣࠩઁ")
    if l1l1l_opy_ (u"ࠩࡋࡈ࡙࡜࠲࠻ࠩં") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧ࠲ࠨઃ")
    if l1l1l_opy_ (u"ࠫࡍࡊࡔࡗ࠵࠽ࠫ઄") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢ࠴ࠪઅ")
    if l1l1l_opy_ (u"࠭ࡈࡅࡖ࡙࠸࠿࠭આ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸ࡭ࠩઇ")
    if l1l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠺ࠨઈ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡤࡥࡧ࡮ࡶ࡬ࡢࡻࡨࡶࠬઉ")
    if l1l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠴࠽ࠫઊ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽࠧઋ")
    if l1l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖ࠿࠭ઌ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰ࡭ࡣࡼࡩࡷࡽࡷࡸࠩઍ")
    if l1l1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡏࡔࡗ࠼ࠪ઎") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡶࡹࠫએ")
    if l1l1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪઐ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡧࡩࡽ࠭ઑ")
    if l1l1l_opy_ (u"ࠫࡏࡏࡎ࡙࠴࠽ࠫ઒") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡯࡯࡮ࡹࡶࡹ࠶ࠬઓ")
    if l1l1l_opy_ (u"࠭ࡍࡂࡖࡖ࠾ࠬઔ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡍࡢࡶࡶࡆࡺ࡯࡬ࡥࡵࡌࡔ࡙࡜ࠧક")
    if l1l1l_opy_ (u"ࠨࡔࡒࡓ࡙ࡀࠧખ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡲࡳࡹ࡯ࡰࡵࡸࠪગ")
    if l1l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡔࡅ࠾ࠬઘ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡪࡨ࡯ࡰࡶࠪઙ")
    if l1l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡇࡑ࡛࠺ࠨચ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡩ࡬ࡶ࡫ࡳࡸࡻ࠭છ")
    if l1l1l_opy_ (u"ࠧࡊࡒࡗࡗࠬજ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲࡷࡺࡸࡻࡢࡴࠩઝ")
    if l1l1l_opy_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠼ࠪઞ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡯࡭ࡻ࡫࡭ࡪࡺࠪટ")
    if l1l1l_opy_ (u"ࠫࡊࡔࡄ࠻ࠩઠ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡊࡴࡤ࡭ࡧࡶࡷࠬડ")
    if l1l1l_opy_ (u"࠭ࡆࡍࡃ࠽ࠫઢ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡆ࡭ࡣࡺࡰࡪࡹࡳࡕࡸࠪણ")
    if l1l1l_opy_ (u"ࠨࡏࡄ࡜ࡎࡀࠧત") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡯ࡤࡼ࡮ࡽࡥࡣࡶࡹࠫથ")
    if l1l1l_opy_ (u"ࠪࡊࡑࡇࡓ࠻ࠩદ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡊࡱࡧࡷ࡭ࡧࡶࡷ࡙ࡼࠧધ")
    if l1l1l_opy_ (u"࡙ࠬࡐࡓࡏ࠽ࠫન") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡙ࡵࡱࡴࡨࡱࡦࡩࡹࡕࡘࠪ઩")
    if l1l1l_opy_ (u"ࠧࡎࡅࡎࡘ࡛ࡀࠧપ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡮ࡥ࡮ࡸࡻ࠳ࡰ࡭ࡷࡶࠫફ")
    if l1l1l_opy_ (u"ࠩࡗ࡛ࡎ࡙ࡔ࠻ࠩબ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡷࡻ࡮ࡹࡴࡦࡦࠪભ")
    if l1l1l_opy_ (u"ࠫࡕࡘࡅࡔࡖ࠽ࠫમ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡵࡹࡡࡥࡦࡲࡲࠬય")
    if l1l1l_opy_ (u"࠭ࡂࡍࡍࡌ࠾ࠬર") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡂ࡭ࡣࡦ࡯ࡎࡩࡥࡕࡘࠪ઱")
    if l1l1l_opy_ (u"ࠨࡈࡕࡉࡊࡀࠧલ") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡨࡵࡩࡪࡼࡩࡦࡹࠪળ")
    if l1l1l_opy_ (u"ࠪࡹࡵࡴࡰ࠻ࠩ઴") in streamurl:
        l1lllll1ll_opy_ = l1l1l_opy_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲࡭ࡪࡨࡰ࡯ࡨࡶࡺࡴ࠮ࡷ࡫ࡨࡻࠬવ")
    return l111111l1_opy_(l1lllll1ll_opy_, kodiID)
def l111111l1_opy_(l1lllll1ll_opy_, kodiID):
    l1llll11l1_opy_     = l1l1l_opy_ (u"ࠬ࠭શ")
    l1llll1l1l_opy_   = l1l1l_opy_ (u"࠭ࠧષ")
    try:
        l1111l1l1_opy_ = xbmcaddon.Addon(l1lllll1ll_opy_).getAddonInfo(l1l1l_opy_ (u"ࠧ࡯ࡣࡰࡩࠬસ"))
        l1llll11l1_opy_    = dixie.cleanLabel(l1111l1l1_opy_)
        l1llll1l1l_opy_  = xbmcaddon.Addon(l1lllll1ll_opy_).getAddonInfo(l1l1l_opy_ (u"ࠨ࡫ࡦࡳࡳ࠭હ"))
        if kodiID:
            l1llll1l11_opy_ = xbmcaddon.Addon(l1lllll1ll_opy_).getAddonInfo(l1l1l_opy_ (u"ࠩ࡬ࡨࠬ઺"))
            return l1llll11l1_opy_, l1llll1l11_opy_
        return l1llll11l1_opy_, l1llll1l1l_opy_
    except:
        l1llll11l1_opy_   = l1l1l_opy_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡘࡵࡵࡳࡥࡨࠫ઻")
        l1llll1l1l_opy_ =  dixie.ICON
        return l1llll11l1_opy_, l1llll1l1l_opy_
    return l1llll11l1_opy_, l1llll1l1l_opy_
def selectStream(url, channel):
    l1llll111l_opy_ = url.split(l1l1l_opy_ (u"ࠫࢁ઼࠭"))
    if len(l1llll111l_opy_) == 0:
        return None
    options, l1l1l11l_opy_ = getOptions(l1llll111l_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l1llll111l_opy_) == 1:
            return l1l1l11l_opy_[0]
    import selectDialog
    l1lllllll1_opy_ = selectDialog.select(l1l1l_opy_ (u"࡙ࠬࡥ࡭ࡧࡦࡸࠥࡧࠠࡴࡶࡵࡩࡦࡳࠧઽ"), options)
    if l1lllllll1_opy_ < 0:
        raise Exception(l1l1l_opy_ (u"࠭ࡓࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡆࡥࡳࡩࡥ࡭ࠩા"))
    return l1l1l11l_opy_[l1lllllll1_opy_]
def getOptions(l1llll111l_opy_, channel, addmore=True):
    options = []
    l1l1l11l_opy_    = []
    for index, stream in enumerate(l1llll111l_opy_):
        l1llll11l1_opy_ = getPluginInfo(stream)
        l1llll1_opy_ = l1l1l_opy_ (u"ࠧࠨિ")
        l1lllll11l_opy_  = l1llll11l1_opy_[1]
        if stream.startswith(OPEN_OTT):
            l111lll1l_opy_ = stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l1l1l_opy_ (u"ࠨࠩી"))
            l1llll1_opy_  = l1llll1_opy_ + l111lll1l_opy_
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l1l1l_opy_ (u"ࠩࠪુ"))
        else:
            l1llll1_opy_  = l1llll1_opy_ + channel
        options.append([l1llll1_opy_, index, l1lllll11l_opy_])
        l1l1l11l_opy_.append(stream)
    if addmore:
        options.append([l1l1l_opy_ (u"ࠪࡅࡩࡪࠠ࡮ࡱࡵࡩ࠳࠴࠮ࠨૂ"), index + 1, dixie.ICON])
        l1l1l11l_opy_.append(l1l1l_opy_ (u"ࠫࡦࡪࡤࡎࡱࡵࡩࠬૃ"))
    return options, l1l1l11l_opy_
if __name__ == l1l1l_opy_ (u"ࠬࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠧૄ"):
    checkAddons()