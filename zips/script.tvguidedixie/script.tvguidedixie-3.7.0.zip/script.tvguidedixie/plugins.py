# coding: UTF-8
import sys
l1111_opy_ = sys.version_info [0] == 2
l11l11_opy_ = 2048
l11l1_opy_ = 7
def l111ll_opy_ (l11l1l_opy_):
	global l11111_opy_
	l11lll_opy_ = ord (l11l1l_opy_ [-1])
	l11ll_opy_ = l11l1l_opy_ [:-1]
	l1111l_opy_ = l11lll_opy_ % len (l11ll_opy_)
	l1l1l1_opy_ = l11ll_opy_ [:l1111l_opy_] + l11ll_opy_ [l1111l_opy_:]
	if l1111_opy_:
		l1l1ll_opy_ = unicode () .join ([unichr (ord (char) - l11l11_opy_ - (l1l1l_opy_ + l11lll_opy_) % l11l1_opy_) for l1l1l_opy_, char in enumerate (l1l1l1_opy_)])
	else:
		l1l1ll_opy_ = str () .join ([chr (ord (char) - l11l11_opy_ - (l1l1l_opy_ + l11lll_opy_) % l11l1_opy_) for l1l1l_opy_, char in enumerate (l1l1l1_opy_)])
	return eval (l1l1ll_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l1l1lllll_opy_    = l111ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡲࡹࡼࠧ൜")
l1ll1ll11_opy_    = l111ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡶࡴ࡮ࠫ൝")
locked = l111ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲ࡯ࡤ࡭ࡨࡨࡹࡼࠧ൞")
l1lll11l1_opy_   = l111ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡵࡴࡨࡥࡲࡺࡶࡣࡱࡻࠫൟ")
l1l1l11l1_opy_     = l111ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡲࡲࡶࡹࡹ࡭ࡢࡰ࡬ࡥࠬൠ")
l1lll111l_opy_     = l111ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡳࡳࡷࡺࡳ࡯ࡣࡷ࡭ࡴࡴࡨࡥࡶࡹࠫൡ")
l1l1l1ll1_opy_     = l111ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸࡰࡹ࡯࡭ࡢࡶࡨࡱࡦࡴࡩࡢࠩൢ")
l1l11llll_opy_   = l111ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰ࡮ࡻࡸ࠯ࡶࡹࠫൣ")
l1l1lll11_opy_    = l111ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡉࡉࡓࡱࡱࡵࡸࡸ࠭൤")
l11lll1l1l_opy_ = l111ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡥࡣࡱࡲࡸࠬ൥")
l11lll111l_opy_    = l111ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡣ࡭ࡷ࡬ࡴࡹࡼࠧ൦")
l1l1l111l_opy_ = [l1ll1ll11_opy_, l1l1lllll_opy_, l1l11llll_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l111ll_opy_ (u"ࠨ࡫ࡱ࡭ࠬ൧"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l11lll1lll_opy_ = l111ll_opy_ (u"ࠩࠪ൨")
def l11lll1111_opy_(i, t1, l11lll1ll1_opy_=[]):
 t = l11lll1lll_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l11lll1ll1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11llll11l_opy_ = l11lll1111_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
def checkAddons():
    if not l11lll1l11_opy_() == l111ll_opy_ (u"ࠪࡘࡷࡻࡥࠨ൩"):
        return
    for addon in l1l1l111l_opy_:
        if l1ll11l11_opy_(addon):
            try: l1ll11l1l_opy_(addon)
            except: pass
def l1ll11l11_opy_(addon):
    if xbmc.getCondVisibility(l111ll_opy_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡍࡧࡳࡂࡦࡧࡳࡳ࠮ࠥࡴࠫࠪ൪") % addon) == 1:
        return True
    return False
def l1ll11l1l_opy_(addon):
    l1ll1llll_opy_ = str(addon).split(l111ll_opy_ (u"ࠬ࠴ࠧ൫"))[2] + l111ll_opy_ (u"࠭࠮ࡪࡰ࡬ࠫ൬")
    l1l1l11ll_opy_  = os.path.join(PATH, l1ll1llll_opy_)
    l1lll1111_opy_ = l1lll1l11_opy_(addon)
    l1l1ll1l1_opy_  = file(l1l1l11ll_opy_, l111ll_opy_ (u"ࠧࡸࠩ൭"))
    l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠨ࡝ࠪ൮"))
    l1l1ll1l1_opy_.write(addon)
    l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠩࡠࠫ൯"))
    l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠪࡠࡳ࠭൰"))
    for channel in l1lll1111_opy_:
        l1ll1l111_opy_  = channel[l111ll_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪ൱")]
        l1ll1l111_opy_  = l1ll1l111_opy_.replace(l111ll_opy_ (u"ࠬ࠴࠮࠯࠰࠱ࠫ൲"), l111ll_opy_ (u"࠭ࠧ൳")).replace(l111ll_opy_ (u"ࠧ࠻ࠩ൴"), l111ll_opy_ (u"ࠨࠩ൵")).replace(l111ll_opy_ (u"ࠩࠣ࡟ࠬ൶"), l111ll_opy_ (u"ࠪ࡟ࠬ൷")).replace(l111ll_opy_ (u"ࠫࡢࠦࠧ൸"), l111ll_opy_ (u"ࠬࡣࠧ൹")).replace(l111ll_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡡࡲࡷࡤࡡࠬൺ"), l111ll_opy_ (u"ࠧࠨൻ")).replace(l111ll_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬ࡱࡪ࡭ࡲࡦࡧࡱࡡࠬർ"), l111ll_opy_ (u"ࠩࠪൽ")).replace(l111ll_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡷ࡫ࡥ࡯࡟ࠪൾ"), l111ll_opy_ (u"ࠫࠬൿ")).replace(l111ll_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡿࡥ࡭࡮ࡲࡻࡢ࠭඀"), l111ll_opy_ (u"࠭ࠧඁ")).replace(l111ll_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢ࠭ං"), l111ll_opy_ (u"ࠨࠩඃ")).replace(l111ll_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡲࡶࡦࡴࡧࡦ࡟ࠪ඄"), l111ll_opy_ (u"ࠪࠫඅ")).replace(l111ll_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞ࠩආ"), l111ll_opy_ (u"ࠬ࠭ඇ")).replace(l111ll_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡷࡩ࡫ࡷࡩࡢ࠭ඈ"), l111ll_opy_ (u"ࠧࠨඉ")).replace(l111ll_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪඊ"), l111ll_opy_ (u"ࠩࠪඋ")).replace(l111ll_opy_ (u"ࠪ࡟ࡎࡣࠧඌ"), l111ll_opy_ (u"ࠫࠬඍ")).replace(l111ll_opy_ (u"ࠬࡡ࠯ࡊ࡟ࠪඎ"), l111ll_opy_ (u"࠭ࠧඏ")).replace(l111ll_opy_ (u"ࠧ࡜ࡄࡠࠫඐ"), l111ll_opy_ (u"ࠨࠩඑ")).replace(l111ll_opy_ (u"ࠩ࡞࠳ࡇࡣࠧඒ"), l111ll_opy_ (u"ࠪࠫඓ"))
        stream = channel[l111ll_opy_ (u"ࠫ࡫࡯࡬ࡦࠩඔ")]
        l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠬࠫࡳࠨඕ") % l1ll1l111_opy_)
        l1l1ll1l1_opy_.write(l111ll_opy_ (u"࠭࠽ࠨඖ"))
        l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠧࠦࡵࠪ඗") % stream)
        l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠨ࡞ࡱࠫ඘"))
    l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠩ࡟ࡲࠬ඙"))
    l1l1ll1l1_opy_.close()
def l1lll1l11_opy_(addon):
    if addon == l1ll1ll11_opy_:
        return l1l1llll1_opy_(addon)
    if addon == l1l1lll11_opy_:
        return l1ll1lll1_opy_(addon)
    try:
        if xbmcaddon.Addon(addon).getSetting(l111ll_opy_ (u"ࠪ࡫ࡪࡴࡲࡦࠩක")) == l111ll_opy_ (u"ࠫࡹࡸࡵࡦࠩඛ"):
            xbmcaddon.Addon(addon).setSetting(l111ll_opy_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫග"), l111ll_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬඝ"))
            xbmcgui.Window(10000).setProperty(l111ll_opy_ (u"ࠧࡑࡎࡘࡋࡎࡔ࡟ࡈࡇࡑࡖࡊ࠭ඞ"), l111ll_opy_ (u"ࠨࡖࡵࡹࡪ࠭ඟ"))
        if xbmcaddon.Addon(addon).getSetting(l111ll_opy_ (u"ࠩࡷࡺ࡬ࡻࡩࡥࡧࠪච")) == l111ll_opy_ (u"ࠪࡸࡷࡻࡥࠨඡ"):
            xbmcaddon.Addon(addon).setSetting(l111ll_opy_ (u"ࠫࡹࡼࡧࡶ࡫ࡧࡩࠬජ"), l111ll_opy_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫඣ"))
            xbmcgui.Window(10000).setProperty(l111ll_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡔࡗࡉࡘࡍࡉࡋࠧඤ"), l111ll_opy_ (u"ࠧࡕࡴࡸࡩࠬඥ"))
    except: pass
    l1l1ll11l_opy_  = l111ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫඦ") + addon
    l1ll11ll1_opy_ =  l1lll11ll_opy_(addon)
    query   =  l1l1ll11l_opy_ + l1ll11ll1_opy_
    return sendJSON(query, addon)
def l1l1l1l1l_opy_(addon):
    l1ll11111_opy_   =  []
    query    = l111ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬට") + addon
    response =  sendJSON(query, addon)
    for item in response:
        if not l111ll_opy_ (u"ࠪ࠲ࠬඨ") in item[l111ll_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪඩ")]:
            l1ll11111_opy_.append(item[l111ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪඪ")])
    l1ll111ll_opy_ = []
    for l1l1lll1l_opy_ in l1ll11111_opy_:
        response = sendJSON(l1l1lll1l_opy_, addon)
        l1ll111ll_opy_.extend(response)
    return l1ll111ll_opy_
def l1l1llll1_opy_(addon):
    l1l1ll11l_opy_ = l111ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩණ") + addon
    l1l11lll1_opy_  = l111ll_opy_ (u"ࠧࡀࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿࡫ࡸࡹࡶࠥ࠴ࡣࠨ࠶࡫ࠫ࠲ࡧ࡯ࡨࡸࡦࡲ࡫ࡦࡶࡷࡰࡪ࠴ࡣࡰࠧ࠵ࡪ࡚ࡑࡔࡶࡴ࡮࠵࠽࠶࠲࠳࠲࠴࠺ࠪ࠸ࡦࡵࡪࡸࡱࡧࡹࠥ࠳ࡨࡱࡩࡼࠫ࠲ࡧࡗ࡮ࠩ࠷࠻࠲࠱ࡶࡸࡶࡰࠫ࠲࠶࠴࠳ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠥ࠳࠷࠵࠴ࡱ࡯ࡶࡦࠧ࠵࠹࠷࠶ࡴࡷ࠰࡭ࡴ࡬ࠬ࡭ࡰࡦࡨࡁ࠶ࠬ࡮ࡢ࡯ࡨࡁࡑ࡯ࡶࡦࠧ࠵࠴࡙࡜ࠦࡶࡴ࡯ࡁ࡭ࡺࡴࡱࠧ࠶ࡥࠪ࠸ࡦࠦ࠴ࡩࡱࡪࡺࡡ࡭࡭ࡨࡸࡹࡲࡥ࠯ࡥࡲࠩ࠷࡬ࡕࡌࡖࡸࡶࡰ࠷࠸࠱࠴࠵࠴࠶࠼ࠥ࠳ࡨࡏ࡭ࡻ࡫ࠥ࠳࠷࠵࠴࡙࡜࠮ࡵࡺࡷࠫඬ")
    l1ll111ll_opy_  = []
    l1ll111ll_opy_ += sendJSON(l1l1ll11l_opy_ + l1l11lll1_opy_, addon)
    l1ll111ll_opy_.sort()
    return l1ll111ll_opy_
def l1ll1lll1_opy_(addon):
    l1l1ll11l_opy_ = l111ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫත") + addon
    l1l11lll1_opy_ = l111ll_opy_ (u"ࠩ࠲ࡃ࡫ࡧ࡮ࡢࡴࡷࡁ࡭ࡺࡴࡱࠧ࠶ࡥࠪ࠸ࡦࠦ࠴ࡩ࡫ࡴࡵ࠮ࡨ࡮ࠨ࠶࡫࡞ࡤࡇ࠴࠻ࡘࠫࡳ࡯ࡥࡧࡀ࠵ࠫࡴࡡ࡮ࡧࡀࡐ࡮ࡼࡥࠦ࠴࠳࡙ࡐࠫ࠲࠱ࡕࡳࡳࡷࡺࡳࠧࡷࡵࡰࡂ࡮ࡴࡵࡲࡶࠩ࠸ࡧࠥ࠳ࡨࠨ࠶࡫࡭࡯ࡰ࠰ࡪࡰࠪ࠸ࡦ࠶ࡳࡔ࡫ࡊ࠺ࠧථ")
    l1l1l1111_opy_ = l111ll_opy_ (u"ࠪ࠳ࡄ࡬ࡡ࡯ࡣࡵࡸࡂ࡮ࡴࡵࡲࡶࠩ࠸ࡧࠥ࠳ࡨࠨ࠶࡫࡭࡯ࡰ࠰ࡪࡰࠪ࠸ࡦࡇࡩ࡚ࡑࡰࡠࠦ࡮ࡱࡧࡩࡂ࠷ࠦ࡯ࡣࡰࡩࡂࡒࡩࡷࡧࠨ࠶࠵࡛ࡓࠦ࠴ࡩࡇࡆࡔࠥ࠳࠲ࡖࡴࡴࡸࡴࡴࠨࡸࡶࡱࡃࡨࡵࡶࡳࡷࠪ࠹ࡡࠦ࠴ࡩࠩ࠷࡬ࡧࡰࡱ࠱࡫ࡱࠫ࠲ࡧࡨ࠼࡮࡬࠾ࡎࠨද")
    l1ll111ll_opy_  = []
    l1ll111ll_opy_ += sendJSON(l1l1ll11l_opy_ + l1l11lll1_opy_, addon)
    l1ll111ll_opy_ += sendJSON(l1l1ll11l_opy_ + l1l1l1111_opy_, addon)
    return l1ll111ll_opy_
def l1lll11ll_opy_(addon):
    if addon == l1l1lllll_opy_:
        return l111ll_opy_ (u"ࠫ࠴ࡅࡣࡢࡶࡀ࠱࠷ࠬ࡭ࡰࡦࡨࡁ࠷ࠬ࡮ࡢ࡯ࡨࡁࡒࡿࠥ࠳࠲ࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪࡺࡸ࡬࠾ࡷࡵࡰࠬධ")
    return l111ll_opy_ (u"ࠬ࠭න")
def l11lll1l11_opy_():
    modules = map(__import__, [l11lll1111_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if not len(modules[-1].Window(10**4).getProperty(l11llll11l_opy_)):
        return l111ll_opy_ (u"࠭ࡆࡢ࡮ࡶࡩࠬ඲")
    return l111ll_opy_ (u"ࠧࡕࡴࡸࡩࠬඳ")
def sendJSON(query, addon):
    try:
        l1ll11lll_opy_     = l111ll_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫප") % query
        l1ll1111l_opy_  = xbmc.executeJSONRPC(l1ll11lll_opy_)
        response = json.loads(l1ll1111l_opy_)
        if xbmcgui.Window(10000).getProperty(l111ll_opy_ (u"ࠩࡓࡐ࡚ࡍࡉࡏࡡࡊࡉࡓࡘࡅࠨඵ")) == l111ll_opy_ (u"ࠪࡘࡷࡻࡥࠨබ"):
            xbmcaddon.Addon(addon).setSetting(l111ll_opy_ (u"ࠫ࡬࡫࡮ࡳࡧࠪභ"), l111ll_opy_ (u"ࠬࡺࡲࡶࡧࠪම"))
            xbmcgui.Window(10000).clearProperty(l111ll_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡇࡆࡐࡕࡉࠬඹ"))
        if xbmcgui.Window(10000).getProperty(l111ll_opy_ (u"ࠧࡑࡎࡘࡋࡎࡔ࡟ࡕࡘࡊ࡙ࡎࡊࡅࠨය")) == l111ll_opy_ (u"ࠨࡖࡵࡹࡪ࠭ර"):
            xbmcaddon.Addon(addon).setSetting(l111ll_opy_ (u"ࠩࡷࡺ࡬ࡻࡩࡥࡧࠪ඼"), l111ll_opy_ (u"ࠪࡸࡷࡻࡥࠨල"))
            xbmcgui.Window(10000).clearProperty(l111ll_opy_ (u"ࠫࡕࡒࡕࡈࡋࡑࡣ࡙࡜ࡇࡖࡋࡇࡉࠬ඾"))
        return response[l111ll_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬ඿")][l111ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬව")]
    except Exception as e:
        l1l1ll1ll_opy_(e, addon)
        return {l111ll_opy_ (u"ࠧࡆࡴࡵࡳࡷ࠭ශ") : l111ll_opy_ (u"ࠨࡒ࡯ࡹ࡬࡯࡮ࠡࡇࡵࡶࡴࡸࠧෂ")}
def l1l1ll1ll_opy_(e, addon):
    l1ll1l11l_opy_ = l111ll_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠭ࠢࡤࡲࠥ࡫ࡲࡳࡱࡵࠤࡴࡩࡣࡶࡴࡨࡨ࠿ࠦࡊࡔࡑࡑࠤࡊࡸࡲࡰࡴ࠽ࠤࠪࡹࠬࠡࠧࡶࠫස")  % (e, addon)
    l1ll1l1l1_opy_ = l111ll_opy_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡧࡴࡴࡴࡢࡥࡷࠤࡺࡹࠠࡰࡰࠣࡸ࡭࡫ࠠࡧࡱࡵࡹࡲ࠴ࠧහ")
    l1ll1l1ll_opy_ = l111ll_opy_ (u"࡚ࠫࡶ࡬ࡰࡣࡧࠤࡦࠦ࡬ࡰࡩࠣࡺ࡮ࡧࠠࡵࡪࡨࠤࡦࡪࡤࡰࡰࠣࡷࡪࡺࡴࡪࡰࡪࡷࠥࡧ࡮ࡥࠢࡳࡳࡸࡺࠠࡵࡪࡨࠤࡱ࡯࡮࡬࠰ࠪළ")
    dixie.log(addon)
    dixie.log(e)
def getPlaylist():
    import requests
    l1ll111l1_opy_ = [l111ll_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲ࡌࡊࡠ࠵࡛ࡻ࡬ࡎࡪ࡝ࠧෆ"), l111ll_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳ࡽ࡬࠵ࡊ࠵ࡋࡓࡩ࡟ࡎࠨ෇"), l111ll_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡹ࠰ࡦࡳ࠴࡛ࡌࡤ࠲࠴ࡑࡔࡒࡧࡄࠩ෈"), l111ll_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡺ࠱ࡧࡴ࠵ࡪࡶࡐࡐࡒ࡬ࡽࡪࡑ࠲ࠪ෉"), l111ll_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡻ࠲ࡨࡵ࠯ࡥ࡬ࡅࡥ࠶ࡴࡶ࠺ࡉࡽ්ࠫ"), l111ll_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡼ࠳ࡩ࡯࠰ࡰ࡙ࡷࡶࡩࡧࡤࡥ࠼ࡽࠬ෋"), l111ll_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱ࡻࡐࡈ࠿࠴ࡆࡘࡔࡺ࡞࠭෌"), l111ll_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲ࡸࡸࡋ࠳ࡋࡒࡷࡪࡒࡸࠧ෍"), l111ll_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳ࡪ࡜ࡖࡂࡹࡎࡍࡸ࡙ࡨࠨ෎"), l111ll_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡹ࠰ࡦࡳ࠴ࡾࡑࡱࡈࡍ࡛࡬࡯ࡧ࡫ࠩා")]
    l1l1ll111_opy_ =  l111ll_opy_ (u"ࠨࠥࡈ࡜࡙ࡓ࠳ࡖࠩැ")
    for url in l1ll111l1_opy_:
        try:
            request  = requests.get(url)
            l1ll1ll1l_opy_ = request.text
        except: pass
        if l1l1ll111_opy_ in l1ll1ll1l_opy_:
            path = os.path.join(dixie.PROFILE, l111ll_opy_ (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡲ࠹ࡵࠨෑ"))
            with open(path, l111ll_opy_ (u"ࠪࡻࠬි")) as f:
                f.write(l1ll1ll1l_opy_)
                break
def getPluginInfo(streamurl):
    if not l11lll1l11_opy_() == l111ll_opy_ (u"࡙ࠫࡸࡵࡦࠩී"):
        return
    if streamurl.isdigit():
        l1l1l1l11_opy_   = l111ll_opy_ (u"ࠬࡑ࡯ࡥ࡫ࠣࡔ࡛ࡘࠠࡄࡪࡤࡲࡳ࡫࡬ࠨු")
        l1l1l1lll_opy_ = os.path.join(dixie.RESOURCES, l111ll_opy_ (u"࠭࡫ࡰࡦ࡬࠱ࡵࡼࡲ࠯ࡲࡱ࡫ࠬ෕"))
        return l1l1l1l11_opy_, l1l1l1lll_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        name = streamurl.split(l111ll_opy_ (u"ࠧ࡞ࡑࡗࡘࡤࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨූ"), 1)[-1].split(l111ll_opy_ (u"ࠨ࠱ࠪ෗"), 1)[0]
    if streamurl.startswith(l111ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬෘ")):
        name = streamurl.split(l111ll_opy_ (u"ࠪ࠳࠴࠭ෙ"), 1)[-1].split(l111ll_opy_ (u"ࠫ࠴࠭ේ"), 1)[0]
    if l111ll_opy_ (u"ࠬࡥ࡟ࡔࡈࡢࡣࠬෛ") in streamurl:
        name = l111ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡰࡳࡱࡪࡶࡦࡳ࠮ࡴࡷࡳࡩࡷ࠴ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵࠪො")
    if l111ll_opy_ (u"ࠧࡉࡆࡗ࡚࠿࠭ෝ") in streamurl:
        name = l111ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡩࡦࡷࡺࠬෞ")
    if l111ll_opy_ (u"ࠩࡋࡈ࡙࡜࠲࠻ࠩෟ") in streamurl:
        name = l111ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧࡩࡱࡶࡹࠫ෠")
    if l111ll_opy_ (u"ࠫࡍࡊࡔࡗ࠵࠽ࠫ෡") in streamurl:
        name = l111ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢࡶࡹࠫ෢")
    if l111ll_opy_ (u"࠭ࡈࡅࡖ࡙࠸࠿࠭෣") in streamurl:
        name = l111ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸ࡭ࠩ෤")
    if l111ll_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠺ࠨ෥") in streamurl:
        name = l111ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡤࡥࡧ࡮ࡶ࡬ࡢࡻࡨࡶࠬ෦")
    if l111ll_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠴࠽ࠫ෧") in streamurl:
        name = l111ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽࠧ෨")
    if l111ll_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖ࠿࠭෩") in streamurl:
        name = l111ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰ࡭ࡣࡼࡩࡷࡽࡷࡸࠩ෪")
    if l111ll_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡏࡔࡗ࠼ࠪ෫") in streamurl:
        name = l111ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡶࡹࠫ෬")
    if l111ll_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪ෭") in streamurl:
        name = l111ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡧࡩࡽ࠭෮")
    if l111ll_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡕࡆ࠿࠭෯") in streamurl:
        name = l111ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷ࡫ࡢࡰࡱࡷࠫ෰")
    if l111ll_opy_ (u"࠭ࡉࡑࡖࡖࠫ෱") in streamurl:
        name = l111ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࡭ࡵࡺࡶࠨෲ")
    if l111ll_opy_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠻ࠩෳ") in streamurl:
        name = l111ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮࡬ࡺࡪࡳࡩࡹࠩ෴")
    if l111ll_opy_ (u"ࠪࡹࡵࡴࡰ࠻ࠩ෵") in streamurl:
        name = l111ll_opy_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲࡭ࡪࡨࡰ࡯ࡨࡶࡺࡴ࠮ࡷ࡫ࡨࡻࠬ෶")
    try:
        l1l1l1l11_opy_   = xbmcaddon.Addon(name).getAddonInfo(l111ll_opy_ (u"ࠬࡴࡡ࡮ࡧࠪ෷"))
        l1l1l1lll_opy_ = xbmcaddon.Addon(name).getAddonInfo(l111ll_opy_ (u"࠭ࡩࡤࡱࡱࠫ෸"))
    except:
        l1l1l1l11_opy_   = l111ll_opy_ (u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡕࡲࡹࡷࡩࡥࠨ෹")
        l1l1l1lll_opy_ =  dixie.ICON
    return l1l1l1l11_opy_, l1l1l1lll_opy_
def selectStream(url, channel):
    l11lll11ll_opy_ = url.split(l111ll_opy_ (u"ࠨࡾࠪ෺"))
    if len(l11lll11ll_opy_) == 0:
        return None
    options, l11lll11l1_opy_ = getOptions(l11lll11ll_opy_, channel)
    if len(l11lll11ll_opy_) == 1:
        return l11lll11l1_opy_[0]
    import selectDialog
    l11llll111_opy_ = selectDialog.select(l111ll_opy_ (u"ࠩࡖࡩࡱ࡫ࡣࡵࠢࡤࠤࡸࡺࡲࡦࡣࡰࠫ෻"), options)
    if l11llll111_opy_ < 0:
        raise Exception(l111ll_opy_ (u"ࠪࡗࡪࡲࡥࡤࡶ࡬ࡳࡳࠦࡃࡢࡰࡦࡩࡱ࠭෼"))
    return l11lll11l1_opy_[l11llll111_opy_]
def getOptions(l11lll11ll_opy_, channel):
    if not l11lll1l11_opy_() == l111ll_opy_ (u"࡙ࠫࡸࡵࡦࠩ෽"):
        return
    options = []
    l11lll11l1_opy_    = []
    for index, stream in enumerate(l11lll11ll_opy_):
        l1l1l1l11_opy_ = getPluginInfo(stream)
        l1ll1l111_opy_ = l1l1l1l11_opy_[0]
        l11ll1llll_opy_  = l1l1l1l11_opy_[1]
        l1ll1l111_opy_  = l111ll_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡵࡲࡢࡰࡪࡩࡢࡡࠧ෾") + l1ll1l111_opy_ + l111ll_opy_ (u"࠭࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࠪ෿")
        if stream.startswith(OPEN_OTT):
            l1ll1l111_opy_  = l1ll1l111_opy_ + stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l111ll_opy_ (u"ࠧࠨ฀"))
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l111ll_opy_ (u"ࠨࠩก"))
        else:
            l1ll1l111_opy_  = l1ll1l111_opy_ + channel
        options.append([l1ll1l111_opy_, index, l11ll1llll_opy_])
        l11lll11l1_opy_.append(stream)
    return options, l11lll11l1_opy_