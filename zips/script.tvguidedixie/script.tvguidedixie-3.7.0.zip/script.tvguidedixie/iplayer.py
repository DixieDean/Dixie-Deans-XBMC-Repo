# coding: UTF-8
import sys
l1111_opy_ = sys.version_info [0] == 2
l11l11_opy_ = 2048
l11l1_opy_ = 7
def l111ll_opy_ (l11l1l_opy_):
	global l11111_opy_
	l11lll_opy_ = ord (l11l1l_opy_ [-1])
	l11ll_opy_ = l11l1l_opy_ [:-1]
	l1111l_opy_ = l11lll_opy_ % len (l11ll_opy_)
	l1l1l1_opy_ = l11ll_opy_ [:l1111l_opy_] + l11ll_opy_ [l1111l_opy_:]
	if l1111_opy_:
		l1l1ll_opy_ = unicode () .join ([unichr (ord (char) - l11l11_opy_ - (l1l1l_opy_ + l11lll_opy_) % l11l1_opy_) for l1l1l_opy_, char in enumerate (l1l1l1_opy_)])
	else:
		l1l1ll_opy_ = str () .join ([chr (ord (char) - l11l11_opy_ - (l1l1l_opy_ + l11lll_opy_) % l11l1_opy_) for l1l1l_opy_, char in enumerate (l1l1l1_opy_)])
	return eval (l1l1ll_opy_)
import xbmc
import xbmcgui
import json
import dixie
l11llll11l_opy_ = l111ll_opy_ (u"ࠪࠫി")
def l11lll1ll1_opy_(i, t1, l11lll1lll_opy_=[]):
 t = l11llll11l_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l11lll1lll_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11llll111_opy_ = l11lll1ll1_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
def getURL(url):
    if not l11lll1l1l_opy_() == l111ll_opy_ (u"࡙ࠫࡸࡵࡦࠩീ"):
        return
    response = l11ll1ll1_opy_(url)
    stream   = url.split(l111ll_opy_ (u"ࠬࡀࠧു"), 1)[-1]
    try:
        result = response[l111ll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ൂ")]
        l1ll111ll_opy_  = result[l111ll_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ൃ")]
    except Exception as e:
        l1l1ll1ll_opy_(e)
        return None
    for file in l1ll111ll_opy_:
        l1ll1l111_opy_ = file[l111ll_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧൄ")]
        dixie.log(l1ll1l111_opy_)
        if stream in l1ll1l111_opy_:
            return file[l111ll_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧ൅")]
    return None
def l11ll1ll1_opy_(url):
    if url.startswith(l111ll_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠼ࠪെ")):
        l11ll1lll_opy_ = (l111ll_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡣࡤࡦ࡭ࡵࡲࡡࡺࡧࡵ࠳ࡄࡻࡲ࡭࠿ࡸࡶࡱࠬ࡭ࡰࡦࡨࡁ࠷ࠬ࡮ࡢ࡯ࡨࡁࡑ࡯ࡶࡦࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࡁࠫࡏࡐࡊࡆࡀࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩേ"))
    if url.startswith(l111ll_opy_ (u"ࠬࡏࡐࡍࡃ࡜࠶࠿࠭ൈ")):
        l11ll1lll_opy_ = (l111ll_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠵࠿ࡶࡴ࡯ࡁࡺࡸ࡬ࠧ࡯ࡲࡨࡪࡃ࠱࠱࠳ࠩࡲࡦࡳࡥ࠾࡙ࡤࡸࡨ࡮ࠫࡍ࡫ࡹࡩࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴ࠽ࠧࡵࡸࡦࡹ࡯ࡴ࡭ࡧࡶࡣࡺࡸ࡬࠾ࠨ࡯ࡳ࡬࡭ࡥࡥࡡ࡬ࡲࡂࡌࡡ࡭ࡵࡨࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ൉"))
    if url.startswith(l111ll_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡘ࠺ࠨൊ")):
        l11ll1lll_opy_ = (l111ll_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶ࡬ࡢࡻࡨࡶࡼࡽࡷ࠰ࡁࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠦ࡭ࡱࡪ࡫ࡪࡪ࡟ࡪࡰࡀࡊࡦࡲࡳࡦࠨࡰࡳࡩ࡫࠽࠲࠳࠶ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡸࡺࡥ࡯ࠧ࠵࠴ࡑ࡯ࡶࡦࠨࡶࡹࡧࡺࡩࡵ࡮ࡨࡷࡤࡻࡲ࡭ࠨࡸࡶࡱࡃࡵࡳ࡮ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨോ"))
    if url.startswith(l111ll_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡊࡖ࡙࠾ࠬൌ")):
        l11ll1lll_opy_ = (l111ll_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡵࡸࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ്"))
    if url.startswith(l111ll_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡇ࠾ࠬൎ")):
        l11ll1lll_opy_ = (l111ll_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡦࡨࡼ࠴ࡅࡡࡤࡶ࡬ࡳࡳࡃࡡ࡭࡮ࠩࡩࡽࡺࡲࡢࠨࡳࡥ࡬࡫ࠦࡱ࡮ࡲࡸࠫࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠾ࡪࡷࡸࡵࡹࠥ࠴ࡣࠨ࠶࡫ࠫ࠲ࡧࡵ࠶࠵࠳ࡶ࡯ࡴࡶ࡬ࡱ࡬࠴࡯ࡳࡩࠨ࠶࡫࠿ࡨ࡯࡭ࡻࡵࡿ࡭ࡢࠦ࠴ࡩࡸࡪࡹࡴࡠ࡫ࡱࡣࡵࡸ࡯ࡨࡴࡨࡷࡸ࠴ࡰ࡯ࡩࠩࡸ࡮ࡺ࡬ࡦ࠿ࠨ࠹ࡧࡉࡏࡍࡑࡕࠩ࠷࠶ࡷࡩ࡫ࡷࡩࠪ࠻ࡤࡂ࡮࡯ࠩ࠷࠶ࡃࡩࡣࡱࡲࡪࡲࡳࠦ࠷ࡥࠩ࠷࡬ࡃࡐࡎࡒࡖࠪ࠻ࡤࠧࡷࡵࡰࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ൏"))
    if url.startswith(l111ll_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡗࡈ࠺ࠨ൐")):
        l11ll1lll_opy_ = (l111ll_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡪࡨ࡯ࡰࡶ࠲ࡃࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠨࡩࡥࡳࡧࡲࡵ࠿࡫ࡸࡹࡶࠥ࠴ࡣࠨ࠶࡫ࠫ࠲ࡧࡶࡤࡶ࡬࡫ࡴࡣࡷ࡬ࡰࡩࡹ࠮࡯ࡧࡷࠩ࠷࡬ࡩࡤࡱࡱࡷࠪ࠸ࡦ࡭࡫ࡹࡩࠪ࠸࠵࠳࠲࡫ࡨ࠳ࡶ࡮ࡨࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂ࡮ࡴࡵࡲࠨ࠷ࡦࠫ࠲ࡧࠧ࠵ࡪࡹࡧࡲࡨࡧࡷࡦࡺ࡯࡬ࡥࡵ࠱ࡲࡪࡺࠥ࠳ࡨ࡬ࡧࡴࡴࡳࠦ࠴ࡩࡰ࡮ࡼࡥࠦ࠴࠸࠶࠵࡮ࡤ࠯ࡲࡱ࡫ࠫࡳ࡯ࡥࡧࡀ࠻ࠫࡶࡩ࡭࡮ࡲࡻࡂࡔ࡯ࠦ࠴࠳ࡋࡺ࡯ࡤࡦࠨࡸࡶࡱࡃࡲࡢࡰࡧࡳࡲࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫ൑"))
    if url.startswith(l111ll_opy_ (u"ࠨࡋࡓࡘࡘࡀࠧ൒")):
        l11ll1lll_opy_ = (l111ll_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡵࡺࡣ࡬ࡴࡹࡼ࠯ࡀࡣࡦࡸ࡮ࡵ࡮࠾࡮࡬ࡺࡪࡺࡶࡠࡣ࡯ࡰࠫ࡫ࡸࡵࡴࡤࠪࡵࡧࡧࡦࠨࡳࡰࡴࡺࠦࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡀࠪࡹ࡯ࡴ࡭ࡧࡀࡅࡱࡲࠥ࠳࠲ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪࡺࡸ࡬ࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭൓"))
    try:
        dixie.ShowBusy()
        addon =  l11ll1lll_opy_.split(l111ll_opy_ (u"ࠪ࠳࠴࠭ൔ"), 1)[-1].split(l111ll_opy_ (u"ࠫ࠴࠭ൕ"), 1)[0]
        l11lll111_opy_ = l111ll_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪൖ") % addon
        xbmc.executeJSONRPC(l11lll111_opy_)
        response = xbmc.executeJSONRPC(l11ll1lll_opy_)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1l1ll1ll_opy_(e)
        return {l111ll_opy_ (u"࠭ࡅࡳࡴࡲࡶࠬൗ") : l111ll_opy_ (u"ࠧࡑ࡮ࡸ࡫࡮ࡴࠠࡆࡴࡵࡳࡷ࠭൘")}
def l11lll1l1l_opy_():
    modules = map(__import__, [l11lll1ll1_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if not len(modules[-1].Window(10**4).getProperty(l11llll111_opy_)):
        return l111ll_opy_ (u"ࠨࡈࡤࡰࡸ࡫ࠧ൙")
    return l111ll_opy_ (u"ࠩࡗࡶࡺ࡫ࠧ൚")
def l1l1ll1ll_opy_(e):
    l1ll1l11l_opy_ = l111ll_opy_ (u"ࠪࡗࡴࡸࡲࡺ࠮ࠣࡥࡳࠦࡥࡳࡴࡲࡶࠥࡵࡣࡤࡷࡵࡩࡩࡀࠠࡋࡕࡒࡒࠥࡋࡲࡳࡱࡵ࠾ࠥࠫࡳࠨ൛")  %e
    l1ll1l1l1_opy_ = l111ll_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡷ࡫࠭࡭࡫ࡱ࡯ࠥࡺࡨࡪࡵࠣࡧ࡭ࡧ࡮࡯ࡧ࡯ࠤࡦࡴࡤࠡࡶࡵࡽࠥࡧࡧࡢ࡫ࡱ࠲ࠬ൜")
    l1ll1l1ll_opy_ = l111ll_opy_ (u"࡛ࠬࡳࡦ࠼ࠣࡇࡴࡴࡴࡦࡺࡷࠤࡒ࡫࡮ࡶࠢࡀࡂࠥࡘࡥ࡮ࡱࡹࡩ࡙ࠥࡴࡳࡧࡤࡱࠬ൝")
    dixie.log(e)
    dixie.DialogOK(l1ll1l11l_opy_, l1ll1l1l1_opy_, l1ll1l1ll_opy_)