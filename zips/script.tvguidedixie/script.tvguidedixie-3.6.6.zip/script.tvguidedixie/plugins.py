# coding: UTF-8
import sys
l1111_opy_ = sys.version_info [0] == 2
l11l11_opy_ = 2048
l11l1_opy_ = 7
def l111ll_opy_ (l11l1l_opy_):
	global l11111_opy_
	l11lll_opy_ = ord (l11l1l_opy_ [-1])
	l11ll_opy_ = l11l1l_opy_ [:-1]
	l1111l_opy_ = l11lll_opy_ % len (l11ll_opy_)
	l1l1l1_opy_ = l11ll_opy_ [:l1111l_opy_] + l11ll_opy_ [l1111l_opy_:]
	if l1111_opy_:
		l1l1ll_opy_ = unicode () .join ([unichr (ord (char) - l11l11_opy_ - (l1l1l_opy_ + l11lll_opy_) % l11l1_opy_) for l1l1l_opy_, char in enumerate (l1l1l1_opy_)])
	else:
		l1l1ll_opy_ = str () .join ([chr (ord (char) - l11l11_opy_ - (l1l1l_opy_ + l11lll_opy_) % l11l1_opy_) for l1l1l_opy_, char in enumerate (l1l1l1_opy_)])
	return eval (l1l1ll_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l1l1lllll_opy_    = l111ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡮ࡵࡸࠪࡳ")
l1ll1ll11_opy_    = l111ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡶ࡭ࡷࡹࡷࡱࠧࡴ")
locked = l111ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮ࡲࡧࡰ࡫ࡤࡵࡸࠪࡵ")
l1lll11l1_opy_   = l111ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡸࡷ࡫ࡡ࡮ࡶࡹࡦࡴࡾࠧࡶ")
l1l1l11l1_opy_     = l111ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡵࡵࡲࡵࡵࡰࡥࡳ࡯ࡡࠨࡷ")
l1lll111l_opy_     = l111ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡶ࡯ࡳࡶࡶࡲࡦࡺࡩࡰࡰ࡫ࡨࡹࡼࠧࡸ")
l1l1l1ll1_opy_     = l111ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡻ࡬ࡵ࡫ࡰࡥࡹ࡫࡭ࡢࡰ࡬ࡥࠬࡹ")
l1l11llll_opy_   = l111ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡬ࡪࡷࡻ࠲ࡹࡼࠧࡺ")
l1l1lll11_opy_    = l111ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡅࡅࡖࡴࡴࡸࡴࡴࠩࡻ")
l1l1l111l_opy_ = [l1ll1ll11_opy_, l1l1lllll_opy_, l1lll11l1_opy_, l1l11llll_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l111ll_opy_ (u"ࠩ࡬ࡲ࡮࠭ࡼ"))
def checkAddons():
    for addon in l1l1l111l_opy_:
        if l1ll11l11_opy_(addon):
            try: l1ll11l1l_opy_(addon)
            except: pass
def l1ll11l11_opy_(addon):
    if xbmc.getCondVisibility(l111ll_opy_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡌࡦࡹࡁࡥࡦࡲࡲ࠭ࠫࡳࠪࠩࡽ") % addon) == 1:
        return True
    return False
def l1ll11l1l_opy_(addon):
    l1ll1llll_opy_ = str(addon).split(l111ll_opy_ (u"ࠫ࠳࠭ࡾ"))[2] + l111ll_opy_ (u"ࠬ࠴ࡩ࡯࡫ࠪࡿ")
    l1l1l11ll_opy_  = os.path.join(PATH, l1ll1llll_opy_)
    l1lll1111_opy_ = l1lll1l11_opy_(addon)
    l1l1ll1l1_opy_  = file(l1l1l11ll_opy_, l111ll_opy_ (u"࠭ࡷࠨࢀ"))
    l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠧ࡜ࠩࢁ"))
    l1l1ll1l1_opy_.write(addon)
    l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠨ࡟ࠪࢂ"))
    l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠩ࡟ࡲࠬࢃ"))
    for channel in l1lll1111_opy_:
        l1ll1l111_opy_  = channel[l111ll_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࢄ")]
        l1ll1l111_opy_  = l1ll1l111_opy_.replace(l111ll_opy_ (u"ࠫ࠳࠴࠮࠯࠰ࠪࢅ"), l111ll_opy_ (u"ࠬ࠭ࢆ")).replace(l111ll_opy_ (u"࠭࠺ࠨࢇ"), l111ll_opy_ (u"ࠧࠨ࢈")).replace(l111ll_opy_ (u"ࠨࠢ࡞ࠫࢉ"), l111ll_opy_ (u"ࠩ࡞ࠫࢊ")).replace(l111ll_opy_ (u"ࠪࡡࠥ࠭ࢋ"), l111ll_opy_ (u"ࠫࡢ࠭ࢌ")).replace(l111ll_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡧࡱࡶࡣࡠࠫࢍ"), l111ll_opy_ (u"࠭ࠧࢎ")).replace(l111ll_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠ࡭࡫ࡰࡩ࡬ࡸࡥࡦࡰࡠࠫ࢏"), l111ll_opy_ (u"ࠨࠩ࢐")).replace(l111ll_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡪࡶࡪ࡫࡮࡞ࠩ࢑"), l111ll_opy_ (u"ࠪࠫ࢒")).replace(l111ll_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡾ࡫࡬࡭ࡱࡺࡡࠬ࢓"), l111ll_opy_ (u"ࠬ࠭࢔")).replace(l111ll_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࠬ࢕"), l111ll_opy_ (u"ࠧࠨ࢖")).replace(l111ll_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡱࡵࡥࡳ࡭ࡥ࡞ࠩࢗ"), l111ll_opy_ (u"ࠩࠪ࢘")).replace(l111ll_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࠨ࢙"), l111ll_opy_ (u"࢚ࠫࠬ")).replace(l111ll_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡽࡨࡪࡶࡨࡡ࢛ࠬ"), l111ll_opy_ (u"࠭ࠧ࢜")).replace(l111ll_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࢝"), l111ll_opy_ (u"ࠨࠩ࢞")).replace(l111ll_opy_ (u"ࠩ࡞ࡍࡢ࠭࢟"), l111ll_opy_ (u"ࠪࠫࢠ")).replace(l111ll_opy_ (u"ࠫࡠ࠵ࡉ࡞ࠩࢡ"), l111ll_opy_ (u"ࠬ࠭ࢢ")).replace(l111ll_opy_ (u"࡛࠭ࡃ࡟ࠪࢣ"), l111ll_opy_ (u"ࠧࠨࢤ")).replace(l111ll_opy_ (u"ࠨ࡝࠲ࡆࡢ࠭ࢥ"), l111ll_opy_ (u"ࠩࠪࢦ"))
        stream = channel[l111ll_opy_ (u"ࠪࡪ࡮ࡲࡥࠨࢧ")]
        l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠫࠪࡹࠧࢨ") % l1ll1l111_opy_)
        l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠬࡃࠧࢩ"))
        l1l1ll1l1_opy_.write(l111ll_opy_ (u"࠭ࠥࡴࠩࢪ") % stream)
        l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠧ࡝ࡰࠪࢫ"))
    l1l1ll1l1_opy_.write(l111ll_opy_ (u"ࠨ࡞ࡱࠫࢬ"))
    l1l1ll1l1_opy_.close()
def l1lll1l11_opy_(addon):
    if addon == l1ll1ll11_opy_:
        return l1l1llll1_opy_(addon)
    if addon == l1l1lll11_opy_:
        return l1ll1lll1_opy_(addon)
    if addon in [l1l1l11l1_opy_, l1lll111l_opy_, l1l1l1ll1_opy_]:
        return
    try:
        if xbmcaddon.Addon(addon).getSetting(l111ll_opy_ (u"ࠩࡪࡩࡳࡸࡥࠨࢭ")) == l111ll_opy_ (u"ࠪࡸࡷࡻࡥࠨࢮ"):
            xbmcaddon.Addon(addon).setSetting(l111ll_opy_ (u"ࠫ࡬࡫࡮ࡳࡧࠪࢯ"), l111ll_opy_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫࢰ"))
            xbmcgui.Window(10000).setProperty(l111ll_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡇࡆࡐࡕࡉࠬࢱ"), l111ll_opy_ (u"ࠧࡕࡴࡸࡩࠬࢲ"))
        if xbmcaddon.Addon(addon).getSetting(l111ll_opy_ (u"ࠨࡶࡹ࡫ࡺ࡯ࡤࡦࠩࢳ")) == l111ll_opy_ (u"ࠩࡷࡶࡺ࡫ࠧࢴ"):
            xbmcaddon.Addon(addon).setSetting(l111ll_opy_ (u"ࠪࡸࡻ࡭ࡵࡪࡦࡨࠫࢵ"), l111ll_opy_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪࢶ"))
            xbmcgui.Window(10000).setProperty(l111ll_opy_ (u"ࠬࡖࡌࡖࡉࡌࡒࡤ࡚ࡖࡈࡗࡌࡈࡊ࠭ࢷ"), l111ll_opy_ (u"࠭ࡔࡳࡷࡨࠫࢸ"))
    except: pass
    l1l1ll11l_opy_  = l111ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪࢹ") + addon
    l1ll11ll1_opy_ =  l1lll11ll_opy_(addon)
    query   =  l1l1ll11l_opy_ + l1ll11ll1_opy_
    return sendJSON(query, addon)
def l1l1l1l1l_opy_(addon):
    l1ll11111_opy_   =  []
    query    = l111ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫࢺ") + addon
    response =  sendJSON(query, addon)
    for item in response:
        if not l111ll_opy_ (u"ࠩ࠱ࠫࢻ") in item[l111ll_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࢼ")]:
            l1ll11111_opy_.append(item[l111ll_opy_ (u"ࠫ࡫࡯࡬ࡦࠩࢽ")])
    l1ll111ll_opy_ = []
    for l1l1lll1l_opy_ in l1ll11111_opy_:
        response = sendJSON(l1l1lll1l_opy_, addon)
        l1ll111ll_opy_.extend(response)
    return l1ll111ll_opy_
def l1l1llll1_opy_(addon):
    l1l1ll11l_opy_ = l111ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨࢾ") + addon
    l1l11lll1_opy_ = l111ll_opy_ (u"࠭࠯ࡀࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࠩࡱࡴࡪࡥ࠾࠳ࠩࡲࡦࡳࡥ࠾ࡎ࡬ࡺࡪࠫ࠲࠱ࡖ࡙ࠪࡺࡸ࡬࠾ࡪࡷࡸࡵࠫ࠳ࡢࠧ࠵ࡪࠪ࠸ࡦ࡮ࡧࡷࡥࡱࡱࡥࡵࡶ࡯ࡩ࠳ࡩ࡯ࠦ࠴ࡩ࡙ࡐ࡚ࡵࡳ࡭࠴࠼࠵࠸࠲࠱࠳࠹ࠩ࠷࡬ࡌࡪࡸࡨࠩ࠷࠻࠲࠱ࡖ࡙࠲ࡹࡾࡴࠨࢿ")
    l1l1l1111_opy_ = l111ll_opy_ (u"ࠧ࠰ࡁࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡲࡵࡤࡦ࠿࠴ࠪࡳࡧ࡭ࡦ࠿ࡖࡴࡴࡸࡴࡴࠨࡸࡶࡱࡃࡨࡵࡶࡳࠩ࠸ࡧࠥ࠳ࡨࠨ࠶࡫ࡳࡥࡵࡣ࡯࡯ࡪࡺࡴ࡭ࡧ࠱ࡧࡴࠫ࠲ࡧࡗࡎࡘࡺࡸ࡫࠲࠺࠳࠶࠷࠶࠱࠷ࠧ࠵ࡪࡘࡶ࡯ࡳࡶࡶࡐ࡮ࡹࡴ࠯ࡶࡻࡸࠬࣀ")
    l1ll111ll_opy_  = []
    l1ll111ll_opy_ += sendJSON(l1l1ll11l_opy_ + l1l11lll1_opy_, addon)
    l1ll111ll_opy_ += sendJSON(l1l1ll11l_opy_ + l1l1l1111_opy_, addon)
    return l1ll111ll_opy_
def l1ll1lll1_opy_(addon):
    l1l1ll11l_opy_ = l111ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫࣁ") + addon
    l1l11lll1_opy_ = l111ll_opy_ (u"ࠩ࠲ࡃ࡫ࡧ࡮ࡢࡴࡷࡁ࡭ࡺࡴࡱࠧ࠶ࡥࠪ࠸ࡦࠦ࠴ࡩ࡫ࡴࡵ࠮ࡨ࡮ࠨ࠶࡫࡞ࡤࡇ࠴࠻ࡘࠫࡳ࡯ࡥࡧࡀ࠵ࠫࡴࡡ࡮ࡧࡀࡐ࡮ࡼࡥࠦ࠴࠳࡙ࡐࠫ࠲࠱ࡕࡳࡳࡷࡺࡳࠧࡷࡵࡰࡂ࡮ࡴࡵࡲࡶࠩ࠸ࡧࠥ࠳ࡨࠨ࠶࡫࡭࡯ࡰ࠰ࡪࡰࠪ࠸ࡦ࠶ࡳࡔ࡫ࡊ࠺ࠧࣂ")
    l1l1l1111_opy_ = l111ll_opy_ (u"ࠪ࠳ࡄ࡬ࡡ࡯ࡣࡵࡸࡂ࡮ࡴࡵࡲࡶࠩ࠸ࡧࠥ࠳ࡨࠨ࠶࡫࡭࡯ࡰ࠰ࡪࡰࠪ࠸ࡦࡇࡩ࡚ࡑࡰࡠࠦ࡮ࡱࡧࡩࡂ࠷ࠦ࡯ࡣࡰࡩࡂࡒࡩࡷࡧࠨ࠶࠵࡛ࡓࠦ࠴ࡩࡇࡆࡔࠥ࠳࠲ࡖࡴࡴࡸࡴࡴࠨࡸࡶࡱࡃࡨࡵࡶࡳࡷࠪ࠹ࡡࠦ࠴ࡩࠩ࠷࡬ࡧࡰࡱ࠱࡫ࡱࠫ࠲ࡧࡨ࠼࡮࡬࠾ࡎࠨࣃ")
    l1ll111ll_opy_  = []
    l1ll111ll_opy_ += sendJSON(l1l1ll11l_opy_ + l1l11lll1_opy_, addon)
    l1ll111ll_opy_ += sendJSON(l1l1ll11l_opy_ + l1l1l1111_opy_, addon)
    return l1ll111ll_opy_
def l1lll11ll_opy_(addon):
    if addon == l1l1lllll_opy_:
        return l111ll_opy_ (u"ࠫ࠴ࡅࡣࡢࡶࡀ࠱࠷ࠬ࡭ࡰࡦࡨࡁ࠷ࠬ࡮ࡢ࡯ࡨࡁࡒࡿࠥ࠳࠲ࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪࡺࡸ࡬࠾ࡷࡵࡰࠬࣄ")
    return l111ll_opy_ (u"ࠬ࠭ࣅ")
def sendJSON(query, addon):
    try:
        l1ll11lll_opy_     = l111ll_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࠧࡶࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩࣆ") % query
        l1ll1111l_opy_  = xbmc.executeJSONRPC(l1ll11lll_opy_)
        response = json.loads(l1ll1111l_opy_)
        if xbmcgui.Window(10000).getProperty(l111ll_opy_ (u"ࠧࡑࡎࡘࡋࡎࡔ࡟ࡈࡇࡑࡖࡊ࠭ࣇ")) == l111ll_opy_ (u"ࠨࡖࡵࡹࡪ࠭ࣈ"):
            xbmcaddon.Addon(addon).setSetting(l111ll_opy_ (u"ࠩࡪࡩࡳࡸࡥࠨࣉ"), l111ll_opy_ (u"ࠪࡸࡷࡻࡥࠨ࣊"))
            xbmcgui.Window(10000).clearProperty(l111ll_opy_ (u"ࠫࡕࡒࡕࡈࡋࡑࡣࡌࡋࡎࡓࡇࠪ࣋"))
        if xbmcgui.Window(10000).getProperty(l111ll_opy_ (u"ࠬࡖࡌࡖࡉࡌࡒࡤ࡚ࡖࡈࡗࡌࡈࡊ࠭࣌")) == l111ll_opy_ (u"࠭ࡔࡳࡷࡨࠫ࣍"):
            xbmcaddon.Addon(addon).setSetting(l111ll_opy_ (u"ࠧࡵࡸࡪࡹ࡮ࡪࡥࠨ࣎"), l111ll_opy_ (u"ࠨࡶࡵࡹࡪ࣏࠭"))
            xbmcgui.Window(10000).clearProperty(l111ll_opy_ (u"ࠩࡓࡐ࡚ࡍࡉࡏࡡࡗ࡚ࡌ࡛ࡉࡅࡇ࣐ࠪ"))
        return response[l111ll_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶ࣑ࠪ")][l111ll_opy_ (u"ࠫ࡫࡯࡬ࡦࡵ࣒ࠪ")]
    except Exception as e:
        l1l1ll1ll_opy_(e, addon)
        return {l111ll_opy_ (u"ࠬࡋࡲࡳࡱࡵ࣓ࠫ") : l111ll_opy_ (u"࠭ࡐ࡭ࡷࡪ࡭ࡳࠦࡅࡳࡴࡲࡶࠬࣔ")}
def l1l1ll1ll_opy_(e, addon):
    l1ll1l11l_opy_ = l111ll_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠲ࠠࡢࡰࠣࡩࡷࡸ࡯ࡳࠢࡲࡧࡨࡻࡲࡦࡦ࠽ࠤࡏ࡙ࡏࡏࠢࡈࡶࡷࡵࡲ࠻ࠢࠨࡷ࠱ࠦࠥࡴࠩࣕ")  % (e, addon)
    l1ll1l1l1_opy_ = l111ll_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡥࡲࡲࡹࡧࡣࡵࠢࡸࡷࠥࡵ࡮ࠡࡶ࡫ࡩࠥ࡬࡯ࡳࡷࡰ࠲ࠬࣖ")
    l1ll1l1ll_opy_ = l111ll_opy_ (u"ࠩࡘࡴࡱࡵࡡࡥࠢࡤࠤࡱࡵࡧࠡࡸ࡬ࡥࠥࡺࡨࡦࠢࡤࡨࡩࡵ࡮ࠡࡵࡨࡸࡹ࡯࡮ࡨࡵࠣࡥࡳࡪࠠࡱࡱࡶࡸࠥࡺࡨࡦࠢ࡯࡭ࡳࡱ࠮ࠨࣗ")
    dixie.log(addon)
    dixie.log(e)
def getPlaylist():
    import requests
    l1ll111l1_opy_ = [l111ll_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡫ࡴ࠸࡬࠯࡫ࡱ࡯࠴ࡱ࡯ࡥ࡫ࠪࣘ"), l111ll_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱ࡧࡦࡨ࡮࠰࠲ࠩࣙ"), l111ll_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫࠱ࡧࡨࡲࡤ࠯࡫ࡲࠫࣚ"), l111ll_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡࡪࡱ࠱ࡧࡨࡲ࡯ࡶࡦࡷࡺ࠳ࡵࡲࡨ࠱࡮ࡳࡩ࡯ࠧࣛ")]
    l1l1ll111_opy_ =  l111ll_opy_ (u"ࠧࠤࡇ࡛ࡘࡒ࠹ࡕࠨࣜ")
    for url in l1ll111l1_opy_:
        dixie.log(url)
        try:
            request  = requests.get(url)
            l1ll1ll1l_opy_ = request.text
        except: pass
        if l1l1ll111_opy_ in l1ll1ll1l_opy_:
            path = os.path.join(dixie.PROFILE, l111ll_opy_ (u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡱ࠸ࡻࠧࣝ"))
            with open(path, l111ll_opy_ (u"ࠩࡺࠫࣞ")) as f:
                f.write(l1ll1ll1l_opy_)
                break
def getPluginInfo(streamurl):
    if streamurl.isdigit():
        l1l1l1l11_opy_   = l111ll_opy_ (u"ࠪࡏࡴࡪࡩࠡࡒ࡙ࡖࠥࡉࡨࡢࡰࡱࡩࡱ࠭ࣟ")
        l1l1l1lll_opy_ = os.path.join(dixie.RESOURCES, l111ll_opy_ (u"ࠫࡰࡵࡤࡪ࠯ࡳࡺࡷ࠴ࡰ࡯ࡩࠪ࣠"))
        return l1l1l1l11_opy_, l1l1l1lll_opy_
    if streamurl.startswith(l111ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ࣡")):
        name = streamurl.split(l111ll_opy_ (u"࠭࠯࠰ࠩ࣢"), 1)[-1].split(l111ll_opy_ (u"ࠧ࠰ࣣࠩ"), 1)[0]
    if streamurl.startswith(l111ll_opy_ (u"ࠨࡡࡢࡗࡋࡥ࡟ࠨࣤ")):
        name = l111ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡳࡶࡴ࡭ࡲࡢ࡯࠱ࡷࡺࡶࡥࡳ࠰ࡩࡥࡻࡵࡵࡳ࡫ࡷࡩࡸ࠭ࣥ")
    if streamurl.startswith(l111ll_opy_ (u"ࠪࡌࡉ࡚ࡖ࠻ࣦࠩ")):
        name = l111ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡬ࡩࡺࡶࠨࣧ")
    if streamurl.startswith(l111ll_opy_ (u"ࠬࡎࡄࡕࡘ࠵࠾ࠬࣨ")):
        name = l111ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡵࡺࡣ࡬ࡴࡹࡼࣩࠧ")
    if streamurl.startswith(l111ll_opy_ (u"ࠧࡉࡆࡗ࡚࠸ࡀࠧ࣪")):
        name = l111ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥࡹࡼࠧ࣫")
    if streamurl.startswith(l111ll_opy_ (u"ࠩࡋࡈ࡙࡜࠴࠻ࠩ࣬")):
        name = l111ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡰ࣭ࠬ")
    if streamurl.startswith(l111ll_opy_ (u"ࠫࡎࡖࡌࡂ࡛࠽࣮ࠫ")):
        name = l111ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡧࡨࡣࡪࡲ࡯ࡥࡾ࡫ࡲࠨ࣯")
    if streamurl.startswith(l111ll_opy_ (u"࠭ࡉࡑࡎࡄ࡝࠷ࡀࣰࠧ")):
        name = l111ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱ࡮ࡤࡽࡪࡸࡷࡸࡹࣱࠪ")
    if streamurl.startswith(l111ll_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡒ࠻ࣲࠩ")):
        name = l111ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡰࡦࡿࡥࡳࡹࡺࡻࠬࣳ")
    if streamurl.startswith(l111ll_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡋࡗ࡚࠿࠭ࣴ")):
        name = l111ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡹࡼࠧࣵ")
    if streamurl.startswith(l111ll_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡈ࠿ࣶ࠭")):
        name = l111ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡪࡥࡹࠩࣷ")
    if streamurl.startswith(l111ll_opy_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠺ࠨࣸ")):
        name = l111ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡭࡫ࡹࡩࡲ࡯ࡸࠨࣹ")
    if streamurl.startswith(l111ll_opy_ (u"ࠩࡸࡴࡳࡶ࠺ࠨࣺ")):
        name = l111ll_opy_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱࡬ࡩ࡮࡯࡮ࡧࡵࡹࡳ࠴ࡶࡪࡧࡺࠫࣻ")
    try:
        l1l1l1l11_opy_   = xbmcaddon.Addon(name).getAddonInfo(l111ll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩࣼ"))
        l1l1l1lll_opy_ = xbmcaddon.Addon(name).getAddonInfo(l111ll_opy_ (u"ࠬ࡯ࡣࡰࡰࠪࣽ"))
    except:
        l1l1l1l11_opy_   = l111ll_opy_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡴࡶࡵࡩࡦࡳࠠࡰࡴࠣࡥࡩࡪ࠭ࡰࡰࠪࣾ")
        l1l1l1lll_opy_ =  dixie.ICON
    return l1l1l1l11_opy_, l1l1l1lll_opy_