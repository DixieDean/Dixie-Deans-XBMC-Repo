# -*- coding: utf-8 -*-
import sys
l11ll111_opy_ = sys.version_info [0] == 2
l1lll1l1_opy_ = 2048
l11lllll_opy_ = 7
def l1l11_opy_ (l11ll1_opy_):
	global l1llll11_opy_
	l1ll1111_opy_ = ord (l11ll1_opy_ [-1])
	l11ll11l_opy_ = l11ll1_opy_ [:-1]
	l11l11l_opy_ = l1ll1111_opy_ % len (l11ll11l_opy_)
	l111l1_opy_ = l11ll11l_opy_ [:l11l11l_opy_] + l11ll11l_opy_ [l11l11l_opy_:]
	if l11ll111_opy_:
		l1lll1_opy_ = unicode () .join ([unichr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	else:
		l1lll1_opy_ = str () .join ([chr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	return eval (l1lll1_opy_)
import os
import json
import requests
import dixie
l1lll1lll_opy_ = dixie.PROFILE
PATH = os.path.join(l1lll1lll_opy_, l1l11_opy_ (u"ࠨࡲ࡯࡭ࡸࡺࡳࠨ࡟"))
def loadPlaylists():
    dixie.log(l1l11_opy_ (u"ࠩࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠢࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠥࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࠫࡠ"))
    source = dixie.GetSetting(l1l11_opy_ (u"ࠪ࡭ࡵࡺࡶ࠯ࡵࡲࡹࡷࡩࡥࠨࡡ"))
    dixie.log(source)
    if source == l1l11_opy_ (u"ࠫ࠶࠭ࡢ"):
        return l1lll111l_opy_()
    return l11111ll_opy_()
def l11111ll_opy_():
    if os.path.exists(PATH):
        return json.load(open(PATH))
    return l1ll1ll1l_opy_()
def l1ll1ll1l_opy_():
    l1llll11l_opy_()
    return json.load(open(PATH))
def l1llll11l_opy_():
    l111l111_opy_ = []
    if dixie.GetSetting(l1l11_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠴ࠬࡣ")) == l1l11_opy_ (u"࠭ࡴࡳࡷࡨࠫࡤ"):
        l1111l1l_opy_  = dixie.GetSetting(l1l11_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠶࡟ࡖࡔࡏࠫࡥ"))
        l1lllllll_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠰ࡠࡒࡒࡖ࡙࠭ࡦ"))
        l1llll111_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠱ࡡࡗ࡝ࡕࡋࠧࡧ"))
        l111111l_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠲ࡢ࡙ࡘࡋࡒࠨࡨ"))
        l1111ll1_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠳ࡣࡕࡇࡓࡔࠩࡩ"))
        if not l1111l1l_opy_ == l1l11_opy_ (u"ࠬ࠭ࡪ"):
            l1ll1l11l_opy_ = l1111111_opy_(l1111l1l_opy_, l1lllllll_opy_, l1llll111_opy_, l111111l_opy_, l1111ll1_opy_)
            l111l111_opy_.append((l1ll1l11l_opy_, l1l11_opy_ (u"࠭ࡉࡑࡖ࡙࠵࠿ࠦࠧ࡫")))
    if dixie.GetSetting(l1l11_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠷ࠧ࡬")) == l1l11_opy_ (u"ࠨࡶࡵࡹࡪ࠭࡭"):
        l1111l1l_opy_  = dixie.GetSetting(l1l11_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠲ࡡࡘࡖࡑ࠭࡮"))
        l1lllllll_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠳ࡢࡔࡔࡘࡔࠨ࡯"))
        l1llll111_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠴ࡣ࡙࡟ࡐࡆࠩࡰ"))
        l111111l_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠵ࡤ࡛ࡓࡆࡔࠪࡱ"))
        l1111ll1_opy_ = dixie.GetSetting(l1l11_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠶ࡥࡐࡂࡕࡖࠫࡲ"))
        if not l1111l1l_opy_ == l1l11_opy_ (u"ࠧࠨࡳ"):
            l1llllll1_opy_ = l1111111_opy_(l1111l1l_opy_, l1lllllll_opy_, l1llll111_opy_, l111111l_opy_, l1111ll1_opy_)
            l111l111_opy_.append((l1llllll1_opy_, l1l11_opy_ (u"ࠨࡋࡓࡘ࡛࠸࠺ࠡࠩࡴ")))
    if dixie.GetSetting(l1l11_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠳ࠩࡵ")) == l1l11_opy_ (u"ࠪࡸࡷࡻࡥࠨࡶ"):
        l1111l1l_opy_  = dixie.GetSetting(l1l11_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠵ࡣ࡚ࡘࡌࠨࡷ"))
        l1lllllll_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠶ࡤࡖࡏࡓࡖࠪࡸ"))
        l1llll111_opy_ = dixie.GetSetting(l1l11_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠷ࡥࡔ࡚ࡒࡈࠫࡹ"))
        l111111l_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠸࡟ࡖࡕࡈࡖࠬࡺ"))
        l1111ll1_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠲ࡠࡒࡄࡗࡘ࠭ࡻ"))
        if not l1111l1l_opy_ == l1l11_opy_ (u"ࠩࠪࡼ"):
            l1lllll1l_opy_ = l1111111_opy_(l1111l1l_opy_, l1lllllll_opy_, l1llll111_opy_, l111111l_opy_, l1111ll1_opy_)
            l111l111_opy_.append((l1lllll1l_opy_, l1l11_opy_ (u"ࠪࡍࡕ࡚ࡖ࠴࠼ࠣࠫࡽ")))
    dixie.log(l111l111_opy_)
    playlists = []
    for item in l111l111_opy_:
        url = item[0]
        l1ll1l1ll_opy_ = item[1]
        l1llll1ll_opy_ = l1lll11ll_opy_(url, l1ll1l1ll_opy_)
        playlists.extend(l1llll1ll_opy_)
    json.dump(playlists, open(PATH,l1l11_opy_ (u"ࠫࡼ࠭ࡾ")))
def l1111111_opy_(l1111l1l_opy_, l1lllllll_opy_, l1llll111_opy_, l111111l_opy_, l1111ll1_opy_):
    url  = l1l11_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭ࡿ")
    url +=  l1111l1l_opy_
    url +=  l1lll11l1_opy_(l1lllllll_opy_)
    url += l1l11_opy_ (u"࠭࠯ࡨࡧࡷ࠲ࡵ࡮ࡰࡀࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠫࢀ")
    url +=  l111111l_opy_
    url += l1l11_opy_ (u"ࠧࠧࡲࡤࡷࡸࡽ࡯ࡳࡦࡀࠫࢁ")
    url +=  l1111ll1_opy_
    url += l1l11_opy_ (u"ࠨࠨࡷࡽࡵ࡫࠽࡮࠵ࡸࡣࡵࡲࡵࡴࠨࡲࡹࡹࡶࡵࡵ࠿ࠪࢂ")
    url +=  l1ll1llll_opy_(l1llll111_opy_)
    return url
def l1lll11l1_opy_(l1lllllll_opy_):
    if not l1lllllll_opy_ == l1l11_opy_ (u"ࠩࠪࢃ"):
        return l1l11_opy_ (u"ࠪ࠾ࠬࢄ") + l1lllllll_opy_
    return l1l11_opy_ (u"ࠫࠬࢅ")
def l1ll1llll_opy_(l1llll111_opy_):
    if l1llll111_opy_ == l1l11_opy_ (u"ࠬ࠶ࠧࢆ"):
        return l1l11_opy_ (u"࠭࡭࠴ࡷ࠻ࠫࢇ")
    if l1llll111_opy_ == l1l11_opy_ (u"ࠧ࠲ࠩ࢈"):
        return l1l11_opy_ (u"ࠨ࡯ࡳࡩ࡬ࡺࡳࠨࢉ")
def l1lll11ll_opy_(url, l1ll1l1ll_opy_):
    l1ll1lll1_opy_   = list()
    l1lll1ll1_opy_     = l1l11_opy_ (u"ࠩࠪࢊ")
    value     = l1l11_opy_ (u"ࠪࠫࢋ")
    dixie.log(l1l11_opy_ (u"ࠫࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࠤࡱࡵࡡࡥࡒ࡯ࡥࡾࡲࡩࡴࡶࠣࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠩࢌ"))
    request = requests.get(url)
    dixie.log(url)
    for line in request.iter_lines():
        if line.startswith(l1l11_opy_ (u"ࠬࠩࡅ࡙ࡖࡌࡒࡋࡀࠧࢍ")):
            l1lll1l11_opy_ = line.split(l1l11_opy_ (u"࠭ࠬࠨࢎ"))[-1].strip()
            l1lll1l11_opy_ = l1111lll_opy_(l1lll1l11_opy_)
            l1lll1ll1_opy_ = dixie.mapChannelName(l1lll1l11_opy_)
            l1lll1ll1_opy_ = l1ll1l1ll_opy_ + l1lll1ll1_opy_
        elif line.startswith(l1l11_opy_ (u"ࠧࡩࡶࡷࡴࠬ࢏")):
            value = line.replace(l1l11_opy_ (u"ࠨ࡞ࡱࠫ࢐"), l1l11_opy_ (u"ࠩࠪ࢑"))
            l1ll1lll1_opy_.append((l1lll1ll1_opy_, value))
    return l1ll1lll1_opy_
def l1111lll_opy_(l1lll1l11_opy_):
    l1lll1l1l_opy_ = [l1l11_opy_ (u"࡙ࠪࡐࠦ࠺ࠡࠩ࢒"), l1l11_opy_ (u"࡚ࠫࡑ࠺ࠡࠩ࢓"), l1l11_opy_ (u"࡛ࠬࡋࠡࡾࠣࠫ࢔"), l1l11_opy_ (u"࠭ࡕࡔࡃࠣ࠾ࠥ࠭࢕"), l1l11_opy_ (u"ࠧࡖࡕࡄࠤ࠿࠭࢖"), l1l11_opy_ (u"ࠨࡗࡖࡅ࠿ࠦࠧࢗ"), l1l11_opy_ (u"ࠩࡘࡗࡆࠦࡼࠡࠩ࢘"), l1l11_opy_ (u"࡙ࠪࡘࡇࠠࠨ࢙"), l1l11_opy_ (u"࡚࡙ࠫࠠࡽ࢚ࠢࠪ"), l1l11_opy_ (u"ࠬࠦࡼ࢛ࠡࠩ"), l1l11_opy_ (u"࠭ࡼࠨ࢜"), l1l11_opy_ (u"ࠧ࠯ࠩ࢝")]
    for prefix in l1lll1l1l_opy_:
        if prefix in l1lll1l11_opy_:
            l1lll1l11_opy_ = l1lll1l11_opy_.replace(prefix, l1l11_opy_ (u"ࠨࠩ࢞"))
    return l1lll1l11_opy_
def l1lll111l_opy_():
    dixie.log(l1l11_opy_ (u"ࠩࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡯ࡳࡦࡪࡌࡦࡩࡤࡧࡾࡏࡐࡕࡘࠣࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠩ࢟"))
    l1llll1l1_opy_ = dixie.GetSetting(l1l11_opy_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡺࡹࡱࡧࠪࢠ"))
    l11111l1_opy_  = l1l11_opy_ (u"ࠫ࠵࠭ࢡ")
    l1lllll11_opy_ = l1l11_opy_ (u"ࠬ࠷ࠧࢢ")
    l1ll1lll1_opy_   = list()
    l1lll1ll1_opy_     = l1l11_opy_ (u"࠭ࠧࢣ")
    value     = l1l11_opy_ (u"ࠧࠨࢤ")
    if l1llll1l1_opy_ == l1lllll11_opy_:
        path = os.path.join(dixie.GetSetting(l1l11_opy_ (u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡪ࡮ࡲࡥࠨࢥ")))
    else:
        url  = dixie.GetSetting(l1l11_opy_ (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡺࡸ࡬ࠨࢦ"))
        path = os.path.join(l1lll1lll_opy_, l1l11_opy_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡳ࠳ࡶࠩࢧ"))
        if url == l1l11_opy_ (u"ࠫࠬࢨ"):
            path = os.path.join(l1lll1lll_opy_, l1l11_opy_ (u"ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠮࡮࠵ࡸࠫࢩ"))
        else:
            request  = requests.get(url)
            l1llll1ll_opy_ = request.content
            with open(path, l1l11_opy_ (u"࠭ࡷࡣࠩࢪ")) as f:
                f.write(l1llll1ll_opy_)
    if os.path.exists(path):
        f = open(path)
        l1llll1ll_opy_ = f.readlines()
        f.close()
        for line in l1llll1ll_opy_:
            if line.startswith(l1l11_opy_ (u"ࠧࠤࡇ࡛ࡘࡎࡔࡆ࠻ࠩࢫ")):
                l1lll1l11_opy_ = line.split(l1l11_opy_ (u"ࠨ࠮ࠪࢬ"))[-1].strip()
                l1lll1l11_opy_ = l1111lll_opy_(l1lll1l11_opy_)
                l1lll1ll1_opy_    = dixie.mapChannelName(l1lll1l11_opy_)
            elif line.startswith(l1l11_opy_ (u"ࠩࡵࡸࡲࡶࠧࢭ")) or line.startswith(l1l11_opy_ (u"ࠪࡶࡹࡳࡰࡦࠩࢮ")) or line.startswith(l1l11_opy_ (u"ࠫࡷࡺࡳࡱࠩࢯ")) or line.startswith(l1l11_opy_ (u"ࠬ࡮ࡴࡵࡲࠪࢰ")):
                value = line.replace(l1l11_opy_ (u"࠭ࡲࡵ࡯ࡳ࠾࠴࠵ࠤࡐࡒࡗ࠾ࡷࡺ࡭ࡱ࠯ࡵࡥࡼࡃࠧࢱ"), l1l11_opy_ (u"ࠧࠨࢲ")).replace(l1l11_opy_ (u"ࠨ࡞ࡱࠫࢳ"), l1l11_opy_ (u"ࠩࠪࢴ"))
                l1ll1lll1_opy_.append((l1lll1ll1_opy_, value))
        l1ll1lll1_opy_.sort()
        return l1ll1lll1_opy_
def l1111l11_opy_():
    l1ll1l1l1_opy_ = os.path.join(l1lll1lll_opy_, l1l11_opy_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡳ࠳ࡶࠩࢵ"))
    if os.path.exists(l1ll1l1l1_opy_):
        os.remove(l1ll1l1l1_opy_)
    l1lll1111_opy_ = [l1l11_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱ࡋࡉ࡟࠻࡚ࡺ࡫ࡍࡩ࡜࠭ࢶ"), l1l11_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲ࡼ࡫࠻ࡉ࠴ࡊࡒࡨ࡞ࡔࠧࢷ"), l1l11_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳࡚ࡒࡣ࠱࠳ࡐࡓࡑ࡭ࡃࠨࢸ"), l1l11_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡹ࠰ࡦࡳ࠴ࡰࡵࡏࡏࡑ࡫ࡼࡰࡐ࠱ࠩࢹ"), l1l11_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡺ࠱ࡧࡴ࠵ࡤ࡫ࡄࡤ࠵ࡳࡼ࠹ࡈࡼࠪࢺ"), l1l11_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡻ࠲ࡨࡵ࠯࡯ࡘࡶࡵࡨ࡭ࡣࡤ࠻ࡼࠫࢻ"), l1l11_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡼ࠳ࡩ࡯࠰ࡺࡏࡇ࠾࠺ࡅࡗࡓࡹ࡝ࠬࢼ"), l1l11_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱ࡷࡷࡊ࠹ࡊࡑࡶࡩࡑࡷ࠭ࢽ"), l1l11_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲ࡩ࡛࡜ࡁࡸࡍࡌࡷࡘ࡮ࠧࢾ"), l1l11_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳ࡽࡗࡰࡇࡌ࡚࡫࡮࡭ࡪࠨࢿ")]
    l1ll1ll11_opy_ =  l1l11_opy_ (u"ࠧࠤࡇ࡛ࡘࡒ࠹ࡕࠨࣀ")
    for url in l1lll1111_opy_:
        try:
            request  = requests.get(url)
            l1llll1ll_opy_ = request.text
        except: pass
        if l1ll1ll11_opy_ in l1llll1ll_opy_:
            with open(l1ll1l1l1_opy_, l1l11_opy_ (u"ࠨࡹࠪࣁ")) as f:
                f.write(l1llll1ll_opy_)
                break
if __name__ == l1l11_opy_ (u"ࠩࡢࡣࡲࡧࡩ࡯ࡡࡢࠫࣂ"):
    l1llll11l_opy_()
    l1111l11_opy_()