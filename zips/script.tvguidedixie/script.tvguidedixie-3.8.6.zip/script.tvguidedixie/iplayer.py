# coding: UTF-8
import sys
l1l111_opy_ = sys.version_info [0] == 2
l11l11_opy_ = 2048
l11l1_opy_ = 7
def l1l1ll_opy_ (ll_opy_):
	global l11lll_opy_
	l11ll_opy_ = ord (ll_opy_ [-1])
	l1l11ll_opy_ = ll_opy_ [:-1]
	l1l1_opy_ = l11ll_opy_ % len (l1l11ll_opy_)
	l11l_opy_ = l1l11ll_opy_ [:l1l1_opy_] + l1l11ll_opy_ [l1l1_opy_:]
	if l1l111_opy_:
		l11111_opy_ = unicode () .join ([unichr (ord (char) - l11l11_opy_ - (l1lll1_opy_ + l11ll_opy_) % l11l1_opy_) for l1lll1_opy_, char in enumerate (l11l_opy_)])
	else:
		l11111_opy_ = str () .join ([chr (ord (char) - l11l11_opy_ - (l1lll1_opy_ + l11ll_opy_) % l11l1_opy_) for l1lll1_opy_, char in enumerate (l11l_opy_)])
	return eval (l11111_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
ADDON    = dixie.ADDON
l1111_opy_ = dixie.PROFILE
l1l1llll_opy_  = os.path.join(l1111_opy_, l1l1ll_opy_ (u"ࠬ࡯࡮ࡪ࣯ࠩ"))
l1l1ll11_opy_ = l1l1ll_opy_ (u"ࣰ࠭ࠧ")
def l1l11l1l_opy_(i, t1, l1l1l1ll_opy_=[]):
 t = l1l1ll11_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l1l1ll_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l111l1l_opy_ = l1l11l1l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11ll1l_opy_ = l1l11l1l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1ll1111_opy_ = l1l1ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡆ࡭ࡣࡺࡰࡪࡹࡳࡕࡸࣱࠪ")
dexter   = l1l1ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡥࡧࡻࣲࠫ")
l1l11ll1_opy_   = [l1ll1111_opy_, dexter]
def checkAddons():
    for addon in l1l11ll1_opy_:
        if l1l11lll_opy_(addon):
            createINI(addon)
def l1l11lll_opy_(addon):
    if xbmc.getCondVisibility(l1l1ll_opy_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡋࡥࡸࡇࡤࡥࡱࡱࠬࠪࡹࠩࠨࣳ") % addon) == 1:
        return True
    else:
        return False
def createINI(addon):
    l11l1ll_opy_ = os.path.join(l1l1llll_opy_, l1l1ll_opy_ (u"ࠪࡨࡪࡾࡴࡦࡴ࠱࡭ࡳ࡯ࠧࣴ"))
    if os.path.exists(l11l1ll_opy_):
        os.remove(l11l1ll_opy_)
    HOME  = dixie.PROFILE
    l1lll1ll_opy_ = os.path.join(HOME, l1l1ll_opy_ (u"ࠫ࡮ࡴࡩࠨࣵ"))
    l1ll11l1_opy_  = str(addon).split(l1l1ll_opy_ (u"ࠬ࠴ࣶࠧ"))[2] + l1l1ll_opy_ (u"࠭࠮ࡪࡰ࡬ࠫࣷ")
    l1ll1lll_opy_   = os.path.join(l1lll1ll_opy_, l1ll11l1_opy_)
    response = l11ll11_opy_(addon)
    l11llll_opy_ = response[l1l1ll_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧࣸ")][l1l1ll_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࣹࠧ")]
    l1lll11l_opy_  = l1l1ll_opy_ (u"ࠩ࡞ࣺࠫ") + addon + l1l1ll_opy_ (u"ࠪࡡࡡࡴࠧࣻ")
    l111ll1_opy_  =  file(l1ll1lll_opy_, l1l1ll_opy_ (u"ࠫࡼ࠭ࣼ"))
    l111ll1_opy_.write(l1lll11l_opy_)
    l1ll1l11_opy_ = []
    for channel in l11llll_opy_:
        l111111_opy_ = channel[l1l1ll_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫࣽ")]
        l1l1l11l_opy_ = l111l11_opy_(l111111_opy_)
        l1ll111l_opy_ = l1l1l11l_opy_
        l11111l_opy_ = l1l1l1l1_opy_(addon)
        l111lll_opy_  = dixie.mapChannelName(l1l1l11l_opy_)
        stream    = l11111l_opy_ + l1ll111l_opy_
        l1111ll_opy_   = l111lll_opy_ + l1l1ll_opy_ (u"࠭࠽ࠨࣾ") + stream
        if l1111ll_opy_ not in l1ll1l11_opy_:
            l1ll1l11_opy_.append(l1111ll_opy_)
    l1ll1l11_opy_.sort()
    for item in l1ll1l11_opy_:
        l111ll1_opy_.write(l1l1ll_opy_ (u"ࠢࠦࡵ࡟ࡲࠧࣿ") % item)
    l111ll1_opy_.close()
def l1l1l1l1_opy_(addon):
    if addon == l1ll1111_opy_:
        return l1l1ll_opy_ (u"ࠨࡈࡏࡅ࠿࠭ऀ")
    if addon == dexter:
        return l1l1ll_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪँ")
def l111l11_opy_(l1llll_opy_):
    l11l11l_opy_ = l1llll_opy_.split(l1l1ll_opy_ (u"ࠪࠤࡠ࠭ं"), 1)
    l1llll_opy_  = l11l11l_opy_[0]
    l1llll_opy_  = l1llll_opy_.replace(l1l1ll_opy_ (u"ࠫࠥࠦࠧः"), l1l1ll_opy_ (u"ࠬ࠭ऄ"))
    l1llll_opy_  = l1llll_opy_.replace(l1l1ll_opy_ (u"࠭ࡕࡌ࠼ࠣࠫअ"), l1l1ll_opy_ (u"ࠧࠨआ"))
    l1llll_opy_  = l1llll_opy_.replace(l1l1ll_opy_ (u"ࠨࡗࡖࡅ࠿ࠦࠧइ"), l1l1ll_opy_ (u"ࠩࠪई"))
    l1llll_opy_  = l1llll_opy_.replace(l1l1ll_opy_ (u"ࠪࡇࡆࡀࠠࠨउ"), l1l1ll_opy_ (u"ࠫࠬऊ"))
    l1llll_opy_  = l1llll_opy_.replace(l1l1ll_opy_ (u"ࠬࡏࡎࡕ࠼ࠣࠫऋ"), l1l1ll_opy_ (u"࠭ࠧऌ"))
    if l1l1ll_opy_ (u"ࠧࡍࡋ࡙ࡉࠥࡔࡂࡂࠩऍ") or l1l1ll_opy_ (u"ࠨࡎࡌ࡚ࡊࠦࡎࡇࡎࠪऎ") or l1l1ll_opy_ (u"ࠩࡏࡍ࡛ࡋࠠࡏࡈࡏࠫए") in l1llll_opy_:
        l1llll_opy_  = l1llll_opy_.rsplit(l1l1ll_opy_ (u"ࠪ࠾ࠬऐ"), 1)[0]
    if l1l1ll_opy_ (u"ࠫࠥ࠳ࠠࠨऑ") in l1llll_opy_:
        l1llll_opy_  = l1llll_opy_.rsplit(l1l1ll_opy_ (u"ࠬࠦ࠭ࠡࠩऒ"), 1)[0]
    return l11lll1_opy_(l1llll_opy_)
def l11lll1_opy_(name):
    import re
    name  = re.sub(l1l1ll_opy_ (u"࠭࡜ࠩ࡝࠳࠱࠾࠯࡝ࠫ࡞ࠬࠫओ"), l1l1ll_opy_ (u"ࠧࠨऔ"), name)
    items = name.split(l1l1ll_opy_ (u"ࠨ࡟ࠪक"))
    name  = l1l1ll_opy_ (u"ࠩࠪख")
    for item in items:
        if len(item) == 0:
            continue
        item += l1l1ll_opy_ (u"ࠪࡡࠬग")
        item  = re.sub(l1l1ll_opy_ (u"ࠫࡡࡡ࡛࡟ࠫࡠ࠮ࡡࡣࠧघ"), l1l1ll_opy_ (u"ࠬ࠭ङ"), item)
        if len(item) > 0:
            name += item
    name  = name.replace(l1l1ll_opy_ (u"࡛࠭ࠨच"), l1l1ll_opy_ (u"ࠧࠨछ"))
    name  = name.replace(l1l1ll_opy_ (u"ࠨ࡟ࠪज"), l1l1ll_opy_ (u"ࠩࠪझ"))
    name  = name.strip()
    while True:
        length = len(name)
        name = name.replace(l1l1ll_opy_ (u"ࠪࠤࠥ࠭ञ"), l1l1ll_opy_ (u"ࠫࠥ࠭ट"))
        if length == len(name):
            break
    return name.strip()
def getURL(url):
    if url.startswith(l1l1ll_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡇࡑ࡛࠺ࠨठ")):
        url = url.replace(l1l1ll_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡈࡒࡕ࠻ࠩड"), l1l1ll_opy_ (u"ࠧࠨढ")).replace(l1l1ll_opy_ (u"ࠨ࠯࠰ࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧण"), l1l1ll_opy_ (u"ࠩࡿࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧत"))
        return url
    if url.startswith(l1l1ll_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡆࠪथ")):
        return l11l1l1_opy_(url, dexter)
    if url.startswith(l1l1ll_opy_ (u"ࠫࡋࡒࡁࠨद")):
        return l11l1l1_opy_(url, l1ll1111_opy_)
    response = l1lll111_opy_(url)
    stream   = url.split(l1l1ll_opy_ (u"ࠬࡀࠧध"), 1)[-1]
    try:
        result = response[l1l1ll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭न")]
        l1ll1ll1_opy_  = result[l1l1ll_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ऩ")]
    except Exception as e:
        l1l1lll1_opy_(e)
        return None
    for file in l1ll1ll1_opy_:
        l1llll_opy_ = file[l1l1ll_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧप")]
        if stream in l1llll_opy_:
            return file[l1l1ll_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧफ")]
    return None
def l11l1l1_opy_(url, addon):
    PATH = l11l111_opy_(addon)
    if os.path.exists(PATH):
        response = json.load(open(PATH))
    else:
        response = l11ll11_opy_(addon)
    l1ll11ll_opy_ = url.split(l1l1ll_opy_ (u"ࠪ࠾ࠬब"))[0]
    l11l1l_opy_    = url.split(l1l1ll_opy_ (u"ࠫ࠿࠭भ"), 1)[-1]
    l1l1l111_opy_ = l11l1l_opy_.split(l1l1ll_opy_ (u"࡛ࠬࠦࠨम"), 1)
    stream  = l1l1l111_opy_[0]
    l1ll1ll1_opy_  = response[l1l1ll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭य")][l1l1ll_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭र")]
    for file in l1ll1ll1_opy_:
        l11l11l_opy_ = file[l1l1ll_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧऱ")].split(l1l1ll_opy_ (u"ࠩࠣ࡟ࠬल"), 1)
        l1llll_opy_  = l11l11l_opy_[0]
        l1llll_opy_  = l1llll_opy_.replace(l1l1ll_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡻ࡭࡯ࡴࡦ࡟ࠪळ"), l1l1ll_opy_ (u"ࠫࠬऴ"))
        if stream in l1llll_opy_:
            l1ll1l1l_opy_ = file[l1l1ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪव")]
            if l1ll11ll_opy_ == l1l1ll_opy_ (u"࠭ࡆࡍࡃࡖࠫश"):
                return l1ll1l1l_opy_
            l1ll1l1l_opy_ = l1ll1l1l_opy_.replace(l1l1ll_opy_ (u"ࠧ࠯ࡶࡶࠫष"), l1l1ll_opy_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧस"))
            return l1ll1l1l_opy_
def l11ll11_opy_(addon):
    if addon == l1ll1111_opy_:
        query = l1l1ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡊࡱࡧࡷ࡭ࡧࡶࡷ࡙ࡼ࠯ࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡵࡷࡶࡪࡧ࡭ࡠࡸ࡬ࡨࡪࡵࠦࡦࡺࡷࡶࡦࠬࡰࡢࡩࡨࠪࡵࡲ࡯ࡵࠨࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡂࠬࡴࡪࡶ࡯ࡩࡂࡇ࡬࡭ࠨࡸࡶࡱࡃ࠰ࠨह")
        content = doJSON(query)
        return l1lll1l1_opy_(addon, content)
    if addon == dexter:
        query   = l1111l1_opy_(dexter)
        content = doJSON(query)
        return l1lll1l1_opy_(dexter, content)
def l1lll1l1_opy_(addon, content):
    PATH  = l11l111_opy_(addon)
    json.dump(content, open(PATH,l1l1ll_opy_ (u"ࠪࡻࠬऺ")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    l1l1ll1l_opy_  = (l1l1ll_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࠥࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧऻ") % query)
    response = xbmc.executeJSONRPC(l1l1ll1l_opy_)
    content  = json.loads(response)
    return content
def l11l111_opy_(addon):
    if addon == l1ll1111_opy_:
        return os.path.join(dixie.PROFILE, l1l1ll_opy_ (u"ࠬ࡬ࡴࡦ࡯ࡳ़ࠫ"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l1l1ll_opy_ (u"࠭ࡤࡵࡧࡰࡴࠬऽ"))
def l1111l1_opy_(addon):
    if addon == dexter:
        query = l1l1ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡦࡨࡼࠬा")
        response = doJSON(query)
        l1ll1ll1_opy_    = response[l1l1ll_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨि")][l1l1ll_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨी")]
        for file in l1ll1ll1_opy_:
            l1llll_opy_ = file[l1l1ll_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩु")]
            if l1llll_opy_ == l1l1ll_opy_ (u"ࠫࡆࡲ࡬ࠨू"):
                login = file[l1l1ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪृ")]
                return login
def l1lll111_opy_(url):
    if url.startswith(l1l1ll_opy_ (u"࠭ࡉࡑࡎࡄ࡝࠿࠭ॄ")):
        l1l1ll1l_opy_ = (l1l1ll_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡦࡧࡩࡩࡱ࡮ࡤࡽࡪࡸ࠯ࡀࡷࡵࡰࡂࡻࡲ࡭ࠨࡰࡳࡩ࡫࠽࠳ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡹࡩࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴ࠽ࠧࡋࡓࡍࡉࡃࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬॅ"))
    if url.startswith(l1l1ll_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠲࠻ࠩॆ")):
        l1l1ll1l_opy_ = (l1l1ll_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰ࡭ࡣࡼࡩࡷࡽࡷࡸ࠱ࡂࡹࡷࡲ࠽ࡶࡴ࡯ࠪࡲࡵࡤࡦ࠿࠴࠴࠶ࠬ࡮ࡢ࡯ࡨࡁ࡜ࡧࡴࡤࡪ࠮ࡐ࡮ࡼࡥࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࡀࠪࡸࡻࡢࡵ࡫ࡷࡰࡪࡹ࡟ࡶࡴ࡯ࡁࠫࡲ࡯ࡨࡩࡨࡨࡤ࡯࡮࠾ࡈࡤࡰࡸ࡫ࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬे"))
    if url.startswith(l1l1ll_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡔ࠽ࠫै")):
        l1l1ll1l_opy_ = (l1l1ll_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺ࠳ࡄࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠩࡰࡴ࡭ࡧࡦࡦࡢ࡭ࡳࡃࡆࡢ࡮ࡶࡩࠫࡳ࡯ࡥࡧࡀ࠵࠶࠹ࠦ࡯ࡣࡰࡩࡂࡒࡩࡴࡶࡨࡲࠪ࠸࠰ࡍ࡫ࡹࡩࠫࡹࡵࡣࡶ࡬ࡸࡱ࡫ࡳࡠࡷࡵࡰࠫࡻࡲ࡭࠿ࡸࡶࡱࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫॉ"))
    if url.startswith(l1l1ll_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡍ࡙࡜࠺ࠨॊ")):
        l1l1ll1l_opy_ = (l1l1ll_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡸࡻࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫो"))
    if url.startswith(l1l1ll_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡊ࠺ࠨौ")):
        l1l1ll1l_opy_ = (l1l1ll_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿ࡤࡰࡱࠬࡥࡹࡶࡵࡥࠫࡶࡡࡨࡧࠩࡴࡱࡵࡴࠧࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡁࠫࡺࡩࡵ࡮ࡨࡁࠪ࠻ࡢࡄࡑࡏࡓࡗࠫ࠲࠱ࡹ࡫࡭ࡹ࡫ࠥ࠶ࡦࡄࡰࡱࠫ࠲࠱ࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠨ࠹ࡧࠫ࠲ࡧࡅࡒࡐࡔࡘࠥ࠶ࡦࠩࡹࡷࡲࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁ्ࠬ"))
    if url.startswith(l1l1ll_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡓࡄ࠽ࠫॎ")):
        l1l1ll1l_opy_ = (l1l1ll_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡦࡤࡲࡳࡹ࠵࠿ࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠫ࡬ࡡ࡯ࡣࡵࡸࡂࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࠩࡱࡴࡪࡥ࠾࠹ࠩࡴ࡮ࡲ࡬ࡰࡹࡀࡐ࡮ࡼࡥࠦ࠴࠳ࡗࡹࡸࡥࡢ࡯ࡶࠪࡺࡸ࡬࠾ࡴࡤࡲࡩࡵ࡭ࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ॏ"))
    if url.startswith(l1l1ll_opy_ (u"ࠫࡎࡖࡔࡔ࠼ࠪॐ")):
        l1l1ll1l_opy_ = (l1l1ll_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࡯ࡰࡵࡸ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡱ࡯ࡶࡦࡶࡹࡣࡦࡲ࡬ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠦࡵ࡫ࡷࡰࡪࡃࡁ࡭࡮ࠨ࠶࠵ࡩࡨࡢࡰࡱࡩࡱࡹࠦࡶࡴ࡯ࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ॑"))
    try:
        dixie.ShowBusy()
        addon =  l1l1ll1l_opy_.split(l1l1ll_opy_ (u"࠭࠯࠰॒ࠩ"), 1)[-1].split(l1l1ll_opy_ (u"ࠧ࠰ࠩ॓"), 1)[0]
        login = l1l1ll_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭॔") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1l1ll1l_opy_)
        dixie.log(response)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1l1lll1_opy_(e)
        return {l1l1ll_opy_ (u"ࠩࡈࡶࡷࡵࡲࠨॕ") : l1l1ll_opy_ (u"ࠪࡔࡱࡻࡧࡪࡰࠣࡉࡷࡸ࡯ࡳࠩॖ")}
def l1llll11_opy_():
    modules = map(__import__, [l1l11l1l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l111l1l_opy_)):
        return l1l1ll_opy_ (u"࡙ࠫࡸࡵࡦࠩॗ")
    if len(modules[-1].Window(10**4).getProperty(l11ll1l_opy_)):
        return l1l1ll_opy_ (u"࡚ࠬࡲࡶࡧࠪक़")
    return l1l1ll_opy_ (u"࠭ࡆࡢ࡮ࡶࡩࠬख़")
def l1l1lll1_opy_(e):
    l1llll1l_opy_ = l1l1ll_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠲ࠠࡢࡰࠣࡩࡷࡸ࡯ࡳࠢࡲࡧࡨࡻࡲࡦࡦ࠽ࠤࡏ࡙ࡏࡏࠢࡈࡶࡷࡵࡲ࠻ࠢࠨࡷࠬग़")  %e
    l1lllll1_opy_ = l1l1ll_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡴࡨ࠱ࡱ࡯࡮࡬ࠢࡷ࡬࡮ࡹࠠࡤࡪࡤࡲࡳ࡫࡬ࠡࡣࡱࡨࠥࡺࡲࡺࠢࡤ࡫ࡦ࡯࡮࠯ࠩज़")
    l1llllll_opy_ = l1l1ll_opy_ (u"ࠩࡘࡷࡪࡀࠠࡄࡱࡱࡸࡪࡾࡴࠡࡏࡨࡲࡺࠦ࠽࠿ࠢࡕࡩࡲࡵࡶࡦࠢࡖࡸࡷ࡫ࡡ࡮ࠩड़")
    dixie.log(e)
    dixie.DialogOK(l1llll1l_opy_, l1lllll1_opy_, l1llllll_opy_)
if __name__ == l1l1ll_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬढ़"):
    checkAddons()