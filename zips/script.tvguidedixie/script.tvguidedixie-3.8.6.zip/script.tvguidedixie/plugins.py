# coding: UTF-8
import sys
l11ll111_opy_ = sys.version_info [0] == 2
l1lll1l1_opy_ = 2048
l11lllll_opy_ = 7
def l1l11_opy_ (l11ll1_opy_):
	global l1llll11_opy_
	l1ll1111_opy_ = ord (l11ll1_opy_ [-1])
	l11ll11l_opy_ = l11ll1_opy_ [:-1]
	l11l11l_opy_ = l1ll1111_opy_ % len (l11ll11l_opy_)
	l111l1_opy_ = l11ll11l_opy_ [:l11l11l_opy_] + l11ll11l_opy_ [l11l11l_opy_:]
	if l11ll111_opy_:
		l1lll1_opy_ = unicode () .join ([unichr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	else:
		l1lll1_opy_ = str () .join ([chr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	return eval (l1lll1_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l1l11ll11_opy_    = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡱࡸࡻ࠭ࣃ")
l1l111l1l_opy_ = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡻࡱ࡯ࡰࡵࡸࠪࣄ")
l1l1lll11_opy_    = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡶࡴ࡮ࠫࣅ")
locked = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲ࡯ࡤ࡭ࡨࡨࡹࡼࠧࣆ")
l1l111111_opy_     = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡵ࡭ࡶ࡬ࡱࡦࡺࡥ࡮ࡣࡱ࡭ࡦ࠭ࣇ")
l11lll11l_opy_   = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡭࡫ࡸࡼ࠳ࡺࡶࠨࣈ")
l1l11l11l_opy_    = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡆࡆࡗࡵࡵࡲࡵࡵࠪࣉ")
l1l1ll1l1_opy_ = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡩࡧࡵ࡯ࡵࠩ࣊")
l1l11l1l1_opy_    = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡧࡱࡻࡩࡱࡶࡹࠫ࣋")
l1l1l1l11_opy_ = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢ࡫ࡳࡸࡻ࠭࣌")
l11lll1ll_opy_ = [l1l11ll11_opy_, locked, l11lll11l_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1l11_opy_ (u"࠭ࡩ࡯࡫ࠪ࣍"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1l1111ll_opy_ = l1l11_opy_ (u"ࠧࠨ࣎")
def l11lll111_opy_(i, t1, l1ll11l1l_opy_=[]):
 t = l1l1111ll_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1ll11l1l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1ll111l1_opy_ = l11lll111_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l1ll1111l_opy_ = l11lll111_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l11lll1ll_opy_:
        if l1l1l11l1_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1l1l11l1_opy_(addon):
    if xbmc.getCondVisibility(l1l11_opy_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫࠩࡸ࠯࣏ࠧ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l1ll11ll1_opy_ = str(addon).split(l1l11_opy_ (u"ࠩ࠱࣐ࠫ"))[2] + l1l11_opy_ (u"ࠪ࠲࡮ࡴࡩࠨ࣑")
    l11llll1l_opy_  = os.path.join(PATH, l1ll11ll1_opy_)
    try:
        l1ll111ll_opy_ = l1ll1l111_opy_(addon)
    except KeyError:
        dixie.log(l1l11_opy_ (u"ࠫ࠲࠳࠭࠮࠯ࠣࡏࡪࡿࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡩࡨࡸࡋ࡯࡬ࡦࡵࠣ࠱࠲࠳࠭࠮࣒ࠢࠪ") + addon)
        result = {l1l11_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࡷ࣓ࠬ"): [{l1l11_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩࣔ"): l1l11_opy_ (u"ࡵࠨࡨ࡬ࡰࡪ࠭ࣕ"), l1l11_opy_ (u"ࡶࠩࡷࡽࡵ࡫ࠧࣖ"): l1l11_opy_ (u"ࡷࠪࡹࡳࡱ࡮ࡰࡹࡱࠫࣗ"), l1l11_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࠩࣘ"): l1l11_opy_ (u"ࡹࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸࡹࡺࠪࣙ"), l1l11_opy_ (u"ࡺ࠭࡬ࡢࡤࡨࡰࠬࣚ"): l1l11_opy_ (u"ࡻࠧࡏࡑࠣࡇࡍࡇࡎࡏࡇࡏࡗࠬࣛ")}], l1l11_opy_ (u"ࡵࠨ࡮࡬ࡱ࡮ࡺࡳࠨࣜ"):{l1l11_opy_ (u"ࡶࠩࡶࡸࡦࡸࡴࠨࣝ"): 0, l1l11_opy_ (u"ࡷࠪࡸࡴࡺࡡ࡭ࠩࣞ"): 1, l1l11_opy_ (u"ࡸࠫࡪࡴࡤࠨࣟ"): 1}}
    l1l111ll1_opy_  = file(l11llll1l_opy_, l1l11_opy_ (u"ࠫࡼ࠭࣠"))
    l1l111ll1_opy_.write(l1l11_opy_ (u"ࠬࡡࠧ࣡"))
    l1l111ll1_opy_.write(addon)
    l1l111ll1_opy_.write(l1l11_opy_ (u"࠭࡝ࠨ࣢"))
    l1l111ll1_opy_.write(l1l11_opy_ (u"ࠧ࡝ࡰࣣࠪ"))
    l1l11lll1_opy_ = []
    for channel in l1ll111ll_opy_:
        l1lll1ll1_opy_ = channel[l1l11_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࣤ")]
        l1lll1ll1_opy_ = l1111lll_opy_(l1lll1ll1_opy_)
        l1ll11l11_opy_ = dixie.mapChannelName(l1lll1ll1_opy_)
        stream   = channel[l1l11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧࣥ")]
        l1ll11111_opy_ = l1ll11l11_opy_ + l1l11_opy_ (u"ࠪࡁࣦࠬ") + stream
        l1l11lll1_opy_.append(l1ll11111_opy_)
        l1l11lll1_opy_.sort()
    for item in l1l11lll1_opy_:
        l1l111ll1_opy_.write(l1l11_opy_ (u"ࠦࠪࡹ࡜࡯ࠤࣧ") % item)
    l1l111ll1_opy_.close()
def l1111lll_opy_(name):
    import re
    name  = re.sub(l1l11_opy_ (u"ࠬࡢࠨ࡜࠲࠰࠽࠮ࡣࠪ࡝ࠫࠪࣨ"), l1l11_opy_ (u"ࣩ࠭ࠧ"), name)
    items = name.split(l1l11_opy_ (u"ࠧ࡞ࠩ࣪"))
    name  = l1l11_opy_ (u"ࠨࠩ࣫")
    for item in items:
        if len(item) == 0:
            continue
        item += l1l11_opy_ (u"ࠩࡠࠫ࣬")
        item  = re.sub(l1l11_opy_ (u"ࠪࡠࡠࡡ࡞ࠪ࡟࠭ࡠࡢ࣭࠭"), l1l11_opy_ (u"࣮ࠫࠬ"), item)
        if len(item) > 0:
            name += item
    name  = name.replace(l1l11_opy_ (u"ࠬࡡ࣯ࠧ"), l1l11_opy_ (u"ࣰ࠭ࠧ"))
    name  = name.replace(l1l11_opy_ (u"ࠧ࡞ࣱࠩ"), l1l11_opy_ (u"ࠨࣲࠩ"))
    name  = name.strip()
    while True:
        length = len(name)
        name = name.replace(l1l11_opy_ (u"ࠩࠣࠤࠬࣳ"), l1l11_opy_ (u"ࠪࠤࠬࣴ"))
        if length == len(name):
            break
    return name.strip()
def l1ll1l111_opy_(addon):
    if (addon == l1l11ll11_opy_) or (addon == l1l111l1l_opy_) or (addon == l1l1l1l11_opy_):
        try:
            if xbmcaddon.Addon(addon).getSetting(l1l11_opy_ (u"ࠫ࡬࡫࡮ࡳࡧࠪࣵ")) == l1l11_opy_ (u"ࠬࡺࡲࡶࡧࣶࠪ"):
                xbmcaddon.Addon(addon).setSetting(l1l11_opy_ (u"࠭ࡧࡦࡰࡵࡩࠬࣷ"), l1l11_opy_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭ࣸ"))
                xbmcgui.Window(10000).setProperty(l1l11_opy_ (u"ࠨࡒࡏ࡙ࡌࡏࡎࡠࡉࡈࡒࡗࡋࣹࠧ"), l1l11_opy_ (u"ࠩࡗࡶࡺ࡫ࣺࠧ"))
            if xbmcaddon.Addon(addon).getSetting(l1l11_opy_ (u"ࠪࡸࡻ࡭ࡵࡪࡦࡨࠫࣻ")) == l1l11_opy_ (u"ࠫࡹࡸࡵࡦࠩࣼ"):
                xbmcaddon.Addon(addon).setSetting(l1l11_opy_ (u"ࠬࡺࡶࡨࡷ࡬ࡨࡪ࠭ࣽ"), l1l11_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬࣾ"))
                xbmcgui.Window(10000).setProperty(l1l11_opy_ (u"ࠧࡑࡎࡘࡋࡎࡔ࡟ࡕࡘࡊ࡙ࡎࡊࡅࠨࣿ"), l1l11_opy_ (u"ࠨࡖࡵࡹࡪ࠭ऀ"))
        except: pass
        l1l111l11_opy_  = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬँ") + addon
        l1l1l1ll1_opy_ =  l1ll11lll_opy_(addon)
        query   =  l1l111l11_opy_ + l1l1l1ll1_opy_
        return sendJSON(query, addon)
    return l1l1l1111_opy_(addon)
def l1l1l1111_opy_(addon):
    if addon == l11lll11l_opy_:
        l1l1l11ll_opy_ = [l1l11_opy_ (u"ࠪ࠹ࠬं"), l1l11_opy_ (u"ࠫ࠶࠶࠶ࠨः"), l1l11_opy_ (u"ࠬ࠺ࠧऄ"), l1l11_opy_ (u"࠭࠲࠷࠵ࠪअ"), l1l11_opy_ (u"ࠧ࠲࠵࠵ࠫआ")]
    if addon == locked:
        l1l1l11ll_opy_ = [l1l11_opy_ (u"ࠨ࠵࠳ࠫइ"), l1l11_opy_ (u"ࠩ࠶࠵ࠬई"), l1l11_opy_ (u"ࠪ࠷࠷࠭उ"), l1l11_opy_ (u"ࠫ࠸࠹ࠧऊ"), l1l11_opy_ (u"ࠬ࠹࠴ࠨऋ"), l1l11_opy_ (u"࠭࠳࠶ࠩऌ"), l1l11_opy_ (u"ࠧ࠴࠺ࠪऍ"), l1l11_opy_ (u"ࠨ࠶࠳ࠫऎ"), l1l11_opy_ (u"ࠩ࠷࠵ࠬए"), l1l11_opy_ (u"ࠪ࠸࠺࠭ऐ"), l1l11_opy_ (u"ࠫ࠹࠽ࠧऑ"), l1l11_opy_ (u"ࠬ࠺࠹ࠨऒ"), l1l11_opy_ (u"࠭࠵࠳ࠩओ")]
    if addon == l1l111111_opy_:
        l1l1l11ll_opy_ = [l1l11_opy_ (u"ࠧ࠳࠷ࠪऔ"), l1l11_opy_ (u"ࠨ࠴࠹ࠫक"), l1l11_opy_ (u"ࠩ࠵࠻ࠬख"), l1l11_opy_ (u"ࠪ࠶࠾࠭ग"), l1l11_opy_ (u"ࠫ࠸࠶ࠧघ"), l1l11_opy_ (u"ࠬ࠹࠱ࠨङ"), l1l11_opy_ (u"࠭࠳࠳ࠩच"), l1l11_opy_ (u"ࠧ࠴࠷ࠪछ"), l1l11_opy_ (u"ࠨ࠵࠹ࠫज"), l1l11_opy_ (u"ࠩ࠶࠻ࠬझ"), l1l11_opy_ (u"ࠪ࠷࠽࠭ञ"), l1l11_opy_ (u"ࠫ࠸࠿ࠧट"), l1l11_opy_ (u"ࠬ࠺࠰ࠨठ"), l1l11_opy_ (u"࠭࠴࠲ࠩड"), l1l11_opy_ (u"ࠧ࠵࠺ࠪढ"), l1l11_opy_ (u"ࠨ࠶࠼ࠫण"), l1l11_opy_ (u"ࠩ࠸࠴ࠬत"), l1l11_opy_ (u"ࠪ࠹࠷࠭थ"), l1l11_opy_ (u"ࠫ࠺࠺ࠧद"), l1l11_opy_ (u"ࠬ࠻࠶ࠨध"), l1l11_opy_ (u"࠭࠵࠸ࠩन"), l1l11_opy_ (u"ࠧ࠶࠺ࠪऩ"), l1l11_opy_ (u"ࠨ࠷࠼ࠫप"), l1l11_opy_ (u"ࠩ࠹࠴ࠬफ"), l1l11_opy_ (u"ࠪ࠺࠶࠭ब"), l1l11_opy_ (u"ࠫ࠻࠸ࠧभ"), l1l11_opy_ (u"ࠬ࠼࠳ࠨम"), l1l11_opy_ (u"࠭࠶࠶ࠩय"), l1l11_opy_ (u"ࠧ࠷࠸ࠪर"), l1l11_opy_ (u"ࠨ࠸࠺ࠫऱ"), l1l11_opy_ (u"ࠩ࠹࠽ࠬल"), l1l11_opy_ (u"ࠪ࠻࠵࠭ळ"), l1l11_opy_ (u"ࠫ࠼࠺ࠧऴ"), l1l11_opy_ (u"ࠬ࠽࠷ࠨव"), l1l11_opy_ (u"࠭࠷࠹ࠩश"), l1l11_opy_ (u"ࠧ࠹࠲ࠪष"), l1l11_opy_ (u"ࠨ࠺࠴ࠫस")]
    login = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠪࡹ࠯ࠨह") % addon
    sendJSON(login, addon)
    l1l1l111l_opy_ = []
    for l1l1lll1l_opy_ in l1l1l11ll_opy_:
        if addon == l11lll11l_opy_:
            query = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳ࠰ࡁࡰࡳࡩ࡫࡟ࡪࡦࡀࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡳ࡯ࡥࡧࡀࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡹࡥࡤࡶ࡬ࡳࡳࡥࡩࡥ࠿ࠨࡷࠬऺ") % (addon, l1l1lll1l_opy_)
        if (addon == locked) or (addon == l1l111111_opy_):
            query = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴ࠱ࡂࡹࡷࡲ࠽ࠦࡵࠩࡱࡴࡪࡥ࠾࠶ࠩࡲࡦࡳࡥ࠾ࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࠬࡰ࡭ࡣࡼࡁࠫࡪࡡࡵࡧࡀࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠩࡴࡦ࡭ࡥ࠾ࠩऻ") % (addon, l1l1lll1l_opy_)
        response = sendJSON(query, addon)
        l1l1l111l_opy_.extend(response)
    return l1l1l111l_opy_
def sendJSON(query, addon):
    l1l1l1lll_opy_     = l1l11_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࠦࡵࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ़") % query
    l1l11ll1l_opy_  = xbmc.executeJSONRPC(l1l1l1lll_opy_)
    response = json.loads(l1l11ll1l_opy_)
    result   = response[l1l11_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ऽ")]
    if xbmcgui.Window(10000).getProperty(l1l11_opy_ (u"ࠧࡑࡎࡘࡋࡎࡔ࡟ࡈࡇࡑࡖࡊ࠭ा")) == l1l11_opy_ (u"ࠨࡖࡵࡹࡪ࠭ि"):
        xbmcaddon.Addon(addon).setSetting(l1l11_opy_ (u"ࠩࡪࡩࡳࡸࡥࠨी"), l1l11_opy_ (u"ࠪࡸࡷࡻࡥࠨु"))
    if xbmcgui.Window(10000).getProperty(l1l11_opy_ (u"ࠫࡕࡒࡕࡈࡋࡑࡣ࡙࡜ࡇࡖࡋࡇࡉࠬू")) == l1l11_opy_ (u"࡚ࠬࡲࡶࡧࠪृ"):
        xbmcaddon.Addon(addon).setSetting(l1l11_opy_ (u"࠭ࡴࡷࡩࡸ࡭ࡩ࡫ࠧॄ"), l1l11_opy_ (u"ࠧࡵࡴࡸࡩࠬॅ"))
    return result[l1l11_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧॆ")]
def l1ll11lll_opy_(addon):
    if (addon == l1l11ll11_opy_) or (addon == l1l111l1l_opy_):
        return l1l11_opy_ (u"ࠩ࠲ࡃࡨࡧࡴ࠾࠯࠵ࠪࡩࡧࡴࡦࠨࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠦࡦࡰࡧࡈࡦࡺࡥࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡳ࡯ࡥࡧࡀ࠶ࠫࡴࡡ࡮ࡧࡀࡑࡾࠫ࠲࠱ࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠩࡶࡪࡩ࡯ࡳࡦࡱࡥࡲ࡫ࠦࡴࡶࡤࡶࡹࡊࡡࡵࡧࠩࡹࡷࡲ࠽ࡶࡴ࡯ࠫे")
    if addon == l1l1l1l11_opy_:
        return l1l11_opy_ (u"ࠪ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡲࡩࡷࡧࡷࡺࡤࡧ࡬࡭ࠨࡨࡼࡹࡸࡡࠧࡲࡤ࡫ࡪࠬࡰ࡭ࡱࡷࠪࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠽ࠧࡶ࡬ࡸࡱ࡫࠽ࡂ࡮࡯ࠩ࠷࠶ࡣࡩࡣࡱࡲࡪࡲࡳࠧࡷࡵࡰࠬै")
    return l1l11_opy_ (u"ࠫࠬॉ")
def l1l1ll111_opy_():
    modules = map(__import__, [l11lll111_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1ll111l1_opy_)):
        return l1l11_opy_ (u"࡚ࠬࡲࡶࡧࠪॊ")
    if len(modules[-1].Window(10**4).getProperty(l1ll1111l_opy_)):
        return l1l11_opy_ (u"࠭ࡔࡳࡷࡨࠫो")
    return l1l11_opy_ (u"ࠧࡇࡣ࡯ࡷࡪ࠭ौ")
def l1l11l111_opy_(e, addon):
    l1l1ll11l_opy_ = l1l11_opy_ (u"ࠨࡕࡲࡶࡷࡿࠬࠡࡣࡱࠤࡪࡸࡲࡰࡴࠣࡳࡨࡩࡵࡳࡧࡧ࠾ࠥࡐࡓࡐࡐࠣࡉࡷࡸ࡯ࡳ࠼ࠣࠩࡸ࠲ࠠࠦࡵ्ࠪ")  % (e, addon)
    l1l1llll1_opy_ = l1l11_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡹࡸࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡦࡰࡴࡸࡱ࠳࠭ॎ")
    l1l1ll1ll_opy_ = l1l11_opy_ (u"࡙ࠪࡵࡲ࡯ࡢࡦࠣࡥࠥࡲ࡯ࡨࠢࡹ࡭ࡦࠦࡴࡩࡧࠣࡥࡩࡪ࡯࡯ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠤࡦࡴࡤࠡࡲࡲࡷࡹࠦࡴࡩࡧࠣࡰ࡮ࡴ࡫࠯ࠩॏ")
    dixie.log(addon)
    dixie.log(e)
def l1l11111l_opy_(addon):
    l1l111l11_opy_ = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧॐ") + addon
    l11ll1lll_opy_  = l1l11_opy_ (u"ࠬࡅࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࡩࡶࡷࡴࠪ࠹ࡡࠦ࠴ࡩࠩ࠷࡬࡭ࡦࡶࡤࡰࡰ࡫ࡴࡵ࡮ࡨ࠲ࡨࡵࠥ࠳ࡨࡘࡏ࡙ࡻࡲ࡬࠳࠻࠴࠷࠸࠰࠲࠸ࠨ࠶࡫ࡺࡨࡶ࡯ࡥࡷࠪ࠸ࡦ࡯ࡧࡺࠩ࠷࡬ࡕ࡬ࠧ࠵࠹࠷࠶ࡴࡶࡴ࡮ࠩ࠷࠻࠲࠱ࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠪ࠸࠵࠳࠲࡯࡭ࡻ࡫ࠥ࠳࠷࠵࠴ࡹࡼ࠮࡫ࡲࡪࠪࡲࡵࡤࡦ࠿࠴ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡻ࡫ࠥ࠳࠲ࡗ࡚ࠫࡻࡲ࡭࠿࡫ࡸࡹࡶࠥ࠴ࡣࠨ࠶࡫ࠫ࠲ࡧ࡯ࡨࡸࡦࡲ࡫ࡦࡶࡷࡰࡪ࠴ࡣࡰࠧ࠵ࡪ࡚ࡑࡔࡶࡴ࡮࠵࠽࠶࠲࠳࠲࠴࠺ࠪ࠸ࡦࡍ࡫ࡹࡩࠪ࠸࠵࠳࠲ࡗ࡚࠳ࡺࡸࡵࠩ॑")
    l1l1l111l_opy_  = []
    l1l1l111l_opy_ += sendJSON(l1l111l11_opy_ + l11ll1lll_opy_, addon)
    l1l1l111l_opy_.sort()
    return l1l1l111l_opy_
def l1l1lllll_opy_(addon):
    l1l111l11_opy_ = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰॒ࠩ") + addon
    l11ll1lll_opy_ = l1l11_opy_ (u"ࠧ࠰ࡁࡩࡥࡳࡧࡲࡵ࠿࡫ࡸࡹࡶࠥ࠴ࡣࠨ࠶࡫ࠫ࠲ࡧࡩࡲࡳ࠳࡭࡬ࠦ࠴ࡩ࡜ࡩࡌ࠲࠹ࡖࠩࡱࡴࡪࡥ࠾࠳ࠩࡲࡦࡳࡥ࠾ࡎ࡬ࡺࡪࠫ࠲࠱ࡗࡎࠩ࠷࠶ࡓࡱࡱࡵࡸࡸࠬࡵࡳ࡮ࡀ࡬ࡹࡺࡰࡴࠧ࠶ࡥࠪ࠸ࡦࠦ࠴ࡩ࡫ࡴࡵ࠮ࡨ࡮ࠨ࠶࡫࠻ࡱࡒࡩࡈ࠸ࠬ॓")
    l11lll1l1_opy_ = l1l11_opy_ (u"ࠨ࠱ࡂࡪࡦࡴࡡࡳࡶࡀ࡬ࡹࡺࡰࡴࠧ࠶ࡥࠪ࠸ࡦࠦ࠴ࡩ࡫ࡴࡵ࠮ࡨ࡮ࠨ࠶࡫ࡌࡧࡘࡏ࡮࡞ࠫࡳ࡯ࡥࡧࡀ࠵ࠫࡴࡡ࡮ࡧࡀࡐ࡮ࡼࡥࠦ࠴࠳࡙ࡘࠫ࠲ࡧࡅࡄࡒࠪ࠸࠰ࡔࡲࡲࡶࡹࡹࠦࡶࡴ࡯ࡁ࡭ࡺࡴࡱࡵࠨ࠷ࡦࠫ࠲ࡧࠧ࠵ࡪ࡬ࡵ࡯࠯ࡩ࡯ࠩ࠷࡬ࡦ࠺࡬ࡪ࠼ࡓ࠭॔")
    l1l1l111l_opy_  = []
    l1l1l111l_opy_ += sendJSON(l1l111l11_opy_ + l11ll1lll_opy_, addon)
    l1l1l111l_opy_ += sendJSON(l1l111l11_opy_ + l11lll1l1_opy_, addon)
    return l1l1l111l_opy_
def getPluginInfo(streamurl):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l11llllll_opy_   = l1l11_opy_ (u"ࠩࡎࡳࡩ࡯ࠠࡑࡘࡕࠫॕ")
            l1l1111l1_opy_ = os.path.join(dixie.RESOURCES, l1l11_opy_ (u"ࠪ࡯ࡴࡪࡩ࠮ࡲࡹࡶ࠳ࡶ࡮ࡨࠩॖ"))
            return l11llllll_opy_, l1l1111l1_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l1l11_opy_ (u"ࠫࡷࡺ࡭ࡱࠩॗ")) or url.startswith(l1l11_opy_ (u"ࠬࡸࡴ࡮ࡲࡨࠫक़")) or url.startswith(l1l11_opy_ (u"࠭ࡲࡵࡵࡳࠫख़")) or url.startswith(l1l11_opy_ (u"ࠧࡩࡶࡷࡴࠬग़")):
            l11llllll_opy_   = l1l11_opy_ (u"ࠨ࡯࠶ࡹࠥࡖ࡬ࡢࡻ࡯࡭ࡸࡺࠧज़")
            l1l1111l1_opy_ = os.path.join(dixie.RESOURCES, l1l11_opy_ (u"ࠩ࡬ࡴࡹࡼ࠭ࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡳࡲ࡬࠭ड़"))
            return l11llllll_opy_, l1l1111l1_opy_
    except:
        pass
    if streamurl.startswith(dixie.OPEN_OTT):
        l1l11l1ll_opy_ = streamurl.split(l1l11_opy_ (u"ࠪࡡࡔ࡚ࡔࡠࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫढ़"), 1)[-1].split(l1l11_opy_ (u"ࠫ࠴࠭फ़"), 1)[0]
    if l1l11_opy_ (u"ࠬࡣࡏࡕࡖࡢࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭य़") in streamurl:
        l1l11l1ll_opy_ = streamurl.split(l1l11_opy_ (u"࠭࡝ࡐࡖࡗࡣࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧॠ"), 1)[-1].split(l1l11_opy_ (u"ࠧ࠰ࠩॡ"), 1)[0]
    if streamurl.startswith(l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫॢ")):
        l1l11l1ll_opy_ = streamurl.split(l1l11_opy_ (u"ࠩ࠲࠳ࠬॣ"), 1)[-1].split(l1l11_opy_ (u"ࠪ࠳ࠬ।"), 1)[0]
    if l1l11_opy_ (u"ࠫࡤࡥࡓࡇࡡࡢࠫ॥") in streamurl:
        l1l11l1ll_opy_ = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡶࡲࡰࡩࡵࡥࡲ࠴ࡳࡶࡲࡨࡶ࠳࡬ࡡࡷࡱࡸࡶ࡮ࡺࡥࡴࠩ०")
    if l1l11_opy_ (u"࠭ࡈࡅࡖ࡙࠾ࠬ१") in streamurl:
        l1l11l1ll_opy_ = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳ࡮ࡣࡵࡸ࡭ࡻࡢࠨ२")
    if l1l11_opy_ (u"ࠨࡊࡇࡘ࡛࠸࠺ࠨ३") in streamurl:
        l1l11l1ll_opy_ = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࠸ࠧ४")
    if l1l11_opy_ (u"ࠪࡌࡉ࡚ࡖ࠴࠼ࠪ५") in streamurl:
        l1l11l1ll_opy_ = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡺࡿࡡ࠳ࠩ६")
    if l1l11_opy_ (u"ࠬࡎࡄࡕࡘ࠷࠾ࠬ७") in streamurl:
        l1l11l1ll_opy_ = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾ࡬ࠨ८")
    if l1l11_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡀࠧ९") in streamurl:
        l1l11l1ll_opy_ = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡣࡤࡦ࡭ࡵࡲࡡࡺࡧࡵࠫ॰")
    if l1l11_opy_ (u"ࠩࡌࡔࡑࡇ࡙࠳࠼ࠪॱ") in streamurl:
        l1l11l1ll_opy_ = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠭ॲ")
    if l1l11_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡕ࠾ࠬॳ") in streamurl:
        l1l11l1ll_opy_ = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶ࡬ࡢࡻࡨࡶࡼࡽࡷࠨॴ")
    if l1l11_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡎ࡚ࡖ࠻ࠩॵ") in streamurl:
        l1l11l1ll_opy_ = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡵࡸࠪॶ")
    if l1l11_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡄ࠻ࠩॷ") in streamurl:
        l1l11l1ll_opy_ = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡦࡨࡼࠬॸ")
    if l1l11_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡔࡅ࠾ࠬॹ") in streamurl:
        l1l11l1ll_opy_ = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡪࡨ࡯ࡰࡶࠪॺ")
    if l1l11_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡇࡑ࡛࠺ࠨॻ") in streamurl:
        l1l11l1ll_opy_ = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡩ࡬ࡶ࡫ࡳࡸࡻ࠭ॼ")
    if l1l11_opy_ (u"ࠧࡊࡒࡗࡗࠬॽ") in streamurl:
        l1l11l1ll_opy_ = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥ࡮ࡶࡴࡷࠩॾ")
    if l1l11_opy_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠼ࠪॿ") in streamurl:
        l1l11l1ll_opy_ = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡯࡭ࡻ࡫࡭ࡪࡺࠪঀ")
    if l1l11_opy_ (u"ࠫࡋࡒࡁ࠻ࠩঁ") in streamurl:
        l1l11l1ll_opy_ = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡋࡲࡡࡸ࡮ࡨࡷࡸ࡚ࡶࠨং")
    if l1l11_opy_ (u"࠭ࡆࡍࡃࡖ࠾ࠬঃ") in streamurl:
        l1l11l1ll_opy_ = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡆ࡭ࡣࡺࡰࡪࡹࡳࡕࡸࠪ঄")
    if l1l11_opy_ (u"ࠨࡷࡳࡲࡵࡀࠧঅ") in streamurl:
        l1l11l1ll_opy_ = l1l11_opy_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰࡫ࡨ࡭ࡵ࡭ࡦࡴࡸࡲ࠳ࡼࡩࡦࡹࠪআ")
    return l1l1l1l1l_opy_(l1l11l1ll_opy_)
def l1l1l1l1l_opy_(l1l11l1ll_opy_):
    l11llllll_opy_   = l1l11_opy_ (u"ࠪࠫই")
    l1l1111l1_opy_ = l1l11_opy_ (u"ࠫࠬঈ")
    if l1l11l1ll_opy_ == l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸࠨউ"):
        l11llllll_opy_   = l1l11_opy_ (u"࠭ࡄࡦࡺࡷࡩࡷ࡚ࡖࠡࡎ࡬ࡸࡪ࠭ঊ")
        l1l1111l1_opy_ = xbmcaddon.Addon(l1l11l1ll_opy_).getAddonInfo(l1l11_opy_ (u"ࠧࡪࡥࡲࡲࠬঋ"))
        return l11llllll_opy_, l1l1111l1_opy_
    try:
        l11llllll_opy_   = xbmcaddon.Addon(l1l11l1ll_opy_).getAddonInfo(l1l11_opy_ (u"ࠨࡰࡤࡱࡪ࠭ঌ"))
        l1l1111l1_opy_ = xbmcaddon.Addon(l1l11l1ll_opy_).getAddonInfo(l1l11_opy_ (u"ࠩ࡬ࡧࡴࡴࠧ঍"))
        return l11llllll_opy_, l1l1111l1_opy_
    except:
        l11llllll_opy_   = l1l11_opy_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡘࡵࡵࡳࡥࡨࠫ঎")
        l1l1111l1_opy_ =  dixie.ICON
        return l11llllll_opy_, l1l1111l1_opy_
    return l11llllll_opy_, l1l1111l1_opy_
def selectStream(url, channel):
    url = url.replace(l1l11_opy_ (u"ࠫࢁࡻࡳࡦࡴ࠰ࡥ࡬࡫࡮ࡵࠩএ"), l1l11_opy_ (u"ࠬ࠳࠭ࡶࡵࡨࡶ࠲ࡧࡧࡦࡰࡷࠫঐ"))
    l11lllll1_opy_ = url.split(l1l11_opy_ (u"࠭ࡼࠨ঑"))
    if len(l11lllll1_opy_) == 0:
        return None
    options, l11llll11_opy_ = getOptions(l11lllll1_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l11lllll1_opy_) == 1:
            return l11llll11_opy_[0]
    import selectDialog
    l1l11llll_opy_ = selectDialog.select(l1l11_opy_ (u"ࠧࡔࡧ࡯ࡩࡨࡺࠠࡢࠢࡶࡸࡷ࡫ࡡ࡮ࠩ঒"), options)
    if l1l11llll_opy_ < 0:
        raise Exception(l1l11_opy_ (u"ࠨࡕࡨࡰࡪࡩࡴࡪࡱࡱࠤࡈࡧ࡮ࡤࡧ࡯ࠫও"))
    return l11llll11_opy_[l1l11llll_opy_]
def getOptions(l11lllll1_opy_, channel, addmore=True):
    options = []
    l11llll11_opy_    = []
    for index, stream in enumerate(l11lllll1_opy_):
        l11llllll_opy_ = getPluginInfo(stream)
        l1lll1ll1_opy_ = l11llllll_opy_[0]
        l1l111lll_opy_  = l11llllll_opy_[1]
        l1lll1ll1_opy_ = l1l11_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡲࡶࡦࡴࡧࡦ࡟࡞ࠫঔ") + l1lll1ll1_opy_ + l1l11_opy_ (u"ࠪࡡࡠ࠵ࡃࡐࡎࡒࡖࡢࠦࠧক")
        if stream.startswith(OPEN_OTT):
            l1lll1ll1_opy_  = l1lll1ll1_opy_ + stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l1l11_opy_ (u"ࠫࠬখ"))
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l1l11_opy_ (u"ࠬ࠭গ"))
        else:
            l1lll1ll1_opy_  = l1lll1ll1_opy_ + channel
        options.append([l1lll1ll1_opy_, index, l1l111lll_opy_])
        l11llll11_opy_.append(stream)
    if addmore:
        options.append([l1l11_opy_ (u"࠭ࡁࡥࡦࠣࡱࡴࡸࡥ࠯࠰࠱ࠫঘ"), index + 1, dixie.ICON])
        l11llll11_opy_.append(l1l11_opy_ (u"ࠧࡢࡦࡧࡑࡴࡸࡥࠨঙ"))
    return options, l11llll11_opy_
if __name__ == l1l11_opy_ (u"ࠨࡡࡢࡱࡦ࡯࡮ࡠࡡࠪচ"):
    checkAddons()