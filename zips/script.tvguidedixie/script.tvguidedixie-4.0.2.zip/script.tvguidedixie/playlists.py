# -*- coding: utf-8 -*-
import sys
l1l1l111_opy_ = sys.version_info [0] == 2
l1111l1_opy_ = 2048
l1ll11l1_opy_ = 7
def l1l1l_opy_ (l11ll1_opy_):
	global l111l11_opy_
	l1llll11_opy_ = ord (l11ll1_opy_ [-1])
	l1l1l1l1_opy_ = l11ll1_opy_ [:-1]
	l11ll1l_opy_ = l1llll11_opy_ % len (l1l1l1l1_opy_)
	l111l1_opy_ = l1l1l1l1_opy_ [:l11ll1l_opy_] + l1l1l1l1_opy_ [l11ll1l_opy_:]
	if l1l1l111_opy_:
		l1llll_opy_ = unicode () .join ([unichr (ord (char) - l1111l1_opy_ - (l1lll_opy_ + l1llll11_opy_) % l1ll11l1_opy_) for l1lll_opy_, char in enumerate (l111l1_opy_)])
	else:
		l1llll_opy_ = str () .join ([chr (ord (char) - l1111l1_opy_ - (l1lll_opy_ + l1llll11_opy_) % l1ll11l1_opy_) for l1lll_opy_, char in enumerate (l111l1_opy_)])
	return eval (l1llll_opy_)
import platform
try:    l1111ll11_opy_ = platform.system
except: l1111ll11_opy_ = None
def l111l111l_opy_():
    if l1111ll11_opy_:
        return l1111ll11_opy_()
    import sys
    if sys.platform.lower().startswith(l1l1l_opy_ (u"࠭ࡷࡪࡰࠪਖ")):
        return l1l1l_opy_ (u"ࠧࡘ࡫ࡱࡨࡴࡽࡳࠨਗ")
    return l1l1l_opy_ (u"ࠨࡑࡷ࡬ࡪࡸࠠࡐࡕࡨࡷࠥࡺ࡯ࠡࡤࡨࠤࡩ࡫ࡴࡦࡴࡰ࡭ࡳ࡫ࡤࠨਘ")
platform.system = l111l111l_opy_
import requests
platform.system = l1111ll11_opy_
import os
import json
import dixie
l1l1lll1_opy_ = dixie.PROFILE
PATH = os.path.join(l1l1lll1_opy_, l1l1l_opy_ (u"ࠩࡳࡰ࡮ࡹࡴࡴࠩਙ"))
def loadPlaylists():
    dixie.log(l1l1l_opy_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࠣࡔࡑࡇ࡙ࡍࡋࡖࡘࡘࠦ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࠬਚ"))
    if os.path.exists(PATH):
        return json.load(open(PATH))
    try:
        l111l1l1l_opy_()
        return json.load(open(PATH))
    except:
        dixie.log(l1l1l_opy_ (u"ࠫࡂࡃ࠽࠾ࠢࡓࡰࡦࡿ࡬ࡪࡵࡷࠤࡱࡵࡡࡥࠢࡨࡶࡷࡵࡲࠡ࠿ࡀࡁࡂ࠭ਛ"))
        return []
def l111l1l1l_opy_():
    source = dixie.GetSetting(l1l1l_opy_ (u"ࠬ࡯ࡰࡵࡸ࠱ࡷࡴࡻࡲࡤࡧࠪਜ"))
    if not source == l1l1l_opy_ (u"࠭࠱ࠨਝ"):
        return l111ll11l_opy_()
    return l111111ll_opy_()
def l111ll11l_opy_():
    l11l11ll1_opy_ = []
    if dixie.GetSetting(l1l1l_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠶ࠧਞ")) == l1l1l_opy_ (u"ࠨࡶࡵࡹࡪ࠭ਟ"):
        l111l1111_opy_  = dixie.GetSetting(l1l1l_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠱ࡡࡘࡖࡑ࠭ਠ"))
        l111llll1_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠲ࡢࡔࡔࡘࡔࠨਡ"))
        l111l1lll_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠳ࡣ࡙࡟ࡐࡆࠩਢ"))
        l11l11111_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠴ࡤ࡛ࡓࡆࡔࠪਣ"))
        l11l1111l_opy_ = dixie.GetSetting(l1l1l_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠵ࡥࡐࡂࡕࡖࠫਤ"))
        if len(l111l1111_opy_) > 0:
            l11111l11_opy_ = l111lllll_opy_(l111l1111_opy_, l111llll1_opy_, l111l1lll_opy_, l11l11111_opy_, l11l1111l_opy_)
            l11l11ll1_opy_.append((l11111l11_opy_, l1l1l_opy_ (u"ࠧࡊࡒࡗ࡚࠶ࡀࠠࠨਥ")))
    if dixie.GetSetting(l1l1l_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠱ࠨਦ")) == l1l1l_opy_ (u"ࠩࡷࡶࡺ࡫ࠧਧ"):
        l111l1111_opy_  = dixie.GetSetting(l1l1l_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠳ࡢ࡙ࡗࡒࠧਨ"))
        l111llll1_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠴ࡣࡕࡕࡒࡕࠩ਩"))
        l111l1lll_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠵ࡤ࡚࡙ࡑࡇࠪਪ"))
        l11l11111_opy_ = dixie.GetSetting(l1l1l_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠶ࡥࡕࡔࡇࡕࠫਫ"))
        l11l1111l_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠷࡟ࡑࡃࡖࡗࠬਬ"))
        if len(l111l1111_opy_) > 0:
            l111lll1l_opy_ = l111lllll_opy_(l111l1111_opy_, l111llll1_opy_, l111l1lll_opy_, l11l11111_opy_, l11l1111l_opy_)
            l11l11ll1_opy_.append((l111lll1l_opy_, l1l1l_opy_ (u"ࠨࡋࡓࡘ࡛࠸࠺ࠡࠩਭ")))
    if dixie.GetSetting(l1l1l_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠳ࠩਮ")) == l1l1l_opy_ (u"ࠪࡸࡷࡻࡥࠨਯ"):
        l111l1111_opy_  = dixie.GetSetting(l1l1l_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠵ࡣ࡚ࡘࡌࠨਰ"))
        l111llll1_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠶ࡤࡖࡏࡓࡖࠪ਱"))
        l111l1lll_opy_ = dixie.GetSetting(l1l1l_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠷ࡥࡔ࡚ࡒࡈࠫਲ"))
        l11l11111_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠸࡟ࡖࡕࡈࡖࠬਲ਼"))
        l11l1111l_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠲ࡠࡒࡄࡗࡘ࠭਴"))
        if len(l111l1111_opy_) > 0:
            l111lll11_opy_ = l111lllll_opy_(l111l1111_opy_, l111llll1_opy_, l111l1lll_opy_, l11l11111_opy_, l11l1111l_opy_)
            l11l11ll1_opy_.append((l111lll11_opy_, l1l1l_opy_ (u"ࠩࡌࡔ࡙࡜࠳࠻ࠢࠪਵ")))
    return l1111l1ll_opy_(l1l1l_opy_ (u"࡙ࠪࡗࡒࡓࠨਸ਼"),  l11l11ll1_opy_)
def l111111ll_opy_():
    l11l11ll1_opy_ = []
    if dixie.GetSetting(l1l1l_opy_ (u"ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡴࡺࡲࡨࠫ਷")) == l1l1l_opy_ (u"ࠬ࠶ࠧਸ"):
        if dixie.GetSetting(l1l1l_opy_ (u"࠭ࡕࡓࡎࡢࡓࠬਹ")) == l1l1l_opy_ (u"ࠧࡵࡴࡸࡩࠬ਺"):
            l111111l1_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡹࡷࡲࠧ਻"))
            if len(l111111l1_opy_) > 0:
                l11l11ll1_opy_.append((l111111l1_opy_, l1l1l_opy_ (u"ࠩࡘࡖࡑ࠷࠺਼ࠡࠩ")))
        if dixie.GetSetting(l1l1l_opy_ (u"࡙ࠪࡗࡒ࡟࠲ࠩ਽")) == l1l1l_opy_ (u"ࠫࡹࡸࡵࡦࠩਾ"):
            l1111lll1_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡶࡴ࡯࠵ࠬਿ"))
            if len(l1111lll1_opy_) > 0:
                l11l11ll1_opy_.append((l1111lll1_opy_, l1l1l_opy_ (u"࠭ࡕࡓࡎ࠵࠾ࠥ࠭ੀ")))
        if dixie.GetSetting(l1l1l_opy_ (u"ࠧࡖࡔࡏࡣ࠷࠭ੁ")) == l1l1l_opy_ (u"ࠨࡶࡵࡹࡪ࠭ੂ"):
            l111ll1ll_opy_ = dixie.GetSetting(l1l1l_opy_ (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡺࡸ࡬࠳ࠩ੃"))
            if len(l111ll1ll_opy_) > 0:
                l11l11ll1_opy_.append((l111ll1ll_opy_, l1l1l_opy_ (u"࡙ࠪࡗࡒ࠳࠻ࠢࠪ੄")))
        dixie.log(l11l11ll1_opy_)
        return l1111l1ll_opy_(l1l1l_opy_ (u"࡚ࠫࡘࡌࡔࠩ੅"),  l11l11ll1_opy_)
    if dixie.GetSetting(l1l1l_opy_ (u"ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡵࡻࡳࡩࠬ੆")) == l1l1l_opy_ (u"࠭࠱ࠨੇ"):
        if dixie.GetSetting(l1l1l_opy_ (u"ࠧࡇࡋࡏࡉࡤ࠶ࠧੈ")) == l1l1l_opy_ (u"ࠨࡶࡵࡹࡪ࠭੉"):
            l11l111ll_opy_ = os.path.join(dixie.GetSetting(l1l1l_opy_ (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲࡫࡯࡬ࡦࠩ੊")))
            if l11l111ll_opy_:
                l11l11ll1_opy_.append((l11l111ll_opy_, l1l1l_opy_ (u"ࠪࡊࡎࡒࡅ࠲࠼ࠣࠫੋ")))
        if dixie.GetSetting(l1l1l_opy_ (u"ࠫࡋࡏࡌࡆࡡ࠳ࠫੌ")) == l1l1l_opy_ (u"ࠬࡺࡲࡶࡧ੍ࠪ"):
            l11l11l11_opy_ = os.path.join(dixie.GetSetting(l1l1l_opy_ (u"࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡨ࡬ࡰࡪ࠷ࠧ੎")))
            if l11l11l11_opy_:
                l11l11ll1_opy_.append((l11l11l11_opy_, l1l1l_opy_ (u"ࠧࡇࡋࡏࡉ࠷ࡀࠠࠨ੏")))
        if dixie.GetSetting(l1l1l_opy_ (u"ࠨࡈࡌࡐࡊࡥ࠰ࠨ੐")) == l1l1l_opy_ (u"ࠩࡷࡶࡺ࡫ࠧੑ"):
            l11l11l1l_opy_ = os.path.join(dixie.GetSetting(l1l1l_opy_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳࡬ࡩ࡭ࡧ࠵ࠫ੒")))
            if l11l11l1l_opy_:
                l11l11ll1_opy_.append((l11l11l1l_opy_, l1l1l_opy_ (u"ࠫࡋࡏࡌࡆ࠵࠽ࠤࠬ੓")))
        dixie.log(l11l11ll1_opy_)
        return l1111l1ll_opy_(l1l1l_opy_ (u"ࠬࡌࡉࡍࡇࡖࠫ੔"), l11l11ll1_opy_)
def l11111ll1_opy_():
    l11111lll_opy_ = [l1l1l_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳ࡍࡋ࡚࠶࡜ࡼ࡭ࡏ࡫ࡗࠨ੕")]
    for url in l11111lll_opy_:
        request = requests.get(url)
        content = request.content
        if l1l1l_opy_ (u"ࠧࠤࡇ࡛ࡘࡒ࠹ࡕࠨ੖") in content:
            return l1111l1ll_opy_(l1l1l_opy_ (u"ࠨࡅࡏࡓ࡚ࡊࠧ੗"), [(url, l1l1l_opy_ (u"ࠩࠪ੘"))])
            break
def l1111l1ll_opy_(l1111l11l_opy_, plist):
    dixie.log(l1111l11l_opy_)
    dixie.log(plist)
    playlists = []
    for item in plist:
        url = item[0]
        l1111l111_opy_ = item[1]
        l111ll1l1_opy_ = l11l111l1_opy_(l1111l11l_opy_, url, l1111l111_opy_)
        playlists.extend(l111ll1l1_opy_)
    json.dump(playlists, open(PATH,l1l1l_opy_ (u"ࠪࡻࠬਖ਼")))
def l11l111l1_opy_(l1111l11l_opy_, url, l1111l111_opy_):
    content  = l11111l1l_opy_(l1111l11l_opy_, url)
    pairs    = []
    for i in range(1,len(content), 2):
        if l1111l1l1_opy_(content[i+1]) == True:
            l1ll1ll_opy_ = content[i]
            l11l1_opy_   = content[i+1]
            pairs.append([l1ll1ll_opy_, l11l1_opy_])
    l1111llll_opy_ = list()
    l1ll1ll_opy_   = l1l1l_opy_ (u"ࠫࠬਗ਼")
    value   = l1l1l_opy_ (u"ࠬ࠭ਜ਼")
    for item in pairs:
        l111l1ll1_opy_ = item[0]
        l111ll111_opy_ = item[1]
        l111l1l11_opy_   = l111l1ll1_opy_.split(l1l1l_opy_ (u"࠭ࠬࠨੜ"))[-1].strip()
        l111l11ll_opy_   = dixie.cleanLabel(l111l1l11_opy_)
        l1l111l_opy_ = dixie.cleanPrefix(l111l11ll_opy_)
        l111ll_opy_ = dixie.mapChannelName(l1l111l_opy_)
        value = l111ll111_opy_.replace(l1l1l_opy_ (u"ࠧࡳࡶࡰࡴ࠿࠵࠯ࠥࡑࡓࡘ࠿ࡸࡴ࡮ࡲ࠰ࡶࡦࡽ࠽ࠨ੝"), l1l1l_opy_ (u"ࠨࠩਫ਼")).replace(l1l1l_opy_ (u"ࠩ࡟ࡲࠬ੟"), l1l1l_opy_ (u"ࠪࠫ੠"))
        l1111llll_opy_.append((l1111l111_opy_, l111ll_opy_, value))
    return l1111llll_opy_
def l1111l1l1_opy_(link):
    if link == l1l1l_opy_ (u"ࠫࠨࡋࡘࡕ࠯࡛࠱ࡊࡔࡄࡍࡋࡖࡘࠬ੡"):
        return False
    if len(link) < 1:
        return False
    if l1l1l_opy_ (u"ࠬ࠵࡬ࡪࡸࡨ࠳ࠬ੢") in link:
        return True
def l11111l1l_opy_(l1111l11l_opy_, url):
    import urllib
    if (l1111l11l_opy_ == l1l1l_opy_ (u"࠭ࡕࡓࡎࡖࠫ੣")) or (l1111l11l_opy_ == l1l1l_opy_ (u"ࠧࡄࡎࡒ࡙ࡉ࠭੤")):
        response = urllib.urlopen(url)
        content  = response.readlines()
        return content
    if l1111l11l_opy_ == l1l1l_opy_ (u"ࠨࡈࡌࡐࡊ࡙ࠧ੥"):
        with open(url) as content:
            return content.readlines()
def l111lllll_opy_(l111l1111_opy_, l111llll1_opy_, l111l1lll_opy_, l11l11111_opy_, l11l1111l_opy_):
    if l111l1111_opy_.startswith(l1l1l_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࠪ੦")):
        url = l111l1111_opy_
    else:
        url = l1l1l_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫ੧") + l111l1111_opy_
    url +=  l1111ll1l_opy_(l111llll1_opy_)
    url += l1l1l_opy_ (u"ࠫ࠴࡭ࡥࡵ࠰ࡳ࡬ࡵࡅࡵࡴࡧࡵࡲࡦࡳࡥ࠾ࠩ੨")
    url +=  l11l11111_opy_
    url += l1l1l_opy_ (u"ࠬࠬࡰࡢࡵࡶࡻࡴࡸࡤ࠾ࠩ੩")
    url +=  l11l1111l_opy_
    url += l1l1l_opy_ (u"࠭ࠦࡵࡻࡳࡩࡂࡳ࠳ࡶࡡࡳࡰࡺࡹࠦࡰࡷࡷࡴࡺࡺ࠽ࠨ੪")
    url +=  l111l11l1_opy_(l111l1lll_opy_)
    return url
def l1111ll1l_opy_(l111llll1_opy_):
    if not l111llll1_opy_ == l1l1l_opy_ (u"ࠧࠨ੫"):
        return l1l1l_opy_ (u"ࠨ࠼ࠪ੬") + l111llll1_opy_
    return l1l1l_opy_ (u"ࠩࠪ੭")
def l111l11l1_opy_(l111l1lll_opy_):
    if l111l1lll_opy_ == l1l1l_opy_ (u"ࠪ࠴ࠬ੮"):
        return l1l1l_opy_ (u"ࠫࡲ࠹ࡵ࠹ࠩ੯")
    if l111l1lll_opy_ == l1l1l_opy_ (u"ࠬ࠷ࠧੰ"):
        return l1l1l_opy_ (u"࠭࡭ࡱࡧࡪࡸࡸ࠭ੱ")
if __name__ == l1l1l_opy_ (u"ࠧࡠࡡࡰࡥ࡮ࡴ࡟ࡠࠩੲ"):
    l111l1l1l_opy_()