# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l1lll1_opy_ = 2048
l111_opy_ = 7
def l111l_opy_ (ll_opy_):
	global l1llll_opy_
	l1l111_opy_ = ord (ll_opy_ [-1])
	l11l1_opy_ = ll_opy_ [:-1]
	l1l_opy_ = l1l111_opy_ % len (l11l1_opy_)
	l11_opy_ = l11l1_opy_ [:l1l_opy_] + l11l1_opy_ [l1l_opy_:]
	if l1_opy_:
		l1ll1l_opy_ = unicode () .join ([unichr (ord (char) - l1lll1_opy_ - (l11ll_opy_ + l1l111_opy_) % l111_opy_) for l11ll_opy_, char in enumerate (l11_opy_)])
	else:
		l1ll1l_opy_ = str () .join ([chr (ord (char) - l1lll1_opy_ - (l11ll_opy_ + l1l111_opy_) % l111_opy_) for l11ll_opy_, char in enumerate (l11_opy_)])
	return eval (l1ll1l_opy_)
import xbmc
import xbmcgui
import json
import dixie
l1l1l1_opy_ = l111l_opy_ (u"ࠫࠬࠀ")
def l11l1l_opy_(i, t1, l1l11l_opy_=[]):
 t = l1l1l1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l11l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1ll_opy_ = l11l1l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l1l1_opy_ = l11l1l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def getURL(url):
    if not l11l_opy_() == l111l_opy_ (u"࡚ࠬࡲࡶࡧࠪࠁ"):
        return
    if url.startswith(l111l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡈࡒࡕ࠻ࠩࠂ")):
        url = url.replace(l111l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡉࡌࡖ࠼ࠪࠃ"), l111l_opy_ (u"ࠨࠩࠄ")).replace(l111l_opy_ (u"ࠩ࠰࠱ࡺࡹࡥࡳ࠯ࡤ࡫ࡪࡴࡴࠨࠅ"), l111l_opy_ (u"ࠪࢀࡺࡹࡥࡳ࠯ࡤ࡫ࡪࡴࡴࠨࠆ"))
        return url
    response = l11lll_opy_(url)
    stream   = url.split(l111l_opy_ (u"ࠫ࠿࠭ࠇ"), 1)[-1]
    try:
        result = response[l111l_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬࠈ")]
        l1111_opy_  = result[l111l_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬࠉ")]
    except Exception as e:
        l1ll11_opy_(e)
        return None
    for file in l1111_opy_:
        l1l11_opy_ = file[l111l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ࠊ")]
        if stream in l1l11_opy_:
            return file[l111l_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ࠋ")]
    return None
def l11lll_opy_(url):
    if url.startswith(l111l_opy_ (u"ࠩࡌࡔࡑࡇ࡙࠻ࠩࠌ")):
        l1l1ll_opy_ = (l111l_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡢࡣࡥ࡬ࡴࡱࡧࡹࡦࡴ࠲ࡃࡺࡸ࡬࠾ࡷࡵࡰࠫࡳ࡯ࡥࡧࡀ࠶ࠫࡴࡡ࡮ࡧࡀࡐ࡮ࡼࡥࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࡀࠪࡎࡖࡉࡅ࠿ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨࠍ"))
    if url.startswith(l111l_opy_ (u"ࠫࡎࡖࡌࡂ࡛࠵࠾ࠬࠎ")):
        l1l1ll_opy_ = (l111l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡰࡦࡿࡥࡳࡹࡺࡻ࠴ࡅࡵࡳ࡮ࡀࡹࡷࡲࠦ࡮ࡱࡧࡩࡂ࠷࠰࠲ࠨࡱࡥࡲ࡫࠽ࡘࡣࡷࡧ࡭࠱ࡌࡪࡸࡨࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࡃࠦࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡵࡢࡹࡷࡲ࠽ࠧ࡮ࡲ࡫࡬࡫ࡤࡠ࡫ࡱࡁࡋࡧ࡬ࡴࡧࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨࠏ"))
    if url.startswith(l111l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡗࡀࠧࠐ")):
        l1l1ll_opy_ = (l111l_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽ࠯ࡀࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬ࠬ࡬ࡰࡩࡪࡩࡩࡥࡩ࡯࠿ࡉࡥࡱࡹࡥࠧ࡯ࡲࡨࡪࡃ࠱࠲࠵ࠩࡲࡦࡳࡥ࠾ࡎ࡬ࡷࡹ࡫࡮ࠦ࠴࠳ࡐ࡮ࡼࡥࠧࡵࡸࡦࡹ࡯ࡴ࡭ࡧࡶࡣࡺࡸ࡬ࠧࡷࡵࡰࡂࡻࡲ࡭ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࠑ"))
    if url.startswith(l111l_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡉࡕࡘ࠽ࠫࠒ")):
        l1l1ll_opy_ = (l111l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡴࡷࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࠓ"))
    if url.startswith(l111l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡆ࠽ࠫࠔ")):
        l1l1ll_opy_ = (l111l_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡥࡧࡻ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡧ࡬࡭ࠨࡨࡼࡹࡸࡡࠧࡲࡤ࡫ࡪࠬࡰ࡭ࡱࡷࠪࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠽ࡩࡶࡷࡴࡸࠫ࠳ࡢࠧ࠵ࡪࠪ࠸ࡦࡴ࠵࠴࠲ࡵࡵࡳࡵ࡫ࡰ࡫࠳ࡵࡲࡨࠧ࠵ࡪ࠾࡮࡮࡬ࡺࡴࡾ࡬ࡨࠥ࠳ࡨࡷࡩࡸࡺ࡟ࡪࡰࡢࡴࡷࡵࡧࡳࡧࡶࡷ࠳ࡶ࡮ࡨࠨࡷ࡭ࡹࡲࡥ࠾ࠧ࠸ࡦࡈࡕࡌࡐࡔࠨ࠶࠵ࡽࡨࡪࡶࡨࠩ࠺ࡪࡁ࡭࡮ࠨ࠶࠵ࡉࡨࡢࡰࡱࡩࡱࡹࠥ࠶ࡤࠨ࠶࡫ࡉࡏࡍࡑࡕࠩ࠺ࡪࠦࡶࡴ࡯ࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩࠕ"))
    if url.startswith(l111l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖࡇࡀࠧࠖ")):
        l1l1ll_opy_ = (l111l_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡩࡧࡵ࡯ࡵ࠱ࡂࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠧࡨࡤࡲࡦࡸࡴ࠾ࡪࡷࡸࡵࠫ࠳ࡢࠧ࠵ࡪࠪ࠸ࡦࡵࡣࡵ࡫ࡪࡺࡢࡶ࡫࡯ࡨࡸ࠴࡮ࡦࡶࠨ࠶࡫࡯ࡣࡰࡰࡶࠩ࠷࡬࡬ࡪࡸࡨࠩ࠷࠻࠲࠱ࡪࡧ࠲ࡵࡴࡧࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁ࡭ࡺࡴࡱࠧ࠶ࡥࠪ࠸ࡦࠦ࠴ࡩࡸࡦࡸࡧࡦࡶࡥࡹ࡮ࡲࡤࡴ࠰ࡱࡩࡹࠫ࠲ࡧ࡫ࡦࡳࡳࡹࠥ࠳ࡨ࡯࡭ࡻ࡫ࠥ࠳࠷࠵࠴࡭ࡪ࠮ࡱࡰࡪࠪࡲࡵࡤࡦ࠿࠺ࠪࡵ࡯࡬࡭ࡱࡺࡁࡓࡵࠥ࠳࠲ࡊࡹ࡮ࡪࡥࠧࡷࡵࡰࡂࡸࡡ࡯ࡦࡲࡱࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࠗ"))
    if url.startswith(l111l_opy_ (u"ࠧࡊࡒࡗࡗ࠿࠭࠘")):
        l1l1ll_opy_ = (l111l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢ࡫ࡳࡸࡻ࠵࠿ࡢࡥࡷ࡭ࡴࡴ࠽࡭࡫ࡹࡩࡹࡼ࡟ࡢ࡮࡯ࠪࡪࡾࡴࡳࡣࠩࡴࡦ࡭ࡥࠧࡲ࡯ࡳࡹࠬࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠿ࠩࡸ࡮ࡺ࡬ࡦ࠿ࡄࡰࡱࠫ࠲࠱ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠩࡹࡷࡲࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬ࠙"))
    try:
        dixie.ShowBusy()
        addon =  l1l1ll_opy_.split(l111l_opy_ (u"ࠩ࠲࠳ࠬࠚ"), 1)[-1].split(l111l_opy_ (u"ࠪ࠳ࠬࠛ"), 1)[0]
        l11ll1_opy_ = l111l_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩࠜ") % addon
        xbmc.executeJSONRPC(l11ll1_opy_)
        response = xbmc.executeJSONRPC(l1l1ll_opy_)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1ll11_opy_(e)
        return {l111l_opy_ (u"ࠬࡋࡲࡳࡱࡵࠫࠝ") : l111l_opy_ (u"࠭ࡐ࡭ࡷࡪ࡭ࡳࠦࡅࡳࡴࡲࡶࠬࠞ")}
def l11l_opy_():
    modules = map(__import__, [l11l1l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1ll_opy_)):
        return l111l_opy_ (u"ࠧࡕࡴࡸࡩࠬࠟ")
    if len(modules[-1].Window(10**4).getProperty(l1l1_opy_)):
        return l111l_opy_ (u"ࠨࡖࡵࡹࡪ࠭ࠠ")
    return l111l_opy_ (u"ࠩࡉࡥࡱࡹࡥࠨࠡ")
def l1ll11_opy_(e):
    l1l1l_opy_ = l111l_opy_ (u"ࠪࡗࡴࡸࡲࡺ࠮ࠣࡥࡳࠦࡥࡳࡴࡲࡶࠥࡵࡣࡤࡷࡵࡩࡩࡀࠠࡋࡕࡒࡒࠥࡋࡲࡳࡱࡵ࠾ࠥࠫࡳࠨࠢ")  %e
    l1ll1_opy_ = l111l_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡷ࡫࠭࡭࡫ࡱ࡯ࠥࡺࡨࡪࡵࠣࡧ࡭ࡧ࡮࡯ࡧ࡯ࠤࡦࡴࡤࠡࡶࡵࡽࠥࡧࡧࡢ࡫ࡱ࠲ࠬࠣ")
    l1lll_opy_ = l111l_opy_ (u"࡛ࠬࡳࡦ࠼ࠣࡇࡴࡴࡴࡦࡺࡷࠤࡒ࡫࡮ࡶࠢࡀࡂࠥࡘࡥ࡮ࡱࡹࡩ࡙ࠥࡴࡳࡧࡤࡱࠬࠤ")
    dixie.log(e)
    dixie.DialogOK(l1l1l_opy_, l1ll1_opy_, l1lll_opy_)