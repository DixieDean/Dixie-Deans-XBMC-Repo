# coding: UTF-8
import sys
l11llll_opy_ = sys.version_info [0] == 2
l1lllll_opy_ = 2048
l1111_opy_ = 7
def l11l1l_opy_ (ll_opy_):
	global l11l_opy_
	l1l1111_opy_ = ord (ll_opy_ [-1])
	l111l1_opy_ = ll_opy_ [:-1]
	l1ll11l_opy_ = l1l1111_opy_ % len (l111l1_opy_)
	l1ll1_opy_ = l111l1_opy_ [:l1ll11l_opy_] + l111l1_opy_ [l1ll11l_opy_:]
	if l11llll_opy_:
		l1lll1l_opy_ = unicode () .join ([unichr (ord (char) - l1lllll_opy_ - (l11ll1_opy_ + l1l1111_opy_) % l1111_opy_) for l11ll1_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1lll1l_opy_ = str () .join ([chr (ord (char) - l1lllll_opy_ - (l11ll1_opy_ + l1l1111_opy_) % l1111_opy_) for l11ll1_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1lll1l_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l111l1l11_opy_    = l11l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡴࡴࡷࠩঃ")
l111l1l1l_opy_ = l11l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡷ࡭࡫ࡳࡸࡻ࠭঄")
l11l11111_opy_    = l11l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡶ࡭ࡷࡹࡷࡱࠧঅ")
locked = l11l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮ࡲࡧࡰ࡫ࡤࡵࡸࠪআ")
l111lll11_opy_     = l11l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸࡰࡹ࡯࡭ࡢࡶࡨࡱࡦࡴࡩࡢࠩই")
l111ll1ll_opy_   = l11l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰ࡮ࡻࡸ࠯ࡶࡹࠫঈ")
l111l11ll_opy_    = l11l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡉࡉࡓࡱࡱࡵࡸࡸ࠭উ")
l111lll1l_opy_ = l11l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡥࡣࡱࡲࡸࠬঊ")
l111l1ll1_opy_    = l11l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡣ࡭ࡷ࡬ࡴࡹࡼࠧঋ")
l111ll111_opy_ = l11l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥ࡮ࡶࡴࡷࠩঌ")
l11l1l1_opy_ = [l111l1l11_opy_, locked, l111ll1ll_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l11l1l_opy_ (u"ࠩ࡬ࡲ࡮࠭঍"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1l11l1_opy_ = l11l1l_opy_ (u"ࠪࠫ঎")
def l11l11l_opy_(i, t1, l1l111l_opy_=[]):
 t = l1l11l1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l111l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1l1l_opy_ = l11l11l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11_opy_ = l11l11l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l11l1l1_opy_:
        if l11ll11_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l11ll11_opy_(addon):
    if xbmc.getCondVisibility(l11l1l_opy_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡍࡧࡳࡂࡦࡧࡳࡳ࠮ࠥࡴࠫࠪএ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l1llll1_opy_ = str(addon).split(l11l1l_opy_ (u"ࠬ࠴ࠧঐ"))[2] + l11l1l_opy_ (u"࠭࠮ࡪࡰ࡬ࠫ঑")
    l1l_opy_  = os.path.join(PATH, l1llll1_opy_)
    try:
        l1l1l1l_opy_ = l1_opy_(addon)
    except KeyError:
        dixie.log(l11l1l_opy_ (u"ࠧ࠮࠯࠰࠱࠲ࠦࡋࡦࡻࡈࡶࡷࡵࡲࠡ࡫ࡱࠤ࡬࡫ࡴࡇ࡫࡯ࡩࡸࠦ࠭࠮࠯࠰࠱ࠥ࠭঒") + addon)
        result = {l11l1l_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࡳࠨও"): [{l11l1l_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬঔ"): l11l1l_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࠩক"), l11l1l_opy_ (u"ࡹࠬࡺࡹࡱࡧࠪখ"): l11l1l_opy_ (u"ࡺ࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧগ"), l11l1l_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࠬঘ"): l11l1l_opy_ (u"ࡵࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡼࡽ࠭ঙ"), l11l1l_opy_ (u"ࡶࠩ࡯ࡥࡧ࡫࡬ࠨচ"): l11l1l_opy_ (u"ࡷࠪࡒࡔࠦࡃࡉࡃࡑࡒࡊࡒࡓࠨছ")}], l11l1l_opy_ (u"ࡸࠫࡱ࡯࡭ࡪࡶࡶࠫজ"):{l11l1l_opy_ (u"ࡹࠬࡹࡴࡢࡴࡷࠫঝ"): 0, l11l1l_opy_ (u"ࡺ࠭ࡴࡰࡶࡤࡰࠬঞ"): 1, l11l1l_opy_ (u"ࡻࠧࡦࡰࡧࠫট"): 1}}
    l111ll_opy_  = l11l1l_opy_ (u"ࠧ࡜ࠩঠ") + addon + l11l1l_opy_ (u"ࠨ࡟࡟ࡲࠬড")
    l1l1l11_opy_  =  file(l1l_opy_, l11l1l_opy_ (u"ࠩࡺࠫঢ"))
    l1l1l11_opy_.write(l111ll_opy_)
    l1ll1l_opy_ = []
    for channel in l1l1l1l_opy_:
        l11l11ll1_opy_ = cleanLabel(channel[l11l1l_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩণ")])
        l11ll1l_opy_   = dixie.l11l11l11_opy_(l11l11ll1_opy_)
        l1lll_opy_ = dixie.mapChannelName(l11ll1l_opy_)
        stream   = channel[l11l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࠩত")]
        l11ll_opy_ = l1lll_opy_ + l11l1l_opy_ (u"ࠬࡃࠧথ") + stream
        l1ll1l_opy_.append(l11ll_opy_)
        l1ll1l_opy_.sort()
    for item in l1ll1l_opy_:
        l1l1l11_opy_.write(l11l1l_opy_ (u"ࠨࠥࡴ࡞ࡱࠦদ") % item)
    l1l1l11_opy_.close()
def l1_opy_(addon):
    if (addon == l111l1l11_opy_) or (addon == l111l1l1l_opy_) or (addon == l111ll111_opy_):
        try:
            if xbmcaddon.Addon(addon).getSetting(l11l1l_opy_ (u"ࠧࡨࡧࡱࡶࡪ࠭ধ")) == l11l1l_opy_ (u"ࠨࡶࡵࡹࡪ࠭ন"):
                xbmcaddon.Addon(addon).setSetting(l11l1l_opy_ (u"ࠩࡪࡩࡳࡸࡥࠨ঩"), l11l1l_opy_ (u"ࠪࡪࡦࡲࡳࡦࠩপ"))
                xbmcgui.Window(10000).setProperty(l11l1l_opy_ (u"ࠫࡕࡒࡕࡈࡋࡑࡣࡌࡋࡎࡓࡇࠪফ"), l11l1l_opy_ (u"࡚ࠬࡲࡶࡧࠪব"))
            if xbmcaddon.Addon(addon).getSetting(l11l1l_opy_ (u"࠭ࡴࡷࡩࡸ࡭ࡩ࡫ࠧভ")) == l11l1l_opy_ (u"ࠧࡵࡴࡸࡩࠬম"):
                xbmcaddon.Addon(addon).setSetting(l11l1l_opy_ (u"ࠨࡶࡹ࡫ࡺ࡯ࡤࡦࠩয"), l11l1l_opy_ (u"ࠩࡩࡥࡱࡹࡥࠨর"))
                xbmcgui.Window(10000).setProperty(l11l1l_opy_ (u"ࠪࡔࡑ࡛ࡇࡊࡐࡢࡘ࡛ࡍࡕࡊࡆࡈࠫ঱"), l11l1l_opy_ (u"࡙ࠫࡸࡵࡦࠩল"))
        except: pass
        l1l1ll11l_opy_  = l11l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ঳") + addon
        l111ll11l_opy_ =  l11l1111l_opy_(addon)
        query   =  l1l1ll11l_opy_ + l111ll11l_opy_
        return sendJSON(query, addon)
    return l1l11l1ll_opy_(addon)
def l1l11l1ll_opy_(addon):
    if addon == l111ll1ll_opy_:
        l1l11ll1l_opy_ = [l11l1l_opy_ (u"࠭࠵ࠨ঴"), l11l1l_opy_ (u"ࠧ࠲࠲࠹ࠫ঵"), l11l1l_opy_ (u"ࠨ࠶ࠪশ"), l11l1l_opy_ (u"ࠩ࠵࠺࠸࠭ষ"), l11l1l_opy_ (u"ࠪ࠵࠸࠸ࠧস")]
    if addon == locked:
        l1l11ll1l_opy_ = [l11l1l_opy_ (u"ࠫ࠸࠶ࠧহ"), l11l1l_opy_ (u"ࠬ࠹࠱ࠨ঺"), l11l1l_opy_ (u"࠭࠳࠳ࠩ঻"), l11l1l_opy_ (u"ࠧ࠴࠵়ࠪ"), l11l1l_opy_ (u"ࠨ࠵࠷ࠫঽ"), l11l1l_opy_ (u"ࠩ࠶࠹ࠬা"), l11l1l_opy_ (u"ࠪ࠷࠽࠭ি"), l11l1l_opy_ (u"ࠫ࠹࠶ࠧী"), l11l1l_opy_ (u"ࠬ࠺࠱ࠨু"), l11l1l_opy_ (u"࠭࠴࠶ࠩূ"), l11l1l_opy_ (u"ࠧ࠵࠹ࠪৃ"), l11l1l_opy_ (u"ࠨ࠶࠼ࠫৄ"), l11l1l_opy_ (u"ࠩ࠸࠶ࠬ৅")]
    if addon == l111lll11_opy_:
        l1l11ll1l_opy_ = [l11l1l_opy_ (u"ࠪ࠶࠺࠭৆"), l11l1l_opy_ (u"ࠫ࠷࠼ࠧে"), l11l1l_opy_ (u"ࠬ࠸࠷ࠨৈ"), l11l1l_opy_ (u"࠭࠲࠺ࠩ৉"), l11l1l_opy_ (u"ࠧ࠴࠲ࠪ৊"), l11l1l_opy_ (u"ࠨ࠵࠴ࠫো"), l11l1l_opy_ (u"ࠩ࠶࠶ࠬৌ"), l11l1l_opy_ (u"ࠪ࠷࠺্࠭"), l11l1l_opy_ (u"ࠫ࠸࠼ࠧৎ"), l11l1l_opy_ (u"ࠬ࠹࠷ࠨ৏"), l11l1l_opy_ (u"࠭࠳࠹ࠩ৐"), l11l1l_opy_ (u"ࠧ࠴࠻ࠪ৑"), l11l1l_opy_ (u"ࠨ࠶࠳ࠫ৒"), l11l1l_opy_ (u"ࠩ࠷࠵ࠬ৓"), l11l1l_opy_ (u"ࠪ࠸࠽࠭৔"), l11l1l_opy_ (u"ࠫ࠹࠿ࠧ৕"), l11l1l_opy_ (u"ࠬ࠻࠰ࠨ৖"), l11l1l_opy_ (u"࠭࠵࠳ࠩৗ"), l11l1l_opy_ (u"ࠧ࠶࠶ࠪ৘"), l11l1l_opy_ (u"ࠨ࠷࠹ࠫ৙"), l11l1l_opy_ (u"ࠩ࠸࠻ࠬ৚"), l11l1l_opy_ (u"ࠪ࠹࠽࠭৛"), l11l1l_opy_ (u"ࠫ࠺࠿ࠧড়"), l11l1l_opy_ (u"ࠬ࠼࠰ࠨঢ়"), l11l1l_opy_ (u"࠭࠶࠲ࠩ৞"), l11l1l_opy_ (u"ࠧ࠷࠴ࠪয়"), l11l1l_opy_ (u"ࠨ࠸࠶ࠫৠ"), l11l1l_opy_ (u"ࠩ࠹࠹ࠬৡ"), l11l1l_opy_ (u"ࠪ࠺࠻࠭ৢ"), l11l1l_opy_ (u"ࠫ࠻࠽ࠧৣ"), l11l1l_opy_ (u"ࠬ࠼࠹ࠨ৤"), l11l1l_opy_ (u"࠭࠷࠱ࠩ৥"), l11l1l_opy_ (u"ࠧ࠸࠶ࠪ০"), l11l1l_opy_ (u"ࠨ࠹࠺ࠫ১"), l11l1l_opy_ (u"ࠩ࠺࠼ࠬ২"), l11l1l_opy_ (u"ࠪ࠼࠵࠭৩"), l11l1l_opy_ (u"ࠫ࠽࠷ࠧ৪")]
    login = l11l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠦࡵ࠲ࠫ৫") % addon
    sendJSON(login, addon)
    l1111l_opy_ = []
    for l1l1l1ll1_opy_ in l1l11ll1l_opy_:
        if addon == l111ll1ll_opy_:
            query = l11l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶ࠳ࡄࡳ࡯ࡥࡧࡢ࡭ࡩࡃࡣࡩࡣࡱࡲࡪࡲࡳࠧ࡯ࡲࡨࡪࡃࡣࡩࡣࡱࡲࡪࡲࡳࠧࡵࡨࡧࡹ࡯࡯࡯ࡡ࡬ࡨࡂࠫࡳࠨ৬") % (addon, l1l1l1ll1_opy_)
        if (addon == locked) or (addon == l111lll11_opy_):
            query = l11l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷ࠴ࡅࡵࡳ࡮ࡀࠩࡸࠬ࡭ࡰࡦࡨࡁ࠹ࠬ࡮ࡢ࡯ࡨࡁࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡳࡰࡦࡿ࠽ࠧࡦࡤࡸࡪࡃࠦࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࡂࠬࡰࡢࡩࡨࡁࠬ৭") % (addon, l1l1l1ll1_opy_)
        response = sendJSON(query, addon)
        l1111l_opy_.extend(response)
    return l1111l_opy_
def sendJSON(query, addon):
    l1l1l11l1_opy_     = l11l1l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫ৮") % query
    l1l1l1lll_opy_  = xbmc.executeJSONRPC(l1l1l11l1_opy_)
    response = json.loads(l1l1l1lll_opy_)
    result   = response[l11l1l_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩ৯")]
    if xbmcgui.Window(10000).getProperty(l11l1l_opy_ (u"ࠪࡔࡑ࡛ࡇࡊࡐࡢࡋࡊࡔࡒࡆࠩৰ")) == l11l1l_opy_ (u"࡙ࠫࡸࡵࡦࠩৱ"):
        xbmcaddon.Addon(addon).setSetting(l11l1l_opy_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ৲"), l11l1l_opy_ (u"࠭ࡴࡳࡷࡨࠫ৳"))
    if xbmcgui.Window(10000).getProperty(l11l1l_opy_ (u"ࠧࡑࡎࡘࡋࡎࡔ࡟ࡕࡘࡊ࡙ࡎࡊࡅࠨ৴")) == l11l1l_opy_ (u"ࠨࡖࡵࡹࡪ࠭৵"):
        xbmcaddon.Addon(addon).setSetting(l11l1l_opy_ (u"ࠩࡷࡺ࡬ࡻࡩࡥࡧࠪ৶"), l11l1l_opy_ (u"ࠪࡸࡷࡻࡥࠨ৷"))
    return result[l11l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪ৸")]
def l11l1111l_opy_(addon):
    if (addon == l111l1l11_opy_) or (addon == l111l1l1l_opy_):
        return l11l1l_opy_ (u"ࠬ࠵࠿ࡤࡣࡷࡁ࠲࠸ࠦࡥࡣࡷࡩࠫࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠩࡩࡳࡪࡄࡢࡶࡨࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧ࡯ࡲࡨࡪࡃ࠲ࠧࡰࡤࡱࡪࡃࡍࡺࠧ࠵࠴ࡈ࡮ࡡ࡯ࡰࡨࡰࡸࠬࡲࡦࡥࡲࡶࡩࡴࡡ࡮ࡧࠩࡷࡹࡧࡲࡵࡆࡤࡸࡪࠬࡵࡳ࡮ࡀࡹࡷࡲࠧ৹")
    if addon == l111ll111_opy_:
        return l11l1l_opy_ (u"࠭࠯ࡀࡣࡦࡸ࡮ࡵ࡮࠾࡮࡬ࡺࡪࡺࡶࡠࡣ࡯ࡰࠫ࡫ࡸࡵࡴࡤࠪࡵࡧࡧࡦࠨࡳࡰࡴࡺࠦࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡀࠪࡹ࡯ࡴ࡭ࡧࡀࡅࡱࡲࠥ࠳࠲ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪࡺࡸ࡬ࠨ৺")
    return l11l1l_opy_ (u"ࠧࠨ৻")
def l111l_opy_():
    modules = map(__import__, [l11l11l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1l1l_opy_)):
        return l11l1l_opy_ (u"ࠨࡖࡵࡹࡪ࠭ৼ")
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l11l1l_opy_ (u"ࠩࡗࡶࡺ࡫ࠧ৽")
    return l11l1l_opy_ (u"ࠪࡊࡦࡲࡳࡦࠩ৾")
def l1l1lll_opy_(e, addon):
    l1l111_opy_ = l11l1l_opy_ (u"ࠫࡘࡵࡲࡳࡻ࠯ࠤࡦࡴࠠࡦࡴࡵࡳࡷࠦ࡯ࡤࡥࡸࡶࡪࡪ࠺ࠡࡌࡖࡓࡓࠦࡅࡳࡴࡲࡶ࠿ࠦࠥࡴ࠮ࠣࠩࡸ࠭৿")  % (e, addon)
    l11l1_opy_ = l11l1l_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡩ࡯࡯ࡶࡤࡧࡹࠦࡵࡴࠢࡲࡲࠥࡺࡨࡦࠢࡩࡳࡷࡻ࡭࠯ࠩ਀")
    l1l1l1_opy_ = l11l1l_opy_ (u"࠭ࡕࡱ࡮ࡲࡥࡩࠦࡡࠡ࡮ࡲ࡫ࠥࡼࡩࡢࠢࡷ࡬ࡪࠦࡡࡥࡦࡲࡲࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹࠠࡢࡰࡧࠤࡵࡵࡳࡵࠢࡷ࡬ࡪࠦ࡬ࡪࡰ࡮࠲ࠬਁ")
    dixie.log(addon)
    dixie.log(e)
def getPluginInfo(streamurl):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l111ll1l1_opy_   = l11l1l_opy_ (u"ࠧࡌࡱࡧ࡭ࠥࡖࡖࡓࠩਂ")
            l111lllll_opy_ = os.path.join(dixie.RESOURCES, l11l1l_opy_ (u"ࠨ࡭ࡲࡨ࡮࠳ࡰࡷࡴ࠱ࡴࡳ࡭ࠧਃ"))
            return l111ll1l1_opy_, l111lllll_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l11l1l_opy_ (u"ࠩࡵࡸࡲࡶࠧ਄")) or url.startswith(l11l1l_opy_ (u"ࠪࡶࡹࡳࡰࡦࠩਅ")) or url.startswith(l11l1l_opy_ (u"ࠫࡷࡺࡳࡱࠩਆ")) or url.startswith(l11l1l_opy_ (u"ࠬ࡮ࡴࡵࡲࠪਇ")):
            l111ll1l1_opy_   = l11l1l_opy_ (u"࠭࡭࠴ࡷࠣࡔࡱࡧࡹ࡭࡫ࡶࡸࠬਈ")
            l111lllll_opy_ = os.path.join(dixie.RESOURCES, l11l1l_opy_ (u"ࠧࡪࡲࡷࡺ࠲ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡱࡰࡪࠫਉ"))
            return l111ll1l1_opy_, l111lllll_opy_
    except:
        pass
    if streamurl.startswith(l11l1l_opy_ (u"ࠨࡲࡹࡶ࠿࠵࠯ࠨਊ")):
        l111ll1l1_opy_   = l11l1l_opy_ (u"ࠩࡎࡳࡩ࡯ࠠࡑࡘࡕࠫ਋")
        l111lllll_opy_ = os.path.join(dixie.RESOURCES, l11l1l_opy_ (u"ࠪ࡯ࡴࡪࡩ࠮ࡲࡹࡶ࠳ࡶ࡮ࡨࠩ਌"))
        return l111ll1l1_opy_, l111lllll_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        l111llll1_opy_ = streamurl.split(l11l1l_opy_ (u"ࠫࡢࡕࡔࡕࡡࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ਍"), 1)[-1].split(l11l1l_opy_ (u"ࠬ࠵ࠧ਎"), 1)[0]
    if l11l1l_opy_ (u"࠭࡝ࡐࡖࡗࡣࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧਏ") in streamurl:
        l111llll1_opy_ = streamurl.split(l11l1l_opy_ (u"ࠧ࡞ࡑࡗࡘࡤࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨਐ"), 1)[-1].split(l11l1l_opy_ (u"ࠨ࠱ࠪ਑"), 1)[0]
    if streamurl.startswith(l11l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ਒")):
        l111llll1_opy_ = streamurl.split(l11l1l_opy_ (u"ࠪ࠳࠴࠭ਓ"), 1)[-1].split(l11l1l_opy_ (u"ࠫ࠴࠭ਔ"), 1)[0]
    if l11l1l_opy_ (u"ࠬࡥ࡟ࡔࡈࡢࡣࠬਕ") in streamurl:
        l111llll1_opy_ = l11l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡰࡳࡱࡪࡶࡦࡳ࠮ࡴࡷࡳࡩࡷ࠴ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵࠪਖ")
    if l11l1l_opy_ (u"ࠧࡉࡆࡗ࡚࠿࠭ਗ") in streamurl:
        l111llll1_opy_ = l11l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴ࡯ࡤࡶࡹ࡮ࡵࡣࠩਘ")
    if l11l1l_opy_ (u"ࠩࡋࡈ࡙࡜࠲࠻ࠩਙ") in streamurl:
        l111llll1_opy_ = l11l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧ࠲ࠨਚ")
    if l11l1l_opy_ (u"ࠫࡍࡊࡔࡗ࠵࠽ࠫਛ") in streamurl:
        l111llll1_opy_ = l11l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢ࠴ࠪਜ")
    if l11l1l_opy_ (u"࠭ࡈࡅࡖ࡙࠸࠿࠭ਝ") in streamurl:
        l111llll1_opy_ = l11l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸ࡭ࠩਞ")
    if l11l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠺ࠨਟ") in streamurl:
        l111llll1_opy_ = l11l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡤࡥࡧ࡮ࡶ࡬ࡢࡻࡨࡶࠬਠ")
    if l11l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠴࠽ࠫਡ") in streamurl:
        l111llll1_opy_ = l11l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽࠧਢ")
    if l11l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖ࠿࠭ਣ") in streamurl:
        l111llll1_opy_ = l11l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰ࡭ࡣࡼࡩࡷࡽࡷࡸࠩਤ")
    if l11l1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡏࡔࡗ࠼ࠪਥ") in streamurl:
        l111llll1_opy_ = l11l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡶࡹࠫਦ")
    if l11l1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪਧ") in streamurl:
        l111llll1_opy_ = l11l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡧࡩࡽ࠭ਨ")
    if l11l1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡕࡆ࠿࠭਩") in streamurl:
        l111llll1_opy_ = l11l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷ࡫ࡢࡰࡱࡷࠫਪ")
    if l11l1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡈࡒࡕ࠻ࠩਫ") in streamurl:
        l111llll1_opy_ = l11l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡣ࡭ࡷ࡬ࡴࡹࡼࠧਬ")
    if l11l1l_opy_ (u"ࠨࡋࡓࡘࡘ࠭ਭ") in streamurl:
        l111llll1_opy_ = l11l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࡯ࡰࡵࡸࠪਮ")
    if l11l1l_opy_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠽ࠫਯ") in streamurl:
        l111llll1_opy_ = l11l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰ࡮ࡼࡥ࡮࡫ࡻࠫਰ")
    if l11l1l_opy_ (u"ࠬࡋࡎࡅ࠼ࠪ਱") in streamurl:
        l111llll1_opy_ = l11l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡋ࡮ࡥ࡮ࡨࡷࡸ࠭ਲ")
    if l11l1l_opy_ (u"ࠧࡇࡎࡄ࠾ࠬਲ਼") in streamurl:
        l111llll1_opy_ = l11l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡇ࡮ࡤࡻࡱ࡫ࡳࡴࡖࡹࠫ਴")
    if l11l1l_opy_ (u"ࠩࡉࡐࡆ࡙࠺ࠨਵ") in streamurl:
        l111llll1_opy_ = l11l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡉࡰࡦࡽ࡬ࡦࡵࡶࡘࡻ࠭ਸ਼")
    if l11l1l_opy_ (u"ࠫࡺࡶ࡮ࡱ࠼ࠪ਷") in streamurl:
        l111llll1_opy_ = l11l1l_opy_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳࡮ࡤࡩࡱࡰࡩࡷࡻ࡮࠯ࡸ࡬ࡩࡼ࠭ਸ")
    return l111l1lll_opy_(l111llll1_opy_)
def l111l1lll_opy_(l111llll1_opy_):
    l111ll1l1_opy_   = l11l1l_opy_ (u"࠭ࠧਹ")
    l111lllll_opy_ = l11l1l_opy_ (u"ࠧࠨ਺")
    try:
        l11l11l1l_opy_ = xbmcaddon.Addon(l111llll1_opy_).getAddonInfo(l11l1l_opy_ (u"ࠨࡰࡤࡱࡪ࠭਻"))
        l111ll1l1_opy_    = cleanLabel(l11l11l1l_opy_)
        l111lllll_opy_  = xbmcaddon.Addon(l111llll1_opy_).getAddonInfo(l11l1l_opy_ (u"ࠩ࡬ࡧࡴࡴ਼ࠧ"))
        return l111ll1l1_opy_, l111lllll_opy_
    except:
        l111ll1l1_opy_   = l11l1l_opy_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡘࡵࡵࡳࡥࡨࠫ਽")
        l111lllll_opy_ =  dixie.ICON
        return l111ll1l1_opy_, l111lllll_opy_
    return l111ll1l1_opy_, l111lllll_opy_
def selectStream(url, channel):
    l11l111ll_opy_ = url.split(l11l1l_opy_ (u"ࠫࢁ࠭ਾ"))
    if len(l11l111ll_opy_) == 0:
        return None
    options, l11l1ll_opy_ = getOptions(l11l111ll_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l11l111ll_opy_) == 1:
            return l11l1ll_opy_[0]
    import selectDialog
    l111l11l1_opy_ = selectDialog.select(l11l1l_opy_ (u"࡙ࠬࡥ࡭ࡧࡦࡸࠥࡧࠠࡴࡶࡵࡩࡦࡳࠧਿ"), options)
    if l111l11l1_opy_ < 0:
        raise Exception(l11l1l_opy_ (u"࠭ࡓࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡆࡥࡳࡩࡥ࡭ࠩੀ"))
    return l11l1ll_opy_[l111l11l1_opy_]
def getOptions(l11l111ll_opy_, channel, addmore=True):
    options = []
    l11l1ll_opy_    = []
    for index, stream in enumerate(l11l111ll_opy_):
        l111ll1l1_opy_ = getPluginInfo(stream)
        l11lll_opy_ = l111ll1l1_opy_[0]
        l11l111l1_opy_  = l111ll1l1_opy_[1]
        l11lll_opy_ = l11l1l_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡰࡴࡤࡲ࡬࡫࡝࡜ࠩੁ") + l11lll_opy_ + l11l1l_opy_ (u"ࠨ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠤࠬੂ")
        if stream.startswith(OPEN_OTT):
            l11lll111_opy_ = stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l11l1l_opy_ (u"ࠩࠪ੃"))
            l11lll_opy_  = l11lll_opy_ + l11lll111_opy_
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l11l1l_opy_ (u"ࠪࠫ੄"))
        else:
            l11lll_opy_  = l11lll_opy_ + channel
        options.append([l11lll_opy_, index, l11l111l1_opy_])
        l11l1ll_opy_.append(stream)
    if addmore:
        options.append([l11l1l_opy_ (u"ࠫࡆࡪࡤࠡ࡯ࡲࡶࡪ࠴࠮࠯ࠩ੅"), index + 1, dixie.ICON])
        l11l1ll_opy_.append(l11l1l_opy_ (u"ࠬࡧࡤࡥࡏࡲࡶࡪ࠭੆"))
    return options, l11l1ll_opy_
def cleanLabel(name):
    import re
    name  = re.sub(l11l1l_opy_ (u"࠭࡜ࠩ࡝࠳࠱࠾࠯࡝ࠫ࡞ࠬࠫੇ"), l11l1l_opy_ (u"ࠧࠨੈ"), name)
    items = name.split(l11l1l_opy_ (u"ࠨ࡟ࠪ੉"))
    name  = l11l1l_opy_ (u"ࠩࠪ੊")
    for item in items:
        if len(item) == 0:
            continue
        item += l11l1l_opy_ (u"ࠪࡡࠬੋ")
        item  = re.sub(l11l1l_opy_ (u"ࠫࡡࡡ࡛࡟ࠫࡠ࠮ࡡࡣࠧੌ"), l11l1l_opy_ (u"੍ࠬ࠭"), item)
        if len(item) > 0:
            name += item
    name  = name.replace(l11l1l_opy_ (u"࡛࠭ࠨ੎"), l11l1l_opy_ (u"ࠧࠨ੏"))
    name  = name.replace(l11l1l_opy_ (u"ࠨ࡟ࠪ੐"), l11l1l_opy_ (u"ࠩࠪੑ"))
    name  = name.strip()
    while True:
        length = len(name)
        name = name.replace(l11l1l_opy_ (u"ࠪࠤࠥ࠭੒"), l11l1l_opy_ (u"ࠫࠥ࠭੓"))
        if length == len(name):
            break
    return name.strip()
if __name__ == l11l1l_opy_ (u"ࠬࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠧ੔"):
    checkAddons()