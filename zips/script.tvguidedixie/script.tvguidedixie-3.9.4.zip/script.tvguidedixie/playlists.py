# -*- coding: utf-8 -*-
import sys
l11llll_opy_ = sys.version_info [0] == 2
l1lllll_opy_ = 2048
l1111_opy_ = 7
def l11l1l_opy_ (ll_opy_):
	global l11l_opy_
	l1l1111_opy_ = ord (ll_opy_ [-1])
	l111l1_opy_ = ll_opy_ [:-1]
	l1ll11l_opy_ = l1l1111_opy_ % len (l111l1_opy_)
	l1ll1_opy_ = l111l1_opy_ [:l1ll11l_opy_] + l111l1_opy_ [l1ll11l_opy_:]
	if l11llll_opy_:
		l1lll1l_opy_ = unicode () .join ([unichr (ord (char) - l1lllll_opy_ - (l11ll1_opy_ + l1l1111_opy_) % l1111_opy_) for l11ll1_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1lll1l_opy_ = str () .join ([chr (ord (char) - l1lllll_opy_ - (l11ll1_opy_ + l1l1111_opy_) % l1111_opy_) for l11ll1_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1lll1l_opy_)
import os
import json
import requests
import dixie
l1l11l_opy_ = dixie.PROFILE
PATH = os.path.join(l1l11l_opy_, l11l1l_opy_ (u"ࠫࡵࡲࡩࡴࡶࡶࠫऊ"))
def loadPlaylists():
    dixie.log(l11l1l_opy_ (u"ࠬࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࠥࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠡ࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃࠧऋ"))
    if os.path.exists(PATH):
        return json.load(open(PATH))
    try:
        l11ll1l1l_opy_()
        return json.load(open(PATH))
    except:
        dixie.log(l11l1l_opy_ (u"࠭࠽࠾࠿ࡀࠤࡕࡲࡡࡺ࡮࡬ࡷࡹࠦ࡬ࡰࡣࡧࠤࡪࡸࡲࡰࡴࠣࡁࡂࡃ࠽ࠨऌ"))
        return []
def l11ll1l1l_opy_():
    source = dixie.GetSetting(l11l1l_opy_ (u"ࠧࡪࡲࡷࡺ࠳ࡹ࡯ࡶࡴࡦࡩࠬऍ"))
    if not source == l11l1l_opy_ (u"ࠨ࠳ࠪऎ"):
        return l11lllll1_opy_()
    return l11l1lll1_opy_()
def l11lllll1_opy_():
    l1l11l1l1_opy_ = []
    if dixie.GetSetting(l11l1l_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠱ࠩए")) == l11l1l_opy_ (u"ࠪࡸࡷࡻࡥࠨऐ"):
        l1l1lll11_opy_  = dixie.GetSetting(l11l1l_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠳ࡣ࡚ࡘࡌࠨऑ"))
        l1l1l1111_opy_ = dixie.GetSetting(l11l1l_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠴ࡤࡖࡏࡓࡖࠪऒ"))
        l11llll11_opy_ = dixie.GetSetting(l11l1l_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠵ࡥࡔ࡚ࡒࡈࠫओ"))
        l1l1l11ll_opy_ = dixie.GetSetting(l11l1l_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠶࡟ࡖࡕࡈࡖࠬऔ"))
        l1l1lll1l_opy_ = dixie.GetSetting(l11l1l_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠰ࡠࡒࡄࡗࡘ࠭क"))
        if len(l1l1lll11_opy_) > 0:
            l11l1llll_opy_ = l1l1l111l_opy_(l1l1lll11_opy_, l1l1l1111_opy_, l11llll11_opy_, l1l1l11ll_opy_, l1l1lll1l_opy_)
            l1l11l1l1_opy_.append((l11l1llll_opy_, l11l1l_opy_ (u"ࠩࡌࡔ࡙࡜࠱࠻ࠢࠪख")))
    if dixie.GetSetting(l11l1l_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠳ࠪग")) == l11l1l_opy_ (u"ࠫࡹࡸࡵࡦࠩघ"):
        l1l1lll11_opy_  = dixie.GetSetting(l11l1l_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠵ࡤ࡛ࡒࡍࠩङ"))
        l1l1l1111_opy_ = dixie.GetSetting(l11l1l_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠶ࡥࡐࡐࡔࡗࠫच"))
        l11llll11_opy_ = dixie.GetSetting(l11l1l_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠷࡟ࡕ࡛ࡓࡉࠬछ"))
        l1l1l11ll_opy_ = dixie.GetSetting(l11l1l_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠱ࡠࡗࡖࡉࡗ࠭ज"))
        l1l1lll1l_opy_ = dixie.GetSetting(l11l1l_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠲ࡡࡓࡅࡘ࡙ࠧझ"))
        if len(l1l1lll11_opy_) > 0:
            l1l1111ll_opy_ = l1l1l111l_opy_(l1l1lll11_opy_, l1l1l1111_opy_, l11llll11_opy_, l1l1l11ll_opy_, l1l1lll1l_opy_)
            l1l11l1l1_opy_.append((l1l1111ll_opy_, l11l1l_opy_ (u"ࠪࡍࡕ࡚ࡖ࠳࠼ࠣࠫञ")))
    if dixie.GetSetting(l11l1l_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠵ࠫट")) == l11l1l_opy_ (u"ࠬࡺࡲࡶࡧࠪठ"):
        l1l1lll11_opy_  = dixie.GetSetting(l11l1l_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠷ࡥࡕࡓࡎࠪड"))
        l1l1l1111_opy_ = dixie.GetSetting(l11l1l_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠸࡟ࡑࡑࡕࡘࠬढ"))
        l11llll11_opy_ = dixie.GetSetting(l11l1l_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠲ࡠࡖ࡜ࡔࡊ࠭ण"))
        l1l1l11ll_opy_ = dixie.GetSetting(l11l1l_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠳ࡡࡘࡗࡊࡘࠧत"))
        l1l1lll1l_opy_ = dixie.GetSetting(l11l1l_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠴ࡢࡔࡆ࡙ࡓࠨथ"))
        if len(l1l1lll11_opy_) > 0:
            l1l1111l1_opy_ = l1l1l111l_opy_(l1l1lll11_opy_, l1l1l1111_opy_, l11llll11_opy_, l1l1l11ll_opy_, l1l1lll1l_opy_)
            l1l11l1l1_opy_.append((l1l1111l1_opy_, l11l1l_opy_ (u"ࠫࡎࡖࡔࡗ࠵࠽ࠤࠬद")))
    return l11ll1l11_opy_(l11l1l_opy_ (u"࡛ࠬࡒࡍࡕࠪध"),  l1l11l1l1_opy_)
def l11l1lll1_opy_():
    l1l11l1l1_opy_ = []
    if dixie.GetSetting(l11l1l_opy_ (u"࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡶࡼࡴࡪ࠭न")) == l11l1l_opy_ (u"ࠧ࠱ࠩऩ"):
        if dixie.GetSetting(l11l1l_opy_ (u"ࠨࡗࡕࡐࡤࡕࠧप")) == l11l1l_opy_ (u"ࠩࡷࡶࡺ࡫ࠧफ"):
            l11l1ll1l_opy_ = dixie.GetSetting(l11l1l_opy_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡻࡲ࡭ࠩब"))
            if len(l11l1ll1l_opy_) > 0:
                l1l11l1l1_opy_.append((l11l1ll1l_opy_, l11l1l_opy_ (u"࡚ࠫࡘࡌ࠲࠼ࠣࠫभ")))
        if dixie.GetSetting(l11l1l_opy_ (u"࡛ࠬࡒࡍࡡ࠴ࠫम")) == l11l1l_opy_ (u"࠭ࡴࡳࡷࡨࠫय"):
            l1l111l11_opy_ = dixie.GetSetting(l11l1l_opy_ (u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡸࡶࡱ࠷ࠧर"))
            if len(l1l111l11_opy_) > 0:
                l1l11l1l1_opy_.append((l1l111l11_opy_, l11l1l_opy_ (u"ࠨࡗࡕࡐ࠷ࡀࠠࠨऱ")))
        if dixie.GetSetting(l11l1l_opy_ (u"ࠩࡘࡖࡑࡥ࠲ࠨल")) == l11l1l_opy_ (u"ࠪࡸࡷࡻࡥࠨळ"):
            l1l11111l_opy_ = dixie.GetSetting(l11l1l_opy_ (u"ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡵࡳ࡮࠵ࠫऴ"))
            if len(l1l11111l_opy_) > 0:
                l1l11l1l1_opy_.append((l1l11111l_opy_, l11l1l_opy_ (u"࡛ࠬࡒࡍ࠵࠽ࠤࠬव")))
        dixie.log(l1l11l1l1_opy_)
        return l11ll1l11_opy_(l11l1l_opy_ (u"࠭ࡕࡓࡎࡖࠫश"),  l1l11l1l1_opy_)
    if dixie.GetSetting(l11l1l_opy_ (u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡷࡽࡵ࡫ࠧष")) == l11l1l_opy_ (u"ࠨ࠳ࠪस"):
        if dixie.GetSetting(l11l1l_opy_ (u"ࠩࡉࡍࡑࡋ࡟࠱ࠩह")) == l11l1l_opy_ (u"ࠪࡸࡷࡻࡥࠨऺ"):
            l1l111lll_opy_ = os.path.join(dixie.GetSetting(l11l1l_opy_ (u"ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡦࡪ࡮ࡨࠫऻ")))
            if l1l111lll_opy_:
                l1l11l1l1_opy_.append((l1l111lll_opy_, l11l1l_opy_ (u"ࠬࡌࡉࡍࡇ࠴࠾़ࠥ࠭")))
        if dixie.GetSetting(l11l1l_opy_ (u"࠭ࡆࡊࡎࡈࡣ࠵࠭ऽ")) == l11l1l_opy_ (u"ࠧࡵࡴࡸࡩࠬा"):
            l1l11l111_opy_ = os.path.join(dixie.GetSetting(l11l1l_opy_ (u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡪ࡮ࡲࡥ࠲ࠩि")))
            if l1l11l111_opy_:
                l1l11l1l1_opy_.append((l1l11l111_opy_, l11l1l_opy_ (u"ࠩࡉࡍࡑࡋ࠲࠻ࠢࠪी")))
        if dixie.GetSetting(l11l1l_opy_ (u"ࠪࡊࡎࡒࡅࡠ࠲ࠪु")) == l11l1l_opy_ (u"ࠫࡹࡸࡵࡦࠩू"):
            l1l11l11l_opy_ = os.path.join(dixie.GetSetting(l11l1l_opy_ (u"ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡧ࡫࡯ࡩ࠷࠭ृ")))
            if l1l11l11l_opy_:
                l1l11l1l1_opy_.append((l1l11l11l_opy_, l11l1l_opy_ (u"࠭ࡆࡊࡎࡈ࠷࠿ࠦࠧॄ")))
        dixie.log(l1l11l1l1_opy_)
        return l11ll1l11_opy_(l11l1l_opy_ (u"ࠧࡇࡋࡏࡉࡘ࠭ॅ"), l1l11l1l1_opy_)
def l11ll111l_opy_():
    l11ll11l1_opy_ = [l11l1l_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡺ࠱ࡧࡴ࠵ࡈࡆ࡜࠸࡞ࡾ࡯ࡊࡦ࡙ࠪॆ")]
    for url in l11ll11l1_opy_:
        request = requests.get(url)
        content = request.content
        if l11l1l_opy_ (u"ࠩࠦࡉ࡝࡚ࡍ࠴ࡗࠪे") in content:
            return l11ll1l11_opy_(l11l1l_opy_ (u"ࠪࡇࡑࡕࡕࡅࠩै"), [(url, l11l1l_opy_ (u"ࠫࠬॉ"))])
            break
def l11ll1l11_opy_(l11ll11ll_opy_, plist):
    dixie.log(l11ll11ll_opy_)
    dixie.log(plist)
    playlists = []
    for item in plist:
        url = item[0]
        l1l111l1l_opy_ = item[1]
        l11llllll_opy_ = l1l111ll1_opy_(l11ll11ll_opy_, url, l1l111l1l_opy_)
        playlists.extend(l11llllll_opy_)
    json.dump(playlists, open(PATH,l11l1l_opy_ (u"ࠬࡽࠧॊ")))
def l1l111ll1_opy_(l11ll11ll_opy_, url, l1l111l1l_opy_):
    content  = l11ll1111_opy_(l11ll11ll_opy_, url)
    pairs    = []
    for i in range(1,len(content), 2):
        if l1l111111_opy_(content[i]) == True:
            l11lll_opy_ = content[i]
            l11lll111_opy_   = content[i+1]
            pairs.append([l11lll_opy_, l11lll111_opy_])
    l11ll1ll1_opy_ = list()
    l11lll_opy_   = l11l1l_opy_ (u"࠭ࠧो")
    value   = l11l1l_opy_ (u"ࠧࠨौ")
    for item in pairs:
        l11lll1ll_opy_ = item[0]
        l11llll1l_opy_ = item[1]
        l11lll1l1_opy_   = l11lll1ll_opy_.split(l11l1l_opy_ (u"ࠨ࠮्ࠪ"))[-1].strip()
        l11ll1l_opy_ = dixie.cleanLabel(l11lll1l1_opy_)
        l1lll_opy_ = dixie.mapChannelName(l11ll1l_opy_)
        value = l11llll1l_opy_.replace(l11l1l_opy_ (u"ࠩࡵࡸࡲࡶ࠺࠰࠱ࠧࡓࡕ࡚࠺ࡳࡶࡰࡴ࠲ࡸࡡࡸ࠿ࠪॎ"), l11l1l_opy_ (u"ࠪࠫॏ")).replace(l11l1l_opy_ (u"ࠫࡡࡴࠧॐ"), l11l1l_opy_ (u"ࠬ࠭॑"))
        l11ll1ll1_opy_.append((l1l111l1l_opy_, l1lll_opy_, value))
    return l11ll1ll1_opy_
def l1l111111_opy_(l11lll_opy_):
    l11lll_opy_ = l11lll_opy_.lower()
    filters = dixie.getFilters()
    for item in filters:
        item = item.lower()
        if item in l11lll_opy_:
            return False
    return True
def l11ll1111_opy_(l11ll11ll_opy_, url):
    import urllib
    if (l11ll11ll_opy_ == l11l1l_opy_ (u"࠭ࡕࡓࡎࡖ॒ࠫ")) or (l11ll11ll_opy_ == l11l1l_opy_ (u"ࠧࡄࡎࡒ࡙ࡉ࠭॓")):
        response = urllib.urlopen(url)
        content  = response.readlines()
        return content
    if l11ll11ll_opy_ == l11l1l_opy_ (u"ࠨࡈࡌࡐࡊ࡙ࠧ॔"):
        with open(url) as content:
            return content.readlines()
def l1l1l111l_opy_(l1l1lll11_opy_, l1l1l1111_opy_, l11llll11_opy_, l1l1l11ll_opy_, l1l1lll1l_opy_):
    url  = l11l1l_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࠪॕ")
    url +=  l1l1lll11_opy_
    url +=  l11lll11l_opy_(l1l1l1111_opy_)
    url += l11l1l_opy_ (u"ࠪ࠳࡬࡫ࡴ࠯ࡲ࡫ࡴࡄࡻࡳࡦࡴࡱࡥࡲ࡫࠽ࠨॖ")
    url +=  l1l1l11ll_opy_
    url += l11l1l_opy_ (u"ࠫࠫࡶࡡࡴࡵࡺࡳࡷࡪ࠽ࠨॗ")
    url +=  l1l1lll1l_opy_
    url += l11l1l_opy_ (u"ࠬࠬࡴࡺࡲࡨࡁࡲ࠹ࡵࡠࡲ࡯ࡹࡸࠬ࡯ࡶࡶࡳࡹࡹࡃࠧक़")
    url +=  l11ll1lll_opy_(l11llll11_opy_)
    return url
def l11lll11l_opy_(l1l1l1111_opy_):
    if not l1l1l1111_opy_ == l11l1l_opy_ (u"࠭ࠧख़"):
        return l11l1l_opy_ (u"ࠧ࠻ࠩग़") + l1l1l1111_opy_
    return l11l1l_opy_ (u"ࠨࠩज़")
def l11ll1lll_opy_(l11llll11_opy_):
    if l11llll11_opy_ == l11l1l_opy_ (u"ࠩ࠳ࠫड़"):
        return l11l1l_opy_ (u"ࠪࡱ࠸ࡻ࠸ࠨढ़")
    if l11llll11_opy_ == l11l1l_opy_ (u"ࠫ࠶࠭फ़"):
        return l11l1l_opy_ (u"ࠬࡳࡰࡦࡩࡷࡷࠬय़")
if __name__ == l11l1l_opy_ (u"࠭࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠨॠ"):
    l11ll1l1l_opy_()