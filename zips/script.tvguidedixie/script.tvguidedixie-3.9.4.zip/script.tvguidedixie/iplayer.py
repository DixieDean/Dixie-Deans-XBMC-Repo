# coding: UTF-8
import sys
l11llll_opy_ = sys.version_info [0] == 2
l1lllll_opy_ = 2048
l1111_opy_ = 7
def l11l1l_opy_ (ll_opy_):
	global l11l_opy_
	l1l1111_opy_ = ord (ll_opy_ [-1])
	l111l1_opy_ = ll_opy_ [:-1]
	l1ll11l_opy_ = l1l1111_opy_ % len (l111l1_opy_)
	l1ll1_opy_ = l111l1_opy_ [:l1ll11l_opy_] + l111l1_opy_ [l1ll11l_opy_:]
	if l11llll_opy_:
		l1lll1l_opy_ = unicode () .join ([unichr (ord (char) - l1lllll_opy_ - (l11ll1_opy_ + l1l1111_opy_) % l1111_opy_) for l11ll1_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1lll1l_opy_ = str () .join ([chr (ord (char) - l1lllll_opy_ - (l11ll1_opy_ + l1l1111_opy_) % l1111_opy_) for l11ll1_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1lll1l_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
ADDON    = dixie.ADDON
l1l11l_opy_ = dixie.PROFILE
l1ll111_opy_  = os.path.join(l1l11l_opy_, l11l1l_opy_ (u"ࠫ࡮ࡴࡩࠨࠀ"))
l1l11l1_opy_ = l11l1l_opy_ (u"ࠬ࠭ࠁ")
def l11l11l_opy_(i, t1, l1l111l_opy_=[]):
 t = l1l11l1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l111l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1l1l_opy_ = l11l11l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11_opy_ = l11l11l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1l1ll1_opy_  = l11l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡋ࡮ࡥ࡮ࡨࡷࡸ࠭ࠂ")
l1ll1ll_opy_ = l11l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡆ࡭ࡣࡺࡰࡪࡹࡳࡕࡸࠪࠃ")
dexter   = l11l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡥࡧࡻࠫࠄ")
l11l1l1_opy_   = [l1l1ll1_opy_, l1ll1ll_opy_, dexter]
def checkAddons():
    for addon in l11l1l1_opy_:
        if l11ll11_opy_(addon):
            createINI(addon)
def l11ll11_opy_(addon):
    if xbmc.getCondVisibility(l11l1l_opy_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡋࡥࡸࡇࡤࡥࡱࡱࠬࠪࡹࠩࠨࠅ") % addon) == 1:
        return True
    return False
def createINI(addon):
    HOME  = dixie.PROFILE
    l1ll11_opy_ = os.path.join(HOME, l11l1l_opy_ (u"ࠪ࡭ࡳ࡯ࠧࠆ"))
    l1llll1_opy_  = str(addon).split(l11l1l_opy_ (u"ࠫ࠳࠭ࠇ"))[2] + l11l1l_opy_ (u"ࠬ࠴ࡩ࡯࡫ࠪࠈ")
    l1l_opy_   = os.path.join(l1ll11_opy_, l1llll1_opy_)
    response = l1_opy_(addon)
    l1l1l1l_opy_ = response[l11l1l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࠉ")][l11l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࠊ")]
    l111ll_opy_  = l11l1l_opy_ (u"ࠨ࡝ࠪࠋ") + addon + l11l1l_opy_ (u"ࠩࡠࡠࡳ࠭ࠌ")
    l1l1l11_opy_  =  file(l1l_opy_, l11l1l_opy_ (u"ࠪࡻࠬࠍ"))
    l1l1l11_opy_.write(l111ll_opy_)
    l1ll1l_opy_ = []
    for channel in l1l1l1l_opy_:
        l11ll1l_opy_ = l1l11_opy_(addon, channel)
        l1ll1l1_opy_ = l11ll1l_opy_
        l1lll1_opy_ = l11lll1_opy_(addon)
        l1lll_opy_  = dixie.mapChannelName(l11ll1l_opy_)
        stream    = l1lll1_opy_ + l1ll1l1_opy_
        l11ll_opy_   = l1lll_opy_ + l11l1l_opy_ (u"ࠫࡂ࠭ࠎ") + stream
        if l11ll_opy_ not in l1ll1l_opy_:
            l1ll1l_opy_.append(l11ll_opy_)
    l1ll1l_opy_.sort()
    for item in l1ll1l_opy_:
        l1l1l11_opy_.write(l11l1l_opy_ (u"ࠧࠫࡳ࡝ࡰࠥࠏ") % item)
    l1l1l11_opy_.close()
def l1l11_opy_(addon, file):
    l11lll_opy_ = file[l11l1l_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬࠐ")].split(l11l1l_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࠑ"), 1)[0]
    l11lll_opy_ = dixie.cleanLabel(l11lll_opy_)
    return l11lll_opy_
def l11lll1_opy_(addon):
    if addon == l1l1ll1_opy_:
        return l11l1l_opy_ (u"ࠨࡇࡑࡈ࠿࠭ࠒ")
    if addon == l1ll1ll_opy_:
        return l11l1l_opy_ (u"ࠩࡉࡐࡆࡀࠧࠓ")
    if addon == dexter:
        return l11l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡆ࠽ࠫࠔ")
def getURL(url):
    if url.startswith(l11l1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡆࡐ࡚ࡀࠧࠕ")):
        url = url.replace(l11l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡇࡑ࡛࠺ࠨࠖ"), l11l1l_opy_ (u"࠭ࠧࠗ")).replace(l11l1l_opy_ (u"ࠧ࠮࠯ࡸࡷࡪࡸ࠭ࡢࡩࡨࡲࡹ࠭࠘"), l11l1l_opy_ (u"ࠨࡾࡸࡷࡪࡸ࠭ࡢࡩࡨࡲࡹ࠭࠙"))
        return url
    if url.startswith(l11l1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅࠩࠚ")):
        return l1ll_opy_(url, dexter)
    if url.startswith(l11l1l_opy_ (u"ࠪࡊࡑࡇࠧࠛ")):
        return l1ll_opy_(url, l1ll1ll_opy_)
    if url.startswith(l11l1l_opy_ (u"ࠫࡊࡔࡄࠨࠜ")):
        return l1ll_opy_(url, l1l1ll1_opy_)
    response = l1l1_opy_(url)
    stream   = url.split(l11l1l_opy_ (u"ࠬࡀࠧࠝ"), 1)[-1]
    try:
        result = response[l11l1l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࠞ")]
        l1111l_opy_  = result[l11l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࠟ")]
    except Exception as e:
        l1l1lll_opy_(e)
        return None
    for file in l1111l_opy_:
        l11lll_opy_ = file[l11l1l_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࠠ")]
        if stream in l11lll_opy_:
            return file[l11l1l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧࠡ")]
    return None
def l1ll_opy_(url, addon):
    PATH = l111_opy_(addon)
    try:
        response = json.load(open(PATH))
    except:
        response = l1_opy_(addon)
    l11l1ll_opy_      = url.split(l11l1l_opy_ (u"ࠪ࠾ࠬࠢ"), 1)[-1]
    stream    = l11l1ll_opy_.split(l11l1l_opy_ (u"ࠫࠥࡡࠧࠣ"), 1)[0]
    l11111_opy_ = dixie.cleanLabel(stream)
    l1111l_opy_  = response[l11l1l_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬࠤ")][l11l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬࠥ")]
    for file in l1111l_opy_:
        l11lll_opy_ = l1l11_opy_(addon, file)
        if l11111_opy_ in l11lll_opy_:
            return file[l11l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࠬࠦ")]
def l1_opy_(addon):
    PATH = l111_opy_(addon)
    if addon == l1l1ll1_opy_:
        query = l11l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡈࡲࡩࡲࡥࡴࡵ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡸࡺࡲࡦࡣࡰࡣࡻ࡯ࡤࡦࡱࠩࡩࡽࡺࡲࡢࠨࡳࡥ࡬࡫ࠦࡱ࡮ࡲࡸࠫࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠾ࠨࡷ࡭ࡹࡲࡥ࠾ࡃ࡯ࡰࠫࡻࡲ࡭࠿࠳ࠫࠧ")
    if addon == l1ll1ll_opy_:
        query = l11l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡊࡱࡧࡷ࡭ࡧࡶࡷ࡙ࡼ࠯ࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡵࡷࡶࡪࡧ࡭ࡠࡸ࡬ࡨࡪࡵࠦࡦࡺࡷࡶࡦࠬࡰࡢࡩࡨࠪࡵࡲ࡯ࡵࠨࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡂࠬࡴࡪࡶ࡯ࡩࡂࡇ࡬࡭ࠨࡸࡶࡱࡃ࠰ࠨࠨ")
    if addon == dexter:
        query = l1llll_opy_(addon)
    try:
        return json.load(open(PATH))
    except:
        content = doJSON(query)
        return l11l11_opy_(PATH, addon, content)
def l11l11_opy_(PATH, addon, content):
    json.dump(content, open(PATH,l11l1l_opy_ (u"ࠪࡻࠬࠩ")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    l1l11ll_opy_  = (l11l1l_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࠥࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࠪ") % query)
    response = xbmc.executeJSONRPC(l1l11ll_opy_)
    content  = json.loads(response)
    return content
def l111_opy_(addon):
    if addon == l1l1ll1_opy_:
        return os.path.join(dixie.PROFILE, l11l1l_opy_ (u"ࠬ࡫ࡴࡦ࡯ࡳࠫࠫ"))
    if addon == l1ll1ll_opy_:
        return os.path.join(dixie.PROFILE, l11l1l_opy_ (u"࠭ࡦࡵࡧࡰࡴࠬࠬ"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l11l1l_opy_ (u"ࠧࡥࡶࡨࡱࡵ࠭࠭"))
def l1llll_opy_(addon):
    if addon == dexter:
        query = l11l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡧࡩࡽ࠭࠮")
        response = doJSON(query)
        l1111l_opy_    = response[l11l1l_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩ࠯")][l11l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩ࠰")]
        for file in l1111l_opy_:
            l1lll11_opy_ = file[l11l1l_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪ࠱")]
            l11lll_opy_ = dixie.cleanLabel(l1lll11_opy_)
            if l11lll_opy_ == l11l1l_opy_ (u"ࠬࡒࡩࡷࡧࠣࡘࡻ࠭࠲"):
                livetv = file[l11l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࠫ࠳")]
                return l1l1ll_opy_(livetv)
def l1l1ll_opy_(livetv):
    response = doJSON(livetv)
    l1111l_opy_    = response[l11l1l_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧ࠴")][l11l1l_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧ࠵")]
    for file in l1111l_opy_:
        l1lll11_opy_ = file[l11l1l_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨ࠶")]
        l11lll_opy_ = dixie.cleanLabel(l1lll11_opy_)
        if l11lll_opy_ == l11l1l_opy_ (u"ࠪࡅࡱࡲࠧ࠷"):
            return file[l11l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࠩ࠸")]
def l1l1_opy_(url):
    if url.startswith(l11l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜࠾ࠬ࠹")):
        l1l11ll_opy_ = (l11l1l_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡥࡦࡨ࡯ࡰ࡭ࡣࡼࡩࡷ࠵࠿ࡶࡴ࡯ࡁࡺࡸ࡬ࠧ࡯ࡲࡨࡪࡃ࠲ࠧࡰࡤࡱࡪࡃࡌࡪࡸࡨࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࡃࠦࡊࡒࡌࡈࡂࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫ࠺"))
    if url.startswith(l11l1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞࠸࠺ࠨ࠻")):
        l1l11ll_opy_ = (l11l1l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶ࡬ࡢࡻࡨࡶࡼࡽࡷ࠰ࡁࡸࡶࡱࡃࡵࡳ࡮ࠩࡱࡴࡪࡥ࠾࠳࠳࠵ࠫࡴࡡ࡮ࡧࡀ࡛ࡦࡺࡣࡩ࠭ࡏ࡭ࡻ࡫ࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠩࡷࡺࡨࡴࡪࡶ࡯ࡩࡸࡥࡵࡳ࡮ࡀࠪࡱࡵࡧࡨࡧࡧࡣ࡮ࡴ࠽ࡇࡣ࡯ࡷࡪࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫ࠼"))
    if url.startswith(l11l1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡓ࠼ࠪ࠽")):
        l1l11ll_opy_ = (l11l1l_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱ࡮ࡤࡽࡪࡸࡷࡸࡹ࠲ࡃࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࡊࡥࡧࡣࡸࡰࡹࡌ࡯࡭ࡦࡨࡶ࠳ࡶ࡮ࡨࠨ࡯ࡳ࡬࡭ࡥࡥࡡ࡬ࡲࡂࡌࡡ࡭ࡵࡨࠪࡲࡵࡤࡦ࠿࠴࠵࠸ࠬ࡮ࡢ࡯ࡨࡁࡑ࡯ࡳࡵࡧࡱࠩ࠷࠶ࡌࡪࡸࡨࠪࡸࡻࡢࡵ࡫ࡷࡰࡪࡹ࡟ࡶࡴ࡯ࠪࡺࡸ࡬࠾ࡷࡵࡰࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ࠾"))
    if url.startswith(l11l1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡌࡘ࡛ࡀࠧ࠿")):
        l1l11ll_opy_ = (l11l1l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡷࡺࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࡀ"))
    if url.startswith(l11l1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡉࡀࠧࡁ")):
        l1l11ll_opy_ = (l11l1l_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡨࡪࡾ࠯ࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡣ࡯ࡰࠫ࡫ࡸࡵࡴࡤࠪࡵࡧࡧࡦࠨࡳࡰࡴࡺࠦࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡀࠪࡹ࡯ࡴ࡭ࡧࡀࠩ࠺ࡨࡃࡐࡎࡒࡖࠪ࠸࠰ࡸࡪ࡬ࡸࡪࠫ࠵ࡥࡃ࡯ࡰࠪ࠸࠰ࡄࡪࡤࡲࡳ࡫࡬ࡴࠧ࠸ࡦࠪ࠸ࡦࡄࡑࡏࡓࡗࠫ࠵ࡥࠨࡸࡶࡱࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࡂ"))
    if url.startswith(l11l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡒࡃ࠼ࠪࡃ")):
        l1l11ll_opy_ = (l11l1l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡥࡣࡱࡲࡸ࠴ࡅࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠪ࡫ࡧ࡮ࡢࡴࡷࡁࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡰࡳࡩ࡫࠽࠸ࠨࡳ࡭ࡱࡲ࡯ࡸ࠿ࡏ࡭ࡻ࡫ࠥ࠳࠲ࡖࡸࡷ࡫ࡡ࡮ࡵࠩࡹࡷࡲ࠽ࡳࡣࡱࡨࡴࡳࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬࡄ"))
    if url.startswith(l11l1l_opy_ (u"ࠪࡍࡕ࡚ࡓ࠻ࠩࡅ")):
        l1l11ll_opy_ = (l11l1l_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥ࡮ࡶࡴࡷ࠱ࡂࡥࡨࡺࡩࡰࡰࡀࡰ࡮ࡼࡥࡵࡸࡢࡥࡱࡲࠦࡦࡺࡷࡶࡦࠬࡰࡢࡩࡨࠪࡵࡲ࡯ࡵࠨࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡂࠬࡴࡪࡶ࡯ࡩࡂࡇ࡬࡭ࠧ࠵࠴ࡨ࡮ࡡ࡯ࡰࡨࡰࡸࠬࡵࡳ࡮ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨࡆ"))
    try:
        dixie.ShowBusy()
        addon =  l1l11ll_opy_.split(l11l1l_opy_ (u"ࠬ࠵࠯ࠨࡇ"), 1)[-1].split(l11l1l_opy_ (u"࠭࠯ࠨࡈ"), 1)[0]
        login = l11l1l_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬࡉ") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1l11ll_opy_)
        dixie.log(response)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1l1lll_opy_(e)
        return {l11l1l_opy_ (u"ࠨࡇࡵࡶࡴࡸࠧࡊ") : l11l1l_opy_ (u"ࠩࡓࡰࡺ࡭ࡩ࡯ࠢࡈࡶࡷࡵࡲࠨࡋ")}
def l111l_opy_():
    modules = map(__import__, [l11l11l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1l1l_opy_)):
        return l11l1l_opy_ (u"ࠪࡘࡷࡻࡥࠨࡌ")
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l11l1l_opy_ (u"࡙ࠫࡸࡵࡦࠩࡍ")
    return l11l1l_opy_ (u"ࠬࡌࡡ࡭ࡵࡨࠫࡎ")
def l1l1lll_opy_(e):
    l1l111_opy_ = l11l1l_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠱ࠦࡡ࡯ࠢࡨࡶࡷࡵࡲࠡࡱࡦࡧࡺࡸࡥࡥ࠼ࠣࡎࡘࡕࡎࠡࡇࡵࡶࡴࡸ࠺ࠡࠧࡶࠫࡏ")  %e
    l11l1_opy_ = l11l1l_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡳࡧ࠰ࡰ࡮ࡴ࡫ࠡࡶ࡫࡭ࡸࠦࡣࡩࡣࡱࡲࡪࡲࠠࡢࡰࡧࠤࡹࡸࡹࠡࡣࡪࡥ࡮ࡴ࠮ࠨࡐ")
    l1l1l1_opy_ = l11l1l_opy_ (u"ࠨࡗࡶࡩ࠿ࠦࡃࡰࡰࡷࡩࡽࡺࠠࡎࡧࡱࡹࠥࡃ࠾ࠡࡔࡨࡱࡴࡼࡥࠡࡕࡷࡶࡪࡧ࡭ࠨࡑ")
    dixie.log(e)
    dixie.DialogOK(l1l111_opy_, l11l1_opy_, l1l1l1_opy_)
if __name__ == l11l1l_opy_ (u"ࠩࡢࡣࡲࡧࡩ࡯ࡡࡢࠫࡒ"):
    checkAddons()