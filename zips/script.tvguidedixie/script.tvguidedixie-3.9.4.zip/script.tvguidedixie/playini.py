# coding: UTF-8
import sys
l11llll_opy_ = sys.version_info [0] == 2
l1lllll_opy_ = 2048
l1111_opy_ = 7
def l11l1l_opy_ (ll_opy_):
	global l11l_opy_
	l1l1111_opy_ = ord (ll_opy_ [-1])
	l111l1_opy_ = ll_opy_ [:-1]
	l1ll11l_opy_ = l1l1111_opy_ % len (l111l1_opy_)
	l1ll1_opy_ = l111l1_opy_ [:l1ll11l_opy_] + l111l1_opy_ [l1ll11l_opy_:]
	if l11llll_opy_:
		l1lll1l_opy_ = unicode () .join ([unichr (ord (char) - l1lllll_opy_ - (l11ll1_opy_ + l1l1111_opy_) % l1111_opy_) for l11ll1_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1lll1l_opy_ = str () .join ([chr (ord (char) - l1lllll_opy_ - (l11ll1_opy_ + l1l1111_opy_) % l1111_opy_) for l11ll1_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1lll1l_opy_)
import xbmc
import xbmcaddon
import json
import os
import dixie
l1l11lll1_opy_ = l11l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡰࡱࡷ࡭ࡵࡺࡶࠨࢲ")
l1l1l1l1l_opy_   = l11l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡙ࡶࡵࡩࡦࡳࡉࡑࡖ࡙ࠫࢳ")
l1l11llll_opy_  = l11l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡺࡷࡶࡪࡧ࡭࠮ࡥࡲࡨࡪࡹࠧࢴ")
l1l1ll111_opy_   = l11l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡑࡩࡲࢀࡺࡺࡋࡓࡘ࡛࠭ࢵ")
l1l1l1l11_opy_     = l11l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡳࡹࡺࡡ࡭ࡲ࡫ࡥࠬࢶ")
l11l1l1_opy_ = [l1l11lll1_opy_, l1l1l1l1l_opy_, l1l11llll_opy_, l1l1ll111_opy_, l1l1l1l11_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l11l1l_opy_ (u"ࠬ࡯࡮ࡪࠩࢷ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1l11l1_opy_ = l11l1l_opy_ (u"࠭ࠧࢸ")
def l11l11l_opy_(i, t1, l1l111l_opy_=[]):
 t = l1l11l1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l111l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1l1l_opy_ = l11l11l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11_opy_ = l11l11l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l11l1l1_opy_:
        if l11ll11_opy_(addon):
            createINI(addon)
def l11ll11_opy_(addon):
    if xbmc.getCondVisibility(l11l1l_opy_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡉࡣࡶࡅࡩࡪ࡯࡯ࠪࠨࡷ࠮࠭ࢹ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l1llll1_opy_ = str(addon).rsplit(l11l1l_opy_ (u"ࠨ࠰ࠪࢺ"), 1)[1] + l11l1l_opy_ (u"ࠩ࠱࡭ࡳ࡯ࠧࢻ")
    l1l_opy_  = os.path.join(PATH, l1llll1_opy_)
    try:
        l1l1l1l_opy_ = l1l11l1ll_opy_(addon)
    except KeyError:
        dixie.log(l11l1l_opy_ (u"ࠪ࠱࠲࠳࠭࠮ࠢࡎࡩࡾࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡨࡧࡷࡊ࡮ࡲࡥࡴࠢ࠰࠱࠲࠳࠭ࠡࠩࢼ") + addon)
        result = {l11l1l_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࡶࠫࢽ"): [{l11l1l_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨࢾ"): l11l1l_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࠬࢿ"), l11l1l_opy_ (u"ࡵࠨࡶࡼࡴࡪ࠭ࣀ"): l11l1l_opy_ (u"ࡶࠩࡸࡲࡰࡴ࡯ࡸࡰࠪࣁ"), l11l1l_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࠨࣂ"): l11l1l_opy_ (u"ࡸࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾࡸࡹࠩࣃ"), l11l1l_opy_ (u"ࡹࠬࡲࡡࡣࡧ࡯ࠫࣄ"): l11l1l_opy_ (u"ࡺ࠭ࡎࡐࠢࡆࡌࡆࡔࡎࡆࡎࡖࠫࣅ")}], l11l1l_opy_ (u"ࡻࠧ࡭࡫ࡰ࡭ࡹࡹࠧࣆ"):{l11l1l_opy_ (u"ࡵࠨࡵࡷࡥࡷࡺࠧࣇ"): 0, l11l1l_opy_ (u"ࡶࠩࡷࡳࡹࡧ࡬ࠨࣈ"): 1, l11l1l_opy_ (u"ࡷࠪࡩࡳࡪࠧࣉ"): 1}}
    l111ll_opy_  = l11l1l_opy_ (u"ࠪ࡟ࠬ࣊") + addon + l11l1l_opy_ (u"ࠫࡢࡢ࡮ࠨ࣋")
    l1l1l11_opy_  = file(l1l_opy_, l11l1l_opy_ (u"ࠬࡽࠧ࣌"))
    l1l1l11_opy_.write(l111ll_opy_)
    l1ll1l_opy_ = []
    try:
        for channel in l1l1l1l_opy_:
            l11ll1l_opy_ = l1l11_opy_(addon, channel)
            l1lll_opy_ = dixie.mapChannelName(l11ll1l_opy_)
            stream   = channel[l11l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࠫ࣍")]
            l11ll_opy_ = l1lll_opy_ + l11l1l_opy_ (u"ࠧ࠾ࠩ࣎") + stream
            l1ll1l_opy_.append(l11ll_opy_)
            l1ll1l_opy_.sort()
        for item in l1ll1l_opy_:
            l1l1l11_opy_.write(l11l1l_opy_ (u"ࠣࠧࡶࡠࡳࠨ࣏") % item)
        l1l1l11_opy_.close()
    except Exception as e:
        l1l1lll_opy_(e, addon)
        return {l11l1l_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࡴ࣐ࠩ"): [{l11l1l_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࣑࠭"): l11l1l_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧ࣒ࠪ"), l11l1l_opy_ (u"ࡺ࠭ࡴࡺࡲࡨ࣓ࠫ"): l11l1l_opy_ (u"ࡻࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨࣔ"), l11l1l_opy_ (u"ࡵࠨࡨ࡬ࡰࡪ࠭ࣕ"): l11l1l_opy_ (u"ࡶࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡽࡾࠧࣖ"), l11l1l_opy_ (u"ࡷࠪࡰࡦࡨࡥ࡭ࠩࣗ"): l11l1l_opy_ (u"ࡸࠫࡓࡕࠠࡄࡊࡄࡒࡓࡋࡌࡔࠩࣘ")}], l11l1l_opy_ (u"ࡹࠬࡲࡩ࡮࡫ࡷࡷࠬࣙ"):{l11l1l_opy_ (u"ࡺ࠭ࡳࡵࡣࡵࡸࠬࣚ"): 0, l11l1l_opy_ (u"ࡻࠧࡵࡱࡷࡥࡱ࠭ࣛ"): 1, l11l1l_opy_ (u"ࡵࠨࡧࡱࡨࠬࣜ"): 1}}
def l1l11_opy_(addon, file):
    l11lll_opy_ = file[l11l1l_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࣝ")].split(l11l1l_opy_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࣞ"), 1)[0]
    return dixie.cleanLabel(l11lll_opy_)
def l1l11l1ll_opy_(addon):
    login = l11l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳ࠰ࠩࣟ") % addon
    sendJSON(login, addon)
    if (addon == l1l11lll1_opy_) or (addon == l1l11llll_opy_) or (addon == l1l1l1l11_opy_):
        return l1_opy_(addon)
    if (addon == l1l1l1l1l_opy_) or (addon == l1l1ll111_opy_):
        l1l11ll1l_opy_ = [l11l1l_opy_ (u"ࠫ࠸࠭࣠"), l11l1l_opy_ (u"ࠬ࠺ࠧ࣡"), l11l1l_opy_ (u"࠭࠶ࠨ࣢"), l11l1l_opy_ (u"ࠧ࠸ࣣࠩ"), l11l1l_opy_ (u"ࠨ࠺ࠪࣤ"), l11l1l_opy_ (u"ࠩ࠴࠵ࠬࣥ"), l11l1l_opy_ (u"ࠪ࠵࠷ࣦ࠭"), l11l1l_opy_ (u"ࠫ࠶࠺ࠧࣧ"), l11l1l_opy_ (u"ࠬ࠷࠵ࠨࣨ"), l11l1l_opy_ (u"࠭࠳࠴ࣩࠩ"), l11l1l_opy_ (u"ࠧ࠺࠳ࠪ࣪"), l11l1l_opy_ (u"ࠨ࠻࠵ࠫ࣫")]
    l1111l_opy_ = []
    for l1l1l1ll1_opy_ in l1l11ll1l_opy_:
        if (addon == l1l1l1l1l_opy_) or (addon == l1l1ll111_opy_):
            query = l11l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠪࡹ࠯ࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡵࡷࡶࡪࡧ࡭ࡠࡸ࡬ࡨࡪࡵࠦࡦࡺࡷࡶࡦࠬࡰࡢࡩࡨࠪࡵࡲ࡯ࡵࠨࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡂࠬࡴࡪࡶ࡯ࡩࡂࠬࡵࡳ࡮ࡀࠩࡸ࠭࣬") % (addon, l1l1l1ll1_opy_)
        response = sendJSON(query, addon)
        l1111l_opy_.extend(response)
    return l1111l_opy_
def l1_opy_(addon):
    query = l1l1ll1l1_opy_(addon)
    return sendJSON(query, addon)
def l1l1ll1l1_opy_(addon):
    Addon = xbmcaddon.Addon(addon)
    l1l1lll11_opy_, l1l1l1111_opy_  = l1l1ll1ll_opy_(Addon, addon)
    l1l1l11ll_opy_, l1l1lll1l_opy_ = l1l11ll11_opy_(Addon, addon)
    return l1l1l111l_opy_(addon, l1l1lll11_opy_, l1l1l1111_opy_, l1l1l11ll_opy_, l1l1lll1l_opy_)
def l1l1ll1ll_opy_(Addon, addon):
    if addon == l1l11lll1_opy_:
        l1l1lll11_opy_  = l11l1l_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡶࡴࡵࡴ࠮࡫ࡳࡸࡻ࠴ࡩࡴ࠯ࡩࡳࡺࡴࡤ࠯ࡱࡵ࡫࣭ࠬ")
        l1l1l1111_opy_ = l11l1l_opy_ (u"ࠫ࠷࠻࠴࠷࠳࣮ࠪ")
        return l1l1lll11_opy_, l1l1l1111_opy_
    if addon == l1l1l1l11_opy_:
        l1l1lll11_opy_  = l11l1l_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡵࡴࡵࡶࡹ࠲࡬ࡧ࣯ࠧ")
        l1l1l1111_opy_ = l11l1l_opy_ (u"࠭࠲࠱࠻࠸ࣰࠫ")
        return l1l1lll11_opy_, l1l1l1111_opy_
    l1l1lll11_opy_  = Addon.getSetting(l11l1l_opy_ (u"ࠧ࡭ࡧ࡫ࡩࡰࡿ࡬ࡨࣱࠩ"))
    l1l1l1111_opy_ = Addon.getSetting(l11l1l_opy_ (u"ࠨࡲࡲࡶࡩ࡯࡮ࡶ࡯ࡥࡩࡷࣲ࠭"))
    return l1l1lll11_opy_, l1l1l1111_opy_
def l1l11ll11_opy_(Addon, addon):
    if addon == l1l1l1l11_opy_:
        l1l1l11ll_opy_ = Addon.getSetting(l11l1l_opy_ (u"ࠩࡘࡷࡪࡸ࡮ࡢ࡯ࡨࠫࣳ"))
        l1l1lll1l_opy_ = Addon.getSetting(l11l1l_opy_ (u"ࠪࡔࡦࡹࡳࡸࡱࡵࡨࠬࣴ"))
        return l1l1l11ll_opy_, l1l1lll1l_opy_
    l1l1l11ll_opy_ = Addon.getSetting(l11l1l_opy_ (u"ࠫࡰࡧࡳࡶࡶࡤ࡮ࡦࡴࡩ࡮࡫ࠪࣵ"))
    l1l1lll1l_opy_ = Addon.getSetting(l11l1l_opy_ (u"ࠬࡹࡡ࡭ࡣࡶࡳࡳࡧࣶࠧ"))
    return l1l1l11ll_opy_, l1l1lll1l_opy_
def l1l1l111l_opy_(addon, l1l1lll11_opy_, l1l1l1111_opy_, l1l1l11ll_opy_, l1l1lll1l_opy_):
    if addon == l1l11lll1_opy_:
        action = l11l1l_opy_ (u"࠭ࡉ࠲࠳ࡌࡍ࠶࡯ࠧࣷ")
    else:
        action = l11l1l_opy_ (u"ࠧࡴࡶࡵࡩࡦࡳ࡟ࡷ࡫ࡧࡩࡴ࠭ࣸ")
    l1l1ll11l_opy_  = l11l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࣹࠫ")
    l1l1ll11l_opy_ +=  addon
    l1l1ll11l_opy_ += l11l1l_opy_ (u"ࠩ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࠪࡹࠦࡦࡺࡷࡶࡦࠬࡰࡢࡩࡨࠪࡵࡲ࡯ࡵࠨࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡂࠬࡴࡪࡶ࡯ࡩࡂࡇ࡬࡭ࠨࡸࡶࡱࡃࣺࠧ") % (action)
    params  =  l1l1lll11_opy_
    params += l11l1l_opy_ (u"ࠪ࠾ࠬࣻ") + l1l1l1111_opy_
    params += l11l1l_opy_ (u"ࠫ࠴࡫࡮ࡪࡩࡰࡥ࠷࠴ࡰࡩࡲࡂࡹࡸ࡫ࡲ࡯ࡣࡰࡩࡂ࠭ࣼ")
    params +=  l1l1l11ll_opy_
    params += l11l1l_opy_ (u"ࠬࠬࡰࡢࡵࡶࡻࡴࡸࡤ࠾ࠩࣽ")
    params +=  l1l1lll1l_opy_
    params += l11l1l_opy_ (u"࠭ࠦࡵࡻࡳࡩࡂ࡭ࡥࡵࡡ࡯࡭ࡻ࡫࡟ࡴࡶࡵࡩࡦࡳࡳࠧࡥࡤࡸࡤ࡯ࡤ࠾࠲ࠪࣾ")
    import urllib
    params = urllib.quote_plus(params)
    url = l1l1ll11l_opy_ + params
    return url
def login(addon):
    login = l11l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷ࠴࠭ࣿ") % addon
    sendJSON(login, addon)
def sendJSON(query, addon):
    l1l1l11l1_opy_     = l11l1l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫऀ") % query
    l1l1l1lll_opy_  = xbmc.executeJSONRPC(l1l1l11l1_opy_)
    response = json.loads(l1l1l1lll_opy_)
    result   = response[l11l1l_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩँ")]
    return result[l11l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩं")]
def l111l_opy_():
    modules = map(__import__, [l11l11l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1l1l_opy_)):
        return l11l1l_opy_ (u"࡙ࠫࡸࡵࡦࠩः")
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l11l1l_opy_ (u"࡚ࠬࡲࡶࡧࠪऄ")
    return l11l1l_opy_ (u"࠭ࡆࡢ࡮ࡶࡩࠬअ")
def l1l1lll_opy_(e, addon):
    l1l111_opy_ = l11l1l_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠲ࠠࡢࡰࠣࡩࡷࡸ࡯ࡳࠢࡲࡧࡨࡻࡲࡦࡦ࠽ࠤࡏ࡙ࡏࡏࠢࡈࡶࡷࡵࡲ࠻ࠢࠨࡷ࠱ࠦࠥࡴࠩआ")  % (e, addon)
    l11l1_opy_ = l11l1l_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡥࡲࡲࡹࡧࡣࡵࠢࡸࡷࠥࡵ࡮ࠡࡶ࡫ࡩࠥ࡬࡯ࡳࡷࡰ࠲ࠬइ")
    l1l1l1_opy_ = l11l1l_opy_ (u"ࠩࡘࡴࡱࡵࡡࡥࠢࡤࠤࡱࡵࡧࠡࡸ࡬ࡥࠥࡺࡨࡦࠢࡤࡨࡩࡵ࡮ࠡࡵࡨࡸࡹ࡯࡮ࡨࡵࠣࡥࡳࡪࠠࡱࡱࡶࡸࠥࡺࡨࡦࠢ࡯࡭ࡳࡱ࠮ࠨई")
    dixie.log(addon)
    dixie.log(e)
if __name__ == l11l1l_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬउ"):
    checkAddons()