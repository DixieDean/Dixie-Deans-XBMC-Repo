# coding: UTF-8
import sys
l111lll_opy_ = sys.version_info [0] == 2
l1llll1_opy_ = 2048
l11l1l_opy_ = 7
def l11lll_opy_ (ll_opy_):
	global l1lll_opy_
	l1111_opy_ = ord (ll_opy_ [-1])
	l11l11l_opy_ = ll_opy_ [:-1]
	l1ll1_opy_ = l1111_opy_ % len (l11l11l_opy_)
	l1l1l_opy_ = l11l11l_opy_ [:l1ll1_opy_] + l11l11l_opy_ [l1ll1_opy_:]
	if l111lll_opy_:
		l1ll1ll_opy_ = unicode () .join ([unichr (ord (char) - l1llll1_opy_ - (l1l1l1_opy_ + l1111_opy_) % l11l1l_opy_) for l1l1l1_opy_, char in enumerate (l1l1l_opy_)])
	else:
		l1ll1ll_opy_ = str () .join ([chr (ord (char) - l1llll1_opy_ - (l1l1l1_opy_ + l1111_opy_) % l11l1l_opy_) for l1l1l1_opy_, char in enumerate (l1l1l_opy_)])
	return eval (l1ll1ll_opy_)
import xbmc
import xbmcgui
import xbmcaddon
import json
import datetime
import os
import dixie
import mapping
l111l1l_opy_   = l11lll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰ࡮ࡻࡸ࠯ࡶࡹࠫࠀ")
l1ll1l1_opy_ = l11lll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡺࡲࡦࡣࡰࡷࡪࡧࡳࡺ࠰ࡷࡺࠬࠁ")
l1l1l1l_opy_ = l11lll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹ࡭ࡢࡴࡷ࡬ࡺࡨࠧࠂ")
l11l1_opy_ = l11lll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࠶ࠬࠃ")
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
def isValid(stream):
    dixie.log(l11lll_opy_ (u"ࠨ࠯࠰࠱ࠥࡉࡨࡦࡥ࡮ࠤࡎ࡙ࠠࡗࡃࡏࡍࡉࠦࡳࡵࡴࡨࡥࡲࠦ࠭࠮࠯ࠪࠄ"))
    dixie.log(stream)
    if l11lll_opy_ (u"ࠩࡉࡐࡆࡀࠧࠅ") in stream:
        dixie.log(l11lll_opy_ (u"ࠪ࠱࠲࠳ࠠࡇࡎࡄ࡛ࡑࡋࡓࡔࠢࡗࡖ࡚ࡋࠠ࠮࠯࠰ࠫࠆ"))
        return True
    if l11lll_opy_ (u"ࠫࡍࡊࡔࡗࠩࠇ") in stream:
        dixie.log(l11lll_opy_ (u"ࠬ࠳࠭࠮ࠢࡋࡈ࡙࡜ࠠࡕࡔࡘࡉࠥ࠳࠭࠮ࠩࠈ"))
        return True
    if l111l1l_opy_ in stream:
        dixie.log(l11lll_opy_ (u"࠭࠭࠮࠯ࠣࡐࡎ࡛ࡘࠡࡖࡕ࡙ࡊࠦ࠭࠮࠯ࠪࠉ"))
        return True
    if l1ll1l1_opy_ in stream:
        dixie.log(l11lll_opy_ (u"ࠧ࠮࠯࠰ࠤࡘ࡚ࡅࡂࡕ࡜ࠤ࡙ࡘࡕࡆࠢ࠰࠱࠲࠭ࠊ"))
        return True
    dixie.log(l11lll_opy_ (u"ࠨ࠯࠰࠱ࠥ࡜ࡁࡍࡋࡇࠤࡋࡇࡌࡔࡇࠣ࠱࠲࠳ࠧࠋ"))
    return False
def getRecording(name, title, start, stream):
    if l11lll_opy_ (u"ࠩࡉࡐࡆࡀࠧࠌ") in stream:
        dixie.log(l11lll_opy_ (u"ࠪ࠱࠲࠳ࠠࡇࡎࡄ࠾ࠥ࡯࡮ࠡࡵࡷࡶࡪࡧ࡭ࠡ࠯࠰࠱ࠬࠍ"))
        return getIPTVRecording(name, title, start, stream)
    if l11lll_opy_ (u"ࠫࡍࡊࡔࡗࠩࠎ") in stream:
        dixie.log(l11lll_opy_ (u"ࠬ࠳࠭࠮ࠢࡋࡈ࡙࡜࠺ࠡ࡫ࡱࠤࡸࡺࡲࡦࡣࡰࠤ࠲࠳࠭ࠨࠏ"))
        return getHDTVRecording(name, title, start, stream)
    if l111l1l_opy_ in stream:
        dixie.log(l11lll_opy_ (u"࠭࠭࠮࠯ࠣࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡯࡭ࡺࡾ࠮ࡵࡸࠣ࡭ࡳࠦࡳࡵࡴࡨࡥࡲࠦ࠭࠮࠯ࠪࠐ"))
        addon = l111l1l_opy_
        return l1ll_opy_(addon, name, title, start, stream)
    if l1ll1l1_opy_ in stream:
        dixie.log(l11lll_opy_ (u"ࠧ࠮࠯࠰ࠤࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡹࡸࡥࡢ࡯ࡶࡩࡦࡹࡹ࠯ࡶࡹࠤ࡮ࡴࠠࡴࡶࡵࡩࡦࡳࠠ࠮࠯࠰ࠫࠑ"))
        addon = l1ll1l1_opy_
        return l1ll_opy_(addon, name, title, start, stream)
def getIPTVRecording(name, title, start, stream):
    dixie.log(l11lll_opy_ (u"ࠨࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࠤࡈࡇࡔࡄࡊ࡙ࠣࡕࠦࡉࡑࡖ࡙ࠤࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࠨࠒ"))
    import time
    l1lllll_opy_ = stream.split(l11lll_opy_ (u"ࠩࡿࠫࠓ"))
    dixie.log(l1lllll_opy_)
    for url in l1lllll_opy_:
        url   = url.split(CLOSE_OTT)[1].rsplit(l11lll_opy_ (u"ࠪ࠾ࠬࠔ"))
        l111l_opy_ = url[0]
        dixie.log(url)
        if l111l_opy_ == l11lll_opy_ (u"ࠫࡋࡒࡁࠨࠕ"):
            addon = l11lll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡋࡲࡡࡸ࡮ࡨࡷࡸ࡚ࡶࠨࠖ")
    import urllib
    l1l1lll_opy_ = l11111_opy_()
    dixie.log(l11lll_opy_ (u"࠭ࡅࡑࡉࠣࡗࡹࡧࡲࡵࠢࡗ࡭ࡲ࡫࠮࠯࠰࠽ࠤࠪࡹࠧࠗ") % start)
    dixie.log(l11lll_opy_ (u"ࠧࡐࡨࡩࡷࡪࡺࠠࡪࡰࠣࡷࡪࡩ࡯࡯ࡦࡶ࠾ࠥࠫࡳࠨ࠘") % l1l1lll_opy_)
    l11l1l1_opy_  =  start - datetime.timedelta(seconds=l1l1lll_opy_)
    dixie.log(l11lll_opy_ (u"ࠨࡕࡷࡥࡷࡺࠠࡕ࡫ࡰࡩࠥࡵࡦࡧࡵࡨࡸ࠿ࠦࠥࡴࠩ࠙") % l11l1l1_opy_)
    l11_opy_ = str(l11l1l1_opy_)
    dixie.log(l11lll_opy_ (u"ࠩࡷ࡭ࡲ࡫ࡳࡵࡴ࡬ࡲ࡬ࡀࠠࠦࡵࠪࠚ") % l11_opy_)
    l1ll1l_opy_   = l11_opy_.split(l11lll_opy_ (u"ࠪࠤࠬࠛ"))[0]
    l1l1l11_opy_  = l11_opy_.split(l11lll_opy_ (u"ࠫࠥ࠭ࠜ"))[1]
    l11l_opy_  = time.strptime(l1l1l11_opy_,  l11lll_opy_ (u"ࠬࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠧࠝ"))
    theTime    = time.strftime(l11lll_opy_ (u"࠭ࠥࡉ࠼ࠨࡑࠬࠞ"),  l11l_opy_)
    dixie.log(l11lll_opy_ (u"ࠧࡊࡒࡗ࡚ࡸࡺࡡࡳࡶ࠽ࠤࠪࡹࠧࠟ") % theTime)
    l11l1ll_opy_ = time.strptime(l1ll1l_opy_,   l11lll_opy_ (u"ࠨࠧ࡜࠱ࠪࡳ࠭ࠦࡦࠪࠠ"))
    theDate    = time.strftime(l11lll_opy_ (u"ࠩࠨ࡝࠴ࠫ࡭࠰ࠧࡧࠫࠡ"), l11l1ll_opy_)
    dixie.log(l11lll_opy_ (u"ࠪࡍࡕ࡚ࡖࡥࡶ࡬ࡸࡱ࡫࠺ࠡࠧࡶࠫࠢ") % theDate)
    return getCatchupLink(addon, name, title, theDate, theTime)
def getCatchupLink(addon, channel, theShow, theDate, theTime):
    dixie.log(l11lll_opy_ (u"ࠫࡂࡃ࠽࠾࠿ࡀࠤ࡬࡫ࡴࡄࡣࡷࡧ࡭ࡻࡰࡍ࡫ࡱ࡯ࠥࡃ࠽࠾࠿ࡀࡁࠬࠣ"))
    HOME  = dixie.PROFILE
    iPATH = os.path.join(HOME, l11lll_opy_ (u"ࠬ࡯࡮ࡪࠩࠤ"))
    LABELFILE = os.path.join(iPATH, l11lll_opy_ (u"࠭ࡣࡢࡶࡦ࡬ࡺࡶ࠮࡫ࡵࡲࡲࠬࠥ"))
    labelmaps = json.load(open(LABELFILE))
    dixie.log(labelmaps)
    l1l1111_opy_ = l11lll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪࠦ") + addon
    item   = l11lll_opy_ (u"ࠨࡈࡏࡅ࡜ࡒࡅࡔࡕࠣࡇࡆ࡚ࡃࡉࡗࡓࠫࠧ")
    try:
        l1llll_opy_  = findCatchup(l1l1111_opy_, item)
        l1l11_opy_  = mapping.mapLabel(labelmaps, channel)
        dixie.log(l11lll_opy_ (u"ࠩࡀࡁࡂࡃ࠽࠾ࠢࡰࡥࡵࡶࡥࡥࡎࡤࡦࡪࡲࠠ࠾࠿ࡀࡁࡂࡃࠧࠨ"))
        dixie.log(l1l11_opy_)
        l111_opy_   = findCatchup(l1llll_opy_, l1l11_opy_)
        dixie.log(l11lll_opy_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࠣࡸ࡭࡫ࡃࡩࡣࡱࡲࡪࡲࠠ࠾࠿ࡀࡁࡂࡃࠧࠩ"))
        dixie.log(l111_opy_)
        l11l11_opy_ = theDate + l11lll_opy_ (u"ࠫࠥ࠳ࠠࠨࠪ") + theTime
        l11l11_opy_ = l11l11_opy_.upper()
        dixie.log(l11lll_opy_ (u"ࠬࡃ࠽࠾࠿ࡀࡁࠥࡺࡨࡦࡔࡨࡧࡴࡸࡤࡪࡰࡪࠤࡂࡃ࠽࠾࠿ࡀࠫࠫ"))
        dixie.log(l11l11_opy_)
        l1111l_opy_      = findCatchup(l111_opy_, l11l11_opy_, splitlabel=True)
        dixie.log(l11lll_opy_ (u"࠭࠽࠾࠿ࡀࡁࡂࠦࡴࡩࡧࡏ࡭ࡳࡱࠠ࠾࠿ࡀࡁࡂࡃࠧࠬ"))
        dixie.log(l1111l_opy_)
        dixie.DialogOK(l11lll_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡰࡴࡤࡲ࡬࡫࡝࡜ࡄࡠࡇࡦࡺࡣࡩ࠯ࡸࡴࠥࡹࡴࡳࡧࡤࡱࠥ࡬࡯ࡶࡰࡧ࠲ࡠ࠵ࡂ࡞࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ࠭"), l11lll_opy_ (u"ࠨࡑࡱ࠱࡙ࡧࡰࡱ࠰ࡗ࡚ࠥࡽࡩ࡭࡮ࠣࡲࡴࡽࠠࡱ࡮ࡤࡽ࠿࡛ࠦࡄࡑࡏࡓࡗࠦ࡯ࡳࡣࡱ࡫ࡪࡣ࡛ࡃ࡟ࠨࡷࡠ࠵ࡂ࡞࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ࠮") % (theShow))
        return l1111l_opy_
    except:
        dixie.DialogOK(l11lll_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠯ࠩ࠯"), l11lll_opy_ (u"࡛ࠪࡪࠦࡣࡰࡷ࡯ࡨࠥࡴ࡯ࡵࠢࡩ࡭ࡳࡪࠠࡢࠢࡦࡥࡹࡩࡨࡶࡲࠣࡷࡹࡸࡥࡢ࡯ࠣࡪࡴࡸࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲ࠴ࠧ࠰"), l11lll_opy_ (u"ࠫࡗ࡫ࡶࡦࡴࡷ࡭ࡳ࡭ࠠࡣࡣࡦ࡯ࠥࡺ࡯ࠡࡎ࡬ࡺࡪࠦࡔࡗ࠰ࠪ࠱"))
        return None
def findCatchup(query, item, splitlabel=False):
    dixie.log(l11lll_opy_ (u"ࠬࡃ࠽࠾࠿ࡀࡁࠥࡌࡉࡏࡆࠣࡇࡆ࡚ࡃࡉࡗࡓࠤࡎ࡚ࡅࡎࠢࡀࡁࡂࡃ࠽࠾ࠩ࠲"))
    dixie.log(item)
    response = doJSON(query)
    l111l1_opy_    = response[l11lll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭࠳")][l11lll_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭࠴")]
    for file in l111l1_opy_:
        l1l1_opy_ = file[l11lll_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧ࠵")]
        l1l1ll_opy_ = mapping.cleanLabel(l1l1_opy_)
        if splitlabel:
            l1l1ll_opy_ = l1l1ll_opy_.upper()
            l1l1ll_opy_ = l1l1ll_opy_.rsplit(l11lll_opy_ (u"ࠩࠣ࠱ࠥ࠭࠶"), 1)[0]
        else:
            l1l1ll_opy_ = l1l1ll_opy_.upper()
        dixie.log(l11lll_opy_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࠣࡊࡎࡔࡄࠡࡅࡄࡘࡈࡎࡕࡑࠢࡀࡁࡂࡃ࠽࠾ࠩ࠷"))
        dixie.log(l1l1ll_opy_)
        if l1l1ll_opy_ == item.upper():
            dixie.log(l11lll_opy_ (u"ࠫࡂࡃ࠽࠾࠿ࡀࠤࡈࡇࡔࡄࡊࡘࡔࠥࡌࡉࡍࡇࠣࡁࡂࡃ࠽࠾࠿ࠪ࠸"))
            dixie.log(file[l11lll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪ࠹")])
            return file[l11lll_opy_ (u"࠭ࡦࡪ࡮ࡨࠫ࠺")]
def doJSON(query):
    l1l11l1_opy_  = (l11lll_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ࠻") % query)
    response = xbmc.executeJSONRPC(l1l11l1_opy_)
    content  = json.loads(response)
    return content
def l1ll_opy_(addon, name, title, start, stream):
    import time
    dixie.log(l11lll_opy_ (u"ࠨࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࠤࡈࡇࡔࡄࡊ࡙ࠣࡕࠦࡌ࡙ࡖ࡙ࠤࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࠨ࠼"))
    l1lllll_opy_ = stream.split(l11lll_opy_ (u"ࠩࡿࠫ࠽"))
    for url in l1lllll_opy_:
        if (l1ll1l1_opy_ in url) or (l111l1l_opy_ in url):
            dixie.log(l11lll_opy_ (u"ࠪࡐ࡝࡚ࡖࠡࡗࡕࡐ࠳࠴࠮࠻ࠢࠨࡷࠬ࠾") % url)
            l111ll_opy_ = url.split(CLOSE_OTT)[0].replace(OPEN_OTT, l11lll_opy_ (u"ࠫࠬ࠿"))
            break
    import urllib
    l1l1lll_opy_ = l11111_opy_()
    dixie.log(l11lll_opy_ (u"ࠬࡋࡐࡈࠢࡖࡸࡦࡸࡴࠡࡖ࡬ࡱࡪ࠴࠮࠯࠼ࠣࠩࡸ࠭ࡀ") % start)
    dixie.log(l11lll_opy_ (u"࠭ࡏࡧࡨࡶࡩࡹࠦࡩ࡯ࠢࡶࡩࡨࡵ࡮ࡥࡵ࠽ࠤࠪࡹࠧࡁ") % l1l1lll_opy_)
    l11l1l1_opy_  =  start - datetime.timedelta(seconds=l1l1lll_opy_)
    dixie.log(l11lll_opy_ (u"ࠧࡔࡶࡤࡶࡹࠦࡔࡪ࡯ࡨࠤࡴ࡬ࡦࡴࡧࡷ࠾ࠥࠫࡳࠨࡂ") % l11l1l1_opy_)
    l1lll1l_opy_     = l1lll1_opy_(l111ll_opy_)
    l11_opy_ = str(l11l1l1_opy_)
    l11llll_opy_   = l11_opy_.split(l11lll_opy_ (u"ࠨࠢࠪࡃ"))[0]
    l1l1l11_opy_  = l11_opy_.split(l11lll_opy_ (u"ࠩࠣࠫࡄ"))[1]
    l11ll1_opy_  = time.strptime(l1l1l11_opy_,  l11lll_opy_ (u"ࠪࠩࡍࡀࠥࡎ࠼ࠨࡗࠬࡅ"))
    l11ll1_opy_  = time.strftime(l11lll_opy_ (u"ࠫࠪࡏ࠺ࠦࡏࠣࠩࡵ࠭ࡆ"),  l11ll1_opy_)
    l1l111l_opy_ = time.strptime(l11llll_opy_,   l11lll_opy_ (u"࡙ࠬࠫ࠮ࠧࡰ࠱ࠪࡪࠧࡇ"))
    l1l111l_opy_ = time.strftime(l11lll_opy_ (u"࠭ࠥࡂ࠮ࠣࠩࡇࠦࠥࡥࠩࡈ"), l1l111l_opy_)
    query = l11lll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷ࠴ࡅࡣࡩࡣࡱࡲࡪࡲ࡟ࡪࡦࡀࠩࡸࠬࡤࡢࡶࡨࡁࠪࡹࠦࡥࡣࡷࡩࡤࡺࡩࡵ࡮ࡨࡁࠪࡹࠦࡪ࡯ࡪࡁࠫࡳ࡯ࡥࡧࡀࡶࡪࡩ࡯ࡳࡦ࡬ࡲ࡬ࡹࠦࡵ࡫ࡷࡰࡪࡃࠥࡴࠩࡉ") % (addon, l1lll1l_opy_, l11llll_opy_, l1l111l_opy_, l111ll_opy_)
    l1l11l_opy_  = l11lll_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࡊ") % query
    if not l1lll1l_opy_:
        dixie.DialogOK(l11lll_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠯ࠩࡋ"), l11lll_opy_ (u"࡛ࠪࡪࠦࡣࡰࡷ࡯ࡨࠥࡴ࡯ࡵࠢࡩ࡭ࡳࡪࠠࡢࠢࡦࡥࡹࡩࡨࡶࡲࠣࡷࡪࡸࡶࡪࡥࡨࠤ࡫ࡵࡲࠡࡶ࡫࡭ࡸࠦࡣࡩࡣࡱࡲࡪࡲ࠮ࠨࡌ"), l11lll_opy_ (u"ࠫࡗ࡫ࡶࡦࡴࡷ࡭ࡳ࡭ࠠࡣࡣࡦ࡯ࠥࡺ࡯ࠡࡎ࡬ࡺࡪࠦࡔࡗ࠰ࠪࡍ"))
        return None
    l1lll11_opy_    = xbmc.executeJSONRPC(l1l11l_opy_)
    response   = json.loads(l1lll11_opy_)
    result     = response[l11lll_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬࡎ")]
    l1ll11l_opy_ = result[l11lll_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬࡏ")]
    for l11ll11_opy_ in l1ll11l_opy_:
        try:
            l1l111_opy_ = l11ll11_opy_[l11lll_opy_ (u"ࠧࡧ࡫࡯ࡩࠬࡐ")]
            l1l1ll_opy_   = l11ll11_opy_[l11lll_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࡑ")]
            if l11ll1_opy_ in l1l1ll_opy_:
                dixie.DialogOK(l11lll_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡲࡶࡦࡴࡧࡦ࡟ࡆࡥࡹࡩࡨ࠮ࡷࡳࠤࡸࡺࡲࡦࡣࡰࠤ࡫ࡵࡵ࡯ࡦ࠱࡟࠴ࡉࡏࡍࡑࡕࡡࠬࡒ"), l11lll_opy_ (u"ࠪࡓࡳ࠳ࡔࡢࡲࡳ࠲࡙࡜ࠠࡸ࡫࡯ࡰࠥࡴ࡯ࡸࠢࡳࡰࡦࡿ࠺ࠡ࡝ࡆࡓࡑࡕࡒࠡࡱࡵࡥࡳ࡭ࡥ࡞࡝ࡅࡡࠪࡹ࡛࠰ࡄࡠ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࡓ") % (title))
                return l1l111_opy_
        except Exception, e:
            dixie.log(l11lll_opy_ (u"ࠫࡊࡘࡒࡐࡔ࠽ࠤࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡵࡪࡵࡳࡼࡴࠠࡪࡰࠣ࡫ࡪࡺࡌ࡙ࡖ࡙ࡖࡪࡩ࡯ࡳࡦ࡬ࡲ࡬ࠦࠥࡴࠩࡔ") % str(e))
            dixie.DialogOK(l11lll_opy_ (u"࡙ࠬ࡯ࡳࡴࡼ࠲ࠬࡕ"), l11lll_opy_ (u"࠭ࡗࡦࠢࡦࡳࡺࡲࡤࠡࡰࡲࡸࠥ࡬ࡩ࡯ࡦࠣࡥࠥࡩࡡࡵࡥ࡫ࡹࡵࠦࡳࡵࡴࡨࡥࡲࠦࡦࡰࡴࠣࡸ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮࠰ࠪࡖ"), l11lll_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡵࡴࡼࠤࡦ࡭ࡡࡪࡰࠣࡰࡦࡺࡥࡳ࠰ࠪࡗ"))
            return None
def l1lll1_opy_(l111ll_opy_):
    l111ll_opy_ = l111ll_opy_.upper()
    if l111ll_opy_ == l11lll_opy_ (u"ࠨ࠵ࡈࠫࡘ") : return 188
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡄࡆࡈࠦࡅࡂࡕࡗ࡙ࠫ") : return 363
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡅࡇࡉ࡚ࠧ") : return 346
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡆࡓࡃࠨ࡛") : return 375
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡇࡌࡊࡄࡌࠤࡎࡘࡅࡍࡃࡑࡈࠬ࡜") : return 280
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡁࡏࡋࡐࡅࡑࠦࡐࡍࡃࡑࡉ࡙ࠦࡕࡔࡃࠪ࡝") : return 386
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡂࡐࡌࡑࡆࡒࠠࡑࡎࡄࡒࡊ࡚ࠧ࡞") : return 19
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡃࡕࡉࡓࡇࠠࡔࡒࡒࡖ࡙࡙ࠠ࠲ࠢࡋࡈࠥࡉࡒࡐࡃࡗࡍࡆ࠭࡟") : return 403
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡄࡖࡊࡔࡁࠡࡕࡓࡓࡗ࡚ࡓࠡ࠴ࠣࡌࡉࠦࡃࡓࡑࡄࡘࡎࡇࠧࡠ") : return 404
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡅࡗࡋࡎࡂࠢࡖࡔࡔࡘࡔࡔࠢ࠶ࠤࡍࡊࠠࡄࡔࡒࡅ࡙ࡏࡁࠨࡡ") : return 405
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡆࡘࡅࡏࡃࠣࡗࡕࡕࡒࡕࡕࠣ࠸ࠥࡎࡄࠡࡅࡕࡓࡆ࡚ࡉࡂࠩࡢ") : return 406
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡇࡒࡆࡐࡄࠤࡘࡖࡏࡓࡖࡖࠤ࠺ࠦࡓࡓࡄࠪࡣ") : return 407
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡁࡕࠢࡗࡌࡊࠦࡒࡂࡅࡈࡗࠬࡤ") : return 273
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡃࡄࡆࠤࡔࡔࡅ࡜ࡊࡇࡡࠬࡥ") : return 210
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡄࡅࡇ࡚ࠥࡗࡐ࡝ࡋࡈࡢ࠭ࡦ") : return 211
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡅࡉࡎࡔࠠࡔࡒࡒࡖ࡙ࠦ࠱࠱ࠢࡋࡈ࡚࠭ࡅࡔࡖࠬࠫࡧ") : return 300
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡆࡊࡏࡎࠡࡕࡓࡓࡗ࡚ࠠ࠲࠳ࠣࡌࡉ࠮ࡔࡆࡕࡗ࠭ࠬࡨ") : return 389
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡇࡋࡉࡏࠢࡖࡔࡔࡘࡔࠡ࠳ࡋࡈ࡚࠭ࡅࡔࡖࠬࠫࡩ") : return 285
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡈࡅࡊࡐࠣࡗࡕࡕࡒࡕࠢ࠵ࠤࡍࡊࠨࡕࡇࡖࡘ࠮࠭ࡪ") : return 286
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡂࡆࡋࡑࠤࡘࡖࡏࡓࡖࠣ࠷ࠥࡎࡄࠩࡖࡈࡗ࡙࠯ࠧ࡫") : return 287
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡃࡇࡌࡒ࡙ࠥࡐࡐࡔࡗࠤ࠹ࠦࡈࡅࠪࡗࡉࡘ࡚ࠩࠨ࡬") : return 288
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡄࡈࡍࡓࠦࡓࡑࡑࡕࡘࠥ࠻ࠠࡉࡆࠫࡘࡊ࡙ࡔࠪࠩ࡭") : return 289
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡅࡉࡎࡔࠠࡔࡒࡒࡖ࡙ࠦ࠶ࠡࡊࡇ࡙ࠬࡋࡓࡕࠫࠪ࡮") : return 290
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡆࡊࡏࡎࠡࡕࡓࡓࡗ࡚ࠠ࠸ࠢࡋࡈ࡚࠭ࡅࡔࡖࠬࠫ࡯") : return 291
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡇࡋࡉࡏࠢࡖࡔࡔࡘࡔࠡ࠺ࠣࡌࡉ࠮ࡔࡆࡕࡗ࠭ࠬࡰ") : return 292
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡈࡅࡊࡐࠣࡗࡕࡕࡒࡕࠢ࠼ࠤࡍࡊࠨࡕࡇࡖࡘ࠮࠭ࡱ") : return 293
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡂࡕࠢࡖࡔࡔࡘࡔࠡ࠳ࠣࡌࡉࠦࠨࡕࡇࡖࡘ࠮࠭ࡲ") : return 306
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡃࡖࠣࡗࡕࡕࡒࡕࠢ࠴ࠫࡳ") : return 17
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡄࡗࠤࡘࡖࡏࡓࡖࠣ࠶ࠥࡎࡄࠡࠪࡗࡉࡘ࡚ࠩࠨࡴ") : return 307
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡅࡘ࡙ࠥࡐࡐࡔࡗࠤ࠷࠭ࡵ") : return 18
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡆ࡙ࠦࡓࡑࡑࡕࡘࠥࡋࡓࡑࡐࠪࡶ") : return 24
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡇ࡚ࠠࡔࡒࡒࡖ࡙ࠦࡅࡖࡔࡒࡔࡊ࠭ࡷ") : return 216
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡈࡁࡃ࡛ࠣࡘ࡛࠭ࡸ") : return 299
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡂࡍࡗࡈࠤࡍ࡛ࡓࡕࡎࡈࡖࠥࡋࡕࡓࡑࡓࡉࠬࡹ") : return 241
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡃࡑࡒࡑࡊࡘࡁࡏࡉࠪࡺ") : return 192
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡄࡒ࡜ࠥࡔࡁࡕࡋࡒࡒࠬࡻ") : return 185
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡅࡖࡎ࡚ࡉࡔࡊࠣࡉ࡚ࡘࡏࡔࡒࡒࡖ࡙࠸ࠧࡼ") : return 173
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡆࡗࡏࡔࡊࡕࡋࠤࡊ࡛ࡒࡐࡕࡓࡓࡗ࡚ࠧࡽ") : return 182
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡈࡈࡓࠡࡔࡈࡅࡑࡏࡔ࡚ࠩࡾ") : return 190
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡉࡎࡃࡅࠪࡿ") : return 366
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡃࡏࡐࠪࢀ") : return 365
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡄࡃࡕࡘࡔࡕࡎࠡࡐࡈࡘ࡜ࡕࡒࡌࠢࡘࡏࠬࢁ") : return 186
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡅࡄࡖ࡙ࡕࡏࡏࡋࡗࡓࠬࢂ") : return 250
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡆࡌࡊࡒࡓࡆࡃࠣࡘ࡛࠭ࢃ") : return 179
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡇࡔࡓࡅࡅ࡛ࠣࡇࡊࡔࡔࡓࡃࡏࠤ࡚࡙ࡁࠨࢄ") : return 374
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡈࡕࡍࡆࡆ࡜ࠤࡈࡋࡎࡕࡔࡄࡐࠬࢅ") : return 251
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡉࡏࡎࡇࡇ࡝ࠥ࡞ࡔࡓࡃࠪࢆ") : return 176
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡃࡓࡋࡐࡉࠥࡏࡎࡗࡇࡖࡘࡎࡍࡁࡕࡋࡒࡒࠬࢇ") : return 249
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡅࡃ࡙ࡉࠬ࢈") : return 230
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡆࡌࡗࡈࡕࡖࡆࡔ࡜ࠤࡍࡏࡓࡕࡑࡕ࡝ࠬࢉ") : return 20
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡇࡍࡘࡉࡏࡗࡇࡕ࡝࡙ࠥࡃࡊࡇࡑࡇࡊ࠭ࢊ") : return 103
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡈࡎ࡙ࡃࡐࡘࡈࡖ࡞ࠦࡔࡖࡔࡅࡓࠬࢋ") : return 102
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡉࡏࡓࡄࡑ࡙ࡉࡗ࡟࠱ࠨࢌ") : return 98
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡊࡉࡔࡅࡒ࡚ࡊࡘ࡙ࠨࢍ") : return 370
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡄࡊࡕࡑࡉ࡞ࡉࡈࡏࡎࠪࢎ") : return 117
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡅࡋࡖࡒࡊ࡟ࡊࡖࡐࡌࡓࡗ࠭࢏") : return 118
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡇࡖࡔࡓࠦ࠲ࠨ࢐") : return 349
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡈࡗࡕࡔࠧ࢑") : return 348
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡉࡉࡋࡎࠡ࠭࠴ࠫ࢒") : return 278
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡊࡏࡒࠡࡕࡓࡓࡗ࡚ࡓࠨ࢓") : return 30
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡋࡕࡓࡑࡑࡉ࡜࡙ࠧ࢔") : return 398
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡆࡐ࡚ࠣࡗࡕࡕࡒࡕࡕࠣ࠵ࠬ࢕") : return 352
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡇࡑ࡛ࠤࡓࡋࡗࡔࠩ࢖") : return 274
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡉࡒࡐࡉࠦࡕࡌࠩࢗ") : return 277
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡋ࠶࡛ࠥࡋࠨ࢘") : return 271
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡌࡇࡕࠠࡆࡃࡖࡘ࢙ࠬ") : return 376
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡍࡈࡏࠡࡈࡄࡑࡎࡒ࡙ࠨ࢚") : return 377
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡎࡂࡐࠢࡖࡍࡌࡔࡁࡕࡗࡕࡉ࢛ࠬ") : return 378
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡈࡃࡑࠣ࡞ࡔࡔࡅࠨ࢜") : return 379
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡉࡉࡗ࡚ࠬ࢝") : return 384
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡊࡌࡗ࡙ࡕࡒ࡚ࠢࡘࡏࠬ࢞") : return 268
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡋࡍࡘ࡚ࡏࡓ࡛࡙ࠣࡘࡇࠧ࢟") : return 369
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡌࡔࡓࡅࠡ࠭࠴ࠫࢠ") : return 279
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡍࡕࡒࡓࡑࡕࠤࡈࡎࡁࡏࡐࡈࡐ࡛ࠥࡋࠨࢡ") : return 183
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡏࡄࠡࡗࡎࠫࢢ") : return 229
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡉࡕࡘࠣ࠶ࠬࢣ") : return 208
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡊࡖ࡙ࠤ࠸࠭ࢤ") : return 207
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡋࡗ࡚ࠥ࠺ࠧࢥ") : return 209
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡌࡘ࡛࠭ࢦ") : return 206
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡐࡋࡉࠠࡕࡘࠪࢧ") : return 180
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡒࡏࡏࠡࡕࡗࡅࡉࡏࡕࡎࠢ࠴࠴࠷ࠦࡈࡅࠩࢨ") : return 334
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡓࡉࡐࠢࡖࡘࡆࡊࡉࡖࡏࠣ࠵࠵࠹ࠠࡉࡆࠪࢩ") : return 335
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡍࡊࡑࠣࡗ࡙ࡇࡄࡊࡗࡐࠤ࠶࠶࠴ࠡࡊࡇࠫࢪ") : return 336
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡎࡋࡒࠤࡘ࡚ࡁࡅࡋࡘࡑࠥ࠷࠰࠶ࠢࡋࡈࠬࢫ") : return 337
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡏࡌࡓ࡙ࠥࡔࡂࡆࡌ࡙ࡒࠦ࠱࠱࠸ࠣࡌࡉ࠭ࢬ") : return 338
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡐࡍࡔࠦࡓࡕࡃࡇࡍ࡚ࡓࠠ࠲࠲࠺ࠤࡍࡊࠧࢭ") : return 333
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡑ࡙࡜ࠠࡃࡃࡖࡉࠬࢮ") : return 132
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡒ࡚ࡖࠡࡆࡄࡒࡈࡋࠧࢯ") : return 131
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡓࡔࡗࠢࡋࡍ࡙࡙ࠡࠨࢰ") : return 135
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡍࡕࡘࠣࡑ࡚࡙ࡉࡄࠩࢱ") : return 217
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡎࡖ࡙ࠤࡗࡕࡃࡌࡕࠪࢲ") : return 133
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡏࡘࡘ࡛࠭ࢳ") : return 106
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡐࡓ࡙ࡕࡒࡔࠢࡘࡏࠬࢴ") : return 215
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡒࡇࡇࠧࢵ") : return 283
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡓࡈࡃࠡࡇࡄࡗ࡙࠭ࢶ") : return 361
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡔࡉࡄࡍࠣࡘࡔࡕࡎࡔࠩࢷ") : return 296
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡎࡂࡖࠣࡋࡊࡕࠠࡘࡋࡏࡈ࡛ࠥࡋࠨࢸ") : return 269
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡏࡃࡗࡍࡔࡔࡁࡍࠢࡊࡉࡔࡍࡒࡂࡒࡋࡍࡈࠦࡕࡌࠩࢹ") : return 270
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡐࡄࡘࡎࡕࡎࡂࡎࠣࡋࡊࡕࡇࡓࡃࡓࡌࡎࡉࠠࡖࡕࡄࠫࢺ") : return 371
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡑࡍࡈࡑࠠࡋࡗࡑࡍࡔࡘࠧࢻ") : return 297
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡒࡎࡉࡋࠡࡗࡎࠫࢼ") : return 295
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡕࡘࡅࡎࡋࡈࡖࡘࡖࡏࡓࡖࡖࠫࢽ") : return 29
    if l111ll_opy_ == l11lll_opy_ (u"ࠬࡘࡔࡆࠢࡒࡒࡊ࠭ࢾ") : return 69
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡒࡕࡇࠣࡘ࡜ࡕ࡛ࡉࡆࡠࠫࢿ") : return 70
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡓࡖࡈࡎࡗ࠭ࣀ") : return 89
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡔࡄࡇࡎࡔࡇࠡࡗࡎࠫࣁ") : return 26
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡕࡉࡆࡒࠠࡍࡋ࡙ࡉࡘ࠭ࣂ") : return 275
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡗࡐ࡟ࠠࡃࡗࡑࡈࡊ࡙ࡌࡊࡉࡄࠤ࠶ࠦࡈࡅ࡝ࡇࡉࡢ࠭ࣃ") : return 408
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡘࡑ࡙ࠡࡐࡈ࡛ࡘ࠭ࣄ") : return 263
    if l111ll_opy_ == l11lll_opy_ (u"࡙ࠬࡋ࡚ࠢ࠴ࠫࣅ") : return 177
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡓࡌ࡛ࠣ࠶ࠬࣆ") : return 178
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡔࡍ࡜ࠤࡆࡉࡔࡊࡑࡑࠤࡒࡕࡖࡊࡇࡖࠫࣇ") : return 16
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡕࡎ࡝ࠥࡇࡔࡍࡃࡑࡘࡎࡉࠧࣈ") : return 174
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡖࡏ࡞ࠦࡃࡐࡏࡈࡈ࡞ࠦࡍࡐࡘࡌࡉࡘ࠭ࣉ") : return 34
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡗࡐ࡟ࠠࡅࡔࡄࡑࡆࡘࡏࡎࠢࡐࡓ࡛ࡏࡅࡔࠩ࣊") : return 97
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡘࡑ࡙ࠡࡈࡄࡑࡎࡒ࡙ࠡࡏࡒ࡚ࡎࡋࡓࠨ࣋") : return 36
    if l111ll_opy_ == l11lll_opy_ (u"࡙ࠬࡋ࡚ࠢࡊࡖࡊࡇࡔࡔࠢࡐࡓ࡛ࡏࡅࡔࠩ࣌") : return 37
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡓࡌ࡛ࠣࡑࡔ࡜ࡉࡆࡕࠣࡈࡎ࡙ࡎࡆ࡛ࠪ࣍") : return 220
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡔࡍ࡜ࠤࡕࡘࡅࡎࡋࡈࡖࡊࠦࡍࡐࡘࡌࡉࡘ࠭࣎") : return 40
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡕࡎ࡝࡙ࠥࡃࡇࡋࡋࡓࡗࡘࡏࡓࠢࡐࡓ࡛ࡏࡅࡔ࣏ࠩ") : return 41
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡖࡏ࡞ࠦࡓࡆࡎࡈࡇ࡙ࠦࡍࡐࡘࡌࡉࡘ࣐࠭") : return 42
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡗࡐ࡟ࠠࡔࡒࠣࡒࡊ࡝ࡓࠡࡊࡔ࣑ࠫ") : return 175
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡘࡑ࡙ࠡࡕࡓࡓࡗ࡚ࠠ࠲ࠢࡋࡈࠥ࠮ࡔࡆࡕࡗ࣒࠭ࠬ") : return 301
    if l111ll_opy_ == l11lll_opy_ (u"࡙ࠬࡋ࡚ࠢࡖࡔࡔࡘࡔࠡ࠴ࠣࡌࡉࠦࠨࡕࡇࡖࡘ࠮࣓࠭") : return 302
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡓࡌ࡛ࠣࡗࡕࡕࡒࡕࠢ࠶ࠤࡍࡊࠠࠩࡖࡈࡗ࡙࠯ࠧࣔ") : return 303
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡔࡍ࡜ࠤࡘࡖࡏࡓࡖࠣ࠸ࠥࡎࡄࠡࠪࡗࡉࡘ࡚ࠩࠨࣕ") : return 304
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡕࡎ࡝࡙ࠥࡐࡐࡔࡗࠤ࠺ࠦࡈࡅࠢࠫࡘࡊ࡙ࡔࠪࠩࣖ") : return 305
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡖࡏ࡞ࠦࡓࡑࡑࡕࡘࡘࠦ࠱ࠨࣗ") : return 95
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡗࡐ࡟ࠠࡔࡒࡒࡖ࡙࡙ࠠ࠳ࠩࣘ") : return 136
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡘࡑ࡙ࠡࡕࡓࡓࡗ࡚ࡓࠡ࠵ࠪࣙ") : return 43
    if l111ll_opy_ == l11lll_opy_ (u"࡙ࠬࡋ࡚ࠢࡖࡔࡔࡘࡔࡔࠢ࠷ࠫࣚ") : return 119
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡓࡌ࡛ࠣࡗࡕࡕࡒࡕࡕࠣ࠹ࠬࣛ") : return 120
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡔࡍ࡜ࠤ࡙ࡎࡒࡊࡎࡏࡉࡗࠦࡍࡐࡘࡌࡉࡘ࠭ࣜ") : return 96
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡕࡎ࡝ࠥࡒࡉࡗࡋࡑࡋࠬࣝ") : return 298
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡖࡔࡔࡘࡔࡔࠢࡉ࠵ࠬࣞ") : return 45
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡗ࡞ࡌ࡙ࠡࡗࡖࡅࠬࣟ") : return 383
    if l111ll_opy_ == l11lll_opy_ (u"࡙ࠫࡉࡍࠡ࠭࠴ࠤ࡚ࡑࠧ࣠") : return 189
    if l111ll_opy_ == l11lll_opy_ (u"࡚ࠬࡇ࠵ࠩ࣡") : return 88
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡔࡔࡐࠣ࠵ࠬ࣢") : return 339
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡕࡕࡑࠤ࠷ࣣ࠭") : return 340
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡖࡖࡒࠥ࠹ࠧࣤ") : return 341
    if l111ll_opy_ == l11lll_opy_ (u"ࠩࡗࡗࡓࠦ࠴ࠨࣥ") : return 342
    if l111ll_opy_ == l11lll_opy_ (u"ࠪࡘࡘࡔࠠ࠶ࣦࠩ") : return 343
    if l111ll_opy_ == l11lll_opy_ (u"࡙ࠫ࡜࠳ࠡࡋࡈࠫࣧ") : return 87
    if l111ll_opy_ == l11lll_opy_ (u"࡚ࠬࡒࡂࡘࡈࡐࠥࡉࡈࡂࡐࡑࡉࡑ࠱࠱ࠡࡗࡎࠫࣨ") : return 184
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡕࡔࡃࠣࡊࡔ࡞ࠠࡔࡒࡒࡖ࡙࡙ࣩࠧ") : return 347
    if l111ll_opy_ == l11lll_opy_ (u"ࠧࡖࡕࡄࠤࡓࡋࡔࡘࡑࡕࡏࠬ࣪") : return 344
    if l111ll_opy_ == l11lll_opy_ (u"ࠨࡗࡗ࡚ࠥࡏࡅࠨ࣫") : return 272
    if l111ll_opy_ == l11lll_opy_ (u"࡙ࠩࡍ࡛ࡇࠠࡕࡊࡈࠤࡍࡏࡔࡔࠣࠪ࣬") : return 130
    if l111ll_opy_ == l11lll_opy_ (u"࡚ࠪࡎࡇࡓࡂࡖࠣࡋࡔࡒࡆࠨ࣭") : return 125
    if l111ll_opy_ == l11lll_opy_ (u"ࠫ࡜ࡇࡔࡄࡊࠣࡍࡗࡋࡌࡂࡐࡇ࣮ࠫ") : return 281
    if l111ll_opy_ == l11lll_opy_ (u"ࠬ࡞ࡘ࡙࠳࣯ࠪ") : return 314
    if l111ll_opy_ == l11lll_opy_ (u"࠭ࡘ࡙࡚࠵ࣰࠫ") : return 315
    if l111ll_opy_ == l11lll_opy_ (u"࡙࡚࡛ࠧ࠷ࣱࠬ") : return 316
    if l111ll_opy_ == l11lll_opy_ (u"ࠨ࡚࡛࡜࠹ࣲ࠭") : return 317
    if l111ll_opy_ == l11lll_opy_ (u"࡛ࠩ࡜࡝࠻ࠧࣳ") : return 318
    if l111ll_opy_ == l11lll_opy_ (u"ࠪ࡝ࡊ࡙ࡔࡆࡔࡇࡅ࡞ࠦࠫ࠲ࠩࣴ") : return 282
    if l111ll_opy_ == l11lll_opy_ (u"ࠫࡒࡕࡖ࠵ࡏࡈࡒ࠶࠭ࣵ") : return 33
def getHDTVRecording(name, title, start, stream):
    l1lllll_opy_ = stream.split(l11lll_opy_ (u"ࠬࢂࣶࠧ"))
    for url in l1lllll_opy_:
        url   = url.split(CLOSE_OTT)[1].rsplit(l11lll_opy_ (u"࠭࠺ࠨࣷ"))
        l111l_opy_ = url[0]
        if l111l_opy_ == l11lll_opy_ (u"ࠧࡉࡆࡗ࡚ࠬࣸ"):
            addon = l11lll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴ࡯ࡤࡶࡹ࡮ࡵࡣࣹࠩ")
        else:
            addon = l11lll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࠸ࣺࠧ")
    dixie.log(l11lll_opy_ (u"ࠪࡅࡩࡪ࡯࡯ࠢࡌࡈ࠳࠴࠮࠻ࠢࠨࡷࠬࣻ") % addon)
    Addon  = xbmcaddon.Addon(id=addon)
    path   = Addon.getAddonInfo(l11lll_opy_ (u"ࠫࡵࡧࡴࡩࠩࣼ"))
    import sys
    sys.path.insert(0, path)
    import api
    l11ll_opy_ = Addon.getSetting(l11lll_opy_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳ࠭ࣽ"))
    l11ll1l_opy_  = Addon.getSetting(l11lll_opy_ (u"࠭ࡳࡦࡴࡹࡩࡷ࠭ࣾ"))
    l1l1ll1_opy_    = l11lll_opy_ (u"ࠧࠧࡦࡀ࡯ࡴࡪࡩࠧࡵࡀࠫࣿ") + l11ll_opy_ + l11lll_opy_ (u"ࠨࠨࡲࡁࠬऀ") + l11ll1l_opy_
    import urllib
    l1l1lll_opy_ = l11111_opy_()
    dixie.log(l11lll_opy_ (u"ࠩࡈࡔࡌࠦࡓࡵࡣࡵࡸ࡚ࠥࡩ࡮ࡧ࠱࠲࠳ࡀࠠࠦࡵࠪँ") % start)
    dixie.log(l11lll_opy_ (u"ࠪࡓ࡫࡬ࡳࡦࡶࠣ࡭ࡳࠦࡳࡦࡥࡲࡲࡩࡹ࠺ࠡࠧࡶࠫं") % l1l1lll_opy_)
    l11l1l1_opy_  =  start - datetime.timedelta(seconds=l1l1lll_opy_)
    dixie.log(l11lll_opy_ (u"ࠫࡘࡺࡡࡳࡶࠣࡘ࡮ࡳࡥࠡࡱࡩࡪࡸ࡫ࡴ࠻ࠢࠨࡷࠬः") % l11l1l1_opy_)
    l11_opy_ = str(l11l1l1_opy_)
    l111ll1_opy_  = l11_opy_.split(l11lll_opy_ (u"ࠬࠦࠧऄ"))[0]
    l1l11ll_opy_     = l11l111_opy_(name)
    if not l1l11ll_opy_:
        dixie.DialogOK(l11lll_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠳࠭अ"), l11lll_opy_ (u"ࠧࡘࡧࠣࡧࡴࡻ࡬ࡥࠢࡱࡳࡹࠦࡦࡪࡰࡧࠤࡦࠦࡣࡢࡶࡦ࡬ࡺࡶࠠࡴࡧࡵࡺ࡮ࡩࡥࠡࡨࡲࡶࠥࡺࡨࡪࡵࠣࡧ࡭ࡧ࡮࡯ࡧ࡯࠲ࠬआ"), l11lll_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡶࡵࡽࠥࡧ࡮ࡰࡶ࡫ࡩࡷࠦࡣࡩࡣࡱࡲࡪࡲ࠮ࠨइ"))
        return None
    l1ll111_opy_  = l11_opy_.split(l11lll_opy_ (u"ࠩ࠰ࠫई"), 1)[-1].rsplit(l11lll_opy_ (u"ࠪ࠾ࠬउ"), 1)[0]
    theTime    = urllib.quote_plus(l1ll111_opy_)
    response   = api.remote_call( l11lll_opy_ (u"ࠦࡹࡼࡡࡳࡥ࡫࡭ࡻ࡫࠯ࡨࡧࡷࡣࡧࡿ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡠࡣࡱࡨࡤࡪࡡࡵࡧ࠱ࡴ࡭ࡶࠢऊ") , {l11lll_opy_ (u"ࠧࡪࡡࡵࡧࠥऋ"): l111ll1_opy_, l11lll_opy_ (u"ࠨࡩࡥࠤऌ"): l1l11ll_opy_ } )
    l1ll11l_opy_ = response[l11lll_opy_ (u"ࠢࡣࡱࡧࡽࠧऍ")]
    if not l1ll11l_opy_:
        dixie.DialogOK(l11lll_opy_ (u"ࠨࡕࡲࡶࡷࡿ࠮ࠨऎ"), l11lll_opy_ (u"࡚ࠩࡩࠥࡩ࡯ࡶ࡮ࡧࠤࡳࡵࡴࠡࡨ࡬ࡲࡩࠦࡡࠡࡥࡤࡸࡨ࡮ࡵࡱࠢࡶࡸࡷ࡫ࡡ࡮ࠢࡩࡳࡷࠦࡴࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱ࠳࠭ए"), l11lll_opy_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡸࡷࡿࠠࡢࡩࡤ࡭ࡳࠦ࡬ࡢࡶࡨࡶ࠳࠭ऐ"))
        return None
    for l11ll11_opy_ in l1ll11l_opy_:
        l1l111_opy_ = l11ll11_opy_[l11lll_opy_ (u"ࠦࡵࡲ࡯ࡵࠤऑ")]
        if l1ll111_opy_ in l1l111_opy_:
            dixie.DialogOK(l11lll_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡵࡲࡢࡰࡪࡩࡢࡉࡡࡵࡥ࡫࠱ࡺࡶࠠࡴࡶࡵࡩࡦࡳࠠࡧࡱࡸࡲࡩ࠴࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨऒ"), l11lll_opy_ (u"࠭ࡏ࡯࠯ࡗࡥࡵࡶ࠮ࡕࡘࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡻࠥࡶ࡬ࡢࡻ࠽ࠤࡠࡉࡏࡍࡑࡕࠤࡴࡸࡡ࡯ࡩࡨࡡࡠࡈ࡝ࠦࡵ࡞࠳ࡇࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨओ") % (title))
            return l11ll11_opy_[l11lll_opy_ (u"ࠢࡶࡴ࡯ࠦऔ")] + l1l1ll1_opy_
def l11l111_opy_(name):
    l1ll11_opy_   = dixie.PROFILE
    l1l_opy_ = os.path.join(l1ll11_opy_, l11lll_opy_ (u"ࠨ࡫ࡱ࡭ࠬक"), l11lll_opy_ (u"ࠩࡦࡥࡹࡩࡨࡶࡲ࠱ࡸࡽࡺࠧख"))
    l111l11_opy_   = json.load(open(l1l_opy_))
    for channel in l111l11_opy_:
        if name.upper() == channel[l11lll_opy_ (u"ࠪࡓ࡙࡚ࡖࠨग")].upper():
            return channel[l11lll_opy_ (u"࡚ࠫࡘࡌࠨघ")]
def l11111_opy_():
    import time
    gmt = time.gmtime()
    loc = time.localtime()
    GMT = datetime.datetime(*gmt[:6]).isoformat(l11lll_opy_ (u"ࠬࠦࠧङ"))
    LOC = datetime.datetime(*loc[:6]).isoformat(l11lll_opy_ (u"࠭ࠠࠨच"))
    dixie.log(gmt)
    dixie.log(loc)
    l1_opy_ = dixie.parseTime(GMT)
    l11lll1_opy_ = dixie.parseTime(LOC)
    dixie.log(l1_opy_)
    dixie.log(l11lll1_opy_)
    dixie.log(l11lll_opy_ (u"ࠧࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࠤࡔࡌࡆࡔࡇࡗࠤࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࠩछ"))
    l1l1lll_opy_ = l1_opy_ - l11lll1_opy_
    dixie.log(l1l1lll_opy_)
    l1l1lll_opy_ = ((l1l1lll_opy_.days * 86400) + (l1l1lll_opy_.seconds + 1800)) / 3600
    dixie.log(l1l1lll_opy_)
    l1l1lll_opy_ *= -3600
    dixie.log(l1l1lll_opy_)
    dixie.log(l11lll_opy_ (u"ࠨࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡠࡡࠪज"))
    return l1l1lll_opy_