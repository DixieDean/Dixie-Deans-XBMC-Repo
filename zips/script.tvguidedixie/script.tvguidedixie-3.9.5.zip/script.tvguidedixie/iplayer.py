# coding: UTF-8
import sys
l11l111_opy_ = sys.version_info [0] == 2
l1ll1l1_opy_ = 2048
l1llll_opy_ = 7
def l111l1_opy_ (ll_opy_):
	global l11l_opy_
	l11l11l_opy_ = ord (ll_opy_ [-1])
	l1lll1l_opy_ = ll_opy_ [:-1]
	l1l11l1_opy_ = l11l11l_opy_ % len (l1lll1l_opy_)
	l1ll1_opy_ = l1lll1l_opy_ [:l1l11l1_opy_] + l1lll1l_opy_ [l1l11l1_opy_:]
	if l11l111_opy_:
		l1ll111_opy_ = unicode () .join ([unichr (ord (char) - l1ll1l1_opy_ - (l11l11_opy_ + l11l11l_opy_) % l1llll_opy_) for l11l11_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1ll111_opy_ = str () .join ([chr (ord (char) - l1ll1l1_opy_ - (l11l11_opy_ + l11l11l_opy_) % l1llll_opy_) for l11l11_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1ll111_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
ADDON    = dixie.ADDON
l11lll_opy_ = dixie.PROFILE
l1l111l_opy_  = os.path.join(l11lll_opy_, l111l1_opy_ (u"ࠫ࡮ࡴࡩࠨࠀ"))
l11l1ll_opy_ = l111l1_opy_ (u"ࠬ࠭ࠁ")
def l1111l1_opy_(i, t1, l11l1l1_opy_=[]):
 t = l11l1ll_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l11l1l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1l1l_opy_ = l1111l1_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l1l11_opy_ = l1111l1_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l111ll_opy_ = l111l1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰࡵࡸࡶࡹࡧࡹࠧࠂ")
l1llll1_opy_     = l111l1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡪࡪࡰࡻࡸࡻ࠸ࠧࠃ")
l11111_opy_ = l111l1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡱࡲࡸ࡮ࡶࡴࡷࠩࠄ")
l11llll_opy_  = l111l1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡇࡱࡨࡱ࡫ࡳࡴࠩࠅ")
l1l1ll1_opy_ = l111l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡉࡰࡦࡽ࡬ࡦࡵࡶࡘࡻ࠭ࠆ")
dexter   = l111l1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡨࡪࡾࠧࠇ")
l1111ll_opy_   = [l111ll_opy_, l1llll1_opy_, l11111_opy_, l11llll_opy_, l1l1ll1_opy_, dexter]
def checkAddons():
    for addon in l1111ll_opy_:
        if l111l1l_opy_(addon):
            createINI(addon)
def l111l1l_opy_(addon):
    if xbmc.getCondVisibility(l111l1_opy_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠦࡵࠬࠫࠈ") % addon) == 1:
        return True
    return False
def createINI(addon):
    HOME  = dixie.PROFILE
    l1l1l1_opy_ = os.path.join(HOME, l111l1_opy_ (u"࠭ࡩ࡯࡫ࠪࠉ"))
    l1l11ll_opy_  = str(addon).split(l111l1_opy_ (u"ࠧ࠯ࠩࠊ"))[2] + l111l1_opy_ (u"ࠨ࠰࡬ࡲ࡮࠭ࠋ")
    l1l_opy_   = os.path.join(l1l1l1_opy_, l1l11ll_opy_)
    response = l1_opy_(addon)
    l11lll1_opy_ = response[l111l1_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩࠌ")][l111l1_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩࠍ")]
    l1lllll_opy_  = l111l1_opy_ (u"ࠫࡠ࠭ࠎ") + addon + l111l1_opy_ (u"ࠬࡣ࡜࡯ࠩࠏ")
    l11ll1l_opy_  =  file(l1l_opy_, l111l1_opy_ (u"࠭ࡷࠨࠐ"))
    l11ll1l_opy_.write(l1lllll_opy_)
    l1l1ll_opy_ = []
    for channel in l11lll1_opy_:
        l111ll1_opy_ = l11_opy_(addon, channel)
        l1l1l1l_opy_ = l111ll1_opy_
        l1ll11_opy_ = l111lll_opy_(addon)
        l1lll_opy_  = dixie.mapChannelName(l111ll1_opy_)
        stream    = l1ll11_opy_ + l1l1l1l_opy_
        l11ll_opy_   = l1lll_opy_ + l111l1_opy_ (u"ࠧ࠾ࠩࠑ") + stream
        if l11ll_opy_ not in l1l1ll_opy_:
            l1l1ll_opy_.append(l11ll_opy_)
    l1l1ll_opy_.sort()
    for item in l1l1ll_opy_:
        l11ll1l_opy_.write(l111l1_opy_ (u"ࠣࠧࡶࡠࡳࠨࠒ") % item)
    l11ll1l_opy_.close()
def l11_opy_(addon, file):
    l11l1l_opy_ = file[l111l1_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨࠓ")].split(l111l1_opy_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࠔ"), 1)[0]
    l11l1l_opy_ = dixie.cleanLabel(l11l1l_opy_)
    return l11l1l_opy_
def l111lll_opy_(addon):
    if addon == l111ll_opy_:
        return l111l1_opy_ (u"ࠫࡎࡖࡔࡔ࠼ࠪࠕ")
    if addon == l1llll1_opy_:
        return l111l1_opy_ (u"ࠬࡐࡉࡏ࡚࠵࠾ࠬࠖ")
    if addon == l11111_opy_:
        return l111l1_opy_ (u"࠭ࡒࡐࡑࡗ࠾ࠬࠗ")
    if addon == l11llll_opy_:
        return l111l1_opy_ (u"ࠧࡆࡐࡇ࠾ࠬ࠘")
    if addon == l1l1ll1_opy_:
        return l111l1_opy_ (u"ࠨࡈࡏࡅ࠿࠭࠙")
    if addon == dexter:
        return l111l1_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪࠚ")
def getURL(url):
    if url.startswith(l111l1_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡅࡏ࡙࠿࠭ࠛ")):
        url = url.replace(l111l1_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡆࡐ࡚ࡀࠧࠜ"), l111l1_opy_ (u"ࠬ࠭ࠝ")).replace(l111l1_opy_ (u"࠭࠭࠮ࡷࡶࡩࡷ࠳ࡡࡨࡧࡱࡸࠬࠞ"), l111l1_opy_ (u"ࠧࡽࡷࡶࡩࡷ࠳ࡡࡨࡧࡱࡸࠬࠟ"))
        return url
    if url.startswith(l111l1_opy_ (u"ࠨࡋࡓࡘࡘ࠭ࠠ")):
        return l1ll_opy_(url, l111ll_opy_)
    if url.startswith(l111l1_opy_ (u"ࠩࡍࡍࡓ࡞࠲ࠨࠡ")):
        return l1ll_opy_(url, l1llll1_opy_)
    if url.startswith(l111l1_opy_ (u"ࠪࡖࡔࡕࡔࠨࠢ")):
        return l1ll_opy_(url, l11111_opy_)
    if url.startswith(l111l1_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡇࠫࠣ")):
        return l1ll_opy_(url, dexter)
    if url.startswith(l111l1_opy_ (u"ࠬࡌࡌࡂࠩࠤ")):
        return l1ll_opy_(url, l1l1ll1_opy_)
    if url.startswith(l111l1_opy_ (u"࠭ࡅࡏࡆࠪࠥ")):
        return l1ll_opy_(url, l11llll_opy_)
    response = l1l1_opy_(url)
    stream   = url.split(l111l1_opy_ (u"ࠧ࠻ࠩࠦ"), 1)[-1]
    try:
        result = response[l111l1_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨࠧ")]
        l1111_opy_  = result[l111l1_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨࠨ")]
    except Exception as e:
        l1l1111_opy_(e)
        return None
    for file in l1111_opy_:
        l11l1l_opy_ = file[l111l1_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࠩ")]
        if stream in l11l1l_opy_:
            return file[l111l1_opy_ (u"ࠫ࡫࡯࡬ࡦࠩࠪ")]
    return None
def l1ll_opy_(url, addon):
    PATH = l111_opy_(addon)
    try:
        response = json.load(open(PATH))
    except:
        response = l1_opy_(addon)
    l111l11_opy_      = url.split(l111l1_opy_ (u"ࠬࡀࠧࠫ"), 1)[-1]
    stream    = l111l11_opy_.split(l111l1_opy_ (u"࠭ࠠ࡜ࠩࠬ"), 1)[0]
    l1ll1ll_opy_ = dixie.cleanLabel(stream)
    l1111_opy_  = response[l111l1_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧ࠭")][l111l1_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧ࠮")]
    for file in l1111_opy_:
        l11l1l_opy_ = l11_opy_(addon, file)
        if l1ll1ll_opy_ in l11l1l_opy_:
            return file[l111l1_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧ࠯")]
def l1_opy_(addon):
    PATH = l111_opy_(addon)
    if addon == l11llll_opy_:
        query = l111l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡊࡴࡤ࡭ࡧࡶࡷ࠴ࡅࡡࡤࡶ࡬ࡳࡳࡃࡳࡵࡴࡨࡥࡲࡥࡶࡪࡦࡨࡳࠫ࡫ࡸࡵࡴࡤࠪࡵࡧࡧࡦࠨࡳࡰࡴࡺࠦࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡀࠪࡹ࡯ࡴ࡭ࡧࡀࡅࡱࡲࠦࡶࡴ࡯ࡁ࠵࠭࠰")
    if addon == l1l1ll1_opy_:
        query = l111l1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡌ࡬ࡢࡹ࡯ࡩࡸࡹࡔࡷ࠱ࡂࡥࡨࡺࡩࡰࡰࡀࡷࡹࡸࡥࡢ࡯ࡢࡺ࡮ࡪࡥࡰࠨࡨࡼࡹࡸࡡࠧࡲࡤ࡫ࡪࠬࡰ࡭ࡱࡷࠪࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠽ࠧࡶ࡬ࡸࡱ࡫࠽ࡂ࡮࡯ࠪࡺࡸ࡬࠾࠲ࠪ࠱")
    if addon == l111ll_opy_:
        query = l1ll1l_opy_(addon)
    if addon == l1llll1_opy_:
        query = l1ll1l_opy_(addon)
    if addon == l11111_opy_:
        query = l1ll1l_opy_(addon)
    if addon == dexter:
        query = l1ll1l_opy_(addon)
    try:
        return json.load(open(PATH))
    except:
        content = doJSON(query)
        return l1111l_opy_(PATH, addon, content)
def l1111l_opy_(PATH, addon, content):
    json.dump(content, open(PATH,l111l1_opy_ (u"ࠬࡽࠧ࠲")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    l11ll11_opy_  = (l111l1_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࠧࡶࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ࠳") % query)
    response = xbmc.executeJSONRPC(l11ll11_opy_)
    content  = json.loads(response)
    return content
def l111_opy_(addon):
    if addon == l111ll_opy_:
        return os.path.join(dixie.PROFILE, l111l1_opy_ (u"ࠧࡪࡲࡷࡷࡹࡳࡰࠨ࠴"))
    if addon == l1llll1_opy_:
        return os.path.join(dixie.PROFILE, l111l1_opy_ (u"ࠨ࡬࠵ࡸࡪࡳࡰࠨ࠵"))
    if addon == l11111_opy_:
        return os.path.join(dixie.PROFILE, l111l1_opy_ (u"ࠩࡵࡳࡹ࡫࡭ࡱࠩ࠶"))
    if addon == l11llll_opy_:
        return os.path.join(dixie.PROFILE, l111l1_opy_ (u"ࠪࡩࡹ࡫࡭ࡱࠩ࠷"))
    if addon == l1l1ll1_opy_:
        return os.path.join(dixie.PROFILE, l111l1_opy_ (u"ࠫ࡫ࡺࡥ࡮ࡲࠪ࠸"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l111l1_opy_ (u"ࠬࡪࡴࡦ࡯ࡳࠫ࠹"))
def l1ll1l_opy_(addon):
    if addon == l111ll_opy_:
        query = l111l1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲࡷࡺࡸࡻࡢࡴࠩ࠺")
        response = doJSON(query)
        l1111_opy_    = response[l111l1_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧ࠻")][l111l1_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧ࠼")]
        for file in l1111_opy_:
            l1l1lll_opy_ = file[l111l1_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨ࠽")]
            l11l1l_opy_ = dixie.cleanLabel(l1l1lll_opy_)
            if l11l1l_opy_ == l111l1_opy_ (u"ࠪࡐ࡮ࡼࡥࠡࡖ࡙ࠫ࠾"):
                livetv = file[l111l1_opy_ (u"ࠫ࡫࡯࡬ࡦࠩ࠿")]
                return l1l11l_opy_(livetv)
    if addon == l1llll1_opy_:
        query = l111l1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡪࡪࡰࡻࡸࡻ࠸ࠧࡀ")
        response = doJSON(query)
        l1111_opy_    = response[l111l1_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࡁ")][l111l1_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࡂ")]
        for file in l1111_opy_:
            l1l1lll_opy_ = file[l111l1_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࡃ")]
            l11l1l_opy_ = dixie.cleanLabel(l1l1lll_opy_)
            if l11l1l_opy_ == l111l1_opy_ (u"ࠩࡏ࡭ࡻ࡫ࠠࡕࡘࠪࡄ"):
                livetv = file[l111l1_opy_ (u"ࠪࡪ࡮ࡲࡥࠨࡅ")]
                return l1l11l_opy_(livetv)
    if addon == l11111_opy_:
        query = l111l1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸ࡯ࡰࡶ࡬ࡴࡹࡼࠧࡆ")
        response = doJSON(query)
        l1111_opy_    = response[l111l1_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬࡇ")][l111l1_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬࡈ")]
        for file in l1111_opy_:
            l1l1lll_opy_ = file[l111l1_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ࡉ")]
            l11l1l_opy_ = dixie.cleanLabel(l1l1lll_opy_)
            if l11l1l_opy_ == l111l1_opy_ (u"ࠨࡎ࡬ࡺࡪࠦࡔࡗࠩࡊ"):
                livetv = file[l111l1_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧࡋ")]
                return l1l11l_opy_(livetv)
    if addon == dexter:
        query = l111l1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸࠨࡌ")
        response = doJSON(query)
        l1111_opy_    = response[l111l1_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫࡍ")][l111l1_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫࡎ")]
        for file in l1111_opy_:
            l1l1lll_opy_ = file[l111l1_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬࡏ")]
            l11l1l_opy_ = dixie.cleanLabel(l1l1lll_opy_)
            if l11l1l_opy_ == l111l1_opy_ (u"ࠧࡍ࡫ࡹࡩ࡚ࠥࡶࠨࡐ"):
                livetv = file[l111l1_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ࡑ")]
                return l1l11l_opy_(livetv)
def l1l11l_opy_(livetv):
    response = doJSON(livetv)
    l1111_opy_    = response[l111l1_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩࡒ")][l111l1_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩࡓ")]
    for file in l1111_opy_:
        l1l1lll_opy_ = file[l111l1_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪࡔ")]
        l11l1l_opy_ = dixie.cleanLabel(l1l1lll_opy_)
        if l11l1l_opy_ == l111l1_opy_ (u"ࠬࡇ࡬࡭ࠩࡕ"):
            return file[l111l1_opy_ (u"࠭ࡦࡪ࡮ࡨࠫࡖ")]
def l1lll11_opy_(l1ll11l_opy_):
    items = []
    _1l1l11_opy_(l1ll11l_opy_, items)
    dixie.log(l111l1_opy_ (u"ࠧ࠾࠿ࡀࡁࠥ࡯ࡴࡦ࡯ࡶࠤࡂࡃ࠽࠾ࠩࡗ"))
    dixie.log(items)
    return items
def _1l1l11_opy_(l1ll11l_opy_, items):
    response = doJSON(l1ll11l_opy_)
    dixie.log(l111l1_opy_ (u"ࠨ࠿ࡀࡁࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࡀࡁࡂ࠭ࡘ"))
    dixie.log(response)
    if response[l111l1_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵ࡙ࠩ")].has_key(l111l1_opy_ (u"ࠪࡪ࡮ࡲࡥࡴ࡚ࠩ")):
        result = response[l111l1_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷ࡛ࠫ")][l111l1_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫ࡜")]
        for item in result:
            if item[l111l1_opy_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ࡝")] == l111l1_opy_ (u"ࠧࡧ࡫࡯ࡩࠬ࡞"):
                dixie.log(l111l1_opy_ (u"ࠨ࠿ࡀࡁࡂࠦࡦࡪ࡮ࡨࠤࡂࡃ࠽࠾ࠩ࡟"))
                l11l1l_opy_ = dixie.cleanLabel(item[l111l1_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨࡠ")])
                dixie.log(l11l1l_opy_)
                items.append(item)
            elif item[l111l1_opy_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬࡡ")] == l111l1_opy_ (u"ࠫࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠧࡢ"):
                dixie.log(l111l1_opy_ (u"ࠬࡃ࠽࠾࠿ࠣࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠦ࠽࠾࠿ࡀࠫࡣ"))
                l11l1l_opy_ = dixie.cleanLabel(item[l111l1_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬࡤ")])
                dixie.log(l11l1l_opy_)
                l1lll1_opy_  = item[l111l1_opy_ (u"ࠧࡧ࡫࡯ࡩࠬࡥ")]
                dixie.log(item)
                dixie.log(l1lll1_opy_)
                _1l1l11_opy_(l1lll1_opy_, items)
def l1l1_opy_(url):
    if url.startswith(l111l1_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠺ࠨࡦ")):
        l11ll11_opy_ = (l111l1_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡨࡢࡤ࡫ࡳࡰࡦࡿࡥࡳ࠱ࡂࡹࡷࡲ࠽ࡶࡴ࡯ࠪࡲࡵࡤࡦ࠿࠵ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡻ࡫ࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠩࡍࡕࡏࡄ࠾ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࡧ"))
    if url.startswith(l111l1_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠴࠽ࠫࡨ")):
        l11ll11_opy_ = (l111l1_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺ࠳ࡄࡻࡲ࡭࠿ࡸࡶࡱࠬ࡭ࡰࡦࡨࡁ࠶࠶࠱ࠧࡰࡤࡱࡪࡃࡗࡢࡶࡦ࡬࠰ࡒࡩࡷࡧࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࡂࠬࡳࡶࡤࡷ࡭ࡹࡲࡥࡴࡡࡸࡶࡱࡃࠦ࡭ࡱࡪ࡫ࡪࡪ࡟ࡪࡰࡀࡊࡦࡲࡳࡦࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࡩ"))
    if url.startswith(l111l1_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖ࠿࠭ࡪ")):
        l11ll11_opy_ = (l111l1_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠵࠿ࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠫࡲ࡯ࡨࡩࡨࡨࡤ࡯࡮࠾ࡈࡤࡰࡸ࡫ࠦ࡮ࡱࡧࡩࡂ࠷࠱࠴ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡶࡸࡪࡴࠥ࠳࠲ࡏ࡭ࡻ࡫ࠦࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡵࡢࡹࡷࡲࠦࡶࡴ࡯ࡁࡺࡸ࡬ࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭࡫"))
    if url.startswith(l111l1_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡏࡔࡗ࠼ࠪ࡬")):
        l11ll11_opy_ = (l111l1_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡺࡶࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭࡭"))
    if url.startswith(l111l1_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪ࡮")):
        l11ll11_opy_ = (l111l1_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡤࡦࡺ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡦࡲ࡬ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠦࡵ࡫ࡷࡰࡪࡃࠥ࠶ࡤࡆࡓࡑࡕࡒࠦ࠴࠳ࡻ࡭࡯ࡴࡦࠧ࠸ࡨࡆࡲ࡬ࠦ࠴࠳ࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠪ࠻ࡢࠦ࠴ࡩࡇࡔࡒࡏࡓࠧ࠸ࡨࠫࡻࡲ࡭ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧ࡯"))
    if url.startswith(l111l1_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡕࡆ࠿࠭ࡰ")):
        l11ll11_opy_ = (l111l1_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡨࡦࡴࡵࡴ࠰ࡁࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠦࡧࡣࡱࡥࡷࡺ࠽ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡳ࡯ࡥࡧࡀ࠻ࠫࡶࡩ࡭࡮ࡲࡻࡂࡒࡩࡷࡧࠨ࠶࠵࡙ࡴࡳࡧࡤࡱࡸࠬࡵࡳ࡮ࡀࡶࡦࡴࡤࡰ࡯ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨࡱ"))
    try:
        dixie.ShowBusy()
        addon =  l11ll11_opy_.split(l111l1_opy_ (u"࠭࠯࠰ࠩࡲ"), 1)[-1].split(l111l1_opy_ (u"ࠧ࠰ࠩࡳ"), 1)[0]
        login = l111l1_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ࡴ") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l11ll11_opy_)
        dixie.log(response)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1l1111_opy_(e)
        return {l111l1_opy_ (u"ࠩࡈࡶࡷࡵࡲࠨࡵ") : l111l1_opy_ (u"ࠪࡔࡱࡻࡧࡪࡰࠣࡉࡷࡸ࡯ࡳࠩࡶ")}
def l111l_opy_():
    modules = map(__import__, [l1111l1_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1l1l_opy_)):
        return l111l1_opy_ (u"࡙ࠫࡸࡵࡦࠩࡷ")
    if len(modules[-1].Window(10**4).getProperty(l1l11_opy_)):
        return l111l1_opy_ (u"࡚ࠬࡲࡶࡧࠪࡸ")
    return l111l1_opy_ (u"࠭ࡆࡢ࡮ࡶࡩࠬࡹ")
def l1l1111_opy_(e):
    l11ll1_opy_ = l111l1_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠲ࠠࡢࡰࠣࡩࡷࡸ࡯ࡳࠢࡲࡧࡨࡻࡲࡦࡦ࠽ࠤࡏ࡙ࡏࡏࠢࡈࡶࡷࡵࡲ࠻ࠢࠨࡷࠬࡺ")  %e
    l11l1_opy_ = l111l1_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡴࡨ࠱ࡱ࡯࡮࡬ࠢࡷ࡬࡮ࡹࠠࡤࡪࡤࡲࡳ࡫࡬ࠡࡣࡱࡨࠥࡺࡲࡺࠢࡤ࡫ࡦ࡯࡮࠯ࠩࡻ")
    l1l111_opy_ = l111l1_opy_ (u"ࠩࡘࡷࡪࡀࠠࡄࡱࡱࡸࡪࡾࡴࠡࡏࡨࡲࡺࠦ࠽࠿ࠢࡕࡩࡲࡵࡶࡦࠢࡖࡸࡷ࡫ࡡ࡮ࠩࡼ")
    dixie.log(e)
    dixie.DialogOK(l11ll1_opy_, l11l1_opy_, l1l111_opy_)
if __name__ == l111l1_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬࡽ"):
    checkAddons()