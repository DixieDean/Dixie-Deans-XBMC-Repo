# coding: UTF-8
import sys
l1l11ll1_opy_ = sys.version_info [0] == 2
l11111l_opy_ = 2048
l1ll111l_opy_ = 7
def l1l1l_opy_ (l11ll1_opy_):
	global l1111ll_opy_
	l1lll1ll_opy_ = ord (l11ll1_opy_ [-1])
	l1l1l11l_opy_ = l11ll1_opy_ [:-1]
	l11ll11_opy_ = l1lll1ll_opy_ % len (l1l1l11l_opy_)
	l111l1_opy_ = l1l1l11l_opy_ [:l11ll11_opy_] + l1l1l11l_opy_ [l11ll11_opy_:]
	if l1l11ll1_opy_:
		l1llll_opy_ = unicode () .join ([unichr (ord (char) - l11111l_opy_ - (l1lll_opy_ + l1lll1ll_opy_) % l1ll111l_opy_) for l1lll_opy_, char in enumerate (l111l1_opy_)])
	else:
		l1llll_opy_ = str () .join ([chr (ord (char) - l11111l_opy_ - (l1lll_opy_ + l1lll1ll_opy_) % l1ll111l_opy_) for l1lll_opy_, char in enumerate (l111l1_opy_)])
	return eval (l1llll_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
import mapping
ADDON    = dixie.ADDON
l1l1ll1l_opy_ = dixie.PROFILE
l1lllll1_opy_  = os.path.join(l1l1ll1l_opy_, l1l1l_opy_ (u"ࠨ࡫ࡱ࡭ࠬइ"))
l11ll1ll_opy_ = os.path.join(l1lllll1_opy_, l1l1l_opy_ (u"ࠩࡳࡶࡪ࡬ࡩࡹࡧࡶ࠲࡯ࡹ࡯࡯ࠩई"))
l111_opy_   = json.load(open(l11ll1ll_opy_))
l1l11ll_opy_ = l1l1l_opy_ (u"ࠪࠫउ")
def l11lll_opy_(i, t1, l1l11l_opy_=[]):
 t = l1l11ll_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l11l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11_opy_ = l11lll_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11l1l_opy_ = l11lll_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1l1l11_opy_       = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡨ࡫ࡴࡷࠩऊ")
l1l111ll_opy_  = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡇࡲࡡࡤ࡭ࡌࡧࡪ࡚ࡖࠨऋ")
dexter    = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡪࡥࡹࠩऌ")
l1ll11_opy_   = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡅ࡯ࡦ࡯ࡩࡸࡹࠧऍ")
l1ll1l_opy_       = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡧࡣࡥ࡬ࡴࡹࡴࡪࡰࡪࠫऎ")
l1l11111_opy_  = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡨࡵࡩࡪࡼࡩࡦࡹࠪए")
l1l1ll_opy_    = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡪࡩ࡭ࡵࡳࡵ࡫ࡱ࡫ࠬऐ")
l11lll1_opy_   = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡬ࡴࡸࡩࡻࡱࡱ࡭ࡵࡺࡶࠨऑ")
l1ll1_opy_  = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶࡴࡷࡵࡸࡦࡸ࠭ऒ")
l111l1l_opy_      = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡰࡩ࡯ࡺࡷࡺ࠷࠭ओ")
l1l111l1_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡌࡪ࡯࡬ࡸࡱ࡫ࡳࡴࡋࡓࡘ࡛࠭औ")
l11ll11l_opy_    = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡍ࡫ࡰ࡭ࡹࡲࡥࡴࡵ࡙࠷ࠬक")
l11l_opy_  = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡯ࡤࡸࡷ࡯ࡸࡪࡴࡨࡰࡦࡴࡤࠨख")
l1ll1l1l_opy_  = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡐࡥࡹࡹࡂࡶ࡫࡯ࡨࡸࡏࡐࡕࡘࠪग")
l11llll1_opy_   = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡱࡦࡾࡩࡸࡧࡥࡸࡻ࠭घ")
l111ll1_opy_     = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡲࡩ࡫ࡵࡸ࠰ࡴࡱࡻࡳࠨङ")
l1lllll_opy_      = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡳࡥࡨࡣ࡬ࡴࡹࡼࠧच")
l1_opy_     = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡎࡢࡶ࡫ࡳ࠳ࡏࡐࡕࡘࠪछ")
l1l111_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡯ࡣࡷ࡬ࡴࡧ࡮ࡰࡸࡤࠫज")
nice      = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡰࡤࡸ࡭ࡵࡳࡶࡤࡶ࡭ࡨ࡫ࠧझ")
l11ll_opy_   = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡳࡶࡪࡳࡩࡶ࡯࡬ࡴࡹࡼࠧञ")
l11lllll_opy_  = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡴࡸࡧࡤࡥࡱࡱࠫट")
root      = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡵ࡯ࡵࡋࡓࡘ࡛࠭ठ")
l1l1l111_opy_     = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡭ࡩࡻ࡯ࡲࡸࡻ࠭ड")
l1l11l1_opy_    = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡧࡪࡼࡰࡳࡸࡶ࡯ࡳࡶࡶࠫढ")
l1ll1l1_opy_      = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡥࡷࡺࠬण")
l1llll1l_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡕࡸࡴࡷ࡫࡭ࡢࡥࡼࡘ࡛࠭त")
l1ll1ll1_opy_   = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡸࡷ࡫ࡡ࡮ࡵࡸࡴࡷ࡫࡭ࡦ࠴ࠪथ")
l1llll11_opy_   = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡸࡼ࡯ࡳࡵࡧࡧࡸࡻ࠭द")
l11l111_opy_   = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡹࡼ࡫ࡪࡰࡪࡷࠬध")
l11l1l1_opy_    = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡻ࡫ࡵࡷࡵ࡯ࠬन")
l1l_opy_     = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡖࡂࡆࡈࡖࠬऩ")
l1lll11l_opy_     = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡗࡋࡓࡗࡺࡶࡥࡳࡕࡷࡶࡪࡧ࡭ࡴࡖ࡙ࠫप")
l1ll11l1_opy_   = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡺࡷࡶࡪࡧ࡭࠮ࡥࡲࡨࡪࡹࠧफ")
l1lll111_opy_    = [l1l111_opy_, l1lll11l_opy_, l11ll11l_opy_, l1_opy_, nice, l11ll_opy_, l1l1l111_opy_, l1l11l1_opy_, l1l1ll_opy_, l11l111_opy_, l11l_opy_, l1ll11l1_opy_, l1ll1l1_opy_, l1ll1ll1_opy_, l11l1l1_opy_, l1l111l1_opy_, l1ll1l_opy_, l1l1l11_opy_, l11lll1_opy_, root, l1lllll_opy_, l1l11111_opy_, l1ll1_opy_, l111l1l_opy_, l1ll11_opy_, l11llll1_opy_, dexter, l1l_opy_, l1llll1l_opy_, l111ll1_opy_, l1llll11_opy_, l11lllll_opy_, l1l111ll_opy_]
def l1111_opy_(addon, l11l11_opy_):
    if (addon == l1l111_opy_) or (addon == l1lll11l_opy_) or (addon == l1llll11_opy_) or (addon == l11ll11l_opy_) or (addon == l1_opy_) or (addon == nice) or (addon == l11ll_opy_) or (addon == l1l1l111_opy_) or (addon == l1l11l1_opy_) or (addon == root) or (addon == l1l111l1_opy_) or (addon == l1ll1l_opy_) or (addon == l1ll11l1_opy_) or (addon == l11l_opy_) or (addon == l11l111_opy_) or (addon == l1l1ll_opy_):
        l1l1111_opy_ = mapping.cleanLabel(l11l11_opy_)
        l1lll1_opy_ = mapping.editPrefix(l111_opy_, l1l1111_opy_)
        return l1lll1_opy_
    l1l1111_opy_ = mapping.cleanLabel(l11l11_opy_)
    l1lll1_opy_ = mapping.cleanStreamLabel(l1l1111_opy_)
    return l1lll1_opy_
def l1lll1l1_opy_(addon, l111_opy_, labelmaps, l1l1llll_opy_, l1l1l1l1_opy_, l11l11_opy_):
    if (addon == l1l111_opy_) or (addon == l1lll11l_opy_) or (addon == l1llll11_opy_) or (addon == l11ll11l_opy_) or (addon == l1_opy_) or (addon == nice) or (addon == l11ll_opy_) or (addon == l1l1l111_opy_) or (addon == l1l11l1_opy_) or (addon == root) or (addon == l1l111l1_opy_) or (addon == l1ll1l_opy_) or (addon == l1ll11l1_opy_) or (addon == l11l_opy_) or (addon == l11l111_opy_) or (addon == l1l1ll_opy_):
        return l1l1111l_opy_(l111_opy_, l1l1l1l1_opy_, l11l11_opy_)
    l1ll1ll_opy_    = mapping.cleanLabel(l11l11_opy_)
    l1l1111_opy_ = mapping.mapLabel(labelmaps, l1ll1ll_opy_)
    l111ll_opy_ = mapping.cleanPrefix(l1l1111_opy_)
    return mapping.mapChannelName(l1l1llll_opy_, l111ll_opy_)
def l1l1111l_opy_(l111_opy_, l1l1l1l1_opy_, l11l11_opy_):
    l1l1_opy_ = mapping.cleanLabel(l11l11_opy_)
    l1l1111_opy_   = mapping.editPrefix(l111_opy_, l1l1_opy_)
    l1111l1_opy_   = mapping.mapEPGLabel(l111_opy_, l1l1l1l1_opy_, l1l1111_opy_)
    return l1111l1_opy_
def l1ll_opy_(addon, file):
    l1ll1ll_opy_ = file[l1l1l_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩब")].split(l1l1l_opy_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭भ"), 1)[0]
    l1ll1ll_opy_ = l1ll1ll_opy_.split(l1l1l_opy_ (u"ࠬ࠱ࠧम"), 1)[0]
    l1ll1ll_opy_ = mapping.cleanLabel(l1ll1ll_opy_)
    return l1ll1ll_opy_
def getURL(url):
    if url.startswith(l1l1l_opy_ (u"࠭ࡁࡏࡑ࡙ࡅࠬय")):
        return ll_opy_(url, l1l111_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡗࡋࡓࡗࡘ࠭र")):
        return ll_opy_(url, l1lll11l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡎࡌࡑ࠷࠭ऱ")):
        return ll_opy_(url, l11ll11l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡑࡅ࡙ࡎࠧल")):
        return ll_opy_(url, l1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡒࡎࡉࡅࠨळ")):
        return ll_opy_(url, nice)
    if url.startswith(l1l1l_opy_ (u"ࠫࡕࡘࡅࡎࠩऴ")):
        return ll_opy_(url, l11ll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡍࡉ࡛ࠩव")):
        return ll_opy_(url, l1l1l111_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡇࡔࡒࡕࡘࡘ࠭श")):
        return ll_opy_(url, l1l11l1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡈࡇࡋࠫष")):
        return ll_opy_(url, l1l1ll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡖ࡙ࡏࠬस")):
        return ll_opy_(url, l11l111_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡐࡘ࡝ࡏࡅࠨह")):
        return ll_opy_(url, l11l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪ࡜࡙ࡉࠧऺ")):
        return ll_opy_(url, l1ll11l1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡘࡉࡔࡗࠩऻ")):
        return ll_opy_(url, l1ll1l1_opy_)
    if url.startswith(l1l1l_opy_ (u"࡙ࠬࡕࡑ़ࠩ")):
        return ll_opy_(url, l1ll1ll1_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡕࡌࡖࠪऽ")):
        return ll_opy_(url, l11l1l1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡍࡋࡐࡍ࡙࠭ा")):
        return ll_opy_(url, l1l111l1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡈࡄࡆࠬि")):
        return ll_opy_(url, l1ll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡄࡇࡊ࠭ी")):
        return ll_opy_(url, l1l1l11_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡌࡔࡘࡉ࡛ࠩु")):
        return ll_opy_(url, l11lll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡗࡕࡏࡕ࠴ࠪू")):
        return ll_opy_(url, root)
    if url.startswith(l1l1l_opy_ (u"ࠬࡓࡅࡈࡃࠪृ")):
        return ll_opy_(url, l1lllll_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡆࡓࡇࡈࠫॄ")):
        return ll_opy_(url, l1l11111_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡉࡌࡖ࠼ࠪॅ")):
        url = url.replace(l1l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡃࡍࡗ࠽ࠫॆ"), l1l1l_opy_ (u"ࠩࠪे")).replace(l1l1l_opy_ (u"ࠪ࠱࠲ࡻࡳࡦࡴ࠰ࡥ࡬࡫࡮ࡵࠩै"), l1l1l_opy_ (u"ࠫࢁࡻࡳࡦࡴ࠰ࡥ࡬࡫࡮ࡵࠩॉ"))
        return url
    if url.startswith(l1l1l_opy_ (u"ࠬࡓࡁࡕࡕࠪॊ")):
        return ll_opy_(url, l1ll1l1l_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡉࡑࡖࡖࠫो")):
        return ll_opy_(url, l1ll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡋࡋࡑ࡜࠷࠭ौ")):
        return ll_opy_(url, l111l1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡄࠨ्")):
        return ll_opy_(url, dexter)
    if url.startswith(l1l1l_opy_ (u"ࠩࡐࡅ࡝ࡏࠧॎ")):
        return ll_opy_(url, l11llll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡉࡓࡊࠧॏ")):
        return ll_opy_(url, l1ll11_opy_)
    if url.startswith(l1l1l_opy_ (u"࡛ࠫࡊࡒࡕࡘࠪॐ")):
        return ll_opy_(url, l1l_opy_)
    if url.startswith(l1l1l_opy_ (u"࡙ࠬࡐࡓࡏࠪ॑")):
        return ll_opy_(url, l1llll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡍࡄࡍࡗ࡚॒ࠬ")):
        return ll_opy_(url, l111ll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡕ࡙ࡌࡗ࡙࠭॓")):
        return ll_opy_(url, l1llll11_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡒࡕࡉࡘ࡚ࠧ॔")):
        return ll_opy_(url, l11lllll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡅࡐࡐࡏࠧॕ")):
        return ll_opy_(url, l1l111ll_opy_)
    response  = l11ll111_opy_(url)
    l1ll111_opy_ = url.split(l1l1l_opy_ (u"ࠪ࠾ࠬॖ"), 1)[-1]
    l1ll111_opy_ = l1ll111_opy_.upper().replace(l1l1l_opy_ (u"ࠫࠥ࠭ॗ"), l1l1l_opy_ (u"ࠬ࠭क़"))
    try:
        result = response[l1l1l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ख़")]
        l111l11_opy_  = result[l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ग़")]
    except Exception as e:
        l11lll1l_opy_(e)
        return None
    for file in l111l11_opy_:
        l11l11_opy_  = file[l1l1l_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧज़")].split(l1l1l_opy_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫड़"), 1)[0]
        l1l1lll_opy_  = l11l11_opy_.split(l1l1l_opy_ (u"ࠪ࠯ࠬढ़"), 1)[0]
        l1l1ll1_opy_ = mapping.cleanLabel(l1l1lll_opy_)
        l1l1ll1_opy_ = l1l1ll1_opy_.upper().replace(l1l1l_opy_ (u"ࠫࠥ࠭फ़"), l1l1l_opy_ (u"ࠬ࠭य़"))
        try:
            if l1ll111_opy_ == l1l1ll1_opy_:
                return file[l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࠫॠ")]
        except:
            if (l1ll111_opy_ in l1l1ll1_opy_) or (l1l1ll1_opy_ in l1ll111_opy_):
                return file[l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࠬॡ")]
    return None
def ll_opy_(url, addon):
    PATH = l1ll1l11_opy_(addon)
    try:
        response = json.load(open(PATH))
    except:
        pass
    l1l11l1l_opy_      = url.split(l1l1l_opy_ (u"ࠨ࠼ࠪॢ"), 1)[-1]
    stream    = l1l11l1l_opy_.split(l1l1l_opy_ (u"ࠩࠣ࡟ࠬॣ"), 1)[0]
    l1ll111_opy_ = mapping.cleanLabel(stream)
    l1ll111_opy_ = l1ll111_opy_.upper().replace(l1l1l_opy_ (u"ࠪࠤࠬ।"), l1l1l_opy_ (u"ࠫࠬ॥"))
    if (addon == l1l_opy_) or (addon == l1ll1ll1_opy_):
        l111l11_opy_ = response
    else:
        l111l11_opy_ = response[l1l1l_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬ०")][l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬ१")]
    for file in l111l11_opy_:
        l11l11_opy_  = file[l1l1l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭२")].split(l1l1l_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ३"), 1)[0]
        if addon == dexter:
            l11l11_opy_ = l11l11_opy_.split(l1l1l_opy_ (u"ࠩࠣ࠯ࠥ࠭४"), 1)[0]
        if (addon == l1l111_opy_) or (addon == l1lll11l_opy_) or (addon == l1llll11_opy_) or (addon == l11ll11l_opy_) or (addon == l1_opy_) or (addon == nice) or (addon == l1l1l111_opy_) or (addon == l1l11l1_opy_) or (addon == root) or (addon == l1l111l1_opy_) or (addon == l11l111_opy_) or (addon == l1l1ll_opy_):
            l11l11_opy_ = l11l11_opy_.split(l1l1l_opy_ (u"ࠪࠤ࠲ࠦࠧ५"), 1)[0]
        l1l1ll1_opy_ = l1111_opy_(addon, l11l11_opy_)
        l1l1ll1_opy_ = l1l1ll1_opy_.upper().replace(l1l1l_opy_ (u"ࠫࠥ࠭६"), l1l1l_opy_ (u"ࠬ࠭७"))
        try:
            if l1ll111_opy_ == l1l1ll1_opy_:
                return file[l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࠫ८")]
        except:
            if (l1ll111_opy_ in l1l1ll1_opy_) or (l1l1ll1_opy_ in l1ll111_opy_):
                return file[l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࠬ९")]
    return None
def l1l11_opy_(PATH, addon, content):
    json.dump(content, open(PATH,l1l1l_opy_ (u"ࠨࡹࠪ॰")), indent=3)
    return json.load(open(PATH))
def doJSON(query, addon=l1l1l_opy_ (u"ࠩࠪॱ")):
    if (addon == l1l_opy_) or (addon == l1ll1ll1_opy_):
        l111lll_opy_     = l1l1l_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ॲ") % query
        l111l_opy_  = xbmc.executeJSONRPC(l111lll_opy_)
        response = json.loads(l111l_opy_)
        result   = response[l1l1l_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫॳ")]
        return result[l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫॴ")]
    l1l1l1l_opy_  = (l1l1l_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࠧࡶࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩॵ") % query)
    response = xbmc.executeJSONRPC(l1l1l1l_opy_)
    content  = json.loads(response)
    return content
def l1ll1l11_opy_(addon):
    if addon == l1l111_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡢࡰࡲࡺࡦࡺࡥ࡮ࡲࠪॶ"))
    if addon == l1lll11l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡸ࡬ࡴࡸࡹࡴࡦ࡯ࡳࠫॷ"))
    if addon == l1lll11l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡹ࡭ࡵࡹࡳࡵࡧࡰࡴࠬॸ"))
    if addon == l11ll11l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡰ࡮ࡳ࠲ࡵࡧࡰࡴࠬॹ"))
    if addon == l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡳࡧࡴࡩࡱࡷࡩࡲࡶࠧॺ"))
    if addon == nice:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡴࡩࡤࡧࡷࡩࡲࡶࠧॻ"))
    if addon == l11ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡰࡳࡧࡰࡸࡪࡳࡰࠨॼ"))
    if addon == l1l1l111_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡨ࡫ࡽࡸࡪࡳࡰࠨॽ"))
    if addon == l1l11l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡩࡶࡴࡷࡺࡳࡵࡧࡰࡴࠬॾ"))
    if addon == l1l1ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡪࡩࡹ࡫࡭ࡱࠩॿ"))
    if addon == l11l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡱࡹࡾࡴࡦ࡯ࡳࠫঀ"))
    if addon == l11l111_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡹࡼ࡫ࡵࡧࡰࡴࠬঁ"))
    if addon == l1ll11l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡾࡴࡦ࡯ࡳࠫং"))
    if addon == l1ll1l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡳࡤࡶࡨࡱࡵ࠭ঃ"))
    if addon == l1ll1ll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡴࡷࡳࡸࡪࡳࡰࠨ঄"))
    if addon == l11l1l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡷ࡮ࡸࡹ࡫࡭ࡱࠩঅ"))
    if addon == l1l111l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩ࡯࡭ࡲ࡯ࡴࡦ࡯ࡳࠫআ"))
    if addon == l1ll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡪࡦࡨࡴࡦ࡯ࡳࠫই"))
    if addon == l1l1l11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡦࡩࡥࡵࡧࡰࡴࠬঈ"))
    if addon == l11lll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬ࡮࡯ࡳࡶࡨࡱࡵ࠭উ"))
    if addon == root:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡲࡰ࠴ࡷࡩࡲࡶࠧঊ"))
    if addon == l1lllll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧ࡮ࡧࡪࡥࡹࡳࡰࠨঋ"))
    if addon == l1ll1l1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨ࡯ࡤࡸࡸࡺ࡭ࡱࠩঌ"))
    if addon == l1l11111_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡩࡶࡪ࡫ࡴ࡮ࡲࠪ঍"))
    if addon == l1ll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪ࡭ࡵࡺࡳࡵ࡯ࡳࠫ঎"))
    if addon == l111l1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫ࡯࠸ࡴࡦ࡯ࡳࠫএ"))
    if addon == l1ll11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬ࡫ࡴࡦ࡯ࡳࠫঐ"))
    if addon == l11llll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭࡭ࡢࡺࡷࡩࡲࡶࠧ঑"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡥࡶࡨࡱࡵ࠭঒"))
    if addon == l1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡸࡧࡸࡪࡳࡰࠨও"))
    if addon == l1llll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡶࡴࡷࡺࡥ࡮ࡲࠪঔ"))
    if addon == l111ll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡱࡨࡱࡴࡦ࡯ࡳࠫক"))
    if addon == l1llll11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡹࡽࡩࡵࡧࡰࡴࠬখ"))
    if addon == l11lllll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡶࡲࡦࡵࡷࡩࡲࡶࠧগ"))
    if addon == l1l111ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡢ࡭࡭࡬ࡸࡪࡳࡰࠨঘ"))
def l11ll111_opy_(url):
    if url.startswith(l1l1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡀࠧঙ")):
        l1l1l1l_opy_ = (l1l1l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡧࡨࡣࡪࡲ࡯ࡥࡾ࡫ࡲ࠰ࡁࡸࡶࡱࡃࡵࡳ࡮ࠩࡱࡴࡪࡥ࠾࠴ࠩࡲࡦࡳࡥ࠾ࡎ࡬ࡺࡪࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࠩࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮࠾ࠨࡌࡔࡎࡊ࠽ࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭চ"))
    if url.startswith(l1l1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙࠳࠼ࠪছ")):
        l1l1l1l_opy_ = (l1l1l_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱ࡮ࡤࡽࡪࡸࡷࡸࡹ࠲ࡃࡺࡸ࡬࠾ࡷࡵࡰࠫࡳ࡯ࡥࡧࡀ࠵࠵࠷ࠦ࡯ࡣࡰࡩࡂ࡝ࡡࡵࡥ࡫࠯ࡑ࡯ࡶࡦࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࡁࠫࡹࡵࡣࡶ࡬ࡸࡱ࡫ࡳࡠࡷࡵࡰࡂࠬ࡬ࡰࡩࡪࡩࡩࡥࡩ࡯࠿ࡉࡥࡱࡹࡥࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭জ"))
    if url.startswith(l1l1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡕ࠾ࠬঝ")):
        l1l1l1l_opy_ = (l1l1l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡰࡦࡿࡥࡳࡹࡺࡻ࠴ࡅࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠪࡱࡵࡧࡨࡧࡧࡣ࡮ࡴ࠽ࡇࡣ࡯ࡷࡪࠬ࡭ࡰࡦࡨࡁ࠶࠷࠳ࠧࡰࡤࡱࡪࡃࡌࡪࡵࡷࡩࡳࠫ࠲࠱ࡎ࡬ࡺࡪࠬࡳࡶࡤࡷ࡭ࡹࡲࡥࡴࡡࡸࡶࡱࠬࡵࡳ࡮ࡀࡹࡷࡲࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬঞ"))
    if url.startswith(l1l1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡎ࡚ࡖ࠻ࠩট")):
        l1l1l1l_opy_ = (l1l1l_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡹࡼࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬঠ"))
    if url.startswith(l1l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡄ࠻ࠩড")):
        l1l1l1l_opy_ = (l1l1l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡪࡥࡹ࠱ࡂࡥࡨࡺࡩࡰࡰࡀࡥࡱࡲࠦࡦࡺࡷࡶࡦࠬࡰࡢࡩࡨࠪࡵࡲ࡯ࡵࠨࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡂࠬࡴࡪࡶ࡯ࡩࡂࠫ࠵ࡣࡅࡒࡐࡔࡘࠥ࠳࠲ࡺ࡬࡮ࡺࡥࠦ࠷ࡧࡅࡱࡲࠥ࠳࠲ࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠩ࠺ࡨࠥ࠳ࡨࡆࡓࡑࡕࡒࠦ࠷ࡧࠪࡺࡸ࡬ࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ঢ"))
    if url.startswith(l1l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡔࡅ࠾ࠬণ")):
        l1l1l1l_opy_ = (l1l1l_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡧࡥࡳࡴࡺ࠯ࡀࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠬࡦࡢࡰࡤࡶࡹࡃࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡲࡵࡤࡦ࠿࠺ࠪࡵ࡯࡬࡭ࡱࡺࡁࡑ࡯ࡶࡦࠧ࠵࠴ࡘࡺࡲࡦࡣࡰࡷࠫࡻࡲ࡭࠿ࡵࡥࡳࡪ࡯࡮ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧত"))
    try:
        dixie.ShowBusy()
        addon =  l1l1l1l_opy_.split(l1l1l_opy_ (u"ࠬ࠵࠯ࠨথ"), 1)[-1].split(l1l1l_opy_ (u"࠭࠯ࠨদ"), 1)[0]
        login = l1l1l_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬধ") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1l1l1l_opy_)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l11lll1l_opy_(e)
        return {l1l1l_opy_ (u"ࠨࡇࡵࡶࡴࡸࠧন") : l1l1l_opy_ (u"ࠩࡓࡰࡺ࡭ࡩ࡯ࠢࡈࡶࡷࡵࡲࠨ঩")}
def l1l1l1ll_opy_():
    modules = map(__import__, [l11lll_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l1l1l_opy_ (u"ࠪࡘࡷࡻࡥࠨপ")
    if len(modules[-1].Window(10**4).getProperty(l11l1l_opy_)):
        return l1l1l_opy_ (u"࡙ࠫࡸࡵࡦࠩফ")
    return l1l1l_opy_ (u"ࠬࡌࡡ࡭ࡵࡨࠫব")
def l11lll1l_opy_(e):
    l1l1ll11_opy_ = l1l1l_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠱ࠦࡡ࡯ࠢࡨࡶࡷࡵࡲࠡࡱࡦࡧࡺࡸࡥࡥ࠼ࠣࡎࡘࡕࡎࠡࡇࡵࡶࡴࡸ࠺ࠡࠧࡶࠫভ")  %e
    l11l11l_opy_ = l1l1l_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡳࡧ࠰ࡰ࡮ࡴ࡫ࠡࡶ࡫࡭ࡸࠦࡣࡩࡣࡱࡲࡪࡲࠠࡢࡰࡧࠤࡹࡸࡹࠡࡣࡪࡥ࡮ࡴ࠮ࠨম")
    l1l1lll1_opy_ = l1l1l_opy_ (u"ࠨࡗࡶࡩ࠿ࠦࡃࡰࡰࡷࡩࡽࡺࠠࡎࡧࡱࡹࠥࡃ࠾ࠡࡔࡨࡱࡴࡼࡥࠡࡕࡷࡶࡪࡧ࡭ࠨয")
    dixie.DialogOK(l1l1ll11_opy_, l11l11l_opy_, l1l1lll1_opy_)