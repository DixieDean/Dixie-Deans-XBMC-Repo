# -*- coding: utf-8 -*-
import sys
l1l111l_opy_ = sys.version_info [0] == 2
l11111_opy_ = 2048
l1111_opy_ = 7
def l11ll1_opy_ (ll_opy_):
	global l1111l_opy_
	l1l11l1_opy_ = ord (ll_opy_ [-1])
	l111ll_opy_ = ll_opy_ [:-1]
	l1ll1l1_opy_ = l1l11l1_opy_ % len (l111ll_opy_)
	l1ll1_opy_ = l111ll_opy_ [:l1ll1l1_opy_] + l111ll_opy_ [l1ll1l1_opy_:]
	if l1l111l_opy_:
		l1lll1l_opy_ = unicode () .join ([unichr (ord (char) - l11111_opy_ - (l11lll_opy_ + l1l11l1_opy_) % l1111_opy_) for l11lll_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1lll1l_opy_ = str () .join ([chr (ord (char) - l11111_opy_ - (l11lll_opy_ + l1l11l1_opy_) % l1111_opy_) for l11lll_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1lll1l_opy_)
import os
import json
import requests
import dixie
l1l1l1_opy_ = dixie.PROFILE
PATH = os.path.join(l1l1l1_opy_, l11ll1_opy_ (u"ࠨࡲ࡯࡭ࡸࡺࡳࠨࢬ"))
def loadPlaylists():
    dixie.log(l11ll1_opy_ (u"ࠩࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠢࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠥࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࠫࢭ"))
    if os.path.exists(PATH):
        return json.load(open(PATH))
    l1l11ll11_opy_()
    return json.load(open(PATH))
def l1l11ll11_opy_():
    source = dixie.GetSetting(l11ll1_opy_ (u"ࠪ࡭ࡵࡺࡶ࠯ࡵࡲࡹࡷࡩࡥࠨࢮ"))
    if not source == l11ll1_opy_ (u"ࠫ࠶࠭ࢯ"):
        return l1l1l11l1_opy_()
    return l1l111l11_opy_()
def l1l1l11l1_opy_():
    l1l1lllll_opy_ = []
    if dixie.GetSetting(l11ll1_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠴ࠬࢰ")) == l11ll1_opy_ (u"࠭ࡴࡳࡷࡨࠫࢱ"):
        l1l1lll11_opy_  = dixie.GetSetting(l11ll1_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠶࡟ࡖࡔࡏࠫࢲ"))
        l1l111l1l_opy_ = dixie.GetSetting(l11ll1_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠰ࡠࡒࡒࡖ࡙࠭ࢳ"))
        l1l1l111l_opy_ = dixie.GetSetting(l11ll1_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠱ࡡࡗ࡝ࡕࡋࠧࢴ"))
        l1l1ll11l_opy_ = dixie.GetSetting(l11ll1_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠲ࡢ࡙ࡘࡋࡒࠨࢵ"))
        l1l1lll1l_opy_ = dixie.GetSetting(l11ll1_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠳ࡣࡕࡇࡓࡔࠩࢶ"))
        if len(l1l1lll11_opy_) > 0:
            l1l1l1111_opy_ = l1l11l11l_opy_(l1l1lll11_opy_, l1l111l1l_opy_, l1l1l111l_opy_, l1l1ll11l_opy_, l1l1lll1l_opy_)
            l1l1lllll_opy_.append((l1l1l1111_opy_, l11ll1_opy_ (u"ࠬࡏࡐࡕࡘ࠴࠾ࠥ࠭ࢷ")))
    if dixie.GetSetting(l11ll1_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠶࠭ࢸ")) == l11ll1_opy_ (u"ࠧࡵࡴࡸࡩࠬࢹ"):
        l1l1lll11_opy_  = dixie.GetSetting(l11ll1_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠱ࡠࡗࡕࡐࠬࢺ"))
        l1l111l1l_opy_ = dixie.GetSetting(l11ll1_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠲ࡡࡓࡓࡗ࡚ࠧࢻ"))
        l1l1l111l_opy_ = dixie.GetSetting(l11ll1_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠳ࡢࡘ࡞ࡖࡅࠨࢼ"))
        l1l1ll11l_opy_ = dixie.GetSetting(l11ll1_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠴ࡣ࡚࡙ࡅࡓࠩࢽ"))
        l1l1lll1l_opy_ = dixie.GetSetting(l11ll1_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠵ࡤࡖࡁࡔࡕࠪࢾ"))
        if len(l1l1lll11_opy_) > 0:
            l1l1l1ll1_opy_ = l1l11l11l_opy_(l1l1lll11_opy_, l1l111l1l_opy_, l1l1l111l_opy_, l1l1ll11l_opy_, l1l1lll1l_opy_)
            l1l1lllll_opy_.append((l1l1l1ll1_opy_, l11ll1_opy_ (u"࠭ࡉࡑࡖ࡙࠶࠿ࠦࠧࢿ")))
    if dixie.GetSetting(l11ll1_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠸ࠧࣀ")) == l11ll1_opy_ (u"ࠨࡶࡵࡹࡪ࠭ࣁ"):
        l1l1lll11_opy_  = dixie.GetSetting(l11ll1_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠳ࡡࡘࡖࡑ࠭ࣂ"))
        l1l111l1l_opy_ = dixie.GetSetting(l11ll1_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠴ࡢࡔࡔࡘࡔࠨࣃ"))
        l1l1l111l_opy_ = dixie.GetSetting(l11ll1_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠵ࡣ࡙࡟ࡐࡆࠩࣄ"))
        l1l1ll11l_opy_ = dixie.GetSetting(l11ll1_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠶ࡤ࡛ࡓࡆࡔࠪࣅ"))
        l1l1lll1l_opy_ = dixie.GetSetting(l11ll1_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠷ࡥࡐࡂࡕࡖࠫࣆ"))
        if len(l1l1lll11_opy_) > 0:
            l1l1l1l1l_opy_ = l1l11l11l_opy_(l1l1lll11_opy_, l1l111l1l_opy_, l1l1l111l_opy_, l1l1ll11l_opy_, l1l1lll1l_opy_)
            l1l1lllll_opy_.append((l1l1l1l1l_opy_, l11ll1_opy_ (u"ࠧࡊࡒࡗ࡚࠸ࡀࠠࠨࣇ")))
    return l1l11l1ll_opy_(l11ll1_opy_ (u"ࠨࡗࡕࡐࡘ࠭ࣈ"),  l1l1lllll_opy_)
def l1l111l11_opy_():
    l1l1lllll_opy_ = []
    if dixie.GetSetting(l11ll1_opy_ (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡹࡿࡰࡦࠩࣉ")) == l11ll1_opy_ (u"ࠪ࠴ࠬ࣊"):
        if dixie.GetSetting(l11ll1_opy_ (u"࡚ࠫࡘࡌࡠࡑࠪ࣋")) == l11ll1_opy_ (u"ࠬࡺࡲࡶࡧࠪ࣌"):
            l1l1111l1_opy_ = dixie.GetSetting(l11ll1_opy_ (u"࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡷࡵࡰࠬ࣍"))
            if len(l1l1111l1_opy_) > 0:
                l1l1lllll_opy_.append((l1l1111l1_opy_, l11ll1_opy_ (u"ࠧࡖࡔࡏ࠵࠿ࠦࠧ࣎")))
        if dixie.GetSetting(l11ll1_opy_ (u"ࠨࡗࡕࡐࡤ࠷࣏ࠧ")) == l11ll1_opy_ (u"ࠩࡷࡶࡺ࡫࣐ࠧ"):
            l1l1l1lll_opy_ = dixie.GetSetting(l11ll1_opy_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡻࡲ࡭࠳࣑ࠪ"))
            if len(l1l1l1lll_opy_) > 0:
                l1l1lllll_opy_.append((l1l1l1lll_opy_, l11ll1_opy_ (u"࡚ࠫࡘࡌ࠳࠼࣒ࠣࠫ")))
        if dixie.GetSetting(l11ll1_opy_ (u"࡛ࠬࡒࡍࡡ࠵࣓ࠫ")) == l11ll1_opy_ (u"࠭ࡴࡳࡷࡨࠫࣔ"):
            l1l1l1l11_opy_ = dixie.GetSetting(l11ll1_opy_ (u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡸࡶࡱ࠸ࠧࣕ"))
            if len(l1l1l1l11_opy_) > 0:
                l1l1lllll_opy_.append((l1l1l1l11_opy_, l11ll1_opy_ (u"ࠨࡗࡕࡐ࠸ࡀࠠࠨࣖ")))
        dixie.log(l1l1lllll_opy_)
        return l1l11l1ll_opy_(l11ll1_opy_ (u"ࠩࡘࡖࡑ࡙ࠧࣗ"),  l1l1lllll_opy_)
    if dixie.GetSetting(l11ll1_opy_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡺࡹࡱࡧࠪࣘ")) == l11ll1_opy_ (u"ࠫ࠶࠭ࣙ"):
        if dixie.GetSetting(l11ll1_opy_ (u"ࠬࡌࡉࡍࡇࡢ࠴ࠬࣚ")) == l11ll1_opy_ (u"࠭ࡴࡳࡷࡨࠫࣛ"):
            l1l1111ll_opy_ = os.path.join(dixie.GetSetting(l11ll1_opy_ (u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡩ࡭ࡱ࡫ࠧࣜ")))
            if l1l1111ll_opy_:
                l1l1lllll_opy_.append((l1l1111ll_opy_, l11ll1_opy_ (u"ࠨࡈࡌࡐࡊ࠷࠺ࠡࠩࣝ")))
        if dixie.GetSetting(l11ll1_opy_ (u"ࠩࡉࡍࡑࡋ࡟࠱ࠩࣞ")) == l11ll1_opy_ (u"ࠪࡸࡷࡻࡥࠨࣟ"):
            l1l1ll1l1_opy_ = os.path.join(dixie.GetSetting(l11ll1_opy_ (u"ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡦࡪ࡮ࡨ࠵ࠬ࣠")))
            if l1l1ll1l1_opy_:
                l1l1lllll_opy_.append((l1l1ll1l1_opy_, l11ll1_opy_ (u"ࠬࡌࡉࡍࡇ࠵࠾ࠥ࠭࣡")))
        if dixie.GetSetting(l11ll1_opy_ (u"࠭ࡆࡊࡎࡈࡣ࠵࠭࣢")) == l11ll1_opy_ (u"ࠧࡵࡴࡸࡩࣣࠬ"):
            l1l1llll1_opy_ = os.path.join(dixie.GetSetting(l11ll1_opy_ (u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡪ࡮ࡲࡥ࠳ࠩࣤ")))
            if l1l1llll1_opy_:
                l1l1lllll_opy_.append((l1l1llll1_opy_, l11ll1_opy_ (u"ࠩࡉࡍࡑࡋ࠳࠻ࠢࠪࣥ")))
        dixie.log(l1l1lllll_opy_)
        return l1l11l1ll_opy_(l11ll1_opy_ (u"ࠪࡊࡎࡒࡅࡔࣦࠩ"), l1l1lllll_opy_)
    if dixie.GetSetting(l11ll1_opy_ (u"ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡴࡺࡲࡨࠫࣧ")) == l11ll1_opy_ (u"ࠬ࠸ࠧࣨ"):
        return l1l111lll_opy_()
def l1l111lll_opy_():
    l1l11l111_opy_ = [l11ll1_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳ࡍࡋ࡚࠶࡜ࡼ࡭ࡏ࡫ࡗࠨࣩ"), l11ll1_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡹ࠰ࡦࡳ࠴ࡾࡦ࠶ࡋ࠶ࡌࡔࡪ࡙ࡏࠩ࣪"), l11ll1_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡺ࠱ࡧࡴ࠵ࡕࡍࡥ࠳࠵ࡒࡕࡌࡨࡅࠪ࣫"), l11ll1_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡻ࠲ࡨࡵ࠯࡫ࡷࡑࡑࡓ࡭ࡷ࡫ࡒ࠳ࠫ࣬"), l11ll1_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡼ࠳ࡩ࡯࠰ࡦ࡭ࡆࡦ࠷࡮ࡷ࠻ࡊࡾ࣭ࠬ"), l11ll1_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱ࡱ࡚ࡸࡷࡣࡨࡥࡦ࠽ࡾ࣮࠭"), l11ll1_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲ࡼࡑࡉ࠹࠵ࡇ࡙ࡕࡻ࡟࣯ࠧ"), l11ll1_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳ࡹࡹࡅ࠴ࡌࡓࡸ࡫ࡓࡲࠨࣰ"), l11ll1_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡹ࠰ࡦࡳ࠴࡫ࡖࡗࡃࡺࡏࡎࡹࡓࡩࣱࠩ"), l11ll1_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡺ࠱ࡧࡴ࠵ࡸࡒࡲࡉࡎ࡜࡭ࡩࡨ࡬ࣲࠪ")]
    for url in l1l11l111_opy_:
        request = requests.get(url)
        content = request.content
        if l11ll1_opy_ (u"ࠩࠦࡉ࡝࡚ࡍ࠴ࡗࠪࣳ") in content:
            return l1l11l1ll_opy_(l11ll1_opy_ (u"ࠪࡇࡑࡕࡕࡅࠩࣴ"), [(url, l11ll1_opy_ (u"ࠫࠬࣵ"))])
            break
def l1l11l1ll_opy_(l1l11l1l1_opy_, plist):
    dixie.log(l1l11l1l1_opy_)
    dixie.log(plist)
    playlists = []
    for item in plist:
        url = item[0]
        l1l1ll111_opy_ = item[1]
        l1l1l11ll_opy_ = l1l1ll1ll_opy_(l1l11l1l1_opy_, url, l1l1ll111_opy_)
        playlists.extend(l1l1l11ll_opy_)
    json.dump(playlists, open(PATH,l11ll1_opy_ (u"ࠬࡽࣶࠧ")))
def l1l1ll1ll_opy_(l1l11l1l1_opy_, url, l1l1ll111_opy_):
    content = l1l111ll1_opy_(l1l11l1l1_opy_, url)
    l1l11ll1l_opy_ = list()
    l1l111_opy_   = l11ll1_opy_ (u"࠭ࠧࣷ")
    value   = l11ll1_opy_ (u"ࠧࠨࣸ")
    for line in content:
        if line.startswith(l11ll1_opy_ (u"ࠨࠥࡈ࡜࡙ࡏࡎࡇ࠼ࣹࠪ")):
            l11llll_opy_ = dixie.cleanLabel(line.split(l11ll1_opy_ (u"ࠩ࠯ࣺࠫ"))[-1].strip())
            l1lll_opy_ = dixie.mapChannelName(l11llll_opy_)
            l1l111_opy_ = l1l1ll111_opy_ + l1lll_opy_
        if line.startswith(l11ll1_opy_ (u"ࠪࡶࡹࡳࡰࠨࣻ")) or line.startswith(l11ll1_opy_ (u"ࠫࡷࡺ࡭ࡱࡧࠪࣼ")) or line.startswith(l11ll1_opy_ (u"ࠬࡸࡴࡴࡲࠪࣽ")) or line.startswith(l11ll1_opy_ (u"࠭ࡨࡵࡶࡳࠫࣾ")):
            value = line.replace(l11ll1_opy_ (u"ࠧࡳࡶࡰࡴ࠿࠵࠯ࠥࡑࡓࡘ࠿ࡸࡴ࡮ࡲ࠰ࡶࡦࡽ࠽ࠨࣿ"), l11ll1_opy_ (u"ࠨࠩऀ")).replace(l11ll1_opy_ (u"ࠩ࡟ࡲࠬँ"), l11ll1_opy_ (u"ࠪࠫं"))
            l1l11ll1l_opy_.append((l1l111_opy_, value))
    return l1l11ll1l_opy_
def l1l111ll1_opy_(l1l11l1l1_opy_, url):
    if l1l11l1l1_opy_ == l11ll1_opy_ (u"࡚ࠫࡘࡌࡔࠩः"):
        content = requests.get(url)
        return content.iter_lines()
    if l1l11l1l1_opy_ == l11ll1_opy_ (u"ࠬࡌࡉࡍࡇࡖࠫऄ"):
        with open(url) as content:
            return content.readlines()
    if l1l11l1l1_opy_ == l11ll1_opy_ (u"࠭ࡃࡍࡑࡘࡈࠬअ"):
        content = requests.get(url)
        dixie.log(content)
        return content.iter_lines()
def l1l11l11l_opy_(l1l1lll11_opy_, l1l111l1l_opy_, l1l1l111l_opy_, l1l1ll11l_opy_, l1l1lll1l_opy_):
    url  = l11ll1_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨआ")
    url +=  l1l1lll11_opy_
    url +=  l1l11llll_opy_(l1l111l1l_opy_)
    url += l11ll1_opy_ (u"ࠨ࠱ࡪࡩࡹ࠴ࡰࡩࡲࡂࡹࡸ࡫ࡲ࡯ࡣࡰࡩࡂ࠭इ")
    url +=  l1l1ll11l_opy_
    url += l11ll1_opy_ (u"ࠩࠩࡴࡦࡹࡳࡸࡱࡵࡨࡂ࠭ई")
    url +=  l1l1lll1l_opy_
    url += l11ll1_opy_ (u"ࠪࠪࡹࡿࡰࡦ࠿ࡰ࠷ࡺࡥࡰ࡭ࡷࡶࠪࡴࡻࡴࡱࡷࡷࡁࠬउ")
    url +=  l1l11lll1_opy_(l1l1l111l_opy_)
    return url
def l1l11llll_opy_(l1l111l1l_opy_):
    if not l1l111l1l_opy_ == l11ll1_opy_ (u"ࠫࠬऊ"):
        return l11ll1_opy_ (u"ࠬࡀࠧऋ") + l1l111l1l_opy_
    return l11ll1_opy_ (u"࠭ࠧऌ")
def l1l11lll1_opy_(l1l1l111l_opy_):
    if l1l1l111l_opy_ == l11ll1_opy_ (u"ࠧ࠱ࠩऍ"):
        return l11ll1_opy_ (u"ࠨ࡯࠶ࡹ࠽࠭ऎ")
    if l1l1l111l_opy_ == l11ll1_opy_ (u"ࠩ࠴ࠫए"):
        return l11ll1_opy_ (u"ࠪࡱࡵ࡫ࡧࡵࡵࠪऐ")
if __name__ == l11ll1_opy_ (u"ࠫࡤࡥ࡭ࡢ࡫ࡱࡣࡤ࠭ऑ"):
    l1l11ll11_opy_()