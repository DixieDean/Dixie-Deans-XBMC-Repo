# coding: UTF-8
import sys
l11ll111_opy_ = sys.version_info [0] == 2
l1lll1l1_opy_ = 2048
l11lllll_opy_ = 7
def l1l11_opy_ (l11ll1_opy_):
	global l1llll11_opy_
	l1ll1111_opy_ = ord (l11ll1_opy_ [-1])
	l11ll11l_opy_ = l11ll1_opy_ [:-1]
	l11l11l_opy_ = l1ll1111_opy_ % len (l11ll11l_opy_)
	l111l1_opy_ = l11ll11l_opy_ [:l11l11l_opy_] + l11ll11l_opy_ [l11l11l_opy_:]
	if l11ll111_opy_:
		l1lll1_opy_ = unicode () .join ([unichr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	else:
		l1lll1_opy_ = str () .join ([chr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	return eval (l1lll1_opy_)
import xbmc
import xbmcaddon
import json
import os
import dixie
l1lll1l11_opy_ = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡱࡲࡸ࡮ࡶࡴࡷࠩ࡟")
l1ll1lll1_opy_   = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡚ࡷࡶࡪࡧ࡭ࡊࡒࡗ࡚ࠬࡠ")
l1l1lll1l_opy_  = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡸࡷ࡫ࡡ࡮࠯ࡦࡳࡩ࡫ࡳࠨࡡ")
l1ll11l1l_opy_   = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡒࡪࡳࡺࡻࡻࡌࡔ࡙࡜ࠧࡢ")
l1lllll11_opy_     = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡴࡺࡴࡢ࡮ࡳ࡬ࡦ࠭ࡣ")
l1l1lllll_opy_ = [l1lll1l11_opy_, l1ll1lll1_opy_, l1l1lll1l_opy_, l1ll11l1l_opy_, l1lllll11_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1l11_opy_ (u"࠭ࡩ࡯࡫ࠪࡤ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1ll111ll_opy_ = l1l11_opy_ (u"ࠧࠨࡥ")
def l1l1llll1_opy_(i, t1, l1ll111l1_opy_=[]):
 t = l1ll111ll_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1ll111l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1lllllll_opy_ = l1l1llll1_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l1111l11_opy_ = l1l1llll1_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1l1lllll_opy_:
        if l1lll11l1_opy_(addon):
            createINI(addon)
def l1lll11l1_opy_(addon):
    if xbmc.getCondVisibility(l1l11_opy_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫࠩࡸ࠯ࠧࡦ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l1ll1ll11_opy_ = str(addon).rsplit(l1l11_opy_ (u"ࠩ࠱ࠫࡧ"), 1)[1] + l1l11_opy_ (u"ࠪ࠲࡮ࡴࡩࠨࡨ")
    l1ll11111_opy_  = os.path.join(PATH, l1ll1ll11_opy_)
    try:
        l1ll1l111_opy_ = l1lll1111_opy_(addon)
    except KeyError:
        dixie.log(l1l11_opy_ (u"ࠫ࠲࠳࠭࠮࠯ࠣࡏࡪࡿࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡩࡨࡸࡋ࡯࡬ࡦࡵࠣ࠱࠲࠳࠭࠮ࠢࠪࡩ") + addon)
        result = {l1l11_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࡷࠬࡪ"): [{l1l11_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ࡫"): l1l11_opy_ (u"ࡵࠨࡨ࡬ࡰࡪ࠭࡬"), l1l11_opy_ (u"ࡶࠩࡷࡽࡵ࡫ࠧ࡭"): l1l11_opy_ (u"ࡷࠪࡹࡳࡱ࡮ࡰࡹࡱࠫ࡮"), l1l11_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࠩ࡯"): l1l11_opy_ (u"ࡹࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸࡹࡺࠪࡰ"), l1l11_opy_ (u"ࡺ࠭࡬ࡢࡤࡨࡰࠬࡱ"): l1l11_opy_ (u"ࡻࠧࡏࡑࠣࡇࡍࡇࡎࡏࡇࡏࡗࠬࡲ")}], l1l11_opy_ (u"ࡵࠨ࡮࡬ࡱ࡮ࡺࡳࠨࡳ"):{l1l11_opy_ (u"ࡶࠩࡶࡸࡦࡸࡴࠨࡴ"): 0, l1l11_opy_ (u"ࡷࠪࡸࡴࡺࡡ࡭ࠩࡵ"): 1, l1l11_opy_ (u"ࡸࠫࡪࡴࡤࠨࡶ"): 1}}
    l1lll11ll_opy_  = l1l11_opy_ (u"ࠫࡠ࠭ࡷ") + addon + l1l11_opy_ (u"ࠬࡣ࡜࡯ࠩࡸ")
    l1ll11lll_opy_  = file(l1ll11111_opy_, l1l11_opy_ (u"࠭ࡷࠨࡹ"))
    l1ll11lll_opy_.write(l1lll11ll_opy_)
    l1llll1ll_opy_ = []
    try:
        for channel in l1ll1l111_opy_:
            l1ll1111l_opy_ = l1llllll1_opy_(addon, channel)
            l11111ll_opy_ = dixie.mapChannelName(l1ll1111l_opy_)
            stream   = channel[l1l11_opy_ (u"ࠧࡧ࡫࡯ࡩࠬࡺ")]
            l1lllll1l_opy_ = l11111ll_opy_ + l1l11_opy_ (u"ࠨ࠿ࠪࡻ") + stream
            l1llll1ll_opy_.append(l1lllll1l_opy_)
            l1llll1ll_opy_.sort()
        for item in l1llll1ll_opy_:
            l1ll11lll_opy_.write(l1l11_opy_ (u"ࠤࠨࡷࡡࡴࠢࡼ") % item)
        l1ll11lll_opy_.close()
    except Exception as e:
        l1ll1l11l_opy_(e, addon)
        return {l1l11_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࡵࠪࡽ"): [{l1l11_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧࡾ"): l1l11_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࠫࡿ"), l1l11_opy_ (u"ࡻࠧࡵࡻࡳࡩࠬࢀ"): l1l11_opy_ (u"ࡵࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩࢁ"), l1l11_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࠧࢂ"): l1l11_opy_ (u"ࡷࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡾࡸࠨࢃ"), l1l11_opy_ (u"ࡸࠫࡱࡧࡢࡦ࡮ࠪࢄ"): l1l11_opy_ (u"ࡹࠬࡔࡏࠡࡅࡋࡅࡓࡔࡅࡍࡕࠪࢅ")}], l1l11_opy_ (u"ࡺ࠭࡬ࡪ࡯࡬ࡸࡸ࠭ࢆ"):{l1l11_opy_ (u"ࡻࠧࡴࡶࡤࡶࡹ࠭ࢇ"): 0, l1l11_opy_ (u"ࡵࠨࡶࡲࡸࡦࡲࠧ࢈"): 1, l1l11_opy_ (u"ࡶࠩࡨࡲࡩ࠭ࢉ"): 1}}
def l1llllll1_opy_(addon, file):
    l1lll1ll1_opy_ = file[l1l11_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨࢊ")].split(l1l11_opy_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࢋ"), 1)[0]
    return dixie.cleanLabel(l1lll1ll1_opy_)
def l1lll1111_opy_(addon):
    login = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴ࠱ࠪࢌ") % addon
    sendJSON(login, addon)
    if (addon == l1lll1l11_opy_) or (addon == l1l1lll1l_opy_) or (addon == l1lllll11_opy_):
        return l111l111_opy_(addon)
    if (addon == l1ll1lll1_opy_) or (addon == l1ll11l1l_opy_):
        l1ll11l11_opy_ = [l1l11_opy_ (u"ࠬ࠹ࠧࢍ"), l1l11_opy_ (u"࠭࠴ࠨࢎ"), l1l11_opy_ (u"ࠧ࠷ࠩ࢏"), l1l11_opy_ (u"ࠨ࠹ࠪ࢐"), l1l11_opy_ (u"ࠩ࠻ࠫ࢑"), l1l11_opy_ (u"ࠪ࠵࠶࠭࢒"), l1l11_opy_ (u"ࠫ࠶࠸ࠧ࢓"), l1l11_opy_ (u"ࠬ࠷࠴ࠨ࢔"), l1l11_opy_ (u"࠭࠱࠶ࠩ࢕"), l1l11_opy_ (u"ࠧ࠴࠵ࠪ࢖"), l1l11_opy_ (u"ࠨ࠻࠴ࠫࢗ"), l1l11_opy_ (u"ࠩ࠼࠶ࠬ࢘")]
    l1lll111l_opy_ = []
    for l1llll1l1_opy_ in l1ll11l11_opy_:
        if (addon == l1ll1lll1_opy_) or (addon == l1ll11l1l_opy_):
            query = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿ࡶࡸࡷ࡫ࡡ࡮ࡡࡹ࡭ࡩ࡫࡯ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠦࡵ࡫ࡷࡰࡪࡃࠦࡶࡴ࡯ࡁࠪࡹ࢙ࠧ") % (addon, l1llll1l1_opy_)
        response = sendJSON(query, addon)
        l1lll111l_opy_.extend(response)
    return l1lll111l_opy_
def l111l111_opy_(addon):
    query = l1ll1llll_opy_(addon)
    return sendJSON(query, addon)
def l1ll1llll_opy_(addon):
    Addon = xbmcaddon.Addon(addon)
    l1111ll1_opy_, l1111111_opy_  = l1111l1l_opy_(Addon, addon)
    l11111l1_opy_, l1111lll_opy_ = l1ll1l1l1_opy_(Addon, addon)
    return l111111l_opy_(addon, l1111ll1_opy_, l1111111_opy_, l11111l1_opy_, l1111lll_opy_)
def l1111l1l_opy_(Addon, addon):
    if addon == l1lll1l11_opy_:
        l1111ll1_opy_  = l1l11_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡷࡵ࡯ࡵ࠯࡬ࡴࡹࡼ࠮ࡪࡵ࠰ࡪࡴࡻ࡮ࡥ࠰ࡲࡶ࡬࢚࠭")
        l1111111_opy_ = l1l11_opy_ (u"ࠬ࠸࠵࠵࠸࠴࢛ࠫ")
        return l1111ll1_opy_, l1111111_opy_
    if addon == l1lllll11_opy_:
        l1111ll1_opy_  = l1l11_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡯ࡵࡶࡷࡺ࠳࡭ࡡࠨ࢜")
        l1111111_opy_ = l1l11_opy_ (u"ࠧ࠳࠲࠼࠹ࠬ࢝")
        return l1111ll1_opy_, l1111111_opy_
    l1111ll1_opy_  = Addon.getSetting(l1l11_opy_ (u"ࠨ࡮ࡨ࡬ࡪࡱࡹ࡭ࡩࠪ࢞"))
    l1111111_opy_ = Addon.getSetting(l1l11_opy_ (u"ࠩࡳࡳࡷࡪࡩ࡯ࡷࡰࡦࡪࡸࠧ࢟"))
    return l1111ll1_opy_, l1111111_opy_
def l1ll1l1l1_opy_(Addon, addon):
    if addon == l1lllll11_opy_:
        l11111l1_opy_ = Addon.getSetting(l1l11_opy_ (u"࡙ࠪࡸ࡫ࡲ࡯ࡣࡰࡩࠬࢠ"))
        l1111lll_opy_ = Addon.getSetting(l1l11_opy_ (u"ࠫࡕࡧࡳࡴࡹࡲࡶࡩ࠭ࢡ"))
        return l11111l1_opy_, l1111lll_opy_
    l11111l1_opy_ = Addon.getSetting(l1l11_opy_ (u"ࠬࡱࡡࡴࡷࡷࡥ࡯ࡧ࡮ࡪ࡯࡬ࠫࢢ"))
    l1111lll_opy_ = Addon.getSetting(l1l11_opy_ (u"࠭ࡳࡢ࡮ࡤࡷࡴࡴࡡࠨࢣ"))
    return l11111l1_opy_, l1111lll_opy_
def l111111l_opy_(addon, l1111ll1_opy_, l1111111_opy_, l11111l1_opy_, l1111lll_opy_):
    if addon == l1lll1l11_opy_:
        action = l1l11_opy_ (u"ࠧࡊ࠳࠴ࡍࡎ࠷ࡩࠨࢤ")
    else:
        action = l1l11_opy_ (u"ࠨࡵࡷࡶࡪࡧ࡭ࡠࡸ࡬ࡨࡪࡵࠧࢥ")
    l1ll11ll1_opy_  = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬࢦ")
    l1ll11ll1_opy_ +=  addon
    l1ll11ll1_opy_ += l1l11_opy_ (u"ࠪ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࠫࡳࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠦࡵ࡫ࡷࡰࡪࡃࡁ࡭࡮ࠩࡹࡷࡲ࠽ࠨࢧ") % (action)
    params  =  l1111ll1_opy_
    params += l1l11_opy_ (u"ࠫ࠿࠭ࢨ") + l1111111_opy_
    params += l1l11_opy_ (u"ࠬ࠵ࡥ࡯࡫ࡪࡱࡦ࠸࠮ࡱࡪࡳࡃࡺࡹࡥࡳࡰࡤࡱࡪࡃࠧࢩ")
    params +=  l11111l1_opy_
    params += l1l11_opy_ (u"࠭ࠦࡱࡣࡶࡷࡼࡵࡲࡥ࠿ࠪࢪ")
    params +=  l1111lll_opy_
    params += l1l11_opy_ (u"ࠧࠧࡶࡼࡴࡪࡃࡧࡦࡶࡢࡰ࡮ࡼࡥࡠࡵࡷࡶࡪࡧ࡭ࡴࠨࡦࡥࡹࡥࡩࡥ࠿࠳ࠫࢫ")
    import urllib
    params = urllib.quote_plus(params)
    url = l1ll11ll1_opy_ + params
    return url
def login(addon):
    login = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸ࠵ࠧࢬ") % addon
    sendJSON(login, addon)
def sendJSON(query, addon):
    l1lll1l1l_opy_     = l1l11_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬࢭ") % query
    l1ll1ll1l_opy_  = xbmc.executeJSONRPC(l1lll1l1l_opy_)
    response = json.loads(l1ll1ll1l_opy_)
    result   = response[l1l11_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪࢮ")]
    return result[l1l11_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪࢯ")]
def l1ll1l1ll_opy_():
    modules = map(__import__, [l1l1llll1_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1lllllll_opy_)):
        return l1l11_opy_ (u"࡚ࠬࡲࡶࡧࠪࢰ")
    if len(modules[-1].Window(10**4).getProperty(l1111l11_opy_)):
        return l1l11_opy_ (u"࠭ࡔࡳࡷࡨࠫࢱ")
    return l1l11_opy_ (u"ࠧࡇࡣ࡯ࡷࡪ࠭ࢲ")
def l1ll1l11l_opy_(e, addon):
    l1lll1lll_opy_ = l1l11_opy_ (u"ࠨࡕࡲࡶࡷࡿࠬࠡࡣࡱࠤࡪࡸࡲࡰࡴࠣࡳࡨࡩࡵࡳࡧࡧ࠾ࠥࡐࡓࡐࡐࠣࡉࡷࡸ࡯ࡳ࠼ࠣࠩࡸ࠲ࠠࠦࡵࠪࢳ")  % (e, addon)
    l1llll111_opy_ = l1l11_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡹࡸࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡦࡰࡴࡸࡱ࠳࠭ࢴ")
    l1llll11l_opy_ = l1l11_opy_ (u"࡙ࠪࡵࡲ࡯ࡢࡦࠣࡥࠥࡲ࡯ࡨࠢࡹ࡭ࡦࠦࡴࡩࡧࠣࡥࡩࡪ࡯࡯ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠤࡦࡴࡤࠡࡲࡲࡷࡹࠦࡴࡩࡧࠣࡰ࡮ࡴ࡫࠯ࠩࢵ")
    dixie.log(addon)
    dixie.log(e)
if __name__ == l1l11_opy_ (u"ࠫࡤࡥ࡭ࡢ࡫ࡱࡣࡤ࠭ࢶ"):
    checkAddons()