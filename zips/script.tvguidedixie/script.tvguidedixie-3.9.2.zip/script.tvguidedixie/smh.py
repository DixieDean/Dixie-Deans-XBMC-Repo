# coding: UTF-8
import sys
l11ll111_opy_ = sys.version_info [0] == 2
l1lll1l1_opy_ = 2048
l11lllll_opy_ = 7
def l1l11_opy_ (l11ll1_opy_):
	global l1llll11_opy_
	l1ll1111_opy_ = ord (l11ll1_opy_ [-1])
	l11ll11l_opy_ = l11ll1_opy_ [:-1]
	l11l11l_opy_ = l1ll1111_opy_ % len (l11ll11l_opy_)
	l111l1_opy_ = l11ll11l_opy_ [:l11l11l_opy_] + l11ll11l_opy_ [l11l11l_opy_:]
	if l11ll111_opy_:
		l1lll1_opy_ = unicode () .join ([unichr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	else:
		l1lll1_opy_ = str () .join ([chr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	return eval (l1lll1_opy_)
import xbmc
import xbmcaddon
import dixie
import os
import sys
import json
l1l1l1l1l_opy_ = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡳࡡࡳࡶ࡫ࡹࡧ࠭ࢷ")
l1l1l11ll_opy_ = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡵࡺࡣ࠵ࠫࢸ")
l1l1lllll_opy_ = [l1l1l1l1l_opy_, l1l1l11ll_opy_]
def checkAddons():
    for addon in l1l1lllll_opy_:
        if l1lll11l1_opy_(addon):
            createINI(addon)
def l1lll11l1_opy_(addon):
    if xbmc.getCondVisibility(l1l11_opy_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡉࡣࡶࡅࡩࡪ࡯࡯ࠪࠨࡷ࠮࠭ࢹ") % addon) == 1:
        return True
    else:
        return False
def l1l1l1lll_opy_(addon):
    Addon  = xbmcaddon.Addon(id=addon)
    prefix = l1l1ll1l1_opy_(Addon)
    if prefix == l1l11_opy_ (u"ࠨࡊࡇࡘ࡛ࡀࠧࢺ"):
        return os.path.join(dixie.PROFILE, l1l11_opy_ (u"ࠩࡶ࡬ࡹ࡫࡭ࡱࠩࢻ"))
    if prefix == l1l11_opy_ (u"ࠪࡌࡉ࡚ࡖ࠳࠼ࠪࢼ"):
        return os.path.join(dixie.PROFILE, l1l11_opy_ (u"ࠫࡷࡻࡴࡦ࡯ࡳࠫࢽ"))
def createINI(addon):
    l1l1ll11l_opy_ = os.path.join(dixie.PROFILE, l1l11_opy_ (u"ࠬࡹࡨࡵࡧࡰࡴࠬࢾ"))
    if os.path.exists(l1l1ll11l_opy_):
        os.remove(l1l1ll11l_opy_)
    l1l1l111l_opy_ = os.path.join(dixie.PROFILE, l1l11_opy_ (u"࠭ࡲࡶࡶࡨࡱࡵ࠭ࢿ"))
    if os.path.exists(l1l1l111l_opy_):
        os.remove(l1l1l111l_opy_)
    Addon  = xbmcaddon.Addon(id=addon)
    path   = Addon.getAddonInfo(l1l11_opy_ (u"ࠧࡱࡣࡷ࡬ࠬࣀ"))
    prefix = l1l1ll1l1_opy_(Addon)
    sys.path.insert(0, path)
    import api
    api.login()
    doJSON(addon)
    HOME  = dixie.PROFILE
    l1l1l1l11_opy_ = os.path.join(HOME, l1l11_opy_ (u"ࠨ࡫ࡱ࡭ࠬࣁ"))
    l1ll1ll11_opy_  = str(addon).split(l1l11_opy_ (u"ࠩ࠱ࠫࣂ"))[2] + l1l11_opy_ (u"ࠪ࠲࡮ࡴࡩࠨࣃ")
    l1ll11111_opy_   = os.path.join(l1l1l1l11_opy_, l1ll1ll11_opy_)
    response = doJSON(addon)
    l1ll1l111_opy_ = response[l1l11_opy_ (u"ࠫࡧࡵࡤࡺࠩࣄ")]
    l1lll11ll_opy_  = l1l11_opy_ (u"ࠬࡡࠧࣅ") + addon + l1l11_opy_ (u"࠭࡝࡝ࡰࠪࣆ")
    l1ll11lll_opy_  =  file(l1ll11111_opy_, l1l11_opy_ (u"ࠧࡸࠩࣇ"))
    l1ll11lll_opy_.write(l1lll11ll_opy_)
    l1llll1ll_opy_ = []
    for channel in l1ll1l111_opy_:
        category =  channel[l1l11_opy_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪࣈ")]
        l1l1l11l1_opy_  = l1l11_opy_ (u"ࠩ࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭ࠡࠩࣉ") + category + l1l11_opy_ (u"ࠪࠤ࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯ࡀࠫ࣊")
        l1lll1ll1_opy_    =  channel[l1l11_opy_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ࣋")]
        l11111ll_opy_ =  l1l1lll11_opy_(l1lll1ll1_opy_, category)
        if (l11111ll_opy_ == l1l11_opy_ (u"࡚ࠬࡖࠡ࠵ࠣࡗࡊ࠭࣌")) or (l11111ll_opy_ == l1l11_opy_ (u"࠭ࡔࡗࠢ࠷ࠤࡘࡋࠧ࣍")) or (l11111ll_opy_ == l1l11_opy_ (u"ࠧࡕࡘࠣ࠷ࠥࡊࡋࠨ࣎")) or (l11111ll_opy_ == l1l11_opy_ (u"ࠨࡖ࡙ࠤ࠹ࠦࡄࡌ࣏ࠩ")):
            stream   =  prefix + l11111ll_opy_
        else:
            stream   =  prefix + l1lll1ll1_opy_
        l1lllll1l_opy_  =  l11111ll_opy_ + l1l11_opy_ (u"ࠩࡀ࣐ࠫ") + stream
        if l1l1l11l1_opy_ not in l1llll1ll_opy_:
            l1llll1ll_opy_.append(l1l1l11l1_opy_)
        if l1lllll1l_opy_ not in l1llll1ll_opy_:
            l1llll1ll_opy_.append(l1lllll1l_opy_)
    for item in l1llll1ll_opy_:
        l1ll11lll_opy_.write(l1l11_opy_ (u"ࠥࠩࡸࡢ࡮࣑ࠣ") % item)
    l1ll11lll_opy_.close()
def l1l1ll1l1_opy_(Addon):
    l1l1l1ll1_opy_ = Addon.getAddonInfo(l1l11_opy_ (u"ࠫࡳࡧ࡭ࡦ࣒ࠩ"))
    l1l1l1ll1_opy_ = l1l1l1ll1_opy_.replace(l1l11_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡽࡨࡪࡶࡨࡡ࣓ࠬ"), l1l11_opy_ (u"࠭ࠧࣔ")).replace(l1l11_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࣕ"), l1l11_opy_ (u"ࠨࠩࣖ"))
    if l1l1l1ll1_opy_ == l1l11_opy_ (u"ࠩࡖࡑࡆࡘࡔࡉࡗࡅࠫࣗ"):
        return l1l11_opy_ (u"ࠪࡌࡉ࡚ࡖ࠻ࠩࣘ")
    if l1l1l1ll1_opy_ == l1l11_opy_ (u"ࠫࡗࡻࡹࡢࠢࡌࡔ࡙࡜ࠧࣙ"):
        return l1l11_opy_ (u"ࠬࡎࡄࡕࡘ࠵࠾ࠬࣚ")
def l1l1lll11_opy_(l1lll1ll1_opy_, category):
    if (l1lll1ll1_opy_ == l1l11_opy_ (u"࠭ࡔࡗ࠵ࠪࣛ")) and (category == l1l11_opy_ (u"ࠧࡔࡹࡨࡨ࡮ࡹࡨࠡࡉࡨࡲࡪࡸࡡ࡭ࠩࣜ")):
        return l1l11_opy_ (u"ࠨࡖ࡙ࠤ࠸ࠦࡓࡆࠩࣝ")
    if (l1lll1ll1_opy_ == l1l11_opy_ (u"ࠩࡗ࡚࠹࠭ࣞ")) and (category == l1l11_opy_ (u"ࠪࡗࡼ࡫ࡤࡪࡵ࡫ࠤࡌ࡫࡮ࡦࡴࡤࡰࠬࣟ")):
        return l1l11_opy_ (u"࡙ࠫ࡜ࠠ࠵ࠢࡖࡉࠬ࣠")
    if (l1lll1ll1_opy_ == l1l11_opy_ (u"࡚ࠬࡖ࠴ࠩ࣡")) and (category == l1l11_opy_ (u"࠭ࡄࡦࡰࡰࡥࡷࡱࠠࡈࡧࡱࡩࡷࡧ࡬ࠨ࣢")):
        return l1l11_opy_ (u"ࠧࡕࡘࠣ࠷ࠥࡊࡋࠨࣣ")
    if (l1lll1ll1_opy_ == l1l11_opy_ (u"ࠨࡖ࡙࠸ࠬࣤ")) and (category == l1l11_opy_ (u"ࠩࡇࡩࡳࡳࡡࡳ࡭ࠣࡋࡪࡴࡥࡳࡣ࡯ࠫࣥ")):
        return l1l11_opy_ (u"ࠪࡘ࡛ࠦ࠴ࠡࡆࡎࣦࠫ")
    return dixie.mapChannelName(l1lll1ll1_opy_)
def getURL(url):
    if url.startswith(l1l11_opy_ (u"ࠫࡍࡊࡔࡗ࠼ࠪࣧ")):
        addon = l1l1l1l1l_opy_
    else:
        addon = l1l1l11ll_opy_
    Addon = xbmcaddon.Addon(id=addon)
    path  = Addon.getAddonInfo(l1l11_opy_ (u"ࠬࡶࡡࡵࡪࠪࣨ"))
    sys.path.insert(0, path)
    import api
    api.login()
    channel   = url.split(l1l11_opy_ (u"࠭࠺ࠨࣩ"), 1)[-1]
    l1l1ll111_opy_ = l1l1ll1ll_opy_(channel, addon)
    response  = api.remote_call( l1l11_opy_ (u"ࠢࡴࡶࡵࡩࡦࡳ࠯ࡨࡧࡷ࠲ࡵ࡮ࡰࠣ࣪") , { l1l11_opy_ (u"ࠣࡶࠥ࣫") : l1l11_opy_ (u"ࠤࡦ࡬ࡦࡴ࡮ࡦ࡮ࠥ࣬") , l1l11_opy_ (u"ࠥ࡭ࡩࠨ࣭") : l1l1ll111_opy_ } )
    return response[l1l11_opy_ (u"ࠦࡧࡵࡤࡺࠤ࣮")][l1l11_opy_ (u"ࠧࡻࡲ࡭ࠤ࣯")]
def l1l1ll1ll_opy_(channel, addon):
    PATH = l1l1l1lll_opy_(addon)
    if os.path.exists(PATH):
        response = json.load(open(PATH))
    else:
        response = doJSON(addon)
    items = response[l1l11_opy_ (u"ࠨࡢࡰࡦࡼࣰࠦ")]
    for item in items:
        if channel == l1l11_opy_ (u"ࠧࡕࡘࠣ࠷࡙ࠥࡅࠨࣱ"):
            if (item[l1l11_opy_ (u"ࠣࡥࡤࡸࡪ࡭࡯ࡳࡻࣲࠥ")] == l1l11_opy_ (u"ࠩࡖࡻࡪࡪࡩࡴࡪࠣࡋࡪࡴࡥࡳࡣ࡯ࠫࣳ")) and (item[l1l11_opy_ (u"ࠥࡸ࡮ࡺ࡬ࡦࠤࣴ")] == l1l11_opy_ (u"࡙ࠫ࡜࠳ࠨࣵ")):
                return item[l1l11_opy_ (u"ࠧ࡯ࡤࣶࠣ")]
        if channel == l1l11_opy_ (u"࠭ࡔࡗࠢ࠶ࠤࡉࡑࠧࣷ"):
            if (item[l1l11_opy_ (u"ࠢࡤࡣࡷࡩ࡬ࡵࡲࡺࠤࣸ")] == l1l11_opy_ (u"ࠨࡆࡨࡲࡲࡧࡲ࡬ࠢࡊࡩࡳ࡫ࡲࡢ࡮ࣹࠪ")) and (item[l1l11_opy_ (u"ࠤࡷ࡭ࡹࡲࡥࣺࠣ")] == l1l11_opy_ (u"ࠪࡘ࡛࠹ࠧࣻ")):
                return item[l1l11_opy_ (u"ࠦ࡮ࡪࠢࣼ")]
        if channel == l1l11_opy_ (u"࡚ࠬࡖࠡ࠶ࠣࡗࡊ࠭ࣽ"):
            if (item[l1l11_opy_ (u"ࠨࡣࡢࡶࡨ࡫ࡴࡸࡹࠣࣾ")] == l1l11_opy_ (u"ࠧࡔࡹࡨࡨ࡮ࡹࡨࠡࡉࡨࡲࡪࡸࡡ࡭ࠩࣿ")) and (item[l1l11_opy_ (u"ࠣࡶ࡬ࡸࡱ࡫ࠢऀ")] == l1l11_opy_ (u"ࠩࡗ࡚࠹࠭ँ")):
                return item[l1l11_opy_ (u"ࠥ࡭ࡩࠨं")]
        if channel == l1l11_opy_ (u"࡙ࠫ࡜ࠠ࠵ࠢࡇࡏࠬः"):
            if (item[l1l11_opy_ (u"ࠧࡩࡡࡵࡧࡪࡳࡷࡿࠢऄ")] == l1l11_opy_ (u"࠭ࡄࡦࡰࡰࡥࡷࡱࠠࡈࡧࡱࡩࡷࡧ࡬ࠨअ")) and (item[l1l11_opy_ (u"ࠢࡵ࡫ࡷࡰࡪࠨआ")] == l1l11_opy_ (u"ࠨࡖ࡙࠸ࠬइ")):
                return item[l1l11_opy_ (u"ࠤ࡬ࡨࠧई")]
        if channel == item[l1l11_opy_ (u"ࠥࡸ࡮ࡺ࡬ࡦࠤउ")]:
            return item[l1l11_opy_ (u"ࠦ࡮ࡪࠢऊ")]
def doJSON(addon):
    try:
        Addon = xbmcaddon.Addon(id=addon)
        path  = Addon.getAddonInfo(l1l11_opy_ (u"ࠬࡶࡡࡵࡪࠪऋ"))
        sys.path.insert(0, path)
        import api
        PATH    = l1l1l1lll_opy_(addon)
        content = api.remote_call( l1l11_opy_ (u"ࠨࡣࡩࡣࡱࡲࡪࡲࡳ࠰࡮࡬ࡷࡹ࠴ࡰࡩࡲࠥऌ") , {l1l11_opy_ (u"ࠧࡢࠩऍ"): l1l11_opy_ (u"ࠨ࠲ࠪऎ"), l1l11_opy_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪए"): l1l11_opy_ (u"ࠪࡥࡱࡲࠧऐ")} )
        json.dump(content, open(PATH,l1l11_opy_ (u"ࠫࡼ࠭ऑ")), indent=3)
        return json.load(open(PATH))
    except:
        return l1l11_opy_ (u"ࠬࢁࠢࡣࡱࡧࡽࠧࡀࠠ࡜ࡽࠥࡧࡦࡺࡥࡨࡱࡵࡽࠧࡀࠠࠣࠤ࠯ࠤࠧࡩࡵࡳࡴࡨࡲࡹࡥࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠦ࠿ࠦࠢࠣ࠮ࠣࠦࡨࡻࡲࡳࡧࡱࡸࡤࡺࡩࡵ࡮ࡨࠦ࠿ࠦࠢࠣ࠮ࠣࠦࡳ࡫ࡸࡵࡡ࡯ࡳࡨࡧ࡬ࡠࡵࡷࡥࡷࡺࠢ࠻ࠢࡱࡹࡱࡲࠬࠡࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠣࠦࠧ࠲ࠠࠣࡨࡤࡺࡴࡸࡩࡵࡧࠥ࠾ࠥࠨ࠰ࠣ࠮ࠣࠦࡨࡻࡲࡳࡧࡱࡸࡤࡲ࡯ࡤࡣ࡯ࡣࡸࡺࡡࡳࡶࠥ࠾ࠥࡴࡵ࡭࡮࠯ࠤࠧ࡯ࡤࠣ࠼ࠣࠦࠧ࠲ࠠࠣࡰࡨࡼࡹࡥࡴࡪࡶ࡯ࡩࠧࡀࠠࠣࠤࢀࡡ࠱ࠦࠢࡦࡴࡵࡳࡷࡥ࡭ࡦࡵࡶࡥ࡬࡫ࠢ࠻ࠢࠥࠦ࠱ࠦࠢࡦࡴࡵࡳࡷࡥࡣࡰࡦࡨࠦ࠿ࠦࠢ࠳࠲࠳ࠦ࠱ࠦࠢࡦࡴࡵࡳࡷࠨ࠺ࠡࡨࡤࡰࡸ࡫ࡽࠨऒ")
if __name__ == l1l11_opy_ (u"࠭࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠨओ"):
    checkAddons()