# coding: UTF-8
import sys
l1l1111_opy_ = sys.version_info [0] == 2
l11111_opy_ = 2048
l1111_opy_ = 7
def l11ll1_opy_ (ll_opy_):
	global l1111l_opy_
	l1l111l_opy_ = ord (ll_opy_ [-1])
	l111ll_opy_ = ll_opy_ [:-1]
	l1ll1l1_opy_ = l1l111l_opy_ % len (l111ll_opy_)
	l1ll1_opy_ = l111ll_opy_ [:l1ll1l1_opy_] + l111ll_opy_ [l1ll1l1_opy_:]
	if l1l1111_opy_:
		l1lll1l_opy_ = unicode () .join ([unichr (ord (char) - l11111_opy_ - (l11lll_opy_ + l1l111l_opy_) % l1111_opy_) for l11lll_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1lll1l_opy_ = str () .join ([chr (ord (char) - l11111_opy_ - (l11lll_opy_ + l1l111l_opy_) % l1111_opy_) for l11lll_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1lll1l_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l1l11l111_opy_    = l11ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡮ࡵࡸࠪࣿ")
l1l111111_opy_ = l11ll1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡸ࡮࡬ࡴࡹࡼࠧऀ")
l1l11l1ll_opy_    = l11ll1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡷ࡮ࡸࡺࡸ࡫ࠨँ")
locked = l11ll1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡯ࡳࡨࡱࡥࡥࡶࡹࠫं")
l1l111lll_opy_     = l11ll1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡹࡱࡺࡩ࡮ࡣࡷࡩࡲࡧ࡮ࡪࡣࠪः")
l1l11ll11_opy_   = l11ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡱ࡯ࡵࡹ࠰ࡷࡺࠬऄ")
l11lllll1_opy_    = l11ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡊࡃࡔࡲࡲࡶࡹࡹࠧअ")
l1l11llll_opy_ = l11ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡦࡤࡲࡳࡹ࠭आ")
l1l11111l_opy_    = l11ll1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡤ࡮ࡸ࡭ࡵࡺࡶࠨइ")
l1l111l11_opy_ = l11ll1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࡯ࡰࡵࡸࠪई")
l11l1ll_opy_ = [l1l11l111_opy_, locked, l1l11ll11_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l11ll1_opy_ (u"ࠪ࡭ࡳ࡯ࠧउ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1l11ll_opy_ = l11ll1_opy_ (u"ࠫࠬऊ")
def l11l1l1_opy_(i, t1, l1l11l1_opy_=[]):
 t = l1l11ll_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l11l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1l1l_opy_ = l11l1l1_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11_opy_ = l11l1l1_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l11l1ll_opy_:
        if l11ll1l_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l11ll1l_opy_(addon):
    if xbmc.getCondVisibility(l11ll1_opy_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠦࡵࠬࠫऋ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l1lllll_opy_ = str(addon).split(l11ll1_opy_ (u"࠭࠮ࠨऌ"))[2] + l11ll1_opy_ (u"ࠧ࠯࡫ࡱ࡭ࠬऍ")
    l1l_opy_  = os.path.join(PATH, l1lllll_opy_)
    try:
        l1l1ll1_opy_ = l1_opy_(addon)
    except KeyError:
        dixie.log(l11ll1_opy_ (u"ࠨ࠯࠰࠱࠲࠳ࠠࡌࡧࡼࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥ࡭ࡥࡵࡈ࡬ࡰࡪࡹࠠ࠮࠯࠰࠱࠲ࠦࠧऎ") + addon)
        result = {l11ll1_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࡴࠩए"): [{l11ll1_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭ऐ"): l11ll1_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࠪऑ"), l11ll1_opy_ (u"ࡺ࠭ࡴࡺࡲࡨࠫऒ"): l11ll1_opy_ (u"ࡻࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨओ"), l11ll1_opy_ (u"ࡵࠨࡨ࡬ࡰࡪ࠭औ"): l11ll1_opy_ (u"ࡶࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡽࡾࠧक"), l11ll1_opy_ (u"ࡷࠪࡰࡦࡨࡥ࡭ࠩख"): l11ll1_opy_ (u"ࡸࠫࡓࡕࠠࡄࡊࡄࡒࡓࡋࡌࡔࠩग")}], l11ll1_opy_ (u"ࡹࠬࡲࡩ࡮࡫ࡷࡷࠬघ"):{l11ll1_opy_ (u"ࡺ࠭ࡳࡵࡣࡵࡸࠬङ"): 0, l11ll1_opy_ (u"ࡻࠧࡵࡱࡷࡥࡱ࠭च"): 1, l11ll1_opy_ (u"ࡵࠨࡧࡱࡨࠬछ"): 1}}
    l11l11_opy_  = l11ll1_opy_ (u"ࠨ࡝ࠪज") + addon + l11ll1_opy_ (u"ࠩࡠࡠࡳ࠭झ")
    l1l1l1l_opy_  =  file(l1l_opy_, l11ll1_opy_ (u"ࠪࡻࠬञ"))
    l1l1l1l_opy_.write(l11l11_opy_)
    l1ll1l_opy_ = []
    for channel in l1l1ll1_opy_:
        l1l111_opy_ = dixie.cleanLabel(channel[l11ll1_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪट")])
        l1lll_opy_ = dixie.mapChannelName(l1l111_opy_)
        stream   = channel[l11ll1_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪठ")]
        l11ll_opy_ = l1lll_opy_ + l11ll1_opy_ (u"࠭࠽ࠨड") + stream
        l1ll1l_opy_.append(l11ll_opy_)
        l1ll1l_opy_.sort()
    for item in l1ll1l_opy_:
        l1l1l1l_opy_.write(l11ll1_opy_ (u"ࠢࠦࡵ࡟ࡲࠧढ") % item)
    l1l1l1l_opy_.close()
def l1_opy_(addon):
    if (addon == l1l11l111_opy_) or (addon == l1l111111_opy_) or (addon == l1l111l11_opy_):
        try:
            if xbmcaddon.Addon(addon).getSetting(l11ll1_opy_ (u"ࠨࡩࡨࡲࡷ࡫ࠧण")) == l11ll1_opy_ (u"ࠩࡷࡶࡺ࡫ࠧत"):
                xbmcaddon.Addon(addon).setSetting(l11ll1_opy_ (u"ࠪ࡫ࡪࡴࡲࡦࠩथ"), l11ll1_opy_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪद"))
                xbmcgui.Window(10000).setProperty(l11ll1_opy_ (u"ࠬࡖࡌࡖࡉࡌࡒࡤࡍࡅࡏࡔࡈࠫध"), l11ll1_opy_ (u"࠭ࡔࡳࡷࡨࠫन"))
            if xbmcaddon.Addon(addon).getSetting(l11ll1_opy_ (u"ࠧࡵࡸࡪࡹ࡮ࡪࡥࠨऩ")) == l11ll1_opy_ (u"ࠨࡶࡵࡹࡪ࠭प"):
                xbmcaddon.Addon(addon).setSetting(l11ll1_opy_ (u"ࠩࡷࡺ࡬ࡻࡩࡥࡧࠪफ"), l11ll1_opy_ (u"ࠪࡪࡦࡲࡳࡦࠩब"))
                xbmcgui.Window(10000).setProperty(l11ll1_opy_ (u"ࠫࡕࡒࡕࡈࡋࡑࡣ࡙࡜ࡇࡖࡋࡇࡉࠬभ"), l11ll1_opy_ (u"࡚ࠬࡲࡶࡧࠪम"))
        except: pass
        l1l1ll1ll_opy_  = l11ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩय") + addon
        l1l111l1l_opy_ =  l1l11lll1_opy_(addon)
        query   =  l1l1ll1ll_opy_ + l1l111l1l_opy_
        return sendJSON(query, addon)
    return l1l1l1111_opy_(addon)
def l1l1l1111_opy_(addon):
    if addon == l1l11ll11_opy_:
        l1l1l111l_opy_ = [l11ll1_opy_ (u"ࠧ࠶ࠩर"), l11ll1_opy_ (u"ࠨ࠳࠳࠺ࠬऱ"), l11ll1_opy_ (u"ࠩ࠷ࠫल"), l11ll1_opy_ (u"ࠪ࠶࠻࠹ࠧळ"), l11ll1_opy_ (u"ࠫ࠶࠹࠲ࠨऴ")]
    if addon == locked:
        l1l1l111l_opy_ = [l11ll1_opy_ (u"ࠬ࠹࠰ࠨव"), l11ll1_opy_ (u"࠭࠳࠲ࠩश"), l11ll1_opy_ (u"ࠧ࠴࠴ࠪष"), l11ll1_opy_ (u"ࠨ࠵࠶ࠫस"), l11ll1_opy_ (u"ࠩ࠶࠸ࠬह"), l11ll1_opy_ (u"ࠪ࠷࠺࠭ऺ"), l11ll1_opy_ (u"ࠫ࠸࠾ࠧऻ"), l11ll1_opy_ (u"ࠬ࠺࠰ࠨ़"), l11ll1_opy_ (u"࠭࠴࠲ࠩऽ"), l11ll1_opy_ (u"ࠧ࠵࠷ࠪा"), l11ll1_opy_ (u"ࠨ࠶࠺ࠫि"), l11ll1_opy_ (u"ࠩ࠷࠽ࠬी"), l11ll1_opy_ (u"ࠪ࠹࠷࠭ु")]
    if addon == l1l111lll_opy_:
        l1l1l111l_opy_ = [l11ll1_opy_ (u"ࠫ࠷࠻ࠧू"), l11ll1_opy_ (u"ࠬ࠸࠶ࠨृ"), l11ll1_opy_ (u"࠭࠲࠸ࠩॄ"), l11ll1_opy_ (u"ࠧ࠳࠻ࠪॅ"), l11ll1_opy_ (u"ࠨ࠵࠳ࠫॆ"), l11ll1_opy_ (u"ࠩ࠶࠵ࠬे"), l11ll1_opy_ (u"ࠪ࠷࠷࠭ै"), l11ll1_opy_ (u"ࠫ࠸࠻ࠧॉ"), l11ll1_opy_ (u"ࠬ࠹࠶ࠨॊ"), l11ll1_opy_ (u"࠭࠳࠸ࠩो"), l11ll1_opy_ (u"ࠧ࠴࠺ࠪौ"), l11ll1_opy_ (u"ࠨ࠵࠼्ࠫ"), l11ll1_opy_ (u"ࠩ࠷࠴ࠬॎ"), l11ll1_opy_ (u"ࠪ࠸࠶࠭ॏ"), l11ll1_opy_ (u"ࠫ࠹࠾ࠧॐ"), l11ll1_opy_ (u"ࠬ࠺࠹ࠨ॑"), l11ll1_opy_ (u"࠭࠵࠱॒ࠩ"), l11ll1_opy_ (u"ࠧ࠶࠴ࠪ॓"), l11ll1_opy_ (u"ࠨ࠷࠷ࠫ॔"), l11ll1_opy_ (u"ࠩ࠸࠺ࠬॕ"), l11ll1_opy_ (u"ࠪ࠹࠼࠭ॖ"), l11ll1_opy_ (u"ࠫ࠺࠾ࠧॗ"), l11ll1_opy_ (u"ࠬ࠻࠹ࠨक़"), l11ll1_opy_ (u"࠭࠶࠱ࠩख़"), l11ll1_opy_ (u"ࠧ࠷࠳ࠪग़"), l11ll1_opy_ (u"ࠨ࠸࠵ࠫज़"), l11ll1_opy_ (u"ࠩ࠹࠷ࠬड़"), l11ll1_opy_ (u"ࠪ࠺࠺࠭ढ़"), l11ll1_opy_ (u"ࠫ࠻࠼ࠧफ़"), l11ll1_opy_ (u"ࠬ࠼࠷ࠨय़"), l11ll1_opy_ (u"࠭࠶࠺ࠩॠ"), l11ll1_opy_ (u"ࠧ࠸࠲ࠪॡ"), l11ll1_opy_ (u"ࠨ࠹࠷ࠫॢ"), l11ll1_opy_ (u"ࠩ࠺࠻ࠬॣ"), l11ll1_opy_ (u"ࠪ࠻࠽࠭।"), l11ll1_opy_ (u"ࠫ࠽࠶ࠧ॥"), l11ll1_opy_ (u"ࠬ࠾࠱ࠨ०")]
    login = l11ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶ࠳ࠬ१") % addon
    sendJSON(login, addon)
    l111l1_opy_ = []
    for l1l1ll111_opy_ in l1l1l111l_opy_:
        if addon == l1l11ll11_opy_:
            query = l11ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷ࠴ࡅ࡭ࡰࡦࡨࡣ࡮ࡪ࠽ࡤࡪࡤࡲࡳ࡫࡬ࡴࠨࡰࡳࡩ࡫࠽ࡤࡪࡤࡲࡳ࡫࡬ࡴࠨࡶࡩࡨࡺࡩࡰࡰࡢ࡭ࡩࡃࠥࡴࠩ२") % (addon, l1l1ll111_opy_)
        if (addon == locked) or (addon == l1l111lll_opy_):
            query = l11ll1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸ࠵࠿ࡶࡴ࡯ࡁࠪࡹࠦ࡮ࡱࡧࡩࡂ࠺ࠦ࡯ࡣࡰࡩࡂࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࠩࡴࡱࡧࡹ࠾ࠨࡧࡥࡹ࡫࠽ࠧࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࡃࠦࡱࡣࡪࡩࡂ࠭३") % (addon, l1l1ll111_opy_)
        response = sendJSON(query, addon)
        l111l1_opy_.extend(response)
    return l111l1_opy_
def sendJSON(query, addon):
    l1l1l1l1l_opy_     = l11ll1_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬ४") % query
    l1l1ll11l_opy_  = xbmc.executeJSONRPC(l1l1l1l1l_opy_)
    response = json.loads(l1l1ll11l_opy_)
    result   = response[l11ll1_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪ५")]
    if xbmcgui.Window(10000).getProperty(l11ll1_opy_ (u"ࠫࡕࡒࡕࡈࡋࡑࡣࡌࡋࡎࡓࡇࠪ६")) == l11ll1_opy_ (u"࡚ࠬࡲࡶࡧࠪ७"):
        xbmcaddon.Addon(addon).setSetting(l11ll1_opy_ (u"࠭ࡧࡦࡰࡵࡩࠬ८"), l11ll1_opy_ (u"ࠧࡵࡴࡸࡩࠬ९"))
    if xbmcgui.Window(10000).getProperty(l11ll1_opy_ (u"ࠨࡒࡏ࡙ࡌࡏࡎࡠࡖ࡙ࡋ࡚ࡏࡄࡆࠩ॰")) == l11ll1_opy_ (u"ࠩࡗࡶࡺ࡫ࠧॱ"):
        xbmcaddon.Addon(addon).setSetting(l11ll1_opy_ (u"ࠪࡸࡻ࡭ࡵࡪࡦࡨࠫॲ"), l11ll1_opy_ (u"ࠫࡹࡸࡵࡦࠩॳ"))
    return result[l11ll1_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫॴ")]
def l1l11lll1_opy_(addon):
    if (addon == l1l11l111_opy_) or (addon == l1l111111_opy_):
        return l11ll1_opy_ (u"࠭࠯ࡀࡥࡤࡸࡂ࠳࠲ࠧࡦࡤࡸࡪࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠪࡪࡴࡤࡅࡣࡷࡩࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡰࡳࡩ࡫࠽࠳ࠨࡱࡥࡲ࡫࠽ࡎࡻࠨ࠶࠵ࡉࡨࡢࡰࡱࡩࡱࡹࠦࡳࡧࡦࡳࡷࡪ࡮ࡢ࡯ࡨࠪࡸࡺࡡࡳࡶࡇࡥࡹ࡫ࠦࡶࡴ࡯ࡁࡺࡸ࡬ࠨॵ")
    if addon == l1l111l11_opy_:
        return l11ll1_opy_ (u"ࠧ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿࡯࡭ࡻ࡫ࡴࡷࡡࡤࡰࡱࠬࡥࡹࡶࡵࡥࠫࡶࡡࡨࡧࠩࡴࡱࡵࡴࠧࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡁࠫࡺࡩࡵ࡮ࡨࡁࡆࡲ࡬ࠦ࠴࠳ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡻࡲ࡭ࠩॶ")
    return l11ll1_opy_ (u"ࠨࠩॷ")
def l111l_opy_():
    modules = map(__import__, [l11l1l1_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1l1l_opy_)):
        return l11ll1_opy_ (u"ࠩࡗࡶࡺ࡫ࠧॸ")
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l11ll1_opy_ (u"ࠪࡘࡷࡻࡥࠨॹ")
    return l11ll1_opy_ (u"ࠫࡋࡧ࡬ࡴࡧࠪॺ")
def l1ll111_opy_(e, addon):
    l1l11l_opy_ = l11ll1_opy_ (u"࡙ࠬ࡯ࡳࡴࡼ࠰ࠥࡧ࡮ࠡࡧࡵࡶࡴࡸࠠࡰࡥࡦࡹࡷ࡫ࡤ࠻ࠢࡍࡗࡔࡔࠠࡆࡴࡵࡳࡷࡀࠠࠦࡵ࠯ࠤࠪࡹࠧॻ")  % (e, addon)
    l11l1_opy_ = l11ll1_opy_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡣࡰࡰࡷࡥࡨࡺࠠࡶࡵࠣࡳࡳࠦࡴࡩࡧࠣࡪࡴࡸࡵ࡮࠰ࠪॼ")
    l1l1ll_opy_ = l11ll1_opy_ (u"ࠧࡖࡲ࡯ࡳࡦࡪࠠࡢࠢ࡯ࡳ࡬ࠦࡶࡪࡣࠣࡸ࡭࡫ࠠࡢࡦࡧࡳࡳࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠡࡣࡱࡨࠥࡶ࡯ࡴࡶࠣࡸ࡭࡫ࠠ࡭࡫ࡱ࡯࠳࠭ॽ")
    dixie.log(addon)
    dixie.log(e)
def getPluginInfo(streamurl):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l1l11l11l_opy_   = l11ll1_opy_ (u"ࠨࡍࡲࡨ࡮ࠦࡐࡗࡔࠪॾ")
            l1l11l1l1_opy_ = os.path.join(dixie.RESOURCES, l11ll1_opy_ (u"ࠩ࡮ࡳࡩ࡯࠭ࡱࡸࡵ࠲ࡵࡴࡧࠨॿ"))
            return l1l11l11l_opy_, l1l11l1l1_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l11ll1_opy_ (u"ࠪࡶࡹࡳࡰࠨঀ")) or url.startswith(l11ll1_opy_ (u"ࠫࡷࡺ࡭ࡱࡧࠪঁ")) or url.startswith(l11ll1_opy_ (u"ࠬࡸࡴࡴࡲࠪং")) or url.startswith(l11ll1_opy_ (u"࠭ࡨࡵࡶࡳࠫঃ")):
            l1l11l11l_opy_   = l11ll1_opy_ (u"ࠧ࡮࠵ࡸࠤࡕࡲࡡࡺ࡮࡬ࡷࡹ࠭঄")
            l1l11l1l1_opy_ = os.path.join(dixie.RESOURCES, l11ll1_opy_ (u"ࠨ࡫ࡳࡸࡻ࠳ࡰ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡲࡱ࡫ࠬঅ"))
            return l1l11l11l_opy_, l1l11l1l1_opy_
    except:
        pass
    if streamurl.startswith(l11ll1_opy_ (u"ࠩࡳࡺࡷࡀ࠯࠰ࠩআ")):
        l1l11l11l_opy_   = l11ll1_opy_ (u"ࠪࡏࡴࡪࡩࠡࡒ࡙ࡖࠬই")
        l1l11l1l1_opy_ = os.path.join(dixie.RESOURCES, l11ll1_opy_ (u"ࠫࡰࡵࡤࡪ࠯ࡳࡺࡷ࠴ࡰ࡯ࡩࠪঈ"))
        return l1l11l11l_opy_, l1l11l1l1_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        l1l111ll1_opy_ = streamurl.split(l11ll1_opy_ (u"ࠬࡣࡏࡕࡖࡢࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭উ"), 1)[-1].split(l11ll1_opy_ (u"࠭࠯ࠨঊ"), 1)[0]
    if l11ll1_opy_ (u"ࠧ࡞ࡑࡗࡘࡤࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨঋ") in streamurl:
        l1l111ll1_opy_ = streamurl.split(l11ll1_opy_ (u"ࠨ࡟ࡒࡘ࡙ࡥࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩঌ"), 1)[-1].split(l11ll1_opy_ (u"ࠩ࠲ࠫ঍"), 1)[0]
    if streamurl.startswith(l11ll1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭঎")):
        l1l111ll1_opy_ = streamurl.split(l11ll1_opy_ (u"ࠫ࠴࠵ࠧএ"), 1)[-1].split(l11ll1_opy_ (u"ࠬ࠵ࠧঐ"), 1)[0]
    if l11ll1_opy_ (u"࠭࡟ࡠࡕࡉࡣࡤ࠭঑") in streamurl:
        l1l111ll1_opy_ = l11ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡱࡴࡲ࡫ࡷࡧ࡭࠯ࡵࡸࡴࡪࡸ࠮ࡧࡣࡹࡳࡺࡸࡩࡵࡧࡶࠫ঒")
    if l11ll1_opy_ (u"ࠨࡊࡇࡘ࡛ࡀࠧও") in streamurl:
        l1l111ll1_opy_ = l11ll1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡰࡥࡷࡺࡨࡶࡤࠪঔ")
    if l11ll1_opy_ (u"ࠪࡌࡉ࡚ࡖ࠳࠼ࠪক") in streamurl:
        l1l111ll1_opy_ = l11ll1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡺࡿࡡ࠳ࠩখ")
    if l11ll1_opy_ (u"ࠬࡎࡄࡕࡘ࠶࠾ࠬগ") in streamurl:
        l1l111ll1_opy_ = l11ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡵࡺࡣ࠵ࠫঘ")
    if l11ll1_opy_ (u"ࠧࡉࡆࡗ࡚࠹ࡀࠧঙ") in streamurl:
        l1l111ll1_opy_ = l11ll1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡹ࡮ࠪচ")
    if l11ll1_opy_ (u"ࠩࡌࡔࡑࡇ࡙࠻ࠩছ") in streamurl:
        l1l111ll1_opy_ = l11ll1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡥࡦࡨ࡯ࡰ࡭ࡣࡼࡩࡷ࠭জ")
    if l11ll1_opy_ (u"ࠫࡎࡖࡌࡂ࡛࠵࠾ࠬঝ") in streamurl:
        l1l111ll1_opy_ = l11ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶ࡬ࡢࡻࡨࡶࡼࡽࡷࠨঞ")
    if l11ll1_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡗࡀࠧট") in streamurl:
        l1l111ll1_opy_ = l11ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱ࡮ࡤࡽࡪࡸࡷࡸࡹࠪঠ")
    if l11ll1_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡉࡕࡘ࠽ࠫড") in streamurl:
        l1l111ll1_opy_ = l11ll1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡷࡺࠬঢ")
    if l11ll1_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡆ࠽ࠫণ") in streamurl:
        l1l111ll1_opy_ = l11ll1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡨࡪࡾࠧত")
    if l11ll1_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖࡇࡀࠧথ") in streamurl:
        l1l111ll1_opy_ = l11ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡥࡣࡱࡲࡸࠬদ")
    if l11ll1_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡉࡌࡖ࠼ࠪধ") in streamurl:
        l1l111ll1_opy_ = l11ll1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡤ࡮ࡸ࡭ࡵࡺࡶࠨন")
    if l11ll1_opy_ (u"ࠩࡌࡔ࡙࡙ࠧ঩") in streamurl:
        l1l111ll1_opy_ = l11ll1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧࡩࡱࡶࡹࠫপ")
    if l11ll1_opy_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠾ࠬফ") in streamurl:
        l1l111ll1_opy_ = l11ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡱ࡯ࡶࡦ࡯࡬ࡼࠬব")
    if l11ll1_opy_ (u"࠭ࡅࡏࡆ࠽ࠫভ") in streamurl:
        l1l111ll1_opy_ = l11ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡅ࡯ࡦ࡯ࡩࡸࡹࠧম")
    if l11ll1_opy_ (u"ࠨࡈࡏࡅ࠿࠭য") in streamurl:
        l1l111ll1_opy_ = l11ll1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡈ࡯ࡥࡼࡲࡥࡴࡵࡗࡺࠬর")
    if l11ll1_opy_ (u"ࠪࡊࡑࡇࡓ࠻ࠩ঱") in streamurl:
        l1l111ll1_opy_ = l11ll1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡊࡱࡧࡷ࡭ࡧࡶࡷ࡙ࡼࠧল")
    if l11ll1_opy_ (u"ࠬࡻࡰ࡯ࡲ࠽ࠫ঳") in streamurl:
        l1l111ll1_opy_ = l11ll1_opy_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴ࡨࡥࡪࡲࡱࡪࡸࡵ࡯࠰ࡹ࡭ࡪࡽࠧ঴")
    return l1l1111l1_opy_(l1l111ll1_opy_)
def l1l1111l1_opy_(l1l111ll1_opy_):
    l1l11l11l_opy_   = l11ll1_opy_ (u"ࠧࠨ঵")
    l1l11l1l1_opy_ = l11ll1_opy_ (u"ࠨࠩশ")
    if l1l111ll1_opy_ == l11ll1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡦࡨࡼࠬষ"):
        l1l11l11l_opy_   = l11ll1_opy_ (u"ࠪࡈࡪࡾࡴࡦࡴࡗ࡚ࠥࡒࡩࡵࡧࠪস")
        l1l11l1l1_opy_ = xbmcaddon.Addon(l1l111ll1_opy_).getAddonInfo(l11ll1_opy_ (u"ࠫ࡮ࡩ࡯࡯ࠩহ"))
        return l1l11l11l_opy_, l1l11l1l1_opy_
    try:
        l1l11l11l_opy_   = xbmcaddon.Addon(l1l111ll1_opy_).getAddonInfo(l11ll1_opy_ (u"ࠬࡴࡡ࡮ࡧࠪ঺"))
        l1l11l1l1_opy_ = xbmcaddon.Addon(l1l111ll1_opy_).getAddonInfo(l11ll1_opy_ (u"࠭ࡩࡤࡱࡱࠫ঻"))
        return l1l11l11l_opy_, l1l11l1l1_opy_
    except:
        l1l11l11l_opy_   = l11ll1_opy_ (u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡕࡲࡹࡷࡩࡥࠨ়")
        l1l11l1l1_opy_ =  dixie.ICON
        return l1l11l11l_opy_, l1l11l1l1_opy_
    return l1l11l11l_opy_, l1l11l1l1_opy_
def selectStream(url, channel):
    l1l11ll1l_opy_ = url.split(l11ll1_opy_ (u"ࠨࡾࠪঽ"))
    if len(l1l11ll1l_opy_) == 0:
        return None
    options, l11ll11_opy_ = getOptions(l1l11ll1l_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l1l11ll1l_opy_) == 1:
            return l11ll11_opy_[0]
    import selectDialog
    l11llll1l_opy_ = selectDialog.select(l11ll1_opy_ (u"ࠩࡖࡩࡱ࡫ࡣࡵࠢࡤࠤࡸࡺࡲࡦࡣࡰࠫা"), options)
    if l11llll1l_opy_ < 0:
        raise Exception(l11ll1_opy_ (u"ࠪࡗࡪࡲࡥࡤࡶ࡬ࡳࡳࠦࡃࡢࡰࡦࡩࡱ࠭ি"))
    return l11ll11_opy_[l11llll1l_opy_]
def getOptions(l1l11ll1l_opy_, channel, addmore=True):
    options = []
    l11ll11_opy_    = []
    for index, stream in enumerate(l1l11ll1l_opy_):
        l1l11l11l_opy_ = getPluginInfo(stream)
        l1l111_opy_ = l1l11l11l_opy_[0]
        l11llllll_opy_  = l1l11l11l_opy_[1]
        l1l111_opy_ = l11ll1_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡴࡸࡡ࡯ࡩࡨࡡࡠ࠭ী") + l1l111_opy_ + l11ll1_opy_ (u"ࠬࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠡࠩু")
        if stream.startswith(OPEN_OTT):
            l1l1111ll_opy_ = stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l11ll1_opy_ (u"࠭ࠧূ"))
            l1l111_opy_  = l1l111_opy_ + l1l1111ll_opy_
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l11ll1_opy_ (u"ࠧࠨৃ"))
        else:
            l1l111_opy_  = l1l111_opy_ + channel
        options.append([l1l111_opy_, index, l11llllll_opy_])
        l11ll11_opy_.append(stream)
    if addmore:
        options.append([l11ll1_opy_ (u"ࠨࡃࡧࡨࠥࡳ࡯ࡳࡧ࠱࠲࠳࠭ৄ"), index + 1, dixie.ICON])
        l11ll11_opy_.append(l11ll1_opy_ (u"ࠩࡤࡨࡩࡓ࡯ࡳࡧࠪ৅"))
    return options, l11ll11_opy_
if __name__ == l11ll1_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬ৆"):
    checkAddons()