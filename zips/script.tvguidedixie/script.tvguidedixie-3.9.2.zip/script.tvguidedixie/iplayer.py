# coding: UTF-8
import sys
l1l1111_opy_ = sys.version_info [0] == 2
l11111_opy_ = 2048
l1111_opy_ = 7
def l11ll1_opy_ (ll_opy_):
	global l1111l_opy_
	l1l111l_opy_ = ord (ll_opy_ [-1])
	l111ll_opy_ = ll_opy_ [:-1]
	l1ll1l1_opy_ = l1l111l_opy_ % len (l111ll_opy_)
	l1ll1_opy_ = l111ll_opy_ [:l1ll1l1_opy_] + l111ll_opy_ [l1ll1l1_opy_:]
	if l1l1111_opy_:
		l1lll1l_opy_ = unicode () .join ([unichr (ord (char) - l11111_opy_ - (l11lll_opy_ + l1l111l_opy_) % l1111_opy_) for l11lll_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1lll1l_opy_ = str () .join ([chr (ord (char) - l11111_opy_ - (l11lll_opy_ + l1l111l_opy_) % l1111_opy_) for l11lll_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1lll1l_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
ADDON    = dixie.ADDON
l1l1l1_opy_ = dixie.PROFILE
l1ll11l_opy_  = os.path.join(l1l1l1_opy_, l11ll1_opy_ (u"ࠫ࡮ࡴࡩࠨࠀ"))
l1l11ll_opy_ = l11ll1_opy_ (u"ࠬ࠭ࠁ")
def l11l1l1_opy_(i, t1, l1l11l1_opy_=[]):
 t = l1l11ll_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l11l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1l1l_opy_ = l11l1l1_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11_opy_ = l11l1l1_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1l1lll_opy_  = l11ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡋ࡮ࡥ࡮ࡨࡷࡸ࠭ࠂ")
l1lll11_opy_ = l11ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡆ࡭ࡣࡺࡰࡪࡹࡳࡕࡸࠪࠃ")
dexter   = l11ll1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡥࡧࡻࠫࠄ")
l11l1ll_opy_   = [l1l1lll_opy_, l1lll11_opy_, dexter]
def checkAddons():
    for addon in l11l1ll_opy_:
        if l11ll1l_opy_(addon):
            createINI(addon)
def l11ll1l_opy_(addon):
    if xbmc.getCondVisibility(l11ll1_opy_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡋࡥࡸࡇࡤࡥࡱࡱࠬࠪࡹࠩࠨࠅ") % addon) == 1:
        return True
    else:
        return False
def createINI(addon):
    HOME  = dixie.PROFILE
    l1ll11_opy_ = os.path.join(HOME, l11ll1_opy_ (u"ࠪ࡭ࡳ࡯ࠧࠆ"))
    l1lllll_opy_  = str(addon).split(l11ll1_opy_ (u"ࠫ࠳࠭ࠇ"))[2] + l11ll1_opy_ (u"ࠬ࠴ࡩ࡯࡫ࠪࠈ")
    l1l_opy_   = os.path.join(l1ll11_opy_, l1lllll_opy_)
    response = l1_opy_(addon)
    l1l1ll1_opy_ = response[l11ll1_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࠉ")][l11ll1_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࠊ")]
    l11l11_opy_  = l11ll1_opy_ (u"ࠨ࡝ࠪࠋ") + addon + l11ll1_opy_ (u"ࠩࡠࡠࡳ࠭ࠌ")
    l1l1l1l_opy_  =  file(l1l_opy_, l11ll1_opy_ (u"ࠪࡻࠬࠍ"))
    l1l1l1l_opy_.write(l11l11_opy_)
    l1ll1l_opy_ = []
    for channel in l1l1ll1_opy_:
        l11lll1_opy_ = l1l11_opy_(addon, channel)
        l1ll1ll_opy_ = l11lll1_opy_
        l1lll1_opy_ = l11llll_opy_(addon)
        l1lll_opy_  = dixie.mapChannelName(l11lll1_opy_)
        stream    = l1lll1_opy_ + l1ll1ll_opy_
        l11ll_opy_   = l1lll_opy_ + l11ll1_opy_ (u"ࠫࡂ࠭ࠎ") + stream
        if l11ll_opy_ not in l1ll1l_opy_:
            l1ll1l_opy_.append(l11ll_opy_)
    l1ll1l_opy_.sort()
    for item in l1ll1l_opy_:
        l1l1l1l_opy_.write(l11ll1_opy_ (u"ࠧࠫࡳ࡝ࡰࠥࠏ") % item)
    l1l1l1l_opy_.close()
def l1l11_opy_(addon, file):
    l1l111_opy_ = file[l11ll1_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬࠐ")].split(l11ll1_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࠑ"), 1)[0]
    l1l111_opy_ = dixie.cleanLabel(l1l111_opy_)
    return l1l111_opy_
def l11llll_opy_(addon):
    if addon == l1l1lll_opy_:
        return l11ll1_opy_ (u"ࠨࡇࡑࡈ࠿࠭ࠒ")
    if addon == l1lll11_opy_:
        return l11ll1_opy_ (u"ࠩࡉࡐࡆࡀࠧࠓ")
    if addon == dexter:
        return l11ll1_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡆ࠽ࠫࠔ")
def getURL(url):
    if url.startswith(l11ll1_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡆࡐ࡚ࡀࠧࠕ")):
        url = url.replace(l11ll1_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡇࡑ࡛࠺ࠨࠖ"), l11ll1_opy_ (u"࠭ࠧࠗ")).replace(l11ll1_opy_ (u"ࠧ࠮࠯ࡸࡷࡪࡸ࠭ࡢࡩࡨࡲࡹ࠭࠘"), l11ll1_opy_ (u"ࠨࡾࡸࡷࡪࡸ࠭ࡢࡩࡨࡲࡹ࠭࠙"))
        return url
    if url.startswith(l11ll1_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅࠩࠚ")):
        return l1ll_opy_(url, dexter)
    if url.startswith(l11ll1_opy_ (u"ࠪࡊࡑࡇࠧࠛ")):
        return l1ll_opy_(url, l1lll11_opy_)
    if url.startswith(l11ll1_opy_ (u"ࠫࡊࡔࡄࠨࠜ")):
        return l1ll_opy_(url, l1l1lll_opy_)
    response = l1l1_opy_(url)
    stream   = url.split(l11ll1_opy_ (u"ࠬࡀࠧࠝ"), 1)[-1]
    try:
        result = response[l11ll1_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࠞ")]
        l111l1_opy_  = result[l11ll1_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࠟ")]
    except Exception as e:
        l1ll111_opy_(e)
        return None
    for file in l111l1_opy_:
        l1l111_opy_ = file[l11ll1_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࠠ")]
        if stream in l1l111_opy_:
            return file[l11ll1_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧࠡ")]
    return None
def l1ll_opy_(url, addon):
    PATH = l111_opy_(addon)
    try:
        response = json.load(open(PATH))
    except:
        response = l1_opy_(addon)
    l1llll1_opy_ = url.split(l11ll1_opy_ (u"ࠪ࠾ࠬࠢ"))[0]
    l11ll11_opy_     = url.split(l11ll1_opy_ (u"ࠫ࠿࠭ࠣ"), 1)[-1]
    stream   = l11ll11_opy_.split(l11ll1_opy_ (u"࡛ࠬࠦࠨࠤ"), 1)[0]
    stream   = dixie.cleanLabel(stream)
    l111l1_opy_  = response[l11ll1_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࠥ")][l11ll1_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࠦ")]
    for file in l111l1_opy_:
        l1l111_opy_ = l1l11_opy_(addon, file)
        if stream in l1l111_opy_:
            l11l_opy_ = file[l11ll1_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ࠧ")]
            if l1llll1_opy_ == l11ll1_opy_ (u"ࠩࡉࡐࡆ࡙ࠧࠨ"):
                return l11l_opy_
            l11l_opy_ = l11l_opy_.replace(l11ll1_opy_ (u"ࠪ࠲ࡹࡹࠧࠩ"), l11ll1_opy_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪࠪ"))
            return l11l_opy_
def l1_opy_(addon):
    PATH = l111_opy_(addon)
    if addon == l1l1lll_opy_:
        query = l11ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡅ࡯ࡦ࡯ࡩࡸࡹ࠯ࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡵࡷࡶࡪࡧ࡭ࡠࡸ࡬ࡨࡪࡵࠦࡦࡺࡷࡶࡦࠬࡰࡢࡩࡨࠪࡵࡲ࡯ࡵࠨࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡂࠬࡴࡪࡶ࡯ࡩࡂࡇ࡬࡭ࠨࡸࡶࡱࡃ࠰ࠨࠫ")
    if addon == l1lll11_opy_:
        query = l11ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡇ࡮ࡤࡻࡱ࡫ࡳࡴࡖࡹ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡹࡴࡳࡧࡤࡱࡤࡼࡩࡥࡧࡲࠪࡪࡾࡴࡳࡣࠩࡴࡦ࡭ࡥࠧࡲ࡯ࡳࡹࠬࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠿ࠩࡸ࡮ࡺ࡬ࡦ࠿ࡄࡰࡱࠬࡵࡳ࡮ࡀ࠴ࠬࠬ")
    if addon == dexter:
        query = l1llll_opy_(addon)
    try:
        return json.load(open(PATH))
    except:
        content = doJSON(query)
        return l11l1l_opy_(PATH, addon, content)
def l11l1l_opy_(PATH, addon, content):
    json.dump(content, open(PATH,l11ll1_opy_ (u"ࠧࡸࠩ࠭")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    l1l1l11_opy_  = (l11ll1_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫ࠮") % query)
    response = xbmc.executeJSONRPC(l1l1l11_opy_)
    content  = json.loads(response)
    return content
def l111_opy_(addon):
    if addon == l1l1lll_opy_:
        return os.path.join(dixie.PROFILE, l11ll1_opy_ (u"ࠩࡨࡸࡪࡳࡰࠨ࠯"))
    if addon == l1lll11_opy_:
        return os.path.join(dixie.PROFILE, l11ll1_opy_ (u"ࠪࡪࡹ࡫࡭ࡱࠩ࠰"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l11ll1_opy_ (u"ࠫࡩࡺࡥ࡮ࡲࠪ࠱"))
def l1llll_opy_(addon):
    if addon == dexter:
        query = l11ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡤࡦࡺࠪ࠲")
        response = doJSON(query)
        l111l1_opy_    = response[l11ll1_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭࠳")][l11ll1_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭࠴")]
        for file in l111l1_opy_:
            l1l111_opy_ = file[l11ll1_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧ࠵")]
            if l1l111_opy_ == l11ll1_opy_ (u"ࠩࡄࡰࡱ࠭࠶"):
                login = file[l11ll1_opy_ (u"ࠪࡪ࡮ࡲࡥࠨ࠷")]
                return login
def l1l1_opy_(url):
    if url.startswith(l11ll1_opy_ (u"ࠫࡎࡖࡌࡂ࡛࠽ࠫ࠸")):
        l1l1l11_opy_ = (l11ll1_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡤࡥࡧ࡮ࡶ࡬ࡢࡻࡨࡶ࠴ࡅࡵࡳ࡮ࡀࡹࡷࡲࠦ࡮ࡱࡧࡩࡂ࠸ࠦ࡯ࡣࡰࡩࡂࡒࡩࡷࡧࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࡂࠬࡉࡑࡋࡇࡁࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ࠹"))
    if url.startswith(l11ll1_opy_ (u"࠭ࡉࡑࡎࡄ࡝࠷ࡀࠧ࠺")):
        l1l1l11_opy_ = (l11ll1_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽ࠯ࡀࡷࡵࡰࡂࡻࡲ࡭ࠨࡰࡳࡩ࡫࠽࠲࠲࠴ࠪࡳࡧ࡭ࡦ࠿࡚ࡥࡹࡩࡨࠬࡎ࡬ࡺࡪࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࠩࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮࠾ࠨࡶࡹࡧࡺࡩࡵ࡮ࡨࡷࡤࡻࡲ࡭࠿ࠩࡰࡴ࡭ࡧࡦࡦࡢ࡭ࡳࡃࡆࡢ࡮ࡶࡩࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ࠻"))
    if url.startswith(l11ll1_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡒ࠻ࠩ࠼")):
        l1l1l11_opy_ = (l11ll1_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰ࡭ࡣࡼࡩࡷࡽࡷࡸ࠱ࡂࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠧ࡮ࡲ࡫࡬࡫ࡤࡠ࡫ࡱࡁࡋࡧ࡬ࡴࡧࠩࡱࡴࡪࡥ࠾࠳࠴࠷ࠫࡴࡡ࡮ࡧࡀࡐ࡮ࡹࡴࡦࡰࠨ࠶࠵ࡒࡩࡷࡧࠩࡷࡺࡨࡴࡪࡶ࡯ࡩࡸࡥࡵࡳ࡮ࠩࡹࡷࡲ࠽ࡶࡴ࡯ࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ࠽"))
    if url.startswith(l11ll1_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡋࡗ࡚࠿࠭࠾")):
        l1l1l11_opy_ = (l11ll1_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡶࡹࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ࠿"))
    if url.startswith(l11ll1_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡈ࠿࠭ࡀ")):
        l1l1l11_opy_ = (l11ll1_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡧࡩࡽ࠵࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࡢ࡮࡯ࠪࡪࡾࡴࡳࡣࠩࡴࡦ࡭ࡥࠧࡲ࡯ࡳࡹࠬࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠿ࠩࡸ࡮ࡺ࡬ࡦ࠿ࠨ࠹ࡧࡉࡏࡍࡑࡕࠩ࠷࠶ࡷࡩ࡫ࡷࡩࠪ࠻ࡤࡂ࡮࡯ࠩ࠷࠶ࡃࡩࡣࡱࡲࡪࡲࡳࠦ࠷ࡥࠩ࠷࡬ࡃࡐࡎࡒࡖࠪ࠻ࡤࠧࡷࡵࡰࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࡁ"))
    if url.startswith(l11ll1_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡘࡂ࠻ࠩࡂ")):
        l1l1l11_opy_ = (l11ll1_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷ࡫ࡢࡰࡱࡷ࠳ࡄࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠩࡪࡦࡴࡡࡳࡶࡀࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧ࡯ࡲࡨࡪࡃ࠷ࠧࡲ࡬ࡰࡱࡵࡷ࠾ࡎ࡬ࡺࡪࠫ࠲࠱ࡕࡷࡶࡪࡧ࡭ࡴࠨࡸࡶࡱࡃࡲࡢࡰࡧࡳࡲࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࡃ"))
    if url.startswith(l11ll1_opy_ (u"ࠩࡌࡔ࡙࡙࠺ࠨࡄ")):
        l1l1l11_opy_ = (l11ll1_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࡭ࡵࡺࡶ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿࡯࡭ࡻ࡫ࡴࡷࡡࡤࡰࡱࠬࡥࡹࡶࡵࡥࠫࡶࡡࡨࡧࠩࡴࡱࡵࡴࠧࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡁࠫࡺࡩࡵ࡮ࡨࡁࡆࡲ࡬ࠦ࠴࠳ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡻࡲ࡭ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࡅ"))
    try:
        dixie.ShowBusy()
        addon =  l1l1l11_opy_.split(l11ll1_opy_ (u"ࠫ࠴࠵ࠧࡆ"), 1)[-1].split(l11ll1_opy_ (u"ࠬ࠵ࠧࡇ"), 1)[0]
        login = l11ll1_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࡈ") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1l1l11_opy_)
        dixie.log(response)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1ll111_opy_(e)
        return {l11ll1_opy_ (u"ࠧࡆࡴࡵࡳࡷ࠭ࡉ") : l11ll1_opy_ (u"ࠨࡒ࡯ࡹ࡬࡯࡮ࠡࡇࡵࡶࡴࡸࠧࡊ")}
def l111l_opy_():
    modules = map(__import__, [l11l1l1_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1l1l_opy_)):
        return l11ll1_opy_ (u"ࠩࡗࡶࡺ࡫ࠧࡋ")
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l11ll1_opy_ (u"ࠪࡘࡷࡻࡥࠨࡌ")
    return l11ll1_opy_ (u"ࠫࡋࡧ࡬ࡴࡧࠪࡍ")
def l1ll111_opy_(e):
    l1l11l_opy_ = l11ll1_opy_ (u"࡙ࠬ࡯ࡳࡴࡼ࠰ࠥࡧ࡮ࠡࡧࡵࡶࡴࡸࠠࡰࡥࡦࡹࡷ࡫ࡤ࠻ࠢࡍࡗࡔࡔࠠࡆࡴࡵࡳࡷࡀࠠࠦࡵࠪࡎ")  %e
    l11l1_opy_ = l11ll1_opy_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡲࡦ࠯࡯࡭ࡳࡱࠠࡵࡪ࡬ࡷࠥࡩࡨࡢࡰࡱࡩࡱࠦࡡ࡯ࡦࠣࡸࡷࡿࠠࡢࡩࡤ࡭ࡳ࠴ࠧࡏ")
    l1l1ll_opy_ = l11ll1_opy_ (u"ࠧࡖࡵࡨ࠾ࠥࡉ࡯࡯ࡶࡨࡼࡹࠦࡍࡦࡰࡸࠤࡂࡄࠠࡓࡧࡰࡳࡻ࡫ࠠࡔࡶࡵࡩࡦࡳࠧࡐ")
    dixie.log(e)
    dixie.DialogOK(l1l11l_opy_, l11l1_opy_, l1l1ll_opy_)
if __name__ == l11ll1_opy_ (u"ࠨࡡࡢࡱࡦ࡯࡮ࡠࡡࠪࡑ"):
    checkAddons()