# coding: UTF-8
import sys
l1l11l1l_opy_ = sys.version_info [0] == 2
l1llll11_opy_ = 2048
l1l1ll11_opy_ = 7
def l11ll_opy_ (l1l11l_opy_):
	global l1llllll_opy_
	l1ll1ll1_opy_ = ord (l1l11l_opy_ [-1])
	l1l1l1l1_opy_ = l1l11l_opy_ [:-1]
	l11l11l_opy_ = l1ll1ll1_opy_ % len (l1l1l1l1_opy_)
	l11ll1_opy_ = l1l1l1l1_opy_ [:l11l11l_opy_] + l1l1l1l1_opy_ [l11l11l_opy_:]
	if l1l11l1l_opy_:
		l1llll_opy_ = unicode () .join ([unichr (ord (char) - l1llll11_opy_ - (l111l11_opy_ + l1ll1ll1_opy_) % l1l1ll11_opy_) for l111l11_opy_, char in enumerate (l11ll1_opy_)])
	else:
		l1llll_opy_ = str () .join ([chr (ord (char) - l1llll11_opy_ - (l111l11_opy_ + l1ll1ll1_opy_) % l1l1ll11_opy_) for l111l11_opy_, char in enumerate (l11ll1_opy_)])
	return eval (l1llll_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l1ll1lll11_opy_     = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡯ࡶࡹࠫ૜")
l1ll1lll1l_opy_  = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡹ࡯࡭ࡵࡺࡶࠨ૝")
l1lll1l111_opy_     = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸ࡯ࡹࡻࡲ࡬ࠩ૞")
locked  = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰࡴࡩ࡫ࡦࡦࡷࡺࠬ૟")
l1lll11l11_opy_      = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡲࡴࡪ࡯ࡤࡸࡪࡳࡡ࡯࡫ࡤࠫૠ")
l11lll1l_opy_    = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲࡩࡶࡺ࠱ࡸࡻ࠭ૡ")
l1ll1lllll_opy_     = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡄࡄࡕࡳࡳࡷࡺࡳࠨૢ")
l1lll11l1l_opy_  = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡧࡥࡳࡴࡺࠧૣ")
l1ll1llll1_opy_     = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡥ࡯ࡹ࡮ࡶࡴࡷࠩ૤")
l1ll1ll1ll_opy_ = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸ࡯ࡹࡼ࠴ࡦࡺࡳࡥࡹࡹ࠮ࡤࡱࡰࠫ૥")
l1ll11ll_opy_ = [l1ll1lll11_opy_, locked, l11lll1l_opy_, l1ll1lll1l_opy_, l1ll1ll1ll_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l11ll_opy_ (u"ࠫ࡮ࡴࡩࠨ૦"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1ll111l1_opy_ = l11ll_opy_ (u"ࠬ࠭૧")
def l1l1l1lll_opy_(i, t1, l1ll11111_opy_=[]):
 t = l1ll111l1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1ll11111_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11l1111_opy_ = l1l1l1lll_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l111llll_opy_ = l1l1l1lll_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1ll11ll_opy_:
        if l1llll1l1_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1llll1l1_opy_(addon):
    if xbmc.getCondVisibility(l11ll_opy_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡈࡢࡵࡄࡨࡩࡵ࡮ࠩࠧࡶ࠭ࠬ૨") % addon) == 1:
        return True
    return False
def createINI(addon):
    l1lll11l1_opy_ = str(addon).split(l11ll_opy_ (u"ࠧ࠯ࠩ૩"))[2] + l11ll_opy_ (u"ࠨ࠰࡬ࡲ࡮࠭૪")
    l1l1ll11l_opy_  = os.path.join(PATH, l1lll11l1_opy_)
    try:
        l11l111_opy_ = l11ll1ll_opy_(addon)
    except KeyError:
        dixie.log(l11ll_opy_ (u"ࠩ࠰࠱࠲࠳࠭ࠡࡍࡨࡽࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡧࡦࡶࡉ࡭ࡱ࡫ࡳࠡ࠯࠰࠱࠲࠳ࠠࠨ૫") + addon)
        result = {l11ll_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࡵࠪ૬"): [{l11ll_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ૭"): l11ll_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࠫ૮"), l11ll_opy_ (u"ࡻࠧࡵࡻࡳࡩࠬ૯"): l11ll_opy_ (u"ࡵࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩ૰"), l11ll_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࠧ૱"): l11ll_opy_ (u"ࡷࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡾࡸࠨ૲"), l11ll_opy_ (u"ࡸࠫࡱࡧࡢࡦ࡮ࠪ૳"): l11ll_opy_ (u"ࡹࠬࡔࡏࠡࡅࡋࡅࡓࡔࡅࡍࡕࠪ૴")}], l11ll_opy_ (u"ࡺ࠭࡬ࡪ࡯࡬ࡸࡸ࠭૵"):{l11ll_opy_ (u"ࡻࠧࡴࡶࡤࡶࡹ࠭૶"): 0, l11ll_opy_ (u"ࡵࠨࡶࡲࡸࡦࡲࠧ૷"): 1, l11ll_opy_ (u"ࡶࠩࡨࡲࡩ࠭૸"): 1}}
    l1lllll11_opy_  = l11ll_opy_ (u"ࠩ࡞ࠫૹ") + addon + l11ll_opy_ (u"ࠪࡡࡡࡴࠧૺ")
    l11l11ll_opy_  =  file(l1l1ll11l_opy_, l11ll_opy_ (u"ࠫࡼ࠭ૻ"))
    l11l11ll_opy_.write(l1lllll11_opy_)
    l1lll1ll1_opy_ = []
    for channel in l11l111_opy_:
        l111l1l1_opy_ = dixie.cleanLabel(channel[l11ll_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫૼ")])
        l1l1111_opy_   = dixie.cleanPrefix(l111l1l1_opy_)
        l11l1l11_opy_ = dixie.mapChannelName(l1l1111_opy_)
        stream   = channel[l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࠫ૽")]
        l111lll1_opy_ = l11l1l11_opy_ + l11ll_opy_ (u"ࠧ࠾ࠩ૾") + stream
        l1lll1ll1_opy_.append(l111lll1_opy_)
        l1lll1ll1_opy_.sort()
    for item in l1lll1ll1_opy_:
        l11l11ll_opy_.write(l11ll_opy_ (u"ࠣࠧࡶࡠࡳࠨ૿") % item)
    l11l11ll_opy_.close()
def l11ll1ll_opy_(addon):
    if (addon == l1ll1lll11_opy_) or (addon == l1ll1lll1l_opy_):
        if xbmcaddon.Addon(addon).getSetting(l11ll_opy_ (u"ࠩࡪࡩࡳࡸࡥࠨ଀")) == l11ll_opy_ (u"ࠪࡸࡷࡻࡥࠨଁ"):
            xbmcaddon.Addon(addon).setSetting(l11ll_opy_ (u"ࠫ࡬࡫࡮ࡳࡧࠪଂ"), l11ll_opy_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫଃ"))
            xbmcgui.Window(10000).setProperty(l11ll_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡇࡆࡐࡕࡉࠬ଄"), l11ll_opy_ (u"ࠧࡕࡴࡸࡩࠬଅ"))
        if xbmcaddon.Addon(addon).getSetting(l11ll_opy_ (u"ࠨࡶࡹ࡫ࡺ࡯ࡤࡦࠩଆ")) == l11ll_opy_ (u"ࠩࡷࡶࡺ࡫ࠧଇ"):
            xbmcaddon.Addon(addon).setSetting(l11ll_opy_ (u"ࠪࡸࡻ࡭ࡵࡪࡦࡨࠫଈ"), l11ll_opy_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪଉ"))
            xbmcgui.Window(10000).setProperty(l11ll_opy_ (u"ࠬࡖࡌࡖࡉࡌࡒࡤ࡚ࡖࡈࡗࡌࡈࡊ࠭ଊ"), l11ll_opy_ (u"࠭ࡔࡳࡷࡨࠫଋ"))
        l1l11ll_opy_  = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪଌ") + addon
        l1lll1111l_opy_ =  l1lll1l11l_opy_(addon)
        query   =  l1l11ll_opy_ + l1lll1111l_opy_
        return sendJSON(query, addon)
    return l1l11l11_opy_(addon)
def l1l11l11_opy_(addon):
    if addon == l1ll1ll1ll_opy_:
        l1111l1_opy_ = [l11ll_opy_ (u"ࠨ࠳࠹࠵ࠬ଍"), l11ll_opy_ (u"ࠩ࠴࠺࠵࠭଎"), l11ll_opy_ (u"ࠪ࠶࠸࠼ࠧଏ"), l11ll_opy_ (u"ࠫ࠷࠺࠲ࠨଐ"), l11ll_opy_ (u"ࠬ࠷࠵࠹ࠩ଑"), l11ll_opy_ (u"࠭࠱࠶࠻ࠪ଒")]
    if addon == l11lll1l_opy_:
        l1111l1_opy_ = [l11ll_opy_ (u"ࠧ࠶ࠩଓ"), l11ll_opy_ (u"ࠨ࠳࠳࠺ࠬଔ"), l11ll_opy_ (u"ࠩ࠷ࠫକ"), l11ll_opy_ (u"ࠪ࠶࠻࠹ࠧଖ"), l11ll_opy_ (u"ࠫ࠶࠹࠲ࠨଗ")]
    if addon == locked:
        l1111l1_opy_ = [l11ll_opy_ (u"ࠬ࠹࠰ࠨଘ"), l11ll_opy_ (u"࠭࠳࠲ࠩଙ"), l11ll_opy_ (u"ࠧ࠴࠴ࠪଚ"), l11ll_opy_ (u"ࠨ࠵࠶ࠫଛ"), l11ll_opy_ (u"ࠩ࠶࠸ࠬଜ"), l11ll_opy_ (u"ࠪ࠷࠺࠭ଝ"), l11ll_opy_ (u"ࠫ࠸࠾ࠧଞ"), l11ll_opy_ (u"ࠬ࠺࠰ࠨଟ"), l11ll_opy_ (u"࠭࠴࠲ࠩଠ"), l11ll_opy_ (u"ࠧ࠵࠷ࠪଡ"), l11ll_opy_ (u"ࠨ࠶࠺ࠫଢ"), l11ll_opy_ (u"ࠩ࠷࠽ࠬଣ"), l11ll_opy_ (u"ࠪ࠹࠷࠭ତ")]
    if addon == l1lll11l11_opy_:
        l1111l1_opy_ = [l11ll_opy_ (u"ࠫ࠷࠻ࠧଥ"), l11ll_opy_ (u"ࠬ࠸࠶ࠨଦ"), l11ll_opy_ (u"࠭࠲࠸ࠩଧ"), l11ll_opy_ (u"ࠧ࠳࠻ࠪନ"), l11ll_opy_ (u"ࠨ࠵࠳ࠫ଩"), l11ll_opy_ (u"ࠩ࠶࠵ࠬପ"), l11ll_opy_ (u"ࠪ࠷࠷࠭ଫ"), l11ll_opy_ (u"ࠫ࠸࠻ࠧବ"), l11ll_opy_ (u"ࠬ࠹࠶ࠨଭ"), l11ll_opy_ (u"࠭࠳࠸ࠩମ"), l11ll_opy_ (u"ࠧ࠴࠺ࠪଯ"), l11ll_opy_ (u"ࠨ࠵࠼ࠫର"), l11ll_opy_ (u"ࠩ࠷࠴ࠬ଱"), l11ll_opy_ (u"ࠪ࠸࠶࠭ଲ"), l11ll_opy_ (u"ࠫ࠹࠾ࠧଳ"), l11ll_opy_ (u"ࠬ࠺࠹ࠨ଴"), l11ll_opy_ (u"࠭࠵࠱ࠩଵ"), l11ll_opy_ (u"ࠧ࠶࠴ࠪଶ"), l11ll_opy_ (u"ࠨ࠷࠷ࠫଷ"), l11ll_opy_ (u"ࠩ࠸࠺ࠬସ"), l11ll_opy_ (u"ࠪ࠹࠼࠭ହ"), l11ll_opy_ (u"ࠫ࠺࠾ࠧ଺"), l11ll_opy_ (u"ࠬ࠻࠹ࠨ଻"), l11ll_opy_ (u"࠭࠶࠱଼ࠩ"), l11ll_opy_ (u"ࠧ࠷࠳ࠪଽ"), l11ll_opy_ (u"ࠨ࠸࠵ࠫା"), l11ll_opy_ (u"ࠩ࠹࠷ࠬି"), l11ll_opy_ (u"ࠪ࠺࠺࠭ୀ"), l11ll_opy_ (u"ࠫ࠻࠼ࠧୁ"), l11ll_opy_ (u"ࠬ࠼࠷ࠨୂ"), l11ll_opy_ (u"࠭࠶࠺ࠩୃ"), l11ll_opy_ (u"ࠧ࠸࠲ࠪୄ"), l11ll_opy_ (u"ࠨ࠹࠷ࠫ୅"), l11ll_opy_ (u"ࠩ࠺࠻ࠬ୆"), l11ll_opy_ (u"ࠪ࠻࠽࠭େ"), l11ll_opy_ (u"ࠫ࠽࠶ࠧୈ"), l11ll_opy_ (u"ࠬ࠾࠱ࠨ୉")]
    login = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶ࠳ࠬ୊") % addon
    sendJSON(login, addon)
    l111111_opy_ = []
    for l1111l_opy_ in l1111l1_opy_:
        if (addon == l1ll1ll1ll_opy_) or (addon == l11lll1l_opy_):
            query = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷ࠴ࡅ࡭ࡰࡦࡨࡣ࡮ࡪ࠽ࡤࡪࡤࡲࡳ࡫࡬ࡴࠨࡰࡳࡩ࡫࠽ࡤࡪࡤࡲࡳ࡫࡬ࡴࠨࡶࡩࡨࡺࡩࡰࡰࡢ࡭ࡩࡃࠥࡴࠩୋ") % (addon, l1111l_opy_)
        if (addon == locked) or (addon == l1lll11l11_opy_):
            query = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸ࠵࠿ࡶࡴ࡯ࡁࠪࡹࠦ࡮ࡱࡧࡩࡂ࠺ࠦ࡯ࡣࡰࡩࡂࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࠩࡴࡱࡧࡹ࠾ࠨࡧࡥࡹ࡫࠽ࠧࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࡃࠦࡱࡣࡪࡩࡂ࠭ୌ") % (addon, l1111l_opy_)
        response = sendJSON(query, addon)
        l111111_opy_.extend(response)
    return l111111_opy_
def sendJSON(query, addon):
    l1111ll_opy_     = l11ll_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁ୍ࠬ") % query
    l1111_opy_  = xbmc.executeJSONRPC(l1111ll_opy_)
    response = json.loads(l1111_opy_)
    result   = response[l11ll_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪ୎")]
    if xbmcgui.Window(10000).getProperty(l11ll_opy_ (u"ࠫࡕࡒࡕࡈࡋࡑࡣࡌࡋࡎࡓࡇࠪ୏")) == l11ll_opy_ (u"࡚ࠬࡲࡶࡧࠪ୐"):
        xbmcaddon.Addon(addon).setSetting(l11ll_opy_ (u"࠭ࡧࡦࡰࡵࡩࠬ୑"), l11ll_opy_ (u"ࠧࡵࡴࡸࡩࠬ୒"))
    if xbmcgui.Window(10000).getProperty(l11ll_opy_ (u"ࠨࡒࡏ࡙ࡌࡏࡎࡠࡖ࡙ࡋ࡚ࡏࡄࡆࠩ୓")) == l11ll_opy_ (u"ࠩࡗࡶࡺ࡫ࠧ୔"):
        xbmcaddon.Addon(addon).setSetting(l11ll_opy_ (u"ࠪࡸࡻ࡭ࡵࡪࡦࡨࠫ୕"), l11ll_opy_ (u"ࠫࡹࡸࡵࡦࠩୖ"))
    return result[l11ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫୗ")]
def l1lll1l11l_opy_(addon):
    if (addon == l1ll1lll11_opy_) or (addon == l1ll1lll1l_opy_):
        return l11ll_opy_ (u"࠭࠯ࡀࡥࡤࡸࡂ࠳࠲ࠧࡦࡤࡸࡪࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠪࡪࡴࡤࡅࡣࡷࡩࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡰࡳࡩ࡫࠽࠳ࠨࡱࡥࡲ࡫࠽ࡎࡻࠨ࠶࠵ࡉࡨࡢࡰࡱࡩࡱࡹࠦࡳࡧࡦࡳࡷࡪ࡮ࡢ࡯ࡨࠪࡸࡺࡡࡳࡶࡇࡥࡹ࡫ࠦࡶࡴ࡯ࡁࡺࡸ࡬ࠨ୘")
    return l11ll_opy_ (u"ࠧࠨ୙")
def l111111l_opy_():
    modules = map(__import__, [l1l1l1lll_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11l1111_opy_)):
        return l11ll_opy_ (u"ࠨࡖࡵࡹࡪ࠭୚")
    if len(modules[-1].Window(10**4).getProperty(l111llll_opy_)):
        return l11ll_opy_ (u"ࠩࡗࡶࡺ࡫ࠧ୛")
    return l11ll_opy_ (u"ࠪࡊࡦࡲࡳࡦࠩଡ଼")
def l1ll1l1l1_opy_(e, addon):
    l11111l1_opy_ = l11ll_opy_ (u"ࠫࡘࡵࡲࡳࡻ࠯ࠤࡦࡴࠠࡦࡴࡵࡳࡷࠦ࡯ࡤࡥࡸࡶࡪࡪ࠺ࠡࡌࡖࡓࡓࠦࡅࡳࡴࡲࡶ࠿ࠦࠥࡴ࠮ࠣࠩࡸ࠭ଢ଼")  % (e, addon)
    l1l1ll1l1_opy_ = l11ll_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡩ࡯࡯ࡶࡤࡧࡹࠦࡵࡴࠢࡲࡲࠥࡺࡨࡦࠢࡩࡳࡷࡻ࡭࠯ࠩ୞")
    l1111l11_opy_ = l11ll_opy_ (u"࠭ࡕࡱ࡮ࡲࡥࡩࠦࡡࠡ࡮ࡲ࡫ࠥࡼࡩࡢࠢࡷ࡬ࡪࠦࡡࡥࡦࡲࡲࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹࠠࡢࡰࡧࠤࡵࡵࡳࡵࠢࡷ࡬ࡪࠦ࡬ࡪࡰ࡮࠲ࠬୟ")
    dixie.log(addon)
    dixie.log(e)
def getPluginInfo(streamurl, kodiID=False):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l1lll111l1_opy_   = l11ll_opy_ (u"ࠧࡌࡱࡧ࡭ࠥࡖࡖࡓࠩୠ")
            l1lll11lll_opy_ = os.path.join(dixie.RESOURCES, l11ll_opy_ (u"ࠨ࡭ࡲࡨ࡮࠳ࡰࡷࡴ࠱ࡴࡳ࡭ࠧୡ"))
            return l1lll111l1_opy_, l1lll11lll_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l11ll_opy_ (u"ࠩࡵࡸࡲࡶࠧୢ")) or url.startswith(l11ll_opy_ (u"ࠪࡶࡹࡳࡰࡦࠩୣ")) or url.startswith(l11ll_opy_ (u"ࠫࡷࡺࡳࡱࠩ୤")) or url.startswith(l11ll_opy_ (u"ࠬ࡮ࡴࡵࡲࠪ୥")):
            l1lll111l1_opy_   = l11ll_opy_ (u"࠭࡭࠴ࡷࠣࡔࡱࡧࡹ࡭࡫ࡶࡸࠬ୦")
            l1lll11lll_opy_ = os.path.join(dixie.RESOURCES, l11ll_opy_ (u"ࠧࡪࡲࡷࡺ࠲ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡱࡰࡪࠫ୧"))
            return l1lll111l1_opy_, l1lll11lll_opy_
    except:
        pass
    if streamurl.startswith(l11ll_opy_ (u"ࠨࡲࡹࡶ࠿࠵࠯ࠨ୨")):
        l1lll111l1_opy_   = l11ll_opy_ (u"ࠩࡎࡳࡩ࡯ࠠࡑࡘࡕࠫ୩")
        l1lll11lll_opy_ = os.path.join(dixie.RESOURCES, l11ll_opy_ (u"ࠪ࡯ࡴࡪࡩ࠮ࡲࡹࡶ࠳ࡶ࡮ࡨࠩ୪"))
        return l1lll111l1_opy_, l1lll11lll_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        l1lll11ll1_opy_ = streamurl.split(l11ll_opy_ (u"ࠫࡢࡕࡔࡕࡡࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ୫"), 1)[-1].split(l11ll_opy_ (u"ࠬ࠵ࠧ୬"), 1)[0]
    if l11ll_opy_ (u"࠭࡝ࡐࡖࡗࡣࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ୭") in streamurl:
        l1lll11ll1_opy_ = streamurl.split(l11ll_opy_ (u"ࠧ࡞ࡑࡗࡘࡤࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ୮"), 1)[-1].split(l11ll_opy_ (u"ࠨ࠱ࠪ୯"), 1)[0]
    if streamurl.startswith(l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ୰")):
        l1lll11ll1_opy_ = streamurl.split(l11ll_opy_ (u"ࠪ࠳࠴࠭ୱ"), 1)[-1].split(l11ll_opy_ (u"ࠫ࠴࠭୲"), 1)[0]
    if l11ll_opy_ (u"ࠬࡍࡓࡑࡔࡗࡗ࠿࠭୳") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡭ࡩࡻ࡯ࡲࡷࡵࡵࡲࡵࡵࠪ୴")
    if l11ll_opy_ (u"ࠧࡠࡡࡖࡊࡤࡥࠧ୵") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡲࡵࡳ࡬ࡸࡡ࡮࠰ࡶࡹࡵ࡫ࡲ࠯ࡨࡤࡺࡴࡻࡲࡪࡶࡨࡷࠬ୶")
    if l11ll_opy_ (u"ࠩࡏࡍࡒ࠸࠺ࠨ୷") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡏ࡭ࡲ࡯ࡴ࡭ࡧࡶࡷ࡛࠸ࠧ୸")
    if l11ll_opy_ (u"ࠫࡓࡏࡃࡆ࠼ࠪ୹") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡳࡧࡴࡩࡱࡶࡹࡧࡹࡩࡤࡧࠪ୺")
    if l11ll_opy_ (u"࠭ࡐࡓࡇࡐ࠾ࠬ୻") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡰࡳࡧࡰ࡭ࡺࡳࡩࡱࡶࡹࠫ୼")
    if l11ll_opy_ (u"ࠨࡉࡌ࡞࠿࠭୽") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡩ࡬ࡾࡲࡵࡴࡷࠩ୾")
    if l11ll_opy_ (u"ࠪࡋࡊࡎ࠺ࠨ୿") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡫ࡪ࡮࡯ࡴࡶ࡬ࡲ࡬࠭஀")
    if l11ll_opy_ (u"ࠬࡓࡔ࡙ࡋࡈ࠾ࠬ஁") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡳࡡࡵࡴ࡬ࡼ࡮ࡸࡥ࡭ࡣࡱࡨࠬஂ")
    if l11ll_opy_ (u"ࠧࡕࡘࡎ࠾ࠬஃ") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡵࡸ࡮࡭ࡳ࡭ࡳࠨ஄")
    if l11ll_opy_ (u"࡛ࠩࡘࡈࡀࠧஅ") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡸࡷ࡫ࡡ࡮࠯ࡦࡳࡩ࡫ࡳࠨஆ")
    if l11ll_opy_ (u"ࠫࡘࡉࡔࡗ࠼ࠪஇ") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡩࡴࡷࠩஈ")
    if l11ll_opy_ (u"࠭ࡓࡖࡒ࠽ࠫஉ") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡵࡴࡨࡥࡲࡹࡵࡱࡴࡨࡱࡪ࠸ࠧஊ")
    if l11ll_opy_ (u"ࠨࡗࡎࡘ࠿࠭஋") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡷ࡮ࡸࡺࡸ࡫ࠨ஌")
    if l11ll_opy_ (u"ࠪࡐࡎࡓࡉࡕ࠼ࠪ஍") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡐ࡮ࡳࡩࡵ࡮ࡨࡷࡸࡏࡐࡕࡘࠪஎ")
    if l11ll_opy_ (u"ࠬࡌࡁࡃ࠼ࠪஏ") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡬ࡡࡣࡪࡲࡷࡹ࡯࡮ࡨࠩஐ")
    if l11ll_opy_ (u"ࠧࡂࡅࡈ࠾ࠬ஑") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡥࡨࡸࡻ࠭ஒ")
    if l11ll_opy_ (u"ࠩࡋࡓࡗࡏ࡚࠻ࠩஓ") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡫ࡳࡷ࡯ࡺࡰࡰ࡬ࡴࡹࡼࠧஔ")
    if l11ll_opy_ (u"ࠫࡗࡕࡏࡕ࠴࠽ࠫக") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡵ࡯ࡵࡋࡓࡘ࡛࠭஖")
    if l11ll_opy_ (u"࠭ࡍࡆࡉࡄ࠾ࠬ஗") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡭ࡦࡩࡤ࡭ࡵࡺࡶࠨ஘")
    if l11ll_opy_ (u"ࠨࡘࡇࡖ࡙࡜࠺ࠨங") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡘࡄࡈࡊࡘࠧச")
    if l11ll_opy_ (u"ࠪࡌࡉ࡚ࡖ࠻ࠩ஛") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡲࡧࡲࡵࡪࡸࡦࠬஜ")
    if l11ll_opy_ (u"ࠬࡎࡄࡕࡘ࠵࠾ࠬ஝") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡵࡺࡣ࠵ࠫஞ")
    if l11ll_opy_ (u"ࠧࡉࡆࡗ࡚࠸ࡀࠧட") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥ࠷࠭஠")
    if l11ll_opy_ (u"ࠩࡋࡈ࡙࡜࠴࠻ࠩ஡") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡰࠬ஢")
    if l11ll_opy_ (u"ࠫࡎࡖࡌࡂ࡛࠽ࠫண") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡧࡨࡣࡪࡲ࡯ࡥࡾ࡫ࡲࠨத")
    if l11ll_opy_ (u"࠭ࡉࡑࡎࡄ࡝࠷ࡀࠧ஥") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱ࡮ࡤࡽࡪࡸࡷࡸࡹࠪ஦")
    if l11ll_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡒ࠻ࠩ஧") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡰࡦࡿࡥࡳࡹࡺࡻࠬந")
    if l11ll_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡋࡗ࡚࠿࠭ன") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡹࡼࠧப")
    if l11ll_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡈ࠿࠭஫") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡪࡥࡹࠩ஬")
    if l11ll_opy_ (u"ࠧࡋࡋࡑ࡜࠷ࡀࠧ஭") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡫࡫ࡱࡼࡹࡼ࠲ࠨம")
    if l11ll_opy_ (u"ࠩࡐࡅ࡙࡙࠺ࠨய") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡐࡥࡹࡹࡂࡶ࡫࡯ࡨࡸࡏࡐࡕࡘࠪர")
    if l11ll_opy_ (u"ࠫࡗࡕࡏࡕ࠼ࠪற") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡵ࡯ࡵ࡫ࡳࡸࡻ࠭ல")
    if l11ll_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡗࡈ࠺ࠨள") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡦࡤࡲࡳࡹ࠭ழ")
    if l11ll_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡃࡍࡗ࠽ࠫவ") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡥ࡯ࡹ࡮ࡶࡴࡷࠩஶ")
    if l11ll_opy_ (u"ࠪࡍࡕ࡚ࡓࠨஷ") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡺࡶࡴࡷࡥࡷࠬஸ")
    if l11ll_opy_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠿࠭ஹ") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲࡩࡷࡧࡰ࡭ࡽ࠭஺")
    if l11ll_opy_ (u"ࠧࡆࡐࡇ࠾ࠬ஻") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡆࡰࡧࡰࡪࡹࡳࠨ஼")
    if l11ll_opy_ (u"ࠩࡉࡐࡆࡀࠧ஽") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡉࡰࡦࡽ࡬ࡦࡵࡶࡘࡻ࠭ா")
    if l11ll_opy_ (u"ࠫࡒࡇࡘࡊ࠼ࠪி") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡲࡧࡸࡪࡹࡨࡦࡹࡼࠧீ")
    if l11ll_opy_ (u"࠭ࡆࡍࡃࡖ࠾ࠬு") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡆ࡭ࡣࡺࡰࡪࡹࡳࡕࡸࠪூ")
    if l11ll_opy_ (u"ࠨࡕࡓࡖࡒࡀࠧ௃") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡕࡸࡴࡷ࡫࡭ࡢࡥࡼࡘ࡛࠭௄")
    if l11ll_opy_ (u"ࠪࡑࡈࡑࡔࡗ࠼ࠪ௅") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡱࡨࡱࡴࡷ࠯ࡳࡰࡺࡹࠧெ")
    if l11ll_opy_ (u"࡚ࠬࡗࡊࡕࡗ࠾ࠬே") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡺࡷࡪࡵࡷࡩࡩ࠭ை")
    if l11ll_opy_ (u"ࠧࡑࡔࡈࡗ࡙ࡀࠧ௉") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡱࡵࡤࡨࡩࡵ࡮ࠨொ")
    if l11ll_opy_ (u"ࠩࡅࡐࡐࡏ࠺ࠨோ") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡅࡰࡦࡩ࡫ࡊࡥࡨࡘ࡛࠭ௌ")
    if l11ll_opy_ (u"ࠫࡋࡘࡅࡆ࠼்ࠪ") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡫ࡸࡥࡦࡸ࡬ࡩࡼ࠭௎")
    if l11ll_opy_ (u"࠭ࡵࡱࡰࡳ࠾ࠬ௏") in streamurl:
        l1lll11ll1_opy_ = l11ll_opy_ (u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮ࡩࡦ࡫ࡳࡲ࡫ࡲࡶࡰ࠱ࡺ࡮࡫ࡷࠨௐ")
    return l1lll11111_opy_(l1lll11ll1_opy_, kodiID)
def l1lll11111_opy_(l1lll11ll1_opy_, kodiID):
    l1lll111l1_opy_     = l11ll_opy_ (u"ࠨࠩ௑")
    l1lll11lll_opy_   = l11ll_opy_ (u"ࠩࠪ௒")
    try:
        l1lll1l1l1_opy_ = xbmcaddon.Addon(l1lll11ll1_opy_).getAddonInfo(l11ll_opy_ (u"ࠪࡲࡦࡳࡥࠨ௓"))
        l1lll111l1_opy_    = dixie.cleanLabel(l1lll1l1l1_opy_)
        l1lll11lll_opy_  = xbmcaddon.Addon(l1lll11ll1_opy_).getAddonInfo(l11ll_opy_ (u"ࠫ࡮ࡩ࡯࡯ࠩ௔"))
        if kodiID:
            l1lll111ll_opy_ = xbmcaddon.Addon(l1lll11ll1_opy_).getAddonInfo(l11ll_opy_ (u"ࠬ࡯ࡤࠨ௕"))
            return l1lll111l1_opy_, l1lll111ll_opy_
        return l1lll111l1_opy_, l1lll11lll_opy_
    except:
        l1lll111l1_opy_   = l11ll_opy_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡔࡱࡸࡶࡨ࡫ࠧ௖")
        l1lll11lll_opy_ =  dixie.ICON
        return l1lll111l1_opy_, l1lll11lll_opy_
    return l1lll111l1_opy_, l1lll11lll_opy_
def selectStream(url, channel):
    l11llll_opy_ = url.split(l11ll_opy_ (u"ࠧࡽࠩௗ"))
    if len(l11llll_opy_) == 0:
        return None
    options, l1l111ll_opy_ = getOptions(l11llll_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l11llll_opy_) == 1:
            return l1l111ll_opy_[0]
    import selectDialog
    l1llll1l_opy_ = selectDialog.select(l11ll_opy_ (u"ࠨࡕࡨࡰࡪࡩࡴࠡࡣࠣࡷࡹࡸࡥࡢ࡯ࠪ௘"), options)
    if l1llll1l_opy_ < 0:
        raise Exception(l11ll_opy_ (u"ࠩࡖࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡉࡡ࡯ࡥࡨࡰࠬ௙"))
    return l1l111ll_opy_[l1llll1l_opy_]
def getOptions(l11llll_opy_, channel, addmore=True):
    options = []
    l1l111ll_opy_    = []
    for index, stream in enumerate(l11llll_opy_):
        l1lll111l1_opy_ = getPluginInfo(stream)
        l1lllll_opy_ = l11ll_opy_ (u"ࠪࠫ௚")
        l1ll1ll1l1_opy_  = l1lll111l1_opy_[1]
        if stream.startswith(OPEN_OTT):
            l111l_opy_ = stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l11ll_opy_ (u"ࠫࠬ௛"))
            l1lllll_opy_  = l1lllll_opy_ + l111l_opy_
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l11ll_opy_ (u"ࠬ࠭௜"))
        else:
            l1lllll_opy_  = l1lllll_opy_ + channel
        options.append([l1lllll_opy_, index, l1ll1ll1l1_opy_])
        l1l111ll_opy_.append(stream)
    if addmore:
        options.append([l11ll_opy_ (u"࠭ࡁࡥࡦࠣࡱࡴࡸࡥ࠯࠰࠱ࠫ௝"), index + 1, dixie.ICON])
        l1l111ll_opy_.append(l11ll_opy_ (u"ࠧࡢࡦࡧࡑࡴࡸࡥࠨ௞"))
    return options, l1l111ll_opy_
if __name__ == l11ll_opy_ (u"ࠨࡡࡢࡱࡦ࡯࡮ࡠࡡࠪ௟"):
    checkAddons()