# coding: UTF-8
import sys
l1l11l1l_opy_ = sys.version_info [0] == 2
l1llll11_opy_ = 2048
l1l1ll11_opy_ = 7
def l11ll_opy_ (l1l11l_opy_):
	global l1llllll_opy_
	l1ll1ll1_opy_ = ord (l1l11l_opy_ [-1])
	l1l1l1l1_opy_ = l1l11l_opy_ [:-1]
	l11l11l_opy_ = l1ll1ll1_opy_ % len (l1l1l1l1_opy_)
	l11ll1_opy_ = l1l1l1l1_opy_ [:l11l11l_opy_] + l1l1l1l1_opy_ [l11l11l_opy_:]
	if l1l11l1l_opy_:
		l1llll_opy_ = unicode () .join ([unichr (ord (char) - l1llll11_opy_ - (l111l11_opy_ + l1ll1ll1_opy_) % l1l1ll11_opy_) for l111l11_opy_, char in enumerate (l11ll1_opy_)])
	else:
		l1llll_opy_ = str () .join ([chr (ord (char) - l1llll11_opy_ - (l111l11_opy_ + l1ll1ll1_opy_) % l1l1ll11_opy_) for l111l11_opy_, char in enumerate (l11ll1_opy_)])
	return eval (l1llll_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
import mapping
ADDON    = dixie.ADDON
l1l1l1ll_opy_ = dixie.PROFILE
l1ll1ll11_opy_  = os.path.join(l1l1l1ll_opy_, l11ll_opy_ (u"ࠪ࡭ࡳ࡯ࠧই"))
l1111ll1_opy_    = os.path.join(l1ll1ll11_opy_, l11ll_opy_ (u"ࠫࡲࡧࡰࡱ࡫ࡱ࡫ࡸ࠴ࡪࡴࡱࡱࠫঈ"))
l11l111l_opy_   = os.path.join(l1ll1ll11_opy_, l11ll_opy_ (u"ࠬࡳࡡࡱࡵ࠱࡮ࡸࡵ࡮ࠨউ"))
LABELFILE  = os.path.join(l1ll1ll11_opy_, l11ll_opy_ (u"࠭࡬ࡢࡤࡨࡰࡸ࠴ࡪࡴࡱࡱࠫঊ"))
l1ll11l1l_opy_ = os.path.join(l1ll1ll11_opy_, l11ll_opy_ (u"ࠧࡱࡴࡨࡪ࡮ࡾࡥࡴ࠰࡭ࡷࡴࡴࠧঋ"))
l1111lll_opy_  = json.load(open(l1111ll1_opy_))
l1111111_opy_      = json.load(open(l11l111l_opy_))
labelmaps = json.load(open(LABELFILE))
l1ll1_opy_  = json.load(open(l1ll11l1l_opy_))
l1ll111l1_opy_ = l11ll_opy_ (u"ࠨࠩঌ")
def l1l1l1lll_opy_(i, t1, l1ll11111_opy_=[]):
 t = l1ll111l1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1ll11111_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11l1111_opy_ = l1l1l1lll_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l111llll_opy_ = l1l1l1lll_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1l1lll11_opy_       = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡦࡩࡹࡼࠧ঍")
l111l1ll_opy_  = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡅࡰࡦࡩ࡫ࡊࡥࡨࡘ࡛࠭঎")
dexter    = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡨࡪࡾࠧএ")
l1ll1l11l_opy_   = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡊࡴࡤ࡭ࡧࡶࡷࠬঐ")
l1ll1lll1_opy_       = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡬ࡡࡣࡪࡲࡷࡹ࡯࡮ࡨࠩ঑")
l1l111l_opy_  = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡆ࡭ࡣࡺࡰࡪࡹࡳࡕࡸࠪ঒")
l1l1llll1_opy_  = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡧࡴࡨࡩࡻ࡯ࡥࡸࠩও")
l1ll1l111_opy_    = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡩࡨ࡬ࡴࡹࡴࡪࡰࡪࠫঔ")
l11lll1_opy_   = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡫ࡳࡷ࡯ࡺࡰࡰ࡬ࡴࡹࡼࠧক")
l1llllll1_opy_  = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡺࡶࡴࡷࡥࡷࠬখ")
l1llll1ll_opy_      = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡯࡯࡮ࡹࡶࡹ࠶ࠬগ")
l1l111l1_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡒࡩ࡮࡫ࡷࡰࡪࡹࡳࡊࡒࡗ࡚ࠬঘ")
l1ll1111l_opy_    = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡌࡪ࡯࡬ࡸࡱ࡫ࡳࡴࡘ࠵ࠫঙ")
l11111ll_opy_  = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡮ࡣࡷࡶ࡮ࡾࡩࡳࡧ࡯ࡥࡳࡪࠧচ")
l11ll1l1_opy_  = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡏࡤࡸࡸࡈࡵࡪ࡮ࡧࡷࡎࡖࡔࡗࠩছ")
l1111l1l_opy_   = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡰࡥࡽ࡯ࡷࡦࡤࡷࡺࠬজ")
l1ll11lll_opy_     = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡱࡨࡱࡴࡷ࠯ࡳࡰࡺࡹࠧঝ")
l1ll111ll_opy_      = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡲ࡫ࡧࡢ࡫ࡳࡸࡻ࠭ঞ")
nice      = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡴࡡࡵࡪࡲࡷࡺࡨࡳࡪࡥࡨࠫট")
l1lll1lll_opy_   = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡰࡳࡧࡰ࡭ࡺࡳࡩࡱࡶࡹࠫঠ")
l1ll1ll1l_opy_  = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡱࡵࡤࡨࡩࡵ࡮ࠨড")
root      = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡲࡳࡹࡏࡐࡕࡘࠪঢ")
l111ll11_opy_     = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡪ࡭ࡿࡳ࡯ࡵࡸࠪণ")
l1l1lllll_opy_    = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡫࡮ࢀ࡭ࡰࡵࡳࡳࡷࡺࡳࠨত")
l1lll1l_opy_      = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡩࡴࡷࠩথ")
l1lllllll_opy_ = l11ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡙ࡵࡱࡴࡨࡱࡦࡩࡹࡕࡘࠪদ")
l1ll111l_opy_   = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡵࡴࡨࡥࡲࡹࡵࡱࡴࡨࡱࡪ࠸ࠧধ")
l1ll11l11_opy_   = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡵࡹ࡬ࡷࡹ࡫ࡤࡵࡸࠪন")
l111l1l_opy_   = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡶࡹ࡯࡮ࡴࡧࡴࠩ঩")
l11l11l1_opy_    = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸ࡯ࡹࡻࡲ࡬ࠩপ")
l1ll_opy_     = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡚ࡆࡊࡅࡓࠩফ")
l1l1l1ll1_opy_   = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡺࡲࡦࡣࡰ࠱ࡨࡵࡤࡦࡵࠪব")
l1ll11ll_opy_    = [l1ll1111l_opy_, nice, l1lll1lll_opy_, l111ll11_opy_, l1l1lllll_opy_, l1ll1l111_opy_, l111l1l_opy_, l11111ll_opy_, l1l1l1ll1_opy_, l1lll1l_opy_, l1ll111l_opy_, l11l11l1_opy_, l1l111l1_opy_, l1ll1lll1_opy_, l1l1lll11_opy_, l11lll1_opy_, root, l1ll111ll_opy_, l1l1llll1_opy_, l1llllll1_opy_, l1llll1ll_opy_, l1ll1l11l_opy_, l1l111l_opy_, l1111l1l_opy_, dexter, l1ll_opy_, l1lllllll_opy_, l1ll11lll_opy_, l1ll11l11_opy_, l1ll1ll1l_opy_, l111l1ll_opy_]
def checkAddons():
    for addon in l1ll11ll_opy_:
        if l1llll1l1_opy_(addon):
            try: createINI(addon)
            except: continue
def l1llll1l1_opy_(addon):
    if xbmc.getCondVisibility(l11ll_opy_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡈࡢࡵࡄࡨࡩࡵ࡮ࠩࠧࡶ࠭ࠬভ") % addon) == 1:
        dixie.log(l11ll_opy_ (u"ࠧ࠾࠿ࡀࡁࠥࡧࡤࡥࡱࡱࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠ࠾࠿ࡀࡁࠬম"))
        dixie.log(addon)
        return True
    return False
def createINI(addon):
    l1lll11l1_opy_  = str(addon).split(l11ll_opy_ (u"ࠨ࠰ࠪয"))[2] + l11ll_opy_ (u"ࠩ࠱࡭ࡳ࡯ࠧর")
    l1l1ll11l_opy_   = os.path.join(l1ll1ll11_opy_, l1lll11l1_opy_)
    response = l11ll1ll_opy_(addon)
    l11l111_opy_ = response[l11ll_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪ঱")][l11ll_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪল")]
    l1lllll11_opy_  = l11ll_opy_ (u"ࠬࡡࠧ঳") + addon + l11ll_opy_ (u"࠭࡝࡝ࡰࠪ঴")
    l11l11ll_opy_  =  file(l1l1ll11l_opy_, l11ll_opy_ (u"ࠧࡸࠩ঵"))
    l11l11ll_opy_.write(l1lllll11_opy_)
    l1lll1ll1_opy_ = []
    for channel in l11l111_opy_:
        l111l111_opy_ = l1l1ll111_opy_(addon)
        l11l1ll1_opy_  = channel[l11ll_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧশ")].split(l11ll_opy_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫষ"), 1)[0]
        if addon == dexter:
            l11l1ll1_opy_ = l11l1ll1_opy_.split(l11ll_opy_ (u"ࠪࠤ࠰ࠦࠧস"), 1)[0]
        if (addon == l1ll11l11_opy_) or (addon == l1ll1111l_opy_) or (addon == nice) or (addon == l111ll11_opy_) or (addon == l1l1lllll_opy_) or (addon == root) or (addon == l1l111l1_opy_) or (addon == l111l1l_opy_) or (addon == l1ll1l111_opy_):
            l11l1ll1_opy_ = l11l1ll1_opy_.split(l11ll_opy_ (u"ࠫࠥ࠳ࠠࠨহ"), 1)[0]
        l1lll1111_opy_ = l1lll1l11_opy_(addon, l11l1ll1_opy_)
        l11l1l11_opy_ = l1l1lll1l_opy_(addon, l1ll1_opy_, labelmaps, l1111lll_opy_, l1111111_opy_, l11l1ll1_opy_)
        stream  = l111l111_opy_ + l1lll1111_opy_
        l111lll1_opy_ = l11l1l11_opy_  + l11ll_opy_ (u"ࠬࡃࠧ঺") + stream
        if l111lll1_opy_ not in l1lll1ll1_opy_:
            l1lll1ll1_opy_.append(l111lll1_opy_)
    l1lll1ll1_opy_.sort()
    for item in l1lll1ll1_opy_:
        l11l11ll_opy_.write(l11ll_opy_ (u"ࠨࠥࡴ࡞ࡱࠦ঻") % item)
    l11l11ll_opy_.close()
def l1lll1l11_opy_(addon, l11l1ll1_opy_):
    if (addon == l1ll11l11_opy_) or (addon == l1ll1111l_opy_) or (addon == nice) or (addon == l1lll1lll_opy_) or (addon == l111ll11_opy_) or (addon == l1l1lllll_opy_) or (addon == root) or (addon == l1l111l1_opy_) or (addon == l1ll1lll1_opy_) or (addon == l1l1l1ll1_opy_) or (addon == l11111ll_opy_) or (addon == l111l1l_opy_) or (addon == l1ll1l111_opy_):
        l1l1111_opy_ = mapping.cleanLabel(l11l1ll1_opy_)
        l1lll1111_opy_ = mapping.editPrefix(l1ll1_opy_, l1l1111_opy_)
        return l1lll1111_opy_
    l1l1111_opy_ = mapping.cleanLabel(l11l1ll1_opy_)
    l1lll1111_opy_ = mapping.cleanStreamLabel(l1l1111_opy_)
    return l1lll1111_opy_
def l1l1lll1l_opy_(addon, l1ll1_opy_, labelmaps, l1111lll_opy_, l1111111_opy_, l11l1ll1_opy_):
    if (addon == l1ll11l11_opy_) or (addon == l1ll1111l_opy_) or (addon == nice) or (addon == l1lll1lll_opy_) or (addon == l111ll11_opy_) or (addon == l1l1lllll_opy_) or (addon == root) or (addon == l1l111l1_opy_) or (addon == l1ll1lll1_opy_) or (addon == l1l1l1ll1_opy_) or (addon == l11111ll_opy_) or (addon == l111l1l_opy_) or (addon == l1ll1l111_opy_):
        return l1l1ll1ll_opy_(l1ll1_opy_, l1111111_opy_, l11l1ll1_opy_)
    l1lllll_opy_    = mapping.cleanLabel(l11l1ll1_opy_)
    l1l1111_opy_ = mapping.mapLabel(labelmaps, l1lllll_opy_)
    l11l1l11_opy_ = mapping.cleanPrefix(l1l1111_opy_)
    return mapping.mapChannelName(l1111lll_opy_, l11l1l11_opy_)
def l1l1ll1ll_opy_(l1ll1_opy_, l1111111_opy_, l11l1ll1_opy_):
    l111l1l1_opy_ = mapping.cleanLabel(l11l1ll1_opy_)
    l1l1111_opy_   = mapping.editPrefix(l1ll1_opy_, l111l1l1_opy_)
    l111ll1l_opy_   = mapping.mapEPGLabel(l1ll1_opy_, l1111111_opy_, l1l1111_opy_)
    return l111ll1l_opy_
def l11ll11l_opy_(addon, file):
    l1lllll_opy_ = file[l11ll_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ়࠭")].split(l11ll_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪঽ"), 1)[0]
    l1lllll_opy_ = l1lllll_opy_.split(l11ll_opy_ (u"ࠩ࠮ࠫা"), 1)[0]
    l1lllll_opy_ = mapping.cleanLabel(l1lllll_opy_)
    return l1lllll_opy_
def l1l1ll111_opy_(addon):
    if addon == l1ll1111l_opy_:
        return l11ll_opy_ (u"ࠪࡐࡎࡓ࠲࠻ࠩি")
    if addon == nice:
        return l11ll_opy_ (u"ࠫࡓࡏࡃࡆ࠼ࠪী")
    if addon == l1lll1lll_opy_:
        return l11ll_opy_ (u"ࠬࡖࡒࡆࡏ࠽ࠫু")
    if addon == l111ll11_opy_:
        return l11ll_opy_ (u"࠭ࡇࡊ࡜࠽ࠫূ")
    if addon == l1l1lllll_opy_:
        return l11ll_opy_ (u"ࠧࡈࡕࡓࡖ࡙࡙࠺ࠨৃ")
    if addon == l1ll1l111_opy_:
        return l11ll_opy_ (u"ࠨࡉࡈࡌ࠿࠭ৄ")
    if addon == l111l1l_opy_:
        return l11ll_opy_ (u"ࠩࡗ࡚ࡐࡀࠧ৅")
    if addon == l11111ll_opy_:
        return l11ll_opy_ (u"ࠪࡑ࡙࡞ࡉࡆ࠼ࠪ৆")
    if addon == l1l1l1ll1_opy_:
        return l11ll_opy_ (u"ࠫ࡝࡚ࡃ࠻ࠩে")
    if addon == l1lll1l_opy_:
        return l11ll_opy_ (u"࡙ࠬࡃࡕࡘ࠽ࠫৈ")
    if addon == l1ll111l_opy_:
        return l11ll_opy_ (u"࠭ࡓࡖࡒ࠽ࠫ৉")
    if addon == l11l11l1_opy_:
        return l11ll_opy_ (u"ࠧࡖࡍࡗ࠾ࠬ৊")
    if addon == l1l111l1_opy_:
        return l11ll_opy_ (u"ࠨࡎࡌࡑࡎ࡚࠺ࠨো")
    if addon == l1ll1lll1_opy_:
        return l11ll_opy_ (u"ࠩࡉࡅࡇࡀࠧৌ")
    if addon == l1l1lll11_opy_:
        return l11ll_opy_ (u"ࠪࡅࡈࡋ࠺ࠨ্")
    if addon == l11lll1_opy_:
        return l11ll_opy_ (u"ࠫࡍࡕࡒࡊ࡜࠽ࠫৎ")
    if addon == root:
        return l11ll_opy_ (u"ࠬࡘࡏࡐࡖ࠵࠾ࠬ৏")
    if addon == l1ll111ll_opy_:
        return l11ll_opy_ (u"࠭ࡍࡆࡉࡄ࠾ࠬ৐")
    if addon == l1l1llll1_opy_:
        return l11ll_opy_ (u"ࠧࡇࡔࡈࡉ࠿࠭৑")
    if addon == l11ll1l1_opy_:
        return l11ll_opy_ (u"ࠨࡏࡄࡘࡘࡀࠧ৒")
    if addon == l1llllll1_opy_:
        return l11ll_opy_ (u"ࠩࡌࡔ࡙࡙࠺ࠨ৓")
    if addon == l1llll1ll_opy_:
        return l11ll_opy_ (u"ࠪࡎࡎࡔࡘ࠳࠼ࠪ৔")
    if addon == l1ll1l11l_opy_:
        return l11ll_opy_ (u"ࠫࡊࡔࡄ࠻ࠩ৕")
    if addon == l1l111l_opy_:
        return l11ll_opy_ (u"ࠬࡌࡌࡂ࠼ࠪ৖")
    if addon == l1111l1l_opy_:
        return l11ll_opy_ (u"࠭ࡍࡂ࡚ࡌ࠾ࠬৗ")
    if addon == dexter:
        return l11ll_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡊ࠺ࠨ৘")
    if addon == l1ll_opy_:
        return l11ll_opy_ (u"ࠨࡘࡇࡖ࡙࡜࠺ࠨ৙")
    if addon == l1lllllll_opy_:
        return l11ll_opy_ (u"ࠩࡖࡔࡗࡓ࠺ࠨ৚")
    if addon == l1ll11lll_opy_:
        return l11ll_opy_ (u"ࠪࡑࡈࡑࡔࡗ࠼ࠪ৛")
    if addon == l1ll11l11_opy_:
        return l11ll_opy_ (u"࡙ࠫ࡝ࡉࡔࡖ࠽ࠫড়")
    if addon == l1ll1ll1l_opy_:
        return l11ll_opy_ (u"ࠬࡖࡒࡆࡕࡗ࠾ࠬঢ়")
    if addon == l111l1ll_opy_:
        return l11ll_opy_ (u"࠭ࡂࡍࡍࡌ࠾ࠬ৞")
def getURL(url):
    if url.startswith(l11ll_opy_ (u"ࠧࡍࡋࡐ࠶ࠬয়")):
        return l11ll111_opy_(url, l1ll1111l_opy_)
    if url.startswith(l11ll_opy_ (u"ࠨࡐࡌࡇࡊ࠭ৠ")):
        return l11ll111_opy_(url, nice)
    if url.startswith(l11ll_opy_ (u"ࠩࡓࡖࡊࡓࠧৡ")):
        return l11ll111_opy_(url, l1lll1lll_opy_)
    if url.startswith(l11ll_opy_ (u"ࠪࡋࡎࡠࠧৢ")):
        return l11ll111_opy_(url, l111ll11_opy_)
    if url.startswith(l11ll_opy_ (u"ࠫࡌ࡙ࡐࡓࡖࡖࠫৣ")):
        return l11ll111_opy_(url, l1l1lllll_opy_)
    if url.startswith(l11ll_opy_ (u"ࠬࡍࡅࡉࠩ৤")):
        return l11ll111_opy_(url, l1ll1l111_opy_)
    if url.startswith(l11ll_opy_ (u"࠭ࡔࡗࡍࠪ৥")):
        return l11ll111_opy_(url, l111l1l_opy_)
    if url.startswith(l11ll_opy_ (u"ࠧࡎࡖ࡛ࡍࡊ࠭০")):
        return l11ll111_opy_(url, l11111ll_opy_)
    if url.startswith(l11ll_opy_ (u"ࠨ࡚ࡗࡇࠬ১")):
        return l11ll111_opy_(url, l1l1l1ll1_opy_)
    if url.startswith(l11ll_opy_ (u"ࠩࡖࡇ࡙࡜ࠧ২")):
        return l11ll111_opy_(url, l1lll1l_opy_)
    if url.startswith(l11ll_opy_ (u"ࠪࡗ࡚ࡖࠧ৩")):
        return l11ll111_opy_(url, l1ll111l_opy_)
    if url.startswith(l11ll_opy_ (u"࡚ࠫࡑࡔࠨ৪")):
        return l11ll111_opy_(url, l11l11l1_opy_)
    if url.startswith(l11ll_opy_ (u"ࠬࡒࡉࡎࡋࡗࠫ৫")):
        return l11ll111_opy_(url, l1l111l1_opy_)
    if url.startswith(l11ll_opy_ (u"࠭ࡆࡂࡄࠪ৬")):
        return l11ll111_opy_(url, l1ll1lll1_opy_)
    if url.startswith(l11ll_opy_ (u"ࠧࡂࡅࡈࠫ৭")):
        return l11ll111_opy_(url, l1l1lll11_opy_)
    if url.startswith(l11ll_opy_ (u"ࠨࡊࡒࡖࡎࡠࠧ৮")):
        return l11ll111_opy_(url, l11lll1_opy_)
    if url.startswith(l11ll_opy_ (u"ࠩࡕࡓࡔ࡚࠲ࠨ৯")):
        return l11ll111_opy_(url, root)
    if url.startswith(l11ll_opy_ (u"ࠪࡑࡊࡍࡁࠨৰ")):
        return l11ll111_opy_(url, l1ll111ll_opy_)
    if url.startswith(l11ll_opy_ (u"ࠫࡋࡘࡅࡆࠩৱ")):
        return l11ll111_opy_(url, l1l1llll1_opy_)
    if url.startswith(l11ll_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡇࡑ࡛࠺ࠨ৲")):
        url = url.replace(l11ll_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡈࡒࡕ࠻ࠩ৳"), l11ll_opy_ (u"ࠧࠨ৴")).replace(l11ll_opy_ (u"ࠨ࠯࠰ࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧ৵"), l11ll_opy_ (u"ࠩࡿࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧ৶"))
        return url
    if url.startswith(l11ll_opy_ (u"ࠪࡑࡆ࡚ࡓࠨ৷")):
        return l11ll111_opy_(url, l11ll1l1_opy_)
    if url.startswith(l11ll_opy_ (u"ࠫࡎࡖࡔࡔࠩ৸")):
        return l11ll111_opy_(url, l1llllll1_opy_)
    if url.startswith(l11ll_opy_ (u"ࠬࡐࡉࡏ࡚࠵ࠫ৹")):
        return l11ll111_opy_(url, l1llll1ll_opy_)
    if url.startswith(l11ll_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡉ࠭৺")):
        return l11ll111_opy_(url, dexter)
    if url.startswith(l11ll_opy_ (u"ࠧࡇࡎࡄࠫ৻")):
        return l11ll111_opy_(url, l1l111l_opy_)
    if url.startswith(l11ll_opy_ (u"ࠨࡏࡄ࡜ࡎ࠭ৼ")):
        return l11ll111_opy_(url, l1111l1l_opy_)
    if url.startswith(l11ll_opy_ (u"ࠩࡈࡒࡉ࠭৽")):
        return l11ll111_opy_(url, l1ll1l11l_opy_)
    if url.startswith(l11ll_opy_ (u"࡚ࠪࡉࡘࡔࡗࠩ৾")):
        return l11ll111_opy_(url, l1ll_opy_)
    if url.startswith(l11ll_opy_ (u"ࠫࡘࡖࡒࡎࠩ৿")):
        return l11ll111_opy_(url, l1lllllll_opy_)
    if url.startswith(l11ll_opy_ (u"ࠬࡓࡃࡌࡖ࡙ࠫ਀")):
        return l11ll111_opy_(url, l1ll11lll_opy_)
    if url.startswith(l11ll_opy_ (u"࠭ࡔࡘࡋࡖࡘࠬਁ")):
        return l11ll111_opy_(url, l1ll11l11_opy_)
    if url.startswith(l11ll_opy_ (u"ࠧࡑࡔࡈࡗ࡙࠭ਂ")):
        return l11ll111_opy_(url, l1ll1ll1l_opy_)
    if url.startswith(l11ll_opy_ (u"ࠨࡄࡏࡏࡎ࠭ਃ")):
        return l11ll111_opy_(url, l111l1ll_opy_)
    response  = l11l1lll_opy_(url)
    l1llll111_opy_ = url.split(l11ll_opy_ (u"ࠩ࠽ࠫ਄"), 1)[-1]
    l1llll111_opy_ = l1llll111_opy_.upper().replace(l11ll_opy_ (u"ࠪࠤࠬਅ"), l11ll_opy_ (u"ࠫࠬਆ"))
    try:
        result = response[l11ll_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬਇ")]
        l111111_opy_  = result[l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬਈ")]
    except Exception as e:
        l1ll1l1l1_opy_(e)
        return None
    for file in l111111_opy_:
        l11l1ll1_opy_  = file[l11ll_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ਉ")].split(l11ll_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪਊ"), 1)[0]
        l1l1lll_opy_  = l11l1ll1_opy_.split(l11ll_opy_ (u"ࠩ࠮ࠫ਋"), 1)[0]
        l1ll1l1ll_opy_ = mapping.cleanLabel(l1l1lll_opy_)
        l1ll1l1ll_opy_ = l1ll1l1ll_opy_.upper().replace(l11ll_opy_ (u"ࠪࠤࠬ਌"), l11ll_opy_ (u"ࠫࠬ਍"))
        try:
            if l1llll111_opy_ == l1ll1l1ll_opy_:
                return file[l11ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪ਎")]
        except:
            if (l1llll111_opy_ in l1ll1l1ll_opy_) or (l1ll1l1ll_opy_ in l1llll111_opy_):
                return file[l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࠫਏ")]
    return None
def l11ll111_opy_(url, addon):
    PATH = l11l1l1l_opy_(addon)
    try:
        response = json.load(open(PATH))
    except:
        response = l11ll1ll_opy_(addon)
    l1l111ll_opy_      = url.split(l11ll_opy_ (u"ࠧ࠻ࠩਐ"), 1)[-1]
    stream    = l1l111ll_opy_.split(l11ll_opy_ (u"ࠨࠢ࡞ࠫ਑"), 1)[0]
    l1llll111_opy_ = mapping.cleanLabel(stream)
    l1llll111_opy_ = l1llll111_opy_.upper().replace(l11ll_opy_ (u"ࠩࠣࠫ਒"), l11ll_opy_ (u"ࠪࠫਓ"))
    l111111_opy_  = response[l11ll_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫਔ")][l11ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫਕ")]
    for file in l111111_opy_:
        l11l1ll1_opy_  = file[l11ll_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬਖ")].split(l11ll_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩਗ"), 1)[0]
        if addon == dexter:
            l11l1ll1_opy_ = l11l1ll1_opy_.split(l11ll_opy_ (u"ࠨࠢ࠮ࠤࠬਘ"), 1)[0]
        if (addon == l1ll11l11_opy_) or (addon == l1ll1111l_opy_) or (addon == nice) or (addon == l111ll11_opy_) or (addon == l1l1lllll_opy_) or (addon == root) or (addon == l1l111l1_opy_) or (addon == l111l1l_opy_) or (addon == l1ll1l111_opy_):
            l11l1ll1_opy_ = l11l1ll1_opy_.split(l11ll_opy_ (u"ࠩࠣ࠱ࠥ࠭ਙ"), 1)[0]
        l1ll1l1ll_opy_ = l1lll1l11_opy_(addon, l11l1ll1_opy_)
        l1ll1l1ll_opy_ = l1ll1l1ll_opy_.upper().replace(l11ll_opy_ (u"ࠪࠤࠬਚ"), l11ll_opy_ (u"ࠫࠬਛ"))
        try:
            if l1llll111_opy_ == l1ll1l1ll_opy_:
                return file[l11ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪਜ")]
        except:
            if (l1llll111_opy_ in l1ll1l1ll_opy_) or (l1ll1l1ll_opy_ in l1llll111_opy_):
                return file[l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࠫਝ")]
    return None
def l11ll1ll_opy_(addon):
    PATH  = l11l1l1l_opy_(addon)
    if addon == l1ll_opy_:
        query = l11ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡘࡄࡈࡊࡘ࠯࡭࡫ࡹࡩࡹࡼ࠯ࡢ࡮࡯࠳ࠬਞ")
    elif addon == l1ll111l_opy_:
        query = l11ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡸࡷ࡫ࡡ࡮ࡵࡸࡴࡷ࡫࡭ࡦ࠴࠲ࡰ࡮ࡼࡥࡵࡸ࠲ࡥࡱࡲ࠯ࠨਟ")
    elif addon == l1lll1l_opy_:
        query = l11ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡨࡺࡶ࠰࡮࡬ࡺࡪࡺࡶ࠰ࡣ࡯ࡰ࠴࠭ਠ")
    elif addon == l1ll111l_opy_:
        query = l11ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡺࡲࡦࡣࡰࡷࡺࡶࡲࡦ࡯ࡨ࠶࠴ࡲࡩࡷࡧࡷࡺ࠴ࡧ࡬࡭࠱ࠪਡ")
    elif addon == l1l1llll1_opy_:
        query = l11ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡬ࡲࡦࡧࡹ࡭ࡪࡽ࠯ࡀࡷࡵࡰࡂࡻࡲ࡭ࠨࡰࡳࡩ࡫࠽࠶ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡹࡩ࠰࡚ࡖࠨਢ")
    elif addon == l11l11l1_opy_:
        query = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡵ࡬ࡶࡸࡶࡰ࠵࠿ࡶࡴ࡯ࡁ࡭ࡺࡴࡱࠧ࠶ࡅࠪ࠸ࡆࠦ࠴ࡉࡥࡩࡪ࡯࡯ࡥ࡯ࡳࡺࡪ࠮ࡰࡴࡪࠩ࠷ࡌࡵ࡬ࡶࡸࡶࡰࠫ࠲ࡇࡗࡎࡘࡺࡸ࡫ࠦ࠴ࡉࡐ࡮ࡼࡥࠦ࠴࠸࠶࠵࡚ࡖ࠯ࡶࡻࡸࠫࡳ࡯ࡥࡧࡀ࠵ࠫࡴࡡ࡮ࡧࡀࡐ࡮ࡼࡥࠬࡖ࡙ࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠩࡪࡦࡴࡡࡳࡶࡀࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠨਣ")
    else:
        query = l1lll111l_opy_(addon)
    try:
        return json.load(open(PATH))
    except:
        content = doJSON(query)
        return l1lllll1l_opy_(PATH, addon, content)
def l1lllll1l_opy_(PATH, addon, content):
    json.dump(content, open(PATH,l11ll_opy_ (u"࠭ࡷࠨਤ")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    l1l1l11_opy_  = (l11ll_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪਥ") % query)
    response = xbmc.executeJSONRPC(l1l1l11_opy_)
    content  = json.loads(response)
    return content
def l11l1l1l_opy_(addon):
    if addon == l1ll1111l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠨ࡮࡬ࡱ࠷ࡺࡥ࡮ࡲࠪਦ"))
    if addon == nice:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠩࡱ࡭ࡨ࡫ࡴࡦ࡯ࡳࠫਧ"))
    if addon == l1lll1lll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠪࡴࡷ࡫࡭ࡵࡧࡰࡴࠬਨ"))
    if addon == l111ll11_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠫ࡬࡯ࡺࡵࡧࡰࡴࠬ਩"))
    if addon == l1l1lllll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠬ࡭ࡳࡱࡴࡷࡷࡹ࡫࡭ࡱࠩਪ"))
    if addon == l1ll1l111_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"࠭ࡧࡦࡶࡨࡱࡵ࠭ਫ"))
    if addon == l11111ll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠧ࡮ࡶࡻࡸࡪࡳࡰࠨਬ"))
    if addon == l111l1l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠨࡶࡹ࡯ࡹ࡫࡭ࡱࠩਭ"))
    if addon == l1l1l1ll1_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠩࡻࡸࡪࡳࡰࠨਮ"))
    if addon == l1lll1l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠪࡷࡨࡺࡥ࡮ࡲࠪਯ"))
    if addon == l1ll111l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠫࡸࡻࡰࡵࡧࡰࡴࠬਰ"))
    if addon == l11l11l1_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠬࡻ࡫ࡵࡶࡨࡱࡵ࠭਱"))
    if addon == l1l111l1_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"࠭࡬ࡪ࡯࡬ࡸࡪࡳࡰࠨਲ"))
    if addon == l1ll1lll1_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠧࡧࡣࡥࡸࡪࡳࡰࠨਲ਼"))
    if addon == l1l1lll11_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠨࡣࡦࡩࡹ࡫࡭ࡱࠩ਴"))
    if addon == l11lll1_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠩ࡫ࡳࡷࡺࡥ࡮ࡲࠪਵ"))
    if addon == root:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠪࡶࡴ࠸ࡴࡦ࡯ࡳࠫਸ਼"))
    if addon == l1ll111ll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠫࡲ࡫ࡧࡢࡶࡰࡴࠬ਷"))
    if addon == l11ll1l1_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠬࡳࡡࡵࡵࡷࡱࡵ࠭ਸ"))
    if addon == l1l1llll1_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"࠭ࡦࡳࡧࡨࡸࡲࡶࠧਹ"))
    if addon == l1llllll1_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠧࡪࡲࡷࡷࡹࡳࡰࠨ਺"))
    if addon == l1llll1ll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠨ࡬࠵ࡸࡪࡳࡰࠨ਻"))
    if addon == l1ll1l11l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠩࡨࡸࡪࡳࡰࠨ਼"))
    if addon == l1l111l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠪࡪࡹ࡫࡭ࡱࠩ਽"))
    if addon == l1111l1l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠫࡲࡧࡸࡵࡧࡰࡴࠬਾ"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠬࡪࡴࡦ࡯ࡳࠫਿ"))
    if addon == l1ll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"࠭ࡶࡥࡶࡨࡱࡵ࠭ੀ"))
    if addon == l1lllllll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠧࡴࡲࡵࡸࡪࡳࡰࠨੁ"))
    if addon == l1ll11lll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠨ࡯ࡦ࡯ࡹ࡫࡭ࡱࠩੂ"))
    if addon == l1ll11l11_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠩࡷࡻ࡮ࡺࡥ࡮ࡲࠪ੃"))
    if addon == l1ll1ll1l_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠪࡴࡷ࡫ࡳࡵࡧࡰࡴࠬ੄"))
    if addon == l111l1ll_opy_:
        return os.path.join(dixie.PROFILE, l11ll_opy_ (u"ࠫࡧࡲ࡫ࡪࡶࡨࡱࡵ࠭੅"))
def l1lll111l_opy_(addon):
    query = l11ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ੆") + addon
    response = doJSON(query)
    l111111_opy_    = response[l11ll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ੇ")][l11ll_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ੈ")]
    for file in l111111_opy_:
        l1lll11ll_opy_ = file[l11ll_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧ੉")]
        l1lllll_opy_ = mapping.cleanLabel(l1lll11ll_opy_)
        l1lllll_opy_ = l1lllll_opy_.upper()
        if (l1lllll_opy_ == l11ll_opy_ (u"ࠩࡏࡍ࡛ࡋࠠࡊࡒࡗ࡚ࠬ੊")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠪࡐࡎ࡜ࡅࠡࡖ࡙ࠫੋ")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠫࡑࡏࡖࡆࠢࡆࡌࡆࡔࡎࡆࡎࡖࠫੌ")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠬࡒࡉࡗࡇ੍ࠪ")) or (l1lllll_opy_ == l11ll_opy_ (u"࠭ࡅࡏࡆࡏࡉࡘ࡙ࠠࡎࡇࡇࡍࡆ࠭੎")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠧࡇࡎࡄ࡛ࡑࡋࡓࡔࡖ࡙ࠫ੏")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠨࡏࡄ࡜ࡎ࡝ࡅࡃࠢࡗ࡚ࠬ੐")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠩࡅࡐࡆࡉࡋࡊࡅࡈࠤ࡙࡜ࠧੑ")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠪࡌࡔࡘࡉ࡛ࡑࡑࠤࡎࡖࡔࡗࠩ੒")) or (l1lllll_opy_ == l11ll_opy_ (u"ࠫࡋࡇࡂࠡࡋࡓࡘ࡛࠭੓")):
            livetv = file[l11ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪ੔")]
            return l111l11l_opy_(livetv)
def l111l11l_opy_(livetv):
    response = doJSON(livetv)
    l111111_opy_    = response[l11ll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭੕")][l11ll_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭੖")]
    for file in l111111_opy_:
        l1lll11ll_opy_ = file[l11ll_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧ੗")]
        l1lllll_opy_ = mapping.cleanLabel(l1lll11ll_opy_)
        l1lllll_opy_ = l1lllll_opy_.upper()
        if l1lllll_opy_ == l11ll_opy_ (u"ࠩࡄࡐࡑ࠭੘"):
            return file[l11ll_opy_ (u"ࠪࡪ࡮ࡲࡥࠨਖ਼")]
def l1llll11l_opy_(l1lll1l1l_opy_):
    items = []
    _1ll1llll_opy_(l1lll1l1l_opy_, items)
    return items
def _1ll1llll_opy_(l1lll1l1l_opy_, items):
    response = doJSON(l1lll1l1l_opy_)
    if response[l11ll_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫਗ਼")].has_key(l11ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫਜ਼")):
        result = response[l11ll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ੜ")][l11ll_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭੝")]
        for item in result:
            if item[l11ll_opy_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪਫ਼")] == l11ll_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧ੟"):
                l1lllll_opy_ = mapping.cleanLabel(item[l11ll_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩ੠")])
                items.append(item)
            elif item[l11ll_opy_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭੡")] == l11ll_opy_ (u"ࠬࡪࡩࡳࡧࡦࡸࡴࡸࡹࠨ੢"):
                l1lllll_opy_ = mapping.cleanLabel(item[l11ll_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬ੣")])
                l1ll11ll1_opy_  = item[l11ll_opy_ (u"ࠧࡧ࡫࡯ࡩࠬ੤")]
                dixie.log(item)
                dixie.log(l1ll11ll1_opy_)
                _1ll1llll_opy_(l1ll11ll1_opy_, items)
def l11l1lll_opy_(url):
    if url.startswith(l11ll_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠺ࠨ੥")):
        l1l1l11_opy_ = (l11ll_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡨࡢࡤ࡫ࡳࡰࡦࡿࡥࡳ࠱ࡂࡹࡷࡲ࠽ࡶࡴ࡯ࠪࡲࡵࡤࡦ࠿࠵ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡻ࡫ࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠩࡍࡕࡏࡄ࠾ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧ੦"))
    if url.startswith(l11ll_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠴࠽ࠫ੧")):
        l1l1l11_opy_ = (l11ll_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺ࠳ࡄࡻࡲ࡭࠿ࡸࡶࡱࠬ࡭ࡰࡦࡨࡁ࠶࠶࠱ࠧࡰࡤࡱࡪࡃࡗࡢࡶࡦ࡬࠰ࡒࡩࡷࡧࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࡂࠬࡳࡶࡤࡷ࡭ࡹࡲࡥࡴࡡࡸࡶࡱࡃࠦ࡭ࡱࡪ࡫ࡪࡪ࡟ࡪࡰࡀࡊࡦࡲࡳࡦࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧ੨"))
    if url.startswith(l11ll_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖ࠿࠭੩")):
        l1l1l11_opy_ = (l11ll_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠵࠿ࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠫࡲ࡯ࡨࡩࡨࡨࡤ࡯࡮࠾ࡈࡤࡰࡸ࡫ࠦ࡮ࡱࡧࡩࡂ࠷࠱࠴ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡶࡸࡪࡴࠥ࠳࠲ࡏ࡭ࡻ࡫ࠦࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡵࡢࡹࡷࡲࠦࡶࡴ࡯ࡁࡺࡸ࡬ࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭੪"))
    if url.startswith(l11ll_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡏࡔࡗ࠼ࠪ੫")):
        l1l1l11_opy_ = (l11ll_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡺࡶࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭੬"))
    if url.startswith(l11ll_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪ੭")):
        l1l1l11_opy_ = (l11ll_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡤࡦࡺ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡦࡲ࡬ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠦࡵ࡫ࡷࡰࡪࡃࠥ࠶ࡤࡆࡓࡑࡕࡒࠦ࠴࠳ࡻ࡭࡯ࡴࡦࠧ࠸ࡨࡆࡲ࡬ࠦ࠴࠳ࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠪ࠻ࡢࠦ࠴ࡩࡇࡔࡒࡏࡓࠧ࠸ࡨࠫࡻࡲ࡭ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧ੮"))
    if url.startswith(l11ll_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡕࡆ࠿࠭੯")):
        l1l1l11_opy_ = (l11ll_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡨࡦࡴࡵࡴ࠰ࡁࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠦࡧࡣࡱࡥࡷࡺ࠽ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡳ࡯ࡥࡧࡀ࠻ࠫࡶࡩ࡭࡮ࡲࡻࡂࡒࡩࡷࡧࠨ࠶࠵࡙ࡴࡳࡧࡤࡱࡸࠬࡵࡳ࡮ࡀࡶࡦࡴࡤࡰ࡯ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨੰ"))
    try:
        dixie.ShowBusy()
        addon =  l1l1l11_opy_.split(l11ll_opy_ (u"࠭࠯࠰ࠩੱ"), 1)[-1].split(l11ll_opy_ (u"ࠧ࠰ࠩੲ"), 1)[0]
        login = l11ll_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ੳ") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1l1l11_opy_)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1ll1l1l1_opy_(e)
        return {l11ll_opy_ (u"ࠩࡈࡶࡷࡵࡲࠨੴ") : l11ll_opy_ (u"ࠪࡔࡱࡻࡧࡪࡰࠣࡉࡷࡸ࡯ࡳࠩੵ")}
def l111111l_opy_():
    modules = map(__import__, [l1l1l1lll_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11l1111_opy_)):
        return l11ll_opy_ (u"࡙ࠫࡸࡵࡦࠩ੶")
    if len(modules[-1].Window(10**4).getProperty(l111llll_opy_)):
        return l11ll_opy_ (u"࡚ࠬࡲࡶࡧࠪ੷")
    return l11ll_opy_ (u"࠭ࡆࡢ࡮ࡶࡩࠬ੸")
def l1ll1l1l1_opy_(e):
    l11111l1_opy_ = l11ll_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠲ࠠࡢࡰࠣࡩࡷࡸ࡯ࡳࠢࡲࡧࡨࡻࡲࡦࡦ࠽ࠤࡏ࡙ࡏࡏࠢࡈࡶࡷࡵࡲ࠻ࠢࠨࡷࠬ੹")  %e
    l1l1ll1l1_opy_ = l11ll_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡴࡨ࠱ࡱ࡯࡮࡬ࠢࡷ࡬࡮ࡹࠠࡤࡪࡤࡲࡳ࡫࡬ࠡࡣࡱࡨࠥࡺࡲࡺࠢࡤ࡫ࡦ࡯࡮࠯ࠩ੺")
    l1111l11_opy_ = l11ll_opy_ (u"ࠩࡘࡷࡪࡀࠠࡄࡱࡱࡸࡪࡾࡴࠡࡏࡨࡲࡺࠦ࠽࠿ࠢࡕࡩࡲࡵࡶࡦࠢࡖࡸࡷ࡫ࡡ࡮ࠩ੻")
    dixie.log(e)
    dixie.DialogOK(l11111l1_opy_, l1l1ll1l1_opy_, l1111l11_opy_)
if __name__ == l11ll_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬ੼"):
    checkAddons()