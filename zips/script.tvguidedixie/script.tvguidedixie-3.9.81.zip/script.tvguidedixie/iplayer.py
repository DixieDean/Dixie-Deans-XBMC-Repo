# coding: UTF-8
import sys
l1l11l1_opy_ = sys.version_info [0] == 2
l1l111l_opy_ = 2048
l1l1l1_opy_ = 7
def l1ll1ll_opy_ (ll_opy_):
	global l1ll1l_opy_
	l1lll111_opy_ = ord (ll_opy_ [-1])
	l1l1l1l_opy_ = ll_opy_ [:-1]
	l1111ll_opy_ = l1lll111_opy_ % len (l1l1l1l_opy_)
	l1lllll1_opy_ = l1l1l1l_opy_ [:l1111ll_opy_] + l1l1l1l_opy_ [l1111ll_opy_:]
	if l1l11l1_opy_:
		l11l1ll_opy_ = unicode () .join ([unichr (ord (char) - l1l111l_opy_ - (l1llll1_opy_ + l1lll111_opy_) % l1l1l1_opy_) for l1llll1_opy_, char in enumerate (l1lllll1_opy_)])
	else:
		l11l1ll_opy_ = str () .join ([chr (ord (char) - l1l111l_opy_ - (l1llll1_opy_ + l1lll111_opy_) % l1l1l1_opy_) for l1llll1_opy_, char in enumerate (l1lllll1_opy_)])
	return eval (l11l1ll_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
import mapping
ADDON    = dixie.ADDON
l1111l_opy_ = dixie.PROFILE
l111ll_opy_  = os.path.join(l1111l_opy_, l1ll1ll_opy_ (u"ࠫ࡮ࡴࡩࠨࠀ"))
l1lll1l1_opy_ = l1ll1ll_opy_ (u"ࠬ࠭ࠁ")
def l1l1llll_opy_(i, t1, l1lll11l_opy_=[]):
 t = l1lll1l1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1lll11l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11l1_opy_ = l1l1llll_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l111l_opy_ = l1l1llll_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l11ll11_opy_  = l1ll1ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡬ࡲࡦࡧࡹ࡭ࡪࡽࠧࠂ")
l11_opy_  = l1ll1ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡍࡢࡶࡶࡆࡺ࡯࡬ࡥࡵࡌࡔ࡙࡜ࠧࠃ")
l1lll11_opy_  = l1ll1ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲࡷࡺࡸࡻࡢࡴࠩࠄ")
l1l1ll1_opy_      = l1ll1ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡬࡬ࡲࡽࡺࡶ࠳ࠩࠅ")
l1ll111_opy_  = l1ll1ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡳࡴࡺࡩࡱࡶࡹࠫࠆ")
l1llllll_opy_   = l1ll1ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡉࡳࡪ࡬ࡦࡵࡶࠫࠇ")
l1ll1ll1_opy_  = l1ll1ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡋࡲࡡࡸ࡮ࡨࡷࡸ࡚ࡶࠨࠈ")
dexter    = l1ll1ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡪࡥࡹࠩࠉ")
l11ll_opy_     = l1ll1ll_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡖࡂࡆࡈࡖࠬࠊ")
l11l1l_opy_ = l1ll1ll_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡔࡷࡳࡶࡪࡳࡡࡤࡻࡗ࡚ࠬࠋ")
l1lll1l_opy_     = l1ll1ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡯ࡦ࡯ࡹࡼ࠭ࡱ࡮ࡸࡷࠬࠌ")
l1lll1ll_opy_   = l1ll1ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡷࡻ࡮ࡹࡴࡦࡦࠪࠍ")
l11l1l1_opy_  = l1ll1ll_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡴࡸࡧࡤࡥࡱࡱࠫࠎ")
l1l11l_opy_  = l1ll1ll_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡇࡲࡡࡤ࡭ࡌࡧࡪ࡚ࡖࠨࠏ")
l1ll111l_opy_    = [l11ll11_opy_, l11_opy_, l1lll11_opy_, l1l1ll1_opy_, l1ll111_opy_, l1llllll_opy_, l1ll1ll1_opy_, dexter, l11ll_opy_, l11l1l_opy_, l1lll1l_opy_, l1lll1ll_opy_, l11l1l1_opy_, l1l11l_opy_]
def checkAddons():
    for addon in l1ll111l_opy_:
        if l1ll1l11_opy_(addon):
            createINI(addon)
def l1ll1l11_opy_(addon):
    if xbmc.getCondVisibility(l1ll1ll_opy_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡈࡢࡵࡄࡨࡩࡵ࡮ࠩࠧࡶ࠭ࠬࠐ") % addon) == 1:
        return True
    return False
def createINI(addon):
    HOME  = dixie.PROFILE
    l1ll11_opy_ = os.path.join(HOME, l1ll1ll_opy_ (u"ࠧࡪࡰ࡬ࠫࠑ"))
    l11l111_opy_  = str(addon).split(l1ll1ll_opy_ (u"ࠨ࠰ࠪࠒ"))[2] + l1ll1ll_opy_ (u"ࠩ࠱࡭ࡳ࡯ࠧࠓ")
    l1l_opy_   = os.path.join(l1ll11_opy_, l11l111_opy_)
    l11l11_opy_   = os.path.join(l1ll11_opy_, l1ll1ll_opy_ (u"ࠪࡱࡦࡶࡰࡪࡰࡪࡷ࠳ࡰࡳࡰࡰࠪࠔ"))
    l1l1111_opy_ = os.path.join(l1ll11_opy_, l1ll1ll_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࡶ࠲࡯ࡹ࡯࡯ࠩࠕ"))
    l111l1_opy_  = json.load(open(l11l11_opy_))
    l111lll_opy_ = json.load(open(l1l1111_opy_))
    response = l1_opy_(addon)
    l1ll1l1_opy_ = response[l1ll1ll_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬࠖ")][l1ll1ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬࠗ")]
    l1l1lll_opy_  = l1ll1ll_opy_ (u"ࠧ࡜ࠩ࠘") + addon + l1ll1ll_opy_ (u"ࠨ࡟࡟ࡲࠬ࠙")
    l1l11_opy_  =  file(l1l_opy_, l1ll1ll_opy_ (u"ࠩࡺࠫࠚ"))
    l1l11_opy_.write(l1l1lll_opy_)
    l1ll11l1_opy_ = []
    for channel in l1ll1l1_opy_:
        l11ll1_opy_ = l1l111_opy_(addon)
        l1lll_opy_  = channel[l1ll1ll_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࠛ")].split(l1ll1ll_opy_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠜ"), 1)[0]
        l1111l1_opy_  = l1lll_opy_.split(l1ll1ll_opy_ (u"ࠬ࠱ࠧࠝ"), 1)[0]
        l111l1l_opy_  = l11ll1l_opy_(l1111l1_opy_)
        l1l1l_opy_  = l1ll1lll_opy_(l111lll_opy_, l111l1_opy_, l1111l1_opy_)
        stream  = l11ll1_opy_ + l111l1l_opy_
        l1111_opy_ = l1l1l_opy_  + l1ll1ll_opy_ (u"࠭࠽ࠨࠞ") + stream
        if l1111_opy_ not in l1ll11l1_opy_:
            l1ll11l1_opy_.append(l1111_opy_)
    l1ll11l1_opy_.sort()
    for item in l1ll11l1_opy_:
        l1l11_opy_.write(l1ll1ll_opy_ (u"ࠢࠦࡵ࡟ࡲࠧࠟ") % item)
    l1l11_opy_.close()
def l11ll1l_opy_(l1111l1_opy_):
    l111l1l_opy_ = mapping.cleanLabel(l1111l1_opy_)
    return l111l1l_opy_
def l1ll1lll_opy_(l111lll_opy_, l111l1_opy_, l1111l1_opy_):
    l1lllll_opy_    = mapping.cleanLabel(l1111l1_opy_)
    l1ll1l1l_opy_ = mapping.mapLabel(l111lll_opy_, l1lllll_opy_)
    l1l1l_opy_ = mapping.cleanPrefix(l1ll1l1l_opy_)
    return mapping.mapChannelName(l111l1_opy_, l1l1l_opy_)
def l1ll_opy_(addon, file):
    l1lllll_opy_ = file[l1ll1ll_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࠠ")].split(l1ll1ll_opy_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࠡ"), 1)[0]
    l1lllll_opy_ = l1lllll_opy_.split(l1ll1ll_opy_ (u"ࠪ࠯ࠬࠢ"), 1)[0]
    l1lllll_opy_ = mapping.cleanLabel(l1lllll_opy_)
    return l1lllll_opy_
def l1l111_opy_(addon):
    if addon == l11ll11_opy_:
        return l1ll1ll_opy_ (u"ࠫࡋࡘࡅࡆ࠼ࠪࠣ")
    if addon == l11_opy_:
        return l1ll1ll_opy_ (u"ࠬࡓࡁࡕࡕ࠽ࠫࠤ")
    if addon == l1lll11_opy_:
        return l1ll1ll_opy_ (u"࠭ࡉࡑࡖࡖ࠾ࠬࠥ")
    if addon == l1l1ll1_opy_:
        return l1ll1ll_opy_ (u"ࠧࡋࡋࡑ࡜࠷ࡀࠧࠦ")
    if addon == l1ll111_opy_:
        return l1ll1ll_opy_ (u"ࠨࡔࡒࡓ࡙ࡀࠧࠧ")
    if addon == l1llllll_opy_:
        return l1ll1ll_opy_ (u"ࠩࡈࡒࡉࡀࠧࠨ")
    if addon == l1ll1ll1_opy_:
        return l1ll1ll_opy_ (u"ࠪࡊࡑࡇ࠺ࠨࠩ")
    if addon == dexter:
        return l1ll1ll_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡇ࠾ࠬࠪ")
    if addon == l11ll_opy_:
        return l1ll1ll_opy_ (u"ࠬ࡜ࡄࡓࡖ࡙࠾ࠬࠫ")
    if addon == l11l1l_opy_:
        return l1ll1ll_opy_ (u"࠭ࡓࡑࡔࡐ࠾ࠬࠬ")
    if addon == l1lll1l_opy_:
        return l1ll1ll_opy_ (u"ࠧࡎࡅࡎࡘ࡛ࡀࠧ࠭")
    if addon == l1lll1ll_opy_:
        return l1ll1ll_opy_ (u"ࠨࡖ࡚ࡍࡘ࡚࠺ࠨ࠮")
    if addon == l11l1l1_opy_:
        return l1ll1ll_opy_ (u"ࠩࡓࡖࡊ࡙ࡔ࠻ࠩ࠯")
    if addon == l1l11l_opy_:
        return l1ll1ll_opy_ (u"ࠪࡆࡑࡑࡉ࠻ࠩ࠰")
def getURL(url):
    if url.startswith(l1ll1ll_opy_ (u"ࠫࡋࡘࡅࡆࠩ࠱")):
        return l11l_opy_(url, l11ll11_opy_)
    if url.startswith(l1ll1ll_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡇࡑ࡛࠺ࠨ࠲")):
        url = url.replace(l1ll1ll_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡈࡒࡕ࠻ࠩ࠳"), l1ll1ll_opy_ (u"ࠧࠨ࠴")).replace(l1ll1ll_opy_ (u"ࠨ࠯࠰ࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧ࠵"), l1ll1ll_opy_ (u"ࠩࡿࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧ࠶"))
        return url
    if url.startswith(l1ll1ll_opy_ (u"ࠪࡑࡆ࡚ࡓࠨ࠷")):
        return l11l_opy_(url, l11_opy_)
    if url.startswith(l1ll1ll_opy_ (u"ࠫࡎࡖࡔࡔࠩ࠸")):
        return l11l_opy_(url, l1lll11_opy_)
    if url.startswith(l1ll1ll_opy_ (u"ࠬࡐࡉࡏ࡚࠵ࠫ࠹")):
        return l11l_opy_(url, l1l1ll1_opy_)
    if url.startswith(l1ll1ll_opy_ (u"࠭ࡒࡐࡑࡗࠫ࠺")):
        return l11l_opy_(url, l1ll111_opy_)
    if url.startswith(l1ll1ll_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡊࠧ࠻")):
        return l11l_opy_(url, dexter)
    if url.startswith(l1ll1ll_opy_ (u"ࠨࡈࡏࡅࠬ࠼")):
        return l11l_opy_(url, l1ll1ll1_opy_)
    if url.startswith(l1ll1ll_opy_ (u"ࠩࡈࡒࡉ࠭࠽")):
        return l11l_opy_(url, l1llllll_opy_)
    if url.startswith(l1ll1ll_opy_ (u"࡚ࠪࡉࡘࡔࡗࠩ࠾")):
        return l11l_opy_(url, l11ll_opy_)
    if url.startswith(l1ll1ll_opy_ (u"ࠫࡘࡖࡒࡎࠩ࠿")):
        return l11l_opy_(url, l11l1l_opy_)
    if url.startswith(l1ll1ll_opy_ (u"ࠬࡓࡃࡌࡖ࡙ࠫࡀ")):
        return l11l_opy_(url, l1lll1l_opy_)
    if url.startswith(l1ll1ll_opy_ (u"࠭ࡔࡘࡋࡖࡘࠬࡁ")):
        return l11l_opy_(url, l1lll1ll_opy_)
    if url.startswith(l1ll1ll_opy_ (u"ࠧࡑࡔࡈࡗ࡙࠭ࡂ")):
        return l11l_opy_(url, l11l1l1_opy_)
    if url.startswith(l1ll1ll_opy_ (u"ࠨࡄࡏࡏࡎ࠭ࡃ")):
        return l11l_opy_(url, l1l11l_opy_)
    response = l111_opy_(url)
    l1ll1111_opy_   = url.split(l1ll1ll_opy_ (u"ࠩ࠽ࠫࡄ"), 1)[-1]
    try:
        result = response[l1ll1ll_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪࡅ")]
        l1l1ll_opy_  = result[l1ll1ll_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪࡆ")]
    except Exception as e:
        l111111_opy_(e)
        return None
    for file in l1l1ll_opy_:
        l1lll_opy_  = file[l1ll1ll_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫࡇ")].split(l1ll1ll_opy_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࡈ"), 1)[0]
        l1111l1_opy_  = l1lll_opy_.split(l1ll1ll_opy_ (u"ࠧࠬࠩࡉ"), 1)[0]
        l11111l_opy_ = mapping.cleanLabel(l1111l1_opy_)
        if l1l11ll_opy_ == l11111l_opy_:
            return file[l1ll1ll_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ࡊ")]
        if (l1l11ll_opy_ in l11111l_opy_) or (l11111l_opy_ in l1l11ll_opy_):
            return file[l1ll1ll_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧࡋ")]
    return None
def l11l_opy_(url, addon):
    PATH = l1ll1_opy_(addon)
    try:
        response = json.load(open(PATH))
    except:
        response = l1_opy_(addon)
    l1ll11ll_opy_      = url.split(l1ll1ll_opy_ (u"ࠪ࠾ࠬࡌ"), 1)[-1]
    stream    = l1ll11ll_opy_.split(l1ll1ll_opy_ (u"ࠫࠥࡡࠧࡍ"), 1)[0]
    l1l11ll_opy_ = mapping.cleanLabel(stream)
    l1l1ll_opy_  = response[l1ll1ll_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬࡎ")][l1ll1ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬࡏ")]
    for file in l1l1ll_opy_:
        l1lll_opy_  = file[l1ll1ll_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ࡐ")].split(l1ll1ll_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࡑ"), 1)[0]
        l1111l1_opy_  = l1lll_opy_.split(l1ll1ll_opy_ (u"ࠩ࠮ࠫࡒ"), 1)[0]
        l11111l_opy_ = mapping.cleanLabel(l1111l1_opy_)
        if l1l11ll_opy_ == l11111l_opy_:
            return file[l1ll1ll_opy_ (u"ࠪࡪ࡮ࡲࡥࠨࡓ")]
        if (l1l11ll_opy_ in l11111l_opy_) or (l11111l_opy_ in l1l11ll_opy_):
            return file[l1ll1ll_opy_ (u"ࠫ࡫࡯࡬ࡦࠩࡔ")]
        if l1ll1ll_opy_ (u"࡛ࠬࡓࡂ࠱ࡆࡅ࠿࠭ࡕ") in l11111l_opy_:
            l11lll1_opy_ = l11111l_opy_.replace(l1ll1ll_opy_ (u"࠭ࡕࡔࡃ࠲ࡇࡆࡀࠧࡖ"), l1ll1ll_opy_ (u"ࠧࡖࡕࡄ࠾ࠬࡗ"))
            if dixie.fuzzyMatch(l1l11ll_opy_, l11lll1_opy_):
                return file[l1ll1ll_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ࡘ")]
    return None
def l1_opy_(addon):
    PATH  = l1ll1_opy_(addon)
    if addon == l11ll_opy_:
        query = l1ll1ll_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡚ࡆࡊࡅࡓ࠱࡯࡭ࡻ࡫ࡴࡷ࠱ࡤࡰࡱ࠵࡙ࠧ")
    elif addon == l11ll11_opy_:
        query = l1ll1ll_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡫ࡸࡥࡦࡸ࡬ࡩࡼ࠵࠿ࡶࡴ࡯ࡁࡺࡸ࡬ࠧ࡯ࡲࡨࡪࡃ࠵ࠧࡰࡤࡱࡪࡃࡌࡪࡸࡨ࠯࡙࡜࡚ࠧ")
    else:
        query = l111ll1_opy_(addon)
    try:
        return json.load(open(PATH))
    except:
        content = doJSON(query)
        return l1ll11l_opy_(PATH, addon, content)
def l1ll11l_opy_(PATH, addon, content):
    json.dump(content, open(PATH,l1ll1ll_opy_ (u"ࠫࡼ࡛࠭")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    l1llll11_opy_  = (l1ll1ll_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࠦࡵࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ࡜") % query)
    response = xbmc.executeJSONRPC(l1llll11_opy_)
    content  = json.loads(response)
    return content
def l1ll1_opy_(addon):
    if addon == l11_opy_:
        return os.path.join(dixie.PROFILE, l1ll1ll_opy_ (u"࠭࡭ࡢࡶࡶࡸࡲࡶࠧ࡝"))
    if addon == l11ll11_opy_:
        return os.path.join(dixie.PROFILE, l1ll1ll_opy_ (u"ࠧࡧࡴࡨࡩࡹࡳࡰࠨ࡞"))
    if addon == l1lll11_opy_:
        return os.path.join(dixie.PROFILE, l1ll1ll_opy_ (u"ࠨ࡫ࡳࡸࡸࡺ࡭ࡱࠩ࡟"))
    if addon == l1l1ll1_opy_:
        return os.path.join(dixie.PROFILE, l1ll1ll_opy_ (u"ࠩ࡭࠶ࡹ࡫࡭ࡱࠩࡠ"))
    if addon == l1ll111_opy_:
        return os.path.join(dixie.PROFILE, l1ll1ll_opy_ (u"ࠪࡶࡴࡺࡥ࡮ࡲࠪࡡ"))
    if addon == l1llllll_opy_:
        return os.path.join(dixie.PROFILE, l1ll1ll_opy_ (u"ࠫࡪࡺࡥ࡮ࡲࠪࡢ"))
    if addon == l1ll1ll1_opy_:
        return os.path.join(dixie.PROFILE, l1ll1ll_opy_ (u"ࠬ࡬ࡴࡦ࡯ࡳࠫࡣ"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l1ll1ll_opy_ (u"࠭ࡤࡵࡧࡰࡴࠬࡤ"))
    if addon == l11ll_opy_:
        return os.path.join(dixie.PROFILE, l1ll1ll_opy_ (u"ࠧࡷࡦࡷࡩࡲࡶࠧࡥ"))
    if addon == l11l1l_opy_:
        return os.path.join(dixie.PROFILE, l1ll1ll_opy_ (u"ࠨࡵࡳࡶࡹ࡫࡭ࡱࠩࡦ"))
    if addon == l1lll1l_opy_:
        return os.path.join(dixie.PROFILE, l1ll1ll_opy_ (u"ࠩࡰࡧࡰࡺࡥ࡮ࡲࠪࡧ"))
    if addon == l1lll1ll_opy_:
        return os.path.join(dixie.PROFILE, l1ll1ll_opy_ (u"ࠪࡸࡼ࡯ࡴࡦ࡯ࡳࠫࡨ"))
    if addon == l11l1l1_opy_:
        return os.path.join(dixie.PROFILE, l1ll1ll_opy_ (u"ࠫࡵࡸࡥࡴࡶࡨࡱࡵ࠭ࡩ"))
    if addon == l1l11l_opy_:
        return os.path.join(dixie.PROFILE, l1ll1ll_opy_ (u"ࠬࡨ࡬࡬࡫ࡷࡩࡲࡶࠧࡪ"))
def l111ll1_opy_(addon):
    query = l1ll1ll_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ࡫") + addon
    response = doJSON(query)
    l1l1ll_opy_    = response[l1ll1ll_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧ࡬")][l1ll1ll_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧ࡭")]
    for file in l1l1ll_opy_:
        l11l11l_opy_ = file[l1ll1ll_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨ࡮")]
        l1lllll_opy_ = mapping.cleanLabel(l11l11l_opy_)
        l1lllll_opy_ = l1lllll_opy_.upper()
        if (l1lllll_opy_ == l1ll1ll_opy_ (u"ࠪࡐࡎ࡜ࡅࠡࡖ࡙ࠫ࡯")) or (l1lllll_opy_ == l1ll1ll_opy_ (u"ࠫࡑࡏࡖࡆࠢࡆࡌࡆࡔࡎࡆࡎࡖࠫࡰ")) or (l1lllll_opy_ == l1ll1ll_opy_ (u"ࠬࡒࡉࡗࡇࠪࡱ")) or (l1lllll_opy_ == l1ll1ll_opy_ (u"࠭ࡅࡏࡆࡏࡉࡘ࡙ࠠࡎࡇࡇࡍࡆ࠭ࡲ")) or (l1lllll_opy_ == l1ll1ll_opy_ (u"ࠧࡇࡎࡄ࡛ࡑࡋࡓࡔࡖ࡙ࠫࡳ")) or (l1lllll_opy_ == l1ll1ll_opy_ (u"ࠨࡄࡏࡅࡈࡑࡉࡄࡇࠣࡘ࡛࠭ࡴ")):
            livetv = file[l1ll1ll_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧࡵ")]
            return l11lll_opy_(livetv)
def l11lll_opy_(livetv):
    response = doJSON(livetv)
    l1l1ll_opy_    = response[l1ll1ll_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪࡶ")][l1ll1ll_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪࡷ")]
    for file in l1l1ll_opy_:
        l11l11l_opy_ = file[l1ll1ll_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫࡸ")]
        l1lllll_opy_ = mapping.cleanLabel(l11l11l_opy_)
        l1lllll_opy_ = l1lllll_opy_.upper()
        if l1lllll_opy_ == l1ll1ll_opy_ (u"࠭ࡁࡍࡎࠪࡹ"):
            return file[l1ll1ll_opy_ (u"ࠧࡧ࡫࡯ࡩࠬࡺ")]
def l1l1l11_opy_(l11llll_opy_):
    items = []
    _111l11_opy_(l11llll_opy_, items)
    return items
def _111l11_opy_(l11llll_opy_, items):
    response = doJSON(l11llll_opy_)
    if response[l1ll1ll_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨࡻ")].has_key(l1ll1ll_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨࡼ")):
        result = response[l1ll1ll_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪࡽ")][l1ll1ll_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪࡾ")]
        for item in result:
            if item[l1ll1ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧࡿ")] == l1ll1ll_opy_ (u"࠭ࡦࡪ࡮ࡨࠫࢀ"):
                l1lllll_opy_ = mapping.cleanLabel(item[l1ll1ll_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ࢁ")])
                items.append(item)
            elif item[l1ll1ll_opy_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪࢂ")] == l1ll1ll_opy_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠬࢃ"):
                l1lllll_opy_ = mapping.cleanLabel(item[l1ll1ll_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࢄ")])
                l1llll1l_opy_  = item[l1ll1ll_opy_ (u"ࠫ࡫࡯࡬ࡦࠩࢅ")]
                dixie.log(item)
                dixie.log(l1llll1l_opy_)
                _111l11_opy_(l1llll1l_opy_, items)
def l111_opy_(url):
    if url.startswith(l1ll1ll_opy_ (u"ࠬࡏࡐࡍࡃ࡜࠾ࠬࢆ")):
        l1llll11_opy_ = (l1ll1ll_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡥࡦࡨ࡯ࡰ࡭ࡣࡼࡩࡷ࠵࠿ࡶࡴ࡯ࡁࡺࡸ࡬ࠧ࡯ࡲࡨࡪࡃ࠲ࠧࡰࡤࡱࡪࡃࡌࡪࡸࡨࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࡃࠦࡊࡒࡌࡈࡂࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࢇ"))
    if url.startswith(l1ll1ll_opy_ (u"ࠧࡊࡒࡏࡅ࡞࠸࠺ࠨ࢈")):
        l1llll11_opy_ = (l1ll1ll_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶ࡬ࡢࡻࡨࡶࡼࡽࡷ࠰ࡁࡸࡶࡱࡃࡵࡳ࡮ࠩࡱࡴࡪࡥ࠾࠳࠳࠵ࠫࡴࡡ࡮ࡧࡀ࡛ࡦࡺࡣࡩ࠭ࡏ࡭ࡻ࡫ࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠩࡷࡺࡨࡴࡪࡶ࡯ࡩࡸࡥࡵࡳ࡮ࡀࠪࡱࡵࡧࡨࡧࡧࡣ࡮ࡴ࠽ࡇࡣ࡯ࡷࡪࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࢉ"))
    if url.startswith(l1ll1ll_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡓ࠼ࠪࢊ")):
        l1llll11_opy_ = (l1ll1ll_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱ࡮ࡤࡽࡪࡸࡷࡸࡹ࠲ࡃࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࡊࡥࡧࡣࡸࡰࡹࡌ࡯࡭ࡦࡨࡶ࠳ࡶ࡮ࡨࠨ࡯ࡳ࡬࡭ࡥࡥࡡ࡬ࡲࡂࡌࡡ࡭ࡵࡨࠪࡲࡵࡤࡦ࠿࠴࠵࠸ࠬ࡮ࡢ࡯ࡨࡁࡑ࡯ࡳࡵࡧࡱࠩ࠷࠶ࡌࡪࡸࡨࠪࡸࡻࡢࡵ࡫ࡷࡰࡪࡹ࡟ࡶࡴ࡯ࠪࡺࡸ࡬࠾ࡷࡵࡰࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࢋ"))
    if url.startswith(l1ll1ll_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡌࡘ࡛ࡀࠧࢌ")):
        l1llll11_opy_ = (l1ll1ll_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡷࡺࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࢍ"))
    if url.startswith(l1ll1ll_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡉࡀࠧࢎ")):
        l1llll11_opy_ = (l1ll1ll_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡨࡪࡾ࠯ࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡣ࡯ࡰࠫ࡫ࡸࡵࡴࡤࠪࡵࡧࡧࡦࠨࡳࡰࡴࡺࠦࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡀࠪࡹ࡯ࡴ࡭ࡧࡀࠩ࠺ࡨࡃࡐࡎࡒࡖࠪ࠸࠰ࡸࡪ࡬ࡸࡪࠫ࠵ࡥࡃ࡯ࡰࠪ࠸࠰ࡄࡪࡤࡲࡳ࡫࡬ࡴࠧ࠸ࡦࠪ࠸ࡦࡄࡑࡏࡓࡗࠫ࠵ࡥࠨࡸࡶࡱࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫ࢏"))
    if url.startswith(l1ll1ll_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡒࡃ࠼ࠪ࢐")):
        l1llll11_opy_ = (l1ll1ll_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡥࡣࡱࡲࡸ࠴ࡅࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠪ࡫ࡧ࡮ࡢࡴࡷࡁࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡰࡳࡩ࡫࠽࠸ࠨࡳ࡭ࡱࡲ࡯ࡸ࠿ࡏ࡭ࡻ࡫ࠥ࠳࠲ࡖࡸࡷ࡫ࡡ࡮ࡵࠩࡹࡷࡲ࠽ࡳࡣࡱࡨࡴࡳࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬ࢑"))
    try:
        dixie.ShowBusy()
        addon =  l1llll11_opy_.split(l1ll1ll_opy_ (u"ࠪ࠳࠴࠭࢒"), 1)[-1].split(l1ll1ll_opy_ (u"ࠫ࠴࠭࢓"), 1)[0]
        login = l1ll1ll_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ࢔") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1llll11_opy_)
        dixie.log(response)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l111111_opy_(e)
        return {l1ll1ll_opy_ (u"࠭ࡅࡳࡴࡲࡶࠬ࢕") : l1ll1ll_opy_ (u"ࠧࡑ࡮ࡸ࡫࡮ࡴࠠࡆࡴࡵࡳࡷ࠭࢖")}
def l1lll1_opy_():
    modules = map(__import__, [l1l1llll_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11l1_opy_)):
        return l1ll1ll_opy_ (u"ࠨࡖࡵࡹࡪ࠭ࢗ")
    if len(modules[-1].Window(10**4).getProperty(l111l_opy_)):
        return l1ll1ll_opy_ (u"ࠩࡗࡶࡺ࡫ࠧ࢘")
    return l1ll1ll_opy_ (u"ࠪࡊࡦࡲࡳࡦ࢙ࠩ")
def l111111_opy_(e):
    l11111_opy_ = l1ll1ll_opy_ (u"ࠫࡘࡵࡲࡳࡻ࠯ࠤࡦࡴࠠࡦࡴࡵࡳࡷࠦ࡯ࡤࡥࡸࡶࡪࡪ࠺ࠡࡌࡖࡓࡓࠦࡅࡳࡴࡲࡶ࠿ࠦࠥࡴ࢚ࠩ")  %e
    l1llll_opy_ = l1ll1ll_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡸࡥ࠮࡮࡬ࡲࡰࠦࡴࡩ࡫ࡶࠤࡨ࡮ࡡ࡯ࡰࡨࡰࠥࡧ࡮ࡥࠢࡷࡶࡾࠦࡡࡨࡣ࡬ࡲ࠳࢛࠭")
    l1l1_opy_ = l1ll1ll_opy_ (u"࠭ࡕࡴࡧ࠽ࠤࡈࡵ࡮ࡵࡧࡻࡸࠥࡓࡥ࡯ࡷࠣࡁࡃࠦࡒࡦ࡯ࡲࡺࡪࠦࡓࡵࡴࡨࡥࡲ࠭࢜")
    dixie.log(e)
    dixie.DialogOK(l11111_opy_, l1llll_opy_, l1l1_opy_)
if __name__ == l1ll1ll_opy_ (u"ࠧࡠࡡࡰࡥ࡮ࡴ࡟ࡠࠩ࢝"):
    checkAddons()