# -*- coding: utf-8 -*-
import sys
l1l11l1_opy_ = sys.version_info [0] == 2
l1l111l_opy_ = 2048
l1l1l1_opy_ = 7
def l1ll1ll_opy_ (ll_opy_):
	global l1ll1l_opy_
	l1lll11l_opy_ = ord (ll_opy_ [-1])
	l1l1l1l_opy_ = ll_opy_ [:-1]
	l111l11_opy_ = l1lll11l_opy_ % len (l1l1l1l_opy_)
	l1llllll_opy_ = l1l1l1l_opy_ [:l111l11_opy_] + l1l1l1l_opy_ [l111l11_opy_:]
	if l1l11l1_opy_:
		l11ll11_opy_ = unicode () .join ([unichr (ord (char) - l1l111l_opy_ - (l1llll1_opy_ + l1lll11l_opy_) % l1l1l1_opy_) for l1llll1_opy_, char in enumerate (l1llllll_opy_)])
	else:
		l11ll11_opy_ = str () .join ([chr (ord (char) - l1l111l_opy_ - (l1llll1_opy_ + l1lll11l_opy_) % l1l1l1_opy_) for l1llll1_opy_, char in enumerate (l1llllll_opy_)])
	return eval (l11ll11_opy_)
import os
import json
import requests
import dixie
l1111l_opy_ = dixie.PROFILE
PATH = os.path.join(l1111l_opy_, l1ll1ll_opy_ (u"ࠧࡱ࡮࡬ࡷࡹࡹࠧ॓"))
def loadPlaylists():
    dixie.log(l1ll1ll_opy_ (u"ࠨ࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠡࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠤࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࠪ॔"))
    if os.path.exists(PATH):
        return json.load(open(PATH))
    try:
        l111llll1_opy_()
        return json.load(open(PATH))
    except:
        dixie.log(l1ll1ll_opy_ (u"ࠩࡀࡁࡂࡃࠠࡑ࡮ࡤࡽࡱ࡯ࡳࡵࠢ࡯ࡳࡦࡪࠠࡦࡴࡵࡳࡷࠦ࠽࠾࠿ࡀࠫॕ"))
        return []
def l111llll1_opy_():
    source = dixie.GetSetting(l1ll1ll_opy_ (u"ࠪ࡭ࡵࡺࡶ࠯ࡵࡲࡹࡷࡩࡥࠨॖ"))
    if not source == l1ll1ll_opy_ (u"ࠫ࠶࠭ॗ"):
        return l11l11ll1_opy_()
    return l111l1lll_opy_()
def l11l11ll1_opy_():
    l11ll11l1_opy_ = []
    if dixie.GetSetting(l1ll1ll_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠴ࠬक़")) == l1ll1ll_opy_ (u"࠭ࡴࡳࡷࡨࠫख़"):
        l1l1111ll_opy_  = dixie.GetSetting(l1ll1ll_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠶࡟ࡖࡔࡏࠫग़"))
        l11ll1lll_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠰ࡠࡒࡒࡖ࡙࠭ज़"))
        l11l11l11_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠱ࡡࡗ࡝ࡕࡋࠧड़"))
        l11lll1l1_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠲ࡢ࡙ࡘࡋࡒࠨढ़"))
        l1l111l11_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠳ࡣࡕࡇࡓࡔࠩफ़"))
        if len(l1l1111ll_opy_) > 0:
            l111ll111_opy_ = l11lll111_opy_(l1l1111ll_opy_, l11ll1lll_opy_, l11l11l11_opy_, l11lll1l1_opy_, l1l111l11_opy_)
            l11ll11l1_opy_.append((l111ll111_opy_, l1ll1ll_opy_ (u"ࠬࡏࡐࡕࡘ࠴࠾ࠥ࠭य़")))
    if dixie.GetSetting(l1ll1ll_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠶࠭ॠ")) == l1ll1ll_opy_ (u"ࠧࡵࡴࡸࡩࠬॡ"):
        l1l1111ll_opy_  = dixie.GetSetting(l1ll1ll_opy_ (u"ࠨࡋࡓࡘ࡛ࡥ࠱ࡠࡗࡕࡐࠬॢ"))
        l11ll1lll_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠲ࡡࡓࡓࡗ࡚ࠧॣ"))
        l11l11l11_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠳ࡢࡘ࡞ࡖࡅࠨ।"))
        l11lll1l1_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠴ࡣ࡚࡙ࡅࡓࠩ॥"))
        l1l111l11_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠵ࡤࡖࡁࡔࡕࠪ०"))
        if len(l1l1111ll_opy_) > 0:
            l11l1l1ll_opy_ = l11lll111_opy_(l1l1111ll_opy_, l11ll1lll_opy_, l11l11l11_opy_, l11lll1l1_opy_, l1l111l11_opy_)
            l11ll11l1_opy_.append((l11l1l1ll_opy_, l1ll1ll_opy_ (u"࠭ࡉࡑࡖ࡙࠶࠿ࠦࠧ१")))
    if dixie.GetSetting(l1ll1ll_opy_ (u"ࠧࡊࡒࡗ࡚ࡤ࠸ࠧ२")) == l1ll1ll_opy_ (u"ࠨࡶࡵࡹࡪ࠭३"):
        l1l1111ll_opy_  = dixie.GetSetting(l1ll1ll_opy_ (u"ࠩࡌࡔ࡙࡜࡟࠳ࡡࡘࡖࡑ࠭४"))
        l11ll1lll_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠪࡍࡕ࡚ࡖࡠ࠴ࡢࡔࡔࡘࡔࠨ५"))
        l11l11l11_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠫࡎࡖࡔࡗࡡ࠵ࡣ࡙࡟ࡐࡆࠩ६"))
        l11lll1l1_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠬࡏࡐࡕࡘࡢ࠶ࡤ࡛ࡓࡆࡔࠪ७"))
        l1l111l11_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"࠭ࡉࡑࡖ࡙ࡣ࠷ࡥࡐࡂࡕࡖࠫ८"))
        if len(l1l1111ll_opy_) > 0:
            l11l1l1l1_opy_ = l11lll111_opy_(l1l1111ll_opy_, l11ll1lll_opy_, l11l11l11_opy_, l11lll1l1_opy_, l1l111l11_opy_)
            l11ll11l1_opy_.append((l11l1l1l1_opy_, l1ll1ll_opy_ (u"ࠧࡊࡒࡗ࡚࠸ࡀࠠࠨ९")))
    return l111lll1l_opy_(l1ll1ll_opy_ (u"ࠨࡗࡕࡐࡘ࠭॰"),  l11ll11l1_opy_)
def l111l1lll_opy_():
    l11ll11l1_opy_ = []
    if dixie.GetSetting(l1ll1ll_opy_ (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡹࡿࡰࡦࠩॱ")) == l1ll1ll_opy_ (u"ࠪ࠴ࠬॲ"):
        if dixie.GetSetting(l1ll1ll_opy_ (u"࡚ࠫࡘࡌࡠࡑࠪॳ")) == l1ll1ll_opy_ (u"ࠬࡺࡲࡶࡧࠪॴ"):
            l111l1ll1_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡷࡵࡰࠬॵ"))
            if len(l111l1ll1_opy_) > 0:
                l11ll11l1_opy_.append((l111l1ll1_opy_, l1ll1ll_opy_ (u"ࠧࡖࡔࡏ࠵࠿ࠦࠧॶ")))
        if dixie.GetSetting(l1ll1ll_opy_ (u"ࠨࡗࡕࡐࡤ࠷ࠧॷ")) == l1ll1ll_opy_ (u"ࠩࡷࡶࡺ࡫ࠧॸ"):
            l11l1ll11_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡻࡲ࡭࠳ࠪॹ"))
            if len(l11l1ll11_opy_) > 0:
                l11ll11l1_opy_.append((l11l1ll11_opy_, l1ll1ll_opy_ (u"࡚ࠫࡘࡌ࠳࠼ࠣࠫॺ")))
        if dixie.GetSetting(l1ll1ll_opy_ (u"࡛ࠬࡒࡍࡡ࠵ࠫॻ")) == l1ll1ll_opy_ (u"࠭ࡴࡳࡷࡨࠫॼ"):
            l11l1l11l_opy_ = dixie.GetSetting(l1ll1ll_opy_ (u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡸࡶࡱ࠸ࠧॽ"))
            if len(l11l1l11l_opy_) > 0:
                l11ll11l1_opy_.append((l11l1l11l_opy_, l1ll1ll_opy_ (u"ࠨࡗࡕࡐ࠸ࡀࠠࠨॾ")))
        dixie.log(l11ll11l1_opy_)
        return l111lll1l_opy_(l1ll1ll_opy_ (u"ࠩࡘࡖࡑ࡙ࠧॿ"),  l11ll11l1_opy_)
    if dixie.GetSetting(l1ll1ll_opy_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡺࡹࡱࡧࠪঀ")) == l1ll1ll_opy_ (u"ࠫ࠶࠭ঁ"):
        if dixie.GetSetting(l1ll1ll_opy_ (u"ࠬࡌࡉࡍࡇࡢ࠴ࠬং")) == l1ll1ll_opy_ (u"࠭ࡴࡳࡷࡨࠫঃ"):
            l11l1llll_opy_ = os.path.join(dixie.GetSetting(l1ll1ll_opy_ (u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡩ࡭ࡱ࡫ࠧ঄")))
            if l11l1llll_opy_:
                l11ll11l1_opy_.append((l11l1llll_opy_, l1ll1ll_opy_ (u"ࠨࡈࡌࡐࡊ࠷࠺ࠡࠩঅ")))
        if dixie.GetSetting(l1ll1ll_opy_ (u"ࠩࡉࡍࡑࡋ࡟࠱ࠩআ")) == l1ll1ll_opy_ (u"ࠪࡸࡷࡻࡥࠨই"):
            l11ll1111_opy_ = os.path.join(dixie.GetSetting(l1ll1ll_opy_ (u"ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡦࡪ࡮ࡨ࠵ࠬঈ")))
            if l11ll1111_opy_:
                l11ll11l1_opy_.append((l11ll1111_opy_, l1ll1ll_opy_ (u"ࠬࡌࡉࡍࡇ࠵࠾ࠥ࠭উ")))
        if dixie.GetSetting(l1ll1ll_opy_ (u"࠭ࡆࡊࡎࡈࡣ࠵࠭ঊ")) == l1ll1ll_opy_ (u"ࠧࡵࡴࡸࡩࠬঋ"):
            l11ll111l_opy_ = os.path.join(dixie.GetSetting(l1ll1ll_opy_ (u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡪ࡮ࡲࡥ࠳ࠩঌ")))
            if l11ll111l_opy_:
                l11ll11l1_opy_.append((l11ll111l_opy_, l1ll1ll_opy_ (u"ࠩࡉࡍࡑࡋ࠳࠻ࠢࠪ঍")))
        dixie.log(l11ll11l1_opy_)
        return l111lll1l_opy_(l1ll1ll_opy_ (u"ࠪࡊࡎࡒࡅࡔࠩ঎"), l11ll11l1_opy_)
def l111ll1l1_opy_():
    l111ll1ll_opy_ = [l1ll1ll_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱ࡋࡉ࡟࠻࡚ࡺ࡫ࡍࡩ࡜࠭এ")]
    for url in l111ll1ll_opy_:
        request = requests.get(url)
        content = request.content
        if l1ll1ll_opy_ (u"ࠬࠩࡅ࡙ࡖࡐ࠷࡚࠭ঐ") in content:
            return l111lll1l_opy_(l1ll1ll_opy_ (u"࠭ࡃࡍࡑࡘࡈࠬ঑"), [(url, l1ll1ll_opy_ (u"ࠧࠨ঒"))])
            break
def l111lll1l_opy_(l111lll11_opy_, plist):
    dixie.log(l111lll11_opy_)
    dixie.log(plist)
    playlists = []
    for item in plist:
        url = item[0]
        l11l1ll1l_opy_ = item[1]
        l11l11lll_opy_ = l11l1lll1_opy_(l111lll11_opy_, url, l11l1ll1l_opy_)
        playlists.extend(l11l11lll_opy_)
    json.dump(playlists, open(PATH,l1ll1ll_opy_ (u"ࠨࡹࠪও")))
def l11l1lll1_opy_(l111lll11_opy_, url, l11l1ll1l_opy_):
    content  = l111ll11l_opy_(l111lll11_opy_, url)
    pairs    = []
    for i in range(1,len(content), 2):
        if l11l1l111_opy_(content[i]) == True:
            l1lllll_opy_ = content[i]
            l11llll_opy_   = content[i+1]
            pairs.append([l1lllll_opy_, l11llll_opy_])
    l111lllll_opy_ = list()
    l1lllll_opy_   = l1ll1ll_opy_ (u"ࠩࠪঔ")
    value   = l1ll1ll_opy_ (u"ࠪࠫক")
    for item in pairs:
        l11l111ll_opy_ = item[0]
        l11l11l1l_opy_ = item[1]
        l11l111l1_opy_   = l11l111ll_opy_.split(l1ll1ll_opy_ (u"ࠫ࠱࠭খ"))[-1].strip()
        l1ll1ll1_opy_ = dixie.cleanLabel(l11l111l1_opy_)
        l1ll1ll1_opy_ = dixie.cleanPrefix(l1lllll_opy_)
        l1l1l_opy_ = dixie.mapChannelName(l1ll1ll1_opy_)
        value = l11l11l1l_opy_.replace(l1ll1ll_opy_ (u"ࠬࡸࡴ࡮ࡲ࠽࠳࠴ࠪࡏࡑࡖ࠽ࡶࡹࡳࡰ࠮ࡴࡤࡻࡂ࠭গ"), l1ll1ll_opy_ (u"࠭ࠧঘ")).replace(l1ll1ll_opy_ (u"ࠧ࡝ࡰࠪঙ"), l1ll1ll_opy_ (u"ࠨࠩচ"))
        l111lllll_opy_.append((l11l1ll1l_opy_, l1l1l_opy_, value))
    return l111lllll_opy_
def l11l1l111_opy_(l1lllll_opy_):
    if l1lllll_opy_ == l1ll1ll_opy_ (u"ࠩࠦࡉ࡝࡚࡙࠭࠯ࡈࡒࡉࡒࡉࡔࡖࠪছ"):
        return False
    l1lllll_opy_ = l1lllll_opy_.lower()
    filters = dixie.getFilters()
    for item in filters:
        item = item.lower()
        if item in l1lllll_opy_:
            return False
    return True
def l111ll11l_opy_(l111lll11_opy_, url):
    import urllib
    if (l111lll11_opy_ == l1ll1ll_opy_ (u"࡙ࠪࡗࡒࡓࠨজ")) or (l111lll11_opy_ == l1ll1ll_opy_ (u"ࠫࡈࡒࡏࡖࡆࠪঝ")):
        response = urllib.urlopen(url)
        content  = response.readlines()
        return content
    if l111lll11_opy_ == l1ll1ll_opy_ (u"ࠬࡌࡉࡍࡇࡖࠫঞ"):
        with open(url) as content:
            return content.readlines()
def l11lll111_opy_(l1l1111ll_opy_, l11ll1lll_opy_, l11l11l11_opy_, l11lll1l1_opy_, l1l111l11_opy_):
    if l1l1111ll_opy_.startswith(l1ll1ll_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧট")):
        url = l1l1111ll_opy_
    else:
        url = l1ll1ll_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨঠ") + l1l1111ll_opy_
    url +=  l11l1111l_opy_(l11ll1lll_opy_)
    url += l1ll1ll_opy_ (u"ࠨ࠱ࡪࡩࡹ࠴ࡰࡩࡲࡂࡹࡸ࡫ࡲ࡯ࡣࡰࡩࡂ࠭ড")
    url +=  l11lll1l1_opy_
    url += l1ll1ll_opy_ (u"ࠩࠩࡴࡦࡹࡳࡸࡱࡵࡨࡂ࠭ঢ")
    url +=  l1l111l11_opy_
    url += l1ll1ll_opy_ (u"ࠪࠪࡹࡿࡰࡦ࠿ࡰ࠷ࡺࡥࡰ࡭ࡷࡶࠪࡴࡻࡴࡱࡷࡷࡁࠬণ")
    url +=  l11l11111_opy_(l11l11l11_opy_)
    return url
def l11l1111l_opy_(l11ll1lll_opy_):
    if not l11ll1lll_opy_ == l1ll1ll_opy_ (u"ࠫࠬত"):
        return l1ll1ll_opy_ (u"ࠬࡀࠧথ") + l11ll1lll_opy_
    return l1ll1ll_opy_ (u"࠭ࠧদ")
def l11l11111_opy_(l11l11l11_opy_):
    if l11l11l11_opy_ == l1ll1ll_opy_ (u"ࠧ࠱ࠩধ"):
        return l1ll1ll_opy_ (u"ࠨ࡯࠶ࡹ࠽࠭ন")
    if l11l11l11_opy_ == l1ll1ll_opy_ (u"ࠩ࠴ࠫ঩"):
        return l1ll1ll_opy_ (u"ࠪࡱࡵ࡫ࡧࡵࡵࠪপ")
if __name__ == l1ll1ll_opy_ (u"ࠫࡤࡥ࡭ࡢ࡫ࡱࡣࡤ࠭ফ"):
    l111llll1_opy_()