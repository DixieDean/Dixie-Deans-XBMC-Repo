# coding: UTF-8
import sys
l1111l_opy_ = sys.version_info [0] == 2
l1l111_opy_ = 2048
l1l11_opy_ = 7
def l1ll1l_opy_ (ll_opy_):
	global l1l11l_opy_
	l1llll1_opy_ = ord (ll_opy_ [-1])
	l1l1ll_opy_ = ll_opy_ [:-1]
	l11l11_opy_ = l1llll1_opy_ % len (l1l1ll_opy_)
	l1ll1_opy_ = l1l1ll_opy_ [:l11l11_opy_] + l1l1ll_opy_ [l11l11_opy_:]
	if l1111l_opy_:
		l11ll1_opy_ = unicode () .join ([unichr (ord (char) - l1l111_opy_ - (l1lll1_opy_ + l1llll1_opy_) % l1l11_opy_) for l1lll1_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l11ll1_opy_ = str () .join ([chr (ord (char) - l1l111_opy_ - (l1lll1_opy_ + l1llll1_opy_) % l1l11_opy_) for l1lll1_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l11ll1_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l1l1lll1l_opy_    = l1ll1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡲࡹࡼ࢚ࠧ")
l1ll1l11l_opy_    = l1ll1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡶࡴ࡮࢛ࠫ")
locked = l1ll1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲ࡯ࡤ࡭ࡨࡨࡹࡼࠧ࢜")
l1ll111ll_opy_   = l1ll1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡵࡴࡨࡥࡲࡺࡶࡣࡱࡻࠫ࢝")
l1ll1l1ll_opy_     = l1ll1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡲࡲࡶࡹࡹ࡭ࡢࡰ࡬ࡥࠬ࢞")
l1ll1lll1_opy_     = l1ll1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡳࡳࡷࡺࡳ࡯ࡣࡷ࡭ࡴࡴࡨࡥࡶࡹࠫ࢟")
l1l1l1l1l_opy_     = l1ll1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸࡰࡹ࡯࡭ࡢࡶࡨࡱࡦࡴࡩࡢࠩࢠ")
l1l11lll1_opy_   = l1ll1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰ࡮ࡻࡸ࠯ࡶࡹࠫࢡ")
l1l1ll1l1_opy_    = l1ll1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡉࡉࡓࡱࡱࡵࡸࡸ࠭ࢢ")
l1ll1l111_opy_ = l1ll1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡥࡣࡱࡲࡸࠬࢣ")
l1l1ll1ll_opy_    = l1ll1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡣ࡭ࡷ࡬ࡴࡹࡼࠧࢤ")
l1l1llll1_opy_ = l1ll1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡶࡵࡩࡦࡳࡳࡦࡣࡶࡽ࠳ࡺࡶࠨࢥ")
l1ll11l1l_opy_ = l1ll1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࡯ࡰࡵࡸࠪࢦ")
l1l1l1111_opy_ = [l1l1lll1l_opy_, locked, l1l11lll1_opy_, l1l1llll1_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1ll1l_opy_ (u"ࠪ࡭ࡳ࡯ࠧࢧ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l11111_opy_ = l1ll1l_opy_ (u"ࠫࠬࢨ")
def l1lll11_opy_(i, t1, l1lllll_opy_=[]):
 t = l11111_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1lllll_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11l_opy_ = l1lll11_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11_opy_ = l1lll11_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1l1l1111_opy_:
        if l1l1l11l1_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1l1l11l1_opy_(addon):
    if xbmc.getCondVisibility(l1ll1l_opy_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠦࡵࠬࠫࢩ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l111_opy_ = str(addon).split(l1ll1l_opy_ (u"࠭࠮ࠨࢪ"))[2] + l1ll1l_opy_ (u"ࠧ࠯࡫ࡱ࡭ࠬࢫ")
    l1l_opy_  = os.path.join(PATH, l111_opy_)
    try:
        l111l1_opy_ = l1lll1111_opy_(addon)
    except KeyError:
        dixie.log(l1ll1l_opy_ (u"ࠨ࠯࠰࠱࠲࠳ࠠࡌࡧࡼࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥ࡭ࡥࡵࡈ࡬ࡰࡪࡹࠠ࠮࠯࠰࠱࠲ࠦࠧࢬ") + addon)
        result = {l1ll1l_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࡴࠩࢭ"): [{l1ll1l_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭ࢮ"): l1ll1l_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࠪࢯ"), l1ll1l_opy_ (u"ࡺ࠭ࡴࡺࡲࡨࠫࢰ"): l1ll1l_opy_ (u"ࡻࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨࢱ"), l1ll1l_opy_ (u"ࡵࠨࡨ࡬ࡰࡪ࠭ࢲ"): l1ll1l_opy_ (u"ࡶࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡽࡾࠧࢳ"), l1ll1l_opy_ (u"ࡷࠪࡰࡦࡨࡥ࡭ࠩࢴ"): l1ll1l_opy_ (u"ࡸࠫࡓࡕࠠࡄࡊࡄࡒࡓࡋࡌࡔࠩࢵ")}], l1ll1l_opy_ (u"ࡹࠬࡲࡩ࡮࡫ࡷࡷࠬࢶ"):{l1ll1l_opy_ (u"ࡺ࠭ࡳࡵࡣࡵࡸࠬࢷ"): 0, l1ll1l_opy_ (u"ࡻࠧࡵࡱࡷࡥࡱ࠭ࢸ"): 1, l1ll1l_opy_ (u"ࡵࠨࡧࡱࡨࠬࢹ"): 1}}
    l1l1_opy_  = file(l1l_opy_, l1ll1l_opy_ (u"ࠨࡹࠪࢺ"))
    l1l1_opy_.write(l1ll1l_opy_ (u"ࠩ࡞ࠫࢻ"))
    l1l1_opy_.write(addon)
    l1l1_opy_.write(l1ll1l_opy_ (u"ࠪࡡࠬࢼ"))
    l1l1_opy_.write(l1ll1l_opy_ (u"ࠫࡡࡴࠧࢽ"))
    l11ll_opy_ = []
    for channel in l111l1_opy_:
        l1l1l_opy_    = channel[l1ll1l_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫࢾ")]
        l1l1l_opy_    = l1l1l_opy_.replace(l1ll1l_opy_ (u"࠭ࡼࠨࢿ"), l1ll1l_opy_ (u"ࠧࠨࣀ")).replace(l1ll1l_opy_ (u"ࠨ࠱ࠪࣁ"), l1ll1l_opy_ (u"ࠩࠪࣂ")).replace(l1ll1l_opy_ (u"ࠪࠤࠥࠦࠠࠡࠩࣃ"), l1ll1l_opy_ (u"ࠫࠥ࠭ࣄ")).replace(l1ll1l_opy_ (u"ࠬ࠴࠮࠯࠰࠱ࠫࣅ"), l1ll1l_opy_ (u"࠭ࠧࣆ")).replace(l1ll1l_opy_ (u"ࠧ࠻ࠩࣇ"), l1ll1l_opy_ (u"ࠨࠩࣈ")).replace(l1ll1l_opy_ (u"ࠩࠣ࡟ࠬࣉ"), l1ll1l_opy_ (u"ࠪ࡟ࠬ࣊"))
        l1l1l_opy_    = l1l1l_opy_.replace(l1ll1l_opy_ (u"ࠫࡢࠦࠧ࣋"), l1ll1l_opy_ (u"ࠬࡣࠧ࣌")).replace(l1ll1l_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡡࡲࡷࡤࡡࠬ࣍"), l1ll1l_opy_ (u"ࠧࠨ࣎")).replace(l1ll1l_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡹ࡫࡭ࡹ࡫࡝ࠨ࣏"), l1ll1l_opy_ (u"࣐ࠩࠪ")).replace(l1ll1l_opy_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡ࣑ࠬ"), l1ll1l_opy_ (u"࣒ࠫࠬ"))
        l1l1l_opy_    = l1l1l_opy_.replace(l1ll1l_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡲࡩ࡮ࡧࡪࡶࡪ࡫࡮࡞࣓ࠩ"), l1ll1l_opy_ (u"࠭ࠧࣔ")).replace(l1ll1l_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡨࡴࡨࡩࡳࡣࠧࣕ"), l1ll1l_opy_ (u"ࠨࠩࣖ")).replace(l1ll1l_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡼࡩࡱࡲ࡯ࡸ࡟ࠪࣗ"), l1ll1l_opy_ (u"ࠪࠫࣘ"))
        l1l1l_opy_    = l1l1l_opy_.replace(l1ll1l_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟ࠪࣙ"), l1ll1l_opy_ (u"ࠬ࠭ࣚ")).replace(l1ll1l_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡯ࡳࡣࡱ࡫ࡪࡣࠧࣛ"), l1ll1l_opy_ (u"ࠧࠨࣜ")).replace(l1ll1l_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡴࡨࡨࡢ࠭ࣝ"), l1ll1l_opy_ (u"ࠩࠪࣞ"))
        l1l1l_opy_    = l1l1l_opy_.replace(l1ll1l_opy_ (u"ࠪ࡟ࡎࡣࠧࣟ"), l1ll1l_opy_ (u"ࠫࠬ࣠")).replace(l1ll1l_opy_ (u"ࠬࡡ࠯ࡊ࡟ࠪ࣡"), l1ll1l_opy_ (u"࠭ࠧ࣢")).replace(l1ll1l_opy_ (u"ࠧ࡜ࡄࡠࣣࠫ"), l1ll1l_opy_ (u"ࠨࠩࣤ")).replace(l1ll1l_opy_ (u"ࠩ࡞࠳ࡇࡣࠧࣥ"), l1ll1l_opy_ (u"ࣦࠪࠫ"))
        l1ll_opy_ = dixie.mapChannelName(l1l1l_opy_)
        stream   = channel[l1ll1l_opy_ (u"ࠫ࡫࡯࡬ࡦࠩࣧ")]
        l1lll_opy_ = l1ll_opy_ + l1ll1l_opy_ (u"ࠬࡃࠧࣨ") + stream
        l11ll_opy_.append(l1lll_opy_)
        l11ll_opy_.sort()
    for item in l11ll_opy_:
        l1l1_opy_.write(l1ll1l_opy_ (u"ࠨࠥࡴ࡞ࡱࣩࠦ") % item)
    l1l1_opy_.close()
def l1lll1111_opy_(addon):
    if (addon == l1l11lll1_opy_) or (addon == locked):
        return l1ll111l1_opy_(addon)
    l1l1ll111_opy_  = l1ll1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ࣪") + addon
    l1ll11ll1_opy_ =  l1ll1llll_opy_(addon)
    query   =  l1l1ll111_opy_ + l1ll11ll1_opy_
    return sendJSON(query, addon)
def l1ll111l1_opy_(addon):
    if addon == l1l11lll1_opy_:
        l1ll11l11_opy_ = [l1ll1l_opy_ (u"ࠨ࠷ࠪ࣫"), l1ll1l_opy_ (u"ࠩ࠴࠴࠻࠭࣬"), l1ll1l_opy_ (u"ࠪ࠸࣭ࠬ"), l1ll1l_opy_ (u"ࠫ࠷࠼࠳ࠨ࣮"), l1ll1l_opy_ (u"ࠬ࠷࠳࠳࣯ࠩ")]
    if addon == locked:
        l1ll11l11_opy_ = [l1ll1l_opy_ (u"࠭࠳࠱ࣰࠩ"), l1ll1l_opy_ (u"ࠧ࠴࠳ࣱࠪ"), l1ll1l_opy_ (u"ࠨ࠵࠵ࣲࠫ"), l1ll1l_opy_ (u"ࠩ࠶࠷ࠬࣳ"), l1ll1l_opy_ (u"ࠪ࠷࠹࠭ࣴ"), l1ll1l_opy_ (u"ࠫ࠸࠻ࠧࣵ"), l1ll1l_opy_ (u"ࠬ࠹࠸ࠨࣶ"), l1ll1l_opy_ (u"࠭࠴࠱ࠩࣷ"), l1ll1l_opy_ (u"ࠧ࠵࠳ࠪࣸ"), l1ll1l_opy_ (u"ࠨ࠶࠸ࣹࠫ"), l1ll1l_opy_ (u"ࠩ࠷࠻ࣺࠬ"), l1ll1l_opy_ (u"ࠪ࠸࠾࠭ࣻ"), l1ll1l_opy_ (u"ࠫ࠺࠸ࠧࣼ")]
    login = l1ll1l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷ࠴ࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࣽ") % addon
    xbmc.executeJSONRPC(login)
    l1l1l1_opy_ = []
    for l1ll1l1l1_opy_ in l1ll11l11_opy_:
        if addon == l1l11lll1_opy_:
            l1ll11lll_opy_ = l1ll1l_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡯࡭ࡺࡾ࠮ࡵࡸ࠲ࡃࡲࡵࡤࡦࡡ࡬ࡨࡂࡩࡨࡢࡰࡱࡩࡱࡹࠦ࡮ࡱࡧࡩࡂࡩࡨࡢࡰࡱࡩࡱࡹࠦࡴࡧࡦࡸ࡮ࡵ࡮ࡠ࡫ࡧࡁࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬࣾ") % l1ll1l1l1_opy_
        if addon == locked:
            l1ll11lll_opy_ = l1ll1l_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰࡴࡩ࡫ࡦࡦࡷࡺ࠴ࡅࡵࡳ࡮ࡀࠩࡸࠬ࡭ࡰࡦࡨࡁ࠹ࠬ࡮ࡢ࡯ࡨࡁࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡳࡰࡦࡿ࠽ࠧࡦࡤࡸࡪࡃࠦࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࡂࠬࡰࡢࡩࡨࡁࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࣿ") % l1ll1l1l1_opy_
        l1l1lllll_opy_  = xbmc.executeJSONRPC(l1ll11lll_opy_)
        response = json.loads(l1l1lllll_opy_)
        l1l1l1_opy_.extend(response[l1ll1l_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨऀ")][l1ll1l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨँ")])
    return l1l1l1_opy_
def sendJSON(query, addon):
    l1ll11lll_opy_     = l1ll1l_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ं") % query
    l1l1lllll_opy_  = xbmc.executeJSONRPC(l1ll11lll_opy_)
    response = json.loads(l1l1lllll_opy_)
    result   = response[l1ll1l_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫः")]
    return result[l1ll1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫऄ")]
def l1l1lll11_opy_(addon):
    l1l1ll111_opy_ = l1ll1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩअ") + addon
    l1l11ll1l_opy_  = l1ll1l_opy_ (u"ࠧࡀࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿࡫ࡸࡹࡶࠥ࠴ࡣࠨ࠶࡫ࠫ࠲ࡧ࡯ࡨࡸࡦࡲ࡫ࡦࡶࡷࡰࡪ࠴ࡣࡰࠧ࠵ࡪ࡚ࡑࡔࡶࡴ࡮࠵࠽࠶࠲࠳࠲࠴࠺ࠪ࠸ࡦࡵࡪࡸࡱࡧࡹࠥ࠳ࡨࡱࡩࡼࠫ࠲ࡧࡗ࡮ࠩ࠷࠻࠲࠱ࡶࡸࡶࡰࠫ࠲࠶࠴࠳ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠥ࠳࠷࠵࠴ࡱ࡯ࡶࡦࠧ࠵࠹࠷࠶ࡴࡷ࠰࡭ࡴ࡬ࠬ࡭ࡰࡦࡨࡁ࠶ࠬ࡮ࡢ࡯ࡨࡁࡑ࡯ࡶࡦࠧ࠵࠴࡙࡜ࠦࡶࡴ࡯ࡁ࡭ࡺࡴࡱࠧ࠶ࡥࠪ࠸ࡦࠦ࠴ࡩࡱࡪࡺࡡ࡭࡭ࡨࡸࡹࡲࡥ࠯ࡥࡲࠩ࠷࡬ࡕࡌࡖࡸࡶࡰ࠷࠸࠱࠴࠵࠴࠶࠼ࠥ࠳ࡨࡏ࡭ࡻ࡫ࠥ࠳࠷࠵࠴࡙࡜࠮ࡵࡺࡷࠫआ")
    l1l1l1_opy_  = []
    l1l1l1_opy_ += sendJSON(l1l1ll111_opy_ + l1l11ll1l_opy_, addon)
    l1l1l1_opy_.sort()
    return l1l1l1_opy_
def l1ll1ll1l_opy_(addon):
    l1l1ll111_opy_ = l1ll1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫइ") + addon
    l1l11ll1l_opy_ = l1ll1l_opy_ (u"ࠩ࠲ࡃ࡫ࡧ࡮ࡢࡴࡷࡁ࡭ࡺࡴࡱࠧ࠶ࡥࠪ࠸ࡦࠦ࠴ࡩ࡫ࡴࡵ࠮ࡨ࡮ࠨ࠶࡫࡞ࡤࡇ࠴࠻ࡘࠫࡳ࡯ࡥࡧࡀ࠵ࠫࡴࡡ࡮ࡧࡀࡐ࡮ࡼࡥࠦ࠴࠳࡙ࡐࠫ࠲࠱ࡕࡳࡳࡷࡺࡳࠧࡷࡵࡰࡂ࡮ࡴࡵࡲࡶࠩ࠸ࡧࠥ࠳ࡨࠨ࠶࡫࡭࡯ࡰ࠰ࡪࡰࠪ࠸ࡦ࠶ࡳࡔ࡫ࡊ࠺ࠧई")
    l1l11llll_opy_ = l1ll1l_opy_ (u"ࠪ࠳ࡄ࡬ࡡ࡯ࡣࡵࡸࡂ࡮ࡴࡵࡲࡶࠩ࠸ࡧࠥ࠳ࡨࠨ࠶࡫࡭࡯ࡰ࠰ࡪࡰࠪ࠸ࡦࡇࡩ࡚ࡑࡰࡠࠦ࡮ࡱࡧࡩࡂ࠷ࠦ࡯ࡣࡰࡩࡂࡒࡩࡷࡧࠨ࠶࠵࡛ࡓࠦ࠴ࡩࡇࡆࡔࠥ࠳࠲ࡖࡴࡴࡸࡴࡴࠨࡸࡶࡱࡃࡨࡵࡶࡳࡷࠪ࠹ࡡࠦ࠴ࡩࠩ࠷࡬ࡧࡰࡱ࠱࡫ࡱࠫ࠲ࡧࡨ࠼࡮࡬࠾ࡎࠨउ")
    l1l1l1_opy_  = []
    l1l1l1_opy_ += sendJSON(l1l1ll111_opy_ + l1l11ll1l_opy_, addon)
    l1l1l1_opy_ += sendJSON(l1l1ll111_opy_ + l1l11llll_opy_, addon)
    return l1l1l1_opy_
def l1ll1llll_opy_(addon):
    if addon == l1l1lll1l_opy_:
        return l1ll1l_opy_ (u"ࠫ࠴ࡅࡣࡢࡶࡀ࠱࠷ࠬࡤࡢࡶࡨࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠨࡨࡲࡩࡊࡡࡵࡧࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦ࡮ࡱࡧࡩࡂ࠸ࠦ࡯ࡣࡰࡩࡂࡓࡹࠦ࠴࠳ࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡸࡥࡤࡱࡵࡨࡳࡧ࡭ࡦࠨࡶࡸࡦࡸࡴࡅࡣࡷࡩࠫࡻࡲ࡭࠿ࡸࡶࡱ࠭ऊ")
    if addon == l1ll11l1l_opy_:
        return l1ll1l_opy_ (u"ࠬ࠵࠿ࡢࡥࡷ࡭ࡴࡴ࠽࡭࡫ࡹࡩࡹࡼ࡟ࡢ࡮࡯ࠪࡪࡾࡴࡳࡣࠩࡴࡦ࡭ࡥࠧࡲ࡯ࡳࡹࠬࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠿ࠩࡸ࡮ࡺ࡬ࡦ࠿ࡄࡰࡱࠫ࠲࠱ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠩࡹࡷࡲࠧऋ")
    return l1ll1l_opy_ (u"࠭ࠧऌ")
def l1llll_opy_():
    modules = map(__import__, [l1lll11_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11l_opy_)):
        return l1ll1l_opy_ (u"ࠧࡕࡴࡸࡩࠬऍ")
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l1ll1l_opy_ (u"ࠨࡖࡵࡹࡪ࠭ऎ")
    return l1ll1l_opy_ (u"ࠩࡉࡥࡱࡹࡥࠨए")
def l111ll_opy_(e, addon):
    l1111_opy_ = l1ll1l_opy_ (u"ࠪࡗࡴࡸࡲࡺ࠮ࠣࡥࡳࠦࡥࡳࡴࡲࡶࠥࡵࡣࡤࡷࡵࡩࡩࡀࠠࡋࡕࡒࡒࠥࡋࡲࡳࡱࡵ࠾ࠥࠫࡳ࠭ࠢࠨࡷࠬऐ")  % (e, addon)
    l111l_opy_ = l1ll1l_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡨࡵ࡮ࡵࡣࡦࡸࠥࡻࡳࠡࡱࡱࠤࡹ࡮ࡥࠡࡨࡲࡶࡺࡳ࠮ࠨऑ")
    l11l1_opy_ = l1ll1l_opy_ (u"࡛ࠬࡰ࡭ࡱࡤࡨࠥࡧࠠ࡭ࡱࡪࠤࡻ࡯ࡡࠡࡶ࡫ࡩࠥࡧࡤࡥࡱࡱࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸࠦࡡ࡯ࡦࠣࡴࡴࡹࡴࠡࡶ࡫ࡩࠥࡲࡩ࡯࡭࠱ࠫऒ")
    dixie.log(addon)
    dixie.log(e)
def getPlaylist():
    import requests
    l1ll11111_opy_ = [l1ll1l_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳ࡍࡋ࡚࠶࡜ࡼ࡭ࡏ࡫ࡗࠨओ"), l1ll1l_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡹ࠰ࡦࡳ࠴ࡾࡦ࠶ࡋ࠶ࡌࡔࡪ࡙ࡏࠩऔ"), l1ll1l_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡺ࠱ࡧࡴ࠵ࡕࡍࡥ࠳࠵ࡒࡕࡌࡨࡅࠪक"), l1ll1l_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡻ࠲ࡨࡵ࠯࡫ࡷࡑࡑࡓ࡭ࡷ࡫ࡒ࠳ࠫख"), l1ll1l_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡼ࠳ࡩ࡯࠰ࡦ࡭ࡆࡦ࠷࡮ࡷ࠻ࡊࡾࠬग"), l1ll1l_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱ࡱ࡚ࡸࡷࡣࡨࡥࡦ࠽ࡾ࠭घ"), l1ll1l_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲ࡼࡑࡉ࠹࠵ࡇ࡙ࡕࡻ࡟ࠧङ"), l1ll1l_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳ࡹࡹࡅ࠴ࡌࡓࡸ࡫ࡓࡲࠨच"), l1ll1l_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡹ࠰ࡦࡳ࠴࡫ࡖࡗࡃࡺࡏࡎࡹࡓࡩࠩछ"), l1ll1l_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡺ࠱ࡧࡴ࠵ࡸࡒࡲࡉࡎ࡜࡭ࡩࡨ࡬ࠪज")]
    l1l1l1lll_opy_ =  l1ll1l_opy_ (u"ࠩࠦࡉ࡝࡚ࡍ࠴ࡗࠪझ")
    for url in l1ll11111_opy_:
        try:
            request  = requests.get(url)
            l1ll1ll11_opy_ = request.text
        except: pass
        if l1l1l1lll_opy_ in l1ll1ll11_opy_:
            path = os.path.join(dixie.PROFILE, l1ll1l_opy_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡳ࠳ࡶࠩञ"))
            with open(path, l1ll1l_opy_ (u"ࠫࡼ࠭ट")) as f:
                f.write(l1ll1ll11_opy_)
                break
def getPluginInfo(streamurl):
    if not l1llll_opy_() == l1ll1l_opy_ (u"࡚ࠬࡲࡶࡧࠪठ"):
        return
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l1l1l1l11_opy_   = l1ll1l_opy_ (u"࠭ࡋࡰࡦ࡬ࠤࡕ࡜ࡒࠨड")
            l1l1l1ll1_opy_ = os.path.join(dixie.RESOURCES, l1ll1l_opy_ (u"ࠧ࡬ࡱࡧ࡭࠲ࡶࡶࡳ࠰ࡳࡲ࡬࠭ढ"))
            return l1l1l1l11_opy_, l1l1l1ll1_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l1ll1l_opy_ (u"ࠨࡴࡷࡱࡵ࠭ण")) or url.startswith(l1ll1l_opy_ (u"ࠩࡵࡸࡲࡶࡥࠨत")) or url.startswith(l1ll1l_opy_ (u"ࠪࡶࡹࡹࡰࠨथ")) or url.startswith(l1ll1l_opy_ (u"ࠫ࡭ࡺࡴࡱࠩद")):
            l1l1l1l11_opy_   = l1ll1l_opy_ (u"ࠬࡳ࠳ࡶࠢࡓࡰࡦࡿ࡬ࡪࡵࡷࠫध")
            l1l1l1ll1_opy_ = os.path.join(dixie.RESOURCES, l1ll1l_opy_ (u"࠭ࡩࡱࡶࡹ࠱ࡵࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡰ࡯ࡩࠪन"))
            return l1l1l1l11_opy_, l1l1l1ll1_opy_
    except:
        pass
    if streamurl.startswith(dixie.OPEN_OTT):
        name = streamurl.split(l1ll1l_opy_ (u"ࠧ࡞ࡑࡗࡘࡤࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨऩ"), 1)[-1].split(l1ll1l_opy_ (u"ࠨ࠱ࠪप"), 1)[0]
    if l1ll1l_opy_ (u"ࠩࡠࡓ࡙࡚࡟ࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪफ") in streamurl:
        name = streamurl.split(l1ll1l_opy_ (u"ࠪࡡࡔ࡚ࡔࡠࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫब"), 1)[-1].split(l1ll1l_opy_ (u"ࠫ࠴࠭भ"), 1)[0]
    if streamurl.startswith(l1ll1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨम")):
        name = streamurl.split(l1ll1l_opy_ (u"࠭࠯࠰ࠩय"), 1)[-1].split(l1ll1l_opy_ (u"ࠧ࠰ࠩर"), 1)[0]
    if l1ll1l_opy_ (u"ࠨࡡࡢࡗࡋࡥ࡟ࠨऱ") in streamurl:
        name = l1ll1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡳࡶࡴ࡭ࡲࡢ࡯࠱ࡷࡺࡶࡥࡳ࠰ࡩࡥࡻࡵࡵࡳ࡫ࡷࡩࡸ࠭ल")
    if l1ll1l_opy_ (u"ࠪࡌࡉ࡚ࡖ࠻ࠩळ") in streamurl:
        name = l1ll1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡲࡧࡲࡵࡪࡸࡦࠬऴ")
    if l1ll1l_opy_ (u"ࠬࡎࡄࡕࡘ࠵࠾ࠬव") in streamurl:
        name = l1ll1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡵࡺࡣ࡬ࡴࡹࡼࠧश")
    if l1ll1l_opy_ (u"ࠧࡉࡆࡗ࡚࠸ࡀࠧष") in streamurl:
        name = l1ll1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥࡹࡼࠧस")
    if l1ll1l_opy_ (u"ࠩࡋࡈ࡙࡜࠴࠻ࠩह") in streamurl:
        name = l1ll1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡰࠬऺ")
    if l1ll1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛࠽ࠫऻ") in streamurl:
        name = l1ll1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡧࡨࡣࡪࡲ࡯ࡥࡾ࡫ࡲࠨ़")
    if l1ll1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝࠷ࡀࠧऽ") in streamurl:
        name = l1ll1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱ࡮ࡤࡽࡪࡸࡷࡸࡹࠪा")
    if l1ll1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡒ࠻ࠩि") in streamurl:
        name = l1ll1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡰࡦࡿࡥࡳࡹࡺࡻࠬी")
    if l1ll1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡋࡗ࡚࠿࠭ु") in streamurl:
        name = l1ll1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡹࡼࠧू")
    if l1ll1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡈ࠿࠭ृ") in streamurl:
        name = l1ll1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡪࡥࡹࠩॄ")
    if l1ll1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡘࡂ࠻ࠩॅ") in streamurl:
        name = l1ll1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡧࡥࡳࡴࡺࠧॆ")
    if l1ll1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡄࡎࡘ࠾ࠬे") in streamurl:
        name = l1ll1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡦࡰࡺ࡯ࡰࡵࡸࠪै")
    if l1ll1l_opy_ (u"ࠫࡎࡖࡔࡔࠩॉ") in streamurl:
        name = l1ll1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢ࡫ࡳࡸࡻ࠭ॊ")
    if l1ll1l_opy_ (u"࠭ࡌࡊࡘࡈࡘ࡛ࡀࠧो") in streamurl:
        name = l1ll1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡬ࡪࡸࡨࡱ࡮ࡾࠧौ")
    if l1ll1l_opy_ (u"ࠨࡷࡳࡲࡵࡀ्ࠧ") in streamurl:
        name = l1ll1l_opy_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰࡫ࡨ࡭ࡵ࡭ࡦࡴࡸࡲ࠳ࡼࡩࡦࡹࠪॎ")
    try:
        l1l1l1l11_opy_   = xbmcaddon.Addon(name).getAddonInfo(l1ll1l_opy_ (u"ࠪࡲࡦࡳࡥࠨॏ"))
        l1l1l1ll1_opy_ = xbmcaddon.Addon(name).getAddonInfo(l1ll1l_opy_ (u"ࠫ࡮ࡩ࡯࡯ࠩॐ"))
    except:
        l1l1l1l11_opy_   = l1ll1l_opy_ (u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡓࡰࡷࡵࡧࡪ࠭॑")
        l1l1l1ll1_opy_ =  dixie.ICON
    return l1l1l1l11_opy_, l1l1l1ll1_opy_
def selectStream(url, channel):
    url = url.replace(l1ll1l_opy_ (u"࠭ࡼࡶࡵࡨࡶ࠲ࡧࡧࡦࡰࡷ॒ࠫ"), l1ll1l_opy_ (u"ࠧ࠮࠯ࡸࡷࡪࡸ࠭ࡢࡩࡨࡲࡹ࠭॓"))
    l1l1l11ll_opy_ = url.split(l1ll1l_opy_ (u"ࠨࡾࠪ॔"))
    if len(l1l1l11ll_opy_) == 0:
        return None
    options, l1l1l111l_opy_ = getOptions(l1l1l11ll_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l1l1l11ll_opy_) == 1:
            return l1l1l111l_opy_[0]
    import selectDialog
    l1ll1111l_opy_ = selectDialog.select(l1ll1l_opy_ (u"ࠩࡖࡩࡱ࡫ࡣࡵࠢࡤࠤࡸࡺࡲࡦࡣࡰࠫॕ"), options)
    if l1ll1111l_opy_ < 0:
        raise Exception(l1ll1l_opy_ (u"ࠪࡗࡪࡲࡥࡤࡶ࡬ࡳࡳࠦࡃࡢࡰࡦࡩࡱ࠭ॖ"))
    return l1l1l111l_opy_[l1ll1111l_opy_]
def getOptions(l1l1l11ll_opy_, channel, addmore=True):
    if not l1llll_opy_() == l1ll1l_opy_ (u"࡙ࠫࡸࡵࡦࠩॗ"):
        return
    options = []
    l1l1l111l_opy_    = []
    for index, stream in enumerate(l1l1l11ll_opy_):
        l1l1l1l11_opy_ = getPluginInfo(stream)
        l1l1l_opy_ = l1l1l1l11_opy_[0]
        l1l1ll11l_opy_  = l1l1l1l11_opy_[1]
        l1l1l_opy_  = l1ll1l_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡵࡲࡢࡰࡪࡩࡢࡡࠧक़") + l1l1l_opy_ + l1ll1l_opy_ (u"࠭࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࠪख़")
        if stream.startswith(OPEN_OTT):
            l1l1l_opy_  = l1l1l_opy_ + stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l1ll1l_opy_ (u"ࠧࠨग़"))
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l1ll1l_opy_ (u"ࠨࠩज़"))
        else:
            l1l1l_opy_  = l1l1l_opy_ + channel
        options.append([l1l1l_opy_, index, l1l1ll11l_opy_])
        l1l1l111l_opy_.append(stream)
    if addmore:
        options.append([l1ll1l_opy_ (u"ࠩࡄࡨࡩࠦ࡭ࡰࡴࡨ࠲࠳࠴ࠧड़"), index + 1, dixie.ICON])
        l1l1l111l_opy_.append(l1ll1l_opy_ (u"ࠪࡥࡩࡪࡍࡰࡴࡨࠫढ़"))
    return options, l1l1l111l_opy_