# coding: UTF-8
import sys
l1111l_opy_ = sys.version_info [0] == 2
l1l111_opy_ = 2048
l1l11_opy_ = 7
def l1ll1l_opy_ (ll_opy_):
	global l1l11l_opy_
	l1llll1_opy_ = ord (ll_opy_ [-1])
	l1l1ll_opy_ = ll_opy_ [:-1]
	l11l11_opy_ = l1llll1_opy_ % len (l1l1ll_opy_)
	l1ll1_opy_ = l1l1ll_opy_ [:l11l11_opy_] + l1l1ll_opy_ [l11l11_opy_:]
	if l1111l_opy_:
		l11ll1_opy_ = unicode () .join ([unichr (ord (char) - l1l111_opy_ - (l1lll1_opy_ + l1llll1_opy_) % l1l11_opy_) for l1lll1_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l11ll1_opy_ = str () .join ([chr (ord (char) - l1l111_opy_ - (l1lll1_opy_ + l1llll1_opy_) % l1l11_opy_) for l1lll1_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l11ll1_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
l11111_opy_ = l1ll1l_opy_ (u"ࠫࠬࠀ")
def l1lll11_opy_(i, t1, l1lllll_opy_=[]):
 t = l11111_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1lllll_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11l_opy_ = l1lll11_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11_opy_ = l1lll11_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1_opy_  = l1ll1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸࠨࠁ")
PATH = os.path.join(dixie.PROFILE, l1ll1l_opy_ (u"࠭ࡤࡵࡧࡰࡴࠬࠂ"))
def createINI():
    if xbmc.getCondVisibility(l1ll1l_opy_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡉࡣࡶࡅࡩࡪ࡯࡯ࠪࠨࡷ࠮࠭ࠃ") % l1_opy_) == 1:
        HOME = dixie.PROFILE
        PATH = os.path.join(HOME, l1ll1l_opy_ (u"ࠨ࡫ࡱ࡭ࠬࠄ"))
        l111_opy_ = l1ll1l_opy_ (u"ࠩࡧࡩࡽࡺࡥࡳ࠰࡬ࡲ࡮࠭ࠅ")
        l1l_opy_  = os.path.join(PATH, l111_opy_)
        response = doJSON()
        l111l1_opy_ = response[l1ll1l_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪࠆ")][l1ll1l_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪࠇ")]
        l1ll11_opy_  = l1ll1l_opy_ (u"ࠬࡡࠧࠈ") + l1_opy_ + l1ll1l_opy_ (u"࠭࡝࡝ࡰࠪࠉ")
        l1l1_opy_  =  file(l1l_opy_, l1ll1l_opy_ (u"ࠧࡸࠩࠊ"))
        l1l1_opy_.write(l1ll11_opy_)
        l11ll_opy_ = []
        for channel in l111l1_opy_:
            l1l1l_opy_    =  channel[l1ll1l_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࠋ")]
            l1ll_opy_ =  dixie.mapChannelName(l1l1l_opy_)
            stream   = l1ll1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪࠌ") + l1l1l_opy_
            l1lll_opy_  =  l1ll_opy_ + l1ll1l_opy_ (u"ࠪࡁࠬࠍ") + stream
            if l1lll_opy_ not in l11ll_opy_:
                l11ll_opy_.append(l1lll_opy_)
        l11ll_opy_.sort()
        for item in l11ll_opy_:
            l1l1_opy_.write(l1ll1l_opy_ (u"ࠦࠪࡹ࡜࡯ࠤࠎ") % item)
        l1l1_opy_.close()
def getURL(url):
    if not l1llll_opy_() == l1ll1l_opy_ (u"࡚ࠬࡲࡶࡧࠪࠏ"):
        return
    if url.startswith(l1ll1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡈࡒࡕ࠻ࠩࠐ")):
        url = url.replace(l1ll1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡉࡌࡖ࠼ࠪࠑ"), l1ll1l_opy_ (u"ࠨࠩࠒ")).replace(l1ll1l_opy_ (u"ࠩ࠰࠱ࡺࡹࡥࡳ࠯ࡤ࡫ࡪࡴࡴࠨࠓ"), l1ll1l_opy_ (u"ࠪࢀࡺࡹࡥࡳ࠯ࡤ࡫ࡪࡴࡴࠨࠔ"))
        return url
    if url.startswith(l1ll1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡇ࠾ࠬࠕ")):
        return l11lll_opy_(url)
    response = l1lll1l_opy_(url)
    stream   = url.split(l1ll1l_opy_ (u"ࠬࡀࠧࠖ"), 1)[-1]
    try:
        result = response[l1ll1l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࠗ")]
        l1l1l1_opy_  = result[l1ll1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭࠘")]
    except Exception as e:
        l111ll_opy_(e)
        return None
    for file in l1l1l1_opy_:
        l1l1l_opy_ = file[l1ll1l_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧ࠙")]
        if stream in l1l1l_opy_:
            return file[l1ll1l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧࠚ")]
    return None
def l11lll_opy_(url):
    if os.path.exists(PATH):
        response = json.load(open(PATH))
    else:
        response = doJSON()
    stream = url.split(l1ll1l_opy_ (u"ࠪ࠾ࠬࠛ"), 1)[-1]
    l1l1l1_opy_  = response[l1ll1l_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫࠜ")][l1ll1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫࠝ")]
    for file in l1l1l1_opy_:
        l1l1l_opy_ = file[l1ll1l_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬࠞ")]
        if stream in l1l1l_opy_:
            return file[l1ll1l_opy_ (u"ࠧࡧ࡫࡯ࡩࠬࠟ")]
def doJSON():
    l11l1l_opy_  = (l1ll1l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿ࡤࡰࡱࠬࡥࡹࡶࡵࡥࠫࡶࡡࡨࡧࠩࡴࡱࡵࡴࠧࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡁࠫࡺࡩࡵ࡮ࡨࡁࠪ࠻ࡢࡄࡑࡏࡓࡗࠫ࠲࠱ࡹ࡫࡭ࡹ࡫ࠥ࠶ࡦࡄࡰࡱࠫ࠲࠱ࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠨ࠹ࡧࠫ࠲ࡧࡅࡒࡐࡔࡘࠥ࠶ࡦࠩࡹࡷࡲࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬࠠ"))
    response = xbmc.executeJSONRPC(l11l1l_opy_)
    content  = json.loads(response)
    json.dump(content, open(PATH,l1ll1l_opy_ (u"ࠩࡺࠫࠡ")), indent=3)
    return json.load(open(PATH))
def l1lll1l_opy_(url):
    if url.startswith(l1ll1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠼ࠪࠢ")):
        l11l1l_opy_ = (l1ll1l_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡣࡤࡦ࡭ࡵࡲࡡࡺࡧࡵ࠳ࡄࡻࡲ࡭࠿ࡸࡶࡱࠬ࡭ࡰࡦࡨࡁ࠷ࠬ࡮ࡢ࡯ࡨࡁࡑ࡯ࡶࡦࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࡁࠫࡏࡐࡊࡆࡀࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩࠣ"))
    if url.startswith(l1ll1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜࠶࠿࠭ࠤ")):
        l11l1l_opy_ = (l1ll1l_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠵࠿ࡶࡴ࡯ࡁࡺࡸ࡬ࠧ࡯ࡲࡨࡪࡃ࠱࠱࠳ࠩࡲࡦࡳࡥ࠾࡙ࡤࡸࡨ࡮ࠫࡍ࡫ࡹࡩࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴ࠽ࠧࡵࡸࡦࡹ࡯ࡴ࡭ࡧࡶࡣࡺࡸ࡬࠾ࠨ࡯ࡳ࡬࡭ࡥࡥࡡ࡬ࡲࡂࡌࡡ࡭ࡵࡨࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩࠥ"))
    if url.startswith(l1ll1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡘ࠺ࠨࠦ")):
        l11l1l_opy_ = (l1ll1l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶ࡬ࡢࡻࡨࡶࡼࡽࡷ࠰ࡁࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠦ࡭ࡱࡪ࡫ࡪࡪ࡟ࡪࡰࡀࡊࡦࡲࡳࡦࠨࡰࡳࡩ࡫࠽࠲࠳࠶ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡸࡺࡥ࡯ࠧ࠵࠴ࡑ࡯ࡶࡦࠨࡶࡹࡧࡺࡩࡵ࡮ࡨࡷࡤࡻࡲ࡭ࠨࡸࡶࡱࡃࡵࡳ࡮ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨࠧ"))
    if url.startswith(l1ll1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡊࡖ࡙࠾ࠬࠨ")):
        l11l1l_opy_ = (l1ll1l_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡵࡸࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨࠩ"))
    if url.startswith(l1ll1l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡇ࠾ࠬࠪ")):
        l11l1l_opy_ = (l1ll1l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡦࡨࡼ࠴ࡅࡡࡤࡶ࡬ࡳࡳࡃࡡ࡭࡮ࠩࡩࡽࡺࡲࡢࠨࡳࡥ࡬࡫ࠦࡱ࡮ࡲࡸࠫࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠾ࠨࡷ࡭ࡹࡲࡥ࠾ࠧ࠸ࡦࡈࡕࡌࡐࡔࠨ࠶࠵ࡽࡨࡪࡶࡨࠩ࠺ࡪࡁ࡭࡮ࠨ࠶࠵ࡉࡨࡢࡰࡱࡩࡱࡹࠥ࠶ࡤࠨ࠶࡫ࡉࡏࡍࡑࡕࠩ࠺ࡪࠦࡶࡴ࡯ࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩࠫ"))
    if url.startswith(l1ll1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡗࡈ࠺ࠨࠬ")):
        l11l1l_opy_ = (l1ll1l_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡪࡨ࡯ࡰࡶ࠲ࡃࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠨࡩࡥࡳࡧࡲࡵ࠿ࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦ࡮ࡱࡧࡩࡂ࠽ࠦࡱ࡫࡯ࡰࡴࡽ࠽ࡍ࡫ࡹࡩࠪ࠸࠰ࡔࡶࡵࡩࡦࡳࡳࠧࡷࡵࡰࡂࡸࡡ࡯ࡦࡲࡱࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ࠭"))
    if url.startswith(l1ll1l_opy_ (u"ࠨࡋࡓࡘࡘࡀࠧ࠮")):
        l11l1l_opy_ = (l1ll1l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡵࡺࡣ࡬ࡴࡹࡼ࠯ࡀࡣࡦࡸ࡮ࡵ࡮࠾࡮࡬ࡺࡪࡺࡶࡠࡣ࡯ࡰࠫ࡫ࡸࡵࡴࡤࠪࡵࡧࡧࡦࠨࡳࡰࡴࡺࠦࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡀࠪࡹ࡯ࡴ࡭ࡧࡀࡅࡱࡲࠥ࠳࠲ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪࡺࡸ࡬ࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭࠯"))
    try:
        dixie.ShowBusy()
        addon =  l11l1l_opy_.split(l1ll1l_opy_ (u"ࠪ࠳࠴࠭࠰"), 1)[-1].split(l1ll1l_opy_ (u"ࠫ࠴࠭࠱"), 1)[0]
        login = l1ll1l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ࠲") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l11l1l_opy_)
        dixie.log(response)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l111ll_opy_(e)
        return {l1ll1l_opy_ (u"࠭ࡅࡳࡴࡲࡶࠬ࠳") : l1ll1l_opy_ (u"ࠧࡑ࡮ࡸ࡫࡮ࡴࠠࡆࡴࡵࡳࡷ࠭࠴")}
def l1llll_opy_():
    modules = map(__import__, [l1lll11_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11l_opy_)):
        return l1ll1l_opy_ (u"ࠨࡖࡵࡹࡪ࠭࠵")
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l1ll1l_opy_ (u"ࠩࡗࡶࡺ࡫ࠧ࠶")
    return l1ll1l_opy_ (u"ࠪࡊࡦࡲࡳࡦࠩ࠷")
def l111ll_opy_(e):
    l1111_opy_ = l1ll1l_opy_ (u"ࠫࡘࡵࡲࡳࡻ࠯ࠤࡦࡴࠠࡦࡴࡵࡳࡷࠦ࡯ࡤࡥࡸࡶࡪࡪ࠺ࠡࡌࡖࡓࡓࠦࡅࡳࡴࡲࡶ࠿ࠦࠥࡴࠩ࠸")  %e
    l111l_opy_ = l1ll1l_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡸࡥ࠮࡮࡬ࡲࡰࠦࡴࡩ࡫ࡶࠤࡨ࡮ࡡ࡯ࡰࡨࡰࠥࡧ࡮ࡥࠢࡷࡶࡾࠦࡡࡨࡣ࡬ࡲ࠳࠭࠹")
    l11l1_opy_ = l1ll1l_opy_ (u"࠭ࡕࡴࡧ࠽ࠤࡈࡵ࡮ࡵࡧࡻࡸࠥࡓࡥ࡯ࡷࠣࡁࡃࠦࡒࡦ࡯ࡲࡺࡪࠦࡓࡵࡴࡨࡥࡲ࠭࠺")
    dixie.log(e)
    dixie.DialogOK(l1111_opy_, l111l_opy_, l11l1_opy_)