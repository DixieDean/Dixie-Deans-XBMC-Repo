# coding: UTF-8
import sys
l1l1l11l_opy_ = sys.version_info [0] == 2
l111l1l_opy_ = 2048
l1l1l1ll_opy_ = 7
def l1l1l_opy_ (l1l111_opy_):
	global l111lll_opy_
	l1llllll_opy_ = ord (l1l111_opy_ [-1])
	l1l1ll11_opy_ = l1l111_opy_ [:-1]
	l1l1111_opy_ = l1llllll_opy_ % len (l1l1ll11_opy_)
	l11l11_opy_ = l1l1ll11_opy_ [:l1l1111_opy_] + l1l1ll11_opy_ [l1l1111_opy_:]
	if l1l1l11l_opy_:
		l1111_opy_ = unicode () .join ([unichr (ord (char) - l111l1l_opy_ - (l1lll_opy_ + l1llllll_opy_) % l1l1l1ll_opy_) for l1lll_opy_, char in enumerate (l11l11_opy_)])
	else:
		l1111_opy_ = str () .join ([chr (ord (char) - l111l1l_opy_ - (l1lll_opy_ + l1llllll_opy_) % l1l1l1ll_opy_) for l1lll_opy_, char in enumerate (l11l11_opy_)])
	return eval (l1111_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l11l1111l_opy_     = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡴࡴࡷࠩ१")
l111lll11_opy_  = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡷ࡭࡫ࡳࡸࡻ࠭२")
l11l1ll11_opy_     = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡶ࡭ࡷࡹࡷࡱࠧ३")
locked  = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮ࡲࡧࡰ࡫ࡤࡵࡸࠪ४")
l111l1lll_opy_      = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸࡰࡹ࡯࡭ࡢࡶࡨࡱࡦࡴࡩࡢࠩ५")
l111ll1l1_opy_    = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰ࡮ࡻࡸ࠯ࡶࡹࠫ६")
l111llll1_opy_     = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡉࡉࡓࡱࡱࡵࡸࡸ࠭७")
l11l1l1ll_opy_  = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡥࡣࡱࡲࡸࠬ८")
l111lllll_opy_     = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡣ࡭ࡷ࡬ࡴࡹࡼࠧ९")
l11l1l1l1_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡶ࡭ࡷࡺ࠹࡫ࡸࡱࡣࡷࡷ࠳ࡩ࡯࡮ࠩ॰")
l1llll11_opy_ = [l11l1111l_opy_, locked, l111ll1l1_opy_, l111lll11_opy_, l11l1l1l1_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1l1l_opy_ (u"ࠩ࡬ࡲ࡮࠭ॱ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1l1ll1_opy_ = l1l1l_opy_ (u"ࠪࠫॲ")
def l1l11l_opy_(i, t1, l1l1l1_opy_=[]):
 t = l1l1ll1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l1l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11_opy_ = l1l11l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11lll_opy_ = l1l11l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1llll11_opy_:
        if l1l1l1l1_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1l1l1l1_opy_(addon):
    if xbmc.getCondVisibility(l1l1l_opy_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡍࡧࡳࡂࡦࡧࡳࡳ࠮ࠥࡴࠫࠪॳ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l11lll1l_opy_ = str(addon).split(l1l1l_opy_ (u"ࠬ࠴ࠧॴ"))[2] + l1l1l_opy_ (u"࠭࠮ࡪࡰ࡬ࠫॵ")
    l1l11l1_opy_  = os.path.join(PATH, l11lll1l_opy_)
    try:
        l11llll_opy_ = l1lll1ll_opy_(addon)
    except KeyError:
        dixie.log(l1l1l_opy_ (u"ࠧ࠮࠯࠰࠱࠲ࠦࡋࡦࡻࡈࡶࡷࡵࡲࠡ࡫ࡱࠤ࡬࡫ࡴࡇ࡫࡯ࡩࡸࠦ࠭࠮࠯࠰࠱ࠥ࠭ॶ") + addon)
        result = {l1l1l_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࡳࠨॷ"): [{l1l1l_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬॸ"): l1l1l_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࠩॹ"), l1l1l_opy_ (u"ࡹࠬࡺࡹࡱࡧࠪॺ"): l1l1l_opy_ (u"ࡺ࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧॻ"), l1l1l_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࠬॼ"): l1l1l_opy_ (u"ࡵࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡼࡽ࠭ॽ"), l1l1l_opy_ (u"ࡶࠩ࡯ࡥࡧ࡫࡬ࠨॾ"): l1l1l_opy_ (u"ࡷࠪࡒࡔࠦࡃࡉࡃࡑࡒࡊࡒࡓࠨॿ")}], l1l1l_opy_ (u"ࡸࠫࡱ࡯࡭ࡪࡶࡶࠫঀ"):{l1l1l_opy_ (u"ࡹࠬࡹࡴࡢࡴࡷࠫঁ"): 0, l1l1l_opy_ (u"ࡺ࠭ࡴࡰࡶࡤࡰࠬং"): 1, l1l1l_opy_ (u"ࡻࠧࡦࡰࡧࠫঃ"): 1}}
    l1l1ll_opy_  = l1l1l_opy_ (u"ࠧ࡜ࠩ঄") + addon + l1l1l_opy_ (u"ࠨ࡟࡟ࡲࠬঅ")
    l1ll1lll_opy_  =  file(l1l11l1_opy_, l1l1l_opy_ (u"ࠩࡺࠫআ"))
    l1ll1lll_opy_.write(l1l1ll_opy_)
    l1l11lll_opy_ = []
    for channel in l11llll_opy_:
        l1l1_opy_ = dixie.cleanLabel(channel[l1l1l_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩই")])
        l1l11ll_opy_   = dixie.cleanPrefix(l1l1_opy_)
        l11l1l_opy_ = dixie.mapChannelName(l1l11ll_opy_)
        stream   = channel[l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࠩঈ")]
        l111l1_opy_ = l11l1l_opy_ + l1l1l_opy_ (u"ࠬࡃࠧউ") + stream
        l1l11lll_opy_.append(l111l1_opy_)
        l1l11lll_opy_.sort()
    for item in l1l11lll_opy_:
        l1ll1lll_opy_.write(l1l1l_opy_ (u"ࠨࠥࡴ࡞ࡱࠦঊ") % item)
    l1ll1lll_opy_.close()
def l1lll1ll_opy_(addon):
    if (addon == l11l1111l_opy_) or (addon == l111lll11_opy_):
        if xbmcaddon.Addon(addon).getSetting(l1l1l_opy_ (u"ࠧࡨࡧࡱࡶࡪ࠭ঋ")) == l1l1l_opy_ (u"ࠨࡶࡵࡹࡪ࠭ঌ"):
            xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"ࠩࡪࡩࡳࡸࡥࠨ঍"), l1l1l_opy_ (u"ࠪࡪࡦࡲࡳࡦࠩ঎"))
            xbmcgui.Window(10000).setProperty(l1l1l_opy_ (u"ࠫࡕࡒࡕࡈࡋࡑࡣࡌࡋࡎࡓࡇࠪএ"), l1l1l_opy_ (u"࡚ࠬࡲࡶࡧࠪঐ"))
        if xbmcaddon.Addon(addon).getSetting(l1l1l_opy_ (u"࠭ࡴࡷࡩࡸ࡭ࡩ࡫ࠧ঑")) == l1l1l_opy_ (u"ࠧࡵࡴࡸࡩࠬ঒"):
            xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"ࠨࡶࡹ࡫ࡺ࡯ࡤࡦࠩও"), l1l1l_opy_ (u"ࠩࡩࡥࡱࡹࡥࠨঔ"))
            xbmcgui.Window(10000).setProperty(l1l1l_opy_ (u"ࠪࡔࡑ࡛ࡇࡊࡐࡢࡘ࡛ࡍࡕࡊࡆࡈࠫক"), l1l1l_opy_ (u"࡙ࠫࡸࡵࡦࠩখ"))
        l111ll1ll_opy_  = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨগ") + addon
        l11l1l111_opy_ =  l11l1lll1_opy_(addon)
        query   =  l111ll1ll_opy_ + l11l1l111_opy_
        return sendJSON(query, addon)
    return l11l11l11_opy_(addon)
def l11l11l11_opy_(addon):
    if addon == l11l1l1l1_opy_:
        l11l11l1l_opy_ = [l1l1l_opy_ (u"࠭࠱࠷࠳ࠪঘ"), l1l1l_opy_ (u"ࠧ࠲࠸࠳ࠫঙ"), l1l1l_opy_ (u"ࠨ࠴࠶࠺ࠬচ"), l1l1l_opy_ (u"ࠩ࠵࠸࠷࠭ছ"), l1l1l_opy_ (u"ࠪ࠵࠺࠾ࠧজ"), l1l1l_opy_ (u"ࠫ࠶࠻࠹ࠨঝ")]
    if addon == l111ll1l1_opy_:
        l11l11l1l_opy_ = [l1l1l_opy_ (u"ࠬ࠻ࠧঞ"), l1l1l_opy_ (u"࠭࠱࠱࠸ࠪট"), l1l1l_opy_ (u"ࠧ࠵ࠩঠ"), l1l1l_opy_ (u"ࠨ࠴࠹࠷ࠬড"), l1l1l_opy_ (u"ࠩ࠴࠷࠷࠭ঢ")]
    if addon == locked:
        l11l11l1l_opy_ = [l1l1l_opy_ (u"ࠪ࠷࠵࠭ণ"), l1l1l_opy_ (u"ࠫ࠸࠷ࠧত"), l1l1l_opy_ (u"ࠬ࠹࠲ࠨথ"), l1l1l_opy_ (u"࠭࠳࠴ࠩদ"), l1l1l_opy_ (u"ࠧ࠴࠶ࠪধ"), l1l1l_opy_ (u"ࠨ࠵࠸ࠫন"), l1l1l_opy_ (u"ࠩ࠶࠼ࠬ঩"), l1l1l_opy_ (u"ࠪ࠸࠵࠭প"), l1l1l_opy_ (u"ࠫ࠹࠷ࠧফ"), l1l1l_opy_ (u"ࠬ࠺࠵ࠨব"), l1l1l_opy_ (u"࠭࠴࠸ࠩভ"), l1l1l_opy_ (u"ࠧ࠵࠻ࠪম"), l1l1l_opy_ (u"ࠨ࠷࠵ࠫয")]
    if addon == l111l1lll_opy_:
        l11l11l1l_opy_ = [l1l1l_opy_ (u"ࠩ࠵࠹ࠬর"), l1l1l_opy_ (u"ࠪ࠶࠻࠭঱"), l1l1l_opy_ (u"ࠫ࠷࠽ࠧল"), l1l1l_opy_ (u"ࠬ࠸࠹ࠨ঳"), l1l1l_opy_ (u"࠭࠳࠱ࠩ঴"), l1l1l_opy_ (u"ࠧ࠴࠳ࠪ঵"), l1l1l_opy_ (u"ࠨ࠵࠵ࠫশ"), l1l1l_opy_ (u"ࠩ࠶࠹ࠬষ"), l1l1l_opy_ (u"ࠪ࠷࠻࠭স"), l1l1l_opy_ (u"ࠫ࠸࠽ࠧহ"), l1l1l_opy_ (u"ࠬ࠹࠸ࠨ঺"), l1l1l_opy_ (u"࠭࠳࠺ࠩ঻"), l1l1l_opy_ (u"ࠧ࠵࠲়ࠪ"), l1l1l_opy_ (u"ࠨ࠶࠴ࠫঽ"), l1l1l_opy_ (u"ࠩ࠷࠼ࠬা"), l1l1l_opy_ (u"ࠪ࠸࠾࠭ি"), l1l1l_opy_ (u"ࠫ࠺࠶ࠧী"), l1l1l_opy_ (u"ࠬ࠻࠲ࠨু"), l1l1l_opy_ (u"࠭࠵࠵ࠩূ"), l1l1l_opy_ (u"ࠧ࠶࠸ࠪৃ"), l1l1l_opy_ (u"ࠨ࠷࠺ࠫৄ"), l1l1l_opy_ (u"ࠩ࠸࠼ࠬ৅"), l1l1l_opy_ (u"ࠪ࠹࠾࠭৆"), l1l1l_opy_ (u"ࠫ࠻࠶ࠧে"), l1l1l_opy_ (u"ࠬ࠼࠱ࠨৈ"), l1l1l_opy_ (u"࠭࠶࠳ࠩ৉"), l1l1l_opy_ (u"ࠧ࠷࠵ࠪ৊"), l1l1l_opy_ (u"ࠨ࠸࠸ࠫো"), l1l1l_opy_ (u"ࠩ࠹࠺ࠬৌ"), l1l1l_opy_ (u"ࠪ࠺࠼্࠭"), l1l1l_opy_ (u"ࠫ࠻࠿ࠧৎ"), l1l1l_opy_ (u"ࠬ࠽࠰ࠨ৏"), l1l1l_opy_ (u"࠭࠷࠵ࠩ৐"), l1l1l_opy_ (u"ࠧ࠸࠹ࠪ৑"), l1l1l_opy_ (u"ࠨ࠹࠻ࠫ৒"), l1l1l_opy_ (u"ࠩ࠻࠴ࠬ৓"), l1l1l_opy_ (u"ࠪ࠼࠶࠭৔")]
    login = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴ࠱ࠪ৕") % addon
    sendJSON(login, addon)
    l11l111_opy_ = []
    for l11l1ll1l_opy_ in l11l11l1l_opy_:
        if (addon == l11l1l1l1_opy_) or (addon == l111ll1l1_opy_):
            query = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠦࡵ࠲ࡃࡲࡵࡤࡦࡡ࡬ࡨࡂࡩࡨࡢࡰࡱࡩࡱࡹࠦ࡮ࡱࡧࡩࡂࡩࡨࡢࡰࡱࡩࡱࡹࠦࡴࡧࡦࡸ࡮ࡵ࡮ࡠ࡫ࡧࡁࠪࡹࠧ৖") % (addon, l11l1ll1l_opy_)
        if (addon == locked) or (addon == l111l1lll_opy_):
            query = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶ࠳ࡄࡻࡲ࡭࠿ࠨࡷࠫࡳ࡯ࡥࡧࡀ࠸ࠫࡴࡡ࡮ࡧࡀࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧࡲ࡯ࡥࡾࡃࠦࡥࡣࡷࡩࡂࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࡁࠫࡶࡡࡨࡧࡀࠫৗ") % (addon, l11l1ll1l_opy_)
        response = sendJSON(query, addon)
        l11l111_opy_.extend(response)
    return l11l111_opy_
def sendJSON(query, addon):
    l11l1l11l_opy_     = l1l1l_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ৘") % query
    l11l111l1_opy_  = xbmc.executeJSONRPC(l11l1l11l_opy_)
    response = json.loads(l11l111l1_opy_)
    result   = response[l1l1l_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨ৙")]
    if xbmcgui.Window(10000).getProperty(l1l1l_opy_ (u"ࠩࡓࡐ࡚ࡍࡉࡏࡡࡊࡉࡓࡘࡅࠨ৚")) == l1l1l_opy_ (u"ࠪࡘࡷࡻࡥࠨ৛"):
        xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"ࠫ࡬࡫࡮ࡳࡧࠪড়"), l1l1l_opy_ (u"ࠬࡺࡲࡶࡧࠪঢ়"))
    if xbmcgui.Window(10000).getProperty(l1l1l_opy_ (u"࠭ࡐࡍࡗࡊࡍࡓࡥࡔࡗࡉࡘࡍࡉࡋࠧ৞")) == l1l1l_opy_ (u"ࠧࡕࡴࡸࡩࠬয়"):
        xbmcaddon.Addon(addon).setSetting(l1l1l_opy_ (u"ࠨࡶࡹ࡫ࡺ࡯ࡤࡦࠩৠ"), l1l1l_opy_ (u"ࠩࡷࡶࡺ࡫ࠧৡ"))
    return result[l1l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩৢ")]
def l11l1lll1_opy_(addon):
    if (addon == l11l1111l_opy_) or (addon == l111lll11_opy_):
        return l1l1l_opy_ (u"ࠫ࠴ࡅࡣࡢࡶࡀ࠱࠷ࠬࡤࡢࡶࡨࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠨࡨࡲࡩࡊࡡࡵࡧࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࠦ࡮ࡱࡧࡩࡂ࠸ࠦ࡯ࡣࡰࡩࡂࡓࡹࠦ࠴࠳ࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡸࡥࡤࡱࡵࡨࡳࡧ࡭ࡦࠨࡶࡸࡦࡸࡴࡅࡣࡷࡩࠫࡻࡲ࡭࠿ࡸࡶࡱ࠭ৣ")
    return l1l1l_opy_ (u"ࠬ࠭৤")
def l1l1lll1_opy_():
    modules = map(__import__, [l1l11l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l1l1l_opy_ (u"࠭ࡔࡳࡷࡨࠫ৥")
    if len(modules[-1].Window(10**4).getProperty(l11lll_opy_)):
        return l1l1l_opy_ (u"ࠧࡕࡴࡸࡩࠬ০")
    return l1l1l_opy_ (u"ࠨࡈࡤࡰࡸ࡫ࠧ১")
def l1l11111_opy_(e, addon):
    l1l1llll_opy_ = l1l1l_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠭ࠢࡤࡲࠥ࡫ࡲࡳࡱࡵࠤࡴࡩࡣࡶࡴࡨࡨ࠿ࠦࡊࡔࡑࡑࠤࡊࡸࡲࡰࡴ࠽ࠤࠪࡹࠬࠡࠧࡶࠫ২")  % (e, addon)
    l11ll1l_opy_ = l1l1l_opy_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡧࡴࡴࡴࡢࡥࡷࠤࡺࡹࠠࡰࡰࠣࡸ࡭࡫ࠠࡧࡱࡵࡹࡲ࠴ࠧ৩")
    l1ll111l_opy_ = l1l1l_opy_ (u"࡚ࠫࡶ࡬ࡰࡣࡧࠤࡦࠦ࡬ࡰࡩࠣࡺ࡮ࡧࠠࡵࡪࡨࠤࡦࡪࡤࡰࡰࠣࡷࡪࡺࡴࡪࡰࡪࡷࠥࡧ࡮ࡥࠢࡳࡳࡸࡺࠠࡵࡪࡨࠤࡱ࡯࡮࡬࠰ࠪ৪")
    dixie.log(addon)
    dixie.log(e)
def getPluginInfo(streamurl, kodiID=False):
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l111l1ll1_opy_   = l1l1l_opy_ (u"ࠬࡑ࡯ࡥ࡫ࠣࡔ࡛ࡘࠧ৫")
            l111ll11l_opy_ = os.path.join(dixie.RESOURCES, l1l1l_opy_ (u"࠭࡫ࡰࡦ࡬࠱ࡵࡼࡲ࠯ࡲࡱ࡫ࠬ৬"))
            return l111l1ll1_opy_, l111ll11l_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l1l1l_opy_ (u"ࠧࡳࡶࡰࡴࠬ৭")) or url.startswith(l1l1l_opy_ (u"ࠨࡴࡷࡱࡵ࡫ࠧ৮")) or url.startswith(l1l1l_opy_ (u"ࠩࡵࡸࡸࡶࠧ৯")) or url.startswith(l1l1l_opy_ (u"ࠪ࡬ࡹࡺࡰࠨৰ")):
            l111l1ll1_opy_   = l1l1l_opy_ (u"ࠫࡲ࠹ࡵࠡࡒ࡯ࡥࡾࡲࡩࡴࡶࠪৱ")
            l111ll11l_opy_ = os.path.join(dixie.RESOURCES, l1l1l_opy_ (u"ࠬ࡯ࡰࡵࡸ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡶ࡮ࡨࠩ৲"))
            return l111l1ll1_opy_, l111ll11l_opy_
    except:
        pass
    if streamurl.startswith(l1l1l_opy_ (u"࠭ࡰࡷࡴ࠽࠳࠴࠭৳")):
        l111l1ll1_opy_   = l1l1l_opy_ (u"ࠧࡌࡱࡧ࡭ࠥࡖࡖࡓࠩ৴")
        l111ll11l_opy_ = os.path.join(dixie.RESOURCES, l1l1l_opy_ (u"ࠨ࡭ࡲࡨ࡮࠳ࡰࡷࡴ࠱ࡴࡳ࡭ࠧ৵"))
        return l111l1ll1_opy_, l111ll11l_opy_
    if streamurl.startswith(dixie.OPEN_OTT):
        l11l11111_opy_ = streamurl.split(l1l1l_opy_ (u"ࠩࡠࡓ࡙࡚࡟ࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ৶"), 1)[-1].split(l1l1l_opy_ (u"ࠪ࠳ࠬ৷"), 1)[0]
    if l1l1l_opy_ (u"ࠫࡢࡕࡔࡕࡡࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ৸") in streamurl:
        l11l11111_opy_ = streamurl.split(l1l1l_opy_ (u"ࠬࡣࡏࡕࡖࡢࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭৹"), 1)[-1].split(l1l1l_opy_ (u"࠭࠯ࠨ৺"), 1)[0]
    if streamurl.startswith(l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ৻")):
        l11l11111_opy_ = streamurl.split(l1l1l_opy_ (u"ࠨ࠱࠲ࠫৼ"), 1)[-1].split(l1l1l_opy_ (u"ࠩ࠲ࠫ৽"), 1)[0]
    if l1l1l_opy_ (u"ࠪࡋࡘࡖࡒࡕࡕ࠽ࠫ৾") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡫࡮ࢀ࡭ࡰࡵࡳࡳࡷࡺࡳࠨ৿")
    if l1l1l_opy_ (u"ࠬࡥ࡟ࡔࡈࡢࡣࠬ਀") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡰࡳࡱࡪࡶࡦࡳ࠮ࡴࡷࡳࡩࡷ࠴ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵࠪਁ")
    if l1l1l_opy_ (u"ࠧࡗࡋࡓࡗࡘࡀࠧਂ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡗࡋࡓࡗࡺࡶࡥࡳࡕࡷࡶࡪࡧ࡭ࡴࡖ࡙ࠫਃ")
    if l1l1l_opy_ (u"ࠩࡏࡍࡒ࠸࠺ࠨ਄") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡏ࡭ࡲ࡯ࡴ࡭ࡧࡶࡷ࡛࠸ࠧਅ")
    if l1l1l_opy_ (u"ࠫࡓࡇࡔࡉ࠼ࠪਆ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡓࡧࡴࡩࡱ࠱ࡍࡕ࡚ࡖࠨਇ")
    if l1l1l_opy_ (u"࠭ࡎࡊࡅࡈ࠾ࠬਈ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡮ࡢࡶ࡫ࡳࡸࡻࡢࡴ࡫ࡦࡩࠬਉ")
    if l1l1l_opy_ (u"ࠨࡒࡕࡉࡒࡀࠧਊ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡲࡵࡩࡲ࡯ࡵ࡮࡫ࡳࡸࡻ࠭਋")
    if l1l1l_opy_ (u"ࠪࡋࡎࡠ࠺ࠨ਌") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡫࡮ࢀ࡭ࡰࡶࡹࠫ਍")
    if l1l1l_opy_ (u"ࠬࡍࡅࡉ࠼ࠪ਎") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡭ࡥࡩࡱࡶࡸ࡮ࡴࡧࠨਏ")
    if l1l1l_opy_ (u"ࠧࡎࡖ࡛ࡍࡊࡀࠧਐ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡮ࡣࡷࡶ࡮ࡾࡩࡳࡧ࡯ࡥࡳࡪࠧ਑")
    if l1l1l_opy_ (u"ࠩࡗ࡚ࡐࡀࠧ਒") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡷࡺࡰ࡯࡮ࡨࡵࠪਓ")
    if l1l1l_opy_ (u"ࠫ࡝࡚ࡃ࠻ࠩਔ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡺࡲࡦࡣࡰ࠱ࡨࡵࡤࡦࡵࠪਕ")
    if l1l1l_opy_ (u"࠭ࡓࡄࡖ࡙࠾ࠬਖ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡤࡶࡹࠫਗ")
    if l1l1l_opy_ (u"ࠨࡕࡘࡔ࠿࠭ਘ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡷࡶࡪࡧ࡭ࡴࡷࡳࡶࡪࡳࡥ࠳ࠩਙ")
    if l1l1l_opy_ (u"࡙ࠪࡐ࡚࠺ࠨਚ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡹࡰࡺࡵࡳ࡭ࠪਛ")
    if l1l1l_opy_ (u"ࠬࡒࡉࡎࡋࡗ࠾ࠬਜ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡒࡩ࡮࡫ࡷࡰࡪࡹࡳࡊࡒࡗ࡚ࠬਝ")
    if l1l1l_opy_ (u"ࠧࡇࡃࡅ࠾ࠬਞ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡧࡣࡥ࡬ࡴࡹࡴࡪࡰࡪࠫਟ")
    if l1l1l_opy_ (u"ࠩࡄࡇࡊࡀࠧਠ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡧࡪࡺࡶࠨਡ")
    if l1l1l_opy_ (u"ࠫࡍࡕࡒࡊ࡜࠽ࠫਢ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡭ࡵࡲࡪࡼࡲࡲ࡮ࡶࡴࡷࠩਣ")
    if l1l1l_opy_ (u"࠭ࡒࡐࡑࡗ࠶࠿࠭ਤ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡰࡱࡷࡍࡕ࡚ࡖࠨਥ")
    if l1l1l_opy_ (u"ࠨࡏࡈࡋࡆࡀࠧਦ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡯ࡨ࡫ࡦ࡯ࡰࡵࡸࠪਧ")
    if l1l1l_opy_ (u"࡚ࠪࡉࡘࡔࡗ࠼ࠪਨ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡚ࡆࡊࡅࡓࠩ਩")
    if l1l1l_opy_ (u"ࠬࡎࡄࡕࡘ࠽ࠫਪ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹ࡭ࡢࡴࡷ࡬ࡺࡨࠧਫ")
    if l1l1l_opy_ (u"ࠧࡉࡆࡗ࡚࠷ࡀࠧਬ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥ࠷࠭ਭ")
    if l1l1l_opy_ (u"ࠩࡋࡈ࡙࡜࠳࠻ࠩਮ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧ࠲ࠨਯ")
    if l1l1l_opy_ (u"ࠫࡍࡊࡔࡗ࠶࠽ࠫਰ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡲࠧ਱")
    if l1l1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝࠿࠭ਲ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡢࡣࡥ࡬ࡴࡱࡧࡹࡦࡴࠪਲ਼")
    if l1l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠲࠻ࠩ਴") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡰࡦࡿࡥࡳࡹࡺࡻࠬਵ")
    if l1l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡔ࠽ࠫਸ਼") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽࠧ਷")
    if l1l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡍ࡙࡜࠺ࠨਸ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡴࡷࠩਹ")
    if l1l1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡊ࠺ࠨ਺") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡥࡧࡻࠫ਻")
    if l1l1l_opy_ (u"ࠩࡍࡍࡓ࡞࠲࠻਼ࠩ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡭࡭ࡳࡾࡴࡷ࠴ࠪ਽")
    if l1l1l_opy_ (u"ࠫࡒࡇࡔࡔ࠼ࠪਾ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡒࡧࡴࡴࡄࡸ࡭ࡱࡪࡳࡊࡒࡗ࡚ࠬਿ")
    if l1l1l_opy_ (u"࠭ࡒࡐࡑࡗ࠾ࠬੀ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡰࡱࡷ࡭ࡵࡺࡶࠨੁ")
    if l1l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡒࡃ࠼ࠪੂ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡨࡦࡴࡵࡴࠨ੃")
    if l1l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡅࡏ࡙࠿࠭੄") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡧࡱࡻࡩࡱࡶࡹࠫ੅")
    if l1l1l_opy_ (u"ࠬࡏࡐࡕࡕࠪ੆") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰࡵࡸࡶࡹࡧࡹࠧੇ")
    if l1l1l_opy_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠺ࠨੈ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡭࡫ࡹࡩࡲ࡯ࡸࠨ੉")
    if l1l1l_opy_ (u"ࠩࡈࡒࡉࡀࠧ੊") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡈࡲࡩࡲࡥࡴࡵࠪੋ")
    if l1l1l_opy_ (u"ࠫࡋࡒࡁ࠻ࠩੌ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡋࡲࡡࡸ࡮ࡨࡷࡸ࡚ࡶࠨ੍")
    if l1l1l_opy_ (u"࠭ࡍࡂ࡚ࡌ࠾ࠬ੎") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡭ࡢࡺ࡬ࡻࡪࡨࡴࡷࠩ੏")
    if l1l1l_opy_ (u"ࠨࡈࡏࡅࡘࡀࠧ੐") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡈ࡯ࡥࡼࡲࡥࡴࡵࡗࡺࠬੑ")
    if l1l1l_opy_ (u"ࠪࡗࡕࡘࡍ࠻ࠩ੒") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡗࡺࡶࡲࡦ࡯ࡤࡧࡾ࡚ࡖࠨ੓")
    if l1l1l_opy_ (u"ࠬࡓࡃࡌࡖ࡙࠾ࠬ੔") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡳࡣ࡬ࡶࡹ࠱ࡵࡲࡵࡴࠩ੕")
    if l1l1l_opy_ (u"ࠧࡕ࡙ࡌࡗ࡙ࡀࠧ੖") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡵࡹ࡬ࡷࡹ࡫ࡤࠨ੗")
    if l1l1l_opy_ (u"ࠩࡓࡖࡊ࡙ࡔ࠻ࠩ੘") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡳࡷࡦࡪࡤࡰࡰࠪਖ਼")
    if l1l1l_opy_ (u"ࠫࡇࡒࡋࡊ࠼ࠪਗ਼") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡇࡲࡡࡤ࡭ࡌࡧࡪ࡚ࡖࠨਜ਼")
    if l1l1l_opy_ (u"࠭ࡆࡓࡇࡈ࠾ࠬੜ") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡦࡳࡧࡨࡺ࡮࡫ࡷࠨ੝")
    if l1l1l_opy_ (u"ࠨࡷࡳࡲࡵࡀࠧਫ਼") in streamurl:
        l11l11111_opy_ = l1l1l_opy_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰࡫ࡨ࡭ࡵ࡭ࡦࡴࡸࡲ࠳ࡼࡩࡦࡹࠪ੟")
    return l11l11lll_opy_(l11l11111_opy_, kodiID)
def l11l11lll_opy_(l11l11111_opy_, kodiID):
    l111l1ll1_opy_     = l1l1l_opy_ (u"ࠪࠫ੠")
    l111ll11l_opy_   = l1l1l_opy_ (u"ࠫࠬ੡")
    try:
        l11l1llll_opy_ = xbmcaddon.Addon(l11l11111_opy_).getAddonInfo(l1l1l_opy_ (u"ࠬࡴࡡ࡮ࡧࠪ੢"))
        l111l1ll1_opy_    = dixie.cleanLabel(l11l1llll_opy_)
        l111ll11l_opy_  = xbmcaddon.Addon(l11l11111_opy_).getAddonInfo(l1l1l_opy_ (u"࠭ࡩࡤࡱࡱࠫ੣"))
        if kodiID:
            l111ll111_opy_ = xbmcaddon.Addon(l11l11111_opy_).getAddonInfo(l1l1l_opy_ (u"ࠧࡪࡦࠪ੤"))
            return l111l1ll1_opy_, l111ll111_opy_
        return l111l1ll1_opy_, l111ll11l_opy_
    except:
        l111l1ll1_opy_   = l1l1l_opy_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡖࡳࡺࡸࡣࡦࠩ੥")
        l111ll11l_opy_ =  dixie.ICON
        return l111l1ll1_opy_, l111ll11l_opy_
    return l111l1ll1_opy_, l111ll11l_opy_
def selectStream(url, channel):
    l111l1l1l_opy_ = url.split(l1l1l_opy_ (u"ࠩࡿࠫ੦"))
    if len(l111l1l1l_opy_) == 0:
        return None
    options, l1l1l111_opy_ = getOptions(l111l1l1l_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l111l1l1l_opy_) == 1:
            return l1l1l111_opy_[0]
    import selectDialog
    l11l111ll_opy_ = selectDialog.select(l1l1l_opy_ (u"ࠪࡗࡪࡲࡥࡤࡶࠣࡥࠥࡹࡴࡳࡧࡤࡱࠬ੧"), options)
    if l11l111ll_opy_ < 0:
        raise Exception(l1l1l_opy_ (u"ࠫࡘ࡫࡬ࡦࡥࡷ࡭ࡴࡴࠠࡄࡣࡱࡧࡪࡲࠧ੨"))
    return l1l1l111_opy_[l11l111ll_opy_]
def getOptions(l111l1l1l_opy_, channel, addmore=True):
    options = []
    l1l1l111_opy_    = []
    for index, stream in enumerate(l111l1l1l_opy_):
        l111l1ll1_opy_ = getPluginInfo(stream)
        l1llll1_opy_ = l1l1l_opy_ (u"ࠬ࠭੩")
        l111lll1l_opy_  = l111l1ll1_opy_[1]
        if stream.startswith(OPEN_OTT):
            l11l11ll1_opy_ = stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l1l1l_opy_ (u"࠭ࠧ੪"))
            l1llll1_opy_  = l1llll1_opy_ + l11l11ll1_opy_
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l1l1l_opy_ (u"ࠧࠨ੫"))
        else:
            l1llll1_opy_  = l1llll1_opy_ + channel
        options.append([l1llll1_opy_, index, l111lll1l_opy_])
        l1l1l111_opy_.append(stream)
    if addmore:
        options.append([l1l1l_opy_ (u"ࠨࡃࡧࡨࠥࡳ࡯ࡳࡧ࠱࠲࠳࠭੬"), index + 1, dixie.ICON])
        l1l1l111_opy_.append(l1l1l_opy_ (u"ࠩࡤࡨࡩࡓ࡯ࡳࡧࠪ੭"))
    return options, l1l1l111_opy_
if __name__ == l1l1l_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬ੮"):
    checkAddons()