# coding: UTF-8
import sys
l1l1l11l_opy_ = sys.version_info [0] == 2
l111l1l_opy_ = 2048
l1l1l1ll_opy_ = 7
def l1l1l_opy_ (l1l111_opy_):
	global l111lll_opy_
	l1llllll_opy_ = ord (l1l111_opy_ [-1])
	l1l1ll11_opy_ = l1l111_opy_ [:-1]
	l1l1111_opy_ = l1llllll_opy_ % len (l1l1ll11_opy_)
	l11l11_opy_ = l1l1ll11_opy_ [:l1l1111_opy_] + l1l1ll11_opy_ [l1l1111_opy_:]
	if l1l1l11l_opy_:
		l1111_opy_ = unicode () .join ([unichr (ord (char) - l111l1l_opy_ - (l1lll_opy_ + l1llllll_opy_) % l1l1l1ll_opy_) for l1lll_opy_, char in enumerate (l11l11_opy_)])
	else:
		l1111_opy_ = str () .join ([chr (ord (char) - l111l1l_opy_ - (l1lll_opy_ + l1llllll_opy_) % l1l1l1ll_opy_) for l1lll_opy_, char in enumerate (l11l11_opy_)])
	return eval (l1111_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
import mapping
ADDON    = dixie.ADDON
l1ll1111_opy_ = dixie.PROFILE
l1111l1_opy_  = os.path.join(l1ll1111_opy_, l1l1l_opy_ (u"ࠫ࡮ࡴࡩࠨࠀ"))
l1lllll_opy_    = os.path.join(l1111l1_opy_, l1l1l_opy_ (u"ࠬࡳࡡࡱࡲ࡬ࡲ࡬ࡹ࠮࡫ࡵࡲࡲࠬࠁ"))
l111ll_opy_   = os.path.join(l1111l1_opy_, l1l1l_opy_ (u"࠭࡭ࡢࡲࡶ࠲࡯ࡹ࡯࡯ࠩࠂ"))
LABELFILE  = os.path.join(l1111l1_opy_, l1l1l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱࡹ࠮࡫ࡵࡲࡲࠬࠃ"))
l11llll1_opy_ = os.path.join(l1111l1_opy_, l1l1l_opy_ (u"ࠨࡲࡵࡩ࡫࡯ࡸࡦࡵ࠱࡮ࡸࡵ࡮ࠨࠄ"))
l1ll11ll_opy_  = json.load(open(l1lllll_opy_))
l1l1ll1l_opy_      = json.load(open(l111ll_opy_))
labelmaps = json.load(open(LABELFILE))
l111_opy_  = json.load(open(l11llll1_opy_))
l1l1ll1_opy_ = l1l1l_opy_ (u"ࠩࠪࠅ")
def l1l11l_opy_(i, t1, l1l1l1_opy_=[]):
 t = l1l1ll1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l1l1_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11_opy_ = l1l11l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11lll_opy_ = l1l11l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l1l1lll_opy_       = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡧࡪࡺࡶࠨࠆ")
l1l11ll1_opy_  = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡆࡱࡧࡣ࡬ࡋࡦࡩ࡙࡜ࠧࠇ")
dexter    = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸࠨࠈ")
l1ll1l_opy_   = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡋ࡮ࡥ࡮ࡨࡷࡸ࠭ࠉ")
l1lll1_opy_       = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡦࡢࡤ࡫ࡳࡸࡺࡩ࡯ࡩࠪࠊ")
l1ll11l1_opy_  = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡇ࡮ࡤࡻࡱ࡫ࡳࡴࡖࡹࠫࠋ")
l1l111ll_opy_  = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡨࡵࡩࡪࡼࡩࡦࡹࠪࠌ")
l1ll11_opy_    = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡪࡩ࡭ࡵࡳࡵ࡫ࡱ࡫ࠬࠍ")
l1l111l_opy_   = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡬ࡴࡸࡩࡻࡱࡱ࡭ࡵࡺࡶࠨࠎ")
l1ll1_opy_  = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶࡴࡷࡵࡸࡦࡸ࠭ࠏ")
l11l11l_opy_      = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡰࡩ࡯ࡺࡷࡺ࠷࠭ࠐ")
l1l11l1l_opy_ = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡌࡪ࡯࡬ࡸࡱ࡫ࡳࡴࡋࡓࡘ࡛࠭ࠑ")
l11lll11_opy_    = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡍ࡫ࡰ࡭ࡹࡲࡥࡴࡵ࡙࠶ࠬࠒ")
l11l_opy_  = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡯ࡤࡸࡷ࡯ࡸࡪࡴࡨࡰࡦࡴࡤࠨࠓ")
l1lll11l_opy_  = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡐࡥࡹࡹࡂࡶ࡫࡯ࡨࡸࡏࡐࡕࡘࠪࠔ")
l1l1111l_opy_   = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡱࡦࡾࡩࡸࡧࡥࡸࡻ࠭ࠕ")
l11l1l1_opy_     = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡲࡩ࡫ࡵࡸ࠰ࡴࡱࡻࡳࠨࠖ")
l111111_opy_      = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡳࡥࡨࡣ࡬ࡴࡹࡼࠧࠗ")
l1_opy_     = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡎࡢࡶ࡫ࡳ࠳ࡏࡐࡕࡘࠪ࠘")
nice      = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡯ࡣࡷ࡬ࡴࡹࡵࡣࡵ࡬ࡧࡪ࠭࠙")
l11ll_opy_   = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡲࡵࡩࡲ࡯ࡵ࡮࡫ࡳࡸࡻ࠭ࠚ")
l1l111l1_opy_  = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡳࡷࡦࡪࡤࡰࡰࠪࠛ")
root      = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡴࡵࡴࡊࡒࡗ࡚ࠬࠜ")
l1ll1l1l_opy_     = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡬࡯ࡺ࡮ࡱࡷࡺࠬࠝ")
l1l1l1l_opy_    = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡭ࡩࡻ࡯ࡲࡷࡵࡵࡲࡵࡵࠪࠞ")
l1lll1l_opy_      = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡤࡶࡹࠫࠟ")
l11111l_opy_ = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡔࡷࡳࡶࡪࡳࡡࡤࡻࡗ࡚ࠬࠠ")
l1lll1l1_opy_   = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡷࡶࡪࡧ࡭ࡴࡷࡳࡶࡪࡳࡥ࠳ࠩࠡ")
l11l1ll_opy_   = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡷࡻ࡮ࡹࡴࡦࡦࡷࡺࠬࠢ")
l11ll11_opy_   = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡸࡻࡱࡩ࡯ࡩࡶࠫࠣ")
l11lll1_opy_    = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡶࡴ࡮ࠫࠤ")
l1l_opy_     = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡜ࡁࡅࡇࡕࠫࠥ")
l1llll1l_opy_     = l1l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡖࡊࡒࡖࡹࡵ࡫ࡲࡔࡶࡵࡩࡦࡳࡳࡕࡘࠪࠦ")
l1ll1ll1_opy_   = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡹࡶࡵࡩࡦࡳ࠭ࡤࡱࡧࡩࡸ࠭ࠧ")
l1llll11_opy_    = [l1llll1l_opy_, l11lll11_opy_, l1_opy_, nice, l11ll_opy_, l1ll1l1l_opy_, l1l1l1l_opy_, l1ll11_opy_, l11ll11_opy_, l11l_opy_, l1ll1ll1_opy_, l1lll1l_opy_, l1lll1l1_opy_, l11lll1_opy_, l1l11l1l_opy_, l1lll1_opy_, l1l1lll_opy_, l1l111l_opy_, root, l111111_opy_, l1l111ll_opy_, l1ll1_opy_, l11l11l_opy_, l1ll1l_opy_, l1ll11l1_opy_, l1l1111l_opy_, dexter,l1l_opy_, l11111l_opy_, l11l1l1_opy_, l11l1ll_opy_, l1l111l1_opy_, l1l11ll1_opy_]
def checkAddons():
    for addon in l1llll11_opy_:
        if l1l1l1l1_opy_(addon):
            try: createINI(addon)
            except: continue
def l1l1l1l1_opy_(addon):
    if xbmc.getCondVisibility(l1l1l_opy_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡋࡥࡸࡇࡤࡥࡱࡱࠬࠪࡹࠩࠨࠨ") % addon) == 1:
        dixie.log(l1l1l_opy_ (u"ࠪࡁࡂࡃ࠽ࠡࡣࡧࡨࡴࡴࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡁࡂࡃ࠽ࠨࠩ"))
        dixie.log(addon)
        return True
    return False
def createINI(addon):
    l11lll1l_opy_  = str(addon).split(l1l1l_opy_ (u"ࠫ࠳࠭ࠪ"))[2] + l1l1l_opy_ (u"ࠬ࠴ࡩ࡯࡫ࠪࠫ")
    l1l11l1_opy_   = os.path.join(l1111l1_opy_, l11lll1l_opy_)
    response = l1lll1ll_opy_(addon)
    l11llll_opy_ = response[l1l1l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࠬ")][l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭࠭")]
    l1l1ll_opy_  = l1l1l_opy_ (u"ࠨ࡝ࠪ࠮") + addon + l1l1l_opy_ (u"ࠩࡠࡠࡳ࠭࠯")
    l1ll1lll_opy_  =  file(l1l11l1_opy_, l1l1l_opy_ (u"ࠪࡻࠬ࠰"))
    l1ll1lll_opy_.write(l1l1ll_opy_)
    l1l11lll_opy_ = []
    for channel in l11llll_opy_:
        l11111_opy_ = l1l1l11_opy_(addon)
        l11ll1_opy_  = channel[l1l1l_opy_ (u"ࠫࡱࡧࡢࡦ࡮ࠪ࠱")].split(l1l1l_opy_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࠲"), 1)[0]
        if addon == dexter:
            l11ll1_opy_ = l11ll1_opy_.split(l1l1l_opy_ (u"࠭ࠠࠬࠢࠪ࠳"), 1)[0]
        if (addon == l1llll1l_opy_) or (addon == l11l1ll_opy_) or (addon == l11lll11_opy_) or (addon == l1_opy_) or (addon == nice) or (addon == l1ll1l1l_opy_) or (addon == l1l1l1l_opy_) or (addon == root) or (addon == l1l11l1l_opy_) or (addon == l11ll11_opy_) or (addon == l1ll11_opy_):
            l11ll1_opy_ = l11ll1_opy_.split(l1l1l_opy_ (u"ࠧࠡ࠯ࠣࠫ࠴"), 1)[0]
        l1llll_opy_ = l111l_opy_(addon, l11ll1_opy_)
        l11l1l_opy_ = l1lllll1_opy_(addon, l111_opy_, labelmaps, l1ll11ll_opy_, l1l1ll1l_opy_, l11ll1_opy_)
        stream  = l11111_opy_ + l1llll_opy_
        l111l1_opy_ = l11l1l_opy_  + l1l1l_opy_ (u"ࠨ࠿ࠪ࠵") + stream
        if l111l1_opy_ not in l1l11lll_opy_:
            l1l11lll_opy_.append(l111l1_opy_)
    l1l11lll_opy_.sort()
    for item in l1l11lll_opy_:
        l1ll1lll_opy_.write(l1l1l_opy_ (u"ࠤࠨࡷࡡࡴࠢ࠶") % item)
    l1ll1lll_opy_.close()
def l111l_opy_(addon, l11ll1_opy_):
    if (addon == l1llll1l_opy_) or (addon == l11l1ll_opy_) or (addon == l11lll11_opy_) or (addon == l1_opy_) or (addon == nice) or (addon == l11ll_opy_) or (addon == l1ll1l1l_opy_) or (addon == l1l1l1l_opy_) or (addon == root) or (addon == l1l11l1l_opy_) or (addon == l1lll1_opy_) or (addon == l1ll1ll1_opy_) or (addon == l11l_opy_) or (addon == l11ll11_opy_) or (addon == l1ll11_opy_):
        l1l11ll_opy_ = mapping.cleanLabel(l11ll1_opy_)
        l1llll_opy_ = mapping.editPrefix(l111_opy_, l1l11ll_opy_)
        return l1llll_opy_
    l1l11ll_opy_ = mapping.cleanLabel(l11ll1_opy_)
    l1llll_opy_ = mapping.cleanStreamLabel(l1l11ll_opy_)
    return l1llll_opy_
def l1lllll1_opy_(addon, l111_opy_, labelmaps, l1ll11ll_opy_, l1l1ll1l_opy_, l11ll1_opy_):
    if (addon == l1llll1l_opy_) or (addon == l11l1ll_opy_) or (addon == l11lll11_opy_) or (addon == l1_opy_) or (addon == nice) or (addon == l11ll_opy_) or (addon == l1ll1l1l_opy_) or (addon == l1l1l1l_opy_) or (addon == root) or (addon == l1l11l1l_opy_) or (addon == l1lll1_opy_) or (addon == l1ll1ll1_opy_) or (addon == l11l_opy_) or (addon == l11ll11_opy_) or (addon == l1ll11_opy_):
        return l1l11l11_opy_(l111_opy_, l1l1ll1l_opy_, l11ll1_opy_)
    l1llll1_opy_    = mapping.cleanLabel(l11ll1_opy_)
    l1l11ll_opy_ = mapping.mapLabel(labelmaps, l1llll1_opy_)
    l11l1l_opy_ = mapping.cleanPrefix(l1l11ll_opy_)
    return mapping.mapChannelName(l1ll11ll_opy_, l11l1l_opy_)
def l1l11l11_opy_(l111_opy_, l1l1ll1l_opy_, l11ll1_opy_):
    l1l1_opy_ = mapping.cleanLabel(l11ll1_opy_)
    l1l11ll_opy_   = mapping.editPrefix(l111_opy_, l1l1_opy_)
    l111ll1_opy_   = mapping.mapEPGLabel(l111_opy_, l1l1ll1l_opy_, l1l11ll_opy_)
    return l111ll1_opy_
def l1ll_opy_(addon, file):
    l1llll1_opy_ = file[l1l1l_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩ࠷")].split(l1l1l_opy_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࠸"), 1)[0]
    l1llll1_opy_ = l1llll1_opy_.split(l1l1l_opy_ (u"ࠬ࠱ࠧ࠹"), 1)[0]
    l1llll1_opy_ = mapping.cleanLabel(l1llll1_opy_)
    return l1llll1_opy_
def l1l1l11_opy_(addon):
    if addon == l1llll1l_opy_:
        return l1l1l_opy_ (u"࠭ࡖࡊࡒࡖࡗ࠿࠭࠺")
    if addon == l11lll11_opy_:
        return l1l1l_opy_ (u"ࠧࡍࡋࡐ࠶࠿࠭࠻")
    if addon == l1_opy_:
        return l1l1l_opy_ (u"ࠨࡐࡄࡘࡍࡀࠧ࠼")
    if addon == nice:
        return l1l1l_opy_ (u"ࠩࡑࡍࡈࡋ࠺ࠨ࠽")
    if addon == l11ll_opy_:
        return l1l1l_opy_ (u"ࠪࡔࡗࡋࡍ࠻ࠩ࠾")
    if addon == l1ll1l1l_opy_:
        return l1l1l_opy_ (u"ࠫࡌࡏ࡚࠻ࠩ࠿")
    if addon == l1l1l1l_opy_:
        return l1l1l_opy_ (u"ࠬࡍࡓࡑࡔࡗࡗ࠿࠭ࡀ")
    if addon == l1ll11_opy_:
        return l1l1l_opy_ (u"࠭ࡇࡆࡊ࠽ࠫࡁ")
    if addon == l11ll11_opy_:
        return l1l1l_opy_ (u"ࠧࡕࡘࡎ࠾ࠬࡂ")
    if addon == l11l_opy_:
        return l1l1l_opy_ (u"ࠨࡏࡗ࡜ࡎࡋ࠺ࠨࡃ")
    if addon == l1ll1ll1_opy_:
        return l1l1l_opy_ (u"࡛ࠩࡘࡈࡀࠧࡄ")
    if addon == l1lll1l_opy_:
        return l1l1l_opy_ (u"ࠪࡗࡈ࡚ࡖ࠻ࠩࡅ")
    if addon == l1lll1l1_opy_:
        return l1l1l_opy_ (u"ࠫࡘ࡛ࡐ࠻ࠩࡆ")
    if addon == l11lll1_opy_:
        return l1l1l_opy_ (u"࡛ࠬࡋࡕ࠼ࠪࡇ")
    if addon == l1l11l1l_opy_:
        return l1l1l_opy_ (u"࠭ࡌࡊࡏࡌࡘ࠿࠭ࡈ")
    if addon == l1lll1_opy_:
        return l1l1l_opy_ (u"ࠧࡇࡃࡅ࠾ࠬࡉ")
    if addon == l1l1lll_opy_:
        return l1l1l_opy_ (u"ࠨࡃࡆࡉ࠿࠭ࡊ")
    if addon == l1l111l_opy_:
        return l1l1l_opy_ (u"ࠩࡋࡓࡗࡏ࡚࠻ࠩࡋ")
    if addon == root:
        return l1l1l_opy_ (u"ࠪࡖࡔࡕࡔ࠳࠼ࠪࡌ")
    if addon == l111111_opy_:
        return l1l1l_opy_ (u"ࠫࡒࡋࡇࡂ࠼ࠪࡍ")
    if addon == l1l111ll_opy_:
        return l1l1l_opy_ (u"ࠬࡌࡒࡆࡇ࠽ࠫࡎ")
    if addon == l1lll11l_opy_:
        return l1l1l_opy_ (u"࠭ࡍࡂࡖࡖ࠾ࠬࡏ")
    if addon == l1ll1_opy_:
        return l1l1l_opy_ (u"ࠧࡊࡒࡗࡗ࠿࠭ࡐ")
    if addon == l11l11l_opy_:
        return l1l1l_opy_ (u"ࠨࡌࡌࡒ࡝࠸࠺ࠨࡑ")
    if addon == l1ll1l_opy_:
        return l1l1l_opy_ (u"ࠩࡈࡒࡉࡀࠧࡒ")
    if addon == l1ll11l1_opy_:
        return l1l1l_opy_ (u"ࠪࡊࡑࡇ࠺ࠨࡓ")
    if addon == l1l1111l_opy_:
        return l1l1l_opy_ (u"ࠫࡒࡇࡘࡊ࠼ࠪࡔ")
    if addon == dexter:
        return l1l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡈ࠿࠭ࡕ")
    if addon == l1l_opy_:
        return l1l1l_opy_ (u"࠭ࡖࡅࡔࡗ࡚࠿࠭ࡖ")
    if addon == l11111l_opy_:
        return l1l1l_opy_ (u"ࠧࡔࡒࡕࡑ࠿࠭ࡗ")
    if addon == l11l1l1_opy_:
        return l1l1l_opy_ (u"ࠨࡏࡆࡏ࡙࡜࠺ࠨࡘ")
    if addon == l11l1ll_opy_:
        return l1l1l_opy_ (u"ࠩࡗ࡛ࡎ࡙ࡔ࠻࡙ࠩ")
    if addon == l1l111l1_opy_:
        return l1l1l_opy_ (u"ࠪࡔࡗࡋࡓࡕ࠼࡚ࠪ")
    if addon == l1l11ll1_opy_:
        return l1l1l_opy_ (u"ࠫࡇࡒࡋࡊ࠼࡛ࠪ")
def getURL(url):
    if url.startswith(l1l1l_opy_ (u"ࠬ࡜ࡉࡑࡕࡖࠫ࡜")):
        return ll_opy_(url, l1llll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡌࡊࡏ࠵ࠫ࡝")):
        return ll_opy_(url, l11lll11_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡏࡃࡗࡌࠬ࡞")):
        return ll_opy_(url, l1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡐࡌࡇࡊ࠭࡟")):
        return ll_opy_(url, nice)
    if url.startswith(l1l1l_opy_ (u"ࠩࡓࡖࡊࡓࠧࡠ")):
        return ll_opy_(url, l11ll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡋࡎࡠࠧࡡ")):
        return ll_opy_(url, l1ll1l1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡌ࡙ࡐࡓࡖࡖࠫࡢ")):
        return ll_opy_(url, l1l1l1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡍࡅࡉࠩࡣ")):
        return ll_opy_(url, l1ll11_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡔࡗࡍࠪࡤ")):
        return ll_opy_(url, l11ll11_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡎࡖ࡛ࡍࡊ࠭ࡥ")):
        return ll_opy_(url, l11l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨ࡚ࡗࡇࠬࡦ")):
        return ll_opy_(url, l1ll1ll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡖࡇ࡙࡜ࠧࡧ")):
        return ll_opy_(url, l1lll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠪࡗ࡚ࡖࠧࡨ")):
        return ll_opy_(url, l1lll1l1_opy_)
    if url.startswith(l1l1l_opy_ (u"࡚ࠫࡑࡔࠨࡩ")):
        return ll_opy_(url, l11lll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡒࡉࡎࡋࡗࠫࡪ")):
        return ll_opy_(url, l1l11l1l_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡆࡂࡄࠪ࡫")):
        return ll_opy_(url, l1lll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡂࡅࡈࠫ࡬")):
        return ll_opy_(url, l1l1lll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡊࡒࡖࡎࡠࠧ࡭")):
        return ll_opy_(url, l1l111l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡕࡓࡔ࡚࠲ࠨ࡮")):
        return ll_opy_(url, root)
    if url.startswith(l1l1l_opy_ (u"ࠪࡑࡊࡍࡁࠨ࡯")):
        return ll_opy_(url, l111111_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡋࡘࡅࡆࠩࡰ")):
        return ll_opy_(url, l1l111ll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡇࡑ࡛࠺ࠨࡱ")):
        url = url.replace(l1l1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡈࡒࡕ࠻ࠩࡲ"), l1l1l_opy_ (u"ࠧࠨࡳ")).replace(l1l1l_opy_ (u"ࠨ࠯࠰ࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧࡴ"), l1l1l_opy_ (u"ࠩࡿࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧࡵ"))
        return url
    if url.startswith(l1l1l_opy_ (u"ࠪࡑࡆ࡚ࡓࠨࡶ")):
        return ll_opy_(url, l1lll11l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡎࡖࡔࡔࠩࡷ")):
        return ll_opy_(url, l1ll1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡐࡉࡏ࡚࠵ࠫࡸ")):
        return ll_opy_(url, l11l11l_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡉ࠭ࡹ")):
        return ll_opy_(url, dexter)
    if url.startswith(l1l1l_opy_ (u"ࠧࡇࡎࡄࠫࡺ")):
        return ll_opy_(url, l1ll11l1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡏࡄ࡜ࡎ࠭ࡻ")):
        return ll_opy_(url, l1l1111l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠩࡈࡒࡉ࠭ࡼ")):
        return ll_opy_(url, l1ll1l_opy_)
    if url.startswith(l1l1l_opy_ (u"࡚ࠪࡉࡘࡔࡗࠩࡽ")):
        return ll_opy_(url, l1l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠫࡘࡖࡒࡎࠩࡾ")):
        return ll_opy_(url, l11111l_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠬࡓࡃࡌࡖ࡙ࠫࡿ")):
        return ll_opy_(url, l11l1l1_opy_)
    if url.startswith(l1l1l_opy_ (u"࠭ࡔࡘࡋࡖࡘࠬࢀ")):
        return ll_opy_(url, l11l1ll_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠧࡑࡔࡈࡗ࡙࠭ࢁ")):
        return ll_opy_(url, l1l111l1_opy_)
    if url.startswith(l1l1l_opy_ (u"ࠨࡄࡏࡏࡎ࠭ࢂ")):
        return ll_opy_(url, l1l11ll1_opy_)
    response  = l11ll1ll_opy_(url)
    l1ll1ll_opy_ = url.split(l1l1l_opy_ (u"ࠩ࠽ࠫࢃ"), 1)[-1]
    l1ll1ll_opy_ = l1ll1ll_opy_.upper().replace(l1l1l_opy_ (u"ࠪࠤࠬࢄ"), l1l1l_opy_ (u"ࠫࠬࢅ"))
    try:
        result = response[l1l1l_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬࢆ")]
        l11l111_opy_  = result[l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬࢇ")]
    except Exception as e:
        l1l11111_opy_(e)
        return None
    for file in l11l111_opy_:
        l11ll1_opy_  = file[l1l1l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭࢈")].split(l1l1l_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢉ"), 1)[0]
        l1ll1l1_opy_  = l11ll1_opy_.split(l1l1l_opy_ (u"ࠩ࠮ࠫࢊ"), 1)[0]
        l1ll11l_opy_ = mapping.cleanLabel(l1ll1l1_opy_)
        l1ll11l_opy_ = l1ll11l_opy_.upper().replace(l1l1l_opy_ (u"ࠪࠤࠬࢋ"), l1l1l_opy_ (u"ࠫࠬࢌ"))
        dixie.log(l1l1l_opy_ (u"ࠬࡃ࠽࠾࠿ࠣࡪ࡮ࡲࡥ࡭ࡣࡥࡩࡱࠦ࠽࠾࠿ࡀࠫࢍ"))
        dixie.log(l1ll11l_opy_)
        try:
            if l1ll1ll_opy_ == l1ll11l_opy_:
                dixie.log(l1l1l_opy_ (u"࠭࠽࠾࠿ࡀࠤࡪࡾࡡࡤࡶࠣࡱࡦࡺࡣࡩࠢࡀࡁࡂࡃࠧࢎ"))
                dixie.log(l1ll11l_opy_)
                return file[l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࠬ࢏")]
        except:
            if (l1ll1ll_opy_ in l1ll11l_opy_) or (l1ll11l_opy_ in l1ll1ll_opy_):
                dixie.log(l1l1l_opy_ (u"ࠨ࠿ࡀࡁࡂࠦࡰࡢࡴࡷ࡭ࡦࡲࠠ࡮ࡣࡷࡧ࡭ࠦ࠽࠾࠿ࡀࠫ࢐"))
                dixie.log(l1ll11l_opy_)
                dixie.log(l1ll1ll_opy_)
                return file[l1l1l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧ࢑")]
    return None
def ll_opy_(url, addon):
    dixie.log(l1l1l_opy_ (u"ࠪࡁࡂࡃ࠽ࠡࡩࡨࡸࡊࡾࡴࡳࡣࡘࡖࡑࠦ࠽࠾࠿ࡀࠫ࢒"))
    dixie.log(url)
    dixie.log(addon)
    PATH = l1lll111_opy_(addon)
    try:
        response = json.load(open(PATH))
    except:
        response = l1lll1ll_opy_(addon)
    l1l1l111_opy_      = url.split(l1l1l_opy_ (u"ࠫ࠿࠭࢓"), 1)[-1]
    stream    = l1l1l111_opy_.split(l1l1l_opy_ (u"࡛ࠬࠦࠨ࢔"), 1)[0]
    l1ll1ll_opy_ = mapping.cleanLabel(stream)
    l1ll1ll_opy_ = l1ll1ll_opy_.upper().replace(l1l1l_opy_ (u"࠭ࠠࠨ࢕"), l1l1l_opy_ (u"ࠧࠨ࢖"))
    dixie.log(l1l1l_opy_ (u"ࠨ࠿ࡀࡁࡂࠦࡳࡵࡴࡨࡥࡲ࡛ࡲ࡭ࠢࡀࡁࡂࡃࠧࢗ"))
    dixie.log(l1ll1ll_opy_)
    l11l111_opy_  = response[l1l1l_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩ࢘")][l1l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࡴ࢙ࠩ")]
    for file in l11l111_opy_:
        l11ll1_opy_  = file[l1l1l_opy_ (u"ࠫࡱࡧࡢࡦ࡮࢚ࠪ")].split(l1l1l_opy_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ࢛ࠧ"), 1)[0]
        if addon == dexter:
            l11ll1_opy_ = l11ll1_opy_.split(l1l1l_opy_ (u"࠭ࠠࠬࠢࠪ࢜"), 1)[0]
        if (addon == l1llll1l_opy_) or (addon == l11l1ll_opy_) or (addon == l11lll11_opy_) or (addon == l1_opy_) or (addon == nice) or (addon == l1ll1l1l_opy_) or (addon == l1l1l1l_opy_) or (addon == root) or (addon == l1l11l1l_opy_) or (addon == l11ll11_opy_) or (addon == l1ll11_opy_):
            l11ll1_opy_ = l11ll1_opy_.split(l1l1l_opy_ (u"ࠧࠡ࠯ࠣࠫ࢝"), 1)[0]
        l1ll11l_opy_ = l111l_opy_(addon, l11ll1_opy_)
        l1ll11l_opy_ = l1ll11l_opy_.upper().replace(l1l1l_opy_ (u"ࠨࠢࠪ࢞"), l1l1l_opy_ (u"ࠩࠪ࢟"))
        dixie.log(l1l1l_opy_ (u"ࠪࡁࡂࡃ࠽ࠡࡨ࡬ࡰࡪࡲࡡࡣࡧ࡯ࠤࡂࡃ࠽࠾ࠩࢠ"))
        dixie.log(l1ll11l_opy_)
        try:
            if l1ll1ll_opy_ == l1ll11l_opy_:
                dixie.log(l1l1l_opy_ (u"ࠫࡂࡃ࠽࠾ࠢࡨࡼࡦࡩࡴࠡ࡯ࡤࡸࡨ࡮ࠠ࠾࠿ࡀࡁࠬࢡ"))
                dixie.log(l1ll1ll_opy_)
                return file[l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪࢢ")]
        except:
            if (l1ll1ll_opy_ in l1ll11l_opy_) or (l1ll11l_opy_ in l1ll1ll_opy_):
                dixie.log(l1l1l_opy_ (u"࠭࠽࠾࠿ࡀࠤࡵࡧࡲࡵ࡫ࡤࡰࠥࡳࡡࡵࡥ࡫ࠤࡂࡃ࠽࠾ࠩࢣ"))
                dixie.log(l1ll11l_opy_)
                dixie.log(l1ll1ll_opy_)
                return file[l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࠬࢤ")]
    return None
def l1lll1ll_opy_(addon):
    PATH  = l1lll111_opy_(addon)
    if addon == l1l_opy_:
        query = l1l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡙ࡅࡉࡋࡒ࠰࡮࡬ࡺࡪࡺࡶ࠰ࡣ࡯ࡰ࠴࠭ࢥ")
    elif addon == l1lll1l1_opy_:
        query = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡹࡸࡥࡢ࡯ࡶࡹࡵࡸࡥ࡮ࡧ࠵࠳ࡱ࡯ࡶࡦࡶࡹ࠳ࡦࡲ࡬࠰ࠩࢦ")
    elif addon == l1lll1l_opy_:
        query = l1l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡩࡴࡷ࠱࡯࡭ࡻ࡫ࡴࡷ࠱ࡤࡰࡱ࠵ࠧࢧ")
    elif addon == l1lll1l1_opy_:
        query = l1l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹࡴࡳࡧࡤࡱࡸࡻࡰࡳࡧࡰࡩ࠷࠵࡬ࡪࡸࡨࡸࡻ࠵ࡡ࡭࡮࠲ࠫࢨ")
    elif addon == l1l111ll_opy_:
        query = l1l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡦࡳࡧࡨࡺ࡮࡫ࡷ࠰ࡁࡸࡶࡱࡃࡵࡳ࡮ࠩࡱࡴࡪࡥ࠾࠷ࠩࡲࡦࡳࡥ࠾ࡎ࡬ࡺࡪ࠱ࡔࡗࠩࢩ")
    elif addon == l11lll1_opy_:
        query = l1l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡶ࡭ࡷࡹࡷࡱ࠯ࡀࡷࡵࡰࡂ࡮ࡴࡵࡲࠨ࠷ࡆࠫ࠲ࡇࠧ࠵ࡊࡦࡪࡤࡰࡰࡦࡰࡴࡻࡤ࠯ࡱࡵ࡫ࠪ࠸ࡆࡶ࡭ࡷࡹࡷࡱࠥ࠳ࡈࡘࡏ࡙ࡻࡲ࡬ࠧ࠵ࡊࡑ࡯ࡶࡦࠧ࠵࠹࠷࠶ࡔࡗ࠰ࡷࡼࡹࠬ࡭ࡰࡦࡨࡁ࠶ࠬ࡮ࡢ࡯ࡨࡁࡑ࡯ࡶࡦ࠭ࡗ࡚ࠫࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࡀࠪ࡫ࡧ࡮ࡢࡴࡷࡁࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠩࢪ")
    else:
        query = l1ll1l11_opy_(addon)
    try:
        return json.load(open(PATH))
    except:
        content = doJSON(query)
        return l1l11_opy_(PATH, addon, content)
def l1l11_opy_(PATH, addon, content):
    json.dump(content, open(PATH,l1l1l_opy_ (u"ࠧࡸࠩࢫ")), indent=3)
    return json.load(open(PATH))
def doJSON(query):
    dixie.log(l1l1l_opy_ (u"ࠨ࠿ࡀࡁࡂࠦࡤࡰࡌࡖࡓࡓࠦࡱࡶࡧࡵࡽࠥࡃ࠽࠾࠿ࠪࢬ"))
    dixie.log(query)
    l1ll111_opy_  = (l1l1l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬࢭ") % query)
    response = xbmc.executeJSONRPC(l1ll111_opy_)
    content  = json.loads(response)
    return content
def l1lll111_opy_(addon):
    if addon == l1llll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡺ࡮ࡶࡳࡴࡶࡨࡱࡵ࠭ࢮ"))
    if addon == l11lll11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡱ࡯࡭࠳ࡶࡨࡱࡵ࠭ࢯ"))
    if addon == l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡴࡡࡵࡪࡲࡸࡪࡳࡰࠨࢰ"))
    if addon == nice:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭࡮ࡪࡥࡨࡸࡪࡳࡰࠨࢱ"))
    if addon == l11ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡱࡴࡨࡱࡹ࡫࡭ࡱࠩࢲ"))
    if addon == l1ll1l1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡩ࡬ࡾࡹ࡫࡭ࡱࠩࢳ"))
    if addon == l1l1l1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡪࡷࡵࡸࡴࡴࡶࡨࡱࡵ࠭ࢴ"))
    if addon == l1ll11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪ࡫ࡪࡺࡥ࡮ࡲࠪࢵ"))
    if addon == l11l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡲࡺࡸࡵࡧࡰࡴࠬࢶ"))
    if addon == l11ll11_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡺࡶ࡬ࡶࡨࡱࡵ࠭ࢷ"))
    if addon == l1ll1ll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡸࡵࡧࡰࡴࠬࢸ"))
    if addon == l1lll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡴࡥࡷࡩࡲࡶࠧࢹ"))
    if addon == l1lll1l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡵࡸࡴࡹ࡫࡭ࡱࠩࢺ"))
    if addon == l11lll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡸ࡯ࡹࡺࡥ࡮ࡲࠪࢻ"))
    if addon == l1l11l1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡰ࡮ࡳࡩࡵࡧࡰࡴࠬࢼ"))
    if addon == l1lll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫ࡫ࡧࡢࡵࡧࡰࡴࠬࢽ"))
    if addon == l1l1lll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡧࡣࡦࡶࡨࡱࡵ࠭ࢾ"))
    if addon == l1l111l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡨࡰࡴࡷࡩࡲࡶࠧࢿ"))
    if addon == root:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡳࡱ࠵ࡸࡪࡳࡰࠨࣀ"))
    if addon == l111111_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨ࡯ࡨ࡫ࡦࡺ࡭ࡱࠩࣁ"))
    if addon == l1lll11l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡰࡥࡹࡹࡴ࡮ࡲࠪࣂ"))
    if addon == l1l111ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡪࡷ࡫ࡥࡵ࡯ࡳࠫࣃ"))
    if addon == l1ll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫ࡮ࡶࡴࡴࡶࡰࡴࠬࣄ"))
    if addon == l11l11l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡰ࠲ࡵࡧࡰࡴࠬࣅ"))
    if addon == l1ll1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡥࡵࡧࡰࡴࠬࣆ"))
    if addon == l1ll11l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡧࡶࡨࡱࡵ࠭ࣇ"))
    if addon == l1l1111l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨ࡯ࡤࡼࡹ࡫࡭ࡱࠩࣈ"))
    if addon == dexter:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠩࡧࡸࡪࡳࡰࠨࣉ"))
    if addon == l1l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠪࡺࡩࡺࡥ࡮ࡲࠪ࣊"))
    if addon == l11111l_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠫࡸࡶࡲࡵࡧࡰࡴࠬ࣋"))
    if addon == l11l1l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠬࡳࡣ࡬ࡶࡨࡱࡵ࠭࣌"))
    if addon == l11l1ll_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"࠭ࡴࡸ࡫ࡷࡩࡲࡶࠧ࣍"))
    if addon == l1l111l1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠧࡱࡴࡨࡷࡹ࡫࡭ࡱࠩ࣎"))
    if addon == l1l11ll1_opy_:
        return os.path.join(dixie.PROFILE, l1l1l_opy_ (u"ࠨࡤ࡯࡯࡮ࡺࡥ࡮ࡲ࣏ࠪ"))
def l1ll1l11_opy_(addon):
    query = l1l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳࣐ࠬ") + addon
    response = doJSON(query)
    l11l111_opy_    = response[l1l1l_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶ࣑ࠪ")][l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࡵ࣒ࠪ")]
    for file in l11l111_opy_:
        l111l11_opy_ = file[l1l1l_opy_ (u"ࠬࡲࡡࡣࡧ࡯࣓ࠫ")]
        l1llll1_opy_ = mapping.cleanLabel(l111l11_opy_)
        l1llll1_opy_ = l1llll1_opy_.upper()
        if (l1llll1_opy_ == l1l1l_opy_ (u"࠭ࡌࡊࡘࡈࠤࡎࡖࡔࡗࠩࣔ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠧࡍࡋ࡙ࡉ࡚ࠥࡖࠨࣕ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠨࡎࡌ࡚ࡊࠦࡃࡉࡃࡑࡒࡊࡒࡓࠨࣖ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠩࡏࡍ࡛ࡋࠧࣗ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠪࡉࡓࡊࡌࡆࡕࡖࠤࡒࡋࡄࡊࡃࠪࣘ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠫࡋࡒࡁࡘࡎࡈࡗࡘ࡚ࡖࠨࣙ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠬࡓࡁ࡙ࡋ࡚ࡉࡇࠦࡔࡗࠩࣚ")) or (l1llll1_opy_ == l1l1l_opy_ (u"࠭ࡂࡍࡃࡆࡏࡎࡉࡅࠡࡖ࡙ࠫࣛ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠧࡉࡑࡕࡍ࡟ࡕࡎࠡࡋࡓࡘ࡛࠭ࣜ")) or (l1llll1_opy_ == l1l1l_opy_ (u"ࠨࡈࡄࡆࠥࡏࡐࡕࡘࠪࣝ"))or (l1llll1_opy_ == l1l1l_opy_ (u"࡙ࠩࡍࡕࠦࡓࡖࡒࡈࡖࡘ࡚ࡒࡆࡃࡐࡗ࡚ࠥࡖࠡ࠯ࠣࡐࡎ࡜ࡅࠡࡕࡗࡖࡊࡇࡍࡔࠩࣞ")):
            livetv = file[l1l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࠨࣟ")]
            return l1111l_opy_(livetv)
def l1111l_opy_(livetv):
    response = doJSON(livetv)
    l11l111_opy_    = response[l1l1l_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫ࣠")][l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫ࣡")]
    for file in l11l111_opy_:
        l111l11_opy_ = file[l1l1l_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬ࣢")]
        l1llll1_opy_ = mapping.cleanLabel(l111l11_opy_)
        l1llll1_opy_ = l1llll1_opy_.upper()
        if l1llll1_opy_ == l1l1l_opy_ (u"ࠧࡂࡎࡏࣣࠫ"):
            return file[l1l1l_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ࣤ")]
def l1lll11_opy_(l11l1_opy_):
    items = []
    _1111ll_opy_(l11l1_opy_, items)
    return items
def _1111ll_opy_(l11l1_opy_, items):
    response = doJSON(l11l1_opy_)
    if response[l1l1l_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩࣥ")].has_key(l1l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࣦࠩ")):
        result = response[l1l1l_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫࣧ")][l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫࣨ")]
        for item in result:
            if item[l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨࣩ")] == l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࠬ࣪"):
                l1llll1_opy_ = mapping.cleanLabel(item[l1l1l_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧ࣫")])
                items.append(item)
            elif item[l1l1l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ࣬")] == l1l1l_opy_ (u"ࠪࡨ࡮ࡸࡥࡤࡶࡲࡶࡾ࣭࠭"):
                l1llll1_opy_ = mapping.cleanLabel(item[l1l1l_opy_ (u"ࠫࡱࡧࡢࡦ࡮࣮ࠪ")])
                l11lllll_opy_  = item[l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧ࣯ࠪ")]
                dixie.log(item)
                dixie.log(l11lllll_opy_)
                _1111ll_opy_(l11lllll_opy_, items)
def l11ll1ll_opy_(url):
    if url.startswith(l1l1l_opy_ (u"࠭ࡉࡑࡎࡄ࡝࠿ࣰ࠭")):
        l1ll111_opy_ = (l1l1l_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡦࡧࡩࡩࡱ࡮ࡤࡽࡪࡸ࠯ࡀࡷࡵࡰࡂࡻࡲ࡭ࠨࡰࡳࡩ࡫࠽࠳ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡹࡩࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴ࠽ࠧࡋࡓࡍࡉࡃࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࣱࠬ"))
    if url.startswith(l1l1l_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠲࠻ࣲࠩ")):
        l1ll111_opy_ = (l1l1l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰ࡭ࡣࡼࡩࡷࡽࡷࡸ࠱ࡂࡹࡷࡲ࠽ࡶࡴ࡯ࠪࡲࡵࡤࡦ࠿࠴࠴࠶ࠬ࡮ࡢ࡯ࡨࡁ࡜ࡧࡴࡤࡪ࠮ࡐ࡮ࡼࡥࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࡀࠪࡸࡻࡢࡵ࡫ࡷࡰࡪࡹ࡟ࡶࡴ࡯ࡁࠫࡲ࡯ࡨࡩࡨࡨࡤ࡯࡮࠾ࡈࡤࡰࡸ࡫ࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬࣳ"))
    if url.startswith(l1l1l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡔ࠽ࠫࣴ")):
        l1ll111_opy_ = (l1l1l_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺ࠳ࡄࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠩࡰࡴ࡭ࡧࡦࡦࡢ࡭ࡳࡃࡆࡢ࡮ࡶࡩࠫࡳ࡯ࡥࡧࡀ࠵࠶࠹ࠦ࡯ࡣࡰࡩࡂࡒࡩࡴࡶࡨࡲࠪ࠸࠰ࡍ࡫ࡹࡩࠫࡹࡵࡣࡶ࡬ࡸࡱ࡫ࡳࡠࡷࡵࡰࠫࡻࡲ࡭࠿ࡸࡶࡱࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࣵ"))
    if url.startswith(l1l1l_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡍ࡙࡜࠺ࠨࣶ")):
        l1ll111_opy_ = (l1l1l_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡸࡻࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࣷ"))
    if url.startswith(l1l1l_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡊ࠺ࠨࣸ")):
        l1ll111_opy_ = (l1l1l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿ࡤࡰࡱࠬࡥࡹࡶࡵࡥࠫࡶࡡࡨࡧࠩࡴࡱࡵࡴࠧࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡁࠫࡺࡩࡵ࡮ࡨࡁࠪ࠻ࡢࡄࡑࡏࡓࡗࠫ࠲࠱ࡹ࡫࡭ࡹ࡫ࠥ࠶ࡦࡄࡰࡱࠫ࠲࠱ࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠨ࠹ࡧࠫ࠲ࡧࡅࡒࡐࡔࡘࠥ࠶ࡦࠩࡹࡷࡲࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࣹࠬ"))
    if url.startswith(l1l1l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡓࡄ࠽ࣺࠫ")):
        l1ll111_opy_ = (l1l1l_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡦࡤࡲࡳࡹ࠵࠿ࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠫ࡬ࡡ࡯ࡣࡵࡸࡂࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࠩࡱࡴࡪࡥ࠾࠹ࠩࡴ࡮ࡲ࡬ࡰࡹࡀࡐ࡮ࡼࡥࠦ࠴࠳ࡗࡹࡸࡥࡢ࡯ࡶࠪࡺࡸ࡬࠾ࡴࡤࡲࡩࡵ࡭ࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ࣻ"))
    try:
        dixie.ShowBusy()
        addon =  l1ll111_opy_.split(l1l1l_opy_ (u"ࠫ࠴࠵ࠧࣼ"), 1)[-1].split(l1l1l_opy_ (u"ࠬ࠵ࠧࣽ"), 1)[0]
        login = l1l1l_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࣾ") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1ll111_opy_)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1l11111_opy_(e)
        return {l1l1l_opy_ (u"ࠧࡆࡴࡵࡳࡷ࠭ࣿ") : l1l1l_opy_ (u"ࠨࡒ࡯ࡹ࡬࡯࡮ࠡࡇࡵࡶࡴࡸࠧऀ")}
def l1l1lll1_opy_():
    modules = map(__import__, [l1l11l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l1l1l_opy_ (u"ࠩࡗࡶࡺ࡫ࠧँ")
    if len(modules[-1].Window(10**4).getProperty(l11lll_opy_)):
        return l1l1l_opy_ (u"ࠪࡘࡷࡻࡥࠨं")
    return l1l1l_opy_ (u"ࠫࡋࡧ࡬ࡴࡧࠪः")
def l1l11111_opy_(e):
    l1l1llll_opy_ = l1l1l_opy_ (u"࡙ࠬ࡯ࡳࡴࡼ࠰ࠥࡧ࡮ࠡࡧࡵࡶࡴࡸࠠࡰࡥࡦࡹࡷ࡫ࡤ࠻ࠢࡍࡗࡔࡔࠠࡆࡴࡵࡳࡷࡀࠠࠦࡵࠪऄ")  %e
    l11ll1l_opy_ = l1l1l_opy_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡲࡦ࠯࡯࡭ࡳࡱࠠࡵࡪ࡬ࡷࠥࡩࡨࡢࡰࡱࡩࡱࠦࡡ࡯ࡦࠣࡸࡷࡿࠠࡢࡩࡤ࡭ࡳ࠴ࠧअ")
    l1ll111l_opy_ = l1l1l_opy_ (u"ࠧࡖࡵࡨ࠾ࠥࡉ࡯࡯ࡶࡨࡼࡹࠦࡍࡦࡰࡸࠤࡂࡄࠠࡓࡧࡰࡳࡻ࡫ࠠࡔࡶࡵࡩࡦࡳࠧआ")
    dixie.log(e)
    dixie.DialogOK(l1l1llll_opy_, l11ll1l_opy_, l1ll111l_opy_)
if __name__ == l1l1l_opy_ (u"ࠨࡡࡢࡱࡦ࡯࡮ࡠࡡࠪइ"):
    checkAddons()