# coding: UTF-8
import sys
l11llll_opy_ = sys.version_info [0] == 2
l1lll1l_opy_ = 2048
l1lll1_opy_ = 7
def l11l11_opy_ (ll_opy_):
	global l1llll1_opy_
	l1l1111_opy_ = ord (ll_opy_ [-1])
	l11111_opy_ = ll_opy_ [:-1]
	l1ll111_opy_ = l1l1111_opy_ % len (l11111_opy_)
	l1l1l_opy_ = l11111_opy_ [:l1ll111_opy_] + l11111_opy_ [l1ll111_opy_:]
	if l11llll_opy_:
		l1ll1l1_opy_ = unicode () .join ([unichr (ord (char) - l1lll1l_opy_ - (l11l1l_opy_ + l1l1111_opy_) % l1lll1_opy_) for l11l1l_opy_, char in enumerate (l1l1l_opy_)])
	else:
		l1ll1l1_opy_ = str () .join ([chr (ord (char) - l1lll1l_opy_ - (l11l1l_opy_ + l1l1111_opy_) % l1lll1_opy_) for l11l1l_opy_, char in enumerate (l1l1l_opy_)])
	return eval (l1ll1l1_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l1l11ll11_opy_    = l11l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡴࡴࡷࠩࢿ")
l1l1ll111_opy_    = l11l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡵ࡬ࡶࡸࡶࡰ࠭ࣀ")
locked = l11l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡭ࡱࡦ࡯ࡪࡪࡴࡷࠩࣁ")
l1l1111l1_opy_   = l11l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡷࡶࡪࡧ࡭ࡵࡸࡥࡳࡽ࠭ࣂ")
l1l11111l_opy_     = l11l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡴࡴࡸࡴࡴ࡯ࡤࡲ࡮ࡧࠧࣃ")
l1l1l11l1_opy_     = l11l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡵࡵࡲࡵࡵࡱࡥࡹ࡯࡯࡯ࡪࡧࡸࡻ࠭ࣄ")
l1l111l1l_opy_     = l11l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡲࡴࡪ࡯ࡤࡸࡪࡳࡡ࡯࡫ࡤࠫࣅ")
l11llllll_opy_   = l11l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲࡩࡶࡺ࠱ࡸࡻ࠭ࣆ")
l1l11l1l1_opy_    = l11l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡄࡄࡕࡳࡳࡷࡺࡳࠨࣇ")
l1l1l1lll_opy_ = l11l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡧࡥࡳࡴࡺࠧࣈ")
l1l1l1l11_opy_    = l11l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡥ࡯ࡹ࡮ࡶࡴࡷࠩࣉ")
l1l11ll1l_opy_ = l11l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡸࡷ࡫ࡡ࡮ࡵࡨࡥࡸࡿ࠮ࡵࡸࠪ࣊")
l1l1111ll_opy_ = l11l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡺࡿࡡࡪࡲࡷࡺࠬ࣋")
l11l11l_opy_ = [l1l11ll11_opy_, locked, l11llllll_opy_, l1l11ll1l_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l11l11_opy_ (u"ࠬ࡯࡮ࡪࠩ࣌"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1l11l1_opy_ = l11l11_opy_ (u"࠭ࠧ࣍")
def l11l111_opy_(i, t1, l1l111l_opy_=[]):
 t = l1l11l1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l111l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1l11_opy_ = l11l111_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11_opy_ = l11l111_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l11l11l_opy_:
        if l11l1ll_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l11l1ll_opy_(addon):
    if xbmc.getCondVisibility(l11l11_opy_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡉࡣࡶࡅࡩࡪ࡯࡯ࠪࠨࡷ࠮࠭࣎") % addon) == 1:
        return True
    return False
def createINI(addon):
    l1lll11_opy_ = str(addon).split(l11l11_opy_ (u"ࠨ࠰࣏ࠪ"))[2] + l11l11_opy_ (u"ࠩ࠱࡭ࡳ࡯࣐ࠧ")
    l1l_opy_  = os.path.join(PATH, l1lll11_opy_)
    try:
        l1l1l1l_opy_ = l1_opy_(addon)
    except KeyError:
        dixie.log(l11l11_opy_ (u"ࠪ࠱࠲࠳࠭࠮ࠢࡎࡩࡾࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡨࡧࡷࡊ࡮ࡲࡥࡴࠢ࠰࠱࠲࠳࣑࠭ࠡࠩ") + addon)
        result = {l11l11_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࡶ࣒ࠫ"): [{l11l11_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ࣓"): l11l11_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࠬࣔ"), l11l11_opy_ (u"ࡵࠨࡶࡼࡴࡪ࠭ࣕ"): l11l11_opy_ (u"ࡶࠩࡸࡲࡰࡴ࡯ࡸࡰࠪࣖ"), l11l11_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࠨࣗ"): l11l11_opy_ (u"ࡸࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾࡸࡹࠩࣘ"), l11l11_opy_ (u"ࡹࠬࡲࡡࡣࡧ࡯ࠫࣙ"): l11l11_opy_ (u"ࡺ࠭ࡎࡐࠢࡆࡌࡆࡔࡎࡆࡎࡖࠫࣚ")}], l11l11_opy_ (u"ࡻࠧ࡭࡫ࡰ࡭ࡹࡹࠧࣛ"):{l11l11_opy_ (u"ࡵࠨࡵࡷࡥࡷࡺࠧࣜ"): 0, l11l11_opy_ (u"ࡶࠩࡷࡳࡹࡧ࡬ࠨࣝ"): 1, l11l11_opy_ (u"ࡷࠪࡩࡳࡪࠧࣞ"): 1}}
    l1l1l11_opy_  = file(l1l_opy_, l11l11_opy_ (u"ࠪࡻࠬࣟ"))
    l1l1l11_opy_.write(l11l11_opy_ (u"ࠫࡠ࠭࣠"))
    l1l1l11_opy_.write(addon)
    l1l1l11_opy_.write(l11l11_opy_ (u"ࠬࡣࠧ࣡"))
    l1l1l11_opy_.write(l11l11_opy_ (u"࠭࡜࡯ࠩ࣢"))
    l1l1ll_opy_ = []
    for channel in l1l1l1l_opy_:
        l11ll1_opy_    = channel[l11l11_opy_ (u"ࠧ࡭ࡣࡥࡩࡱࣣ࠭")].replace(l11l11_opy_ (u"ࠨ࡝ࡅࡡࡠࡉࡏࡍࡑࡕࠤࡼ࡮ࡩࡵࡧࡠࠫࣤ"), l11l11_opy_ (u"ࠩࠪࣥ")).replace(l11l11_opy_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࡠ࠵ࡂ࡞ࣦࠩ"), l11l11_opy_ (u"ࠫࠬࣧ")).replace(l11l11_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࡭ࡲࡦࡧࡱࡡࡍࡊ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨࣨ"), l11l11_opy_ (u"࠭ࡈࡅࡆࣩࠪ"))
        l11ll1_opy_    = l11ll1_opy_.replace(l11l11_opy_ (u"ࠧࡽࠩ࣪"), l11l11_opy_ (u"ࠨࠩ࣫")).replace(l11l11_opy_ (u"ࠩ࠲ࠫ࣬"), l11l11_opy_ (u"࣭ࠪࠫ")).replace(l11l11_opy_ (u"࣮ࠫࠥࠦࠠࠡࠢࠪ"), l11l11_opy_ (u"࣯ࠬࠦࠧ")).replace(l11l11_opy_ (u"࠭࠮࠯࠰࠱࠲ࣰࠬ"), l11l11_opy_ (u"ࠧࠨࣱ")).replace(l11l11_opy_ (u"ࠨ࠼ࣲࠪ"), l11l11_opy_ (u"ࠩࠪࣳ"))
        l11ll1_opy_    = l11ll1_opy_.replace(l11l11_opy_ (u"ࠪࡡࠥ࠭ࣴ"), l11l11_opy_ (u"ࠫࡢ࠭ࣵ")).replace(l11l11_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡧࡱࡶࡣࡠࣶࠫ"), l11l11_opy_ (u"࠭ࠧࣷ")).replace(l11l11_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡸࡪ࡬ࡸࡪࡣࠧࣸ"), l11l11_opy_ (u"ࠨࣹࠩ")).replace(l11l11_opy_ (u"ࠩࠣ࡟ࣺࠬ"), l11l11_opy_ (u"ࠪ࡟ࠬࣻ"))
        l11ll1_opy_    = l11ll1_opy_.replace(l11l11_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡱ࡯࡭ࡦࡩࡵࡩࡪࡴ࡝ࠨࣼ"), l11l11_opy_ (u"ࠬ࠭ࣽ")).replace(l11l11_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡹࡦ࡮࡯ࡳࡼࡣࠧࣾ"), l11l11_opy_ (u"ࠧࠨࣿ"))
        l11ll1_opy_    = l11ll1_opy_.replace(l11l11_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣࠧऀ"), l11l11_opy_ (u"ࠩࠪँ")).replace(l11l11_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡳࡷࡧ࡮ࡨࡧࡠࠫं"), l11l11_opy_ (u"ࠫࠬः")).replace(l11l11_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡸࡥࡥ࡟ࠪऄ"), l11l11_opy_ (u"࠭ࠧअ"))
        l11ll1_opy_    = l11ll1_opy_.replace(l11l11_opy_ (u"ࠧ࡜ࡋࡠࠫआ"), l11l11_opy_ (u"ࠨࠩइ")).replace(l11l11_opy_ (u"ࠩ࡞࠳ࡎࡣࠧई"), l11l11_opy_ (u"ࠪࠫउ")).replace(l11l11_opy_ (u"ࠫࡠࡈ࡝ࠨऊ"), l11l11_opy_ (u"ࠬ࠭ऋ")).replace(l11l11_opy_ (u"࡛࠭࠰ࡄࡠࠫऌ"), l11l11_opy_ (u"ࠧࠨऍ"))
        l1ll1_opy_ = dixie.mapChannelName(l11ll1_opy_)
        stream   = channel[l11l11_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ऎ")]
        l11l1_opy_ = l1ll1_opy_ + l11l11_opy_ (u"ࠩࡀࠫए") + stream
        l1l1ll_opy_.append(l11l1_opy_)
        l1l1ll_opy_.sort()
    for item in l1l1ll_opy_:
        l1l1l11_opy_.write(l11l11_opy_ (u"ࠥࠩࡸࡢ࡮ࠣऐ") % item)
    l1l1l11_opy_.close()
def l1_opy_(addon):
    if (addon == l11llllll_opy_) or (addon == locked):
        return l1l1l111l_opy_(addon)
    l1l11l111_opy_  = l11l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧऑ") + addon
    l1l1l1l1l_opy_ =  l1l1lll11_opy_(addon)
    query   =  l1l11l111_opy_ + l1l1l1l1l_opy_
    return sendJSON(query, addon)
def l1l1l111l_opy_(addon):
    if addon == l11llllll_opy_:
        l1l1l11ll_opy_ = [l11l11_opy_ (u"ࠬ࠻ࠧऒ"), l11l11_opy_ (u"࠭࠱࠱࠸ࠪओ"), l11l11_opy_ (u"ࠧ࠵ࠩऔ"), l11l11_opy_ (u"ࠨ࠴࠹࠷ࠬक"), l11l11_opy_ (u"ࠩ࠴࠷࠷࠭ख")]
    if addon == locked:
        l1l1l11ll_opy_ = [l11l11_opy_ (u"ࠪ࠷࠵࠭ग"), l11l11_opy_ (u"ࠫ࠸࠷ࠧघ"), l11l11_opy_ (u"ࠬ࠹࠲ࠨङ"), l11l11_opy_ (u"࠭࠳࠴ࠩच"), l11l11_opy_ (u"ࠧ࠴࠶ࠪछ"), l11l11_opy_ (u"ࠨ࠵࠸ࠫज"), l11l11_opy_ (u"ࠩ࠶࠼ࠬझ"), l11l11_opy_ (u"ࠪ࠸࠵࠭ञ"), l11l11_opy_ (u"ࠫ࠹࠷ࠧट"), l11l11_opy_ (u"ࠬ࠺࠵ࠨठ"), l11l11_opy_ (u"࠭࠴࠸ࠩड"), l11l11_opy_ (u"ࠧ࠵࠻ࠪढ"), l11l11_opy_ (u"ࠨ࠷࠵ࠫण")]
    login = l11l11_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴ࠱ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨत") % addon
    xbmc.executeJSONRPC(login)
    l1lllll_opy_ = []
    for l1l1ll11l_opy_ in l1l1l11ll_opy_:
        if addon == l11llllll_opy_:
            l1l1l1ll1_opy_ = l11l11_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡬ࡪࡷࡻ࠲ࡹࡼ࠯ࡀ࡯ࡲࡨࡪࡥࡩࡥ࠿ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪࡲࡵࡤࡦ࠿ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪࡸ࡫ࡣࡵ࡫ࡲࡲࡤ࡯ࡤ࠾ࠧࡶࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩथ") % l1l1ll11l_opy_
        if addon == locked:
            l1l1l1ll1_opy_ = l11l11_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡭ࡱࡦ࡯ࡪࡪࡴࡷ࠱ࡂࡹࡷࡲ࠽ࠦࡵࠩࡱࡴࡪࡥ࠾࠶ࠩࡲࡦࡳࡥ࠾ࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࠬࡰ࡭ࡣࡼࡁࠫࡪࡡࡵࡧࡀࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠩࡴࡦ࡭ࡥ࠾ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧद") % l1l1ll11l_opy_
        l1l11lll1_opy_  = xbmc.executeJSONRPC(l1l1l1ll1_opy_)
        response = json.loads(l1l11lll1_opy_)
        l1lllll_opy_.extend(response[l11l11_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬध")][l11l11_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬन")])
    return l1lllll_opy_
def sendJSON(query, addon):
    l1l1l1ll1_opy_     = l11l11_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪऩ") % query
    l1l11lll1_opy_  = xbmc.executeJSONRPC(l1l1l1ll1_opy_)
    response = json.loads(l1l11lll1_opy_)
    result   = response[l11l11_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨप")]
    return result[l11l11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨफ")]
def l1l11l1ll_opy_(addon):
    l1l11l111_opy_ = l11l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭ब") + addon
    l11lllll1_opy_  = l11l11_opy_ (u"ࠫࡄࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠩ࡭ࡨࡵ࡮ࡪ࡯ࡤ࡫ࡪࡃࡨࡵࡶࡳࠩ࠸ࡧࠥ࠳ࡨࠨ࠶࡫ࡳࡥࡵࡣ࡯࡯ࡪࡺࡴ࡭ࡧ࠱ࡧࡴࠫ࠲ࡧࡗࡎࡘࡺࡸ࡫࠲࠺࠳࠶࠷࠶࠱࠷ࠧ࠵ࡪࡹ࡮ࡵ࡮ࡤࡶࠩ࠷࡬࡮ࡦࡹࠨ࠶࡫࡛࡫ࠦ࠴࠸࠶࠵ࡺࡵࡳ࡭ࠨ࠶࠺࠸࠰ࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠩ࠷࠻࠲࠱࡮࡬ࡺࡪࠫ࠲࠶࠴࠳ࡸࡻ࠴ࡪࡱࡩࠩࡱࡴࡪࡥ࠾࠳ࠩࡲࡦࡳࡥ࠾ࡎ࡬ࡺࡪࠫ࠲࠱ࡖ࡙ࠪࡺࡸ࡬࠾ࡪࡷࡸࡵࠫ࠳ࡢࠧ࠵ࡪࠪ࠸ࡦ࡮ࡧࡷࡥࡱࡱࡥࡵࡶ࡯ࡩ࠳ࡩ࡯ࠦ࠴ࡩ࡙ࡐ࡚ࡵࡳ࡭࠴࠼࠵࠸࠲࠱࠳࠹ࠩ࠷࡬ࡌࡪࡸࡨࠩ࠷࠻࠲࠱ࡖ࡙࠲ࡹࡾࡴࠨभ")
    l1lllll_opy_  = []
    l1lllll_opy_ += sendJSON(l1l11l111_opy_ + l11lllll1_opy_, addon)
    l1lllll_opy_.sort()
    return l1lllll_opy_
def l1l1ll1ll_opy_(addon):
    l1l11l111_opy_ = l11l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨम") + addon
    l11lllll1_opy_ = l11l11_opy_ (u"࠭࠯ࡀࡨࡤࡲࡦࡸࡴ࠾ࡪࡷࡸࡵࠫ࠳ࡢࠧ࠵ࡪࠪ࠸ࡦࡨࡱࡲ࠲࡬ࡲࠥ࠳ࡨ࡛ࡨࡋ࠸࠸ࡕࠨࡰࡳࡩ࡫࠽࠲ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡹࡩࠪ࠸࠰ࡖࡍࠨ࠶࠵࡙ࡰࡰࡴࡷࡷࠫࡻࡲ࡭࠿࡫ࡸࡹࡶࡳࠦ࠵ࡤࠩ࠷࡬ࠥ࠳ࡨࡪࡳࡴ࠴ࡧ࡭ࠧ࠵ࡪ࠺ࡷࡑࡨࡇ࠷ࠫय")
    l1l111111_opy_ = l11l11_opy_ (u"ࠧ࠰ࡁࡩࡥࡳࡧࡲࡵ࠿࡫ࡸࡹࡶࡳࠦ࠵ࡤࠩ࠷࡬ࠥ࠳ࡨࡪࡳࡴ࠴ࡧ࡭ࠧ࠵ࡪࡋ࡭ࡗࡎ࡭࡝ࠪࡲࡵࡤࡦ࠿࠴ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡻ࡫ࠥ࠳࠲ࡘࡗࠪ࠸ࡦࡄࡃࡑࠩ࠷࠶ࡓࡱࡱࡵࡸࡸࠬࡵࡳ࡮ࡀ࡬ࡹࡺࡰࡴࠧ࠶ࡥࠪ࠸ࡦࠦ࠴ࡩ࡫ࡴࡵ࠮ࡨ࡮ࠨ࠶࡫࡬࠹࡫ࡩ࠻ࡒࠬर")
    l1lllll_opy_  = []
    l1lllll_opy_ += sendJSON(l1l11l111_opy_ + l11lllll1_opy_, addon)
    l1lllll_opy_ += sendJSON(l1l11l111_opy_ + l1l111111_opy_, addon)
    return l1lllll_opy_
def l1l1lll11_opy_(addon):
    if addon == l1l11ll11_opy_:
        return l11l11_opy_ (u"ࠨ࠱ࡂࡧࡦࡺ࠽࠮࠴ࠩࡨࡦࡺࡥࠧࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠬࡥ࡯ࡦࡇࡥࡹ࡫ࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡲࡵࡤࡦ࠿࠵ࠪࡳࡧ࡭ࡦ࠿ࡐࡽࠪ࠸࠰ࡄࡪࡤࡲࡳ࡫࡬ࡴࠨࡵࡩࡨࡵࡲࡥࡰࡤࡱࡪࠬࡳࡵࡣࡵࡸࡉࡧࡴࡦࠨࡸࡶࡱࡃࡵࡳ࡮ࠪऱ")
    if addon == l1l1111ll_opy_:
        return l11l11_opy_ (u"ࠩ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡱ࡯ࡶࡦࡶࡹࡣࡦࡲ࡬ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠦࡵ࡫ࡷࡰࡪࡃࡁ࡭࡮ࠨ࠶࠵ࡩࡨࡢࡰࡱࡩࡱࡹࠦࡶࡴ࡯ࠫल")
    return l11l11_opy_ (u"ࠪࠫळ")
def l1111_opy_():
    modules = map(__import__, [l11l111_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1l11_opy_)):
        return l11l11_opy_ (u"࡙ࠫࡸࡵࡦࠩऴ")
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l11l11_opy_ (u"࡚ࠬࡲࡶࡧࠪव")
    return l11l11_opy_ (u"࠭ࡆࡢ࡮ࡶࡩࠬश")
def l1l1ll1_opy_(e, addon):
    l11lll_opy_ = l11l11_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠲ࠠࡢࡰࠣࡩࡷࡸ࡯ࡳࠢࡲࡧࡨࡻࡲࡦࡦ࠽ࠤࡏ࡙ࡏࡏࠢࡈࡶࡷࡵࡲ࠻ࠢࠨࡷ࠱ࠦࠥࡴࠩष")  % (e, addon)
    l111l_opy_ = l11l11_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡥࡲࡲࡹࡧࡣࡵࠢࡸࡷࠥࡵ࡮ࠡࡶ࡫ࡩࠥ࡬࡯ࡳࡷࡰ࠲ࠬस")
    l1l11l_opy_ = l11l11_opy_ (u"ࠩࡘࡴࡱࡵࡡࡥࠢࡤࠤࡱࡵࡧࠡࡸ࡬ࡥࠥࡺࡨࡦࠢࡤࡨࡩࡵ࡮ࠡࡵࡨࡸࡹ࡯࡮ࡨࡵࠣࡥࡳࡪࠠࡱࡱࡶࡸࠥࡺࡨࡦࠢ࡯࡭ࡳࡱ࠮ࠨह")
    dixie.log(addon)
    dixie.log(e)
def getPlaylist():
    import requests
    l1l11llll_opy_ = [l11l11_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡼ࠳ࡩ࡯࠰ࡊࡈ࡞࠺ࡠࡹࡪࡌࡨ࡛ࠬऺ"), l11l11_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱ࡻࡪ࠺ࡏ࠳ࡉࡑࡧ࡝ࡓ࠭ऻ"), l11l11_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲࡙ࡑࡩ࠰࠲ࡏࡒࡐ࡬ࡉ़ࠧ"), l11l11_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳࡯ࡻࡎࡎࡐࡪࡻ࡯ࡖ࠰ࠨऽ"), l11l11_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡹ࠰ࡦࡳ࠴ࡪࡪࡃࡣ࠴ࡲࡻ࠿ࡇࡻࠩा"), l11l11_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡺ࠱ࡧࡴ࠵࡮ࡗࡵࡴࡧ࡬ࡩࡣ࠺ࡻࠪि"), l11l11_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡻ࠲ࡨࡵ࠯ࡹࡎࡆ࠽࠹ࡋࡖࡒࡸ࡜ࠫी"), l11l11_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡼ࠳ࡩ࡯࠰ࡶࡶࡉ࠸ࡐࡐࡵࡨࡐࡶࠬु"), l11l11_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱ࡨ࡚࡛ࡇࡷࡌࡋࡶࡗ࡭࠭ू"), l11l11_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲ࡼࡖࡶࡆࡋ࡙ࡪ࡭࡬ࡰࠧृ")]
    l1l111lll_opy_ =  l11l11_opy_ (u"࠭ࠣࡆ࡚ࡗࡑ࠸࡛ࠧॄ")
    for url in l1l11llll_opy_:
        try:
            request  = requests.get(url)
            l1l1ll1l1_opy_ = request.text
        except: pass
        if l1l111lll_opy_ in l1l1ll1l1_opy_:
            path = os.path.join(dixie.PROFILE, l11l11_opy_ (u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡰ࠷ࡺ࠭ॅ"))
            with open(path, l11l11_opy_ (u"ࠨࡹࠪॆ")) as f:
                f.write(l1l1ll1l1_opy_)
                break
def getPluginInfo(streamurl):
    if not l1111_opy_() == l11l11_opy_ (u"ࠩࡗࡶࡺ࡫ࠧे"):
        return
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l1l111l11_opy_   = l11l11_opy_ (u"ࠪࡏࡴࡪࡩࠡࡒ࡙ࡖࠬै")
            l1l111ll1_opy_ = os.path.join(dixie.RESOURCES, l11l11_opy_ (u"ࠫࡰࡵࡤࡪ࠯ࡳࡺࡷ࠴ࡰ࡯ࡩࠪॉ"))
            return l1l111l11_opy_, l1l111ll1_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l11l11_opy_ (u"ࠬࡸࡴ࡮ࡲࠪॊ")) or url.startswith(l11l11_opy_ (u"࠭ࡲࡵ࡯ࡳࡩࠬो")) or url.startswith(l11l11_opy_ (u"ࠧࡳࡶࡶࡴࠬौ")) or url.startswith(l11l11_opy_ (u"ࠨࡪࡷࡸࡵ्࠭")):
            l1l111l11_opy_   = l11l11_opy_ (u"ࠩࡰ࠷ࡺࠦࡐ࡭ࡣࡼࡰ࡮ࡹࡴࠨॎ")
            l1l111ll1_opy_ = os.path.join(dixie.RESOURCES, l11l11_opy_ (u"ࠪ࡭ࡵࡺࡶ࠮ࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡴࡳ࡭ࠧॏ"))
            return l1l111l11_opy_, l1l111ll1_opy_
    except:
        pass
    if streamurl.startswith(dixie.OPEN_OTT):
        name = streamurl.split(l11l11_opy_ (u"ࠫࡢࡕࡔࡕࡡࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬॐ"), 1)[-1].split(l11l11_opy_ (u"ࠬ࠵ࠧ॑"), 1)[0]
    if l11l11_opy_ (u"࠭࡝ࡐࡖࡗࡣࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵॒ࠧ") in streamurl:
        name = streamurl.split(l11l11_opy_ (u"ࠧ࡞ࡑࡗࡘࡤࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ॓"), 1)[-1].split(l11l11_opy_ (u"ࠨ࠱ࠪ॔"), 1)[0]
    if streamurl.startswith(l11l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬॕ")):
        name = streamurl.split(l11l11_opy_ (u"ࠪ࠳࠴࠭ॖ"), 1)[-1].split(l11l11_opy_ (u"ࠫ࠴࠭ॗ"), 1)[0]
    if l11l11_opy_ (u"ࠬࡥ࡟ࡔࡈࡢࡣࠬक़") in streamurl:
        name = l11l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡰࡳࡱࡪࡶࡦࡳ࠮ࡴࡷࡳࡩࡷ࠴ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵࠪख़")
    if l11l11_opy_ (u"ࠧࡉࡆࡗ࡚࠿࠭ग़") in streamurl:
        name = l11l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴ࡯ࡤࡶࡹ࡮ࡵࡣࠩज़")
    if l11l11_opy_ (u"ࠩࡋࡈ࡙࡜࠲࠻ࠩड़") in streamurl:
        name = l11l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧࡩࡱࡶࡹࠫढ़")
    if l11l11_opy_ (u"ࠫࡍࡊࡔࡗ࠵࠽ࠫफ़") in streamurl:
        name = l11l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢࡶࡹࠫय़")
    if l11l11_opy_ (u"࠭ࡈࡅࡖ࡙࠸࠿࠭ॠ") in streamurl:
        name = l11l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸ࡭ࠩॡ")
    if l11l11_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠺ࠨॢ") in streamurl:
        name = l11l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡤࡥࡧ࡮ࡶ࡬ࡢࡻࡨࡶࠬॣ")
    if l11l11_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠴࠽ࠫ।") in streamurl:
        name = l11l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽࠧ॥")
    if l11l11_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡖ࠿࠭०") in streamurl:
        name = l11l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰ࡭ࡣࡼࡩࡷࡽࡷࡸࠩ१")
    if l11l11_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡏࡔࡗ࠼ࠪ२") in streamurl:
        name = l11l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡶࡹࠫ३")
    if l11l11_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪ४") in streamurl:
        name = l11l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡧࡩࡽ࠭५")
    if l11l11_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡕࡆ࠿࠭६") in streamurl:
        name = l11l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷ࡫ࡢࡰࡱࡷࠫ७")
    if l11l11_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡈࡒࡕ࠻ࠩ८") in streamurl:
        name = l11l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡣ࡭ࡷ࡬ࡴࡹࡼࠧ९")
    if l11l11_opy_ (u"ࠨࡋࡓࡘࡘ࠭॰") in streamurl:
        name = l11l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࡯ࡰࡵࡸࠪॱ")
    if l11l11_opy_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠽ࠫॲ") in streamurl:
        name = l11l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰ࡮ࡼࡥ࡮࡫ࡻࠫॳ")
    if l11l11_opy_ (u"ࠬࡌࡌࡂ࠼ࠪॴ") in streamurl:
        name = l11l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡌ࡬ࡢࡹ࡯ࡩࡸࡹࡔࡷࠩॵ")
    if l11l11_opy_ (u"ࠧࡇࡎࡄࡗ࠿࠭ॶ") in streamurl:
        name = l11l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡇ࡮ࡤࡻࡱ࡫ࡳࡴࡖࡹࠫॷ")
    if l11l11_opy_ (u"ࠩࡸࡴࡳࡶ࠺ࠨॸ") in streamurl:
        name = l11l11_opy_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱࡬ࡩ࡮࡯࡮ࡧࡵࡹࡳ࠴ࡶࡪࡧࡺࠫॹ")
    try:
        l1l111l11_opy_   = xbmcaddon.Addon(name).getAddonInfo(l11l11_opy_ (u"ࠫࡳࡧ࡭ࡦࠩॺ"))
        l1l111l11_opy_   = l1l111l11_opy_.replace(l11l11_opy_ (u"ࠬࡡࡂ࡞࡝ࡌࡡࡠࡉࡏࡍࡑࡕࠤࡲ࡫ࡤࡪࡷࡰࡷࡱࡧࡴࡦࡤ࡯ࡹࡪࡣࠧॻ"), l11l11_opy_ (u"࠭ࠧॼ")).replace(l11l11_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠ࡭ࡧࡰࡳࡳࡩࡨࡪࡨࡩࡳࡳࡣࠧॽ"), l11l11_opy_ (u"ࠨࠩॾ")).replace(l11l11_opy_ (u"ࠩ࡞࠳ࡎࡣ࡛࠰ࡄࡠ࡟࠴ࡉࡏࡍࡑࡕࡡࠬॿ"), l11l11_opy_ (u"ࠪࠫঀ"))
        l1l111ll1_opy_ = xbmcaddon.Addon(name).getAddonInfo(l11l11_opy_ (u"ࠫ࡮ࡩ࡯࡯ࠩঁ"))
    except:
        l1l111l11_opy_   = l11l11_opy_ (u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡓࡰࡷࡵࡧࡪ࠭ং")
        l1l111ll1_opy_ =  dixie.ICON
    return l1l111l11_opy_, l1l111ll1_opy_
def selectStream(url, channel):
    url = url.replace(l11l11_opy_ (u"࠭ࡼࡶࡵࡨࡶ࠲ࡧࡧࡦࡰࡷࠫঃ"), l11l11_opy_ (u"ࠧ࠮࠯ࡸࡷࡪࡸ࠭ࡢࡩࡨࡲࡹ࠭঄"))
    l11ll11_opy_ = url.split(l11l11_opy_ (u"ࠨࡾࠪঅ"))
    if len(l11ll11_opy_) == 0:
        return None
    options, l11l1l1_opy_ = getOptions(l11ll11_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l11ll11_opy_) == 1:
            return l11l1l1_opy_[0]
    import selectDialog
    l1l1l1111_opy_ = selectDialog.select(l11l11_opy_ (u"ࠩࡖࡩࡱ࡫ࡣࡵࠢࡤࠤࡸࡺࡲࡦࡣࡰࠫআ"), options)
    if l1l1l1111_opy_ < 0:
        raise Exception(l11l11_opy_ (u"ࠪࡗࡪࡲࡥࡤࡶ࡬ࡳࡳࠦࡃࡢࡰࡦࡩࡱ࠭ই"))
    return l11l1l1_opy_[l1l1l1111_opy_]
def getOptions(l11ll11_opy_, channel, addmore=True):
    if not l1111_opy_() == l11l11_opy_ (u"࡙ࠫࡸࡵࡦࠩঈ"):
        return
    options = []
    l11l1l1_opy_    = []
    for index, stream in enumerate(l11ll11_opy_):
        l1l111l11_opy_ = getPluginInfo(stream)
        l11ll1_opy_ = l1l111l11_opy_[0]
        l1l11l11l_opy_  = l1l111l11_opy_[1]
        l11ll1_opy_ = l11l11_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡵࡲࡢࡰࡪࡩࡢࡡࠧউ") + l11ll1_opy_ + l11l11_opy_ (u"࠭࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࠪঊ")
        if stream.startswith(OPEN_OTT):
            l11ll1_opy_  = l11ll1_opy_ + stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l11l11_opy_ (u"ࠧࠨঋ"))
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l11l11_opy_ (u"ࠨࠩঌ"))
        else:
            l11ll1_opy_  = l11ll1_opy_ + channel
        options.append([l11ll1_opy_, index, l1l11l11l_opy_])
        l11l1l1_opy_.append(stream)
    if addmore:
        options.append([l11l11_opy_ (u"ࠩࡄࡨࡩࠦ࡭ࡰࡴࡨ࠲࠳࠴ࠧ঍"), index + 1, dixie.ICON])
        l11l1l1_opy_.append(l11l11_opy_ (u"ࠪࡥࡩࡪࡍࡰࡴࡨࠫ঎"))
    return options, l11l1l1_opy_