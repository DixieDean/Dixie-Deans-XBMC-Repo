# coding: UTF-8
import sys
l11ll111_opy_ = sys.version_info [0] == 2
l1lll1l1_opy_ = 2048
l11lllll_opy_ = 7
def l1l11_opy_ (l11ll1_opy_):
	global l1llll11_opy_
	l1ll1111_opy_ = ord (l11ll1_opy_ [-1])
	l11ll11l_opy_ = l11ll1_opy_ [:-1]
	l11l11l_opy_ = l1ll1111_opy_ % len (l11ll11l_opy_)
	l111l1_opy_ = l11ll11l_opy_ [:l11l11l_opy_] + l11ll11l_opy_ [l11l11l_opy_:]
	if l11ll111_opy_:
		l1lll1_opy_ = unicode () .join ([unichr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	else:
		l1lll1_opy_ = str () .join ([chr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	return eval (l1lll1_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l1ll11ll1_opy_    = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡯ࡶࡹࠫ࡟")
l1lll1lll_opy_    = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡷ࡮ࡸࡺࡸ࡫ࠨࡠ")
locked = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡯ࡳࡨࡱࡥࡥࡶࡹࠫࡡ")
l1111ll1_opy_   = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡹࡸࡥࡢ࡯ࡷࡺࡧࡵࡸࠨࡢ")
l1llll11l_opy_     = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡶ࡯ࡳࡶࡶࡱࡦࡴࡩࡢࠩࡣ")
l11111ll_opy_     = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹࡰࡰࡴࡷࡷࡳࡧࡴࡪࡱࡱ࡬ࡩࡺࡶࠨࡤ")
l1l1ll1ll_opy_     = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡵ࡭ࡶ࡬ࡱࡦࡺࡥ࡮ࡣࡱ࡭ࡦ࠭ࡥ")
l1ll11l1l_opy_   = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡭࡫ࡸࡼ࠳ࡺࡶࠨࡦ")
l1ll111l1_opy_    = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡆࡆࡗࡵࡵࡲࡵࡵࠪࡧ")
l1lll1l1l_opy_ = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡩࡧࡵ࡯ࡵࠩࡨ")
l1ll111ll_opy_    = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡧࡱࡻࡩࡱࡶࡹࠫࡩ")
l1ll11lll_opy_ = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡺࡲࡦࡣࡰࡷࡪࡧࡳࡺ࠰ࡷࡺࠬࡪ")
l1lll1111_opy_ = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡵࡺࡣ࡬ࡴࡹࡼࠧ࡫")
l1l1l1ll1_opy_ = [l1ll11ll1_opy_, locked, l1ll11l1l_opy_, l1ll11lll_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1l11_opy_ (u"ࠧࡪࡰ࡬ࠫ࡬"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1l1l1l11_opy_ = l1l11_opy_ (u"ࠨࠩ࡭")
def l1l1l11ll_opy_(i, t1, l1l1lll11_opy_=[]):
 t = l1l1l1l11_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1l1lll11_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l1111111_opy_ = l1l1l11ll_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l1lllllll_opy_ = l1l1l11ll_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1l1l1ll1_opy_:
        if l1l1ll111_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1l1ll111_opy_(addon):
    if xbmc.getCondVisibility(l1l11_opy_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡋࡥࡸࡇࡤࡥࡱࡱࠬࠪࡹࠩࠨ࡮") % addon) == 1:
        return True
    return False
def createINI(addon):
    l1111l1l_opy_ = str(addon).split(l1l11_opy_ (u"ࠪ࠲ࠬ࡯"))[2] + l1l11_opy_ (u"ࠫ࠳࡯࡮ࡪࠩࡰ")
    l1ll1lll1_opy_  = os.path.join(PATH, l1111l1l_opy_)
    try:
        l111111l_opy_ = l111l111_opy_(addon)
    except KeyError:
        dixie.log(l1l11_opy_ (u"ࠬ࠳࠭࠮࠯࠰ࠤࡐ࡫ࡹࡆࡴࡵࡳࡷࠦࡩ࡯ࠢࡪࡩࡹࡌࡩ࡭ࡧࡶࠤ࠲࠳࠭࠮࠯ࠣࠫࡱ") + addon)
        result = {l1l11_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࡸ࠭ࡲ"): [{l1l11_opy_ (u"ࡵࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪࡳ"): l1l11_opy_ (u"ࡶࠩࡩ࡭ࡱ࡫ࠧࡴ"), l1l11_opy_ (u"ࡷࠪࡸࡾࡶࡥࠨࡵ"): l1l11_opy_ (u"ࡸࠫࡺࡴ࡫࡯ࡱࡺࡲࠬࡶ"), l1l11_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࠪࡷ"): l1l11_opy_ (u"ࡺ࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡹࡺࡻࠫࡸ"), l1l11_opy_ (u"ࡻࠧ࡭ࡣࡥࡩࡱ࠭ࡹ"): l1l11_opy_ (u"ࡵࠨࡐࡒࠤࡈࡎࡁࡏࡐࡈࡐࡘ࠭ࡺ")}], l1l11_opy_ (u"ࡶࠩ࡯࡭ࡲ࡯ࡴࡴࠩࡻ"):{l1l11_opy_ (u"ࡷࠪࡷࡹࡧࡲࡵࠩࡼ"): 0, l1l11_opy_ (u"ࡸࠫࡹࡵࡴࡢ࡮ࠪࡽ"): 1, l1l11_opy_ (u"ࡹࠬ࡫࡮ࡥࠩࡾ"): 1}}
    l1l1lllll_opy_  = file(l1ll1lll1_opy_, l1l11_opy_ (u"ࠬࡽࠧࡿ"))
    l1l1lllll_opy_.write(l1l11_opy_ (u"࡛࠭ࠨࢀ"))
    l1l1lllll_opy_.write(addon)
    l1l1lllll_opy_.write(l1l11_opy_ (u"ࠧ࡞ࠩࢁ"))
    l1l1lllll_opy_.write(l1l11_opy_ (u"ࠨ࡞ࡱࠫࢂ"))
    l1ll1l1l1_opy_ = []
    for channel in l111111l_opy_:
        l1lll11ll_opy_    = channel[l1l11_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨࢃ")].replace(l1l11_opy_ (u"ࠪ࡟ࡇࡣ࡛ࡄࡑࡏࡓࡗࠦࡷࡩ࡫ࡷࡩࡢ࠭ࢄ"), l1l11_opy_ (u"ࠫࠬࢅ")).replace(l1l11_opy_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ࡛࠰ࡄࡠࠫࢆ"), l1l11_opy_ (u"࠭ࠧࢇ")).replace(l1l11_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡨࡴࡨࡩࡳࡣࡈࡅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ࢈"), l1l11_opy_ (u"ࠨࡊࡇࡈࠬࢉ"))
        l1lll11ll_opy_    = l1lll11ll_opy_.replace(l1l11_opy_ (u"ࠩࡿࠫࢊ"), l1l11_opy_ (u"ࠪࠫࢋ")).replace(l1l11_opy_ (u"ࠫ࠴࠭ࢌ"), l1l11_opy_ (u"ࠬ࠭ࢍ")).replace(l1l11_opy_ (u"࠭ࠠࠡࠢࠣࠤࠬࢎ"), l1l11_opy_ (u"ࠧࠡࠩ࢏")).replace(l1l11_opy_ (u"ࠨ࠰࠱࠲࠳࠴ࠧ࢐"), l1l11_opy_ (u"ࠩࠪ࢑")).replace(l1l11_opy_ (u"ࠪ࠾ࠬ࢒"), l1l11_opy_ (u"ࠫࠬ࢓"))
        l1lll11ll_opy_    = l1lll11ll_opy_.replace(l1l11_opy_ (u"ࠬࡣࠠࠨ࢔"), l1l11_opy_ (u"࠭࡝ࠨ࢕")).replace(l1l11_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡢࡳࡸࡥࡢ࠭࢖"), l1l11_opy_ (u"ࠨࠩࢗ")).replace(l1l11_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡺ࡬࡮ࡺࡥ࡞ࠩ࢘"), l1l11_opy_ (u"࢙ࠪࠫ")).replace(l1l11_opy_ (u"ࠫࠥࡡ࢚ࠧ"), l1l11_opy_ (u"ࠬࡡ࢛ࠧ"))
        l1lll11ll_opy_    = l1lll11ll_opy_.replace(l1l11_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡬ࡪ࡯ࡨ࡫ࡷ࡫ࡥ࡯࡟ࠪ࢜"), l1l11_opy_ (u"ࠧࠨ࢝")).replace(l1l11_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡻࡨࡰࡱࡵࡷ࡞ࠩ࢞"), l1l11_opy_ (u"ࠩࠪ࢟"))
        l1lll11ll_opy_    = l1lll11ll_opy_.replace(l1l11_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞ࠩࢠ"), l1l11_opy_ (u"ࠫࠬࢡ")).replace(l1l11_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡵࡲࡢࡰࡪࡩࡢ࠭ࢢ"), l1l11_opy_ (u"࠭ࠧࢣ")).replace(l1l11_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࠬࢤ"), l1l11_opy_ (u"ࠨࠩࢥ"))
        l1lll11ll_opy_    = l1lll11ll_opy_.replace(l1l11_opy_ (u"ࠩ࡞ࡍࡢ࠭ࢦ"), l1l11_opy_ (u"ࠪࠫࢧ")).replace(l1l11_opy_ (u"ࠫࡠ࠵ࡉ࡞ࠩࢨ"), l1l11_opy_ (u"ࠬ࠭ࢩ")).replace(l1l11_opy_ (u"࡛࠭ࡃ࡟ࠪࢪ"), l1l11_opy_ (u"ࠧࠨࢫ")).replace(l1l11_opy_ (u"ࠨ࡝࠲ࡆࡢ࠭ࢬ"), l1l11_opy_ (u"ࠩࠪࢭ"))
        l11111l1_opy_ = dixie.mapChannelName(l1lll11ll_opy_)
        stream   = channel[l1l11_opy_ (u"ࠪࡪ࡮ࡲࡥࠨࢮ")]
        l1llllll1_opy_ = l11111l1_opy_ + l1l11_opy_ (u"ࠫࡂ࠭ࢯ") + stream
        l1ll1l1l1_opy_.append(l1llllll1_opy_)
        l1ll1l1l1_opy_.sort()
    for item in l1ll1l1l1_opy_:
        l1l1lllll_opy_.write(l1l11_opy_ (u"ࠧࠫࡳ࡝ࡰࠥࢰ") % item)
    l1l1lllll_opy_.close()
def l111l111_opy_(addon):
    if (addon == l1ll11l1l_opy_) or (addon == locked):
        return l1ll1ll11_opy_(addon)
    l1l1llll1_opy_  = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩࢱ") + addon
    l1lll111l_opy_ =  l1111lll_opy_(addon)
    query   =  l1l1llll1_opy_ + l1lll111l_opy_
    return sendJSON(query, addon)
def l1ll1ll11_opy_(addon):
    if addon == l1ll11l1l_opy_:
        l1ll1llll_opy_ = [l1l11_opy_ (u"ࠧ࠶ࠩࢲ"), l1l11_opy_ (u"ࠨ࠳࠳࠺ࠬࢳ"), l1l11_opy_ (u"ࠩ࠷ࠫࢴ"), l1l11_opy_ (u"ࠪ࠶࠻࠹ࠧࢵ"), l1l11_opy_ (u"ࠫ࠶࠹࠲ࠨࢶ")]
    if addon == locked:
        l1ll1llll_opy_ = [l1l11_opy_ (u"ࠬ࠹࠰ࠨࢷ"), l1l11_opy_ (u"࠭࠳࠲ࠩࢸ"), l1l11_opy_ (u"ࠧ࠴࠴ࠪࢹ"), l1l11_opy_ (u"ࠨ࠵࠶ࠫࢺ"), l1l11_opy_ (u"ࠩ࠶࠸ࠬࢻ"), l1l11_opy_ (u"ࠪ࠷࠺࠭ࢼ"), l1l11_opy_ (u"ࠫ࠸࠾ࠧࢽ"), l1l11_opy_ (u"ࠬ࠺࠰ࠨࢾ"), l1l11_opy_ (u"࠭࠴࠲ࠩࢿ"), l1l11_opy_ (u"ࠧ࠵࠷ࠪࣀ"), l1l11_opy_ (u"ࠨ࠶࠺ࠫࣁ"), l1l11_opy_ (u"ࠩ࠷࠽ࠬࣂ"), l1l11_opy_ (u"ࠪ࠹࠷࠭ࣃ")]
    login = l1l11_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶ࠳ࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪࣄ") % addon
    xbmc.executeJSONRPC(login)
    l1ll1ll1l_opy_ = []
    for l1llll111_opy_ in l1ll1llll_opy_:
        if addon == l1ll11l1l_opy_:
            l1lll11l1_opy_ = l1l11_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮࡬ࡹࡽ࠴ࡴࡷ࠱ࡂࡱࡴࡪࡥࡠ࡫ࡧࡁࡨ࡮ࡡ࡯ࡰࡨࡰࡸࠬ࡭ࡰࡦࡨࡁࡨ࡮ࡡ࡯ࡰࡨࡰࡸࠬࡳࡦࡥࡷ࡭ࡴࡴ࡟ࡪࡦࡀࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫࣅ") % l1llll111_opy_
        if addon == locked:
            l1lll11l1_opy_ = l1l11_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡯ࡳࡨࡱࡥࡥࡶࡹ࠳ࡄࡻࡲ࡭࠿ࠨࡷࠫࡳ࡯ࡥࡧࡀ࠸ࠫࡴࡡ࡮ࡧࡀࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧࡲ࡯ࡥࡾࡃࠦࡥࡣࡷࡩࡂࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࡁࠫࡶࡡࡨࡧࡀࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩࣆ") % l1llll111_opy_
        l1ll1l111_opy_  = xbmc.executeJSONRPC(l1lll11l1_opy_)
        response = json.loads(l1ll1l111_opy_)
        l1ll1ll1l_opy_.extend(response[l1l11_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧࣇ")][l1l11_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧࣈ")])
    return l1ll1ll1l_opy_
def sendJSON(query, addon):
    l1lll11l1_opy_     = l1l11_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬࣉ") % query
    l1ll1l111_opy_  = xbmc.executeJSONRPC(l1lll11l1_opy_)
    response = json.loads(l1ll1l111_opy_)
    result   = response[l1l11_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪ࣊")]
    return result[l1l11_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪ࣋")]
def l1ll11l11_opy_(addon):
    l1l1llll1_opy_ = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ࣌") + addon
    l1l1l11l1_opy_  = l1l11_opy_ (u"࠭࠿ࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࡪࡷࡸࡵࠫ࠳ࡢࠧ࠵ࡪࠪ࠸ࡦ࡮ࡧࡷࡥࡱࡱࡥࡵࡶ࡯ࡩ࠳ࡩ࡯ࠦ࠴ࡩ࡙ࡐ࡚ࡵࡳ࡭࠴࠼࠵࠸࠲࠱࠳࠹ࠩ࠷࡬ࡴࡩࡷࡰࡦࡸࠫ࠲ࡧࡰࡨࡻࠪ࠸ࡦࡖ࡭ࠨ࠶࠺࠸࠰ࡵࡷࡵ࡯ࠪ࠸࠵࠳࠲ࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸࠫ࠲࠶࠴࠳ࡰ࡮ࡼࡥࠦ࠴࠸࠶࠵ࡺࡶ࠯࡬ࡳ࡫ࠫࡳ࡯ࡥࡧࡀ࠵ࠫࡴࡡ࡮ࡧࡀࡐ࡮ࡼࡥࠦ࠴࠳ࡘ࡛ࠬࡵࡳ࡮ࡀ࡬ࡹࡺࡰࠦ࠵ࡤࠩ࠷࡬ࠥ࠳ࡨࡰࡩࡹࡧ࡬࡬ࡧࡷࡸࡱ࡫࠮ࡤࡱࠨ࠶࡫࡛ࡋࡕࡷࡵ࡯࠶࠾࠰࠳࠴࠳࠵࠻ࠫ࠲ࡧࡎ࡬ࡺࡪࠫ࠲࠶࠴࠳ࡘ࡛࠴ࡴࡹࡶࠪ࣍")
    l1ll1ll1l_opy_  = []
    l1ll1ll1l_opy_ += sendJSON(l1l1llll1_opy_ + l1l1l11l1_opy_, addon)
    l1ll1ll1l_opy_.sort()
    return l1ll1ll1l_opy_
def l1lllll1l_opy_(addon):
    l1l1llll1_opy_ = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ࣎") + addon
    l1l1l11l1_opy_ = l1l11_opy_ (u"ࠨ࠱ࡂࡪࡦࡴࡡࡳࡶࡀ࡬ࡹࡺࡰࠦ࠵ࡤࠩ࠷࡬ࠥ࠳ࡨࡪࡳࡴ࠴ࡧ࡭ࠧ࠵ࡪ࡝ࡪࡆ࠳࠺ࡗࠪࡲࡵࡤࡦ࠿࠴ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡻ࡫ࠥ࠳࠲ࡘࡏࠪ࠸࠰ࡔࡲࡲࡶࡹࡹࠦࡶࡴ࡯ࡁ࡭ࡺࡴࡱࡵࠨ࠷ࡦࠫ࠲ࡧࠧ࠵ࡪ࡬ࡵ࡯࠯ࡩ࡯ࠩ࠷࡬࠵ࡲࡓࡪࡉ࠹࣏࠭")
    l1l1l1l1l_opy_ = l1l11_opy_ (u"ࠩ࠲ࡃ࡫ࡧ࡮ࡢࡴࡷࡁ࡭ࡺࡴࡱࡵࠨ࠷ࡦࠫ࠲ࡧࠧ࠵ࡪ࡬ࡵ࡯࠯ࡩ࡯ࠩ࠷࡬ࡆࡨ࡙ࡐ࡯࡟ࠬ࡭ࡰࡦࡨࡁ࠶ࠬ࡮ࡢ࡯ࡨࡁࡑ࡯ࡶࡦࠧ࠵࠴࡚࡙ࠥ࠳ࡨࡆࡅࡓࠫ࠲࠱ࡕࡳࡳࡷࡺࡳࠧࡷࡵࡰࡂ࡮ࡴࡵࡲࡶࠩ࠸ࡧࠥ࠳ࡨࠨ࠶࡫࡭࡯ࡰ࠰ࡪࡰࠪ࠸ࡦࡧ࠻࡭࡫࠽ࡔ࣐ࠧ")
    l1ll1ll1l_opy_  = []
    l1ll1ll1l_opy_ += sendJSON(l1l1llll1_opy_ + l1l1l11l1_opy_, addon)
    l1ll1ll1l_opy_ += sendJSON(l1l1llll1_opy_ + l1l1l1l1l_opy_, addon)
    return l1ll1ll1l_opy_
def l1111lll_opy_(addon):
    if addon == l1ll11ll1_opy_:
        return l1l11_opy_ (u"ࠪ࠳ࡄࡩࡡࡵ࠿࠰࠶ࠫࡪࡡࡵࡧࠩࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠧࡧࡱࡨࡉࡧࡴࡦࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࠬ࡭ࡰࡦࡨࡁ࠷ࠬ࡮ࡢ࡯ࡨࡁࡒࡿࠥ࠳࠲ࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪࡷ࡫ࡣࡰࡴࡧࡲࡦࡳࡥࠧࡵࡷࡥࡷࡺࡄࡢࡶࡨࠪࡺࡸ࡬࠾ࡷࡵࡰ࣑ࠬ")
    if addon == l1lll1111_opy_:
        return l1l11_opy_ (u"ࠫ࠴ࡅࡡࡤࡶ࡬ࡳࡳࡃ࡬ࡪࡸࡨࡸࡻࡥࡡ࡭࡮ࠩࡩࡽࡺࡲࡢࠨࡳࡥ࡬࡫ࠦࡱ࡮ࡲࡸࠫࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠾ࠨࡷ࡭ࡹࡲࡥ࠾ࡃ࡯ࡰࠪ࠸࠰ࡤࡪࡤࡲࡳ࡫࡬ࡴࠨࡸࡶࡱ࣒࠭")
    return l1l11_opy_ (u"࣓ࠬ࠭")
def l1llll1ll_opy_():
    modules = map(__import__, [l1l1l11ll_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l1111111_opy_)):
        return l1l11_opy_ (u"࠭ࡔࡳࡷࡨࠫࣔ")
    if len(modules[-1].Window(10**4).getProperty(l1lllllll_opy_)):
        return l1l11_opy_ (u"ࠧࡕࡴࡸࡩࠬࣕ")
    return l1l11_opy_ (u"ࠨࡈࡤࡰࡸ࡫ࠧࣖ")
def l1ll1111l_opy_(e, addon):
    l1lll1l11_opy_ = l1l11_opy_ (u"ࠩࡖࡳࡷࡸࡹ࠭ࠢࡤࡲࠥ࡫ࡲࡳࡱࡵࠤࡴࡩࡣࡶࡴࡨࡨ࠿ࠦࡊࡔࡑࡑࠤࡊࡸࡲࡰࡴ࠽ࠤࠪࡹࠬࠡࠧࡶࠫࣗ")  % (e, addon)
    l1lllll11_opy_ = l1l11_opy_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡧࡴࡴࡴࡢࡥࡷࠤࡺࡹࠠࡰࡰࠣࡸ࡭࡫ࠠࡧࡱࡵࡹࡲ࠴ࠧࣘ")
    l1lll1ll1_opy_ = l1l11_opy_ (u"࡚ࠫࡶ࡬ࡰࡣࡧࠤࡦࠦ࡬ࡰࡩࠣࡺ࡮ࡧࠠࡵࡪࡨࠤࡦࡪࡤࡰࡰࠣࡷࡪࡺࡴࡪࡰࡪࡷࠥࡧ࡮ࡥࠢࡳࡳࡸࡺࠠࡵࡪࡨࠤࡱ࡯࡮࡬࠰ࠪࣙ")
    dixie.log(addon)
    dixie.log(e)
def getPlaylist():
    import requests
    l1ll1l11l_opy_ = [l1l11_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲ࡌࡊࡠ࠵࡛ࡻ࡬ࡎࡪ࡝ࠧࣚ"), l1l11_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳ࡽ࡬࠵ࡊ࠵ࡋࡓࡩ࡟ࡎࠨࣛ"), l1l11_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡹ࠰ࡦࡳ࠴࡛ࡌࡤ࠲࠴ࡑࡔࡒࡧࡄࠩࣜ"), l1l11_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡺ࠱ࡧࡴ࠵ࡪࡶࡐࡐࡒ࡬ࡽࡪࡑ࠲ࠪࣝ"), l1l11_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡻ࠲ࡨࡵ࠯ࡥ࡬ࡅࡥ࠶ࡴࡶ࠺ࡉࡽࠫࣞ"), l1l11_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡼ࠳ࡩ࡯࠰ࡰ࡙ࡷࡶࡩࡧࡤࡥ࠼ࡽࠬࣟ"), l1l11_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱ࡻࡐࡈ࠿࠴ࡆࡘࡔࡺ࡞࠭࣠"), l1l11_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲ࡸࡸࡋ࠳ࡋࡒࡷࡪࡒࡸࠧ࣡"), l1l11_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳ࡪ࡜ࡖࡂࡹࡎࡍࡸ࡙ࡨࠨ࣢"), l1l11_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡹ࠰ࡦࡳ࠴ࡾࡑࡱࡈࡍ࡛࡬࡯ࡧ࡫ࣣࠩ")]
    l1l1lll1l_opy_ =  l1l11_opy_ (u"ࠨࠥࡈ࡜࡙ࡓ࠳ࡖࠩࣤ")
    for url in l1ll1l11l_opy_:
        try:
            request  = requests.get(url)
            l1llll1l1_opy_ = request.text
        except: pass
        if l1l1lll1l_opy_ in l1llll1l1_opy_:
            path = os.path.join(dixie.PROFILE, l1l11_opy_ (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡲ࠹ࡵࠨࣥ"))
            with open(path, l1l11_opy_ (u"ࠪࡻࣦࠬ")) as f:
                f.write(l1llll1l1_opy_)
                break
def getPluginInfo(streamurl):
    if not l1llll1ll_opy_() == l1l11_opy_ (u"࡙ࠫࡸࡵࡦࠩࣧ"):
        return
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l1l1ll1l1_opy_   = l1l11_opy_ (u"ࠬࡑ࡯ࡥ࡫ࠣࡔ࡛ࡘࠧࣨ")
            l1111l11_opy_ = os.path.join(dixie.RESOURCES, l1l11_opy_ (u"࠭࡫ࡰࡦ࡬࠱ࡵࡼࡲ࠯ࡲࡱ࡫ࣩࠬ"))
            return l1l1ll1l1_opy_, l1111l11_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l1l11_opy_ (u"ࠧࡳࡶࡰࡴࠬ࣪")) or url.startswith(l1l11_opy_ (u"ࠨࡴࡷࡱࡵ࡫ࠧ࣫")) or url.startswith(l1l11_opy_ (u"ࠩࡵࡸࡸࡶࠧ࣬")) or url.startswith(l1l11_opy_ (u"ࠪ࡬ࡹࡺࡰࠨ࣭")):
            l1l1ll1l1_opy_   = l1l11_opy_ (u"ࠫࡲ࠹ࡵࠡࡒ࡯ࡥࡾࡲࡩࡴࡶ࣮ࠪ")
            l1111l11_opy_ = os.path.join(dixie.RESOURCES, l1l11_opy_ (u"ࠬ࡯ࡰࡵࡸ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡶ࡮ࡨ࣯ࠩ"))
            return l1l1ll1l1_opy_, l1111l11_opy_
    except:
        pass
    if streamurl.startswith(dixie.OPEN_OTT):
        name = streamurl.split(l1l11_opy_ (u"࠭࡝ࡐࡖࡗࡣࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࣰࠧ"), 1)[-1].split(l1l11_opy_ (u"ࠧ࠰ࣱࠩ"), 1)[0]
    if l1l11_opy_ (u"ࠨ࡟ࡒࡘ࡙ࡥࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࣲࠩ") in streamurl:
        name = streamurl.split(l1l11_opy_ (u"ࠩࡠࡓ࡙࡚࡟ࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪࣳ"), 1)[-1].split(l1l11_opy_ (u"ࠪ࠳ࠬࣴ"), 1)[0]
    if streamurl.startswith(l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧࣵ")):
        name = streamurl.split(l1l11_opy_ (u"ࠬ࠵࠯ࠨࣶ"), 1)[-1].split(l1l11_opy_ (u"࠭࠯ࠨࣷ"), 1)[0]
    if l1l11_opy_ (u"ࠧࡠࡡࡖࡊࡤࡥࠧࣸ") in streamurl:
        name = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡲࡵࡳ࡬ࡸࡡ࡮࠰ࡶࡹࡵ࡫ࡲ࠯ࡨࡤࡺࡴࡻࡲࡪࡶࡨࡷࣹࠬ")
    if l1l11_opy_ (u"ࠩࡋࡈ࡙࡜࠺ࠨࣺ") in streamurl:
        name = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡱࡦࡸࡴࡩࡷࡥࠫࣻ")
    if l1l11_opy_ (u"ࠫࡍࡊࡔࡗ࠴࠽ࠫࣼ") in streamurl:
        name = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡷࡻࡹࡢ࡫ࡳࡸࡻ࠭ࣽ")
    if l1l11_opy_ (u"࠭ࡈࡅࡖ࡙࠷࠿࠭ࣾ") in streamurl:
        name = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤࡸࡻ࠭ࣿ")
    if l1l11_opy_ (u"ࠨࡊࡇࡘ࡛࠺࠺ࠨऀ") in streamurl:
        name = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡺ࡯ࠫँ")
    if l1l11_opy_ (u"ࠪࡍࡕࡒࡁ࡚࠼ࠪं") in streamurl:
        name = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡦࡧࡩࡩࡱ࡮ࡤࡽࡪࡸࠧः")
    if l1l11_opy_ (u"ࠬࡏࡐࡍࡃ࡜࠶࠿࠭ऄ") in streamurl:
        name = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡰ࡭ࡣࡼࡩࡷࡽࡷࡸࠩअ")
    if l1l11_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡘ࠺ࠨआ") in streamurl:
        name = l1l11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺࠫइ")
    if l1l11_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡊࡖ࡙࠾ࠬई") in streamurl:
        name = l1l11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡸࡻ࠭उ")
    if l1l11_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡇ࠾ࠬऊ") in streamurl:
        name = l1l11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸࠨऋ")
    if l1l11_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡗࡈ࠺ࠨऌ") in streamurl:
        name = l1l11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡦࡤࡲࡳࡹ࠭ऍ")
    if l1l11_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡃࡍࡗ࠽ࠫऎ") in streamurl:
        name = l1l11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡥ࡯ࡹ࡮ࡶࡴࡷࠩए")
    if l1l11_opy_ (u"ࠪࡍࡕ࡚ࡓࠨऐ") in streamurl:
        name = l1l11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡺࡿࡡࡪࡲࡷࡺࠬऑ")
    if l1l11_opy_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠿࠭ऒ") in streamurl:
        name = l1l11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲࡩࡷࡧࡰ࡭ࡽ࠭ओ")
    if l1l11_opy_ (u"ࠧࡶࡲࡱࡴ࠿࠭औ") in streamurl:
        name = l1l11_opy_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯ࡪࡧ࡬ࡴࡳࡥࡳࡷࡱ࠲ࡻ࡯ࡥࡸࠩक")
    try:
        l1l1ll1l1_opy_   = xbmcaddon.Addon(name).getAddonInfo(l1l11_opy_ (u"ࠩࡱࡥࡲ࡫ࠧख"))
        l1111l11_opy_ = xbmcaddon.Addon(name).getAddonInfo(l1l11_opy_ (u"ࠪ࡭ࡨࡵ࡮ࠨग"))
    except:
        l1l1ll1l1_opy_   = l1l11_opy_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲ࡙ࠥ࡯ࡶࡴࡦࡩࠬघ")
        l1111l11_opy_ =  dixie.ICON
    return l1l1ll1l1_opy_, l1111l11_opy_
def selectStream(url, channel):
    url = url.replace(l1l11_opy_ (u"ࠬࢂࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪङ"), l1l11_opy_ (u"࠭࠭࠮ࡷࡶࡩࡷ࠳ࡡࡨࡧࡱࡸࠬच"))
    l1l1ll11l_opy_ = url.split(l1l11_opy_ (u"ࠧࡽࠩछ"))
    if len(l1l1ll11l_opy_) == 0:
        return None
    options, l1l1l1lll_opy_ = getOptions(l1l1ll11l_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l1l1ll11l_opy_) == 1:
            return l1l1l1lll_opy_[0]
    import selectDialog
    l1ll1l1ll_opy_ = selectDialog.select(l1l11_opy_ (u"ࠨࡕࡨࡰࡪࡩࡴࠡࡣࠣࡷࡹࡸࡥࡢ࡯ࠪज"), options)
    if l1ll1l1ll_opy_ < 0:
        raise Exception(l1l11_opy_ (u"ࠩࡖࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡉࡡ࡯ࡥࡨࡰࠬझ"))
    return l1l1l1lll_opy_[l1ll1l1ll_opy_]
def getOptions(l1l1ll11l_opy_, channel, addmore=True):
    if not l1llll1ll_opy_() == l1l11_opy_ (u"ࠪࡘࡷࡻࡥࠨञ"):
        return
    options = []
    l1l1l1lll_opy_    = []
    for index, stream in enumerate(l1l1ll11l_opy_):
        l1l1ll1l1_opy_ = getPluginInfo(stream)
        l1lll11ll_opy_ = l1l1ll1l1_opy_[0]
        l1ll11111_opy_  = l1l1ll1l1_opy_[1]
        l1lll11ll_opy_  = l1l11_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡴࡸࡡ࡯ࡩࡨࡡࡠ࠭ट") + l1lll11ll_opy_ + l1l11_opy_ (u"ࠬࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠡࠩठ")
        if stream.startswith(OPEN_OTT):
            l1lll11ll_opy_  = l1lll11ll_opy_ + stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l1l11_opy_ (u"࠭ࠧड"))
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l1l11_opy_ (u"ࠧࠨढ"))
        else:
            l1lll11ll_opy_  = l1lll11ll_opy_ + channel
        options.append([l1lll11ll_opy_, index, l1ll11111_opy_])
        l1l1l1lll_opy_.append(stream)
    if addmore:
        options.append([l1l11_opy_ (u"ࠨࡃࡧࡨࠥࡳ࡯ࡳࡧ࠱࠲࠳࠭ण"), index + 1, dixie.ICON])
        l1l1l1lll_opy_.append(l1l11_opy_ (u"ࠩࡤࡨࡩࡓ࡯ࡳࡧࠪत"))
    return options, l1l1l1lll_opy_