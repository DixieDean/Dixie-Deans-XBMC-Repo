# coding: UTF-8
import sys
l1llll11_opy_ = sys.version_info [0] == 2
l1ll11l_opy_ = 2048
l1ll1l_opy_ = 7
def l1111l_opy_ (ll_opy_):
	global l111_opy_
	l1111l1_opy_ = ord (ll_opy_ [-1])
	l1lllll1_opy_ = ll_opy_ [:-1]
	l1ll1_opy_ = l1111l1_opy_ % len (l1lllll1_opy_)
	l11l11l_opy_ = l1lllll1_opy_ [:l1ll1_opy_] + l1lllll1_opy_ [l1ll1_opy_:]
	if l1llll11_opy_:
		l1l1ll1_opy_ = unicode () .join ([unichr (ord (char) - l1ll11l_opy_ - (l11l1l_opy_ + l1111l1_opy_) % l1ll1l_opy_) for l11l1l_opy_, char in enumerate (l11l11l_opy_)])
	else:
		l1l1ll1_opy_ = str () .join ([chr (ord (char) - l1ll11l_opy_ - (l11l1l_opy_ + l1111l1_opy_) % l1ll1l_opy_) for l11l1l_opy_, char in enumerate (l11l11l_opy_)])
	return eval (l1l1ll1_opy_)
import xbmc
import xbmcaddon
import json
import urllib
import os
import dixie
l111lllll_opy_   = l1111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡷ࡮ࡸࡻ࡬ࡲࡢࡰࡦࡩࠬছ")
l11l111l1_opy_   = l1111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡸࡷ࡫ࡡ࡮࠯ࡦࡳࡩ࡫ࡳࠨজ")
l111llll1_opy_ = l1111l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡺࡶࡴࡷࡥࡷࠬঝ")
l11l11l1l_opy_   = l1111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸࠨঞ")
l11l1l11l_opy_   =  [l111lllll_opy_, l11l111l1_opy_, l111llll1_opy_, l11l11l1l_opy_]
def checkAddons():
    for l11l1l1_opy_ in l11l1l11l_opy_:
        if l11ll1111_opy_(l11l1l1_opy_):
            l1l11lll_opy_(l11l1l1_opy_)
def l11ll1111_opy_(l11l1l1_opy_):
    if xbmc.getCondVisibility(l1111l_opy_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡈࡢࡵࡄࡨࡩࡵ࡮ࠩࠧࡶ࠭ࠬট") % l11l1l1_opy_) == 1:
        return True
    else:
        return False
def l1l11lll_opy_(l11l1l1_opy_):
    HOME = dixie.PROFILE
    PATH = os.path.join(HOME, l1111l_opy_ (u"ࠧࡪࡰ࡬ࠫঠ"))
    l1l1l11l_opy_ = l11l11ll1_opy_(l11l1l1_opy_) + l1111l_opy_ (u"ࠨ࠰࡬ࡲ࡮࠭ড")
    l1l11l1l_opy_  = os.path.join(PATH, l1l1l11l_opy_)
    response = l11lll11l_opy_(l11l1l1_opy_)
    result   = response[l1111l_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩঢ")]
    l1lll11l_opy_ = result[l1111l_opy_ (u"ࠪࡪ࡮ࡲࡥࡴࠩণ")]
    l1l1ll1l_opy_  = file(l1l11l1l_opy_, l1111l_opy_ (u"ࠫࡼ࠭ত"))
    l1l1ll1l_opy_.write(l1111l_opy_ (u"ࠬࡡࠧথ"))
    l1l1ll1l_opy_.write(l11l1l1_opy_)
    l1l1ll1l_opy_.write(l1111l_opy_ (u"࠭࡝ࠨদ"))
    l1l1ll1l_opy_.write(l1111l_opy_ (u"ࠧ࡝ࡰࠪধ"))
    l11l111ll_opy_ = []
    for channel in l1lll11l_opy_:
        l111ll1l1_opy_ = channel[l1111l_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧন")]
        if l1111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡦࡨࡼࠬ঩") in channel[l1111l_opy_ (u"ࠪࡪ࡮ࡲࡥࠨপ")]:
            stream = channel[l1111l_opy_ (u"ࠫ࡫࡯࡬ࡦࠩফ")].replace(l1111l_opy_ (u"ࠬ࠴ࡴࡴࠩব"), l1111l_opy_ (u"࠭࠮࡮࠵ࡸ࠼ࠬভ"))
        else:
            stream  = channel[l1111l_opy_ (u"ࠧࡧ࡫࡯ࡩࠬম")]
        l111ll11l_opy_  = l111l1lll_opy_(l11l1l1_opy_, l111ll1l1_opy_)
        channel = l1l1l1l_opy_(l11l1l1_opy_, l111ll11l_opy_)
        l111ll1ll_opy_ = channel + l1111l_opy_ (u"ࠨ࠿ࠪয") + stream
        l11l111ll_opy_.append(l111ll1ll_opy_)
        l11l111ll_opy_.sort()
    for item in l11l111ll_opy_:
      l1l1ll1l_opy_.write(l1111l_opy_ (u"ࠤࠨࡷࡡࡴࠢর") % item)
    l1l1ll1l_opy_.close()
def l11l11ll1_opy_(l11l1l1_opy_):
    if l11l1l1_opy_ == l111lllll_opy_:
        return l1111l_opy_ (u"ࠪࡹࡰࡺࡶࡧࡴࡤࡲࡨ࡫ࠧ঱")
    if l11l1l1_opy_ == l11l111l1_opy_:
        return l1111l_opy_ (u"ࠫࡽࡺࡲࡦࡣࡰ࠱ࡨࡵࡤࡦࡵࠪল")
    if l11l1l1_opy_ == l111llll1_opy_:
        return l1111l_opy_ (u"ࠬ࡯ࡰࡵࡸࡶࡹࡧࡹࠧ঳")
    if l11l1l1_opy_ == l11l11l1l_opy_:
        return l1111l_opy_ (u"࠭ࡤࡦࡺࠪ঴")
def l11lll11l_opy_(l11l1l1_opy_):
    Addon    =  xbmcaddon.Addon(l11l1l1_opy_)
    username =  Addon.getSetting(l1111l_opy_ (u"ࠧ࡬ࡣࡶࡹࡹࡧࡪࡢࡰ࡬ࡱ࡮࠭঵"))
    password =  Addon.getSetting(l1111l_opy_ (u"ࠨࡵࡤࡰࡦࡹ࡯࡯ࡣࠪশ"))
    l11ll1ll1_opy_   = l1111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬষ") + l11l1l1_opy_
    l111ll111_opy_     = l1111l_opy_ (u"ࠪ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡹࡴࡳࡧࡤࡱࡤࡼࡩࡥࡧࡲࠪࡪࡾࡴࡳࡣࠩࡴࡦ࡭ࡥࠧࡲ࡯ࡳࡹࠬࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠿ࠩࡸ࡮ࡺ࡬ࡦ࠿ࡄࡰࡱࠬࡵࡳ࡮ࡀࠫস")
    l11l1lll1_opy_  =  l11lll111_opy_(l11l1l1_opy_)
    l11l11111_opy_  =  l11ll1ll1_opy_ + l111ll111_opy_ + l11l1lll1_opy_
    l11l11l11_opy_ = l1111l_opy_ (u"ࠫࡺࡹࡥࡳࡰࡤࡱࡪࡃࠧহ") + username + l1111l_opy_ (u"ࠬࠬࡰࡢࡵࡶࡻࡴࡸࡤ࠾ࠩ঺") + password + l1111l_opy_ (u"࠭ࠦࡵࡻࡳࡩࡂ࡭ࡥࡵࡡ࡯࡭ࡻ࡫࡟ࡴࡶࡵࡩࡦࡳࡳࠧࡥࡤࡸࡤ࡯ࡤ࠾࠲ࠪ঻")
    l11ll11_opy_ = l11ll1ll1_opy_  + l1111l_opy_ (u"ࠧ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿ࡶࡩࡨࡻࡲࡪࡶࡼࡣࡨ࡮ࡥࡤ࡭ࠩࡩࡽࡺࡲࡢࠨࡳࡥ࡬࡫ࠦࡱ࡮ࡲࡸࠫࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠧࡶ࡬ࡸࡱ࡫࠽ࡍ࡫ࡹࡩࠪ࠸࠰ࡕࡘࠩࡹࡷࡲ়ࠧ")
    query = l11l11111_opy_ +  urllib.quote_plus(l11l11l11_opy_)
    l111lll11_opy_ = (l1111l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫঽ") % l11ll11_opy_)
    l111lll1l_opy_ = (l1111l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬা") % query)
    try:
        xbmc.executeJSONRPC(l111lll11_opy_)
        response = xbmc.executeJSONRPC(l111lll1l_opy_)
        content = json.loads(response.decode(l1111l_opy_ (u"ࠪࡹࡹ࡬࠭࠹ࠩি"), l1111l_opy_ (u"ࠫ࡮࡭࡮ࡰࡴࡨࠫী")))
        return content
    except Exception as e:
        l1l11ll1_opy_(e)
        return {l1111l_opy_ (u"ࠬࡋࡲࡳࡱࡵࠫু") : l1111l_opy_ (u"࠭ࡐ࡭ࡷࡪ࡭ࡳࠦࡅࡳࡴࡲࡶࠬূ")}
def l111l1lll_opy_(l11l1l1_opy_, l1l1lll1_opy_):
    if (l11l1l1_opy_ == l111lllll_opy_) or (l11l1l1_opy_ == l11l111l1_opy_) or (l11l1l1_opy_ == l111llll1_opy_):
        l1l1lll1_opy_ = l1l1lll1_opy_.replace(l1111l_opy_ (u"ࠧࠡࠢࠪৃ"), l1111l_opy_ (u"ࠨࠢࠪৄ")).replace(l1111l_opy_ (u"ࠩࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ৅"), l1111l_opy_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ৆"))
        return l1l1lll1_opy_
    if l11l1l1_opy_ == l11l11l1l_opy_:
        l1l1lll1_opy_ = l1l1lll1_opy_.replace(l1111l_opy_ (u"ࠫࠥࠦࠧে"), l1111l_opy_ (u"ࠬࠦࠧৈ")).replace(l1111l_opy_ (u"࠭ࠠ࡜࠱ࡅࡡࠬ৉"), l1111l_opy_ (u"ࠧ࡜࠱ࡅࡡࠬ৊"))
        return l1l1lll1_opy_
def l1l1l1l_opy_(l11l1l1_opy_, l11l1111l_opy_):
    if (l11l1l1_opy_ == l111lllll_opy_) or (l11l1l1_opy_ == l11l111l1_opy_) or (l11l1l1_opy_ == l111llll1_opy_):
        channel = l11l1111l_opy_.rsplit(l1111l_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪো"), 1)[0].split(l1111l_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡺ࡬࡮ࡺࡥ࡞ࠩৌ"), 1)[-1]
        return channel
    if l11l1l1_opy_ == l11l11l1l_opy_:
        channel = l11l1111l_opy_.rsplit(l1111l_opy_ (u"ࠪ࡟࠴ࡈ࡝ࠨ্"), 1)[0].split(l1111l_opy_ (u"ࠫࡠࡈ࡝ࠨৎ"), 1)[-1]
        return channel
def l11lll111_opy_(l11l1l1_opy_):
    if (l11l1l1_opy_ == l111lllll_opy_) or (l11l1l1_opy_ == l11l111l1_opy_):
        return l1111l_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠹࠷࠯࠳࠻࠻࠳࠷࠳࠺࠰࠴࠹࠺ࡀ࠸࠱࠲࠳࠳ࡪࡴࡩࡨ࡯ࡤ࠶࠳ࡶࡨࡱࡁࠪ৏")
    if l11l1l1_opy_ == l111llll1_opy_:
        return l1111l_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠲࠯ࡹࡨࡰࡨࡳ࠮ࡵࡸ࠽࠼࠵࠶࠰࠰ࡧࡱ࡭࡬ࡳࡡ࠳࠰ࡳ࡬ࡵࡅࠧ৐")
    if l11l1l1_opy_ == l11l11l1l_opy_:
        return l1111l_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠷࠻࠲࠻࠿࠮࠶࠶࠱࠹࠹ࡀ࠸࠱࠲࠳࠳ࡪࡴࡩࡨ࡯ࡤ࠶࠳ࡶࡨࡱࡁࠪ৑")
def l1l11ll1_opy_(e):
    l1l1llll_opy_ = l1111l_opy_ (u"ࠨࡕࡲࡶࡷࡿࠬࠡࡣࡱࠤࡪࡸࡲࡰࡴࠣࡳࡨࡩࡵࡳࡧࡧ࠾ࠥࡐࡓࡐࡐࠣࡉࡷࡸ࡯ࡳ࠼ࠣࠩࡸ࠭৒")  %e
    l1l1l1ll_opy_ = l1111l_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡹࡸࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡦࡰࡴࡸࡱ࠳࠭৓")
    l1ll111l_opy_ = l1111l_opy_ (u"࡙ࠪࡵࡲ࡯ࡢࡦࠣࡥࠥࡲ࡯ࡨࠢࡹ࡭ࡦࠦࡴࡩࡧࠣࡥࡩࡪ࡯࡯ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠤࡦࡴࡤࠡࡲࡲࡷࡹࠦࡴࡩࡧࠣࡰ࡮ࡴ࡫࠯ࠩ৔")
    dixie.log(e)
    dixie.DialogOK(l1l1llll_opy_, l1l1l1ll_opy_, l1ll111l_opy_)
    dixie.SetSetting(SETTING, l1111l_opy_ (u"ࠫࠬ৕"))