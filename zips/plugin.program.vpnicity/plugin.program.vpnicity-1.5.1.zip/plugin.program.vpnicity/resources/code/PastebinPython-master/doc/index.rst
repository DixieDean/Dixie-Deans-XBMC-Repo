.. pastebin_python documentation master file, created by
   sphinx-quickstart on Mon Feb 18 20:03:34 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pastebin_python's documentation!
*******************************************

.. toctree::
	:maxdepth: 1

	intro
	code

Indices and tables
******************

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
