#
#      Copyright (C) 2017 On-Tapp-Networks Limited
#

import xbmc
import xbmcaddon
import xbmcgui
import os

import vpn_utils as utils


def AddAddonShortcut(autoaddon, country, addonlabel):
    addonNames = getNames()
    addonList  = getList(addonNames)

    option = xbmcgui.Dialog().select('Select Add-on', addonList)

    if option < 0:
        return

    theLabel = addonNames[option][0]
    theAddon = addonNames[option][1]

    utils.SetSetting(addonlabel, theLabel)
    utils.SetSetting(autoaddon,  theAddon)

    if utils.GetSetting(autoaddon) > 0:
        return addCountry(country)

    return


def addCountry(country):
    countryNames = getCountries()
    countryList  = getList(countryNames)

    option = xbmcgui.Dialog().select('Select country', countryList)

    if option < 0:
        return

    update = countryNames[option][0]

    utils.SetSetting(country, update)

    return


def getCountries():
    import glob
    path = xbmc.translatePath(os.path.join(utils.PROFILE, 'countries', '*'))
    countries = []

    for item in glob.glob(path):
        f = open(item)
        abrv = f.read()
        f.close()
        country = item.rsplit(os.path.sep, 1)[-1]
        countries.append([country, abrv])

    countries.sort()

    return countries


def getList(names):
    theList = []

    for name in names:
        theList.append(name[0])

    if theList < 0:
        return False

    return theList


def getNames():
    import glob
    path  = xbmc.translatePath(os.path.join('special://home' , 'addons', '*.*'))
    names = []

    for addon in glob.glob(path):
        try:
            name     = addon.lower().rsplit(os.path.sep, 1)[-1]
            realname = xbmcaddon.Addon(name).getAddonInfo('name')
            provides = xbmcaddon.Addon(name).getAddonInfo('type')

            if (provides == 'xbmc.python.pluginsource') or (provides == 'xbmc.python.script'):
                names.append([realname, name])
        except:
            pass

    if len(names) < 1:
        return

    names.sort()

    return names


if __name__ == '__main__':
    autoaddon  = sys.argv[1]
    country    = sys.argv[2]
    addonlabel = sys.argv[3]
    AddAddonShortcut(autoaddon, country, addonlabel)
