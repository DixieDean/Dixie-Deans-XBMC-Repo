#
#      Copyright (C) 2017 On-Tapp-Networks Limited
#

import xbmcgui

import vpn_utils as utils


def removeAddonShortcut():
    addons = getAddons()
    option = xbmcgui.Dialog().select('Select an Add-on to remove', addons)

    if option < 0:
        return

    utils.SetSetting('ADDON_%d' % option, '')
    utils.SetSetting('VPN_%d'   % option, '')
    utils.SetSetting('LABEL_%d' % option, '')

    return


def getAddons():
    addons = []
    for i in range(10):
        addon = utils.GetSetting('LABEL_%d' % i)
        if len(addon) > 0:
            addons.append(addon)

    return addons


if __name__ == '__main__':
    removeAddonShortcut()
