#
#      Copyright (C) 2016 Richard Dean (write2utils@gmail.com)
#

import os
import xbmc
import resources
import vpn_utils as utils

from resources.pastebin_python import PastebinPython
from resources.pastebin_python.pastebin_exceptions   import PastebinBadRequestException, PastebinNoPastesException, PastebinFileException
from resources.pastebin_python.pastebin_constants    import PASTE_PUBLIC, EXPIRE_10_MIN, EXPIRE_1_MONTH, EXPIRE_1_WEEK, PASTE_UNLISTED
from resources.pastebin_python.pastebin_formats      import FORMAT_NONE, FORMAT_PYTHON, FORMAT_HTML


def LogUploader():
    pastebin = PastebinPython(api_dev_key='82ab1f8053f13f84beea0d1c933f48f2')
    vpnLog   = os.path.abspath(getVPNLog())
    kodiLog  = os.path.abspath(getLogfile())

    utils.log('------------ UPLOAD LOG ------------')
    utils.log(vpnLog)
    utils.log(kodiLog)

    try:
        pastebin.createAPIUserKey('OnTappNetworks', 'ontapp123')

        vpnPaste  = pastebin.createPasteFromFile(vpnLog,  'On-Tapp-Networks Logfiles', FORMAT_HTML, PASTE_UNLISTED, EXPIRE_1_WEEK)
        utils.log('OpenVPN log:')
        if len(vpnPaste) == 0:
            utils.log('empty ovpn log file')
        else:
            utils.log(vpnPaste)

        kodiPaste = pastebin.createPasteFromFile(kodiLog, 'On-Tapp-Networks Logfiles', FORMAT_HTML, PASTE_UNLISTED, EXPIRE_1_WEEK)
        utils.log(kodiPaste)

        logcode   = kodiPaste.rsplit('/', 1)[-1]
        utils.log(logcode)
 
        utils.dialogOK('This is your log code: [COLOR orange][B]' + logcode + '[/B][/COLOR]', 'Write it down and send it to us via our forum.', 'Or email it to us with your support question: support@vpnicity.com')

    except PastebinBadRequestException as e:
        showError(e.message)
    except PastebinFileException as e:
        showError(e.message)


def showError(error):
    utils.log(error)
    utils.dialogOK('Sorry, the following error occurred:', '[COLOR orange][B]' + error + '[/B][/COLOR]', 'Restart Kodi and try again.')

def showBusy():
    try: xbmc.executebuiltin('ActivateWindow(busydialog)')
    except: pass

    return None


def closeBusy():
    try: xbmc.executebuiltin('Dialog.Close(busydialog)')
    except: pass


def getLogfile():
    path = xbmc.translatePath('special://logpath')
    old  = os.path.join(path, 'xbmc.log')
    kodi = os.path.join(path, 'kodi.log')
    spmc = os.path.join(path, 'spmc.log')

    if os.path.isfile(old):
        utils.log('======= VPNicity log path is =======')
        utils.log(old)
        return old

    if os.path.isfile(kodi):
        utils.log('======= VPNicity log path is =======')
        utils.log(kodi)
        return kodi

    if os.path.isfile(spmc):
        utils.log('======= VPNicity log path is =======')
        utils.log(spmc)
        return spmc


def getVPNLog():
    vpnpath = xbmc.translatePath('special://profile/addon_data/plugin.program.vpnicity/')
    vpnlog  = os.path.join(vpnpath, 'openvpn.log')

    if os.path.isfile(vpnlog):
        utils.log('======= OpenVPN log path is =======')
        utils.log(vpnlog)
        return vpnlog


if __name__ == '__main__':
    showBusy()
    LogUploader()
    closeBusy()
