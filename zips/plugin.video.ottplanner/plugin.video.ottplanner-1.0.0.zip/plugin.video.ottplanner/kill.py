

import os
import subprocess

import ottplanner_utils as utils


def PID(pid): 
    if os.name == 'nt':
        try:
            #si = subprocess.STARTUPINFO
            #si.dwFlags |= subprocess._subprocess.STARTF_USESHOWWINDOW
            #si.wShowWindow = subprocess._subprocess.SW_HIDE

            ps  = subprocess.Popen('TASKKILL /F /PID %d' % pid, shell=True, stdout=subprocess.PIPE, startupinfo=None)
            ps.wait()
        except:
            pass

        return
    """
    # Android
    if utils.platform() == "android" :
        print '************  in kill.py kill vpn android activity  ************'
        xbmc.executebuiltin( "StartAndroidActivity(%s,%s)" % ( "com.vpnicity.openvpn.control", "com.vpnicity.openvpn.control.DISCONNECT") )
        return

    #LINUX
    try:
        cmd = utils.getSudo() + 'killall -9 openvpn'

        ps  = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        ps.wait()
    except:
        pass
    """

