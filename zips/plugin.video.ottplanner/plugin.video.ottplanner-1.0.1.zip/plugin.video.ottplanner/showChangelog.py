

if __name__ == '__main__':
    import ottplanner_utils as utils
    utils._showChangelog()