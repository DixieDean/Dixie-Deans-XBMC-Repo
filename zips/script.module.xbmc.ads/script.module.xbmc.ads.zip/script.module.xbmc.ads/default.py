VERSION = "1.0.0"

if __name__ == '__main__':  
    #from xbmcads import ads
    #ads.SERVICE_ADVERTISE()
    print 'ADS Service Disabled. Only Addon-On-Demand Ads Supported.'