# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l11ll1_opy_ = 2048
l1l11_opy_ = 7
def l1ll11_opy_ (ll_opy_):
	global l11lll_opy_
	l1lll11_opy_ = ord (ll_opy_ [-1])
	l1l11l_opy_ = ll_opy_ [:-1]
	l111l1_opy_ = l1lll11_opy_ % len (l1l11l_opy_)
	l1ll1_opy_ = l1l11l_opy_ [:l111l1_opy_] + l1l11l_opy_ [l111l1_opy_:]
	if l1_opy_:
		l111ll_opy_ = unicode () .join ([unichr (ord (char) - l11ll1_opy_ - (l1lll1_opy_ + l1lll11_opy_) % l1l11_opy_) for l1lll1_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l111ll_opy_ = str () .join ([chr (ord (char) - l11ll1_opy_ - (l1lll1_opy_ + l1lll11_opy_) % l1l11_opy_) for l1lll1_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l111ll_opy_)
import time
import random
import base64
import requests
import re
import os
import json
import hashlib
import xbmc
import dixie
addon = l1ll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮࡬ࡺࡪࡳࡩࡹࠩࡋ")
def checkAddons():
    if l1l1l1l_opy_(addon):
        createINI()
def l1l1l1l_opy_(addon):
    if xbmc.getCondVisibility(l1ll11_opy_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡌࡦࡹࡁࡥࡦࡲࡲ࠭ࠫࡳࠪࠩࡌ") % addon) == 1:
        return True
    return False
def getLIVETV(url):
    if url.startswith(l1ll11_opy_ (u"ࠫࡑࡏࡖࡆࡖ࡙ࡊ࠿࠭ࡍ")):
        return url.replace(l1ll11_opy_ (u"ࠬࡒࡉࡗࡇࡗ࡚ࡋࡀࠧࡎ"), l1ll11_opy_ (u"࠭ࠧࡏ")).replace(l1ll11_opy_ (u"ࠧ࠯ࡶࡶࠫࡐ"), l1ll11_opy_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧࡑ"))
    l11111_opy_ = getChannels()
    stream   = url.split(l1ll11_opy_ (u"ࠩ࠽ࠫࡒ"), 1)[-1].lower()
    for channel in l11111_opy_:
        l1l1l_opy_ = channel[l1ll11_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࡓ")]
        url   = channel[l1ll11_opy_ (u"ࠫࡺࡸ࡬ࠨࡔ")]
        if stream == l1l1l_opy_.lower():
            return url
    return None
def createINI():
    HOME = dixie.PROFILE
    PATH = os.path.join(HOME, l1ll11_opy_ (u"ࠬ࡯࡮ࡪࠩࡕ"))
    l111_opy_ = l1ll11_opy_ (u"࠭࡬ࡪࡸࡨࡸࡻ࠴ࡩ࡯࡫ࠪࡖ")
    l1l_opy_  = os.path.join(PATH, l111_opy_)
    l11111_opy_ = getChannels()
    l1l1_opy_  = file(l1l_opy_, l1ll11_opy_ (u"ࠧࡸࠩࡗ"))
    l1l1_opy_.write(l1ll11_opy_ (u"ࠨ࡝ࠪࡘ"))
    l1l1_opy_.write(addon)
    l1l1_opy_.write(l1ll11_opy_ (u"ࠩࡠ࡙ࠫ"))
    l1l1_opy_.write(l1ll11_opy_ (u"ࠪࡠࡳ࡚࠭"))
    for channel in l11111_opy_:
        l1l1l_opy_   = channel[l1ll11_opy_ (u"ࠫࡱࡧࡢࡦ࡮࡛ࠪ")]
        stream  = channel[l1ll11_opy_ (u"ࠬࡻࡲ࡭ࠩ࡜")]
        l1l1_opy_.write(l1ll11_opy_ (u"࠭ࠥࡴࠩ࡝") % l1l1l_opy_)
        l1l1_opy_.write(l1ll11_opy_ (u"ࠧ࠾ࠩ࡞"))
        l1l1_opy_.write(l1ll11_opy_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠻ࠩ࡟"))
        l1l1_opy_.write(l1ll11_opy_ (u"ࠩࠨࡷࠬࡠ") % l1l1l_opy_)
        l1l1_opy_.write(l1ll11_opy_ (u"ࠪࡠࡳ࠭ࡡ"))
    l1l1_opy_.write(l1ll11_opy_ (u"ࠫࡡࡴࠧࡢ"))
    l1l1_opy_.close()
def getChannels():
    token   =  l1l1l11_opy_(l1ll11_opy_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡱࡲ࠱ࡹࡰࡺࡶ࡯ࡱࡺ࠲ࡳ࡫ࡴ࠰ࡸ࠴࠳࡬࡫ࡴࡠࡣ࡯ࡰࡤࡩࡨࡢࡰࡱࡩࡱࡹࠧࡣ"),l1ll11_opy_ (u"࠭ࡧࡰࡣࡷࠫࡤ"))
    headers =  {l1ll11_opy_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫࡥ"):l1ll11_opy_ (u"ࠨࡗࡖࡉࡗ࠳ࡁࡈࡇࡑࡘ࠲࡛ࡋࡕࡘࡑࡓ࡜࠳ࡁࡑࡒ࠰࡚࠶࠭ࡦ"),
                l1ll11_opy_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨࡧ"):l1ll11_opy_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪࡨ"),
                l1ll11_opy_ (u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭ࡩ") : l1ll11_opy_ (u"ࠬ࡭ࡺࡪࡲࠪࡪ"),
                l1ll11_opy_ (u"࠭ࡡࡱࡲ࠰ࡸࡴࡱࡥ࡯ࠩ࡫"):token,
                l1ll11_opy_ (u"ࠧࡄࡱࡱࡲࡪࡩࡴࡪࡱࡱࠫ࡬"):l1ll11_opy_ (u"ࠨࡍࡨࡩࡵ࠳ࡁ࡭࡫ࡹࡩࠬ࡭"),
                l1ll11_opy_ (u"ࠩࡋࡳࡸࡺࠧ࡮"):l1ll11_opy_ (u"ࠪࡥࡵࡶ࠮ࡶ࡭ࡷࡺࡳࡵࡷ࠯ࡰࡨࡸࠬ࡯")}
    l1l11ll_opy_ = {l1ll11_opy_ (u"ࠫࡺࡹࡥࡳࡰࡤࡱࡪ࠭ࡰ"):l1ll11_opy_ (u"ࠬ࡭࡯ࡢࡶࠪࡱ")}
    request = requests.post(l1ll11_opy_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡲࡳ࠲ࡺࡱࡴࡷࡰࡲࡻ࠳ࡴࡥࡵ࠱ࡹ࠵࠴࡭ࡥࡵࡡࡤࡰࡱࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨࡲ"), data=l1l11ll_opy_, headers=headers)
    l1l1lll_opy_ =  request.content
    l1l1lll_opy_ =  l1l1lll_opy_.replace(l1ll11_opy_ (u"ࠧ࡝࠱ࠪࡳ"),l1ll11_opy_ (u"ࠨ࠱ࠪࡴ"))
    l1ll111_opy_ = l1ll11_opy_ (u"ࠩࠥࡧ࡭ࡧ࡮࡯ࡧ࡯ࡣࡳࡧ࡭ࡦࠤ࠽ࠦ࠭࠴ࠫࡀࠫࠥ࠰ࠧ࡯࡭ࡨࠤ࠽ࠦ࠭࠴ࠫࡀࠫࠥ࠰ࠧ࡮ࡴࡵࡲࡢࡷࡹࡸࡥࡢ࡯ࠥ࠾ࠧ࠮࠮ࠬࡁࠬࠦ࠱ࠨࡲࡵ࡯ࡳࡣࡸࡺࡲࡦࡣࡰࠦ࠿ࠨࠨ࠯࠭ࡂ࠭ࠧ࠲ࠢࡤࡣࡷࡣ࡮ࡪࠢ࠻ࠤࠫ࠲࠰ࡅࠩࠣࠩࡵ")
    items    = re.compile(l1ll111_opy_).findall(l1l1lll_opy_)
    l11111_opy_ = []
    for item in items:
        link = {l1ll11_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࡶ"): item[0], l1ll11_opy_ (u"ࠫࡺࡸ࡬ࠨࡷ"): item[2]}
        l11111_opy_.append(link)
    return l11111_opy_
def l1l1l11_opy_(url, username):
    l1l1ll1_opy_   =  l1l11l1_opy_()
    st   = l1ll11_opy_ (u"ࠧࡻ࡫ࡵࡸࡱࡳࡼ࠳ࡴࡰ࡭ࡨࡲ࠲ࠨࡸ")+ l1l1ll1_opy_ + l1ll11_opy_ (u"ࠨ࠭ࠣࡹ")+ l1ll11_opy_ (u"ࠢࡠࡾࡢ࠱ࠧࡺ") + url + l1ll11_opy_ (u"ࠣ࠯ࠥࡻ") + username +l1ll11_opy_ (u"ࠤ࠰ࠦࡼ") + l1ll11_opy_ (u"ࠥࡣࢁࡥࠢࡽ")+ l1ll11_opy_ (u"ࠦ࠲ࠨࡾ")+ base64.b64decode(l1ll11_opy_ (u"ࠧࡓࡔࡊࡼࡑࡈ࡚࠸ࡉࡖࡃ࡭ࡎࡈ࡜ࡥࡥ࡙ࡷ࠴ࡩࡳ࠵ࡷࡦ࠴࠸ࡱࡐࡃࡏࡃࡌࡘ࡞࠷ࡎࡅࡏࡼࡑࡖࡃ࠽ࠣࡿ"))
    return hashlib.md5(st).hexdigest()
def l1l11l1_opy_():
    from datetime import datetime, timedelta
    local = datetime.now() + timedelta(hours=5)
    return local.strftime(l1ll11_opy_ (u"࠭ࠥࡃ࠯ࠨࡨ࠲࡙ࠫࠨࢀ"))