# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l11ll1_opy_ = 2048
l1l11_opy_ = 7
def l1ll11_opy_ (ll_opy_):
	global l11lll_opy_
	l1lll11_opy_ = ord (ll_opy_ [-1])
	l1l11l_opy_ = ll_opy_ [:-1]
	l111l1_opy_ = l1lll11_opy_ % len (l1l11l_opy_)
	l1ll1_opy_ = l1l11l_opy_ [:l111l1_opy_] + l1l11l_opy_ [l111l1_opy_:]
	if l1_opy_:
		l111ll_opy_ = unicode () .join ([unichr (ord (char) - l11ll1_opy_ - (l1lll1_opy_ + l1lll11_opy_) % l1l11_opy_) for l1lll1_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l111ll_opy_ = str () .join ([chr (ord (char) - l11ll1_opy_ - (l1lll1_opy_ + l1lll11_opy_) % l1l11_opy_) for l1lll1_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l111ll_opy_)
import xbmc
import xbmcaddon
import json
import urllib
import os
import dixie
l11llll11_opy_   = l1ll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡶ࡭ࡷࡺ࡫ࡸࡡ࡯ࡥࡨࠫন")
l1l11111l_opy_   = l1ll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡺࡷࡶࡪࡧ࡭࠮ࡥࡲࡨࡪࡹࠧ঩")
l11lll111_opy_ = l1ll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧࡩࡱࡶࡹࠫপ")
l11ll1l11_opy_    = l1ll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡵࡺ࡯ࡣ࡬࡫ࡳࡸࡻ࠭ফ")
l11lllll1_opy_   = l1ll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡫ࡻࡴࡶࡴࡨࡷࡹࡸࡥࡢ࡯ࡶࠫব")
l11ll1l1l_opy_    = l1ll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹࡰࡪࡰࡽࠫভ")
l1l111111_opy_  = l1ll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡵࡧࡤࡰࡹ࡮ࡵ࡯ࡦࡨࡶ࡬ࡸ࡯ࡶࡰࡧࠫম")
l11ll11l1_opy_     = l1ll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡰࡶࡷࡥࡱࡶࡨࡢࠩয")
l11lll1ll_opy_ = l1ll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡈ࡯ࡥࡼࡲࡥࡴࡵࡗࡺࠬর")
l1l111lll_opy_   =  [l11llll11_opy_, l1l11111l_opy_, l11ll1l11_opy_, l11lllll1_opy_, l11ll1l1l_opy_, l1l111111_opy_, l11ll11l1_opy_, l11lll1ll_opy_]
def checkAddons():
    for addon in l1l111lll_opy_:
        if l1l1l1l_opy_(addon):
            createINI(addon)
def l1l1l1l_opy_(addon):
    if xbmc.getCondVisibility(l1ll11_opy_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡌࡦࡹࡁࡥࡦࡲࡲ࠭ࠫࡳࠪࠩ঱") % addon) == 1:
        return True
    else:
        return False
def createINI(addon):
    HOME = dixie.PROFILE
    PATH = os.path.join(HOME, l1ll11_opy_ (u"ࠫ࡮ࡴࡩࠨল"))
    l111_opy_ = str(addon).split(l1ll11_opy_ (u"ࠬ࠴ࠧ঳"))[2] + l1ll11_opy_ (u"࠭࠮ࡪࡰ࡬ࠫ঴")
    l1l_opy_  = os.path.join(PATH, l111_opy_)
    response = l1ll11ll1_opy_(addon)
    try:
        result = response[l1ll11_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧ঵")]
    except KeyError:
        dixie.log(l1ll11_opy_ (u"ࠨ࠯࠰࠱࠲࠳ࠠࡌࡧࡼࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥ࡭ࡥࡵࡈ࡬ࡰࡪࡹࠠ࠮࠯࠰࠱࠲ࠦࠧশ") + addon)
        result = {l1ll11_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࡴࠩষ"): [{l1ll11_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭স"): l1ll11_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࠪহ"), l1ll11_opy_ (u"ࡺ࠭ࡴࡺࡲࡨࠫ঺"): l1ll11_opy_ (u"ࡻࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨ঻"), l1ll11_opy_ (u"ࡵࠨࡨ࡬ࡰࡪ়࠭"): l1ll11_opy_ (u"ࡶࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡽࡾࠧঽ"), l1ll11_opy_ (u"ࡷࠪࡰࡦࡨࡥ࡭ࠩা"): l1ll11_opy_ (u"ࡸࠫࡓࡕࠠࡄࡊࡄࡒࡓࡋࡌࡔࠩি")}], l1ll11_opy_ (u"ࡹࠬࡲࡩ࡮࡫ࡷࡷࠬী"): {l1ll11_opy_ (u"ࡺ࠭ࡳࡵࡣࡵࡸࠬু"): 0, l1ll11_opy_ (u"ࡻࠧࡵࡱࡷࡥࡱ࠭ূ"): 1, l1ll11_opy_ (u"ࡵࠨࡧࡱࡨࠬৃ"): 1}}
    l11111_opy_ = result[l1ll11_opy_ (u"ࠨࡨ࡬ࡰࡪࡹࠧৄ")]
    l1l1_opy_  = file(l1l_opy_, l1ll11_opy_ (u"ࠩࡺࠫ৅"))
    l1l1_opy_.write(l1ll11_opy_ (u"ࠪ࡟ࠬ৆"))
    l1l1_opy_.write(addon)
    l1l1_opy_.write(l1ll11_opy_ (u"ࠫࡢ࠭ে"))
    l1l1_opy_.write(l1ll11_opy_ (u"ࠬࡢ࡮ࠨৈ"))
    l11ll_opy_ = []
    for channel in l11111_opy_:
        if addon == l11ll11l1_opy_:
            l11ll11ll_opy_ = channel[l1ll11_opy_ (u"࠭࡬ࡢࡤࡨࡰࠬ৉")].split(l1ll11_opy_ (u"ࠧࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ৊"), 1)[0].replace(l1ll11_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡵࡷࡩࡪࡲࡢ࡭ࡷࡨࡡࠬো"), l1ll11_opy_ (u"ࠩࠪৌ"))
            l11ll11ll_opy_ = l11ll11ll_opy_.replace(l1ll11_opy_ (u"࡙ࠪࡐࡀࠠࠨ্"), l1ll11_opy_ (u"ࠫࠬৎ"))
        else:
            l11ll11ll_opy_ = channel[l1ll11_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫ৏")].split(l1ll11_opy_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ৐"), 1)[0].replace(l1ll11_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡸࡪ࡬ࡸࡪࡣࠧ৑"), l1ll11_opy_ (u"ࠨࠩ৒"))
            l11ll11ll_opy_ = l11ll11ll_opy_.replace(l1ll11_opy_ (u"ࠩࠣࠤࠬ৓"), l1ll11_opy_ (u"ࠪࠫ৔"))
            l11ll11ll_opy_ = l11ll11ll_opy_.replace(l1ll11_opy_ (u"࡚ࠫࡑ࠺ࠡࠩ৕"), l1ll11_opy_ (u"ࠬ࠭৖"))
            l11ll11ll_opy_ = l11ll11ll_opy_.replace(l1ll11_opy_ (u"࠭ࡕࡔࡃ࠽ࠤࠬৗ"), l1ll11_opy_ (u"ࠧࠨ৘"))
            l11ll11ll_opy_ = l11ll11ll_opy_.replace(l1ll11_opy_ (u"ࠨࡅࡄ࠾ࠥ࠭৙"), l1ll11_opy_ (u"ࠩࠪ৚"))
            l11ll11ll_opy_ = l11ll11ll_opy_.replace(l1ll11_opy_ (u"ࠪࡍࡓ࡚࠺ࠡࠩ৛"), l1ll11_opy_ (u"ࠫࠬড়"))
        l1l1l_opy_  = dixie.mapChannelName(l11ll11ll_opy_)
        stream = channel[l1ll11_opy_ (u"ࠬ࡬ࡩ࡭ࡧࠪঢ়")]
        if addon == l11lll1ll_opy_:
            stream = l1ll11_opy_ (u"࠭ࡌࡊࡘࡈࡘ࡛ࡌ࠺ࠨ৞") + stream
        l1lll_opy_ = l1l1l_opy_ + l1ll11_opy_ (u"ࠧ࠾ࠩয়") + stream
        l11ll_opy_.append(l1lll_opy_)
        l11ll_opy_.sort()
    for item in l11ll_opy_:
      l1l1_opy_.write(l1ll11_opy_ (u"ࠣࠧࡶࡠࡳࠨৠ") % item)
    l1l1_opy_.close()
def l1ll11ll1_opy_(addon):
    l11lll11l_opy_ = (l1ll11_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬৡ") % addon)
    if addon == l1l111111_opy_:
        login = l1ll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡺࡥࡢ࡮ࡷ࡬ࡺࡴࡤࡦࡴࡪࡶࡴࡻ࡮ࡥ࠱ࡂࡱࡴࡪࡥ࠾ࡩࡨࡲࡷ࡫ࡳࠧࡲࡲࡶࡹࡧ࡬࠾ࠧ࠺ࡦࠪ࠸࠲࡯ࡣࡰࡩࠪ࠸࠲ࠦ࠵ࡤࠩ࠷࠶ࠥ࠳࠴ࠨ࠹ࡧࡏࠥ࠶ࡦࠨ࠹ࡧࡉࡏࡍࡑࡕࠩ࠷࠶ࡷࡩ࡫ࡷࡩࠪ࠻ࡤࡄ࡮࡬ࡧࡰࠫ࠲࠱ࡖࡲࠩ࠷࠶ࡖࡪࡧࡺࠩ࠷࠶ࡔࡩࡧࠨ࠶࠵ࡒࡩࡴࡶࠨ࠶࠵ࡕࡦࠦ࠴࠳ࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠪ࠻ࡢࠦ࠴ࡩࡇࡔࡒࡏࡓࠧ࠸ࡨࠪ࠻ࡢࠦ࠴ࡩࡍࠪ࠻ࡤࠦ࠴࠵ࠩ࠷ࡩࠥ࠳࠲ࠨ࠶࠷ࡶࡡࡳࡧࡱࡸࡦࡲࠥ࠳࠴ࠨ࠷ࡦࠫ࠲࠱ࠧ࠵࠶࡫ࡧ࡬ࡴࡧࠨ࠶࠷ࠫ࠲ࡤࠧ࠵࠴ࠪ࠸࠲ࡶࡴ࡯ࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࠫ࠲࠳ࡪࡷࡸࡵࠫ࠳ࡢࠧ࠵ࡪࠪ࠸ࡦ࡮ࡹ࠴࠲࡮ࡶࡴࡷ࠸࠹࠲ࡹࡼࠥ࠳࠴ࠨ࠶ࡨࠫ࠲࠱ࠧ࠵࠶ࡵࡶࡡࡴࡵࡺࡳࡷࡪࠥ࠳࠴ࠨ࠷ࡦࠫ࠲࠱ࠧ࠵࠶࠵࠶࠰࠱ࠧ࠵࠶ࠪ࠸ࡣࠦ࠴࠳ࠩ࠷࠸࡭ࡢࡥࠨ࠶࠷ࠫ࠳ࡢࠧ࠵࠴ࠪ࠸࠲࠱࠲ࠨ࠷ࡦ࠷ࡁࠦ࠵ࡤ࠻࠽ࠫ࠳ࡢ࠶࠶ࠩ࠸ࡧ࠱࠳ࠧ࠶ࡥ࠼࠺ࠥ࠳࠴ࠨ࠶ࡨࠫ࠲࠱ࠧ࠵࠶ࡸ࡫ࡲࡪࡣ࡯ࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࠫ࠷ࡣࠧ࠵࠶ࡸ࡫࡮ࡥࡡࡶࡩࡷ࡯ࡡ࡭ࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࡸࡷࡻࡥࠦ࠴ࡦࠩ࠷࠶ࠥ࠳࠴ࡦࡹࡸࡺ࡯࡮ࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࡸࡷࡻࡥࠦ࠴ࡦࠩ࠷࠶ࠥ࠳࠴ࡶࡲࠪ࠸࠲ࠦ࠵ࡤࠩ࠷࠶ࠥ࠳࠴ࠨ࠶࠷ࠫ࠲ࡤࠧ࠵࠴ࠪ࠸࠲ࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࠨ࠶࠷ࠫ࠳ࡢࠧ࠵࠴ࠪ࠸࠲ࠦ࠴࠵ࠩ࠷ࡩࠥ࠳࠲ࠨ࠶࠷ࡪࡥࡷ࡫ࡦࡩࡤ࡯ࡤ࠳ࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࠩ࠷࠸ࠥ࠳࠴ࠨ࠶ࡨࠫ࠲࠱ࠧ࠵࠶ࡩ࡫ࡶࡪࡥࡨࡣ࡮ࡪࠥ࠳࠴ࠨ࠷ࡦࠫ࠲࠱ࠧ࠵࠶ࠪ࠸࠲ࠦ࠹ࡧࠩ࠷ࡩࠥ࠳࠲ࠨ࠶࠷ࡶࡡࡴࡵࡺࡳࡷࡪࠥ࠳࠴ࠨ࠷ࡦࠫ࠲࠱ࡰࡸࡰࡱࠫ࠲ࡤࠧ࠵࠴ࠪ࠸࠲࡭ࡱࡪ࡭ࡳࠫ࠲࠳ࠧ࠶ࡥࠪ࠸࠰࡯ࡷ࡯ࡰࠪ࠽ࡤࠨৢ")
    else:
        login = l1ll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧৣ") + addon + l1ll11_opy_ (u"ࠬ࠵࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࡴࡧࡦࡹࡷ࡯ࡴࡺࡡࡦ࡬ࡪࡩ࡫ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠬࡴࡪࡶ࡯ࡩࡂࡒࡩࡷࡧࠨ࠶࠵࡚ࡖࠧࡷࡵࡰࠬ৤")
    query = l1l1111ll_opy_(addon)
    l11ll1ll1_opy_ = (l1ll11_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࠧࡶࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ৥") % login)
    l11ll1lll_opy_ = (l1ll11_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࠨࡷࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ০") % query)
    try:
        xbmc.executeJSONRPC(l11lll11l_opy_)
        if addon != l11lll111_opy_:
            xbmc.executeJSONRPC(l11ll1ll1_opy_)
        response = xbmc.executeJSONRPC(l11ll1lll_opy_)
        content  = json.loads(response.decode(l1ll11_opy_ (u"ࠨࡷࡷࡪ࠲࠾ࠧ১"), l1ll11_opy_ (u"ࠩ࡬࡫ࡳࡵࡲࡦࠩ২")))
        return content
    except:
        dixie.log(l1ll11_opy_ (u"ࠪ࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱ࠥࡖ࡬ࡶࡩ࡬ࡲࠥࡋࡲࡳࡱࡵࠤ࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠭৩"))
        return {l1ll11_opy_ (u"ࠫࡊࡸࡲࡰࡴࠪ৪") : l1ll11_opy_ (u"ࠬࡖ࡬ࡶࡩ࡬ࡲࠥࡋࡲࡳࡱࡵࠫ৫")}
def l1l1111ll_opy_(addon):
    if addon == l11lll1ll_opy_:
        return l1ll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡇ࡮ࡤࡻࡱ࡫ࡳࡴࡖࡹ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡹࡴࡳࡧࡤࡱࡤࡼࡩࡥࡧࡲࠪࡪࡾࡴࡳࡣࠩࡴࡦ࡭ࡥࠧࡲ࡯ࡳࡹࠬࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠿ࠩࡸ࡮ࡺ࡬ࡦ࠿ࡄࡰࡱࠬࡵࡳ࡮ࡀ࠴ࠬ৬")
    if addon == l11lll111_opy_:
        return l1ll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࡯ࡰࡵࡸ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡱ࡯ࡶࡦࡶࡹࡣࡦࡲ࡬ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠥ࠳ࡨࡘࡷࡪࡸࡳࠦ࠴ࡩࡶ࡮ࡩࡨࡢࡴࡧࠩ࠷࡬ࡌࡪࡤࡵࡥࡷࡿࠥ࠳ࡨࡄࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴࠥ࠳࠲ࡖࡹࡵࡶ࡯ࡳࡶࠨ࠶࡫ࡑ࡯ࡥ࡫ࠨ࠶࡫ࡧࡤࡥࡱࡱࡷࠪ࠸ࡦࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱࡶࡹࡷࡺࡨࡳ࠳࠰࠷ࠩ࠷࡬ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠧ࠵ࡪ࡮ࡳࡧࠦ࠴ࡩ࡬ࡴࡺ࠮ࡱࡰࡪࠪࡹ࡯ࡴ࡭ࡧࡀࡅࡱࡲࠥ࠳࠲ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠪࡺࡸ࡬ࠨ৭")
    if addon == l11ll1l11_opy_:
        return l1ll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡴࡹ࡮ࡩ࡫ࡪࡲࡷࡺ࠴ࡅࡡࡤࡶ࡬ࡳࡳࡃࡳࡵࡴࡨࡥࡲࡥࡶࡪࡦࡨࡳࠫ࡫ࡸࡵࡴࡤࠪࡵࡧࡧࡦࠨࡳࡰࡴࡺࠦࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡀࠪࡹ࡯ࡴ࡭ࡧࡀࡅࡱࡲࠦࡶࡴ࡯ࡁ࠵࠭৮")
    if addon == l11lllll1_opy_:
        return l1ll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡪࡺࡺࡵࡳࡧࡶࡸࡷ࡫ࡡ࡮ࡵ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡸࡺࡲࡦࡣࡰࡣࡻ࡯ࡤࡦࡱࠩࡩࡽࡺࡲࡢࠨࡳࡥ࡬࡫ࠦࡱ࡮ࡲࡸࠫࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠾ࠨࡷ࡭ࡹࡲࡥ࠾ࡃ࡯ࡰࠫࡻࡲ࡭࠿࠳ࠫ৯")
    if addon == l1l111111_opy_:
        return l1ll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡸࡺࡥࡢ࡮ࡷ࡬ࡺࡴࡤࡦࡴࡪࡶࡴࡻ࡮ࡥ࠱ࡂ࡫ࡪࡴࡲࡦࡡࡱࡥࡲ࡫࠽ࡂ࡮࡯ࠪࡵࡵࡲࡵࡣ࡯ࡁࠪ࠽ࡂࠦ࠴࠵ࡲࡦࡳࡥࠦ࠴࠵ࠩ࠸ࡇࠫࠦ࠴࠵ࠩ࠺ࡈࡉࠦ࠷ࡇࠩ࠺ࡈࡃࡐࡎࡒࡖ࠰ࡽࡨࡪࡶࡨࠩ࠺ࡊࡃ࡭࡫ࡦ࡯࠰࡚࡯ࠬࡘ࡬ࡩࡼ࠱ࡔࡩࡧ࠮ࡐ࡮ࡹࡴࠬࡑࡩ࠯ࡈ࡮ࡡ࡯ࡰࡨࡰࡸࠫ࠵ࡃࠧ࠵ࡊࡈࡕࡌࡐࡔࠨ࠹ࡉࠫ࠵ࡃࠧ࠵ࡊࡎࠫ࠵ࡅࠧ࠵࠶ࠪ࠸ࡃࠬࠧ࠵࠶ࡵࡧࡲࡦࡰࡷࡥࡱࠫ࠲࠳ࠧ࠶ࡅ࠰ࠫ࠲࠳ࡨࡤࡰࡸ࡫ࠥ࠳࠴ࠨ࠶ࡈ࠱ࠥ࠳࠴ࡸࡶࡱࠫ࠲࠳ࠧ࠶ࡅ࠰ࠫ࠲࠳ࡪࡷࡸࡵࠫ࠳ࡂࠧ࠵ࡊࠪ࠸ࡆ࡮ࡹ࠴࠲࡮ࡶࡴࡷ࠸࠹࠲ࡹࡼࠥ࠳࠴ࠨ࠶ࡈ࠱ࠥ࠳࠴ࡳࡴࡦࡹࡳࡸࡱࡵࡨࠪ࠸࠲ࠦ࠵ࡄ࠯ࠪ࠸࠲࠱࠲࠳࠴ࠪ࠸࠲ࠦ࠴ࡆ࠯ࠪ࠸࠲࡮ࡣࡦࠩ࠷࠸ࠥ࠴ࡃ࠮ࠩ࠷࠸࠰࠱ࠧ࠶ࡅ࠶ࡇࠥ࠴ࡃ࠺࠼ࠪ࠹ࡁ࠵࠵ࠨ࠷ࡆ࠷࠲ࠦ࠵ࡄ࠻࠹ࠫ࠲࠳ࠧ࠵ࡇ࠰ࠫ࠲࠳ࡵࡨࡶ࡮ࡧ࡬ࠦ࠴࠵ࠩ࠸ࡇࠫࠦ࠹ࡅࠩ࠷࠸ࡳࡦࡰࡧࡣࡸ࡫ࡲࡪࡣ࡯ࠩ࠷࠸ࠥ࠴ࡃ࠮ࡸࡷࡻࡥࠦ࠴ࡆ࠯ࠪ࠸࠲ࡤࡷࡶࡸࡴࡳࠥ࠳࠴ࠨ࠷ࡆ࠱ࡴࡳࡷࡨࠩ࠷ࡉࠫࠦ࠴࠵ࡷࡳࠫ࠲࠳ࠧ࠶ࡅ࠰ࠫ࠲࠳ࠧ࠵࠶ࠪ࠸ࡃࠬࠧ࠵࠶ࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࠥ࠳࠴ࠨ࠷ࡆ࠱ࠥ࠳࠴ࠨ࠶࠷ࠫ࠲ࡄ࠭ࠨ࠶࠷ࡪࡥࡷ࡫ࡦࡩࡤ࡯ࡤ࠳ࠧ࠵࠶ࠪ࠹ࡁࠬࠧ࠵࠶ࠪ࠸࠲ࠦ࠴ࡆ࠯ࠪ࠸࠲ࡥࡧࡹ࡭ࡨ࡫࡟ࡪࡦࠨ࠶࠷ࠫ࠳ࡂ࠭ࠨ࠶࠷ࠫ࠲࠳ࠧ࠺ࡈࠪ࠸ࡃࠬࠧ࠵࠶ࡵࡧࡳࡴࡹࡲࡶࡩࠫ࠲࠳ࠧ࠶ࡅ࠰ࡴࡵ࡭࡮ࠨ࠶ࡈ࠱ࠥ࠳࠴࡯ࡳ࡬࡯࡮ࠦ࠴࠵ࠩ࠸ࡇࠫ࡯ࡷ࡯ࡰࠪ࠽ࡄࠧ࡯ࡲࡨࡪࡃࡣࡩࡣࡱࡲࡪࡲࡳࠧࡩࡨࡲࡷ࡫࡟ࡪࡦࡀࠩ࠷ࡇࠧৰ")
    else:
        Addon = xbmcaddon.Addon(addon)
        if addon == l11ll11l1_opy_:
            username =  Addon.getSetting(l1ll11_opy_ (u"࡚ࠫࡹࡥࡳࡰࡤࡱࡪ࠭ৱ"))
            password =  Addon.getSetting(l1ll11_opy_ (u"ࠬࡖࡡࡴࡵࡺࡳࡷࡪࠧ৲"))
        else:
            username =  Addon.getSetting(l1ll11_opy_ (u"࠭࡫ࡢࡵࡸࡸࡦࡰࡡ࡯࡫ࡰ࡭ࠬ৳"))
            password =  Addon.getSetting(l1ll11_opy_ (u"ࠧࡴࡣ࡯ࡥࡸࡵ࡮ࡢࠩ৴"))
        l11ll111l_opy_     = l1ll11_opy_ (u"ࠨ࠱ࡂࡥࡨࡺࡩࡰࡰࡀࡷࡹࡸࡥࡢ࡯ࡢࡺ࡮ࡪࡥࡰࠨࡨࡼࡹࡸࡡࠧࡲࡤ࡫ࡪࠬࡰ࡭ࡱࡷࠪࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠽ࠧࡶ࡬ࡸࡱ࡫࠽ࡂ࡮࡯ࠪࡺࡸ࡬࠾ࠩ৵")
        l1l1lll1l_opy_  =  l1ll11l1l_opy_(addon)
        l1l11llll_opy_   = l1ll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ৶") + addon
        l11llll1l_opy_  =  l1l11llll_opy_ + l11ll111l_opy_ + l1l1lll1l_opy_
        l1l1111l1_opy_ = l1ll11_opy_ (u"ࠪࡹࡸ࡫ࡲ࡯ࡣࡰࡩࡂ࠭৷") + username + l1ll11_opy_ (u"ࠫࠫࡶࡡࡴࡵࡺࡳࡷࡪ࠽ࠨ৸") + password + l1ll11_opy_ (u"ࠬࠬࡴࡺࡲࡨࡁ࡬࡫ࡴࡠ࡮࡬ࡺࡪࡥࡳࡵࡴࡨࡥࡲࡹࠦࡤࡣࡷࡣ࡮ࡪ࠽࠱ࠩ৹")
        return l11llll1l_opy_ + urllib.quote_plus(l1l1111l1_opy_)
def l1ll11l1l_opy_(addon):
    if (addon == l11llll11_opy_) or (addon == l1l11111l_opy_):
        return l1ll11_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠳࠸࠰࠴࠼࠼࠴࠱࠴࠻࠱࠵࠺࠻࠺࠹࠲࠳࠴࠴࡫࡮ࡪࡩࡰࡥ࠷࠴ࡰࡩࡲࡂࠫ৺")
    if addon == l11ll1l1l_opy_:
        return l1ll11_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡲ࡬ࡲࡿࡺࡶࡱࡴࡲ࠲ࡹࡱ࠺࠹࠲࠳࠴࠴࡫࡮ࡪࡩࡰࡥ࠷࠴ࡰࡩࡲࡂࠫ৻")
    if addon == l11ll11l1_opy_:
        return l1ll11_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡱࡷࡸࡹࡼ࠮ࡨࡣ࠽࠶࠵࠿࠵࠰ࡧࡱ࡭࡬ࡳࡡ࠳࠰ࡳ࡬ࡵࡅࠧৼ")
def l1l1ll_opy_(addon, l1l1l_opy_):
    if (addon == l11llll11_opy_) or (addon == l1l11111l_opy_):
        l1l1l_opy_ = l1l1l_opy_.replace(l1ll11_opy_ (u"ࠩࠣࠤࠬ৽"), l1ll11_opy_ (u"ࠪࠤࠬ৾")).replace(l1ll11_opy_ (u"ࠫࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ৿"), l1ll11_opy_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ਀"))
        return l1l1l_opy_
    return l1l1l_opy_
def l11lll1l1_opy_(addon, l11llllll_opy_):
    if (addon == l11llll11_opy_) or (addon == l1l11111l_opy_):
        channel = l11llllll_opy_.rsplit(l1ll11_opy_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨਁ"), 1)[0].split(l1ll11_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡸࡪ࡬ࡸࡪࡣࠧਂ"), 1)[-1]
        channel = channel.replace(l1ll11_opy_ (u"ࠨࡄࡅࡇࠥ࠷ࠧਃ"), l1ll11_opy_ (u"ࠩࡅࡆࡈࠦࡏ࡯ࡧࠪ਄")).replace(l1ll11_opy_ (u"ࠪࡆࡇࡉࠠ࠳ࠩਅ"), l1ll11_opy_ (u"ࠫࡇࡈࡃࠡࡖࡺࡳࠬਆ")).replace(l1ll11_opy_ (u"ࠬࡈࡂࡄࠢ࠷ࠫਇ"), l1ll11_opy_ (u"࠭ࡂࡃࡅࠣࡊࡔ࡛ࡒࠨਈ")).replace(l1ll11_opy_ (u"ࠧࡊࡖ࡙ࠤ࠶࠭ਉ"), l1ll11_opy_ (u"ࠨࡋࡗ࡚࠶࠭ਊ")).replace(l1ll11_opy_ (u"ࠩࡌࡘ࡛ࠦ࠲ࠨ਋"), l1ll11_opy_ (u"ࠪࡍ࡙࡜࠲ࠨ਌")).replace(l1ll11_opy_ (u"ࠫࡎ࡚ࡖࠡ࠵ࠪ਍"), l1ll11_opy_ (u"ࠬࡏࡔࡗ࠵ࠪ਎")).replace(l1ll11_opy_ (u"࠭ࡉࡕࡘࠣ࠸ࠬਏ"), l1ll11_opy_ (u"ࠧࡊࡖ࡙࠸ࠬਐ"))
        return channel
    if (addon == l11ll1l11_opy_) or (addon == l11lllll1_opy_):
        channel = l11llllll_opy_.rsplit(l1ll11_opy_ (u"ࠨࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ਑"))[0].replace(l1ll11_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡺ࡬࡮ࡺࡥ࡞ࠩ਒"), l1ll11_opy_ (u"ࠪࠫਓ"))
        channel = channel.replace(l1ll11_opy_ (u"ࠫ࠿࠭ਔ"), l1ll11_opy_ (u"ࠬ࠭ਕ")).replace(l1ll11_opy_ (u"࠭ࡂࡃࡅࠣ࠵ࠬਖ"), l1ll11_opy_ (u"ࠧࡃࡄࡆࠤࡔࡴࡥࠨਗ")).replace(l1ll11_opy_ (u"ࠨࡄࡅࡇࠥ࠸ࠧਘ"), l1ll11_opy_ (u"ࠩࡅࡆࡈࠦࡔࡸࡱࠪਙ")).replace(l1ll11_opy_ (u"ࠪࡆࡇࡉࠠ࠵ࠩਚ"), l1ll11_opy_ (u"ࠫࡇࡈࡃࠡࡈࡒ࡙ࡗ࠭ਛ")).replace(l1ll11_opy_ (u"ࠬࡏࡔࡗࠢ࠴ࠫਜ"), l1ll11_opy_ (u"࠭ࡉࡕࡘ࠴ࠫਝ")).replace(l1ll11_opy_ (u"ࠧࡊࡖ࡙ࠤ࠷࠭ਞ"), l1ll11_opy_ (u"ࠨࡋࡗ࡚࠷࠭ਟ")).replace(l1ll11_opy_ (u"ࠩࡌࡘ࡛ࠦ࠳ࠨਠ"), l1ll11_opy_ (u"ࠪࡍ࡙࡜࠳ࠨਡ")).replace(l1ll11_opy_ (u"ࠫࡎ࡚ࡖࠡ࠶ࠪਢ"), l1ll11_opy_ (u"ࠬࡏࡔࡗ࠶ࠪਣ"))
        return channel
    else:
        channel = l11llllll_opy_.replace(l1ll11_opy_ (u"࠭ࡂࡃࡅࠣ࠵ࠬਤ"), l1ll11_opy_ (u"ࠧࡃࡄࡆࠤࡔࡴࡥࠨਥ")).replace(l1ll11_opy_ (u"ࠨࡄࡅࡇࠥ࠸ࠧਦ"), l1ll11_opy_ (u"ࠩࡅࡆࡈࠦࡔࡸࡱࠪਧ")).replace(l1ll11_opy_ (u"ࠪࡆࡇࡉࠠ࠵ࠩਨ"), l1ll11_opy_ (u"ࠫࡇࡈࡃࠡࡈࡒ࡙ࡗ࠭਩")).replace(l1ll11_opy_ (u"ࠬࡏࡔࡗࠢ࠴ࠫਪ"), l1ll11_opy_ (u"࠭ࡉࡕࡘ࠴ࠫਫ")).replace(l1ll11_opy_ (u"ࠧࡊࡖ࡙ࠤ࠷࠭ਬ"), l1ll11_opy_ (u"ࠨࡋࡗ࡚࠷࠭ਭ")).replace(l1ll11_opy_ (u"ࠩࡌࡘ࡛ࠦ࠳ࠨਮ"), l1ll11_opy_ (u"ࠪࡍ࡙࡜࠳ࠨਯ")).replace(l1ll11_opy_ (u"ࠫࡎ࡚ࡖࠡ࠶ࠪਰ"), l1ll11_opy_ (u"ࠬࡏࡔࡗ࠶ࠪ਱"))
        return channel
def l1111l_opy_(e):
    l1111_opy_ = l1ll11_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠱ࠦࡡ࡯ࠢࡨࡶࡷࡵࡲࠡࡱࡦࡧࡺࡸࡥࡥ࠼ࠣࡎࡘࡕࡎࠡࡇࡵࡶࡴࡸ࠺ࠡࠧࡶࠫਲ")  %e
    l111l_opy_ = l1ll11_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡤࡱࡱࡸࡦࡩࡴࠡࡷࡶࠤࡴࡴࠠࡵࡪࡨࠤ࡫ࡵࡲࡶ࡯࠱ࠫਲ਼")
    l11l1_opy_ = l1ll11_opy_ (u"ࠨࡗࡳࡰࡴࡧࡤࠡࡣࠣࡰࡴ࡭ࠠࡷ࡫ࡤࠤࡹ࡮ࡥࠡࡣࡧࡨࡴࡴࠠࡴࡧࡷࡸ࡮ࡴࡧࡴࠢࡤࡲࡩࠦࡰࡰࡵࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰ࠴ࠧ਴")
    dixie.log(e)
    dixie.DialogOK(l1111_opy_, l111l_opy_, l11l1_opy_)
    dixie.SetSetting(SETTING, l1ll11_opy_ (u"ࠩࠪਵ"))