# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l11ll1_opy_ = 2048
l1l11_opy_ = 7
def l1ll11_opy_ (ll_opy_):
	global l11lll_opy_
	l1lll11_opy_ = ord (ll_opy_ [-1])
	l1l11l_opy_ = ll_opy_ [:-1]
	l111l1_opy_ = l1lll11_opy_ % len (l1l11l_opy_)
	l1ll1_opy_ = l1l11l_opy_ [:l111l1_opy_] + l1l11l_opy_ [l111l1_opy_:]
	if l1_opy_:
		l111ll_opy_ = unicode () .join ([unichr (ord (char) - l11ll1_opy_ - (l1lll1_opy_ + l1lll11_opy_) % l1l11_opy_) for l1lll1_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l111ll_opy_ = str () .join ([chr (ord (char) - l11ll1_opy_ - (l1lll1_opy_ + l1lll11_opy_) % l1l11_opy_) for l1lll1_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l111ll_opy_)
import xbmc
import xbmcgui
import json
import os
import dixie
l1llll1_opy_ = l1ll11_opy_ (u"ࠫࠬࠀ")
def l1ll11l_opy_(i, t1, l1lll1l_opy_=[]):
 t = l1llll1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1lll1l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11l_opy_ = l1ll11l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11_opy_ = l1ll11l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
l11l1l_opy_  = l1ll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸࠨࠁ")
PATH = os.path.join(dixie.PROFILE, l1ll11_opy_ (u"࠭ࡤࡵࡧࡰࡴࠬࠂ"))
def createINI():
    if xbmc.getCondVisibility(l1ll11_opy_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡉࡣࡶࡅࡩࡪ࡯࡯ࠪࠨࡷ࠮࠭ࠃ") % l11l1l_opy_) == 1:
        HOME = dixie.PROFILE
        PATH = os.path.join(HOME, l1ll11_opy_ (u"ࠨ࡫ࡱ࡭ࠬࠄ"))
        l111_opy_ = l1ll11_opy_ (u"ࠩࡧࡩࡽࡺࡥࡳ࠰࡬ࡲ࡮࠭ࠅ")
        l1l_opy_  = os.path.join(PATH, l111_opy_)
        response = doJSON()
        l11111_opy_ = response[l1ll11_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪࠆ")][l1ll11_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪࠇ")]
        l1l1l1_opy_  = l1ll11_opy_ (u"ࠬࡡࠧࠈ") + l11l1l_opy_ + l1ll11_opy_ (u"࠭࡝࡝ࡰࠪࠉ")
        l1l1_opy_  =  file(l1l_opy_, l1ll11_opy_ (u"ࠧࡸࠩࠊ"))
        l1l1_opy_.write(l1l1l1_opy_)
        l11ll_opy_ = []
        for channel in l11111_opy_:
            l1ll1l_opy_ =  channel[l1ll11_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࠋ")]
            l1ll1ll_opy_ =  l1l1ll_opy_(l1ll1l_opy_)
            l1ll_opy_ =  dixie.mapChannelName(l1ll1ll_opy_)
            stream   = l1ll11_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡅ࠼ࠪࠌ") + l1ll1l_opy_
            l1lll_opy_  =  l1ll_opy_ + l1ll11_opy_ (u"ࠪࡁࠬࠍ") + stream
            if l1lll_opy_ not in l11ll_opy_:
                l11ll_opy_.append(l1lll_opy_)
        l11ll_opy_.sort()
        for item in l11ll_opy_:
            l1l1_opy_.write(l1ll11_opy_ (u"ࠦࠪࡹ࡜࡯ࠤࠎ") % item)
        l1l1_opy_.close()
def l1l1ll_opy_(l1l1l_opy_):
    l1l1l_opy_ = l1l1l_opy_.replace(l1ll11_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡹ࡫ࡺࡤ࡯ࡹࡪࡣ࡛ࡃ࡟ࡘࡗࡆ࡛ࠦࡄࡑࡏࡓࡗࠦ࡯࡭ࡦ࡯ࡥࡨ࡫࡝ࠨࠏ"), l1ll11_opy_ (u"࠭ࠧࠐ"))
    l1l1l_opy_ = l1l1l_opy_.replace(l1ll11_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡱࡣ࡯ࡩ࡬ࡸࡥࡦࡰࡠ࡟ࡇࡣ࠲࠵࠹ࠣ࡟ࡈࡕࡌࡐࡔࠣࡳࡱࡪ࡬ࡢࡥࡨࡡࠬࠑ"), l1ll11_opy_ (u"ࠨࠩࠒ"))
    l1l1l_opy_ = l1l1l_opy_.replace(l1ll11_opy_ (u"ࠩ࡞࠳ࡇࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠡࠩࠓ"), l1ll11_opy_ (u"ࠪࠫࠔ"))
    l1l1l_opy_ = l1l1l_opy_.replace(l1ll11_opy_ (u"ࠫࡠ࠵ࡂ࡞࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࠕ"), l1ll11_opy_ (u"ࠬ࠭ࠖ"))
    l1l1l_opy_ = l1l1l_opy_.replace(l1ll11_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡹࡦ࡮࡯ࡳࡼࡣࠧࠗ"), l1ll11_opy_ (u"ࠧࠨ࠘"))
    l1l1l_opy_ = l1l1l_opy_.replace(l1ll11_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣ࡟ࡈࡕࡌࡐࡔࠣࡻ࡭࡯ࡴࡦ࡟࡞ࡆࡢ࠭࠙"), l1ll11_opy_ (u"ࠩࠪࠚ"))
    l1l1l_opy_ = l1l1l_opy_.replace(l1ll11_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡷࡧࡹ࡞࡝ࡌࡡࠬࠛ"), l1ll11_opy_ (u"ࠫࠬࠜ"))
    l1l1l_opy_ = l1l1l_opy_.replace(l1ll11_opy_ (u"ࠬࡡ࠯ࡊ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫࠝ"), l1ll11_opy_ (u"࠭ࠧࠞ"))
    return l1l1l_opy_
def getURL(url):
    if not l1llll_opy_() == l1ll11_opy_ (u"ࠧࡕࡴࡸࡩࠬࠟ"):
        return
    if url.startswith(l1ll11_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡃࡍࡗ࠽ࠫࠠ")):
        url = url.replace(l1ll11_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡄࡎࡘ࠾ࠬࠡ"), l1ll11_opy_ (u"ࠪࠫࠢ")).replace(l1ll11_opy_ (u"ࠫ࠲࠳ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪࠣ"), l1ll11_opy_ (u"ࠬࢂࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪࠤ"))
        return url
    if url.startswith(l1ll11_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡉࡀࠧࠥ")):
        return l11l11_opy_(url)
    response = l1ll1l1_opy_(url)
    stream   = url.split(l1ll11_opy_ (u"ࠧ࠻ࠩࠦ"), 1)[-1]
    try:
        result = response[l1ll11_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨࠧ")]
        l1l111_opy_  = result[l1ll11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡳࠨࠨ")]
    except Exception as e:
        l1111l_opy_(e)
        return None
    for file in l1l111_opy_:
        l1l1l_opy_ = file[l1ll11_opy_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࠩ")]
        if stream in l1l1l_opy_:
            return file[l1ll11_opy_ (u"ࠫ࡫࡯࡬ࡦࠩࠪ")]
    return None
def l11l11_opy_(url):
    if os.path.exists(PATH):
        response = json.load(open(PATH))
    else:
        response = doJSON()
    stream = url.split(l1ll11_opy_ (u"ࠬࡀࠧࠫ"), 1)[-1]
    l1l111_opy_  = response[l1ll11_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ࠬ")][l1ll11_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭࠭")]
    for file in l1l111_opy_:
        l1l1l_opy_ = file[l1ll11_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧ࠮")]
        if stream in l1l1l_opy_:
            return file[l1ll11_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧ࠯")]
def doJSON():
    l1lllll_opy_  = (l1ll11_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡤࡦࡺ࠲ࡃࡦࡩࡴࡪࡱࡱࡁࡦࡲ࡬ࠧࡧࡻࡸࡷࡧࠦࡱࡣࡪࡩࠫࡶ࡬ࡰࡶࠩࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡃࠦࡵ࡫ࡷࡰࡪࡃࠥ࠶ࡤࡆࡓࡑࡕࡒࠦ࠴࠳ࡻ࡭࡯ࡴࡦࠧ࠸ࡨࡆࡲ࡬ࠦ࠴࠳ࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠪ࠻ࡢࠦ࠴ࡩࡇࡔࡒࡏࡓࠧ࠸ࡨࠫࡻࡲ࡭ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧ࠰"))
    response = xbmc.executeJSONRPC(l1lllll_opy_)
    content  = json.loads(response)
    json.dump(content, open(PATH,l1ll11_opy_ (u"ࠫࡼ࠭࠱")), indent=3)
    return json.load(open(PATH))
def l1ll1l1_opy_(url):
    if url.startswith(l1ll11_opy_ (u"ࠬࡏࡐࡍࡃ࡜࠾ࠬ࠲")):
        l1lllll_opy_ = (l1ll11_opy_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡆࡪ࡮ࡨࡷ࠳ࡍࡥࡵࡆ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠨ࠺ࠣࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡥࡦࡨ࡯ࡰ࡭ࡣࡼࡩࡷ࠵࠿ࡶࡴ࡯ࡁࡺࡸ࡬ࠧ࡯ࡲࡨࡪࡃ࠲ࠧࡰࡤࡱࡪࡃࡌࡪࡸࡨࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࡃࠦࡊࡒࡌࡈࡂࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫ࠳"))
    if url.startswith(l1ll11_opy_ (u"ࠧࡊࡒࡏࡅ࡞࠸࠺ࠨ࠴")):
        l1lllll_opy_ = (l1ll11_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡶ࡬ࡢࡻࡨࡶࡼࡽࡷ࠰ࡁࡸࡶࡱࡃࡵࡳ࡮ࠩࡱࡴࡪࡥ࠾࠳࠳࠵ࠫࡴࡡ࡮ࡧࡀ࡛ࡦࡺࡣࡩ࠭ࡏ࡭ࡻ࡫ࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠩࡷࡺࡨࡴࡪࡶ࡯ࡩࡸࡥࡵࡳ࡮ࡀࠪࡱࡵࡧࡨࡧࡧࡣ࡮ࡴ࠽ࡇࡣ࡯ࡷࡪࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫ࠵"))
    if url.startswith(l1ll11_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡓ࠼ࠪ࠶")):
        l1lllll_opy_ = (l1ll11_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱ࡮ࡤࡽࡪࡸࡷࡸࡹ࠲ࡃࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠨ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࡂࡊࡥࡧࡣࡸࡰࡹࡌ࡯࡭ࡦࡨࡶ࠳ࡶ࡮ࡨࠨ࡯ࡳ࡬࡭ࡥࡥࡡ࡬ࡲࡂࡌࡡ࡭ࡵࡨࠪࡲࡵࡤࡦ࠿࠴࠵࠸ࠬ࡮ࡢ࡯ࡨࡁࡑ࡯ࡳࡵࡧࡱࠩ࠷࠶ࡌࡪࡸࡨࠪࡸࡻࡢࡵ࡫ࡷࡰࡪࡹ࡟ࡶࡴ࡯ࠪࡺࡸ࡬࠾ࡷࡵࡰࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ࠷"))
    if url.startswith(l1ll11_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡌࡘ࡛ࡀࠧ࠸")):
        l1lllll_opy_ = (l1ll11_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡷࡺࠧࢃࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ࠹"))
    if url.startswith(l1ll11_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡉࡀࠧ࠺")):
        l1lllll_opy_ = (l1ll11_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡨࡪࡾ࠯ࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡣ࡯ࡰࠫ࡫ࡸࡵࡴࡤࠪࡵࡧࡧࡦࠨࡳࡰࡴࡺࠦࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡀࠪࡹ࡯ࡴ࡭ࡧࡀࠩ࠺ࡨࡃࡐࡎࡒࡖࠪ࠸࠰ࡸࡪ࡬ࡸࡪࠫ࠵ࡥࡃ࡯ࡰࠪ࠸࠰ࡄࡪࡤࡲࡳ࡫࡬ࡴࠧ࠸ࡦࠪ࠸ࡦࡄࡑࡏࡓࡗࠫ࠵ࡥࠨࡸࡶࡱࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫ࠻"))
    if url.startswith(l1ll11_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡒࡃ࠼ࠪ࠼")):
        l1lllll_opy_ = (l1ll11_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡥࡣࡱࡲࡸ࠴ࡅࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠪ࡫ࡧ࡮ࡢࡴࡷࡁࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡰࡳࡩ࡫࠽࠸ࠨࡳ࡭ࡱࡲ࡯ࡸ࠿ࡏ࡭ࡻ࡫ࠥ࠳࠲ࡖࡸࡷ࡫ࡡ࡮ࡵࠩࡹࡷࡲ࠽ࡳࡣࡱࡨࡴࡳࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬ࠽"))
    if url.startswith(l1ll11_opy_ (u"ࠪࡍࡕ࡚ࡓ࠻ࠩ࠾")):
        l1lllll_opy_ = (l1ll11_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥ࡮ࡶࡴࡷ࠱ࡂࡥࡨࡺࡩࡰࡰࡀࡰ࡮ࡼࡥࡵࡸࡢࡥࡱࡲࠦࡦࡺࡷࡶࡦࠬࡰࡢࡩࡨࠪࡵࡲ࡯ࡵࠨࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡂࠬࡴࡪࡶ࡯ࡩࡂࡇ࡬࡭ࠧ࠵࠴ࡨ࡮ࡡ࡯ࡰࡨࡰࡸࠬࡵࡳ࡮ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ࠿"))
    try:
        dixie.ShowBusy()
        addon =  l1lllll_opy_.split(l1ll11_opy_ (u"ࠬ࠵࠯ࠨࡀ"), 1)[-1].split(l1ll11_opy_ (u"࠭࠯ࠨࡁ"), 1)[0]
        login = l1ll11_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬࡂ") % addon
        xbmc.executeJSONRPC(login)
        response = xbmc.executeJSONRPC(l1lllll_opy_)
        dixie.log(response)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1111l_opy_(e)
        return {l1ll11_opy_ (u"ࠨࡇࡵࡶࡴࡸࠧࡃ") : l1ll11_opy_ (u"ࠩࡓࡰࡺ࡭ࡩ࡯ࠢࡈࡶࡷࡵࡲࠨࡄ")}
def l1llll_opy_():
    modules = map(__import__, [l1ll11l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11l_opy_)):
        return l1ll11_opy_ (u"ࠪࡘࡷࡻࡥࠨࡅ")
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l1ll11_opy_ (u"࡙ࠫࡸࡵࡦࠩࡆ")
    return l1ll11_opy_ (u"ࠬࡌࡡ࡭ࡵࡨࠫࡇ")
def l1111l_opy_(e):
    l1111_opy_ = l1ll11_opy_ (u"࠭ࡓࡰࡴࡵࡽ࠱ࠦࡡ࡯ࠢࡨࡶࡷࡵࡲࠡࡱࡦࡧࡺࡸࡥࡥ࠼ࠣࡎࡘࡕࡎࠡࡇࡵࡶࡴࡸ࠺ࠡࠧࡶࠫࡈ")  %e
    l111l_opy_ = l1ll11_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡳࡧ࠰ࡰ࡮ࡴ࡫ࠡࡶ࡫࡭ࡸࠦࡣࡩࡣࡱࡲࡪࡲࠠࡢࡰࡧࠤࡹࡸࡹࠡࡣࡪࡥ࡮ࡴ࠮ࠨࡉ")
    l11l1_opy_ = l1ll11_opy_ (u"ࠨࡗࡶࡩ࠿ࠦࡃࡰࡰࡷࡩࡽࡺࠠࡎࡧࡱࡹࠥࡃ࠾ࠡࡔࡨࡱࡴࡼࡥࠡࡕࡷࡶࡪࡧ࡭ࠨࡊ")
    dixie.log(e)
    dixie.DialogOK(l1111_opy_, l111l_opy_, l11l1_opy_)