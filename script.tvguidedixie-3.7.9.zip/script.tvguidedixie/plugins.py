# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l11ll1_opy_ = 2048
l1l11_opy_ = 7
def l1ll11_opy_ (ll_opy_):
	global l11lll_opy_
	l1lll11_opy_ = ord (ll_opy_ [-1])
	l1l11l_opy_ = ll_opy_ [:-1]
	l111l1_opy_ = l1lll11_opy_ % len (l1l11l_opy_)
	l1ll1_opy_ = l1l11l_opy_ [:l111l1_opy_] + l1l11l_opy_ [l111l1_opy_:]
	if l1_opy_:
		l111ll_opy_ = unicode () .join ([unichr (ord (char) - l11ll1_opy_ - (l1lll1_opy_ + l1lll11_opy_) % l1l11_opy_) for l1lll1_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l111ll_opy_ = str () .join ([chr (ord (char) - l11ll1_opy_ - (l1lll1_opy_ + l1lll11_opy_) % l1l11_opy_) for l1lll1_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l111ll_opy_)
import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie
l1l1l1l11_opy_    = l1ll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡲࡹࡼࠧ࣠")
l1ll11111_opy_    = l1ll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡶࡴ࡮ࠫ࣡")
locked = l1ll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲ࡯ࡤ࡭ࡨࡨࡹࡼࠧ࣢")
l1l11l11l_opy_   = l1ll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡵࡴࡨࡥࡲࡺࡶࡣࡱࡻࣣࠫ")
l1ll111l1_opy_     = l1ll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡲࡲࡶࡹࡹ࡭ࡢࡰ࡬ࡥࠬࣤ")
l1l1ll1l1_opy_     = l1ll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡵࡳࡳࡷࡺࡳ࡯ࡣࡷ࡭ࡴࡴࡨࡥࡶࡹࠫࣥ")
l1l11ll11_opy_     = l1ll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡸࡰࡹ࡯࡭ࡢࡶࡨࡱࡦࡴࡩࡢࣦࠩ")
l1l111l1l_opy_   = l1ll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡰ࡮ࡻࡸ࠯ࡶࡹࠫࣧ")
l1l1l111l_opy_    = l1ll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡉࡉࡓࡱࡱࡵࡸࡸ࠭ࣨ")
l1l1lllll_opy_ = l1ll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡸࡥࡣࡱࡲࡸࣩࠬ")
l1l1l11l1_opy_    = l1ll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡣ࡭ࡷ࡬ࡴࡹࡼࠧ࣪")
l1l1l1l1l_opy_ = l1ll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡴࡶࡵࡩࡦࡳࡳࡦࡣࡶࡽ࠳ࡺࡶࠨ࣫")
l1l1lll11_opy_ = l1ll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦ࡯ࡰࡵࡸࠪ࣬")
l1l111lll_opy_ = [l1l1l1l11_opy_, locked, l1l111l1l_opy_, l1l1l1l1l_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1ll11_opy_ (u"ࠪ࡭ࡳ࡯࣭ࠧ"))
OPEN_OTT  = dixie.OPEN_OTT
CLOSE_OTT = dixie.CLOSE_OTT
l1llll1_opy_ = l1ll11_opy_ (u"࣮ࠫࠬ")
def l1ll11l_opy_(i, t1, l1lll1l_opy_=[]):
 t = l1llll1_opy_
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 for c in l1lll1l_opy_:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t
l11l_opy_ = l1ll11l_opy_(0,[79,98,84,141,84,68,95,248,82],[189,85,0,78,245,78,83,73,147,78,11,71])
l11_opy_ = l1ll11l_opy_(191,[106,79,109,84,70,84,112,95,252,79,57,83,3,68,163,95,50,82,125,85,51,78,28,78],[215,73,180,78,40,71])
def checkAddons():
    for addon in l1l111lll_opy_:
        if l1l1l1l_opy_(addon):
            try:
                createINI(addon)
            except: pass
def l1l1l1l_opy_(addon):
    if xbmc.getCondVisibility(l1ll11_opy_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠦࡵ࣯ࠬࠫ") % addon) == 1:
        return True
    return False
def createINI(addon):
    l111_opy_ = str(addon).split(l1ll11_opy_ (u"࠭࠮ࠨࣰ"))[2] + l1ll11_opy_ (u"ࠧ࠯࡫ࡱ࡭ࣱࠬ")
    l1l_opy_  = os.path.join(PATH, l111_opy_)
    try:
        l11111_opy_ = l1ll11ll1_opy_(addon)
    except KeyError:
        dixie.log(l1ll11_opy_ (u"ࠨ࠯࠰࠱࠲࠳ࠠࡌࡧࡼࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥ࡭ࡥࡵࡈ࡬ࡰࡪࡹࠠ࠮࠯࠰࠱࠲ࣲࠦࠧ") + addon)
        result = {l1ll11_opy_ (u"ࡷࠪࡪ࡮ࡲࡥࡴࠩࣳ"): [{l1ll11_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭ࣴ"): l1ll11_opy_ (u"ࡹࠬ࡬ࡩ࡭ࡧࠪࣵ"), l1ll11_opy_ (u"ࡺ࠭ࡴࡺࡲࡨࣶࠫ"): l1ll11_opy_ (u"ࡻࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨࣷ"), l1ll11_opy_ (u"ࡵࠨࡨ࡬ࡰࡪ࠭ࣸ"): l1ll11_opy_ (u"ࡶࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡽࡾࣹࠧ"), l1ll11_opy_ (u"ࡷࠪࡰࡦࡨࡥ࡭ࣺࠩ"): l1ll11_opy_ (u"ࡸࠫࡓࡕࠠࡄࡊࡄࡒࡓࡋࡌࡔࠩࣻ")}], l1ll11_opy_ (u"ࡹࠬࡲࡩ࡮࡫ࡷࡷࠬࣼ"):{l1ll11_opy_ (u"ࡺ࠭ࡳࡵࡣࡵࡸࠬࣽ"): 0, l1ll11_opy_ (u"ࡻࠧࡵࡱࡷࡥࡱ࠭ࣾ"): 1, l1ll11_opy_ (u"ࡵࠨࡧࡱࡨࠬࣿ"): 1}}
    l1l1_opy_  = file(l1l_opy_, l1ll11_opy_ (u"ࠨࡹࠪऀ"))
    l1l1_opy_.write(l1ll11_opy_ (u"ࠩ࡞ࠫँ"))
    l1l1_opy_.write(addon)
    l1l1_opy_.write(l1ll11_opy_ (u"ࠪࡡࠬं"))
    l1l1_opy_.write(l1ll11_opy_ (u"ࠫࡡࡴࠧः"))
    l11ll_opy_ = []
    for channel in l11111_opy_:
        l1l1l_opy_    = channel[l1ll11_opy_ (u"ࠬࡲࡡࡣࡧ࡯ࠫऄ")].replace(l1ll11_opy_ (u"࡛࠭ࡃ࡟࡞ࡇࡔࡒࡏࡓࠢࡺ࡬࡮ࡺࡥ࡞ࠩअ"), l1ll11_opy_ (u"ࠧࠨआ")).replace(l1ll11_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟࡞࠳ࡇࡣࠧइ"), l1ll11_opy_ (u"ࠩࠪई")).replace(l1ll11_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡷ࡫ࡥ࡯࡟ࡋࡈࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭उ"), l1ll11_opy_ (u"ࠫࡍࡊࡄࠨऊ"))
        l1l1l_opy_    = l1l1l_opy_.replace(l1ll11_opy_ (u"ࠬࢂࠧऋ"), l1ll11_opy_ (u"࠭ࠧऌ")).replace(l1ll11_opy_ (u"ࠧ࠰ࠩऍ"), l1ll11_opy_ (u"ࠨࠩऎ")).replace(l1ll11_opy_ (u"ࠩࠣࠤࠥࠦࠠࠨए"), l1ll11_opy_ (u"ࠪࠤࠬऐ")).replace(l1ll11_opy_ (u"ࠫ࠳࠴࠮࠯࠰ࠪऑ"), l1ll11_opy_ (u"ࠬ࠭ऒ")).replace(l1ll11_opy_ (u"࠭࠺ࠨओ"), l1ll11_opy_ (u"ࠧࠨऔ"))
        l1l1l_opy_    = l1l1l_opy_.replace(l1ll11_opy_ (u"ࠨ࡟ࠣࠫक"), l1ll11_opy_ (u"ࠩࡠࠫख")).replace(l1ll11_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡥࡶࡻࡡ࡞ࠩग"), l1ll11_opy_ (u"ࠫࠬघ")).replace(l1ll11_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡽࡨࡪࡶࡨࡡࠬङ"), l1ll11_opy_ (u"࠭ࠧच")).replace(l1ll11_opy_ (u"ࠧࠡ࡝ࠪछ"), l1ll11_opy_ (u"ࠨ࡝ࠪज"))
        l1l1l_opy_    = l1l1l_opy_.replace(l1ll11_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢ࡯࡭ࡲ࡫ࡧࡳࡧࡨࡲࡢ࠭झ"), l1ll11_opy_ (u"ࠪࠫञ")).replace(l1ll11_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡾ࡫࡬࡭ࡱࡺࡡࠬट"), l1ll11_opy_ (u"ࠬ࠭ठ"))
        l1l1l_opy_    = l1l1l_opy_.replace(l1ll11_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࠬड"), l1ll11_opy_ (u"ࠧࠨढ")).replace(l1ll11_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡱࡵࡥࡳ࡭ࡥ࡞ࠩण"), l1ll11_opy_ (u"ࠩࠪत")).replace(l1ll11_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࠨथ"), l1ll11_opy_ (u"ࠫࠬद"))
        l1l1l_opy_    = l1l1l_opy_.replace(l1ll11_opy_ (u"ࠬࡡࡉ࡞ࠩध"), l1ll11_opy_ (u"࠭ࠧन")).replace(l1ll11_opy_ (u"ࠧ࡜࠱ࡌࡡࠬऩ"), l1ll11_opy_ (u"ࠨࠩप")).replace(l1ll11_opy_ (u"ࠩ࡞ࡆࡢ࠭फ"), l1ll11_opy_ (u"ࠪࠫब")).replace(l1ll11_opy_ (u"ࠫࡠ࠵ࡂ࡞ࠩभ"), l1ll11_opy_ (u"ࠬ࠭म"))
        l1ll_opy_ = dixie.mapChannelName(l1l1l_opy_)
        stream   = channel[l1ll11_opy_ (u"࠭ࡦࡪ࡮ࡨࠫय")]
        l1lll_opy_ = l1ll_opy_ + l1ll11_opy_ (u"ࠧ࠾ࠩर") + stream
        l11ll_opy_.append(l1lll_opy_)
        l11ll_opy_.sort()
    for item in l11ll_opy_:
        l1l1_opy_.write(l1ll11_opy_ (u"ࠣࠧࡶࡠࡳࠨऱ") % item)
    l1l1_opy_.close()
def l1ll11ll1_opy_(addon):
    if (addon == l1l111l1l_opy_) or (addon == locked):
        return l1l1ll11l_opy_(addon)
    l1l11llll_opy_  = l1ll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬल") + addon
    l1l1lll1l_opy_ =  l1ll11l1l_opy_(addon)
    query   =  l1l11llll_opy_ + l1l1lll1l_opy_
    return sendJSON(query, addon)
def l1l1ll11l_opy_(addon):
    if addon == l1l111l1l_opy_:
        l1l1ll1ll_opy_ = [l1ll11_opy_ (u"ࠪ࠹ࠬळ"), l1ll11_opy_ (u"ࠫ࠶࠶࠶ࠨऴ"), l1ll11_opy_ (u"ࠬ࠺ࠧव"), l1ll11_opy_ (u"࠭࠲࠷࠵ࠪश"), l1ll11_opy_ (u"ࠧ࠲࠵࠵ࠫष")]
    if addon == locked:
        l1l1ll1ll_opy_ = [l1ll11_opy_ (u"ࠨ࠵࠳ࠫस"), l1ll11_opy_ (u"ࠩ࠶࠵ࠬह"), l1ll11_opy_ (u"ࠪ࠷࠷࠭ऺ"), l1ll11_opy_ (u"ࠫ࠸࠹ࠧऻ"), l1ll11_opy_ (u"ࠬ࠹࠴ࠨ़"), l1ll11_opy_ (u"࠭࠳࠶ࠩऽ"), l1ll11_opy_ (u"ࠧ࠴࠺ࠪा"), l1ll11_opy_ (u"ࠨ࠶࠳ࠫि"), l1ll11_opy_ (u"ࠩ࠷࠵ࠬी"), l1ll11_opy_ (u"ࠪ࠸࠺࠭ु"), l1ll11_opy_ (u"ࠫ࠹࠽ࠧू"), l1ll11_opy_ (u"ࠬ࠺࠹ࠨृ"), l1ll11_opy_ (u"࠭࠵࠳ࠩॄ")]
    login = l1ll11_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠪࡹ࠯ࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ॅ") % addon
    xbmc.executeJSONRPC(login)
    l1l111_opy_ = []
    for l1ll1111l_opy_ in l1l1ll1ll_opy_:
        if addon == l1l111l1l_opy_:
            l1l1llll1_opy_ = l1ll11_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡱ࡯ࡵࡹ࠰ࡷࡺ࠴ࡅ࡭ࡰࡦࡨࡣ࡮ࡪ࠽ࡤࡪࡤࡲࡳ࡫࡬ࡴࠨࡰࡳࡩ࡫࠽ࡤࡪࡤࡲࡳ࡫࡬ࡴࠨࡶࡩࡨࡺࡩࡰࡰࡢ࡭ࡩࡃࠥࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧॆ") % l1ll1111l_opy_
        if addon == locked:
            l1l1llll1_opy_ = l1ll11_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡲ࡯ࡤ࡭ࡨࡨࡹࡼ࠯ࡀࡷࡵࡰࡂࠫࡳࠧ࡯ࡲࡨࡪࡃ࠴ࠧࡰࡤࡱࡪࡃࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡵࡲࡡࡺ࠿ࠩࡨࡦࡺࡥ࠾ࠨࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴ࠽ࠧࡲࡤ࡫ࡪࡃࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬे") % l1ll1111l_opy_
        l1l1l1ll1_opy_  = xbmc.executeJSONRPC(l1l1llll1_opy_)
        response = json.loads(l1l1l1ll1_opy_)
        l1l111_opy_.extend(response[l1ll11_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪै")][l1ll11_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪॉ")])
    return l1l111_opy_
def sendJSON(query, addon):
    l1l1llll1_opy_     = l1ll11_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࠦࡵࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨॊ") % query
    l1l1l1ll1_opy_  = xbmc.executeJSONRPC(l1l1llll1_opy_)
    response = json.loads(l1l1l1ll1_opy_)
    result   = response[l1ll11_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ो")]
    return result[l1ll11_opy_ (u"ࠧࡧ࡫࡯ࡩࡸ࠭ौ")]
def l1l1l11ll_opy_(addon):
    l1l11llll_opy_ = l1ll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲्ࠫ") + addon
    l1l111l11_opy_  = l1ll11_opy_ (u"ࠩࡂࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁ࡭ࡺࡴࡱࠧ࠶ࡥࠪ࠸ࡦࠦ࠴ࡩࡱࡪࡺࡡ࡭࡭ࡨࡸࡹࡲࡥ࠯ࡥࡲࠩ࠷࡬ࡕࡌࡖࡸࡶࡰ࠷࠸࠱࠴࠵࠴࠶࠼ࠥ࠳ࡨࡷ࡬ࡺࡳࡢࡴࠧ࠵ࡪࡳ࡫ࡷࠦ࠴ࡩ࡙ࡰࠫ࠲࠶࠴࠳ࡸࡺࡸ࡫ࠦ࠴࠸࠶࠵ࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠧ࠵࠹࠷࠶࡬ࡪࡸࡨࠩ࠷࠻࠲࠱ࡶࡹ࠲࡯ࡶࡧࠧ࡯ࡲࡨࡪࡃ࠱ࠧࡰࡤࡱࡪࡃࡌࡪࡸࡨࠩ࠷࠶ࡔࡗࠨࡸࡶࡱࡃࡨࡵࡶࡳࠩ࠸ࡧࠥ࠳ࡨࠨ࠶࡫ࡳࡥࡵࡣ࡯࡯ࡪࡺࡴ࡭ࡧ࠱ࡧࡴࠫ࠲ࡧࡗࡎࡘࡺࡸ࡫࠲࠺࠳࠶࠷࠶࠱࠷ࠧ࠵ࡪࡑ࡯ࡶࡦࠧ࠵࠹࠷࠶ࡔࡗ࠰ࡷࡼࡹ࠭ॎ")
    l1l111_opy_  = []
    l1l111_opy_ += sendJSON(l1l11llll_opy_ + l1l111l11_opy_, addon)
    l1l111_opy_.sort()
    return l1l111_opy_
def l1ll11l11_opy_(addon):
    l1l11llll_opy_ = l1ll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭ॏ") + addon
    l1l111l11_opy_ = l1ll11_opy_ (u"ࠫ࠴ࡅࡦࡢࡰࡤࡶࡹࡃࡨࡵࡶࡳࠩ࠸ࡧࠥ࠳ࡨࠨ࠶࡫࡭࡯ࡰ࠰ࡪࡰࠪ࠸ࡦ࡙ࡦࡉ࠶࠽࡚ࠦ࡮ࡱࡧࡩࡂ࠷ࠦ࡯ࡣࡰࡩࡂࡒࡩࡷࡧࠨ࠶࠵࡛ࡋࠦ࠴࠳ࡗࡵࡵࡲࡵࡵࠩࡹࡷࡲ࠽ࡩࡶࡷࡴࡸࠫ࠳ࡢࠧ࠵ࡪࠪ࠸ࡦࡨࡱࡲ࠲࡬ࡲࠥ࠳ࡨ࠸ࡵࡖ࡭ࡅ࠵ࠩॐ")
    l1l111ll1_opy_ = l1ll11_opy_ (u"ࠬ࠵࠿ࡧࡣࡱࡥࡷࡺ࠽ࡩࡶࡷࡴࡸࠫ࠳ࡢࠧ࠵ࡪࠪ࠸ࡦࡨࡱࡲ࠲࡬ࡲࠥ࠳ࡨࡉ࡫࡜ࡓ࡫࡛ࠨࡰࡳࡩ࡫࠽࠲ࠨࡱࡥࡲ࡫࠽ࡍ࡫ࡹࡩࠪ࠸࠰ࡖࡕࠨ࠶࡫ࡉࡁࡏࠧ࠵࠴ࡘࡶ࡯ࡳࡶࡶࠪࡺࡸ࡬࠾ࡪࡷࡸࡵࡹࠥ࠴ࡣࠨ࠶࡫ࠫ࠲ࡧࡩࡲࡳ࠳࡭࡬ࠦ࠴ࡩࡪ࠾ࡰࡧ࠹ࡐࠪ॑")
    l1l111_opy_  = []
    l1l111_opy_ += sendJSON(l1l11llll_opy_ + l1l111l11_opy_, addon)
    l1l111_opy_ += sendJSON(l1l11llll_opy_ + l1l111ll1_opy_, addon)
    return l1l111_opy_
def l1ll11l1l_opy_(addon):
    if addon == l1l1l1l11_opy_:
        return l1ll11_opy_ (u"࠭࠯ࡀࡥࡤࡸࡂ࠳࠲ࠧࡦࡤࡸࡪࠬࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠪࡪࡴࡤࡅࡣࡷࡩࠫ࡯ࡣࡰࡰ࡬ࡱࡦ࡭ࡥ࠾ࠨࡰࡳࡩ࡫࠽࠳ࠨࡱࡥࡲ࡫࠽ࡎࡻࠨ࠶࠵ࡉࡨࡢࡰࡱࡩࡱࡹࠦࡳࡧࡦࡳࡷࡪ࡮ࡢ࡯ࡨࠪࡸࡺࡡࡳࡶࡇࡥࡹ࡫ࠦࡶࡴ࡯ࡁࡺࡸ࡬ࠨ॒")
    if addon == l1l1lll11_opy_:
        return l1ll11_opy_ (u"ࠧ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿࡯࡭ࡻ࡫ࡴࡷࡡࡤࡰࡱࠬࡥࡹࡶࡵࡥࠫࡶࡡࡨࡧࠩࡴࡱࡵࡴࠧࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡁࠫࡺࡩࡵ࡮ࡨࡁࡆࡲ࡬ࠦ࠴࠳ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠫࡻࡲ࡭ࠩ॓")
    return l1ll11_opy_ (u"ࠨࠩ॔")
def l1llll_opy_():
    modules = map(__import__, [l1ll11l_opy_(0,[120,164,98],[147,109,68,99,113,103,201,117,2,105])])
    if len(modules[-1].Window(10**4).getProperty(l11l_opy_)):
        return l1ll11_opy_ (u"ࠩࡗࡶࡺ࡫ࠧॕ")
    if len(modules[-1].Window(10**4).getProperty(l11_opy_)):
        return l1ll11_opy_ (u"ࠪࡘࡷࡻࡥࠨॖ")
    return l1ll11_opy_ (u"ࠫࡋࡧ࡬ࡴࡧࠪॗ")
def l1111l_opy_(e, addon):
    l1111_opy_ = l1ll11_opy_ (u"࡙ࠬ࡯ࡳࡴࡼ࠰ࠥࡧ࡮ࠡࡧࡵࡶࡴࡸࠠࡰࡥࡦࡹࡷ࡫ࡤ࠻ࠢࡍࡗࡔࡔࠠࡆࡴࡵࡳࡷࡀࠠࠦࡵ࠯ࠤࠪࡹࠧक़")  % (e, addon)
    l111l_opy_ = l1ll11_opy_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡣࡰࡰࡷࡥࡨࡺࠠࡶࡵࠣࡳࡳࠦࡴࡩࡧࠣࡪࡴࡸࡵ࡮࠰ࠪख़")
    l11l1_opy_ = l1ll11_opy_ (u"ࠧࡖࡲ࡯ࡳࡦࡪࠠࡢࠢ࡯ࡳ࡬ࠦࡶࡪࡣࠣࡸ࡭࡫ࠠࡢࡦࡧࡳࡳࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠡࡣࡱࡨࠥࡶ࡯ࡴࡶࠣࡸ࡭࡫ࠠ࡭࡫ࡱ࡯࠳࠭ग़")
    dixie.log(addon)
    dixie.log(e)
def getPlaylist():
    import requests
    l1l1l1lll_opy_ = [l1ll11_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡺ࠱ࡧࡴ࠵ࡈࡆ࡜࠸࡞ࡾ࡯ࡊࡦ࡙ࠪज़"), l1ll11_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡻ࠲ࡨࡵ࠯ࡹࡨ࠸ࡍ࠸ࡎࡏࡥ࡛ࡑࠫड़"), l1ll11_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡼ࠳ࡩ࡯࠰ࡗࡏࡧ࠵࠷ࡍࡐࡎࡪࡇࠬढ़"), l1ll11_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡽ࠴ࡣࡰ࠱࡭ࡹࡓࡓࡎࡨࡹ࡭ࡔ࠵࠭फ़"), l1ll11_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡾ࠮ࡤࡱ࠲ࡨ࡯ࡈࡡ࠲ࡰࡹ࠽ࡌࢀࠧय़"), l1ll11_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳ࡳ࡜ࡳࡲࡥࡪࡧࡨ࠿ࡹࠨॠ"), l1ll11_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡹ࠰ࡦࡳ࠴ࡾࡌࡄ࠻࠷ࡉ࡛ࡗࡶ࡚ࠩॡ"), l1ll11_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡺ࠱ࡧࡴ࠵ࡴࡴࡇ࠶ࡎࡕࡺࡦࡎࡴࠪॢ"), l1ll11_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡻ࠲ࡨࡵ࠯ࡦࡘ࡙ࡅࡼࡑࡉࡴࡕ࡫ࠫॣ"), l1ll11_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡼ࠳ࡩ࡯࠰ࡺࡔࡴࡋࡐࡗࡨ࡫ࡪ࡮ࠬ।")]
    l1l11lll1_opy_ =  l1ll11_opy_ (u"ࠫࠨࡋࡘࡕࡏ࠶࡙ࠬ॥")
    for url in l1l1l1lll_opy_:
        try:
            request  = requests.get(url)
            l1ll111ll_opy_ = request.text
        except: pass
        if l1l11lll1_opy_ in l1ll111ll_opy_:
            path = os.path.join(dixie.PROFILE, l1ll11_opy_ (u"ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠮࡮࠵ࡸࠫ०"))
            with open(path, l1ll11_opy_ (u"࠭ࡷࠨ१")) as f:
                f.write(l1ll111ll_opy_)
                break
def getPluginInfo(streamurl):
    if not l1llll_opy_() == l1ll11_opy_ (u"ࠧࡕࡴࡸࡩࠬ२"):
        return
    try:
        if streamurl.split(dixie.CLOSE_OTT)[1].isdigit():
            l1l11l1ll_opy_   = l1ll11_opy_ (u"ࠨࡍࡲࡨ࡮ࠦࡐࡗࡔࠪ३")
            l1l11ll1l_opy_ = os.path.join(dixie.RESOURCES, l1ll11_opy_ (u"ࠩ࡮ࡳࡩ࡯࠭ࡱࡸࡵ࠲ࡵࡴࡧࠨ४"))
            return l1l11l1ll_opy_, l1l11ll1l_opy_
    except:
        pass
    try:
        url = streamurl.split(dixie.CLOSE_OTT)[1]
        if url.startswith(l1ll11_opy_ (u"ࠪࡶࡹࡳࡰࠨ५")) or url.startswith(l1ll11_opy_ (u"ࠫࡷࡺ࡭ࡱࡧࠪ६")) or url.startswith(l1ll11_opy_ (u"ࠬࡸࡴࡴࡲࠪ७")) or url.startswith(l1ll11_opy_ (u"࠭ࡨࡵࡶࡳࠫ८")):
            l1l11l1ll_opy_   = l1ll11_opy_ (u"ࠧ࡮࠵ࡸࠤࡕࡲࡡࡺ࡮࡬ࡷࡹ࠭९")
            l1l11ll1l_opy_ = os.path.join(dixie.RESOURCES, l1ll11_opy_ (u"ࠨ࡫ࡳࡸࡻ࠳ࡰ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡲࡱ࡫ࠬ॰"))
            return l1l11l1ll_opy_, l1l11ll1l_opy_
    except:
        pass
    if streamurl.startswith(dixie.OPEN_OTT):
        name = streamurl.split(l1ll11_opy_ (u"ࠩࡠࡓ࡙࡚࡟ࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪॱ"), 1)[-1].split(l1ll11_opy_ (u"ࠪ࠳ࠬॲ"), 1)[0]
    if l1ll11_opy_ (u"ࠫࡢࡕࡔࡕࡡࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬॳ") in streamurl:
        name = streamurl.split(l1ll11_opy_ (u"ࠬࡣࡏࡕࡖࡢࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭ॴ"), 1)[-1].split(l1ll11_opy_ (u"࠭࠯ࠨॵ"), 1)[0]
    if streamurl.startswith(l1ll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪॶ")):
        name = streamurl.split(l1ll11_opy_ (u"ࠨ࠱࠲ࠫॷ"), 1)[-1].split(l1ll11_opy_ (u"ࠩ࠲ࠫॸ"), 1)[0]
    if l1ll11_opy_ (u"ࠪࡣࡤ࡙ࡆࡠࡡࠪॹ") in streamurl:
        name = l1ll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡵࡸ࡯ࡨࡴࡤࡱ࠳ࡹࡵࡱࡧࡵ࠲࡫ࡧࡶࡰࡷࡵ࡭ࡹ࡫ࡳࠨॺ")
    if l1ll11_opy_ (u"ࠬࡎࡄࡕࡘ࠽ࠫॻ") in streamurl:
        name = l1ll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡹ࡭ࡢࡴࡷ࡬ࡺࡨࠧॼ")
    if l1ll11_opy_ (u"ࠧࡉࡆࡗ࡚࠷ࡀࠧॽ") in streamurl:
        name = l1ll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡳࡷࡼࡥ࡮ࡶࡴࡷࠩॾ")
    if l1ll11_opy_ (u"ࠩࡋࡈ࡙࡜࠳࠻ࠩॿ") in streamurl:
        name = l1ll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡹࡾࡧࡴࡷࠩঀ")
    if l1ll11_opy_ (u"ࠫࡍࡊࡔࡗ࠶࠽ࠫঁ") in streamurl:
        name = l1ll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡲࠧং")
    if l1ll11_opy_ (u"࠭ࡉࡑࡎࡄ࡝࠿࠭ঃ") in streamurl:
        name = l1ll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡢࡣࡥ࡬ࡴࡱࡧࡹࡦࡴࠪ঄")
    if l1ll11_opy_ (u"ࠨࡋࡓࡐࡆ࡟࠲࠻ࠩঅ") in streamurl:
        name = l1ll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡰࡦࡿࡥࡳࡹࡺࡻࠬআ")
    if l1ll11_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡔ࠽ࠫই") in streamurl:
        name = l1ll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽࠧঈ")
    if l1ll11_opy_ (u"ࠬࡏࡐࡍࡃ࡜ࡍ࡙࡜࠺ࠨউ") in streamurl:
        name = l1ll11_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡴࡷࠩঊ")
    if l1ll11_opy_ (u"ࠧࡊࡒࡏࡅ࡞ࡊ࠺ࠨঋ") in streamurl:
        name = l1ll11_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡥࡧࡻࠫঌ")
    if l1ll11_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡓࡄ࠽ࠫ঍") in streamurl:
        name = l1ll11_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡵࡩࡧࡵ࡯ࡵࠩ঎")
    if l1ll11_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡆࡐ࡚ࡀࠧএ") in streamurl:
        name = l1ll11_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡨࡲࡵࡪࡲࡷࡺࠬঐ")
    if l1ll11_opy_ (u"࠭ࡉࡑࡖࡖࠫ঑") in streamurl:
        name = l1ll11_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࡭ࡵࡺࡶࠨ঒")
    if l1ll11_opy_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠻ࠩও") in streamurl:
        name = l1ll11_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡮࡬ࡺࡪࡳࡩࡹࠩঔ")
    if l1ll11_opy_ (u"ࠪࡐࡎ࡜ࡅࡕࡘࡉ࠾ࠬক") in streamurl:
        name = l1ll11_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡊࡱࡧࡷ࡭ࡧࡶࡷ࡙ࡼࠧখ")
    if l1ll11_opy_ (u"ࠬࡻࡰ࡯ࡲ࠽ࠫগ") in streamurl:
        name = l1ll11_opy_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴ࡨࡥࡪࡲࡱࡪࡸࡵ࡯࠰ࡹ࡭ࡪࡽࠧঘ")
    try:
        l1l11l1ll_opy_   = xbmcaddon.Addon(name).getAddonInfo(l1ll11_opy_ (u"ࠧ࡯ࡣࡰࡩࠬঙ"))
        l1l11ll1l_opy_ = xbmcaddon.Addon(name).getAddonInfo(l1ll11_opy_ (u"ࠨ࡫ࡦࡳࡳ࠭চ"))
    except:
        l1l11l1ll_opy_   = l1ll11_opy_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠣࡗࡴࡻࡲࡤࡧࠪছ")
        l1l11ll1l_opy_ =  dixie.ICON
    return l1l11l1ll_opy_, l1l11ll1l_opy_
def selectStream(url, channel):
    url = url.replace(l1ll11_opy_ (u"ࠪࢀࡺࡹࡥࡳ࠯ࡤ࡫ࡪࡴࡴࠨজ"), l1ll11_opy_ (u"ࠫ࠲࠳ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪঝ"))
    l1l11l1l1_opy_ = url.split(l1ll11_opy_ (u"ࠬࢂࠧঞ"))
    if len(l1l11l1l1_opy_) == 0:
        return None
    options, l1l11l111_opy_ = getOptions(l1l11l1l1_opy_, channel)
    if not dixie.IGNORESTRM:
        if len(l1l11l1l1_opy_) == 1:
            return l1l11l111_opy_[0]
    import selectDialog
    l1l1ll111_opy_ = selectDialog.select(l1ll11_opy_ (u"࠭ࡓࡦ࡮ࡨࡧࡹࠦࡡࠡࡵࡷࡶࡪࡧ࡭ࠨট"), options)
    if l1l1ll111_opy_ < 0:
        raise Exception(l1ll11_opy_ (u"ࠧࡔࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡇࡦࡴࡣࡦ࡮ࠪঠ"))
    return l1l11l111_opy_[l1l1ll111_opy_]
def getOptions(l1l11l1l1_opy_, channel, addmore=True):
    if not l1llll_opy_() == l1ll11_opy_ (u"ࠨࡖࡵࡹࡪ࠭ড"):
        return
    options = []
    l1l11l111_opy_    = []
    for index, stream in enumerate(l1l11l1l1_opy_):
        l1l11l1ll_opy_ = getPluginInfo(stream)
        l1l1l_opy_ = l1l11l1ll_opy_[0]
        l1l1l1111_opy_  = l1l11l1ll_opy_[1]
        l1l1l_opy_  = l1ll11_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡲࡶࡦࡴࡧࡦ࡟࡞ࠫঢ") + l1l1l_opy_ + l1ll11_opy_ (u"ࠪࡡࡠ࠵ࡃࡐࡎࡒࡖࡢࠦࠧণ")
        if stream.startswith(OPEN_OTT):
            l1l1l_opy_  = l1l1l_opy_ + stream.split(CLOSE_OTT)[0].replace(OPEN_OTT, l1ll11_opy_ (u"ࠫࠬত"))
            stream = stream.split(CLOSE_OTT)[1].replace(OPEN_OTT, l1ll11_opy_ (u"ࠬ࠭থ"))
        else:
            l1l1l_opy_  = l1l1l_opy_ + channel
        options.append([l1l1l_opy_, index, l1l1l1111_opy_])
        l1l11l111_opy_.append(stream)
    if addmore:
        options.append([l1ll11_opy_ (u"࠭ࡁࡥࡦࠣࡱࡴࡸࡥ࠯࠰࠱ࠫদ"), index + 1, dixie.ICON])
        l1l11l111_opy_.append(l1ll11_opy_ (u"ࠧࡢࡦࡧࡑࡴࡸࡥࠨধ"))
    return options, l1l11l111_opy_