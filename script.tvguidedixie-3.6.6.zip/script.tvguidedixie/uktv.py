#
# Copyright (C) 2015 Sean Poyser and Richard Dean

import xbmc
import xbmcaddon
import json
import urllib
import os

import dixie

france   = 'plugin.video.uktvfrance'
xtream   = 'plugin.video.xtream-codes'
iptvsubs = 'plugin.video.iptvsubs'
quick    = 'plugin.video.quickiptv'
future   = 'plugin.video.futurestreams'
stealth  = 'plugin.video.stealthunderground'

ADDONS   =  [france, xtream, iptvsubs, quick, future, stealth]


def checkAddons():
    for addon in ADDONS:
        if isInstalled(addon):
            createINI(addon)


def isInstalled(addon):
    if xbmc.getCondVisibility('System.HasAddon(%s)' % addon) == 1:
        return True
    else:
        return False


def createINI(addon):
    HOME = dixie.PROFILE
    PATH = os.path.join(HOME, 'ini')
    FILE = getININame(addon) + '.ini'
    INI  = os.path.join(PATH, FILE)

    response = getFiles(addon)
    try:
        result = response['result']
    except KeyError:
        dixie.log('----- KeyError in getFiles ----- ' + addon)
        result = {u'files': [{u'filetype': u'file', u'type': u'unknown', u'file': u'plugin://plugin.video.xxx', u'label': u'NO CHANNELS'}], u'limits': {u'start': 0, u'total': 1, u'end': 1}}

    channels = result['files']

    theFile  = file(INI, 'w')

    theFile.write('[')
    theFile.write(addon)
    theFile.write(']')
    theFile.write('\n')

    theList = []

    for channel in channels:
        labelA = channel['label']
        stream = channel['file']

        labelB  = getLabel(addon, labelA)
        channel = getChannel(addon, labelB)
        iniLine = channel + '=' + stream

        theList.append(iniLine)
        theList.sort()

    for item in theList:
      theFile.write("%s\n" % item)

    theFile.close()


def getININame(addon):
    if addon == france:
        return 'uktvfrance'

    if addon == xtream:
        return 'xtream-codes'

    if addon == iptvsubs:
        return 'iptvsubs'

    if addon == quick:
        return 'quick'

    if addon == future:
        return 'future'

    if addon == stealth:
        return 'stealth'


def getFiles(addon):
    trigger = ('{"jsonrpc":"2.0", "method":"Files.GetDirectory", "params":{"directory":"%s"}, "id": 1}' % addon)

    if addon == stealth:
        login = 'plugin://plugin.video.stealthunderground/?mode=genres&portal=%7b%22name%22%3a%20%22%5bI%5d%5bCOLOR%20white%5dClick%20To%20View%20The%20List%20Of%20Channels%5b%2fCOLOR%5d%5b%2fI%5d%22%2c%20%22parental%22%3a%20%22false%22%2c%20%22url%22%3a%20%22http%3a%2f%2fmw1.iptv66.tv%22%2c%20%22ppassword%22%3a%20%220000%22%2c%20%22mac%22%3a%20%2200%3a1A%3a78%3a43%3a12%3a74%22%2c%20%22serial%22%3a%20%7b%22send_serial%22%3a%20true%2c%20%22custom%22%3a%20true%2c%20%22sn%22%3a%20%22%22%2c%20%22signature%22%3a%20%22%22%2c%20%22device_id2%22%3a%20%22%22%2c%20%22device_id%22%3a%20%22%22%7d%2c%20%22password%22%3a%20null%2c%20%22login%22%3a%20null%7d'
    else:
        login = 'plugin://' + addon + '/?action=security_check&extra&page&plot&thumbnail&title=Live%20TV&url'

    query = getQuery(addon)

    json1 = ('{"jsonrpc":"2.0", "method":"Files.GetDirectory", "params":{"directory":"%s"}, "id": 1}' % login)
    json2 = ('{"jsonrpc":"2.0", "method":"Files.GetDirectory", "params":{"directory":"%s"}, "id": 1}' % query)


    try:
        xbmc.executeJSONRPC(trigger)
        xbmc.executeJSONRPC(json1)

        response = xbmc.executeJSONRPC(json2)
        content  = json.loads(response.decode('utf-8', 'ignore'))

        return content

    except:
        dixie.log('--------------- Plugin Error ---------------')
        return {'Error' : 'Plugin Error'}


def getQuery(addon):
    if addon == quick:
        return 'plugin://plugin.video.quickiptv/?action=stream_video&extra&page&plot&thumbnail=&title=All&url=0'

    if addon == future:
        return 'plugin://plugin.video.futurestreams/?action=stream_video&extra&page&plot&thumbnail=&title=All&url=0'

    if addon == stealth:
        return 'plugin://plugin.video.stealthunderground/?genre_name=All&portal=%7B%22name%22%3A+%22%5BI%5D%5BCOLOR+white%5DClick+To+View+The+List+Of+Channels%5B%2FCOLOR%5D%5B%2FI%5D%22%2C+%22parental%22%3A+%22false%22%2C+%22url%22%3A+%22http%3A%2F%2Fmw1.iptv66.tv%22%2C+%22ppassword%22%3A+%220000%22%2C+%22mac%22%3A+%2200%3A1A%3A78%3A43%3A12%3A74%22%2C+%22serial%22%3A+%7B%22send_serial%22%3A+true%2C+%22custom%22%3A+true%2C+%22sn%22%3A+%22%22%2C+%22signature%22%3A+%22%22%2C+%22device_id2%22%3A+%22%22%2C+%22device_id%22%3A+%22%22%7D%2C+%22password%22%3A+null%2C+%22login%22%3A+null%7D&mode=channels&genre_id=%2A'
    else:
        Addon = xbmcaddon.Addon(addon)
        username =  Addon.getSetting('kasutajanimi')
        password =  Addon.getSetting('salasona')
        slug     = '/?action=stream_video&extra&page&plot&thumbnail=&title=All&url='
        slugurl  =  getSlugURL(addon)
        plugin   = 'plugin://' + addon
        baseurl  =  plugin + slug + slugurl
        usercred = 'username=' + username + '&password=' + password + '&type=get_live_streams&cat_id=0'

        return baseurl + urllib.quote_plus(usercred)


def getSlugURL(addon):
    if (addon == france) or (addon == xtream):
        return 'http://37.187.139.155:8000/enigma2.php?'

    if addon == iptvsubs:
        return 'http://2.welcm.tv:8000/enigma2.php?'


def getLabel(addon, label):
    if (addon == france) or (addon == xtream) or (addon == iptvsubs):
        label = label.replace('  ', ' ').replace(' [/COLOR]', '[/COLOR]')
        return label

    if (addon == quick) or (addon == future) or (addon == stealth):
        return label


def getChannel(addon, label2):
    if (addon == france) or (addon == xtream) or (addon == iptvsubs):
        channel = label2.rsplit('[/COLOR]', 1)[0].split('[COLOR white]', 1)[-1]
        channel = channel.replace('BBC 1', 'BBC One').replace('BBC 2', 'BBC Two').replace('BBC 4', 'BBC FOUR').replace('ITV 1', 'ITV1').replace('ITV 2', 'ITV2').replace('ITV 3', 'ITV3').replace('ITV 4', 'ITV4')
        return channel


    if (addon == quick) or (addon == future):
        channel = label2.rsplit(' [/COLOR]')[0].replace('[COLOR white]', '')
        channel = channel.replace(':', '').replace('BBC 1', 'BBC One').replace('BBC 2', 'BBC Two').replace('BBC 4', 'BBC FOUR').replace('ITV 1', 'ITV1').replace('ITV 2', 'ITV2').replace('ITV 3', 'ITV3').replace('ITV 4', 'ITV4')
        return channel

    else:
        channel = label2.replace('BBC 1', 'BBC One').replace('BBC 2', 'BBC Two').replace('BBC 4', 'BBC FOUR').replace('ITV 1', 'ITV1').replace('ITV 2', 'ITV2').replace('ITV 3', 'ITV3').replace('ITV 4', 'ITV4')
        return channel


def catchException(e):
    line1 = 'Sorry, an error occured: JSON Error: %s'  %e
    line2 = 'Please contact us on the forum.'
    line3 = 'Upload a log via the addon settings and post the link.'

    dixie.log(e)
    dixie.DialogOK(line1, line2, line3)
    dixie.SetSetting(SETTING, '')
