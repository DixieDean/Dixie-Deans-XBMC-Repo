# coding: UTF-8
import sys
l1ll_opy_ = sys.version_info [0] == 2
l1l1_opy_ = 2048
l11_opy_ = 7
def l111l_opy_ (l1_opy_):
	global l1l_opy_
	l1llll_opy_ = ord (l1_opy_ [-1])
	l1ll11_opy_ = l1_opy_ [:-1]
	l1l1l_opy_ = l1llll_opy_ % len (l1ll11_opy_)
	l1l11_opy_ = l1ll11_opy_ [:l1l1l_opy_] + l1ll11_opy_ [l1l1l_opy_:]
	if l1ll_opy_:
		l1lll_opy_ = unicode () .join ([unichr (ord (char) - l1l1_opy_ - (l11ll_opy_ + l1llll_opy_) % l11_opy_) for l11ll_opy_, char in enumerate (l1l11_opy_)])
	else:
		l1lll_opy_ = str () .join ([chr (ord (char) - l1l1_opy_ - (l11ll_opy_ + l1llll_opy_) % l11_opy_) for l11ll_opy_, char in enumerate (l1l11_opy_)])
	return eval (l1lll_opy_)
import xbmc
import json
import dixie
def getURL(url):
    response = l11l_opy_(url)
    stream   = url.split(l111l_opy_ (u"ࠫ࠿࠭ࠀ"), 1)[-1].lower()
    try:
        result = response[l111l_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬࠁ")]
        ll_opy_  = result[l111l_opy_ (u"࠭ࡦࡪ࡮ࡨࡷࠬࠂ")]
    except Exception as e:
        l1ll1l_opy_(e)
        return None
    for file in ll_opy_:
        l11l1_opy_ = file[l111l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ࠃ")]
        if stream == l11l1_opy_.lower():
            return file[l111l_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭ࠄ")]
    return None
def l11l_opy_(url):
    if url.startswith(l111l_opy_ (u"ࠩࡌࡔࡑࡇ࡙࠻ࠩࠅ")):
        l1lll1_opy_ = (l111l_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡢࡣࡥ࡬ࡴࡱࡧࡹࡦࡴ࠲ࡃࡺࡸ࡬࠾ࡷࡵࡰࠫࡳ࡯ࡥࡧࡀ࠶ࠫࡴࡡ࡮ࡧࡀࡐ࡮ࡼࡥࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࡀࠪࡎࡖࡉࡅ࠿ࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨࠆ"))
    if url.startswith(l111l_opy_ (u"ࠫࡎࡖࡌࡂ࡛࠵࠾ࠬࠇ")):
        l1lll1_opy_ = (l111l_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡌࡩ࡭ࡧࡶ࠲ࡌ࡫ࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧࡀࠢࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡰࡦࡿࡥࡳࡹࡺࡻ࠴ࡅࡵࡳ࡮ࡀࡹࡷࡲࠦ࡮ࡱࡧࡩࡂ࠷࠰࠲ࠨࡱࡥࡲ࡫࠽ࡘࡣࡷࡧ࡭࠱ࡌࡪࡸࡨࠪ࡮ࡩ࡯࡯࡫ࡰࡥ࡬࡫࠽ࠧࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࡃࠦࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡵࡢࡹࡷࡲ࠽ࠧ࡮ࡲ࡫࡬࡫ࡤࡠ࡫ࡱࡁࡋࡧ࡬ࡴࡧࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨࠈ"))
    if url.startswith(l111l_opy_ (u"࠭ࡉࡑࡎࡄ࡝ࡗࡀࠧࠉ")):
        l1lll1_opy_ = (l111l_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡇ࡫࡯ࡩࡸ࠴ࡇࡦࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠻ࠤࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱࡭ࡵࡲࡡࡺࡧࡵࡻࡼࡽ࠯ࡀࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠬࡩࡤࡱࡱ࡭ࡲࡧࡧࡦ࠿ࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬ࠬ࡬ࡰࡩࡪࡩࡩࡥࡩ࡯࠿ࡉࡥࡱࡹࡥࠧ࡯ࡲࡨࡪࡃ࠱࠲࠵ࠩࡲࡦࡳࡥ࠾ࡎ࡬ࡷࡹ࡫࡮ࠦ࠴࠳ࡐ࡮ࡼࡥࠧࡵࡸࡦࡹ࡯ࡴ࡭ࡧࡶࡣࡺࡸ࡬ࠧࡷࡵࡰࡂࡻࡲ࡭ࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࠊ"))
    if url.startswith(l111l_opy_ (u"ࠨࡋࡓࡐࡆ࡟ࡉࡕࡘ࠽ࠫࠋ")):
        l1lll1_opy_ = (l111l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡯ࡴࡷࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧࠌ"))
    if url.startswith(l111l_opy_ (u"ࠪࡍࡕࡒࡁ࡚ࡆ࠽ࠫࠍ")):
        l1lll1_opy_ = (l111l_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡥࡧࡻ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡧ࡬࡭ࠨࡨࡼࡹࡸࡡࠧࡲࡤ࡫ࡪࠬࡰ࡭ࡱࡷࠪࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠽ࡩࡶࡷࡴࡸࠫ࠳ࡢࠧ࠵ࡪࠪ࠸ࡦࡴ࠵࠴࠲ࡵࡵࡳࡵ࡫ࡰ࡫࠳ࡵࡲࡨࠧ࠵ࡪ࠾࡮࡮࡬ࡺࡴࡾ࡬ࡨࠥ࠳ࡨࡷࡩࡸࡺ࡟ࡪࡰࡢࡴࡷࡵࡧࡳࡧࡶࡷ࠳ࡶ࡮ࡨࠨࡷ࡭ࡹࡲࡥ࠾ࠧ࠸ࡦࡈࡕࡌࡐࡔࠨ࠶࠵ࡽࡨࡪࡶࡨࠩ࠺ࡪࡁ࡭࡮ࠨ࠶࠵ࡉࡨࡢࡰࡱࡩࡱࡹࠥ࠶ࡤࠨ࠶࡫ࡉࡏࡍࡑࡕࠩ࠺ࡪࠦࡶࡴ࡯ࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩࠎ"))
    try:
        dixie.ShowBusy()
        response = xbmc.executeJSONRPC(l1lll1_opy_)
        dixie.CloseBusy()
        content = json.loads(response)
        return content
    except Exception as e:
        l1ll1l_opy_(e)
        return {l111l_opy_ (u"ࠬࡋࡲࡳࡱࡵࠫࠏ") : l111l_opy_ (u"࠭ࡐ࡭ࡷࡪ࡭ࡳࠦࡅࡳࡴࡲࡶࠬࠐ")}
def l1ll1l_opy_(e):
    l1ll1_opy_ = l111l_opy_ (u"ࠧࡔࡱࡵࡶࡾ࠲ࠠࡢࡰࠣࡩࡷࡸ࡯ࡳࠢࡲࡧࡨࡻࡲࡦࡦ࠽ࠤࡏ࡙ࡏࡏࠢࡈࡶࡷࡵࡲ࠻ࠢࠨࡷࠬࠑ")  %e
    l1111_opy_ = l111l_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡴࡨ࠱ࡱ࡯࡮࡬ࠢࡷ࡬࡮ࡹࠠࡤࡪࡤࡲࡳ࡫࡬ࠡࡣࡱࡨࠥࡺࡲࡺࠢࡤ࡫ࡦ࡯࡮࠯ࠩࠒ")
    l111_opy_ = l111l_opy_ (u"ࠩࡘࡷࡪࡀࠠࡄࡱࡱࡸࡪࡾࡴࠡࡏࡨࡲࡺࠦ࠽࠿ࠢࡕࡩࡲࡵࡶࡦࠢࡖࡸࡷ࡫ࡡ࡮ࠩࠓ")
    dixie.log(e)
    dixie.DialogOK(l1ll1_opy_, l1111_opy_, l111_opy_)