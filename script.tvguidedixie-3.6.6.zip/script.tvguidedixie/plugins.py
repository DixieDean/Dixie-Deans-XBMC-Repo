#
# Copyright (C) 2015 On-Tapp-Networks

import xbmc
import xbmcaddon
import xbmcgui
import json
import os
import shutil
import dixie

ntv    = 'plugin.video.ntv'
ukt    = 'plugin.video.ukturk'
locked = 'plugin.video.lockedtv'
stvb   = 'plugin.video.streamtvbox'
sm     = 'plugin.video.sportsmania'
sn     = 'plugin.video.sportsnationhdtv'
um     = 'plugin.video.ultimatemania'
liux   = 'plugin.video.liux.tv'
dcs    = 'plugin.video.DCSports'
# clu    = 'plugin.video.cluiptv'

# vidtime = 'plugin.video.VidTime'
# tvtime  = 'plugin.video.tvtime.tva'

ADDONS = [ukt, ntv, stvb, liux] # , sm, sn, um, locked, dcs

HOME = dixie.PROFILE
PATH = os.path.join(HOME, 'ini')


def checkAddons():
    for addon in ADDONS:
        if isInstalled(addon):
            try: createINI(addon)
            except: pass


def isInstalled(addon):
    if xbmc.getCondVisibility('System.HasAddon(%s)' % addon) == 1:
        return True
    return False


def createINI(addon):
    FILE = str(addon).split('.')[2] + '.ini'
    INI  = os.path.join(PATH, FILE)

    # REMOVE = [sm, sn, um]
    #
    # if addon in REMOVE:
    #     removeINI(FILE, INI)
    #     return

    channels = getFiles(addon)

    theFile  = file(INI, 'w')

    theFile.write('[')
    theFile.write(addon)
    theFile.write(']')
    theFile.write('\n')

    for channel in channels:
        label  = channel['label']
        label  = label.replace('.....', '').replace(':', '').replace(' [', '[').replace('] ', ']').replace('[COLOR aqua]', '').replace('[COLOR limegreen]', '').replace('[COLOR green]', '').replace('[COLOR yellow]', '').replace('[COLOR blue]', '').replace('[COLOR orange]', '').replace('[COLOR red]', '').replace('[COLOR white]', '').replace('[/COLOR]', '').replace('[I]', '').replace('[/I]', '').replace('[B]', '').replace('[/B]', '')
        stream = channel['file']

        theFile.write('%s' % label)
        theFile.write('=')
        theFile.write('%s' % stream)
        theFile.write('\n')

    theFile.write('\n')
    theFile.close()


# def test():
#     JSON     = '{"jsonrpc":"2.0", "method":"Files.GetDirectory", "params":{"directory":"plugin://plugin.video.sportsmania/?mode=None"}, "id": 1}'
#     jsonCMD  = xbmc.executeJSONRPC(JSON)
#     response = json.loads(jsonCMD)
#     result   = response['result']
#
#     dixie.log('======================= TEST ======================')
#     dixie.log(response)
#     dixie.log(result)


# def removeINI(FILE, INI):
#     dixie.log('------------ removeINI -------------')
#     dixie.log(FILE)
#     dixie.log(INI)
#     path = xbmc.translatePath(INI)
#     dixie.log(path)
#
#     if os.path.isfile(path):
#         import sfile
#         sfile.remove(path)


def getFiles(addon):
    if addon == ukt:
        return getUKTFiles(addon)

    if addon == dcs:
        return getDCSFiles(addon)

    if addon in [sm, sn, um]:
        return # getGenres(addon)

    try:
        if xbmcaddon.Addon(addon).getSetting('genre') == 'true':
            xbmcaddon.Addon(addon).setSetting('genre', 'false')
            xbmcgui.Window(10000).setProperty('PLUGIN_GENRE', 'True')

        if xbmcaddon.Addon(addon).getSetting('tvguide') == 'true':
            xbmcaddon.Addon(addon).setSetting('tvguide', 'false')
            xbmcgui.Window(10000).setProperty('PLUGIN_TVGUIDE', 'True')
    except: pass

    plugin  = 'plugin://' + addon
    slugurl =  getSlugURL(addon)
    query   =  plugin + slugurl

    return sendJSON(query, addon)


def getGenres(addon):
    genres   =  []
    query    = 'plugin://' + addon
    response =  sendJSON(query, addon)

    for item in response:
        if not '.' in item['label']:
            genres.append(item['file'])

    files = []
    for genre in genres:
        response = sendJSON(genre, addon)
        files.extend(response)

    return files


def getUKTFiles(addon):
    plugin = 'plugin://' + addon

    slug1 = '/?description&iconimage=&mode=1&name=Live%20TV&url=http%3a%2f%2fmetalkettle.co%2fUKTurk18022016%2fLive%2520TV.txt'
    slug2 = '/?description&iconimage=&mode=1&name=Sports&url=http%3a%2f%2fmetalkettle.co%2fUKTurk18022016%2fSportsList.txt'

    files  = []
    files += sendJSON(plugin + slug1, addon)
    files += sendJSON(plugin + slug2, addon)

    return files


def getDCSFiles(addon):
    plugin = 'plugin://' + addon

    slug1 = '/?fanart=http%3a%2f%2fgoo.gl%2fXdF28T&mode=1&name=Live%20UK%20Sports&url=https%3a%2f%2fgoo.gl%2f5qQgE4'
    slug2 = '/?fanart=https%3a%2f%2fgoo.gl%2fFgWMkZ&mode=1&name=Live%20US%2fCAN%20Sports&url=https%3a%2f%2fgoo.gl%2ff9jg8N'

    files  = []
    files += sendJSON(plugin + slug1, addon)
    files += sendJSON(plugin + slug2, addon)

    return files


def getSlugURL(addon):
    if addon == ntv:
        return '/?cat=-2&mode=2&name=My%20Channels&url=url'

    return ''


def sendJSON(query, addon):
    try:
        JSON     = '{"jsonrpc":"2.0", "method":"Files.GetDirectory", "params":{"directory":"%s"}, "id": 1}' % query
        jsonCMD  = xbmc.executeJSONRPC(JSON)
        response = json.loads(jsonCMD)

        if xbmcgui.Window(10000).getProperty('PLUGIN_GENRE') == 'True':
            xbmcaddon.Addon(addon).setSetting('genre', 'true')
            xbmcgui.Window(10000).clearProperty('PLUGIN_GENRE')

        if xbmcgui.Window(10000).getProperty('PLUGIN_TVGUIDE') == 'True':
            xbmcaddon.Addon(addon).setSetting('tvguide', 'true')
            xbmcgui.Window(10000).clearProperty('PLUGIN_TVGUIDE')

        return response['result']['files']

    except Exception as e:
        catchException(e, addon)
        return {'Error' : 'Plugin Error'}


def catchException(e, addon):
    line1 = 'Sorry, an error occured: JSON Error: %s, %s'  % (e, addon) 
    line2 = 'Please contact us on the forum.'
    line3 = 'Upload a log via the addon settings and post the link.'

    dixie.log(addon)
    dixie.log(e)


def getPlaylist():
    import requests

    URL = ['http://go2l.ink/kodi', 'http://x.co/dbch01', 'http://kodi.ccld.io', 'http://aio.ccloudtv.org/kodi']
    M3U =  '#EXTM3U'

    for url in URL:
        dixie.log(url)
        try:
            request  = requests.get(url)
            playlist = request.text
        except: pass

        if M3U in playlist:
            path = os.path.join(dixie.PROFILE, 'playlist.m3u')
            with open(path, 'w') as f:
                f.write(playlist)
                break


def getPluginInfo(streamurl):
    if streamurl.isdigit():
        pluginid   = 'Kodi PVR Channel'
        pluginicon = os.path.join(dixie.RESOURCES, 'kodi-pvr.png')
        return pluginid, pluginicon

    if streamurl.startswith('plugin://'):
        name = streamurl.split('//', 1)[-1].split('/', 1)[0]

    if streamurl.startswith('__SF__'):
        name = 'plugin.program.super.favourites'

    if streamurl.startswith('HDTV:'):
        name = 'plugin.video.hdtv'

    if streamurl.startswith('HDTV2:'):
        name = 'plugin.video.ruyaiptv'

    if streamurl.startswith('HDTV3:'):
        name = 'plugin.video.ruyatv'

    if streamurl.startswith('HDTV4:'):
        name = 'plugin.video.xl'

    if streamurl.startswith('IPLAY:'):
        name = 'plugin.video.bbciplayer'

    if streamurl.startswith('IPLAY2:'):
        name = 'plugin.video.iplayerwww'

    if streamurl.startswith('IPLAYR:'):
        name = 'plugin.video.iplayerwww'

    if streamurl.startswith('IPLAYITV:'):
        name = 'plugin.video.itv'

    if streamurl.startswith('IPLAYD:'):
        name = 'plugin.video.dex'

    if streamurl.startswith('LIVETV:'):
        name = 'plugin.video.livemix'

    if streamurl.startswith('upnp:'):
        name = 'script.hdhomerun.view'

    try:
        pluginid   = xbmcaddon.Addon(name).getAddonInfo('name')
        pluginicon = xbmcaddon.Addon(name).getAddonInfo('icon')
    except:
        pluginid   = 'Unknown stream or add-on'
        pluginicon =  dixie.ICON

    return pluginid, pluginicon


    # import urllib
    #
    # TEMP = os.path.join(PATH, 'tempini')
    # INI  = os.path.join(PATH, 'ini2.ini')
    # URL  = 'https://raw.githubusercontent.com/RenegadesTV/repository.renegadestv/master/addons2.ini'
    #
    # urllib.urlretrieve(URL, TEMP)
    #
    # temp = open(TEMP)
    # ini  = open(INI, 'wt')
    #
    # for line in temp:
    #     ini.write(line.replace(
    #                            '[plugin.video.dex]', '[plugin.video.xxx]')
    #                            .replace('[plugin.video.F.T.V]', '[plugin.video.xxx]')
    #                            .replace('[plugin.video.iplayerwww]', '[plugin.video.xxx]')
    #                            .replace('[plugin.video.itv]', '[plugin.video.xxx]')
    #                            .replace('[plugin.video.bbciplayer]', '[plugin.video.xxx]')
    #                            .replace('[plugin.video.castaway]', '[plugin.video.xxx]')
    #                            .replace('[plugin.video.xl]', '[plugin.video.xxx]')
    #                            )
    #
    # temp.close()
    # ini.close()
    #
    # os.remove(TEMP)


# def getVTFiles(addon):
#     plugin = 'plugin://' + addon
#
#     slug1 = '/?icon=http%3a%2f%2fs5.postimg.org%2f4vavhx43r%2fOnline_Sports_isn_t_it_Fun.jpg&mode=VT%20SPORTS'
#     slug2 = '/?mode=PERCH%20PICKS%20-%20ASSORTED%20SPORTS'
#
#     files  = []
#     files += sendJSON(plugin + slug1, addon)
#     files += sendJSON(plugin + slug2, addon)
#
#     return files

