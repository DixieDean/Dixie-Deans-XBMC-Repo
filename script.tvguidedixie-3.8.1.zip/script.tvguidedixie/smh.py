# coding: UTF-8
import sys
l1111l_opy_ = sys.version_info [0] == 2
l1l111_opy_ = 2048
l1l11_opy_ = 7
def l1ll1l_opy_ (ll_opy_):
	global l1l11l_opy_
	l1llll1_opy_ = ord (ll_opy_ [-1])
	l1l1ll_opy_ = ll_opy_ [:-1]
	l11l11_opy_ = l1llll1_opy_ % len (l1l1ll_opy_)
	l1ll1_opy_ = l1l1ll_opy_ [:l11l11_opy_] + l1l1ll_opy_ [l11l11_opy_:]
	if l1111l_opy_:
		l11ll1_opy_ = unicode () .join ([unichr (ord (char) - l1l111_opy_ - (l1lll1_opy_ + l1llll1_opy_) % l1l11_opy_) for l1lll1_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l11ll1_opy_ = str () .join ([chr (ord (char) - l1l111_opy_ - (l1lll1_opy_ + l1llll1_opy_) % l1l11_opy_) for l1lll1_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l11ll1_opy_)
import xbmc
import xbmcaddon
import dixie
l1l11ll11_opy_ = l1ll1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡲࡧࡲࡵࡪࡸࡦࠬफ़")
import os
import sys
import json
try:
    addon = xbmcaddon.Addon(id = l1l11ll11_opy_)
    path  = addon.getAddonInfo(l1ll1l_opy_ (u"ࠬࡶࡡࡵࡪࠪय़"))
    sys.path.insert(0, path)
    import api
except: pass
PATH = os.path.join(dixie.PROFILE, l1ll1l_opy_ (u"࠭ࡳࡩࡶࡨࡱࡵ࠭ॠ"))
def createINI():
    api.login()
    doJSON()
    HOME = dixie.PROFILE
    PATH = os.path.join(HOME, l1ll1l_opy_ (u"ࠧࡪࡰ࡬ࠫॡ"))
    l111_opy_ = l1ll1l_opy_ (u"ࠨࡵࡰࡥࡷࡺࡨࡶࡤ࠱࡭ࡳ࡯ࠧॢ")
    l1l_opy_  = os.path.join(PATH, l111_opy_)
    response = api.remote_call( l1ll1l_opy_ (u"ࠤࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶ࠳ࡱ࡯ࡳࡵ࠰ࡳ࡬ࡵࠨॣ") , {l1ll1l_opy_ (u"ࠪࡥࠬ।"): l1ll1l_opy_ (u"ࠫ࠵࠭॥"), l1ll1l_opy_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭०"): l1ll1l_opy_ (u"࠭ࡡ࡭࡮ࠪ१")} )
    l111l1_opy_ = response[l1ll1l_opy_ (u"ࠧࡣࡱࡧࡽࠬ२")]
    l1ll11_opy_  = l1ll1l_opy_ (u"ࠨ࡝ࠪ३") + l1l11ll11_opy_ + l1ll1l_opy_ (u"ࠩࡠࡠࡳ࠭४")
    l1l1_opy_  =  file(l1l_opy_, l1ll1l_opy_ (u"ࠪࡻࠬ५"))
    l1l1_opy_.write(l1ll11_opy_)
    l11ll_opy_ = []
    for channel in l111l1_opy_:
        category =  channel[l1ll1l_opy_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭६")]
        category = l1ll1l_opy_ (u"ࠬ࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰ࠤࠬ७") + category + l1ll1l_opy_ (u"࠭ࠠ࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲ࡃࠧ८")
        l1l1l_opy_    =  channel[l1ll1l_opy_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭९")]
        l1ll_opy_ =  dixie.mapChannelName(l1l1l_opy_)
        stream   = l1ll1l_opy_ (u"ࠨࡊࡇࡘ࡛ࡀࠧ॰") + l1l1l_opy_
        l1lll_opy_  =  l1ll_opy_ + l1ll1l_opy_ (u"ࠩࡀࠫॱ") + stream
        if category not in l11ll_opy_:
            l11ll_opy_.append(category)
        if l1lll_opy_ not in l11ll_opy_:
            l11ll_opy_.append(l1lll_opy_)
    l11ll_opy_.append(l1ll1l_opy_ (u"ࠪࡘ࡛ࠦ࠳ࠡࡆࡎࡁࡍࡊࡔࡗ࠼ࡗ࡚ࠥ࠹ࠠࡅࡍࠪॲ"))
    l11ll_opy_.append(l1ll1l_opy_ (u"࡙ࠫ࡜ࠠ࠵ࠢࡇࡏࡂࡎࡄࡕࡘ࠽ࡘ࡛ࠦ࠴ࠡࡆࡎࠫॳ"))
    l11ll_opy_.append(l1ll1l_opy_ (u"࡚ࠬࡖࠡ࠵ࠣࡗࡊࡃࡈࡅࡖ࡙࠾࡙࡜ࠠ࠴ࠢࡖࡉࠬॴ"))
    l11ll_opy_.append(l1ll1l_opy_ (u"࠭ࡔࡗࠢ࠷ࠤࡘࡋ࠽ࡉࡆࡗ࡚࠿࡚ࡖࠡ࠶ࠣࡗࡊ࠭ॵ"))
    for item in l11ll_opy_:
        l1l1_opy_.write(l1ll1l_opy_ (u"ࠢࠦࡵ࡟ࡲࠧॶ") % item)
    l1l1_opy_.close()
def getURL(url):
    if (url.startswith(l1ll1l_opy_ (u"ࠨࡊࡇࡘ࡛࠸࠺ࠨॷ"))) or (url.startswith(l1ll1l_opy_ (u"ࠩࡋࡈ࡙࡜࠳࠻ࠩॸ"))):
        dixie.log(l1ll1l_opy_ (u"ࠪ࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰ࠤࡗ࡛࡙ࡂࠢ࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯ࠪॹ"))
        import hdtv
        return hdtv.getURL(url)
    api.login()
    channel   = url.split(l1ll1l_opy_ (u"ࠫ࠿࠭ॺ"), 1)[-1]
    dixie.log(l1ll1l_opy_ (u"ࠬ࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲ࠦࡣࡩࡣࡱࡲࡪࡲࠠ࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭ࠨॻ"))
    dixie.log(channel)
    l1l11l1ll_opy_ = l1l11l1l1_opy_(channel)
    dixie.log(l1ll1l_opy_ (u"࠭࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳ࠠࡤࡪࡤࡲࡳ࡫࡬ࡊࡆࠣ࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰ࠫॼ"))
    dixie.log(l1l11l1ll_opy_)
    response  = api.remote_call( l1ll1l_opy_ (u"ࠢࡴࡶࡵࡩࡦࡳ࠯ࡨࡧࡷ࠲ࡵ࡮ࡰࠣॽ") , { l1ll1l_opy_ (u"ࠣࡶࠥॾ") : l1ll1l_opy_ (u"ࠤࡦ࡬ࡦࡴ࡮ࡦ࡮ࠥॿ") , l1ll1l_opy_ (u"ࠥ࡭ࡩࠨঀ") : l1l11l1ll_opy_ } )
    return response[l1ll1l_opy_ (u"ࠦࡧࡵࡤࡺࠤঁ")][l1ll1l_opy_ (u"ࠧࡻࡲ࡭ࠤং")]
def l1l11l1l1_opy_(channel):
    dixie.log(l1ll1l_opy_ (u"࠭࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳ࠠࡨࡧࡷࡍࡉࠦ࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳ࠧঃ"))
    if os.path.exists(PATH):
        response = json.load(open(PATH))
        dixie.log(l1ll1l_opy_ (u"ࠧ࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭ࠡࡒࡄࡘࡍࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮ࠩ঄"))
    else:
        response = doJSON()
        dixie.log(l1ll1l_opy_ (u"ࠨ࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮ࠢࡧࡳࡏ࡙ࡏࡏࠢࡵࡩࡸࡶ࡯࡯ࡵࡨࠤ࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱ࠬঅ"))
    items = response[l1ll1l_opy_ (u"ࠤࡥࡳࡩࡿࠢআ")]
    for item in items:
        if channel == item[l1ll1l_opy_ (u"ࠥࡸ࡮ࡺ࡬ࡦࠤই")]:
            dixie.log(l1ll1l_opy_ (u"ࠫ࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱ࠥࡩࡨࡢࡰࡱࡩࡱࠦ࡭ࡢࡶࡦ࡬ࠥ࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠭ঈ"))
            dixie.log(item)
            return item[l1ll1l_opy_ (u"ࠧ࡯ࡤࠣউ")]
def doJSON():
    dixie.log(l1ll1l_opy_ (u"࠭࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳ࠠࡥࡱࡍࡗࡔࡔࠠ࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭ࠨঊ"))
    PATH    = os.path.join(dixie.PROFILE, l1ll1l_opy_ (u"ࠧࡴࡪࡷࡩࡲࡶࠧঋ"))
    content = api.remote_call( l1ll1l_opy_ (u"ࠣࡥ࡫ࡥࡳࡴࡥ࡭ࡵ࠲ࡰ࡮ࡹࡴ࠯ࡲ࡫ࡴࠧঌ") , {l1ll1l_opy_ (u"ࠩࡤࠫ঍"): l1ll1l_opy_ (u"ࠪ࠴ࠬ঎"), l1ll1l_opy_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬএ"): l1ll1l_opy_ (u"ࠬࡧ࡬࡭ࠩঐ")} )
    json.dump(content, open(PATH,l1ll1l_opy_ (u"࠭ࡷࠨ঑")), indent=3)
    return json.load(open(PATH))