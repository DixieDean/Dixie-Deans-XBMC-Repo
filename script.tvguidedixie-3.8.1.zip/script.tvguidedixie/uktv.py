# coding: UTF-8
import sys
l1l1l1l_opy_ = sys.version_info [0] == 2
l111l1_opy_ = 2048
l1111_opy_ = 7
def l11l1l_opy_ (ll_opy_):
	global l111ll_opy_
	l1l1ll1_opy_ = ord (ll_opy_ [-1])
	l11lll_opy_ = ll_opy_ [:-1]
	l1lll_opy_ = l1l1ll1_opy_ % len (l11lll_opy_)
	l1ll1_opy_ = l11lll_opy_ [:l1lll_opy_] + l11lll_opy_ [l1lll_opy_:]
	if l1l1l1l_opy_:
		l1lllll_opy_ = unicode () .join ([unichr (ord (char) - l111l1_opy_ - (l1l111_opy_ + l1l1ll1_opy_) % l1111_opy_) for l1l111_opy_, char in enumerate (l1ll1_opy_)])
	else:
		l1lllll_opy_ = str () .join ([chr (ord (char) - l111l1_opy_ - (l1l111_opy_ + l1l1ll1_opy_) % l1111_opy_) for l1l111_opy_, char in enumerate (l1ll1_opy_)])
	return eval (l1lllll_opy_)
import xbmc
import xbmcaddon
import json
import urllib
import os
import dixie
l11ll1ll1_opy_   = l11l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡺࡱࡴࡷࡨࡵࡥࡳࡩࡥࠨু")
l11lll1ll_opy_   = l11l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾࡴࡳࡧࡤࡱ࠲ࡩ࡯ࡥࡧࡶࠫূ")
l11ll11ll_opy_ = l11l1l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࡭ࡵࡺࡶࠨৃ")
l11l1llll_opy_    = l11l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡲࡷ࡬ࡧࡰ࡯ࡰࡵࡸࠪৄ")
l11lll111_opy_   = l11l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡨࡸࡸࡺࡸࡥࡴࡶࡵࡩࡦࡳࡳࠨ৅")
l11ll1111_opy_    = l11l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡶࡴ࡮ࡴࡺࠨ৆")
l11lll1l1_opy_  = l11l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡷࡹ࡫ࡡ࡭ࡶ࡫ࡹࡳࡪࡥࡳࡩࡵࡳࡺࡴࡤࠨে")
l11l1ll1l_opy_     = l11l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡴࡺࡴࡢ࡮ࡳ࡬ࡦ࠭ৈ")
l1l111l_opy_   =  [l11ll1ll1_opy_, l11lll1ll_opy_, l11l1llll_opy_, l11lll111_opy_, l11ll1111_opy_, l11lll1l1_opy_, l11l1ll1l_opy_]
def checkAddons():
    for addon in l1l111l_opy_:
        if l1l11l1_opy_(addon):
            createINI(addon)
def l1l11l1_opy_(addon):
    if xbmc.getCondVisibility(l11l1l_opy_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡈࡢࡵࡄࡨࡩࡵ࡮ࠩࠧࡶ࠭ࠬ৉") % addon) == 1:
        return True
    else:
        return False
def createINI(addon):
    HOME = dixie.PROFILE
    PATH = os.path.join(HOME, l11l1l_opy_ (u"ࠧࡪࡰ࡬ࠫ৊"))
    l1111l_opy_ = str(addon).split(l11l1l_opy_ (u"ࠨ࠰ࠪো"))[2] + l11l1l_opy_ (u"ࠩ࠱࡭ࡳ࡯ࠧৌ")
    l1l_opy_  = os.path.join(PATH, l1111l_opy_)
    response = l1l1llll1_opy_(addon)
    try:
        result = response[l11l1l_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶ্ࠪ")]
    except KeyError:
        dixie.log(l11l1l_opy_ (u"ࠫ࠲࠳࠭࠮࠯ࠣࡏࡪࡿࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡩࡨࡸࡋ࡯࡬ࡦࡵࠣ࠱࠲࠳࠭࠮ࠢࠪৎ") + addon)
        result = {l11l1l_opy_ (u"ࡺ࠭ࡦࡪ࡮ࡨࡷࠬ৏"): [{l11l1l_opy_ (u"ࡻࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ৐"): l11l1l_opy_ (u"ࡵࠨࡨ࡬ࡰࡪ࠭৑"), l11l1l_opy_ (u"ࡶࠩࡷࡽࡵ࡫ࠧ৒"): l11l1l_opy_ (u"ࡷࠪࡹࡳࡱ࡮ࡰࡹࡱࠫ৓"), l11l1l_opy_ (u"ࡸࠫ࡫࡯࡬ࡦࠩ৔"): l11l1l_opy_ (u"ࡹࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸࡹࡺࠪ৕"), l11l1l_opy_ (u"ࡺ࠭࡬ࡢࡤࡨࡰࠬ৖"): l11l1l_opy_ (u"ࡻࠧࡏࡑࠣࡇࡍࡇࡎࡏࡇࡏࡗࠬৗ")}], l11l1l_opy_ (u"ࡵࠨ࡮࡬ࡱ࡮ࡺࡳࠨ৘"): {l11l1l_opy_ (u"ࡶࠩࡶࡸࡦࡸࡴࠨ৙"): 0, l11l1l_opy_ (u"ࡷࠪࡸࡴࡺࡡ࡭ࠩ৚"): 1, l11l1l_opy_ (u"ࡸࠫࡪࡴࡤࠨ৛"): 1}}
    l1ll1ll_opy_ = result[l11l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࡵࠪড়")]
    l1ll1l1_opy_  = file(l1l_opy_, l11l1l_opy_ (u"ࠬࡽࠧঢ়"))
    l1ll1l1_opy_.write(l11l1l_opy_ (u"࡛࠭ࠨ৞"))
    l1ll1l1_opy_.write(addon)
    l1ll1l1_opy_.write(l11l1l_opy_ (u"ࠧ࡞ࠩয়"))
    l1ll1l1_opy_.write(l11l1l_opy_ (u"ࠨ࡞ࡱࠫৠ"))
    l1lll1_opy_ = []
    for channel in l1ll1ll_opy_:
        if addon == l11l1ll1l_opy_:
            l11l1lll1_opy_ = channel[l11l1l_opy_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨৡ")].split(l11l1l_opy_ (u"ࠪࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧৢ"), 1)[0].replace(l11l1l_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡸࡺࡥࡦ࡮ࡥࡰࡺ࡫࡝ࠨৣ"), l11l1l_opy_ (u"ࠬ࠭৤"))
            l11l1lll1_opy_ = l11l1lll1_opy_.replace(l11l1l_opy_ (u"࠭ࡕࡌ࠼ࠣࠫ৥"), l11l1l_opy_ (u"ࠧࠨ০"))
        else:
            l11l1lll1_opy_ = channel[l11l1l_opy_ (u"ࠨ࡮ࡤࡦࡪࡲࠧ১")].split(l11l1l_opy_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ২"), 1)[0].replace(l11l1l_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡻ࡭࡯ࡴࡦ࡟ࠪ৩"), l11l1l_opy_ (u"ࠫࠬ৪"))
            l11l1lll1_opy_ = l11l1lll1_opy_.replace(l11l1l_opy_ (u"ࠬࠦࠠࠨ৫"), l11l1l_opy_ (u"࠭ࠧ৬"))
            l11l1lll1_opy_ = l11l1lll1_opy_.replace(l11l1l_opy_ (u"ࠧࡖࡍ࠽ࠤࠬ৭"), l11l1l_opy_ (u"ࠨࠩ৮"))
            l11l1lll1_opy_ = l11l1lll1_opy_.replace(l11l1l_opy_ (u"ࠩࡘࡗࡆࡀࠠࠨ৯"), l11l1l_opy_ (u"ࠪࠫৰ"))
            l11l1lll1_opy_ = l11l1lll1_opy_.replace(l11l1l_opy_ (u"ࠫࡈࡇ࠺ࠡࠩৱ"), l11l1l_opy_ (u"ࠬ࠭৲"))
            l11l1lll1_opy_ = l11l1lll1_opy_.replace(l11l1l_opy_ (u"࠭ࡉࡏࡖ࠽ࠤࠬ৳"), l11l1l_opy_ (u"ࠧࠨ৴"))
        l1l11l_opy_  = dixie.mapChannelName(l11l1lll1_opy_)
        stream = channel[l11l1l_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭৵")]
        l11ll_opy_ = l1l11l_opy_ + l11l1l_opy_ (u"ࠩࡀࠫ৶") + stream
        l1lll1_opy_.append(l11ll_opy_)
        l1lll1_opy_.sort()
    for item in l1lll1_opy_:
      l1ll1l1_opy_.write(l11l1l_opy_ (u"ࠥࠩࡸࡢ࡮ࠣ৷") % item)
    l1ll1l1_opy_.close()
def l1l1llll1_opy_(addon):
    l11ll1l11_opy_ = (l11l1l_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡋ࡯࡬ࡦࡵ࠱ࡋࡪࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠦ࠿ࠨࠥࡴࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧ৸") % addon)
    if addon == l11lll1l1_opy_:
        login = l11l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡵࡧࡤࡰࡹ࡮ࡵ࡯ࡦࡨࡶ࡬ࡸ࡯ࡶࡰࡧ࠳ࡄࡳ࡯ࡥࡧࡀ࡫ࡪࡴࡲࡦࡵࠩࡴࡴࡸࡴࡢ࡮ࡀࠩ࠼ࡨࠥ࠳࠴ࡱࡥࡲ࡫ࠥ࠳࠴ࠨ࠷ࡦࠫ࠲࠱ࠧ࠵࠶ࠪ࠻ࡢࡊࠧ࠸ࡨࠪ࠻ࡢࡄࡑࡏࡓࡗࠫ࠲࠱ࡹ࡫࡭ࡹ࡫ࠥ࠶ࡦࡆࡰ࡮ࡩ࡫ࠦ࠴࠳ࡘࡴࠫ࠲࠱ࡘ࡬ࡩࡼࠫ࠲࠱ࡖ࡫ࡩࠪ࠸࠰ࡍ࡫ࡶࡸࠪ࠸࠰ࡐࡨࠨ࠶࠵ࡉࡨࡢࡰࡱࡩࡱࡹࠥ࠶ࡤࠨ࠶࡫ࡉࡏࡍࡑࡕࠩ࠺ࡪࠥ࠶ࡤࠨ࠶࡫ࡏࠥ࠶ࡦࠨ࠶࠷ࠫ࠲ࡤࠧ࠵࠴ࠪ࠸࠲ࡱࡣࡵࡩࡳࡺࡡ࡭ࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࠩ࠷࠸ࡦࡢ࡮ࡶࡩࠪ࠸࠲ࠦ࠴ࡦࠩ࠷࠶ࠥ࠳࠴ࡸࡶࡱࠫ࠲࠳ࠧ࠶ࡥࠪ࠸࠰ࠦ࠴࠵࡬ࡹࡺࡰࠦ࠵ࡤࠩ࠷࡬ࠥ࠳ࡨࡰࡻ࠶࠴ࡩࡱࡶࡹ࠺࠻࠴ࡴࡷࠧ࠵࠶ࠪ࠸ࡣࠦ࠴࠳ࠩ࠷࠸ࡰࡱࡣࡶࡷࡼࡵࡲࡥࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࠩ࠷࠸࠰࠱࠲࠳ࠩ࠷࠸ࠥ࠳ࡥࠨ࠶࠵ࠫ࠲࠳࡯ࡤࡧࠪ࠸࠲ࠦ࠵ࡤࠩ࠷࠶ࠥ࠳࠴࠳࠴ࠪ࠹ࡡ࠲ࡃࠨ࠷ࡦ࠽࠸ࠦ࠵ࡤ࠸࠸ࠫ࠳ࡢ࠳࠵ࠩ࠸ࡧ࠷࠵ࠧ࠵࠶ࠪ࠸ࡣࠦ࠴࠳ࠩ࠷࠸ࡳࡦࡴ࡬ࡥࡱࠫ࠲࠳ࠧ࠶ࡥࠪ࠸࠰ࠦ࠹ࡥࠩ࠷࠸ࡳࡦࡰࡧࡣࡸ࡫ࡲࡪࡣ࡯ࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࡺࡲࡶࡧࠨ࠶ࡨࠫ࠲࠱ࠧ࠵࠶ࡨࡻࡳࡵࡱࡰࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࡺࡲࡶࡧࠨ࠶ࡨࠫ࠲࠱ࠧ࠵࠶ࡸࡴࠥ࠳࠴ࠨ࠷ࡦࠫ࠲࠱ࠧ࠵࠶ࠪ࠸࠲ࠦ࠴ࡦࠩ࠷࠶ࠥ࠳࠴ࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࠪ࠸࠲ࠦ࠵ࡤࠩ࠷࠶ࠥ࠳࠴ࠨ࠶࠷ࠫ࠲ࡤࠧ࠵࠴ࠪ࠸࠲ࡥࡧࡹ࡭ࡨ࡫࡟ࡪࡦ࠵ࠩ࠷࠸ࠥ࠴ࡣࠨ࠶࠵ࠫ࠲࠳ࠧ࠵࠶ࠪ࠸ࡣࠦ࠴࠳ࠩ࠷࠸ࡤࡦࡸ࡬ࡧࡪࡥࡩࡥࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࠩ࠷࠸ࠥ࠳࠴ࠨ࠻ࡩࠫ࠲ࡤࠧ࠵࠴ࠪ࠸࠲ࡱࡣࡶࡷࡼࡵࡲࡥࠧ࠵࠶ࠪ࠹ࡡࠦ࠴࠳ࡲࡺࡲ࡬ࠦ࠴ࡦࠩ࠷࠶ࠥ࠳࠴࡯ࡳ࡬࡯࡮ࠦ࠴࠵ࠩ࠸ࡧࠥ࠳࠲ࡱࡹࡱࡲࠥ࠸ࡦࠪ৹")
    else:
        login = l11l1l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ৺") + addon + l11l1l_opy_ (u"ࠧ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿ࡶࡩࡨࡻࡲࡪࡶࡼࡣࡨ࡮ࡥࡤ࡭ࠩࡩࡽࡺࡲࡢࠨࡳࡥ࡬࡫ࠦࡱ࡮ࡲࡸࠫࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠧࡶ࡬ࡸࡱ࡫࠽ࡍ࡫ࡹࡩࠪ࠸࠰ࡕࡘࠩࡹࡷࡲࠧ৻")
    query = l11l11_opy_(addon)
    l11ll111l_opy_ = (l11l1l_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡈ࡬ࡰࡪࡹ࠮ࡈࡧࡷࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡪࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠼ࠥࠩࡸࠨࡽ࠭ࠢࠥ࡭ࡩࠨ࠺ࠡ࠳ࢀࠫৼ") % login)
    l11ll11l1_opy_ = (l11l1l_opy_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡉ࡭ࡱ࡫ࡳ࠯ࡉࡨࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡤࡪࡴࡨࡧࡹࡵࡲࡺࠤ࠽ࠦࠪࡹࠢࡾ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬ৽") % query)
    try:
        xbmc.executeJSONRPC(l11ll1l11_opy_)
        if addon != l11ll11ll_opy_:
            xbmc.executeJSONRPC(l11ll111l_opy_)
        response = xbmc.executeJSONRPC(l11ll11l1_opy_)
        content  = json.loads(response.decode(l11l1l_opy_ (u"ࠪࡹࡹ࡬࠭࠹ࠩ৾"), l11l1l_opy_ (u"ࠫ࡮࡭࡮ࡰࡴࡨࠫ৿")))
        return content
    except:
        dixie.log(l11l1l_opy_ (u"ࠬ࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳ࠠࡑ࡮ࡸ࡫࡮ࡴࠠࡆࡴࡵࡳࡷࠦ࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭ࠨ਀"))
        return {l11l1l_opy_ (u"࠭ࡅࡳࡴࡲࡶࠬਁ") : l11l1l_opy_ (u"ࠧࡑ࡮ࡸ࡫࡮ࡴࠠࡆࡴࡵࡳࡷ࠭ਂ")}
def l11l11_opy_(addon):
    if addon == l1llll1_opy_:
        return l11l1l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡉࡰࡦࡽ࡬ࡦࡵࡶࡘࡻ࠵࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࡴࡶࡵࡩࡦࡳ࡟ࡷ࡫ࡧࡩࡴࠬࡥࡹࡶࡵࡥࠫࡶࡡࡨࡧࠩࡴࡱࡵࡴࠧࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡁࠫࡺࡩࡵ࡮ࡨࡁࡆࡲ࡬ࠧࡷࡵࡰࡂ࠶ࠧਃ")
    if addon == l11ll11ll_opy_:
        return l11l1l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡶࡺࡿࡡࡪࡲࡷࡺ࠴ࡅࡡࡤࡶ࡬ࡳࡳࡃ࡬ࡪࡸࡨࡸࡻࡥࡡ࡭࡮ࠩࡩࡽࡺࡲࡢࠨࡳࡥ࡬࡫ࠦࡱ࡮ࡲࡸࠫࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠾ࠧ࠵ࡪ࡚ࡹࡥࡳࡵࠨ࠶࡫ࡸࡩࡤࡪࡤࡶࡩࠫ࠲ࡧࡎ࡬ࡦࡷࡧࡲࡺࠧ࠵ࡪࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠧ࠵࠴ࡘࡻࡰࡱࡱࡵࡸࠪ࠸ࡦࡌࡱࡧ࡭ࠪ࠸ࡦࡢࡦࡧࡳࡳࡹࠥ࠳ࡨࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡳࡸࡻࡹࡵࡣࡵ࠵࠲࠹ࠫ࠲ࡧࡴࡨࡷࡴࡻࡲࡤࡧࡶࠩ࠷࡬ࡩ࡮ࡩࠨ࠶࡫࡮࡯ࡵ࠰ࡳࡲ࡬ࠬࡴࡪࡶ࡯ࡩࡂࡇ࡬࡭ࠧ࠵࠴ࡨ࡮ࡡ࡯ࡰࡨࡰࡸࠬࡵࡳ࡮ࠪ਄")
    if addon == l11l1llll_opy_:
        return l11l1l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡶࡻࡩࡤ࡭࡬ࡴࡹࡼ࠯ࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡵࡷࡶࡪࡧ࡭ࡠࡸ࡬ࡨࡪࡵࠦࡦࡺࡷࡶࡦࠬࡰࡢࡩࡨࠪࡵࡲ࡯ࡵࠨࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡂࠬࡴࡪࡶ࡯ࡩࡂࡇ࡬࡭ࠨࡸࡶࡱࡃ࠰ࠨਅ")
    if addon == l11lll111_opy_:
        return l11l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࡬ࡵࡵࡷࡵࡩࡸࡺࡲࡦࡣࡰࡷ࠴ࡅࡡࡤࡶ࡬ࡳࡳࡃࡳࡵࡴࡨࡥࡲࡥࡶࡪࡦࡨࡳࠫ࡫ࡸࡵࡴࡤࠪࡵࡧࡧࡦࠨࡳࡰࡴࡺࠦࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡀࠪࡹ࡯ࡴ࡭ࡧࡀࡅࡱࡲࠦࡶࡴ࡯ࡁ࠵࠭ਆ")
    if addon == l11lll1l1_opy_:
        return l11l1l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡳࡵࡧࡤࡰࡹ࡮ࡵ࡯ࡦࡨࡶ࡬ࡸ࡯ࡶࡰࡧ࠳ࡄ࡭ࡥ࡯ࡴࡨࡣࡳࡧ࡭ࡦ࠿ࡄࡰࡱࠬࡰࡰࡴࡷࡥࡱࡃࠥ࠸ࡄࠨ࠶࠷ࡴࡡ࡮ࡧࠨ࠶࠷ࠫ࠳ࡂ࠭ࠨ࠶࠷ࠫ࠵ࡃࡋࠨ࠹ࡉࠫ࠵ࡃࡅࡒࡐࡔࡘࠫࡸࡪ࡬ࡸࡪࠫ࠵ࡅࡅ࡯࡭ࡨࡱࠫࡕࡱ࠮࡚࡮࡫ࡷࠬࡖ࡫ࡩ࠰ࡒࡩࡴࡶ࠮ࡓ࡫࠱ࡃࡩࡣࡱࡲࡪࡲࡳࠦ࠷ࡅࠩ࠷ࡌࡃࡐࡎࡒࡖࠪ࠻ࡄࠦ࠷ࡅࠩ࠷ࡌࡉࠦ࠷ࡇࠩ࠷࠸ࠥ࠳ࡅ࠮ࠩ࠷࠸ࡰࡢࡴࡨࡲࡹࡧ࡬ࠦ࠴࠵ࠩ࠸ࡇࠫࠦ࠴࠵ࡪࡦࡲࡳࡦࠧ࠵࠶ࠪ࠸ࡃࠬࠧ࠵࠶ࡺࡸ࡬ࠦ࠴࠵ࠩ࠸ࡇࠫࠦ࠴࠵࡬ࡹࡺࡰࠦ࠵ࡄࠩ࠷ࡌࠥ࠳ࡈࡰࡻ࠶࠴ࡩࡱࡶࡹ࠺࠻࠴ࡴࡷࠧ࠵࠶ࠪ࠸ࡃࠬࠧ࠵࠶ࡵࡶࡡࡴࡵࡺࡳࡷࡪࠥ࠳࠴ࠨ࠷ࡆ࠱ࠥ࠳࠴࠳࠴࠵࠶ࠥ࠳࠴ࠨ࠶ࡈ࠱ࠥ࠳࠴ࡰࡥࡨࠫ࠲࠳ࠧ࠶ࡅ࠰ࠫ࠲࠳࠲࠳ࠩ࠸ࡇ࠱ࡂࠧ࠶ࡅ࠼࠾ࠥ࠴ࡃ࠷࠷ࠪ࠹ࡁ࠲࠴ࠨ࠷ࡆ࠽࠴ࠦ࠴࠵ࠩ࠷ࡉࠫࠦ࠴࠵ࡷࡪࡸࡩࡢ࡮ࠨ࠶࠷ࠫ࠳ࡂ࠭ࠨ࠻ࡇࠫ࠲࠳ࡵࡨࡲࡩࡥࡳࡦࡴ࡬ࡥࡱࠫ࠲࠳ࠧ࠶ࡅ࠰ࡺࡲࡶࡧࠨ࠶ࡈ࠱ࠥ࠳࠴ࡦࡹࡸࡺ࡯࡮ࠧ࠵࠶ࠪ࠹ࡁࠬࡶࡵࡹࡪࠫ࠲ࡄ࠭ࠨ࠶࠷ࡹ࡮ࠦ࠴࠵ࠩ࠸ࡇࠫࠦ࠴࠵ࠩ࠷࠸ࠥ࠳ࡅ࠮ࠩ࠷࠸ࡳࡪࡩࡱࡥࡹࡻࡲࡦࠧ࠵࠶ࠪ࠹ࡁࠬࠧ࠵࠶ࠪ࠸࠲ࠦ࠴ࡆ࠯ࠪ࠸࠲ࡥࡧࡹ࡭ࡨ࡫࡟ࡪࡦ࠵ࠩ࠷࠸ࠥ࠴ࡃ࠮ࠩ࠷࠸ࠥ࠳࠴ࠨ࠶ࡈ࠱ࠥ࠳࠴ࡧࡩࡻ࡯ࡣࡦࡡ࡬ࡨࠪ࠸࠲ࠦ࠵ࡄ࠯ࠪ࠸࠲ࠦ࠴࠵ࠩ࠼ࡊࠥ࠳ࡅ࠮ࠩ࠷࠸ࡰࡢࡵࡶࡻࡴࡸࡤࠦ࠴࠵ࠩ࠸ࡇࠫ࡯ࡷ࡯ࡰࠪ࠸ࡃࠬࠧ࠵࠶ࡱࡵࡧࡪࡰࠨ࠶࠷ࠫ࠳ࡂ࠭ࡱࡹࡱࡲࠥ࠸ࡆࠩࡱࡴࡪࡥ࠾ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠩ࡫ࡪࡴࡲࡦࡡ࡬ࡨࡂࠫ࠲ࡂࠩਇ")
    else:
        Addon = xbmcaddon.Addon(addon)
        if addon == l11l1ll1l_opy_:
            username =  Addon.getSetting(l11l1l_opy_ (u"࠭ࡕࡴࡧࡵࡲࡦࡳࡥࠨਈ"))
            password =  Addon.getSetting(l11l1l_opy_ (u"ࠧࡑࡣࡶࡷࡼࡵࡲࡥࠩਉ"))
        else:
            username =  Addon.getSetting(l11l1l_opy_ (u"ࠨ࡭ࡤࡷࡺࡺࡡ࡫ࡣࡱ࡭ࡲ࡯ࠧਊ"))
            password =  Addon.getSetting(l11l1l_opy_ (u"ࠩࡶࡥࡱࡧࡳࡰࡰࡤࠫ਋"))
        l11l1ll11_opy_     = l11l1l_opy_ (u"ࠪ࠳ࡄࡧࡣࡵ࡫ࡲࡲࡂࡹࡴࡳࡧࡤࡱࡤࡼࡩࡥࡧࡲࠪࡪࡾࡴࡳࡣࠩࡴࡦ࡭ࡥࠧࡲ࡯ࡳࡹࠬࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠿ࠩࡸ࡮ࡺ࡬ࡦ࠿ࡄࡰࡱࠬࡵࡳ࡮ࡀࠫ਌")
        l1l1l1l1l_opy_  =  l1l1lll1l_opy_(addon)
        l1l111lll_opy_   = l11l1l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ਍") + addon
        l11ll1lll_opy_  =  l1l111lll_opy_ + l11l1ll11_opy_ + l1l1l1l1l_opy_
        l11llll11_opy_ = l11l1l_opy_ (u"ࠬࡻࡳࡦࡴࡱࡥࡲ࡫࠽ࠨ਎") + username + l11l1l_opy_ (u"࠭ࠦࡱࡣࡶࡷࡼࡵࡲࡥ࠿ࠪਏ") + password + l11l1l_opy_ (u"ࠧࠧࡶࡼࡴࡪࡃࡧࡦࡶࡢࡰ࡮ࡼࡥࡠࡵࡷࡶࡪࡧ࡭ࡴࠨࡦࡥࡹࡥࡩࡥ࠿࠳ࠫਐ")
        return l11ll1lll_opy_ + urllib.quote_plus(l11llll11_opy_)
def l1l1lll1l_opy_(addon):
    if (addon == l11ll1ll1_opy_) or (addon == l11lll1ll_opy_):
        return l11l1l_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠵࠺࠲࠶࠾࠷࠯࠳࠶࠽࠳࠷࠵࠶࠼࠻࠴࠵࠶࠯ࡦࡰ࡬࡫ࡲࡧ࠲࠯ࡲ࡫ࡴࡄ࠭਑")
    if addon == l11ll1111_opy_:
        return l11l1l_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡴ࡮ࡴࡺࡵࡸࡳࡶࡴ࠴ࡴ࡬࠼࠻࠴࠵࠶࠯ࡦࡰ࡬࡫ࡲࡧ࠲࠯ࡲ࡫ࡴࡄ࠭਒")
    if addon == l11l1ll1l_opy_:
        return l11l1l_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡳࡹࡺࡴࡷ࠰ࡪࡥ࠿࠸࠰࠺࠷࠲ࡩࡳ࡯ࡧ࡮ࡣ࠵࠲ࡵ࡮ࡰࡀࠩਓ")
def l1l11_opy_(addon, l1l11l_opy_):
    if (addon == l11ll1ll1_opy_) or (addon == l11lll1ll_opy_):
        l1l11l_opy_ = l1l11l_opy_.replace(l11l1l_opy_ (u"ࠫࠥࠦࠧਔ"), l11l1l_opy_ (u"ࠬࠦࠧਕ")).replace(l11l1l_opy_ (u"࠭ࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩਖ"), l11l1l_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩਗ"))
        return l1l11l_opy_
    return l1l11l_opy_
def l11ll1l1l_opy_(addon, l11lll11l_opy_):
    if (addon == l11ll1ll1_opy_) or (addon == l11lll1ll_opy_):
        channel = l11lll11l_opy_.rsplit(l11l1l_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪਘ"), 1)[0].split(l11l1l_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡺ࡬࡮ࡺࡥ࡞ࠩਙ"), 1)[-1]
        channel = channel.replace(l11l1l_opy_ (u"ࠪࡆࡇࡉࠠ࠲ࠩਚ"), l11l1l_opy_ (u"ࠫࡇࡈࡃࠡࡑࡱࡩࠬਛ")).replace(l11l1l_opy_ (u"ࠬࡈࡂࡄࠢ࠵ࠫਜ"), l11l1l_opy_ (u"࠭ࡂࡃࡅࠣࡘࡼࡵࠧਝ")).replace(l11l1l_opy_ (u"ࠧࡃࡄࡆࠤ࠹࠭ਞ"), l11l1l_opy_ (u"ࠨࡄࡅࡇࠥࡌࡏࡖࡔࠪਟ")).replace(l11l1l_opy_ (u"ࠩࡌࡘ࡛ࠦ࠱ࠨਠ"), l11l1l_opy_ (u"ࠪࡍ࡙࡜࠱ࠨਡ")).replace(l11l1l_opy_ (u"ࠫࡎ࡚ࡖࠡ࠴ࠪਢ"), l11l1l_opy_ (u"ࠬࡏࡔࡗ࠴ࠪਣ")).replace(l11l1l_opy_ (u"࠭ࡉࡕࡘࠣ࠷ࠬਤ"), l11l1l_opy_ (u"ࠧࡊࡖ࡙࠷ࠬਥ")).replace(l11l1l_opy_ (u"ࠨࡋࡗ࡚ࠥ࠺ࠧਦ"), l11l1l_opy_ (u"ࠩࡌࡘ࡛࠺ࠧਧ"))
        return channel
    if (addon == l11l1llll_opy_) or (addon == l11lll111_opy_):
        channel = l11lll11l_opy_.rsplit(l11l1l_opy_ (u"ࠪࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ਨ"))[0].replace(l11l1l_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡼ࡮ࡩࡵࡧࡠࠫ਩"), l11l1l_opy_ (u"ࠬ࠭ਪ"))
        channel = channel.replace(l11l1l_opy_ (u"࠭࠺ࠨਫ"), l11l1l_opy_ (u"ࠧࠨਬ")).replace(l11l1l_opy_ (u"ࠨࡄࡅࡇࠥ࠷ࠧਭ"), l11l1l_opy_ (u"ࠩࡅࡆࡈࠦࡏ࡯ࡧࠪਮ")).replace(l11l1l_opy_ (u"ࠪࡆࡇࡉࠠ࠳ࠩਯ"), l11l1l_opy_ (u"ࠫࡇࡈࡃࠡࡖࡺࡳࠬਰ")).replace(l11l1l_opy_ (u"ࠬࡈࡂࡄࠢ࠷ࠫ਱"), l11l1l_opy_ (u"࠭ࡂࡃࡅࠣࡊࡔ࡛ࡒࠨਲ")).replace(l11l1l_opy_ (u"ࠧࡊࡖ࡙ࠤ࠶࠭ਲ਼"), l11l1l_opy_ (u"ࠨࡋࡗ࡚࠶࠭਴")).replace(l11l1l_opy_ (u"ࠩࡌࡘ࡛ࠦ࠲ࠨਵ"), l11l1l_opy_ (u"ࠪࡍ࡙࡜࠲ࠨਸ਼")).replace(l11l1l_opy_ (u"ࠫࡎ࡚ࡖࠡ࠵ࠪ਷"), l11l1l_opy_ (u"ࠬࡏࡔࡗ࠵ࠪਸ")).replace(l11l1l_opy_ (u"࠭ࡉࡕࡘࠣ࠸ࠬਹ"), l11l1l_opy_ (u"ࠧࡊࡖ࡙࠸ࠬ਺"))
        return channel
    else:
        channel = l11lll11l_opy_.replace(l11l1l_opy_ (u"ࠨࡄࡅࡇࠥ࠷ࠧ਻"), l11l1l_opy_ (u"ࠩࡅࡆࡈࠦࡏ࡯ࡧ਼ࠪ")).replace(l11l1l_opy_ (u"ࠪࡆࡇࡉࠠ࠳ࠩ਽"), l11l1l_opy_ (u"ࠫࡇࡈࡃࠡࡖࡺࡳࠬਾ")).replace(l11l1l_opy_ (u"ࠬࡈࡂࡄࠢ࠷ࠫਿ"), l11l1l_opy_ (u"࠭ࡂࡃࡅࠣࡊࡔ࡛ࡒࠨੀ")).replace(l11l1l_opy_ (u"ࠧࡊࡖ࡙ࠤ࠶࠭ੁ"), l11l1l_opy_ (u"ࠨࡋࡗ࡚࠶࠭ੂ")).replace(l11l1l_opy_ (u"ࠩࡌࡘ࡛ࠦ࠲ࠨ੃"), l11l1l_opy_ (u"ࠪࡍ࡙࡜࠲ࠨ੄")).replace(l11l1l_opy_ (u"ࠫࡎ࡚ࡖࠡ࠵ࠪ੅"), l11l1l_opy_ (u"ࠬࡏࡔࡗ࠵ࠪ੆")).replace(l11l1l_opy_ (u"࠭ࡉࡕࡘࠣ࠸ࠬੇ"), l11l1l_opy_ (u"ࠧࡊࡖ࡙࠸ࠬੈ"))
        return channel
def l1lll11_opy_(e):
    l1l1l1_opy_ = l11l1l_opy_ (u"ࠨࡕࡲࡶࡷࡿࠬࠡࡣࡱࠤࡪࡸࡲࡰࡴࠣࡳࡨࡩࡵࡳࡧࡧ࠾ࠥࡐࡓࡐࡐࠣࡉࡷࡸ࡯ࡳ࠼ࠣࠩࡸ࠭੉")  %e
    l1l1ll_opy_ = l11l1l_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡹࡸࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡦࡰࡴࡸࡱ࠳࠭੊")
    l1ll11_opy_ = l11l1l_opy_ (u"࡙ࠪࡵࡲ࡯ࡢࡦࠣࡥࠥࡲ࡯ࡨࠢࡹ࡭ࡦࠦࡴࡩࡧࠣࡥࡩࡪ࡯࡯ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠤࡦࡴࡤࠡࡲࡲࡷࡹࠦࡴࡩࡧࠣࡰ࡮ࡴ࡫࠯ࠩੋ")
    dixie.log(e)
    dixie.DialogOK(l1l1l1_opy_, l1l1ll_opy_, l1ll11_opy_)
    dixie.SetSetting(SETTING, l11l1l_opy_ (u"ࠫࠬੌ"))