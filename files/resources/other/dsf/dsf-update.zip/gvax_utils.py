#
#       Copyright (C) 2015-
#       Sean Poyser (seanpoyser@gmail.com)
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with XBMC; see the file COPYING.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#


import xbmcaddon
import xbmc
import xbmcgui



def GetXBMCVersion():
    version = xbmcaddon.Addon('xbmc.addon').getAddonInfo('version')
    version = version.split('.')
    return int(version[0]), int(version[1]) #major, minor eg, 13.9.902


ADDONID = 'plugin.video.gvax'
ADDON   =  xbmcaddon.Addon(ADDONID)
HOME    =  xbmc.translatePath(ADDON.getAddonInfo('path'))
PROFILE =  xbmc.translatePath(ADDON.getAddonInfo('profile'))
VERSION =  ADDON.getAddonInfo('version')
TITLE   =  ADDON.getAddonInfo('name')
LOGO    =  ADDON.getAddonInfo('icon')
FANART  =  ADDON.getAddonInfo('fanart')
GETTEXT =  ADDON.getLocalizedString


USER    = ADDON.getSetting('username')
PASS    = ADDON.getSetting('password')
SUBSYS  = ADDON.getSetting('GVAX-SUBSYS')
REGION  = '1' #ADDON.getSetting('GVAX-REGION')

MAC = ''
while len(MAC.split(':')) <> 6: 
    xbmc.sleep(100)
    MAC = xbmc.getInfoLabel('Network.MacAddress')


MAJOR, MINOR = GetXBMCVersion()
FRODO        = (MAJOR == 12) and (MINOR < 9)
GOTHAM       = (MAJOR == 13) or (MAJOR == 12 and MINOR == 9)
HELIX        = (MAJOR == 14) or (MAJOR == 13 and MINOR == 9)
ISENGARD     = (MAJOR == 15) or (MAJOR == 14 and MINOR == 9)
JARVIS       = (MAJOR == 16) or (MAJOR == 15 and MINOR == 9)


DEBUG = ADDON.getSetting('DEBUG') == 'true'



def fix(text):
    text = str(text)
    ret = ''
    for ch in text:
        if ord(ch) < 128:
            ret += ch
    return ret.strip()


def log(text):
    try:
        output = '%s V%s : %s' % (TITLE, VERSION, fix(text))
        
        if DEBUG:
            xbmc.log(output)
        else:
            xbmc.log(output, xbmc.LOGDEBUG)
    except:
        pass


def DialogOK(line1, line2='', line3=''):
    d = xbmcgui.Dialog()
    d.ok(TITLE + ' - ' + VERSION, line1, line2 , line3)


def DialogNumber(line1, type=0):
    #0: ShowAndGetNumber    (default format: #)
    #1: ShowAndGetDate      (default format: DD/MM/YYYY)
    #2: ShowAndGetTime      (default format: HH:MM)
    #3: ShowAndGetIPAddress (default format: #.#.#.#)
    return xbmcgui.Dialog().numeric(type, line1)


def DialogYesNo(line1, line2='', line3='', noLabel=None, yesLabel=None):
    d = xbmcgui.Dialog()
    if noLabel == None or yesLabel == None:
        return d.yesno(TITLE + ' - ' + VERSION, line1, line2 , line3) == True
    else:
        return d.yesno(TITLE + ' - ' + VERSION, line1, line2 , line3, noLabel, yesLabel) == True


def Progress(title, line1 = '', line2 = '', line3 = ''):
    dp = xbmcgui.DialogProgress()
    dp.create(title, line1, line2, line3)
    dp.update(0)
    return dp


def showText(heading, text, waitForClose=False):
    id = 10147

    xbmc.executebuiltin('ActivateWindow(%d)' % id)
    xbmc.sleep(100)

    win = xbmcgui.Window(id)

    retry = 50
    while (retry > 0):
        try:
            xbmc.sleep(10)
            win.getControl(1).setLabel(heading)
            win.getControl(5).setText(text)
            retry = 0
        except:
            retry -= 1

    if waitForClose:
        while xbmc.getCondVisibility('Window.IsVisible(%d)' % id) == 1:
            xbmc.sleep(50)


def showChangelog(addonID=None):
    try:
        if addonID:
            ADDON = xbmcaddon.Addon(addonID)
        else: 
            ADDON = xbmcaddon.Addon(ADDONID)

        text  = sfile.read(ADDON.getAddonInfo('changelog'))
        title = '%s - %s' % (xbmc.getLocalizedString(24054), ADDON.getAddonInfo('name'))

        showText(title, text)

    except:
        pass


def showBusy():
    xbmc.executebuiltin('ActivateWindow(busydialog)')


def closeBusy():
    xbmc.executebuiltin('Dialog.Close(busydialog)')


def notify(message, length=5000):
    cmd = 'XBMC.notification(%s,%s,%d,%s)' % (TITLE, message, length, LOGO)
    xbmc.executebuiltin(cmd)


def openSettings(addonID=None, focus=None):
    print "IN OPEN SETTINGS"
    if not addonID:
        addonID = ADDONID

    if not focus: 
        return xbmcaddon.Addon(addonID).openSettings()
    
    try:
        xbmc.executebuiltin('Addon.OpenSettings(%s)' % addonID)

        value1, value2 = str(focus).split('.')

        if FRODO:
            xbmc.executebuiltin('SetFocus(%d)' % (int(value1) + 200))
            xbmc.executebuiltin('SetFocus(%d)' % (int(value2) + 100))
        else:
            xbmc.executebuiltin('SetFocus(%d)' % (int(value1) + 100))
            xbmc.executebuiltin('SetFocus(%d)' % (int(value2) + 200))
    except:
        pass