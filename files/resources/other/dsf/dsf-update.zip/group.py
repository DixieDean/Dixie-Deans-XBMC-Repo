#
#       Copyright (C) 2015
#       Sean Poyser (seanpoyser@gmail.com)
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with XBMC; see the file COPYING.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#

from channel import Channel

class Group(object):
    def __init__(self, data, mediaserver):       
        id        = data['id']
        name      = data['name']
        position  = data['position']
        logo      = mediaserver + data['logo']
        channels  = data['channel']['data']

        self.set(id, name, position, logo, channels, mediaserver)
        

    def set(self, id, name, position, logo, channels, mediaserver):
        self.id        = id
        self.name      = name
        self.position  = position
        self.logo      = logo
        self.channels  = []
 
        for channel in channels:
            try:    self.channels.append(Channel(channel, mediaserver))
            except: pass


    def __repr__(self):
        try:
            repr = 'Group(id=%s, name=%s, position=%s, logo=%s)' % (self.id, self.name, self.position, self.logo)
            print repr
            for channel in self.channels:
                repr += '\n\t' + str(channel)
            return repr
        except Exception, e:
            print str(e)
            return 'Can\'t display group'