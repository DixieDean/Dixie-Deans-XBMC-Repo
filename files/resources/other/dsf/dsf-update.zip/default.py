# -*- coding: utf-8 -*-
#
#      Copyright (C) 2015- Sean Poyser
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with XBMC; see the file COPYING.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#

import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui

import urllib

import gvax_utils as utils
import gvax

ADDON   = utils.ADDON
HOME    = utils.HOME
TITLE   = utils.TITLE
VERSION = utils.VERSION
LOGO    = utils.LOGO
FANART  = utils.FANART

DEBUG   = utils.DEBUG
GETTEXT = utils.GETTEXT


MAIN    = 0
CHANNEL = 100
EPG     = 200
MISSING = 300

RSS_GRAPHIC = 400
RSS_TEXT    = 500


def Main():
    isFolder   = False
    isPlayable = True

    channels = gvax.getSortedChannels()

    # AddDir(GETTEXT(30010), EPG,         isFolder=False)
    # AddDir(GETTEXT(30011), MISSING,     isFolder=False)
    AddDir(GETTEXT(30012), RSS_GRAPHIC, isFolder=False)
    AddDir(GETTEXT(30013), RSS_TEXT,    isFolder=False)

    for ch in channels:
        name        = ch.name
        mode        = CHANNEL
        channel     = name.lower()
        image       = ch.logo

        AddDir(name, mode, channel, image, isFolder, isPlayable)


def PlayChannel(_channel):
    from channel import Channel

    utils.log('Request to play channel : %s' % _channel)

    channel, url = gvax.getChannelAndPlaybackURL(_channel)

    if not url:
        utils.log('%s - Unable to start playback - %s' % (_channel, _channel))
        utils.DialogOK(_channel, GETTEXT(30001), channel)
        return

    name = urllib.unquote_plus(channel.name)
    liz = xbmcgui.ListItem(name, iconImage=channel.logo, thumbnailImage=channel.logo)
    liz.setInfo( type='Video', infoLabels={'Title':name})

    if DEBUG:
        utils.notify(url, 10000)

    liz.setPath(url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)


def CreateEPG():
    gvax.createEPG()


def AddDir(name, mode, channel='', image=None, isFolder=True, isPlayable=False, infoLabels=None, contextMenu=None):
    if not image:
        image = LOGO

    u  = sys.argv[0] 
    u += '?mode='      + str(mode)
    u += '&name='      + urllib.quote_plus(name.encode('utf-8'))


    if channel:
        u += '&channel=' + urllib.quote_plus(channel.encode('utf-8')) 

    if image:
        u += '&image=' + urllib.quote_plus(image)

    liz = xbmcgui.ListItem(urllib.unquote_plus(name), iconImage=image, thumbnailImage=image)

    if contextMenu:
        liz.addContextMenuItems(contextMenu)

    if infoLabels:
        liz.setInfo(type='Video', infoLabels=infoLabels)

    if isPlayable:
        liz.setProperty('IsPlayable','true')

    liz.setProperty('Fanart_Image', FANART)     

    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)


    
def get_params(path):
    params = {}
    path   = path.split('?', 1)[-1]
    pairs  = path.split('&')

    for pair in pairs:
        split = pair.split('=')
        if len(split) > 1:
            params[split[0]] = urllib.unquote_plus(split[1])

    return params
  

params = get_params(sys.argv[2])


try:    mode = int(params['mode'])
except: mode = None


try:
    channel = params['channel']
    mode    = CHANNEL
except:
    pass


if mode == CHANNEL:
    try:
        PlayChannel(channel)
    except:
        pass


if mode == EPG:
    CreateEPG()


if mode == MISSING:
    gvax.printMissingChannels()

if mode == RSS_GRAPHIC:
    import rss
    rss.getGraphic()


if mode == RSS_TEXT:
    import rss
    rss.getText()

else:
    Main()

xbmcplugin.endOfDirectory(int(sys.argv[1]))