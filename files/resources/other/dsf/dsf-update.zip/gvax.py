﻿# -*- coding: utf-8 -*-
#
#       Copyright (C) 2015-
#       Sean Poyser (seanpoyser@gmail.com)
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  aflong with XBMC; see the file COPYING.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#

import datetime
import urllib

import quicknet
import gvax_utils as utils


global MEDIASERVER
MEDIASERVER = ''

global EPGSERVER
EPGSERVER = ''

GETTEXT = utils.GETTEXT

URL = 'https://api.nubeetv.net/api/v1/'


USER    = utils.USER
PASS    = utils.PASS
SUBSYS  = utils.SUBSYS
REGION  = utils.REGION
MAC     = utils.MAC
VERSION = utils.VERSION #'my_clien_version1'


def getToken():
    if not USER or not PASS or not SUBSYS:
        utils.DialogOK(GETTEXT(30007))
        utils.openSettings(addonID=ADDON_ID, focus='5.0')
        return None
            
    data = {}
    url  = URL + 'login'

    data['login']     = USER
    data['pass']      = PASS
    data['subsystem'] = SUBSYS
    data['serial']    = MAC
    data['rvideos']   = '1'
    data['device']    = 'arm'
    data['region']    = REGION #1-Americas 2-Europe

    data['dmodel']    = 'Kodi'  #roku3'
    data['dver']      = 'Kodi'  #x2779'
    data['cver']      = VERSION

    url += '?%s' % urllib.quote_plus(str(data))   

    utils.log('getPost url  : %s' % url)
    utils.log('getPost data : %s' % data)

    json = quicknet.getPOST(url, data)

    if json['code'] <> 200:
        #try without cache
        json = quicknet.getPOST(url, data, maxSec=0)

    utils.log('POST response %s' % json)

    response = json['response']
    data     = response['data']
    token    = data['token']

    global MEDIASERVER
    MEDIASERVER = data['mediaserver']

    global EPGSERVER
    EPGSERVER = data['epgserver']

    utils.log('response    : %s' % response)
    utils.log('data        : %s' % data)
    utils.log('token       : %s' % token)
    utils.log('mediaserver : %s' % MEDIASERVER)
    utils.log('epgserver   : %s' % EPGSERVER)

    return token


def getGroups():
    from group import Group
    token = getToken()

    if not token:
        return []

    url = 'https://api.nubeetv.net/api/v1/channel_list?token=%s&subsystem=%s' % (token, SUBSYS)

    utils.log('url         : %s' % url)

    json = quicknet.getGET(url)

    response = json['response']
    data     = response['data']

    utils.log('response    : %s' % response)
    utils.log('data        : %s' % data)

    groups = []

    for group in data:
        try:    groups.append(Group(group, MEDIASERVER))
        except: pass

    return groups


def getChannels():
    groups = getGroups()
    channels = {}

    for group in groups:
        for channel in group.channels:
            name = channel.name.lower()
            if not name in channels:
                channels[name] = channel
            
    return channels


def getSortedChannels():
    channels = getChannels()

    toSort = []
    for channel in channels:
        toSort.append([channel, channels[channel]])

    toSort.sort()

    channels = []
    for channel in toSort:
        channels.append(channel[1])

    return channels


def getChannelAndPlaybackURL(_channel):
    try:
        channel   = mapChannel(_channel)
        channel   = getChannels()[channel.lower()]
        protected = channel.protected
        return _getChannelAndPlaybackURL(_channel, protected=protected)
    except:
        return GETTEXT(30003), None

def _getChannelAndPlaybackURL(channel, protected):
    pcode = ''
    if protected:
        pin = utils.DialogNumber(GETTEXT(30008))
        if pin:
            pcode = '&pcode=%s' % str(pin)
        else:
            return GETTEXT(30009), None

    jsn = {}
    try:
        channel = mapChannel(channel)
        channel = getChannels()[channel.lower()]
        url     = '%schannel_url?token=%s&subsystem=%s&cid=%d%s' % (URL, getToken(), SUBSYS, channel.id, pcode)

        jsn = quicknet.getGET(url)
        utils.log('Retrieving playback URL')
        utils.log(str(jsn))
        if 'response' in jsn:
            url = jsn['response']['url']
            if url.startswith('rtp:'):
                return GETTEXT(30004), None
            return channel,  url
    except:
        pass

    if 'message' in jsn:
        return jsn['message'], None

    return GETTEXT(30003), None



def mapChannel(channel):
    channel = channel.lower()

    if channel == 'whtmh 5170' : return 'abc'
    if channel == 'cnn 200' : return 'cnn'
    # if channel == 'comobia su musica' : return
    # if channel == 'disco tk' : return
    if channel == 'dsc 182' : return 'discovery'
    # if channel == 'dom telesistema' : return
    # if channel == 'ec uno' : return
    # if channel == 'el gourmet' : return
    if channel == 'espn brasil' : return 'espn deportes - usa'
    if channel == 'espnhd 681' : return 'espn'
    if channel == 'espn2hd 682' : return 'espn 2'
    if channel == 'events 1' : return 'events'
    if channel == 'events 2' : return 'events'
    if channel == 'wpmtdt1 5173' : return 'fox'
    if channel == 'fs1hd 689' : return 'fox sports 1'
    # if channel == 'fox sports 2 - la' : return
    # if channel == 'fx-hd' : return
    # if channel == 'globo' : return
    if channel == 'hist 340' : return 'history channel'
    if channel == 'la amc' : return 'amc'
    if channel == 'la cartoon network' : return 'cartoon network'
    if channel == 'la cine sony' : return 'cine sony'
    if channel == 'la cinemax' : return 'cinemax'
    # if channel == 'la comedy central' : return
    if channel == 'la discovery channel' : return 'discovery channel'
    # if channel == 'la discovery home' : return
    if channel == 'la disney channel' : 'disney channel'
    if channel == 'la disney junior' : return 'disney junior'
    if channel == 'la disney xd' : return 'disney xd'
    if channel == 'la encore' : return 'encore'
    if channel == 'la fox' : return 'fox'
    if channel == 'la hbo family' : return 'hbo family'
    if channel == 'la hbo signature' : return 'hbo signature'
    if channel == 'la hbo' : return 'hbo'
    if channel == 'la history channel' : return 'history channel'
    # if channel == 'la maxprime' : return
    if channel == 'la natgeo wild' : return 'natgeo'
    if channel == 'la national geographic' : return 'national geographic'
    if channel == 'la nick' : return 'nick'
    if channel == 'la paramount channel' : return 'paramount channel'
    if channel == 'la showcase' : return 'showcase'
    if channel == 'la showtime' : return 'showtime'
    if channel == 'la sony' : return 'sony'
    if channel == 'la starz' : return 'starz'
    if channel == 'la tnt' : return 'tnt'
    # if channel == 'melody channel' : return
    # if channel == 'milenio' : return
    # if channel == 'multimedios' : return
    if channel == 'ngc 186' : return 'national geographic'
    if channel == 'wgalhd 5172' : return 'nbc'
    if channel == 'nbcsp 382' : return 'nbc sports'
    if channel == 'panavision' : return u('panavisión')
    # if channel == 'pfc' : return
    # if channel == 'record' : return
    # if channel == 'skysports' : return
    # if channel == 'tbs usa' : return
    # if channel == 'tdn' : return
    # if channel == 'telecafe' : return
    # if channel == 'telemusica hit' : return
    # if channel == 'televen' : return
    # if channel == 'televitrola' : return
    if channel == 'tnt 138' : return 'tnt'
    # if channel == 'tv chile' : return
    # if channel == 'tvn' : return
    # if channel == 'zoomoo' : return

    return channel


def playChannel(channel):
    import xbmc
    cmd = 'PlayMedia(plugin://plugin.video.gvax/?channel=%s)' % mapChannel(channel)
    xbmc.executebuiltin(cmd) 


def getDate():
    now = datetime.datetime.today()
    return now.strftime('%d%m%y')


def writeProgram(program, channel, file):
    duration = program['duration']
    begin    = program['begin']
    end      = program['end']
    desc     = program['description'].encode('utf-8')
    title    = program['title'].encode('utf-8')

    begin = datetime.datetime.fromtimestamp(begin)
    end   = datetime.datetime.fromtimestamp(end)

    file.write('\t<programme ')
    file.write('start="%s" ' % begin.strftime('%Y%m%d%H%M%S'))
    file.write('stop="%s" ' % end.strftime('%Y%m%d%H%M%S'))
    file.write('channel="%s">\n' % channel.id)
    file.write('\t\t<title lang="en">%s</title>\n' % title)
    file.write('\t\t<desc lang="en">%s</desc>\n' % desc)
    file.write('\t</programme>\n')


def createEPG():
    import os

    utils.showBusy()

    channels = getSortedChannels()

    filename = os.path.join(utils.HOME ,'epg.xml')
    theFile  = file(filename, 'w')
 
    theFile.write('<?xml version="1.0" encoding="UTF-8"?>\n')
    theFile.write('<!DOCTYPE tv SYSTEM "xmltv.dtd"[]>\n')
    theFile.write('<tv source-info-name="GVAX-TV" generator-info-name="gvaxxml" generator-info-url="mailto:gvaxxml@gmail.com">\n')

    for channel in channels: 
        if not channel.has_epg:
            continue

        theFile.write('\t<channel id="%s">\n' % channel.id)
        theFile.write('\t\t<display-name>%s</display-name>\n' % channel.name.encode('utf-8'))
        theFile.write('\t</channel>\n')

    day   = getDate()
    range = 7
    token = getToken()

    for channel in channels:
        if not channel.has_epg:
            utils.log('Channel %s does NOT have EPG data' % channel.name.encode('utf-8'))
            continue

        url  = EPGSERVER
        url += '/api/v1/epg'
        url += '?cid=%d'       % channel.id
        url += '&day=%s'       % day
        url += '&range=%d'     % range
        url += '&token=%s'     % token
        url += '&subsystem=%s' % SUBSYS

        json = quicknet.getGET(url)
        if json['code'] <> 200:
            continue

        response = json['response']
        data     = response['data']

        utils.log('response : %s' % response)
        utils.log('data     : %s' % data)

        for program in data:
            writeProgram(program, channel, theFile)

    theFile.write('</tv>')

    theFile.close()

    utils.closeBusy()
    

def printMissingChannels():
    import os
    import re

    utils.showBusy()

    filename = os.path.join(utils.HOME ,'chan.xml')
    theFile = file(filename)
    xml = theFile.read()
    
    theFile.close()

    channels = getChannels()

    list = ''

    items = re.compile('<display-name lang="en">(.+?)</display-name>').findall(xml)
    for item in items:
        item = item.lower()
        if item.lower() not in channels:
            list += '    if channel == \'%s\' : return\r\n'  % item

    if len(list) == 0:
        print 'NO MISSING CHANNELS'
    else:
        text  = 'def mapChannel(channel):\r\n'
        text += '    channel = channel.lower()\r\n\r\n'
        text += list
        text += '\r\n    return channel'

        theFile = file(os.path.join(utils.HOME, 'missing.txt'),  'w')
        theFile.write(text)
        theFile.close()

    utils.closeBusy()
