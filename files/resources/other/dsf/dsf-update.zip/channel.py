#
#       Copyright (C) 2015
#       Sean Poyser (seanpoyser@gmail.com)
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with XBMC; see the file COPYING.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#

import urllib

class Channel(object):
    def __init__(self, data, mediaserver):       
        id         = data['id']
        name       = data['name']
        position   = data['position']
        logo       = mediaserver + data['logo']
        has_epg    = data['has_epg'] == 1
        channel_id = data['channel_id']
        protected  = data['protected'] == 1

        self.set(id, name, position, logo, has_epg, channel_id, protected)
        

    def set(self, id, name, position, logo, has_epg, channel_id, protected):
        try:
            self.id         = id
            self.name       = urllib.quote_plus(name.encode('utf-8').strip())
            self.position   = position
            self.logo       = logo
            self.has_epg    = has_epg
            self.channel_id = channel_id
            self.protected  = protected
        except:
            pass


    def __repr__(self):
        try:
            return 'Channel(id=%s name=%s position=%s logo=%s has_epg=%s channel_id=%s protected=%s)' % (self.id, self.name.encode('utf-8'), self.position, self.logo, self.has_epg, self.channel_id, self.protected)
        except:
            return 'Can\'t display channel'