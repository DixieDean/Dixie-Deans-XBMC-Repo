# coding: UTF-8
import sys
l11ll111_opy_ = sys.version_info [0] == 2
l1lll1l1_opy_ = 2048
l11lllll_opy_ = 7
def l1l11_opy_ (l11ll1_opy_):
	global l1llll11_opy_
	l1ll1111_opy_ = ord (l11ll1_opy_ [-1])
	l11ll11l_opy_ = l11ll1_opy_ [:-1]
	l11l11l_opy_ = l1ll1111_opy_ % len (l11ll11l_opy_)
	l111l1_opy_ = l11ll11l_opy_ [:l11l11l_opy_] + l11ll11l_opy_ [l11l11l_opy_:]
	if l11ll111_opy_:
		l1lll1_opy_ = unicode () .join ([unichr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	else:
		l1lll1_opy_ = str () .join ([chr (ord (char) - l1lll1l1_opy_ - (l1l1l_opy_ + l1ll1111_opy_) % l11lllll_opy_) for l1l1l_opy_, char in enumerate (l111l1_opy_)])
	return eval (l1lll1_opy_)
import datetime
import time
import urllib
import json
import os
import threading
import xbmc
import dixie
import sfile
from channel import GetChannelFromFile
PROFILE = xbmc.translatePath(dixie.PROFILE)
l1lll1ll1_opy_ = dixie.RecordingFolder()
def notify(message, length=5000):
    dixie.notify(message, length)
def __Run(l111111l_opy_, timeout=0):
    if l11111ll_opy_.platform() == l1l11_opy_ (u"ࠨࡡ࡯ࡦࡵࡳ࡮ࡪࠢࢣ"):
        return l11111l1_opy_(l111111l_opy_, timeout)
    l1llll111_opy_ = l1l11_opy_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡑࡴࡲࡧࡪࡹࡳࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡸࡺࡡࡳࡶࠪࢤ")
    if timeout > 0:
        path = l1ll1l1ll_opy_
        shell = True
        l1ll11lll_opy_ = None
        if os.name == l1l11_opy_ (u"ࠨࡰࡷࠫࢥ"):
            shell = False
            l1ll11lll_opy_ = subprocess.STARTUPINFO
            l1ll11lll_opy_.l1ll1lll1_opy_ |= subprocess._1llll11l_opy_.l1ll111ll_opy_
            l1ll11lll_opy_.l1ll111l1_opy_ = subprocess._1llll11l_opy_.l1111lll_opy_
        f  = open(path, mode=l1l11_opy_ (u"ࠩࡺࠫࢦ"))
        l1llll1ll_opy_ = subprocess.Popen(l111111l_opy_, shell=shell, stdout=f, startupinfo=l1ll11lll_opy_)
        xbmc.sleep(5000)
        while timeout > 0:
            xbmc.sleep(1000)
            timeout -= 1
            f1  = open(path, mode=l1l11_opy_ (u"ࠪࡶࠬࢧ"))
            l1llll111_opy_ = f1.read()
            f1.close()
            if l1ll1llll_opy_(l1llll111_opy_) or l1lll11l1_opy_(l1llll111_opy_):
                timeout = 0
        f.close()
    else:
        l1llll1ll_opy_  = subprocess.Popen(l111111l_opy_, shell=False, stdout=subprocess.PIPE)
        l1llll111_opy_ = l1llll1ll_opy_.stdout.read()
        l1llll1ll_opy_.stdout.close()
    return l1llll111_opy_
class l1lllllll_opy_(threading.Thread):
    def __init__(self, title, channel, l111l111_opy_, duration, channelID, stream, image):
        super(l1lllllll_opy_, self).__init__()
        self.title     = title.replace(l1l11_opy_ (u"ࠫࢃ࠭ࢨ"), l1l11_opy_ (u"ࠬ࠳ࠧࢩ"))
        self.channel   = channel
        self.l111l111_opy_ = l111l111_opy_
        self.duration  = duration
        self.channelID = channelID
        self.stream    = stream
        self.image     = image
        self.l1111l11_opy_ = True
        self.pid       = 0
        self.key       = l1l11_opy_ (u"࠭ࠧࢪ")
        self.l1ll11ll1_opy_    = l1l11_opy_ (u"ࠧࠨࢫ")
        self.filename  = l1l11_opy_ (u"ࠨࠩࢬ")
    def run(self):
        l1111111_opy_ = self.l1ll11l1l_opy_()
        f = 1 if l1111111_opy_ else 5
        self.key      = sfile.fileSystemSafe(l1l11_opy_ (u"ࠩࠨࡷࠥࢄࠠࠦࡵࠣࢂࠥࠫࡳࠨࢭ") % (self.title, self.l111l111_opy_, self.channelID))
        self.l1ll11ll1_opy_   = os.path.join(l1lll1ll1_opy_, sfile.fileSystemSafe(self.title))
        self.filename = os.path.join(self.l1ll11ll1_opy_, l1l11_opy_ (u"ࠪࠩࡸ࠴ࡡࡷ࡫ࠪࢮ") % self.key)
        if sfile.exists(self.filename):
            return
        l1ll1l1l1_opy_ = os.path.join(PROFILE, l1l11_opy_ (u"ࠫ࡫࡬࡭ࡱࡧࡪࠫࢯ"), l1l11_opy_ (u"ࠬ࡬ࡦ࡮ࡲࡨ࡫ࠬࢰ"))
        sfile.makedirs(self.l1ll11ll1_opy_)
        sfile.remove(self.filename)
        args = l1l11_opy_ (u"࠭࠭ࡪࠢࠥࠩࡸࠨࠠ࠮ࡥࡲࡨࡪࡩࠠࡤࡱࡳࡽࠥ࠳ࡴࠡࠧࡧࠤࠧࠫࡳࠣࠩࢱ") % (self.stream, int(self.duration/f), xbmc.translatePath(self.filename))
        cmd = l1l11_opy_ (u"ࠧࠣࠧࡶࠦࠥࠫࡳࠨࢲ") % (l1ll1l1l1_opy_, args)
        msg = l1l11_opy_ (u"ࠨࡐࡲࡻࠥࡸࡥࡤࡱࡵࡨ࡮ࡴࡧࠡࠧࡶࠫࢳ") % self.title
        notify(msg)
        self.record(cmd)
    def l1ll11l1l_opy_(self):
        if xbmc.getCondVisibility(l1l11_opy_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡋࡥࡸࡇࡤࡥࡱࡱࠬࡸࡩࡲࡪࡲࡷ࠲ࡹࡼࡧࡶ࡫ࡧࡩࡩ࡯ࡸࡪࡧࠬࠫࢴ")) == 1:
            return True
        return False
    def record(self, cmd, l1lllll1l_opy_=None, l1lllll11_opy_=l1l11_opy_ (u"ࠪ࠲࠴࠭ࢵ")):
        from subprocess import Popen, PIPE, STDOUT
        env = os.environ
        envname = l1l11_opy_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࡔࡆ࡚ࡈࠨࢶ")
        try:    env[envname] = env[envname] + l1l11_opy_ (u"ࠧࡀࠢࢷ") + l1lllll11_opy_
        except: env[envname] = l1lllll11_opy_
        if l1lllll1l_opy_:
            envname = l1l11_opy_ (u"࠭ࡌࡅࡡࡏࡍࡇࡘࡁࡓ࡛ࡢࡔࡆ࡚ࡈࠨࢸ")
            try:    env[envname] = env[envname] + l1l11_opy_ (u"ࠢ࠻ࠤࢹ") + l1lllll1l_opy_
            except: env[envname] = l1lllll1l_opy_
            envname = l1l11_opy_ (u"ࠨࡆ࡜ࡐࡉࡥࡌࡊࡄࡕࡅࡗ࡟࡟ࡑࡃࡗࡌࠬࢺ")
            try:    env[envname] = env[envname] + l1l11_opy_ (u"ࠤ࠽ࠦࢻ") + l1lllll1l_opy_
            except: env[envname] = l1lllll1l_opy_
        now = datetime.datetime.now()
        shell = True
        l1ll11lll_opy_    = None
        if os.name == l1l11_opy_ (u"ࠪࡲࡹ࠭ࢼ"):
            from subprocess import STARTUPINFO, _1llll11l_opy_
            shell          = False
            l1ll11lll_opy_             = STARTUPINFO
            l1ll11lll_opy_.l1ll111l1_opy_ = _1llll11l_opy_.l1111lll_opy_
            l1ll11lll_opy_.l1ll1lll1_opy_    |= _1llll11l_opy_.l1ll111ll_opy_
        l1ll1l111_opy_    = Popen(cmd, shell=shell, env=env, stdin=None, stdout=None, stderr=None, startupinfo=l1ll11lll_opy_)
        self.pid = l1ll1l111_opy_.pid
        self.l1lll1lll_opy_()
        while l1ll1l111_opy_.poll() == None:
            xbmc.sleep(1000)
        l1111l1l_opy_  = l1ll1l111_opy_.returncode
        self.pid = 0
        end    = datetime.datetime.now()
        l1ll1ll1l_opy_  = end - now
        l1ll1ll1l_opy_  = (l1ll1ll1l_opy_.days * 86400) + l1ll1ll1l_opy_.seconds
        l1ll1ll1l_opy_ += 30
        self.l1111l11_opy_ = (l1111l1l_opy_ != 0 or l1ll1ll1l_opy_ < self.duration)
        self.l1lll1lll_opy_()
    def l1lll1lll_opy_(self):
        l1lll111l_opy_ = os.path.join(l1lll1ll1_opy_, l1l11_opy_ (u"ࠫࡷ࡫ࡣࡰࡴࡧ࡭ࡳ࡭ࡳ࠯ࡶࡻࡸࠬࢽ"))
        try:
            info = json.loads(sfile.read(l1lll111l_opy_))
        except Exception, e:
            info = {}
        l1lll11ll_opy_ = {}
        l1lll11ll_opy_[l1l11_opy_ (u"ࠬࡺࡩࡵ࡮ࡨࠫࢾ")]     = self.title
        l1lll11ll_opy_[l1l11_opy_ (u"࠭ࡣࡩࡣࡱࡲࡪࡲࠧࢿ")]   = self.channel.title
        l1lll11ll_opy_[l1l11_opy_ (u"ࠧࡴࡶࡤࡶࡹࡊࡡࡵࡧࠪࣀ")] = self.l111l111_opy_
        l1lll11ll_opy_[l1l11_opy_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪࣁ")]  = self.duration
        l1lll11ll_opy_[l1l11_opy_ (u"ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࡌࡈࠬࣂ")] = self.channelID
        l1lll11ll_opy_[l1l11_opy_ (u"ࠪࡷࡹࡸࡥࡢ࡯ࠪࣃ")]    = self.stream
        l1lll11ll_opy_[l1l11_opy_ (u"ࠫ࡮ࡳࡡࡨࡧࠪࣄ")]     = self.image
        l1lll11ll_opy_[l1l11_opy_ (u"ࠬࡺࡲࡶࡰࡦࡥࡹ࡫ࡤࠨࣅ")] = self.l1111l11_opy_
        l1lll11ll_opy_[l1l11_opy_ (u"࠭ࡰࡪࡦࠪࣆ")]       = self.pid
        l1lll11ll_opy_[l1l11_opy_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧࣇ")]    = self.l1ll11ll1_opy_
        l1lll11ll_opy_[l1l11_opy_ (u"ࠨࡨ࡬ࡰࡪࡴࡡ࡮ࡧࠪࣈ")]  = self.filename
        info[self.key] = l1lll11ll_opy_
        try:
            sfile.write(l1lll111l_opy_, json.dumps(info))
        except Exception, e:
            pass
def main(channelID, title, start, duration, image):
    l1ll1l11l_opy_ = dixie.IsRecordingEnabled()
    if not l1ll1l11l_opy_:
        return
    try:
        record(channelID, title, start, duration, image)
    except Exception, e:
        dixie.DialogOK(l1l11_opy_ (u"ࠩࡉࡅࡎࡒࡅࡅࠩࣉ"), str(e))
def record(channelID, title, l111l111_opy_, duration, image):
    duration  = int(duration)
    l111l111_opy_ = dixie.parseTime(l111l111_opy_)
    now       = datetime.datetime.now()
    l1llll1l1_opy_ = l111l111_opy_ - now
    l1llll1l1_opy_ = ((l1llll1l1_opy_.days * 86400) + l1llll1l1_opy_.seconds)
    l1lll1111_opy_   = dixie.RecordingEndPad() * 60
    l1111ll1_opy_  = l111l111_opy_ + datetime.timedelta(minutes=duration) + datetime.timedelta(minutes=l1lll1111_opy_)
    duration += l1llll1l1_opy_ + l1lll1111_opy_
    channel = l1ll1ll11_opy_(channelID)
    stream  = l1lll1l1l_opy_(channel, 0)
    if not stream:
        raise Exception(l1l11_opy_ (u"ࠪࡲࡴࠦࡳࡵࡴࡨࡥࡲ࠭࣊"))
    l1lll1l11_opy_ = l1lllllll_opy_(title, channel, start, duration, channelID, stream, image)
    l1lll1l11_opy_.start()
def l1llllll1_opy_(path):
    params = {}
    path   = path.split(l1l11_opy_ (u"ࠫࡄ࠭࣋"), 1)[-1]
    pairs  = path.split(l1l11_opy_ (u"ࠬࠬࠧ࣌"))
    for pair in pairs:
        split = pair.split(l1l11_opy_ (u"࠭࠽ࠨ࣍"))
        if len(split) > 1:
            params[split[0]] = urllib.unquote_plus(split[1])
    return params
def l1lll1l1l_opy_(channel, index):
    if not channel:
        return None
    return getStreamFromChannel(channel, index)
def getStreamFromChannel(channel, index):
    streamUrl = getStreamUrl(channel, index)
    if not streamUrl:
        return None
    import resolver
    stream, play = resolver.resolve(streamUrl, recording=True)
    if not stream:
        return getStreamFromChannel(channel, index+1)
    params = l1llllll1_opy_(stream)
    if l1l11_opy_ (u"ࠧࡶࡴ࡯ࠫ࣎") not in params:
        return getStreamFromChannel(channel, index+1)
    stream = params[l1l11_opy_ (u"ࠨࡷࡵࡰ࣏ࠬ")]
    return stream
def l1ll1ll11_opy_(channelID):
    l1ll11ll1_opy_   = dixie.GetChannelFolder()
    filename = os.path.join(l1ll11ll1_opy_, l1l11_opy_ (u"ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶ࣐ࠫ"), channelID)
    return GetChannelFromFile(filename)
def getStreamUrl(channel, index):
    try:
        import plugins
        options, l1ll11l11_opy_ = plugins.getOptions(channel.streamUrl.split(l1l11_opy_ (u"ࠪࢀ࣑ࠬ")), channel=l1l11_opy_ (u"࣒ࠫࠬ"), addmore=False)
        return l1ll11l11_opy_[index]
    except Exception, e:
        dixie.DialogOK(l1l11_opy_ (u"ࠧࡋࡲࡳࡱࡵ࣓ࠦ"), str(e))
        pass
    return None
if __name__ == l1l11_opy_ (u"࠭࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠨࣔ"):
    try:
        channelID  = sys.argv[1]
        title      = sys.argv[2]
        start      = sys.argv[3]
        duration   = sys.argv[4]
        image      = sys.argv[5]
        main(channelID, title, start, duration, image)
    except Exception, e:
        dixie.DialogOK(str(e))
        raise(e)